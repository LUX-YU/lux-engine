from pathlib import Path
b=Path('E:/RenderV2Rebuild/Layer/source/modules/function/render')
p=b/'resource/include/lux/engine/render/resource/Factory.hpp';s=p.read_text().replace('    struct StorageFactory final','    namespace resource_detail { struct StorageFactoryAudit; }\n\n    struct StorageFactory final');needle='        StorageCppType ops_type;';s=s.replace(needle,needle+'''

    private:
        friend struct resource_detail::StorageFactoryAudit;
        template <class Declaration, class Native, class Device, auto Create, auto Compatible>
            requires std::same_as<decltype(Create), RenderResult<std::unique_ptr<Native>> (*)(
                Device&, const typename Declaration::Config&) noexcept> &&
                std::same_as<decltype(Compatible), bool (*)(const Native&, const typename Declaration::Config&) noexcept>
        friend StorageFactory makeStorageFactory(
            EGraphicsApi, const typename Declaration::Ops&, const void*, void (*)(void*) noexcept, std::shared_ptr<const void>
        ) noexcept;

        StorageFactory(const StorageDescriptor* description, EGraphicsApi api, const void* ops,
            RenderResult<NativeStorage> (*create)(void*, const void*) noexcept,
            bool (*compatible_config)(const void*, const void*) noexcept,
            std::shared_ptr<const void> code_pin, const void* binding_ops, void (*collect)(void*) noexcept,
            StorageCppType config_type, StorageCppType ops_type) noexcept
            : description(description), api(api), ops(ops), create(create), compatible_config(compatible_config),
              code_pin(std::move(code_pin)), binding_ops(binding_ops), collect(collect),
              config_type(config_type), ops_type(ops_type) {}
''');p.write_text(s)
p=b/'resource/test/FactoryAudit.hpp';p.write_text('''#pragma once

#include <lux/engine/render/resource/Factory.hpp>

namespace lux::render::resource_detail
{
    // Explicitly trusted malformed-factory boundary used only by historical negative/cost fixtures.
    struct StorageFactoryAudit final
    {
        static StorageFactory make(const StorageDescriptor* description, EGraphicsApi api, const void* ops,
            RenderResult<NativeStorage> (*create)(void*, const void*) noexcept,
            bool (*compatible)(const void*, const void*) noexcept,
            std::shared_ptr<const void> pin, const void* bindings, void (*collect)(void*) noexcept,
            StorageCppType config_type, StorageCppType ops_type) noexcept
        {
            return {description, api, ops, create, compatible, std::move(pin), bindings, collect, config_type, ops_type};
        }
    };
}
''')
for rel in ['resource/test/Registry.cpp','resource/test/Storage.cpp','native/vulkan/test/BufferStorageFixture.hpp','native/vulkan/test/MemoryCost.cpp']:
 p=b/rel;s=p.read_text();include='FactoryAudit.hpp' if rel.startswith('resource') else '../../../resource/test/FactoryAudit.hpp';s='#include "'+include+'"\n'+s
 if rel.endswith('Registry.cpp') or rel.endswith('BufferStorageFixture.hpp'):
  a=s.index('        return {\n            &');z=s.index('\n        };',a);s=s[:a]+s[a:z].replace('return {','return resource_detail::StorageFactoryAudit::make(',1)+s[z:].replace('\n        };','\n        );',1)
 else:
  a=s.index('StorageFactory factory{');start=a+len('StorageFactory factory');depth=1;i=start+1
  while depth:depth+=(s[i]=='{')-(s[i]=='}');i+=1
  s=s[:a]+'auto factory = resource_detail::StorageFactoryAudit::make('+s[start+1:i-1]+')'+s[i:]
 p.write_text(s)
# Session explicit installation alternative, using the same template as real Texture/TestBuffer.
(b/'native/vulkan/test/ExplicitFactory.cpp').write_text('''#include "Support.hpp"
#include <lux/engine/render/native/vulkan/DeviceSession.hpp>
#include <lux/engine/render/resource/Texture.hpp>

using namespace foundation_test;
using Declaration = lux::render::TextureStorage;

static unsigned created = 0, destroyed = 0;
struct Replacement final
{
    TextureStorageConfig config;
    ~Replacement() noexcept { ++destroyed; }
};

static RenderResult<std::unique_ptr<Replacement>> createReplacement(
    DeviceSession&, const TextureStorageConfig& config) noexcept
{
    ++created;
    return std::make_unique<Replacement>(config);
}

static bool compatible(const Replacement& value, const TextureStorageConfig& config) noexcept
{
    return value.config == config;
}

int main()
{
    Validation validation;
    auto bootstrap = instance(validation);
    DeviceOptions options;
    options.texture_descriptors = true;
    auto session = take(DeviceSession::create(bootstrap, options));
    auto& registry = session->resources();
    CHECK(registry.factory(Declaration::description.type) == nullptr && registry.size() == 0);
    static const Declaration::Ops ops{
        [](const void*, TextureId id) noexcept -> RenderResult<TexturePublished> { return TexturePublished{id, 991}; },
        [](void*, TextureId, std::uint64_t) noexcept -> RenderResult<void> { return {}; }
    };
    auto factory = makeStorageFactory<Declaration, Replacement, DeviceSession, createReplacement, compatible>(
        EGraphicsApi::VULKAN, ops);
    CHECK(registry.installFactory(factory));
    CHECK(!registry.installFactory(factory));
    CHECK(registry.configureType(Declaration::description, std::make_shared<const TextureStorageConfig>()));
    registry.freeze();
    auto access = take(registry.getOrCreate<Declaration>(registry.root(), "explicit"));
    CHECK(created == 1 && take(access.query(TextureId{2, 3})).revision == 991);
    session.reset();
    CHECK(created == destroyed && validation.errors == 0);
}
''')
p=b/'native/vulkan/test/CMakeLists.txt';s=p.read_text()+'''
add_executable(render_explicit_factory_test ExplicitFactory.cpp)

target_link_libraries(render_explicit_factory_test PRIVATE render_native_vulkan)

add_test(NAME render.native.explicit_factory COMMAND render_explicit_factory_test)

set_tests_properties(render.native.explicit_factory PROPERTIES TIMEOUT 60)
''';p.write_text(s)
