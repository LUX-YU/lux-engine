#pragma once
// Generated typed Lua projection. Include the matching .ability.generated.hpp first.
#include <lux/engine/simulation/scripting/lua/LuaScriptAbilityProjection.hpp>

#include <array>
#include <type_traits>
#include <utility>

namespace lux::script::lua
{

    template <>
    struct ScriptAbilityLuaTraits<::lux::simulation::script::test::LuaRuntimeTestAbility> final
    {
        using AbilityTraits = ScriptAbilityTraits<::lux::simulation::script::test::LuaRuntimeTestAbility>;
        using Policy = typename ScriptAbilityLuaPolicy<::lux::simulation::script::test::LuaRuntimeTestAbility>::Type;

        using Values_readValue = LuaAbilityValueSignature<Policy, int, int>;
        [[nodiscard]] static int readValue(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, int, int>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, int input) noexcept -> int
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.readValue(access.context, input);
                }
            );
        }

        using Values_writeValue = LuaAbilityValueSignature<Policy, void, int>;
        [[nodiscard]] static int writeValue(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, void, int>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, int value) noexcept -> void
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    dispatch.writeValue(access.context, value);
                }
            );
        }

        using Values_borrowValue = LuaAbilityValueSignature<Policy, const int &>;
        [[nodiscard]] static int borrowValue(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, const int &>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access) noexcept -> const int &
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.borrowValue(access.context);
                }
            );
        }

        using Values_echoBool = LuaAbilityValueSignature<Policy, bool, bool>;
        [[nodiscard]] static int echoBool(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, bool, bool>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, bool value) noexcept -> bool
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.echoBool(access.context, value);
                }
            );
        }

        using Values_echoI32 = LuaAbilityValueSignature<Policy, int, int>;
        [[nodiscard]] static int echoI32(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, int, int>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, int value) noexcept -> int
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.echoI32(access.context, value);
                }
            );
        }

        using Values_echoU32 = LuaAbilityValueSignature<Policy, unsigned int, unsigned int>;
        [[nodiscard]] static int echoU32(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, unsigned int, unsigned int>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, unsigned int value) noexcept -> unsigned int
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.echoU32(access.context, value);
                }
            );
        }

        using Values_echoF32 = LuaAbilityValueSignature<Policy, float, float>;
        [[nodiscard]] static int echoF32(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, float, float>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, float value) noexcept -> float
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.echoF32(access.context, value);
                }
            );
        }

        using Values_echoF64 = LuaAbilityValueSignature<Policy, double, double>;
        [[nodiscard]] static int echoF64(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, double, double>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, double value) noexcept -> double
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.echoF64(access.context, value);
                }
            );
        }

        using Values_beginOperation = LuaAbilityValueSignature<Policy, int, int>;
        [[nodiscard]] static int beginOperation(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::startLuaValueAbility<Policy, int, int>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, int input, ScriptAbilityCompletion<int> completion) noexcept
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.beginOperation(access.context, input, std::move(completion));
                }
            );
        }

        inline static constexpr std::array<ScriptAbilityLuaMethodProjection, AbilityTraits::Methods.size()> Methods{
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.lua_runtime.read"},
                &readValue, Values_readValue::Parameters, Values_readValue::Results
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.lua_runtime.write"},
                &writeValue, Values_writeValue::Parameters, Values_writeValue::Results
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.lua_runtime.borrow"},
                &borrowValue, Values_borrowValue::Parameters, Values_borrowValue::Results
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.lua_runtime.echo_bool"},
                &echoBool, Values_echoBool::Parameters, Values_echoBool::Results
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.lua_runtime.echo_i32"},
                &echoI32, Values_echoI32::Parameters, Values_echoI32::Results
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.lua_runtime.echo_u32"},
                &echoU32, Values_echoU32::Parameters, Values_echoU32::Results
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.lua_runtime.echo_f32"},
                &echoF32, Values_echoF32::Parameters, Values_echoF32::Results
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.lua_runtime.echo_f64"},
                &echoF64, Values_echoF64::Parameters, Values_echoF64::Results
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.lua_runtime.begin"},
                &beginOperation, Values_beginOperation::Parameters, Values_beginOperation::Results
            }
        };
    };
} // namespace lux::script::lua
