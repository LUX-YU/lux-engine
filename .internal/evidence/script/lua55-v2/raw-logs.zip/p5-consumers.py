from pathlib import Path
import re
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source')
p=r/'engine/toolchain/flowforge/src/AOT.cpp';t=p.read_text(); t=t.replace('auto* start_type = llvm::FunctionType::get(i32, {ptr_type, ptr_type, ptr_type, ptr_type}, false);','auto* start_type = llvm::FunctionType::get(i32, {ptr_type, ptr_type, ptr_type, ptr_type, ptr_type}, false);'); t=t.replace('''            auto* call_frame = result.start->getArg(0);
            auto* start_host = result.start->getArg(1);
            auto* start_frame = result.start->getArg(2);
            auto* start_outcome = result.start->getArg(3);''','''            auto* native_instance = result.start->getArg(0);
            auto* call_frame = result.start->getArg(1);
            auto* start_host = result.start->getArg(2);
            auto* start_frame = result.start->getArg(3);
            auto* start_outcome = result.start->getArg(4);'''); t=t.replace('''            auto* native_instance = start_builder.CreateLoad(
                ptr_type,
                start_field(call_frame, offsetof(lux_script_call_frame, native_instance))
            );
''',''); t=t.replace('auto* wrap_ft = llvm::FunctionType::get(i32, {ptr_ty}, false);','auto* wrap_ft = llvm::FunctionType::get(i32, {ptr_ty, ptr_ty}, false);').replace('llvm::Value* frame = wrap->getArg(0);','llvm::Value* native_instance = wrap->getArg(0);\n            llvm::Value* frame = wrap->getArg(1);'); t=t.replace('''            llvm::Value* native_instance = b.CreateLoad(
                ptr_ty,
                gepByte(frame, offsetof(lux_script_call_frame, native_instance)),
                "native.instance"
            );
''','');t=t.replace('{i32, i32, i64, ptr_ty, ptr_ty, ptr_ty}, "lux_script_step_desc"','{i32, i32, i64, ptr_ty, ptr_ty, ptr_ty, i32, i32}, "lux_script_step_desc"');t=t.replace('steps[e].destroy}','steps[e].destroy,\n                             llvm::ConstantInt::get(i32, LUX_SCRIPT_FRAME_ZEROED_BY_HOST),\n                             llvm::ConstantInt::get(i32, 0U)}'); t=t.replace('frame_hash = appendFrameHash(frame_hash, result.frame_align);','frame_hash = appendFrameHash(frame_hash, result.frame_align);\n            frame_hash = appendFrameHash(frame_hash, LUX_SCRIPT_FRAME_ZEROED_BY_HOST);');p.write_text(t)
# Explicit native contexts in actual consumers; mutable descriptor address is ABI context, fields read-only.
p=r/'modules/function/script/native/test/install_consumer/main.cpp';t=p.read_text().replace('    lux_script_call_frame frame{};','    lux_script_native_instance_context context{&value};\n    lux_script_call_frame frame{};').replace('increment->invoke(&frame)','increment->invoke(&context, &frame)');p.write_text(t)
p=r/'modules/function/script/native/test/script_native_runtime_contract_test.cpp';t=p.read_text().replace('    lux_script_call_frame raw{};','    lux_script_native_instance_context context{&counter};\n    lux_script_call_frame raw{};').replace('function->invoke(&raw)','function->invoke(&context, &raw)').replace('function->invoke(&failing_raw)','function->invoke(nullptr, &failing_raw)');p.write_text(t)
p=r/'engine/toolchain/flowforge/test/flowforge_aot_test.cpp';t=p.read_text(); # context formerly raw state, recover original from git
import subprocess
old=subprocess.check_output(['git','show','HEAD:'+str(p.relative_to(r)).replace('\\','/')],cwd=r,text=True)
m=re.search(r'raw.user_context = ([^;]+);',old); assert m
print('aot native state',m[1]);t=t.replace('        lux_script_call_frame raw{};','        lux_script_native_instance_context native_context{'+m[1]+'};\n        lux_script_call_frame raw{};').replace('fn->invoke(&raw)','fn->invoke(&native_context, &raw)').replace('call_frame.user_context','the explicit native context');p.write_text(t)
p=r/'engine/toolchain/flowforge/test/script_artifact_compiler_test.cpp';t=p.read_text();pairs=re.findall(r'(\w+)\.native_instance = std::addressof\((\w+)\);',t)
for frame,ctx in pairs:
 t=t.replace(f'    {frame}.native_instance = std::addressof({ctx});\n','')
 # strip const on context only to pass void*; no code mutates its fields
 t=re.sub(r'(const (?:auto|lux_script_native_instance_context) '+re.escape(ctx)+r'\b)',lambda m:m[0].replace('const ',''),t)
 t=t.replace(f'->invoke(&{frame})',f'->invoke(std::addressof({ctx}), &{frame})').replace(f'->invoke(std::addressof({frame}))',f'->invoke(std::addressof({ctx}), std::addressof({frame}))')
 # starts multi-line first argument
 t=re.sub(r'(->start\(\s*)(std::addressof\('+re.escape(frame)+r'\)|&'+re.escape(frame)+r')',lambda m:m[1]+f'std::addressof({ctx}), '+m[2],t)
p.write_text(t)
# Native Event adapter owns only invocation-local wait access plus prepared span.
p=r/'engine/domain/simulation/scripting/native/src/NativeScriptBackend.cpp';t=p.read_text().replace('''        struct StepAdapter final
        {
            PreparedCall* call{};''','''        struct StepAdapter final
        {
            std::span<const Instance::PreparedEvent> events;''');a=t.index('            if (adapter.call == nullptr');b=t.index('            const auto result = adapter.context->event_waits.wait',a);t=t[:a]+'''            if (adapter.context == nullptr || waiting_on == nullptr || ordinal >= adapter.events.size())
                return -1;
            const auto& prepared = adapter.events[ordinal];
'''+t[b:];t=t.replace('StepAdapter adapter{continuation.call,','StepAdapter adapter{continuation.call->instance->events,').replace('StepAdapter adapter{std::addressof(prepared),','StepAdapter adapter{prepared.instance->events,');p.write_text(t)
