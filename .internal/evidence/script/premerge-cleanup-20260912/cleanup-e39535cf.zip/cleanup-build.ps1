param([string]$Label,[string]$Slot='d',[string]$Tests='script|lua',[switch]$Configure,[switch]$Install)
$ErrorActionPreference='Stop'
$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1'
$q="$r/local-source"
$b="E:/SyncForder/CodeRepos/build/RelWithDebInfo/o/w/$Slot"
$out="$r/cleanup-20260912"
New-Item -ItemType Directory -Force -Path $out | Out-Null
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
function Run([string]$Name,[string[]]$Command) {
 $log="$out/$Label-$Name.log"
 if (Test-Path -LiteralPath $log) { throw "Log exists: $log" }
 $watch=[Diagnostics.Stopwatch]::StartNew()
 & $Command[0] $Command[1..($Command.Length-1)] *> $log
 $code=$LASTEXITCODE
 @{source=(git -C $q rev-parse HEAD); status=(@(git -C $q status --porcelain) -join "`n"); command=$Command; exit=$code;seconds=$watch.Elapsed.TotalSeconds} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath "$out/$Label-$Name.json"
 Write-Output "$Label-$Name exit=$code seconds=$($watch.Elapsed.TotalSeconds)"
 if ($code) { Get-Content -LiteralPath $log | Select-Object -Last 22; throw "Failed $log" }
}
$prefix=if($Slot -eq 't') {'cleanup-tools'} else {'cleanup-sdk'}
if ($Configure) { Run 'configure' @('cmake','-S',$q,'-B',$b,"-DCMAKE_INSTALL_PREFIX=E:/SyncForder/CodeRepos/install/o/na1/$prefix") }
Run 'build' @('cmake','--build',$b,'--target','all','-j','4','--','-k','0')
Run 'noop' @('cmake','--build',$b,'--target','all','-j','4','--','-k','0')
if ($Tests) { Run 'tests' @('ctest','--test-dir',$b,'-C','RelWithDebInfo','--output-on-failure','-j','1','-R',$Tests) }
if ($Install) { Run 'install' @('cmake','--install',$b,'--config','RelWithDebInfo') }
