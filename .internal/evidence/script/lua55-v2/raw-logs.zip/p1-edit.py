from pathlib import Path
import re
root=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source')
def edit(n,fn):
 p=root/n; s=p.read_text(encoding='utf-8-sig'); t=fn(s)
 if t!=s:p.write_text(t,encoding='utf-8',newline='\n')
def backend(s):
 s=s.replace('int (*entry)(lua_State*) noexcept{};','LuxLuaTypedWorker entry{};')
 s=re.sub(r'            for \(const auto factory : wrapper_factories\)\n.*?\n','',s)
 a=s.index('        [[nodiscard]] bool wrapAbility(');b=s.index('        [[nodiscard]] bool appendArtifactEvents(',a)
 s=s[:a]+'''        // All four upvalues are rooted before the C closure is published.
        void pushPrimitive(LuxLuaTypedWorker worker)
        {
            auto* storage = static_cast<LuxLuaTypedWorker*>(lua_newuserdatauv(state, sizeof(worker), 0));
            *storage = worker;
            lua_pushcclosure(state, &luxLuaBoundaryEntry, 4);
        }

'''+s[b:]
 s=s.replace('                    lua_pushcclosure(state, ability_methods[ordinal].entry, 3);\n                    const bool is_async = method->kind == lux::script::EScriptApiMethodKind::ASYNC_OPERATION;\n                    if (!wrapAbility(is_async, !method->results.empty()))\n                        return false;', '                    pushPrimitive(ability_methods[ordinal].entry);')
 s=s.replace('            if (!pushWrapperFactory(3U))\n            {\n                return false;\n            }\n            const auto factory_index = lua_gettop(state);\n','')
 s=s.replace('                lua_pushvalue(state, factory_index);\n','')
 s=s.replace('                lua_pushcclosure(state, &State::invokeEventWait, 3);\n                if (lua_pcall(state, 1, 1, 0) != LUA_OK)\n                    return false;\n                ++wrapper_closures_created;', '                pushPrimitive(&State::invokeEventWait);')
 s=s.replace('            lua_remove(state, factory_index);\n','')
 s=s.replace('        static int abilityFailure(', '        static LuxLuaBoundaryOutcome abilityFailure(')
 s=s.replace('            return lux::script::lua::detail::LuaValueAccess::failure(state, message);','            const auto count = lux::script::lua::detail::LuaValueAccess::failure(state, message);\n            return {LUX_LUA_BOUNDARY_ERROR, count, status};')
 s=s.replace('        static int invokeEventWait(', '        static LuxLuaBoundaryOutcome invokeEventWait(')
 s=s.replace('            lua_pushboolean(state, true);\n            return 1;\n        }\n\n        static int invoke(', '            return {LUX_LUA_BOUNDARY_SUSPEND, 0, 0};\n        }\n\n        static int invoke(')
 for fn in ['fail','suspend','succeed']:
  s=s.replace('    int detail::LuaAbilityProjectionAccess::'+fn, '    LuxLuaBoundaryOutcome detail::LuaAbilityProjectionAccess::'+fn)
 s=s.replace('        lua_pushboolean(state, true);\n        return 1;\n    }\n\n    LuxLuaBoundaryOutcome detail::LuaAbilityProjectionAccess::succeed', '        return {LUX_LUA_BOUNDARY_SUSPEND, 0, 0};\n    }\n\n    LuxLuaBoundaryOutcome detail::LuaAbilityProjectionAccess::succeed')
 s=s.replace('        lua_pushboolean(state, true);\n        lua_insert(state, -results - 1);\n        return results + 1;', '        static_cast<void>(state);\n        return {LUX_LUA_BOUNDARY_RETURN, results, 0};')
 s=re.sub(r'        std::array<int, 4U> wrapper_factories.*?;\n','',s)
 s=re.sub(r'(?m)^.*wrapper_(?:factory_compilations|closures_created).*\n','',s)
 # The light C function needs no allocating registry bootstrap or per-call registry lookup.
 s=s.replace('        inline static char thread_creator_key;\n','')
 a=s.index('        static int installThreadCreator(');b=s.index('        [[nodiscard]] int createThreadProtected',a)
 s=s[:a]+s[b:]
 s=s.replace('            lua_pushlightuserdata(state, &thread_creator_key);\n            lua_rawget(state, LUA_REGISTRYINDEX);','            lua_pushcfunction(state, &createThread);')
 s=s.replace('            if (!initializeThreadCreator(state)) return;\n','')
 # Original incarnation + authority remain pinned by the shared Execution resume scope.
 a=s.index('            int argument_count{};\n            if (!pushResumeValue(')
 b=s.index('            continuation.waiting_on = {};',a)
 s=s[:a]+'''            const auto* behavior = continuation.instance->behavior;
            const bool bound_authority = behavior != nullptr && behavior->hasInvocationAuthority();
            const auto qualification = bound_authority ? behavior->captureInvocation() : ScriptInvocationValidity{};
            if (bound_authority && !qualification.valid()) return ScriptStepResult::failed(kInvalidCall);
            const auto* original_instance = continuation.instance;
            const auto* original_call = continuation.call;
            auto* original_thread = continuation.thread;
            const auto original_wait = continuation.waiting_on;
            const auto base = lua_gettop(original_thread);
            int argument_count{};
            if (!pushResumeValue(continuation, packet, argument_count))
            {
                lua_settop(original_thread, base);
                return ScriptStepResult::failed(kInvalidResume);
            }
            const bool same_execution = continuation.active && continuation.instance == original_instance &&
                continuation.call == original_call && continuation.thread == original_thread &&
                continuation.waiting_on == original_wait;
            const bool same_binding = same_execution && original_instance->active &&
                original_instance->behavior == behavior &&
                (behavior != nullptr && behavior->hasInvocationAuthority()) == bound_authority;
            if (!same_binding || (bound_authority && !qualification.valid()))
            {
                lua_settop(original_thread, base);
                return ScriptStepResult::failed(kInvalidCall);
            }
'''+s[b:]
 return s
edit('engine/domain/simulation/scripting/lua/src/LuaScriptBackend.cpp',backend)
edit('engine/domain/simulation/scripting/lua/include/lux/engine/simulation/scripting/lua/LuaScriptBackend.hpp',lambda s:re.sub(r'(?m)^.*wrapper_(?:factory_compilations|closures_created).*\n','',s))
def projection(s):
 for fn in ['fail','succeed','suspend']:
  s=s.replace('static int '+fn+'(', 'static LuxLuaBoundaryOutcome '+fn+'(')
 for fn in ['invokeLuaValueAbility','invokeLuaAbility','startLuaValueAbility','startLuaAbility']:
  s=s.replace('int '+fn+'(', 'LuxLuaBoundaryOutcome '+fn+'(')
 s=s.replace("the wrapper's success/error/yield protocol",'the C boundary performs error/yield')
 return s
edit('engine/domain/simulation/scripting/lua/include/lux/engine/simulation/scripting/lua/LuaScriptAbilityProjection.hpp',projection)
edit('modules/function/script/core/template/script_ability_lua.template',lambda s:s.replace('static int {{ method.spelling }}(lua_State* state)', 'static LuxLuaBoundaryOutcome {{ method.spelling }}(lua_State* state)'))
edit('modules/function/script/lua/src/LuaValue.cpp',lambda s:s.replace('                lua_pushboolean(state, false);\n                lua_pushlstring','                lua_pushlstring').replace('                return 2;\n            }\n            int readField','                return 1;\n            }\n            int readField').replace('            if (run(state, operation, 0, 0, 2))\n                return 2;\n            // No allocation is needed for the fallback. The Lua wrapper reports this after the\n            // generated C++ conversion frame has been destroyed.\n            if (!lua_checkstack(state, 2))\n                return 0;\n            lua_pushboolean(state, false);\n            lua_pushnil(state);\n            return 2;', '            if (run(state, operation, 0, 0, 1)) return 1;\n            // The C boundary formats the status after all C++ owners have returned.\n            return 0;'))
for name,fn in [('lua_backend_test.cpp','noOpAbility'),('lua_prepared_storage_test.cpp','project'),('lua_closure_provenance_test.cpp','call')]:
 edit('engine/domain/simulation/scripting/lua/test/'+name,lambda s,fn=fn: re.sub(r'(?m)^.*assert\(backend->stats\(\).wrapper_.*\n','',s.replace('    int '+fn+'(lua_State','    LuxLuaBoundaryOutcome '+fn+'(lua_State')).replace('return 0;\n    }\n\n    inline constexpr std::array kNameLuaMethods', 'return {LUX_LUA_BOUNDARY_RETURN, 0, 0};\n    }\n\n    inline constexpr std::array kNameLuaMethods').replace('return 0;\n    }\n\n    [[nodiscard]] lux::script::ScriptArtifact artifact', 'return {LUX_LUA_BOUNDARY_RETURN, 0, 0};\n    }\n\n    [[nodiscard]] lux::script::ScriptArtifact artifact'))
