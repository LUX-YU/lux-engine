$ErrorActionPreference='Stop'
$repo='E:/SyncForder/CodeRepos/lux-engine-deep-optimization'
$root='E:/SyncForder/CodeRepos/build/RelWithDebInfo/sr4'
$python='C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
$deps='E:/SyncForder/CodeRepos/install/q2/toolset;E:/SyncForder/CodeRepos/install/q2/c;E:/SyncForder/CodeRepos/install/RelWithDebInfo'
$candidate_sha=(& git -C E:/SyncForder/CodeRepos/lux-engine-sr4-candidate rev-parse HEAD).Trim()
$qualification=@(Get-Content "$root/candidate/qualification.json" -Raw | ConvertFrom-Json | Where-Object source_sha -eq $candidate_sha)
if ($qualification.Count -ne 2 -or @($qualification | Where-Object status -ne 'PASS').Count) {throw 'Candidate qualification has not passed'}
& "$repo/cmake/RunScriptSR3Validation.ps1" -BaselineSource E:/SyncForder/CodeRepos/lux-engine-sr3-event -CandidateSource E:/SyncForder/CodeRepos/lux-engine-sr4-candidate -BaselineInstall E:/SyncForder/CodeRepos/install/sr3-e -CandidateInstall E:/SyncForder/CodeRepos/install/sr4-candidate -CandidateBuild "$root/candidate" -OutputRoot "$root/validation" -Python $python -SkipMeasurements *> "$root/validation-driver.log"
if ($LASTEXITCODE -ne 0) {throw 'Installed validation failed'}
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$env:LUX_FLOWFORGE_LINKER=Join-Path $env:VCToolsInstallDir 'bin/Hostx64/x64/link.exe'
foreach ($variant in @('e0','e1','h0')) {
 $identity = switch ($variant) {
  'e0' {@('lux-engine-sr3-event','sr3-e','E:/SyncForder/CodeRepos/build/RelWithDebInfo/sr3-e')}
  'e1' {@('lux-engine-sr4-candidate','sr4-candidate',"$root/candidate")}
  'h0' {@('lux-engine-sr3-reference','sr3-reference','E:/SyncForder/CodeRepos/build/RelWithDebInfo/sr3-reference')}
 }
 & $python -B "$repo/cmake/BuildScriptEventBenchmark.py" --source E:/SyncForder/CodeRepos/lux-engine-sr3-event --runtime-source "E:/SyncForder/CodeRepos/$($identity[0])" --prefix "E:/SyncForder/CodeRepos/install/$($identity[1])/t" --build-root "$($identity[2])/t" --dependencies $deps --output "$root/observers/$variant" *> "$root/observer-$variant.log"
 if ($LASTEXITCODE -ne 0) {throw "Observer build failed: $variant"}
}
foreach ($baseline in @('e0','h0')) {
 $base = if ($baseline -eq 'e0') {'sr3-e'} else {'sr3-reference'}
 & $python -B "$repo/cmake/RunScriptSR2Measurements.py" --baseline "E:/SyncForder/CodeRepos/install/$base" --candidate E:/SyncForder/CodeRepos/install/sr4-candidate --candidate-build "$root/candidate" --output "$root/final-$baseline-e1" --short-path-frames 3000 --event-frames 3000 --affinity-mask 1 --baseline-flow-executable "$root/observers/$baseline/build/script_event_observer.exe" --candidate-flow-executable "$root/observers/e1/build/script_event_observer.exe" *> "$root/measure-$baseline-e1.log"
 if ($LASTEXITCODE -ne 0) {throw "Same-work measurement failed: $baseline"}
}
& $python -B "$repo/cmake/SummarizeScriptCost.py" --root $root --output "$root/cost-summary.json" --comparisons e0-e1 h0-e1 *> "$root/cost-summary.log"
if ($LASTEXITCODE -ne 0) {throw 'Cost summary validation failed'}