# LUX Editor Editing：统一编辑历史与业务扩展实施规范 v2

**版本：2.0；日期：2026-09-08；交付对象：LLM 实施方。**

> 全部新实现位于 `engine/editor`。`Editing` 只提供历史和回放协议；Scene、文本、FlowForge、Material 各自定义具体操作、恢复数据、模型和变化通知。不得让核心反向认识业务或 Pane。
>
> 本包是实施规范与待实现接口，不是已完成或编译通过的 SDK。用户发送并明确要求执行时，**默认只授权 ED-1**。后续阶段的说明是接入约束，不是自动实施所有编辑器的授权。本次文档制作没有修改仓库。

## 0. 阅读顺序、优先级与旧版本处理

完整阅读本文与附录接口，然后执行 `implementation/ED-1_TASK.zh-CN.md` 和 `verification/ACCEPTANCE.csv`。不得只读摘要、类名或局部代码。

“必须／不得”为验收要求；“现状”来自固定源码；“拟新增”是本次协议；“后续接入”不表示本轮已实现或获准开发。最新用户决定 > 当前任务授权和正文 > 接口声明 > 旧方案。真实冲突要给出精确符号与行为冲突，完成无依赖部分，不擅自采用另一套架构。普通私有实现细节无需逐项确认。

**旧《LUX Editor：通用 Undo/Redo 与编辑一致性设计 v1》以下内容被明确替换：**

| 旧设计 | v2 唯一正式决定 |
|---|---|
| `modules/function/undo`、`lux::undo` | 不创建；使用 `engine/editor/editing`、`lux::editor::editing` |
| UndoHistory / UndoCommand | EditHistory / EditOperation；方法仍叫 undo()/redo() |
| SceneEditSession、ScenePatchCommand 位于 Editing | 所有场景类型归业务；核心不得包含它们或它们的分支 |
| 通用 DocumentChangeBatch 内含场景对象 | 具体业务自有变化批次；核心只提供 HistoryNotice |
| 全局路由只识别 Scene | 应用面向 EditHistoryTarget，不能按场景／材质／脚本分类调用 |
| execute(unique_ptr) 失败也消费输入 | execute(EditOperationPtr&)：失败保留，成功才转移或处理 no-op |
| 任意 markSaved(StateId) | 匹配的 SaveTicket；保存确认必须对应已捕获内容 |
| 立即建设完整场景编辑系统 | ED-1 先实际实现核心和通用路由，在两个不同测试业务及安装消费者中验证 |

旧文件保留为历史资料，不同时作为执行任务。Script SR-1～SR-6 不重新开启；旧文件的测试数字、阶段禁令和性能工作不自动转化为本轮要求。

## 1. 目标、哲学与非目标

### 1.1 总目标

同一份内容文档的 Inspector、Hierarchy、Viewport、节点画布和菜单共享一条历史。不同文档可以有不同历史，但使用同一份实现。用户看到的是统一的撤销／重做动作；系统内部依赖业务模型变化协议更新面板，不由历史逐个调用面板。

Editing 不知道 Entity、节点、文本范围、组件、材质参数或编译器。业务提供可恢复操作，核心保证接纳、游标、分支、保存状态、容量与回放顺序。新增业务操作不修改核心源文件。

### 1.2 固定设计哲学

1. **复用机制，不统一业务表示。** 文本区间替换、图结构差量、场景作者快照都可接入；不强制统一为 ScenePatch、Entity 或任意字节 Variant。
2. **内容、历史、选择、视图分别有权威。** 文档拥有内容；历史拥有顺序；业务选择拥有有效目标；Pane 只有呈现与局部输入状态。
3. **先完成可失败准备，再提交。** prepare 可失败且不改 live 状态；apply 提交准备好的内容；publish 在模型与历史同时一致以后运行。
4. **Undo/Redo 不是绕开业务规则的捷径。** 回放走正式领域协议，照常通知模型变化，但不再记录成用户编辑。
5. **确定的数据恢复，不重取输入。** Redo 不读当前鼠标、随机数、系统时间、当前选中对象或磁盘最新内容来猜原操作。
6. **显式生命周期。** 操作恢复内容不等于保活运行中的 Scene、GPU 或 Lua coroutine；旧 runtime 代次不得被恢复。
7. **单 owner，不新增全局调度。** 一份历史由创建线程使用；同历史递归变更返回 BUSY。后台结果通过现有 owner 接入点验证后处理。
8. **有限复杂度。** 不为了理论通用性引入操作发现、插件注册、事务数据库、事件总线或另一套 UI 路由。

### 1.3 成熟软件参考及取舍

| 来源 | 采用的公开机制 | LUX 自己的决定／不照搬 |
|---|---|---|
| Qt QUndoCommand / QUndoStack [Q1,Q2] | 业务派生操作、游标、重做分支、保存点；组合和合并不同 | 不引入 Qt；不把 void undo/redo 当作任意失败都能原子回滚的证明 |
| Qt QUndoGroup [Q3] | 多文档各有历史，应用明确设置活动历史 | 不根据最近 Entity 或某个对象猜历史；不重复实现快捷键系统 |
| Godot UndoRedo [G1] | 历史承担恢复资源的有效期；初次执行政策明确 | 不将 live VM/GPU 保活作为通用恢复；首版不开放任意 already-applied |
| Unity RecordObject [U1] | 属性记录与创建／销毁／父子关系等结构操作区分 | 反射 diff 不会自动解决对象关系和删除恢复 |

下文的准备／纯提交／发布、失败所有权、保存票据和接入规则，是 LUX 的设计选择，不声称这些成熟软件内部采用完全相同协议。

### 1.4 首版不做

跨文档原子撤销、选择性 Undo、历史分支树、协同编辑／CRDT、跨进程历史持久化、网络和磁盘副作用回滚、任意插件热重载、编辑脚本沙箱、通用自动合并器、运行中游戏倒放。业务需要这些能力时另行批准，不以“为以后准备”进入当前实现。

## 2. 当前源码依据与核查范围

只读核查仓库 `LUX-YU/lux-engine`，分支 `codex/s6-deep-optimization`，本次 HEAD 为 **`0ceedbcdbc75f3b2be4b6be8d0b0cbfc6e0b8db7`**。它已晚于旧设计的 5a309191 和脚本验收 d2d24f05。实施方接手重新核对，不回退或重标既有工作。[L0]

本次没有构建 Engine 或这些声明，也没有验证当前依赖二进制。实际依赖以当前工作区／配置／安装来源为准，不凭旧 SHA 自动升级、重建或猜绝对路径。

| 实际位置 | 当前事实 | 对本任务的约束 |
|---|---|---|
| AGENTS.md [L1] | modules 为外部复用，engine 为引擎专属；Editor=L5；enum E 前缀；可见性分层 | 保持目录、target、产品与 include 一致 |
| engine/editor/CMakeLists.txt [L2] | context、inspector、node_graph、material、flowforge、application 已存在 | editing 在 context 前接入，不建立第二个 Editor 根 |
| GraphEditingSession.hpp [L3] | 自有 undo_/redo_/pending_、Transaction、revision、selection | 不能忽略现有图历史；以后迁移不能新旧双记 |
| GraphDocument.hpp [L4] | 有可失败 add/detach/attach/action 和可写 topology/layout，没有通用 prepared commit | 不编造现成 clone/atomic replace API |
| InspectorContext.hpp [L5] | 含 EditorContext、Frame、InspectorUndoJournal、EditorSelectionValue | 旧绘制修改链不能只改日志名称；本轮不提前迁移 |
| CommandRouter.hpp [L6] | define、bind/bindGlobal、state、invoke；route 由 UISession 管 | 复用，没有 setCommandLabel，不新造 UI 命令系统 |
| editor_context CMake [L7] | 现有应用级 Object/UI/meta 和 Scene 依赖 | 路由可放此处；领域盲核心不能依赖它 |
| editor_application CMake [L8] | 已有窗口／渲染组合 | 不为了历史模块另建宿主或要求无关 GPU 重构 |

AGENTS 已要求 GraphKit 组合修改／Undo／Redo 失败恢复 document/history/revision。本版不能删除这一保证。现有 inverse journal 是业务迁移依据，不自动满足纯提交接口；将来必须据实际代码证明适配。[L1,L3,L4]

## 3. 唯一目录、target、namespace 与依赖

### 3.1 Editing 核心

```text
engine/editor/editing/
    CMakeLists.txt
    include/lux/engine/editor/editing/
        EditTypes.hpp
        EditOperation.hpp
        EditHistory.hpp
        EditHistoryTarget.hpp
    pinclude/lux/engine/editor/editing/detail/
        ... 私有历史存储与测试接点，不安装
    src/
        EditTypes.cpp
        EditHistory.cpp
    test/
        ... 核心协议、两个业务 fixture、生命周期测试
```

target 为 `editor_editing`，别名 `lux::engine::editor::editor_editing`，分类 `EDITOR / EDITOR / FOUNDATION`，安装项目名 `lux-engine-editor-editing`。使用仓库现有 add_component/install_components；不为每个类建 DLL。

按当前组件方式建立**一份共享核心实现**。身份发行在唯一 out-of-line 实现中；禁止多个业务 DLL 各自静态嵌入一份从 1 开始的计数器。ED-1 不另支持静态多副本／插件独立 core 变体，也不为它建立全局服务定位器。

核心 namespace：`lux::editor::editing`。依赖仅标准 C++ 和现有 `lux::cxx::compile_time`。禁止直接或传递链接 UI、LuxObject、EditorContext、Scene、World、Simulation/ECS、Process、Material、FlowForge、GraphKit、Vulkan 或 ImGui。核心不继承 LuxObject。

### 3.2 应用路由接入

```text
engine/editor/context/include/lux/engine/editor/
    ActiveEditHistory.hpp
    EditHistoryController.hpp
engine/editor/context/src/
    ActiveEditHistory.cpp
    EditHistoryController.cpp
```

继续使用现有 `editor_context` target，namespace `lux::editor`。它依赖核心和现有 Object/UI，不新建一族 Manager。Controller 信号沿现有 meta 生成。core 不得反向 include context。

### 3.3 具体业务（后续接入）

Scene、文本、材质、FlowForge、node_graph 的会话、具体操作、恢复数据、模型变化、选择策略都在各自业务目录。`ScenePatchOperation` 是可选业务实现名，不是核心类型。禁止在 core 出现业务 forward declaration、enum/variant、工厂分支或 dynamic_cast。

已有 modules 的 graph/material/flowforge source model 仍可被业务使用；本规范不要求迁走通用数据模型，只禁止新的编辑历史语义进入 modules。

## 4. 不可改写的决策 D01—D20

| 编号 | 固定要求 |
|---|---|
| D01 | 一份内容一条历史，所有编辑入口共享；Pane 不是历史 owner。 |
| D02 | 业务自定义 EditOperation；core 无业务类型目录。 |
| D03 | prepare → apply → 历史提交 → 业务 publish → HistoryNotice → 回收。 |
| D04 | 常规失败不改变模型、选择、memento、历史、redo、保存状态。 |
| D05 | execute 以 unique_ptr 左值引用接入；失败保留输入，成功才消费。 |
| D06 | no-op 不丢 redo、不加条目、不改内容 revision。 |
| D07 | baseState 只用于初次接纳；Undo/Redo 使用条目 before/after，不拿原始 revision 拒绝合法回放。 |
| D08 | StateId 不复用；Undo 回旧 state 但 Revision 单调增加。 |
| D09 | 保存是票据匹配的元数据协议，核心不做文件 I/O。 |
| D10 | owner-thread 和同历史忙碌门必须在优化构建有效。 |
| D11 | 选择修正先于普通通知，不依赖 subscriber 顺序。 |
| D12 | 清理不 Undo；恢复资源有效期明确，不持 Pane 或复活 runtime 资格。 |
| D13 | 组合编辑由业务 staged view 生成一条 operation；首版无通用宏／自动合并。 |
| D14 | 预览由业务管理；不提供任意 recordAlreadyApplied。 |
| D15 | ActiveEditHistory 仅非拥有注册和路由，不拥有文档／模型。 |
| D16 | target 负责当前编辑资格；disabled 查询不替代执行重验。 |
| D17 | 配额显式、溢出早拒绝，不无限 fallback／静默不可撤销。 |
| D18 | 本轮不把旧 Inspector/Graph 栈包在新历史下；实际业务迁移另行闭环。 |
| D19 | 仅 RelWithDebInfo；源码事实、设计、实测、未测范围分开。 |
| D20 | 真正前提冲突保留证据；不造新 source model／VM／UI 框架填补范围外缺口。 |

## 5. 完整类型与所有权

接口完整声明在附录 A；独立 contracts 与附录内容相同。它们没有链接定义，不是已编译实现。生产接入补准确 include、visibility 和现有 meta，不改变签名的所有权语义。

| 类型 | 唯一责任 |
|---|---|
| HistoryId | 历史实例身份，不是文档类型、世界对象或持久化 ID |
| StateId | HistoryId + 不复用序号，标识内容位置 |
| Revision | 成功内容变更的单调版本 |
| EditFailure | 有界 owned 错误，无模型指针和借用文本 |
| HistoryLimits | 条目、保留计费、准备计费、标题长度上限 |
| HistorySnapshot | 可复制标量快照，不授予跨线程访问权限 |
| HistoryView / EntryView | owner 的短借用查询，标题不可排队 |
| EditPreparationBudget | 一次 prepare 的保守预留账，不是 allocator 或插件沙箱 |
| EditOperation | 业务创建的恢复描述；成功接纳后历史独占 |
| PreparedEdit | 一次应用的暂存、已准备提交和延后释放资源 |
| EditHistory | 历史条目、cursor、保存标记和阶段 |
| SaveTicket | 已发起保存的 History/内容/request 匹配信息 |
| HistoryObserver | 唯一非拥有通知出口，不是订阅系统 |
| EditHistoryTarget | 业务会话面向应用的窄历史能力 |
| ActiveEditHistory | 有界目标注册与当前目标，不管理内容 |
| HistoryTargetRegistration | 注销责任；busy 不丢 token |
| EditHistoryController | 现有 CommandRouter 的 LuxObject 接收者 |

History、Operation、PreparedEdit、ActiveEditHistory 的对象本体不 copy/move。移动 unique_ptr 不移动对象。Registration 可移动，但 live 移动也遵守 owner 和准确注销规则。

## 6. 身份、版本和阶段

### 6.1 HistoryId

由唯一核心 create out-of-line 实现发行非零 uint64，原子检查溢出，不 fetch_add 绕回。计数器不保存文档或服务，不是全局 Manager。不能把对象地址当 ID。默认同一进程装入一份匹配核心；跨两个调用组件创建历史必须得到不同 ID。

HistoryId 只防止可信业务误投递，不是对任意第三方代码的安全沙箱。默认值 0 无效。

### 6.2 内容状态与修订

初始 StateId.serial=1、Revision=0、event_sequence=0。新 CHANGE 使用新序号；Undo/Redo 使用条目原 state，但 Revision 增加。失败/no-op 不改变可见状态序号、Revision 或 event_sequence。

```text
S1/r0 → execute A → S2/r1 → execute B → S3/r2
→ undo B → S2/r3 → execute C → S4/r4
```

新分支不能把 S3 发行给另一份内容。准备中已占用却失败的私有序号可以留空洞，但不能复用成旧身份。业务异步计算要验证自己的文档 lifetime 和 Revision，不能因为 Undo 回旧 StateId 就接纳旧任务结果。

### 6.3 检查优先级

除不可变 id 和纯值 getter，live 查询/操作都是 owner-thread。先检查 WRONG_THREAD，再 CLOSED，再 BUSY，再参数／历史／base，然后配额／计数和准备。异线程拒绝前不能读取可变数组、执行业务 virtual 或析构输入。view 在同线程 CLOSED 仍允许读最终标量；entry 返回 CLOSED。

同一历史阶段：

```text
IDLE → PREPARING → COMMITTING → PUBLISHING → RECLAIMING → IDLE
IDLE → RECLAIMING/关闭提交 → CLOSED
```

metadata、prepare、effect、publish、plan 和被删除 operation 析构都在门内。所有同历史变更（包括 save/clear/close）在门内返回 BUSY。不能递归锁、等待自己、pump 或自动无限排队。

另一份独立历史可以在自己的 owner 上运行，不加全应用互斥。业务必须封住同文档其他写入口；核心无法拦住外部绕过会话直接写 Registry。

## 7. 操作协议与失败所有权

### 7.1 Metadata

historyId/baseState/label/retainedBytesUpperBound 必须稳定、无副作用、不分配、不通知。标签非空、无内嵌 NUL、不超过上限；不得按标签推断类型或自动合并。

retained 上界覆盖操作整个历史寿命的 memento、字符串、引用和可能更新的有限选择回放记忆；回放后不能隐式超出最初 accepted charge。共享恢复数据可保守重复计费，但不能称为精确 RSS。

baseState 仅检查第一次 execute；Undo/Redo 根据 context.from/to 和方向校验记录内容，不能继续检查最初生成操作时的 Revision。

### 7.2 prepare

可以分配、校验和构造私有暂存与通知。禁止改变模型、选择、操作 memento 或历史；禁止启动声称新版本已提交的后台工作。

分配前调用 budget.reserve 保守上界，可一次预留完整 typed 规划。reserve(0) 成功，溢出或不足返回 STAGING_LIMIT 且 used 不变。预算单调不退款，因此是保守累积准备计费，不是精确峰值。它不持有内存，不需要新 PMR 框架。

业务和核心各自在可失败准备边界把实际 bad_alloc 转成 ALLOCATION_FAILURE。noexcept 违约不是核心能捕获并正常继续的保证。不能把所有异常吞掉写成成功。

输入 operation 调用前已有的数据由业务构造阶段限制，接纳后算 retained；不能将核心限额宣称为整个进程内存硬上限。

### 7.3 成功、失败与 no-op

`execute(EditOperationPtr& op)` 在失败时保留同一个非空指针，数据不变；CHANGE 成功后指针为空、历史接管；NO_CHANGE 成功后在门内析构输入并置空，但不改内容或历史。

同步调用期间调用方不得改同一个 unique_ptr；业务 callback 不能借变量地址夺走所有权。禁止提供按值的便利 overload 重新引入失败销毁语义。

prepare 成功必须非空 plan。NO_CHANGE 只允许 execute，且仍需先通过 history/base/目标/输入验证。Undo/Redo 返回 NO_CHANGE 是 CONTRACT_VIOLATION，不移动游标、不跳过条目或自动裁剪。core 不凭模型偶然相等吞掉错误历史。

### 7.4 apply

apply 只提交已经准备好的状态。允许相同 allocator 的 noexcept swap、immutable image 交换和预验证标量写入。禁止首次分配、I/O、Lua、用户 setter、signal、pump，以及会运行 observer 的 Registry 结构操作。

旧数据保留到 plan 内，通知后再释放，避免提交第一步就触发外部析构回调看到半状态。不能仅加 noexcept 然后把合法资源不足 terminate。

强保证覆盖编辑模型、相关选择和历史，不覆盖 GPU/Simulation/文件系统同时原子提交。派生同步失败单独报告，不回滚一半内容或修改历史游标。

### 7.5 publish 和析构

历史 cursor/state/revision 已提交后才 business publish；之后才 HistoryObserver。普通观察者第一次回调时看见一致模型与选择。通知来源 EXECUTE/UNDO/REDO 明确，不关闭所有 signal，也不让它重新入历史。

publish 的回调必须 noexcept；有界 owned payload 在 prepare 获得。投影／编译／绘制失败是后续业务结果，不能把已完成历史提交报告成未执行。

未提交 plan 析构只丢暂存；已提交 plan 析构释放被替换旧数据。operation 析构不 Undo、不查 Pane。代码/schema有效期必须覆盖最后虚析构。ED-1 不支持中途卸载提供操作虚函数的模块。

## 8. 历史具体算法与资源存储

### 8.1 内部布局

一个私有 entries 向量和 cursor：`[0,cursor)` 已应用，`[cursor,end)` 可重做。Entry 含独占 operation、before/after、固定标题缓存与计费。不要暴露可写记录。

factory 预留 max_entries 正式槽，另预留 max_entries+1 回收槽。溢出／分配失败使 create 失败；不在提交后扩容。metadata按容量记，业务payload另计。标题计费采用已准备缓存的实际 capacity+1 保守记账；不能只加sizeof指针。

### 8.2 execute 的完整顺序

1. 线程／状态／输入检查，进入 PREPARING；指针仍归调用方。
2. 核验 history/base 和稳定 metadata，配额与整数递增预检。
3. 仅准备新 Entry 标题和规划 redo／旧前缀裁剪，不删除任何历史。
4. 调用 prepare，校验 plan。失败在 RECLAIMING 释放本次暂存，回 IDLE；原指针、模型、memento、cursor、redo、saved和版本不变。
5. NO_CHANGE 按前节结束；CHANGE 进入 COMMITTING，此后没有正常可失败工作。
6. plan.apply；无抛接管操作；把待丢 redo/前缀移到预留回收槽；完成剩余 Entry 压紧、新条目、cursor、base/current、revision/event和charge。
7. 在最终 Entry 地址稳定后创建 CommitInfo.label；PUBLISHING 业务通知，然后 HistoryNotice。
8. RECLAIMING 先释放 plan 的旧资源，再按旧历史索引从高到低析构丢弃条目；清回收槽、回 IDLE。

Entry压紧前所有待丢operation先移出，避免move-assignment提前析构。不要在SSO标题搬迁前保存string_view再用于publish。普通错误不改变任何已提交状态，诊断计数不冒充业务版本。

### 8.3 Undo/Redo

Undo 取 entries[cursor-1]，BACKWARD，to=before；Redo取 entries[cursor]，FORWARD，to=after。核验当前状态符合条目方向，然后同一prepare/apply/metadata/publish/cleanup协议。

Undo不析构该operation、不删条目；Redo不发行新内容serial。NO_UNDO/NO_REDO不通知。回放准备失败可重试，不能部分改变业务memento。首版没有setIndex／任意跳转。

### 8.4 redo分支与容量裁剪

新CHANGE成功时才删除redo尾部。最终候选费用按“仍应用的旧前缀+新条目”计算，不能被将丢弃的redo费用错误拒绝。超限时仅裁最少的最旧已应用前缀，不删中间条目、不按业务类型选择。

max_entries=2，执行A/B/C后保留B/C。撤销C、B回到A后状态，不能冒称还可回初始状态。saved标记即使不可达仍保留身份，不用cursor猜clean。

单条操作超过预算直接拒绝，不能先修改再降级不可撤销。capacity不由0暗示无限，所有上限显式正数。

### 8.5 clear、close与计数耗尽

clear只清条目，cursor=0、base=current；内容/current/revision/saved/pending SaveTicket不变，序号不重置。历史已空无新通知；真正清了条目才增加event并发CLEARED。

close busy返回BUSY，不释放正在使用资源。IDLE关闭撤销pending save，清历史，提交closed状态，发一次CLOSED，再释放旧资源。view保留最终标量，canUndo/canRedo=false，标题空。重复close幂等。

普通内容／metadata操作在序号将溢出前返回ID_EXHAUSTED。**close不因event_sequence耗尽拒绝释放**：饱和时保留最大值并发closed终态，不绕回。closed是终态，不会再产生普通通知。

正常先显式close再析构；未close但IDLE的析构只关闭资源、不调用可能已失效的observer。异线程／busy析构是生命周期违约，使用现有fail-fast；可恢复关闭必须通过Result先判断，不递归等待或pump。

## 9. 保存票据与通知序号

beginSave只捕获current，发行SaveTicket，不写文件，不启动任务。一次最多一个pending，第二次SAVE_IN_PROGRESS。Host先处理预览并固定committed快照，确保内容与票据匹配；快照或实际保存启动失败需以FAILED/CANCELLED完成票据。

finishSave严格匹配history/request/state。SUCCEEDED设置saved=ticket.state，不是当时current；FAILED/CANCELLED保留旧saved。完成清pending，增加event，发SAVE_FINISHED。busy保留结果和ticket到owner下一点重试。

重复/foreign/invalid完成为STALE_SAVE；closed为CLOSED。新打开/重载建立新HistoryId，不复用旧票据。不暴露任意markSaved(StateId)。clear不使仍有效的保存结果失效。

```text
S2开始保存 → 用户编辑到S3 → S2保存成功
saved=S2,current=S3,dirty=true
Undo回S2（Revision继续增加）→ clean=true
```

Revision只计内容execute/undo/redo；event_sequence另计实际clear、save开始/结束、close。失败/no-op都不计。metadata事件不触发业务重新编译。实际文件写入同一文档首版最多一个在途，由业务既有流程串行，不能旧请求晚完成覆盖新文件。

## 10. 查询、通知和一致性

核心只有构造期注入的一个非拥有HistoryObserver。业务将其转成现有LuxObject signal或dirty提示；不新增connection表／dispatcher。observer必须活过显式close，析构不通知。

HistoryNotice只含owned标量，可复制但不授予跨线程直接访问history。HistoryView/EntryView/CommitInfo含的标签借用遇后续mutation或析构失效，禁止queued payload保存这些view。UI在owner返回后查询或复制。

通知时模型和历史已一致，但phase=PUBLISHING，view.can_undo/can_redo=false表示此刻不准递归调用。**观察者标dirty并在下一UI读取时重查，不把回调内false永久缓存**。Snapshot刻意不携带瞬时准入布尔值。

选择修正属于业务apply，不由subscriber先后顺序决定。晚注册或漏过通知的视图从业务快照刷新；消息不是第二份模型真相。

同历史通知中Delete/Undo/Save/Close明确BUSY，不能吞请求或自动创建无限重试队列；显式后续操作由现有应用安全点处理。核心可以阻止自己的回放，业务必须同样封住直接模型写入口。

## 11. 业务如何定义自己的操作

### 11.1 固定扩展面

业务实现EditOperation和PreparedEdit，由自己的会话实现EditHistoryTarget。core只调用接口，不dynamic_cast具体业务，不读取kind字符串，不维护可用操作列表。

| 业务 | 建议恢复表示 | core不应要求 |
|---|---|---|
| 脚本文本 | 范围、原文本、新文本、业务光标策略 | Entity、AST、运行中脚本对象 |
| Scene | 稳定逻辑对象、作者组件、关系和引用前后数据 | 整份Registry memcpy、旧runtime generation |
| FlowForge | 节点、端口、连线和源布局变化 | ScenePatchOperation、GPU状态 |
| Material | 参数前后值、图结构、资源引用 | 编译器缓存、pipeline或ShaderModule恢复 |

core不增加EditValue、ComponentImage、ObjectRef或通用DocumentHandle。业务文档身份由相应业务／应用边界负责，不能强制文本也使用WorldObjectId。现有可复用source model继续使用，不重新建engine/authoring。

### 11.2 ED-1 的两种独立测试业务

**TextBufferFixture**：私有committed std::string，替换指定字节范围。保存before/after和范围，prepare检查方向对应内容、范围及加法溢出，构造新字符串；apply swap；publish记录文本变化。fixture只验证字节操作，不宣称Unicode光标、语法、增量编译或完整脚本编辑器。

**RecordDocumentFixture**：私有简单记录表与可选selected id，支持创建、删除、修改。删除prepare计算下一个记录和合法选择，apply同时交换，两个观察者读取一致结果。此fixture没有ECS/World/Scene，不称真实Entity编辑已经完成。

两个模型只在test和consumer自有源码实现，不安装为生产模型。小fixture可完整复制再swap来验证强保证；不能将这个成本策略自动推广到大型Scene。核心编译单位和接口不因第二种业务出现而修改。

### 11.3 拟定业务操作的写法

```cpp
namespace consumer::text
{
    class TextModel; // Session owns it; history/operations are cleared before it is destroyed.

    class ReplaceTextOperation final : public lux::editor::editing::EditOperation
    {
        // 自有：HistoryId、初次baseState、固定标题、range、old/new text、受控TextModel借用。
        // prepare按方向验证并返回可swap的plan。
        // 不持Pane，不经EditorContext寻找服务，不调用另一份Undo栈。
    };
}
```

该片段只是业务归属示意，不是让实施方复制空类。真实fixture必须给出完整成员和行为，并通过对应用例。具体业务可以一个Patch类或多个专用类，不需要向core登记种类。

### 11.4 组合、合并与预览

首版不实现通用CompositeOperation、beginMacro、mergeWith、按标题或时间自动合并。业务在一个自己的staged view中顺序解释多个意图，最终形成一条operation。先创建节点再改属性必须在暂存视图中可见，不能让所有子操作分别对旧模型prepare。

手势期间只变业务preview，不变committed内容或历史；结束时execute一次，取消／净零不截redo。不得新增recordAlreadyApplied来掩盖“控件先写一次、历史又执行一次”。

接入的新业务首版每文档一个写手势；无文本局部消费时，Undo先取消手势并返回TRANSIENT_CANCELLED，下次才回放内容。活动手势的Redo返回BLOCKED_BY_HOST，不偷偷提交或取消。关闭发起Pane、切目标或文档时按业务明确规则先取消手势，旧token不能作用于新文档。

## 12. Editor 通用路由的具体机制

### 12.1 EditHistoryTarget

业务会话只暴露historyView、undo、redo，不暴露可写History或模型。业务可因Play、事务或关闭阻止动作；view分别返回READY/EMPTY/BUSY/BLOCKED/CLOSED，失败通过核心类别和domain_code/message表达。

成功只有两种：CONTENT_APPLIED要求content.effect=CHANGE；TRANSIENT_CANCELLED要求content.effect=NO_CHANGE且内容历史未变。没有可撤销内容且没有预览时必须返回NO_UNDO，不能把它包装为成功。target的historyId在注册期间固定；不能关闭后复用同一注册关联新的历史。

### 12.2 ActiveEditHistory 注册与激活

factory显式正target_capacity并预留。仅非拥有登记target指针和稳定HistoryId；handle={router身份,不复用registration序号}。重复指针或相同HistoryId返回DUPLICATE_TARGET，容量超限TARGET_CAPACITY。

注册时通过纯接口检查target身份有效、未关闭且在相同owner可访问。查询有BUSY时不擅自启动业务。register不自动activate；activate必须匹配完整handle，旧/foreign返回STALE_TARGET且原active不变。注销当前target后active为空，不自动选择另一份文档。

每次进入target的virtual保持窄路由调用门。在historyView或undo/redo返回之前，不允许register/activate/deactivate/unregister/close递归改route，返回BUSY。不能向外暴露长期resolve裸指针。

activeTarget()是owner上的值查询，不调用target virtual；busy路由中仍可读取稳定handle，空active返回无效handle，关闭后也返回空handle，错误线程返回WRONG_THREAD。无active时view成功且has_target=false；undo/redo为NO_ACTIVE_TARGET。当前target被阻塞时不回退另一份文档，不为了“总能撤销点东西”执行错误内容。

### 12.3 Registration 与销毁

Host同时拥有target和token。正常关闭先停止新输入，显式reset registration成功，再关闭业务history并释放模型。BUSY reset保留token，调用者必须等回调返回，不得立即delete target。

live token的move-assignment先reset旧绑定，再取得新token；不能默认覆盖。无返回值析构/move无法完成注销时属于生命周期违约，采用既有fail-fast；可恢复流程必须先用reset Result。自移动不破坏自己，moved-from为空。

router.close使所有control/token逻辑失效，但不调用业务Undo或关闭所有文档。之后晚到token析构只清本地值；weak control不保活整个Editor、模型或目标。router先销毁也不能让token访问悬空地址。

ActiveHistoryView含的标题受target下一次history修改、target注销／析构、route修改共同限制。不能queue保存该view。

### 12.4 Controller 与 CommandRouter

Controller是现有LuxObject派生接收者，仅借ActiveEditHistory。undo/redo先用activeTarget()固定入口handle，再执行目标动作；失败发owned `EditHistoryActionFailure`，不吞错误，不从日志推断成功。

用现有CommandRouter.defineCommand/bindGlobal注册一对命令，enabled分别canUndo/canRedo。测试必须实际走CommandRouter.invoke，不仅直接调用Controller。实际调用仍由target重验，不能只相信上帧enabled。CommandRouter若在分派前重新计算enabled并拒绝，不会进入Controller，也不应强求Controller.failed；只有实际进入Controller的失败才由其发送。

菜单标题默认Undo/Redo；操作标题由controller getter与呈现组合，不调用不存在的setCommandLabel，不为这个需求修改modules/UI。

焦点与活动文档是显式关系：文档tab或绑定文档的Pane激活target；菜单、工具栏、诊断窗口不自动清空active。操作归属由内容决定——修改Entity的材质引用属于Scene历史，修改材质自身参数属于Material历史，即使两者都显示在Inspector。

### 12.5 文本与快捷键优先级

真实UI接入时：活动文本输入局部撤销优先；局部栈为空但输入框持有快捷键也应消费；然后是属性手势取消；最后才文档Undo。这是UI上下文接入规则，不是另建完整文本历史来同步文档历史。

ED-1只验证通用动作与target策略，不宣称真实键盘、IME、焦点窗口已经验证。此轮不为了补完整UI去修改modules。以后接入时若基础库确有缺口，列为明确的通用基础库改动另行批准。

### 12.6 本轮不偷偷全局启用

ED-1实现并测试可装配的ActiveEditHistory/Controller；不在真实EditorApplication里为仍用旧栈的Graph/Inspector自动绑定全局Undo。不与旧快捷键争夺、不跨两套history重复提交。生产业务一轮完整迁移后，再显式接入统一应用动作。

## 13. 后续业务迁移与跨面板一致性

本节是后续约束，不是ED-1自动增加真实业务的授权。

### 13.1 Scene 与选择

业务维护逻辑对象、关系、选择和手势。Undo创建导致对象消失时，业务apply同时修正selection，再publish场景变化。Hierarchy更新行，Inspector目标失效，Viewport更新高亮；operation不保存这些Pane指针。

普通选择不进入内容history、不改变dirty。结构操作可保存有限选择before/after、expected_current与user_selection_revision；用户未介入时条件恢复，主动选中无关B后Undo A保留B，只过滤真实失效对象。不用signal顺序碰巧维持一致。

恢复逻辑对象不复活旧Entity、ScriptInstance、completion或拾取版本。WorldObjectId可在合适编辑文档使用，但不进入核心或回流ScriptSystem。GUI画面滞后时旧hit需验证文档、投影代次和内容/preview版本。

### 13.2 Inspector 的整体写路径

后续迁移同时处理EntityInspector局部日志、InspectorContext、ComponentEditorBinding绘制写入口及所有第一方调用者。只把undo_成员放到EditorContext不会关闭可写Registry旁路。

新的绘制只读值并提交编辑意图，session负责验证、手势与历史。不要假设WorldDescription已经有objects/removeObject等不存在接口。优先接现有semantic source model，必要窄适配属于Scene业务，不下沉Editing、不重建整个authoring层。

### 13.3 GraphEditingSession 的原子历史

现有GraphEditingSession持undo/redo/pending与inverse rollback，GraphDocument操作可能失败。[L3,L4] 迁移一个graph文档时必须一次转移所有权威写入口并移除旧历史；不得新core外包旧history.apply/undo然后两边各存一条。

也不得把可失败attachNode/restoreNodeAction简单塞进void apply。先建立可证明的staging/预留或相应业务原子提交接口，保留原故障恢复测试。实际接口不足时给出精确最窄修改和影响，不删除AGENTS强保证，不要求共享core识别Graph种类。

### 13.4 Material、FlowForge、Script

各业务恢复源内容，编译/预览是之后的工作。编译失败不使history半回滚，标明当前源版本与产物不同步。任务带业务lifetime与revision，旧完成不能写入新文档。

完整文本编辑器只能有一份内容history权威，不能同时保留控件完整文档栈和EditHistory栈再靠回调同步。局部未提交buffer与正式内容区分。跨文档原子操作首版不支持，不能向两个栈push就声称原子。

## 14. CMake、安装与编译规范

在editor根于context前加入editing。核心只导出四个公开头和必要库，private/test不安装。`editor_context`增加core公开依赖、transitive find和两个integration实现，Controller信号沿现有meta作业生成。

使用现有generate_visibility_header：`lux/engine/editor/editing/visibility.h`；宏`LUX_EDITOR_EDITING_LIBRARY/PUBLIC/DLL_DISABLE`。附录省略visibility只是避免伪装成已构建产物，生产所有跨库类/函数和虚析构必须准确导出。匹配编译器/CRT销毁业务对象，不宣称任意旧DLL ABI兼容。

core的HistoryId在唯一共享实现颁发；禁止多个静态副本各自计数。一个组件即可，不建每类DLL。其他静态部署不在本轮资格。

仅RelWithDebInfo，实际启用EDITOR层目标；不能只跑排除了Editor的Toolchain profile就称完成。读取真实cache/options，沿现有all构建约定；不得发明LUX_BUILD_EDITOR、近似配置名或借目录名代替编译命令证据。

CMake变化后第二次无修改构建必须no-op。构建、测试和计时串行；构建失败不运行旧EXE作为候选。测试局部/UNDEBUG或-UNDEBUG，保证assert内业务真的执行；不要全局换Debug CRT。

核心installed consumer仅依赖安装editor_editing及自有两业务，真实configure/build/run、跨DLL虚析构，闭包无Scene/UI/ImGui/Vulkan。应用route测试使用真实context/UI是另一资格，不能混淆其依赖。

在本轮隔离新prefix安装，再迁到新位置隔离旧路径重新生成/编译/运行；不移动用户未知安装、不手改cache或包文件。环境受阻保留具体BLOCKED_ENVIRONMENT，不能以stub dependency冒充真实SDK。

## 15. 测试矩阵和失败注入

`verification/ACCEPTANCE.csv`列出逐例条件。ED-1为本轮必达；FUTURE不自动执行。逻辑用例可以组织在同一个CTest里，不把用例数量当注册数量。

重点覆盖：初始/非法容量、错线程、错history/base、两业务回放、分支/no-op、保存点、前缀裁剪、所有权转移、逐准备失败、publish/析构重入、route激活注销、真实CommandRouter、installed consumer及有限成本。

失败前后对拍必须含：业务模型、选择、操作memento、entries、cursor、saved、current、Revision、event_sequence、输入指针。只看最后一个值不够。prepare失败应实际命中分配或校验，不以缺头/没加载DLL当负例成功。

apply无分配要有真实类型/容量/分配点证据，EXE-local new=0不能证明DLL全域无分配。测试可用私有诊断或隔离构建开关，但不在公开接口增加可写状态、不产生ODR布局不一致。死亡测试若使用，必须匹配预期契约原因，不能任意崩溃算通过。

## 16. 有限性能和内存记录

没有等价旧通用实现，不虚构加速比。两个fixture分别做固定1,000与10,000次非空execute/undo/redo完整批量以及clear/close，至少五次独立进程，固定warmup/上限/数据。

持续样本保持模型尺寸受控，比如固定宽文本或固定记录值；不要把不断增长整文档拷贝归因于core。另选64/1,024记录的有限创建删除样本，说明业务准备成本和history保留量。

记录成功数、独立checksum/内容、失败/notice/析构计数、metadata backing、charged retained、prepare账目及全部样本。诊断/正式计时分开。批量时间不伪造逐操作p95，不能平均多run p95。

不重复整个Script历史基准，不为每个纳秒试遍模板/锁/allocator。发现明确的O(N²)、每条操作复制全部history等冗余可窄修并给依据；不删检查、裁剪错误样本或少做业务换速度。

## 17. 阶段与停止点

### ED-1：共享机制与通用路由——本包默认授权

实际实现core、ActiveEditHistory、Controller；两个无Scene/UI业务fixture；真实CommandRouter和独立安装消费者；失败/保存/route/生命周期/成本验证。不得只交同义设计。

结束状态为“共享机制及路由候选，等待审阅；真实业务尚未统一迁移”。旧Inspector/Graph不是被验收的新统一history。默认不向旧application绑定新全局Undo。

### ED-2：首个真实业务迁移——另行批准

从有闭合模型和原子协议的现有业务选择一条，完整迁移其文档所有写入口、清除旧权威栈；另一种非同构业务接入证明无需改core。具体业务范围按届时源码和需求确定，不由ED-1 Agent自由创建全部场景体系。

### ED-3：多Pane和真实输入——另行批准

接应用焦点与统一动作，验证多Pane共用history、手势、文本输入优先级、选择同步。迁移业务没有fallback；未迁移业务明确列出，不能宣称全局统一。

### ED-4：有限联合资格——另行批准

对应业务正式codec的保存/重载、preview、关闭、安装与成本。没有codec不造JSON假保存；不自动扩多脚本、热重载或协同编辑。

## 18. LLM 禁止行为与真实阻塞

禁止：编辑语义放modules；核心识别业务；variant列所有操作；mutable getter绕回大State；每Pane一栈；全部文档混一全局栈；外层history套旧history；回放再自动记录；先删redo再准备；apply首次分配/Registry回调/Lua/GPU；旧Entity代次复活；弱对象活着即认定版本匹配；任意memcpy恢复组件；无codec假保存；自动迁移全部Editor；以private/void*改名隐藏反向依赖；旧二进制或缺文件负例冒充资格。

允许在确定语义下选私有容器和辅助函数，复用现有基础设施，不需为小实现细节停下确认。公开行为/目录/错误所有权的变更必须明确提出，不能暗改。

GraphDocument缺少纯提交接口是后续业务设计事项，不是本轮改GraphKit或放宽核心的授权。核心协议若发现真实矛盾，给精确反例和影响，完成无依赖部分，不能“先实现大概版本”。

## 19. 交付与结论口径

复用现有证据方式，在`.internal/evidence/editor/editing/ed1/`组织本轮记录；不改旧Script归档、不新建庞大取证平台。本机绝对路径不能代替可取文件。

交付最终source/dependency/config/compiler/prefix/EXE/DLL身份、改动分类、D01—D20映射、完整逻辑测试结果、原始日志、installed/relocation、两个业务trace、成本/内存和限制。

最终分别报告IMPLEMENTATION、CORE_PROTOCOL、EDITOR_ROUTING、META_INSTALL、BUSINESS_MIGRATION、PERFORMANCE_OBSERVATION、GUI_INTERACTION。本轮实际业务迁移为NOT_AUTHORIZED、完整GUI为NOT_TESTED，不藏成成功，也不扩大为必须开发完所有Editor。

保护未知修改，不reset/clean/stash/rebase、不升级依赖、不操作main/强推/tag/发布/冻结。用户交给实施方并要求执行后，只可在既定目标分支普通提交/推送。本次文档制作不执行这些写操作。

## 20. 来源与事实边界

官方网页于2026-09-08核对；只借鉴公开机制，不复制代码，不将LUX拟定保证说成官方框架共同内部实现。

- [Q1] https://doc.qt.io/qt-6/qundocommand.html
- [Q2] https://doc.qt.io/qt-6/qundostack.html
- [Q3] https://doc.qt.io/qt-6/qundogroup.html
- [G1] https://docs.godotengine.org/en/stable/classes/class_undoredo.html
- [U1] https://docs.unity3d.com/6000.0/Documentation/ScriptReference/Undo.RecordObject.html

[L0] 本次查询HEAD 0ceedbcdbc75f3b2be4b6be8d0b0cbfc6e0b8db7。
[L1] AGENTS.md。
[L2] engine/editor/CMakeLists.txt。
[L3] engine/editor/node_graph/include/lux/engine/editor/node_graph/GraphEditingSession.hpp。
[L4] engine/editor/node_graph/include/lux/engine/editor/node_graph/GraphDocument.hpp。
[L5] engine/editor/inspector/include/lux/engine/editor/inspector/InspectorContext.hpp。
[L6] modules/function/ui/include/lux/engine/ui/CommandRouter.hpp。
[L7] engine/editor/context/CMakeLists.txt。
[L8] engine/editor/application/CMakeLists.txt。

固定URL见sources/SOURCE_REGISTER.json。旧v1属于设计修订来源，不作为当前路径/签名授权。附带历史Script材料不授权恢复旧阶段或额外工程。

---

# 附录 A：完整接口契约

下列声明与contracts文件一致，**未编译、无链接实现**。生产补准确include/visibility/meta；不能改变所有权和提交契约。业务不需要、更不允许将自己的具体operation加入这些核心头。

## A.EditTypes

文件：`contracts/EditTypes.contract.hpp`。

```cpp
#pragma once
// v2 normative interface. Declarations only; NOT a compiled SDK or header-only implementation.
// Production: engine/editor/editing/include/lux/engine/editor/editing/EditTypes.hpp.
#include <lux/cxx/compile_time/expected.hpp>
#include <array>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <string_view>

namespace lux::editor::editing
{
    enum class EEditError : std::uint8_t
    {
        INVALID_ARGUMENT, INVALID_LIMITS, WRONG_THREAD, BUSY, CLOSED,
        NO_UNDO, NO_REDO, WRONG_HISTORY, STALE_BASE, PRECONDITION_FAILED,
        UNSUPPORTED_OPERATION, HISTORY_LIMIT, STAGING_LIMIT, ALLOCATION_FAILURE,
        ID_EXHAUSTED, CONTRACT_VIOLATION, SAVE_IN_PROGRESS, STALE_SAVE,
        NO_ACTIVE_TARGET, STALE_TARGET, DUPLICATE_TARGET, TARGET_CAPACITY, BLOCKED_BY_HOST
    };
    struct EditFailure final
    {
        EEditError code{EEditError::INVALID_ARGUMENT};
        std::uint64_t domain_code{};
        std::array<char, 192> message{};
        bool message_truncated{};
    };
    [[nodiscard]] EditFailure makeEditFailure(
        EEditError code, std::uint64_t domain_code = 0, std::string_view message = {}) noexcept;
    template<class T> using EditResult = lux::cxx::expected<T, EditFailure>;

    struct HistoryId final
    {
        std::uint64_t value{};
        [[nodiscard]] constexpr bool valid() const noexcept { return value != 0; }
        friend bool operator==(const HistoryId&, const HistoryId&) noexcept = default;
    };
    struct StateId final
    {
        HistoryId history;
        std::uint64_t serial{};
        [[nodiscard]] constexpr bool valid() const noexcept { return history.valid() && serial != 0; }
        friend bool operator==(const StateId&, const StateId&) noexcept = default;
    };
    struct Revision final
    {
        std::uint64_t value{};
        friend bool operator==(const Revision&, const Revision&) noexcept = default;
    };
    enum class EApplyKind : std::uint8_t { EXECUTE, UNDO, REDO };
    enum class EDirection : std::uint8_t { FORWARD, BACKWARD };
    enum class EEditEffect : std::uint8_t { CHANGE, NO_CHANGE };
    enum class EHistoryPhase : std::uint8_t { IDLE, PREPARING, COMMITTING, PUBLISHING, RECLAIMING, CLOSED };
    enum class EHistoryEvent : std::uint8_t { EXECUTED, UNDONE, REDONE, CLEARED, SAVE_STARTED, SAVE_FINISHED, CLOSED };
    enum class ESaveOutcome : std::uint8_t { SUCCEEDED, FAILED, CANCELLED };

    struct HistoryLimits final
    {
        std::size_t max_entries{};
        std::size_t max_retained_bytes{};
        std::size_t max_staging_bytes{};
        std::size_t max_label_bytes{};
    };
    // Owning scalar-only state. Safe to copy; NOT permission to access the history across threads.
    struct HistorySnapshot final
    {
        HistoryId history;
        StateId current;
        std::optional<StateId> saved;
        Revision revision;
        std::uint64_t event_sequence{};
        std::size_t entry_count{}, cursor{}, charged_retained_bytes{}, history_metadata_bytes{};
        bool save_pending{}, clean{}, closed{};
    };
    // Owner-thread borrow: labels expire at the next mutation or destruction.
    struct HistoryView final
    {
        HistorySnapshot snapshot;
        EHistoryPhase phase{EHistoryPhase::IDLE};
        std::string_view undo_label, redo_label;
        bool can_undo{}, can_redo{};
    };
    struct HistoryEntryView final
    {
        std::size_t index{};
        StateId before, after;
        std::string_view label;
        std::size_t charged_bytes{};
        bool applied{};
    };
    struct ApplyContext final
    {
        HistoryId history;
        EApplyKind kind{EApplyKind::EXECUTE};
        EDirection direction{EDirection::FORWARD};
        StateId from, to;
        Revision next_revision;
    };
    struct CommitInfo final
    {
        EApplyKind kind{EApplyKind::EXECUTE};
        StateId from, to;
        Revision revision;
        std::uint64_t event_sequence{};
        std::string_view label; // Borrowed for publish only; copy before delayed use.
    };
    struct ApplyResult final
    {
        EEditEffect effect{EEditEffect::NO_CHANGE};
        StateId current;
        Revision revision;
        std::uint64_t event_sequence{};
    };
    struct HistoryNotice final
    {
        EHistoryEvent kind{EHistoryEvent::EXECUTED};
        HistorySnapshot snapshot;
    };
    struct HistoryObserver final
    {
        void* context{};
        void (*changed)(void*, const HistoryNotice&) noexcept{};
    };
    struct HistoryCreateInfo final
    {
        HistoryLimits limits;
        HistoryObserver observer;
        bool initially_saved{};
    };
    class EditHistory;
    // Conservative, monotonic reservation ledger for one prepare call, NOT an allocator or sandbox.
    class EditPreparationBudget final
    {
    public:
        EditPreparationBudget(const EditPreparationBudget&) = delete;
        EditPreparationBudget& operator=(const EditPreparationBudget&) = delete;
        [[nodiscard]] EditResult<void> reserve(std::size_t bytes) noexcept;
        [[nodiscard]] std::size_t limit() const noexcept;
        [[nodiscard]] std::size_t used() const noexcept;
        [[nodiscard]] std::size_t remaining() const noexcept;
    private:
        friend class EditHistory;
        explicit EditPreparationBudget(std::size_t limit) noexcept;
        std::size_t limit_{}, used_{};
    };
    class SaveTicket final
    {
    public:
        SaveTicket() noexcept = default;
        [[nodiscard]] bool valid() const noexcept;
        [[nodiscard]] HistoryId history() const noexcept;
        [[nodiscard]] StateId state() const noexcept;
        [[nodiscard]] std::uint64_t request() const noexcept;
    private:
        friend class EditHistory;
        SaveTicket(HistoryId history, StateId state, std::uint64_t request) noexcept;
        HistoryId history_;
        StateId state_;
        std::uint64_t request_{};
    };
}
```

## A.EditOperation

文件：`contracts/EditOperation.contract.hpp`。

```cpp
#pragma once
// Production: engine/editor/editing/include/lux/engine/editor/editing/EditOperation.hpp.
#include "EditTypes.contract.hpp"
#include <memory>
namespace lux::editor::editing
{
    class PreparedEdit
    {
    public:
        virtual ~PreparedEdit() noexcept = default;
        PreparedEdit(const PreparedEdit&) = delete;
        PreparedEdit& operator=(const PreparedEdit&) = delete;
        PreparedEdit(PreparedEdit&&) = delete;
        PreparedEdit& operator=(PreparedEdit&&) = delete;
        [[nodiscard]] virtual EEditEffect effect() const noexcept = 0;
    protected:
        PreparedEdit() noexcept = default;
    private:
        friend class EditHistory;
        // No new allocations, validation, callbacks, I/O, or fallible live-model mutation.
        virtual void apply() noexcept = 0;
        // Business model AND history are committed before this call.
        virtual void publish(const CommitInfo&) noexcept = 0;
    };
    using PreparedEditPtr = std::unique_ptr<PreparedEdit>;
    class EditOperation
    {
    public:
        virtual ~EditOperation() noexcept = default;
        EditOperation(const EditOperation&) = delete;
        EditOperation& operator=(const EditOperation&) = delete;
        EditOperation(EditOperation&&) = delete;
        EditOperation& operator=(EditOperation&&) = delete;
        [[nodiscard]] virtual HistoryId historyId() const noexcept = 0;
        [[nodiscard]] virtual StateId baseState() const noexcept = 0;
        [[nodiscard]] virtual std::string_view label() const noexcept = 0;
        [[nodiscard]] virtual std::size_t retainedBytesUpperBound() const noexcept = 0;
        [[nodiscard]] virtual EditResult<PreparedEditPtr>
        prepare(const ApplyContext& context, EditPreparationBudget& budget) const noexcept = 0;
    protected:
        EditOperation() noexcept = default;
    };
    using EditOperationPtr = std::unique_ptr<EditOperation>;
}
```

## A.EditHistory

文件：`contracts/EditHistory.contract.hpp`。

```cpp
#pragma once
// Production: engine/editor/editing/include/lux/engine/editor/editing/EditHistory.hpp.
#include "EditOperation.contract.hpp"
#include <memory>
namespace lux::editor::editing
{
    class EditHistory final
    {
    public:
        using CreateResult = EditResult<std::unique_ptr<EditHistory>>;
        [[nodiscard]] static CreateResult create(HistoryCreateInfo info) noexcept;
        ~EditHistory() noexcept;
        EditHistory(const EditHistory&) = delete;
        EditHistory& operator=(const EditHistory&) = delete;
        EditHistory(EditHistory&&) = delete;
        EditHistory& operator=(EditHistory&&) = delete;
        [[nodiscard]] HistoryId id() const noexcept;
        [[nodiscard]] EditResult<HistoryView> view() const noexcept;
        [[nodiscard]] EditResult<HistoryEntryView> entry(std::size_t index) const noexcept;
        // Failure: caller retains unchanged operation.
        // CHANGE success: ownership moves into history, input becomes null.
        // NO_CHANGE success: input is destroyed under the gate, without new history, then null.
        [[nodiscard]] EditResult<ApplyResult> execute(EditOperationPtr& operation) noexcept;
        [[nodiscard]] EditResult<ApplyResult> undo() noexcept;
        [[nodiscard]] EditResult<ApplyResult> redo() noexcept;
        // Metadata only; no file I/O or asynchronous task is started here.
        [[nodiscard]] EditResult<SaveTicket> beginSave() noexcept;
        [[nodiscard]] EditResult<void> finishSave(SaveTicket ticket, ESaveOutcome outcome) noexcept;
        [[nodiscard]] EditResult<void> clear() noexcept;
        [[nodiscard]] EditResult<void> close() noexcept;
    private:
        struct Impl;
        explicit EditHistory(std::unique_ptr<Impl> impl) noexcept;
        std::unique_ptr<Impl> impl_;
    };
}
```

## A.EditHistoryTarget

文件：`contracts/EditHistoryTarget.contract.hpp`。

```cpp
#pragma once
// Production: engine/editor/editing/include/lux/engine/editor/editing/EditHistoryTarget.hpp.
#include "EditTypes.contract.hpp"
namespace lux::editor::editing
{
    enum class EHistoryAction : std::uint8_t { UNDO, REDO };
    enum class EHistoryActionAvailability : std::uint8_t { READY, EMPTY, BUSY, BLOCKED, CLOSED };
    enum class EHistoryTargetOutcome : std::uint8_t { CONTENT_APPLIED, TRANSIENT_CANCELLED };
    struct HistoryTargetView final
    {
        HistorySnapshot history;
        EHistoryActionAvailability undo{EHistoryActionAvailability::EMPTY};
        EHistoryActionAvailability redo{EHistoryActionAvailability::EMPTY};
        std::string_view undo_label, redo_label;
    };
    struct HistoryTargetResult final
    {
        EHistoryTargetOutcome outcome{EHistoryTargetOutcome::CONTENT_APPLIED};
        ApplyResult content;
    };
    // Business session port; never exposes mutable EditHistory or business model.
    class EditHistoryTarget
    {
    public:
        virtual ~EditHistoryTarget() noexcept = default;
        [[nodiscard]] virtual HistoryId historyId() const noexcept = 0;
        [[nodiscard]] virtual EditResult<HistoryTargetView> historyView() const noexcept = 0;
        [[nodiscard]] virtual EditResult<HistoryTargetResult> undo() noexcept = 0;
        [[nodiscard]] virtual EditResult<HistoryTargetResult> redo() noexcept = 0;
    };
}
```

## A.ActiveEditHistory

文件：`contracts/ActiveEditHistory.contract.hpp`。

```cpp
#pragma once
// Application-level routing, NOT part of the domain-blind editing core.
// Production: engine/editor/context/include/lux/engine/editor/ActiveEditHistory.hpp.
#include "EditHistoryTarget.contract.hpp"
#include <memory>
namespace lux::editor
{
    namespace detail { struct ActiveEditHistoryControl; }
    struct HistoryTargetHandle final
    {
        std::uint64_t router{}, registration{};
        [[nodiscard]] constexpr bool valid() const noexcept { return router != 0 && registration != 0; }
        friend bool operator==(const HistoryTargetHandle&, const HistoryTargetHandle&) noexcept = default;
    };
    class ActiveEditHistory;
    class HistoryTargetRegistration final
    {
    public:
        HistoryTargetRegistration() noexcept = default;
        ~HistoryTargetRegistration() noexcept;
        HistoryTargetRegistration(const HistoryTargetRegistration&) = delete;
        HistoryTargetRegistration& operator=(const HistoryTargetRegistration&) = delete;
        HistoryTargetRegistration(HistoryTargetRegistration&& other) noexcept;
        HistoryTargetRegistration& operator=(HistoryTargetRegistration&& other) noexcept;
        [[nodiscard]] HistoryTargetHandle handle() const noexcept;
        // BUSY/WRONG_THREAD failure retains the live registration.
        [[nodiscard]] editing::EditResult<void> reset() noexcept;
    private:
        friend class ActiveEditHistory;
        HistoryTargetRegistration(
            std::weak_ptr<detail::ActiveEditHistoryControl> control, HistoryTargetHandle handle) noexcept;
        std::weak_ptr<detail::ActiveEditHistoryControl> control_;
        HistoryTargetHandle handle_;
    };
    struct ActiveHistoryView final
    {
        HistoryTargetHandle handle;
        bool has_target{};
        editing::HistoryTargetView target;
    };
    class ActiveEditHistory final
    {
    public:
        using CreateResult = editing::EditResult<std::unique_ptr<ActiveEditHistory>>;
        [[nodiscard]] static CreateResult create(std::size_t target_capacity) noexcept;
        ~ActiveEditHistory() noexcept;
        ActiveEditHistory(const ActiveEditHistory&) = delete;
        ActiveEditHistory& operator=(const ActiveEditHistory&) = delete;
        ActiveEditHistory(ActiveEditHistory&&) = delete;
        ActiveEditHistory& operator=(ActiveEditHistory&&) = delete;
        [[nodiscard]] editing::EditResult<HistoryTargetRegistration>
        registerTarget(editing::EditHistoryTarget& target) noexcept;
        [[nodiscard]] editing::EditResult<void> activate(HistoryTargetHandle target) noexcept;
        [[nodiscard]] editing::EditResult<void> deactivate() noexcept;
        // Owner-thread value query; does not call into the target. Empty handle means no active target.
        [[nodiscard]] editing::EditResult<HistoryTargetHandle> activeTarget() const noexcept;
        [[nodiscard]] editing::EditResult<ActiveHistoryView> view() const noexcept;
        [[nodiscard]] editing::EditResult<editing::HistoryTargetResult> undo() noexcept;
        [[nodiscard]] editing::EditResult<editing::HistoryTargetResult> redo() noexcept;
        [[nodiscard]] editing::EditResult<void> close() noexcept;
    private:
        friend class HistoryTargetRegistration;
        struct Impl;
        explicit ActiveEditHistory(std::unique_ptr<Impl> impl) noexcept;
        [[nodiscard]] editing::EditResult<void> unregisterTarget(HistoryTargetHandle target) noexcept;
        std::unique_ptr<Impl> impl_;
    };
}
```

## A.EditHistoryController

文件：`contracts/EditHistoryController.contract.hpp`。

```cpp
#pragma once
// Production: engine/editor/context/include/lux/engine/editor/EditHistoryController.hpp.
// Use existing editor_context visibility and meta generation.
#include "ActiveEditHistory.contract.hpp"
#include <lux/engine/object/Object.hpp>
#include <lux/engine/object/ObjectAnnotations.hpp>
namespace lux::editor
{
    struct EditHistoryActionFailure final
    {
        HistoryTargetHandle target;
        editing::EHistoryAction action{editing::EHistoryAction::UNDO};
        editing::EditFailure failure;
    };
    class LUX_OBJECT() EditHistoryController final : public object::Object<EditHistoryController>
    {
    public:
        static const signal_type<EditHistoryActionFailure> failed;
        explicit EditHistoryController(object::ObjectDispatcherRef dispatcher, ActiveEditHistory& histories) noexcept;
        ~EditHistoryController() override;
        void undo() noexcept;
        void redo() noexcept;
        [[nodiscard]] bool canUndo() const noexcept;
        [[nodiscard]] bool canRedo() const noexcept;
        [[nodiscard]] std::string_view undoLabel() const noexcept;
        [[nodiscard]] std::string_view redoLabel() const noexcept;
    private:
        ActiveEditHistory* histories_{};
    };
}
```

# 附录 B：逐例验收矩阵

ED-1为本轮必达，FUTURE为后续阶段；87项逻辑用例不等于87个CTest注册。

| ID | 阶段 | 组 | 前提／操作 | 必须结果 | 证据 |
|---|---|---|---|---|---|
|C01|ED-1|Core creation|正数上限；initially_saved=false；创建history|ID非零；serial=1；revision/event=0；entry/cursor=0；clean=false；无notice|初始完整snapshot|
|C02|ED-1|Core creation|同进程从不同调用组件创建两history；比较身份；关闭后新建|全部HistoryId不同；新建不复用旧ID|含installed consumer跨DLL结果|
|C03|ED-1|Core creation|分别将4个limit置0；槽位计算接近SIZE_MAX；调用create|INVALID_LIMITS或受控overflow；无部分对象泄漏|各无效输入独立退出与资源计数|
|C04|ED-1|Core creation|实际factory分配点故障注入；create失败再正常创建|ALLOCATION_FAILURE；释放已取得存储；后续成功|准确注入点和构造析构数|
|C05|ED-1|Threads|history owner静止；独立线程借只读稳定对象；异线程view/entry/execute/undo/redo/clear/save/close|WRONG_THREAD；不得调用operation虚函数；输入指针保留|join后owner比对全snapshot和业务数|
|C06|ED-1|Admission|空operation指针；execute|INVALID_ARGUMENT；无状态变化或notice|state/entries/输入对比|
|C07|ED-1|Admission|A构造的operation交给B；execute|WRONG_HISTORY；A/B模型和历史不变|两份历史、模型和指针计数|
|C08|ED-1|Admission|操作捕获S1；history已到S2；execute旧操作|STALE_BASE；输入可丢弃；不消耗redo|state与原operation数据|
|C09|ED-1|Admission|标签空/过长/含NUL；单条payload超限；分别execute|按规范拒绝；不静默截标签或退化成不可撤销|metadata虚调用和目标业务计数|
|C10|ED-1|Basic history|文本从alpha开始；替换一次；undo；redo|内容准确；cursor 1/0/1；初次新state；redo复用state；revision 1/2/3|独立期望字符串与完整snapshot|
|C11|ED-1|Basic history|记录模型有选中A；删除A；undo；redo|逻辑记录存在性和选择始终一致；准备成功后再发布|两个独立观察者的内容/选择/历史读数|
|C12|ED-1|Basic history|空history和已处于历史末端；undo/redo|NO_UNDO/NO_REDO；无业务调用、无notice|counter=0|
|C13|ED-1|Basic history|先修改A再修改B；逐次undo/redo|每次命中正确业务目标和direction；确定前后内容|操作顺序trace|
|C14|ED-1|Branches|A/B/C已执行；undo两步；提交D|只在成功后丢B/C redo；保留A/D；新StateId不复用|析构顺序与entries before/after|
|C15|ED-1|Branches|存在redo分支；新操作prepare失败|redo内容/游标/保存点全保留；operation仍归调用方|失败前后完整snapshot与内容|
|C16|ED-1|Branches|存在redo分支；合法NO_CHANGE操作|指针清空并安全析构；entry/cursor/state/revision/event/redo不变；不publish|no-op plan/apply/publish计数|
|C17|ED-1|Branches|目标不存在但新旧值字面相同；execute|验证失败不是NO_CHANGE成功|target validation计数|
|C18|ED-1|Branches|已接受条目；业务错误返回NO_CHANGE；undo/redo|CONTRACT_VIOLATION；游标不动；不自动删除记录|故障plan trace|
|C19|ED-1|State identities|S1→S2→S3→undo到S2→新分支；继续多次分支|新serial单调不复用；revision每次内容变化递增|state序列|
|C20|ED-1|Ownership|新operation含可观测资源；execute成功CHANGE|调用方ptr=null；history释放时才析构；undo不析构条目|独占生命周期计数|
|C21|ED-1|Ownership|prepare可重试失败；失败后修正外部受控条件并重试同一ptr|失败操作及memento未变；成功才转移|相同操作地址、snapshot、计数|
|C22|ED-1|Ownership|无实际变化但持恢复资源；execute NO_CHANGE|RECLAIMING释放恰好一次；析构重入得到BUSY|phase+析构trace|
|C23|ED-1|Ownership|移交过的业务operation来自consumer模块；核心close释放|动态派生析构和所属恢复资源释放一次|installed consumer跨DLL日志|
|F01|ED-1|Prepare failure|文本range超过当前内容或整数相加溢出；execute|PRECONDITION_FAILED或INVALID_ARGUMENT；无live变更|实际range/value对拍|
|F02|ED-1|Prepare failure|记录删除准备的第1/第2资源分配失败；分别执行|所有未提交暂存逆序释放；model/selection/history不变|注入点命中与live资源0|
|F03|ED-1|Prepare failure|核心标题复制分配失败；execute|ALLOCATION_FAILURE；输入保留；redo不丢|核心真实分配点命中|
|F04|ED-1|Prepare failure|业务budget不足；reserve后不分配|STAGING_LIMIT；reserve失败used不增加|预算和实际allocation计数|
|F05|ED-1|Prepare failure|budget exact/0/溢出请求；按顺序reserve|边界正确；无回绕；单调保守计费|budget数值trace|
|F06|ED-1|Prepare failure|业务prepare错误返回空plan；execute|CONTRACT_VIOLATION；操作保留；无提交|模型/游标与virtual trace|
|F07|ED-1|Prepare failure|Undo恢复暂存失败；undo后解除注入重试|首次所有内容/历史不变；重试准确恢复|failure与retry两份结果|
|F08|ED-1|Prepare failure|Redo恢复暂存失败；redo后重试|未提前挪cursor；未改变恢复memento|before/after完整对比|
|F09|ED-1|Commit boundary|prepare完成后关闭实际分配入口；apply并发布有限预留通知|纯提交不触发额外分配；模型/选择/history一致|跨模块分配范围和源码容量证明|
|F10|ED-1|Commit boundary|cached_label使用短字符串SSO且需要前缀压紧；execute触发prune后publish|CommitInfo.label准确无悬空；queued通知不借该view|标签内容、ASan仅环境已有时附加非门槛|
|F11|ED-1|Reentry|operation.prepare尝试同history execute/undo/clear/save/close；各独立子例|BUSY；外层可继续；输入所有权不丢|inner目标业务=0与外层结果|
|F12|ED-1|Reentry|publish observer读取全部model/history并尝试写；execute/undo/redo|读取一致最终状态；写BUSY；没有重复历史|observer trace|
|F13|ED-1|Reentry|plan/被裁剪operation析构试图重入；触发no-op/prune/clear/close|门保持；无递归回放；close后按CLOSED拒绝|析构阶段与释放计数|
|F14|ED-1|Reentry|另一个独立history同owner；A的安全publish内操作B|B可按自身协议成功；非全局互斥|两history正确顺序和状态|
|F15|ED-1|Failure recovery|一项普通输入失败；随后合法编辑同history|正常成功；无永久error latch|counter和最终内容|
|L01|ED-1|Limits|max_entries=2；执行A/B/C再undo两次|仅B/C可撤；回到A后；不假称回初始|base/entry/cursor/state|
|L02|ED-1|Limits|retained低于新旧总计；触发最小前缀裁剪|只裁最少旧应用前缀；不删中间；charge合限|实际charge与entry列表|
|L03|ED-1|Limits|大redo分支但新操作可替换其费用；execute新分支|按将保留前缀+新entry计费；不被旧redo费用错误拒绝|容量规划与最终charge|
|L04|ED-1|Limits|单条操作超max_retained；execute|HISTORY_LIMIT；原历史不变；输入保留|全状态和无业务计数|
|L05|ED-1|Limits|memento共享immutable数据；多条历史/裁剪|允许保守重复计费；不把charged当RSS；最后引用才释放|charged与真实引用析构分列|
|L06|ED-1|Clear|dirty内容且有redo、pending save；clear|内容/state/revision/saved/ticket不变；历史空；事件正确|snapshot与finishSave成功|
|L07|ED-1|Clear|历史原来已空；clear两次|无重复CLEARED事件；不改变dirty|事件数|
|L08|ED-1|Exhaustion|私有测试快照接近state/revision/event极限；ordinary mutation|ID_EXHAUSTED前拒绝；不回绕/覆盖state|隔离进程私有探针|
|L09|ED-1|Exhaustion|event_sequence已经最大且有资源；close|资源仍释放；终态saturated closed；不因计数漏清理|closed通知和资源0|
|S01|ED-1|Save|initially_saved=true；编辑再undo/redo|初始clean；编辑dirty；回保存state clean|state/saved/revision|
|S02|ED-1|Save|S2开始保存，随后编辑到S3；S2保存成功|saved=S2,current=S3,dirty；undo到S2 clean|ticket与状态trace|
|S03|ED-1|Save|已经一个pending ticket；再次beginSave|SAVE_IN_PROGRESS；原ticket保留|pending匹配|
|S04|ED-1|Save|分别持invalid/foreign/旧完成ticket；finishSave|STALE_SAVE或准确closed；不覆盖saved|每负例独立|
|S05|ED-1|Save|同ticket先成功；重复finishSave|STALE_SAVE；saved/event不重复变|notice计数|
|S06|ED-1|Save|有效保存请求；FAILED和CANCELLED独立测试|旧saved保留；pending清除；后续新请求成功|失败恢复trace|
|S07|ED-1|Save|publish回调里报告写入已成功；finishSave busy后保留结果重试|第一次BUSY；下一owner点确认原state；不丢完成|ticket重试与saved|
|S08|ED-1|Save|保存的state已从redo分支删除或被裁剪；保存成功或查询clean|仍记录真实写入state；新内容不能伪clean|分支/保存组合|
|S09|ED-1|Save|pending ticket时关闭并新建history；迟到finishSave|旧closed拒绝；新history拒绝foreign；无新模型访问|历史ID与provider=0|
|R01|ED-1|Routing|两种不同EditHistoryTarget业务；注册/显式激活A/B并undo/redo|只选中target业务发生；核心无domain switch|两模型与route trace|
|R02|ED-1|Routing|无active或deactivate后；view/undo/redo|view has_target=false；NO_ACTIVE_TARGET；不自动找其他栈|业务=0|
|R03|ED-1|Routing|target_capacity满或同pointer/history再注册；registerTarget|TARGET_CAPACITY/DUPLICATE_TARGET；原状态不变|registry数量及handle|
|R04|ED-1|Routing|foreign router或已经reset的handle；activate|STALE_TARGET；不覆盖当前有效active；activeTarget值查询不调用target|旧active保留|
|R05|ED-1|Routing|当前target注销后注册新target复用槽；用旧handle激活|旧registration不命中新对象；新token不同|ID序列|
|R06|ED-1|Routing|target history BUSY/BLOCKED/CLOSED；undo/redo|不调用另一target，不静默清空历史；返回准确错误|业务目标=0|
|R07|ED-1|Routing|一个host有预览手势而无局部文本消费；undo|TRANSIENT_CANCELLED；内容history不变；下一undo才内容|preview/内容双计数|
|R08|ED-1|Routing|活动手势；redo|BLOCKED_BY_HOST；不提交或取消手势|preview不变|
|R09|ED-1|Routing|target回调内尝试activate/reset/close；路由undo|BUSY；原token保持；业务对象直到回调后存活|资源寿命和explicit retry|
|R10|ED-1|Routing|两个live registration；move construction/assignment/self-move|唯一token；旧目标先正常注销；源为空；self保持|目标连接和注销数|
|R11|ED-1|Routing|显式reset busy后owner安全点；retry reset后销毁target|成功前不能销毁；成功后旧handle拒绝|target析构顺序|
|R12|ED-1|Routing|router先close并销毁，仍有token；晚reset/析构token|不解引用旧router；不操作新router或business|weak-control资源计数|
|R13|ED-1|Routing|异线程访问live router/token；activate/view/reset等|WRONG_THREAD且token不丢；不能只assert消失|join后状态|
|R14|ED-1|Commands|真实CommandRouter+LuxObject Controller；define/bindGlobal/state/invoke|两业务正确undo/redo；enabled与实际target匹配|实际CommandRouter调用|
|R15|ED-1|Commands|enabled查询后target被业务模式禁用；invoke观察Router是否重新禁用；另用直接Controller入口验证业务拒绝|Router未分派时业务0、不要求Controller.failed；实际进入Controller的失败才发原目标错误|两个独立分支的dispatch/Controller/业务计数|
|R16|ED-1|Commands|业务prepare失败被Controller接收；invoke后合法重试|一次失败notice；后续成功；不吞错误或锁死|failed sink+内容|
|R17|ED-1|Commands|切换active target但菜单取得焦点；使用明确route，不自动deactivate|命令仍作用于明确文档；不按selection猜|headless路由策略；不宣称真实键盘UI|
|I01|ED-1|Install|仅安装SDK和consumer自有源码；configure/build/run|两个业务无需core修改；无source/pinclude/旧build依赖|实际compile/link命令|
|I02|ED-1|Install|隔离旧前缀并换SDK位置；重新configure/build/run|正确find组件和headers；虚析构准确|relocation日志和解析路径|
|I03|ED-1|Install|同配置无修改第二build；build all|no-op；不重新生成同内容metadata|构建日志|
|I04|ED-1|Dependency|core直接/传递链接和include检查；审计installed consumer|无Scene/World/Simulation/UI/Object/ImGui/Vulkan/Graph；context依赖分开|DAG和真实链接闭包|
|I05|ED-1|Regression|受影响context/object/UI消费者；RelWithDebInfo真实回归|旧接口未被误删；已存在Graph/Inspector测试语义保留|CTest范围和非零断言执行|
|I06|ED-1|Performance|两fixture固定规模非空工作；各5次进程1k/10k execute/undo/redo等|完整量/checksum；绝对成本/charged/staging/metadata清楚|全部原始样本不挑最好|
|B01|FUTURE|Real business migration|真实Graph或Scene编辑会话；迁移所有该文档写入口|一个权威history；不包装旧undo栈；原失败保证仍成立|生产路径与旧入口删除映射|
|B02|FUTURE|Pane synchronization|真实Hierarchy/Inspector/Viewport；创建/修改/删除连续undo redo|各视图与选择一致；关闭面板不改变结果|实际窗口交互和模型断言|
|B03|FUTURE|Logical identity|真实Scene删除/恢复；回放更早属性操作|逻辑对象命中；旧Entity/拾取/async资格仍失效|实际业务身份trace|
|B04|FUTURE|Selection policy|创建A后用户主动选择B；undo A|保留无关有效B；无用户介入时按业务策略恢复|文档selection版本|
|B05|FUTURE|Gesture|100次绝对preview；commit/cancel/net-zero|一条或零条history；不双执行；不误删redo|实际frame手势|
|B06|FUTURE|Input focus|文本输入框局部history为空但具有焦点；Ctrl+Z|不穿透删除场景；输入/手势/内容优先级正确|真实UI键盘与focus记录|
|B07|FUTURE|Save product|已批准source codec；保存中编辑/关闭重开/异步完成|实际文件内容匹配save state；不临时造格式|真实codec/IO/文件回读|
|B08|FUTURE|Preview projection|运行preview/编译失败/延迟回传；模型已提交后更新|历史仍一致；标不同步；拒绝旧revision结果|实际render/compiler边界|

# 附录 C：算法和不变量审查

# 算法与边界精化

本文件解释主规范，没有新架构或额外阶段授权。

## 1. 操作费用与裁剪公式

Entry={独占operation,before,after,cached_label,charged}。charged为operation固定上界加其标题缓存容量等逐entry拥有存储；预留Entry数组另记metadata，不漏也不双计为精确物理内存。

设原n条、cursor=k、新charge=c。先预检c自身不超限，再仅对将保留的[0,k)+new选择最少p，使k-p+1<=max_entries且sum(charges[p:k])+c<=max_retained_bytes。准备阶段不改任何旧条目。

成功后保留[p,k)追加new；[0,p)与[k,n)移到预留回收槽。saved即使引用被裁去状态也继续保存。新基点是剩余首项before；全部旧前缀裁掉时是new.before。不会恢复被裁去的操作。

## 2. 标题与容器移动

必须在Entry最终压紧结束后才取得CommitInfo.label。std::string的SSO可能因Entry移动换地址；不能拿准备阶段的string_view继续publish。

所有待丢operation先move到回收区，再压紧空槽。不能让move-assignment覆盖尚未移出的旧operation并提前执行其析构。回收顺序按原index从高到低，不参与模型恢复。

## 3. 常规错误分类

| 条件 | 返回 |
|---|---|
| limit为0、工厂槽位/元数据计算无法表示 | INVALID_LIMITS |
| factory/prepare实际分配失败 | ALLOCATION_FAILURE |
| 标题空、内嵌NUL、空operation、entry越界 | INVALID_ARGUMENT |
| 标题超过max_label_bytes、单条或最终保留费用不合限 | HISTORY_LIMIT |
| prepare预算reserve不足或求和溢出 | STAGING_LIMIT |
| history身份不匹配 | WRONG_HISTORY |
| 初次operation.baseState不等于current | STALE_BASE |
| 内容范围/关系等领域前置条件不符 | PRECONDITION_FAILED，domain_code说明业务原因 |
| plan为空、存量undo/redo错误返回NO_CHANGE | CONTRACT_VIOLATION |
| state/revision/request或非终态event将溢出 | ID_EXHAUSTED |
| 无undo/redo或无active | NO_UNDO / NO_REDO / NO_ACTIVE_TARGET |

wrongthread/closed/busy优先于普通参数错误；已关闭view例外仍可读最终标量。label过长不静默截断；Error message可以有限截断并标志。

makeEditFailure不分配，message零初始化，最多复制191字节并终止NUL；输入内嵌NUL视为文字结束，存在被丢后缀或超长则message_truncated=true。它是有限诊断字节串，不建立完整本地化/Unicode库。成功路径不应构造不需要的长错误字符串。

HistoryObserver若changed=null则context也必须null；changed非空时允许context=null用于静态接收者。没有observer也必须完成全部内容和历史语义。

## 4. 失败所有权与业务门

核心自己的准备分配捕获到Result；业务prepare须自己遵守noexcept，将正常分配错误转Result。已经违反noexcept的业务不能靠外层catch恢复，不能承诺任意插件异常安全。

输入unique_ptr在整个同步execute期间被独占借用，调用方或回调不得并行修改该变量。错误返回保留其地址和memento；NO_CHANGE成功会在门内销毁。

业务prepare不得间接走另一入口修改同一模型。业务会话须将select/gesture/reload/close和所有写入口纳入同一文档门。core不能拦截绕过会话的裸Registry写入。fixture同样必须测试此点。

## 5. 通知与生命周期

内容execute/undo/redo各business publish一次、HistoryNotice一次；save/clear/close仅metadata notice，不调用业务publish。失败/no-op不发普通变化通知。

显式close时observer必须还存活；析构不通知。发布失败的渲染/编译后续任务不回滚已提交历史。queued listener自己拥有notice值，带版本重取权威模型，不持EntryView。

PreparedEdit旧数据析构、被裁剪条目析构都在RECLAIMING；再次写同history拒绝。其源模型与操作代码必须存活到这些清理返回。不能先销毁business model再让history的operation析构访问它。

## 6. 路由与状态对齐

每个注册target有固定HistoryId，register时检查其可查询、未关闭且身份有效。同一History不能重复注册为不同pane history。HistoryTargetView.history.history与注册身份必须一致，不一致视CONTRACT_VIOLATION且不执行业务。

ActiveEditHistory调用target虚方法期间禁止变更本route；view的借用标题遇target mutation、注销/销毁或route mutation失效。Controller在入口记录handle，failed不能误标成后来另一个active。

目标EMPTY对应NO_UNDO/NO_REDO；BUSY对应BUSY；BLOCKED对应BLOCKED_BY_HOST；CLOSED对应CLOSED。READY只是查询，真正target.undo/redo仍验证。当期间无修改且target返回成功，其结果必须对应原HistoryId，不允许跨目标回放。

应用把当前文本输入消费与文档动作分开。ED-1 headless测试不伪装实际IME/键盘资格；没有新增输入系统授权。

## 7. 现有业务接口不足不是core后门的理由

GraphEditingSession当前的undo/redo和GraphDocument的可失败attach/action不能直接放进PreparedEdit.apply。后续业务要证明staging与commit，或单独提出实际协议冲突。ED-1不修改这套存量，也不删除原原子inverse测试。

不能把dependent子操作全部对旧model prepare再顺序apply；业务组内必须有一致暂存视图。也不能把新history包裹旧history来隐藏迁移未完成。

## 8. 基准无比较来源时的口径

测试两fixture绝对成本即可。模型完整复制仅为小fixture证明，计费与耗时需包含它，不能称core高效或未来Scene同等复杂度。记录所有有效样本；无测试产物或错误工作量不进入性能平均。

## 9. 动作失败与UI未分派不是同一事件

CommandRouter可以在invoke时再次检查enabled并直接拒绝。此时目标业务为零，但Controller没有执行，不能要求它发failed或为了满足测试删除Router校验。另一个独立场景直接进入Controller、在业务prepare中失败，才验证owned failed通知与原handle。

Controller先用activeTarget取得handle值，该查询不调用业务virtual，也不取得可写target。错误线程下Route返回WRONG_THREAD；Controller本身是UI owner-only LuxObject入口，不承诺跨线程发signal。

成功target结果须匹配原HistoryId：CONTENT_APPLIED对应CHANGE；TRANSIENT_CANCELLED对应NO_CHANGE并保持内容state/revision。无历史且无预览返回NO_UNDO/NO_REDO，不返回第三种模糊成功。

# 附录 D：当前唯一实施任务 ED-1

# ED-1：共享编辑历史与通用 Editor 路由——实际实施任务单

2026-09-08，与主规范v2配套。用户发送并要求执行后生效。**只执行ED-1**。职责和协议已确定，不再以一篇同义设计代替编码，也不自动进入业务全面迁移。

## 1. 本轮完成什么

在engine/editor/editing建立EditHistory、EditOperation、PreparedEdit、EditHistoryTarget和值类型；现有engine/editor/context中建立ActiveEditHistory、Registration及LuxObject EditHistoryController。两种不同测试业务使用同一核心；真实CommandRouter动作与安装消费者形成可验证链路。

core不包含ScenePatchOperation、SceneEditSession、TextReplaceOperation、MaterialGraphOperation；具体类型仅位于测试业务或日后对应业务。所有Editor语义不进入modules。

## 2. 入口核对

记录实际Engine HEAD、branch、status、worktree、依赖/安装来源和编译配置。本包只读HEAD为0ceedbcdbc75f3b2be4b6be8d0b0cbfc6e0b8db7，不是回退指令。后续新增Script/VTune工作保持不动，不重标旧资格。

读AGENTS和下级约束；核对当前editor/CMake、context、InspectorContext、GraphEditingSession/GraphDocument、CommandRouter。新文件若已存在先比对，不重复创建。旧v1路径、命名、场景类型进入core和按值execute所有权均已撤回。

只写必要状态映射和改动计划后直接实施。普通内部细节自行选择；具体前提矛盾按规范登记并完成无依赖工作，不能扩大到新架构。

## 3. 改动白名单

允许新增engine/editor/editing；修改现有editor_context中两类通用接入、相应CMake/meta/测试；editor根依赖顺序；现有测试和安装注册的必要接线；一个cmake/installed-consumers/editor-editing消费者；本轮记录。

禁止修改modules生产代码、Scene/Simulation/Script runtime与其生成模板；禁止完整Scene源模型/所有Inspector写入口/GraphDocument协议迁移；禁止新增材质或脚本编辑产品；禁止在仍用旧栈的真实EditorApplication上全局启用新Undo；禁止新插件注册/消息总线/Variant/codec/database。

旧业务在ED-1未迁移，不等于允许同一业务双记。新机制只在明确fixture/consumer中接入，结束时准确标记真实业务尚未统一。

## 4. 内部实施顺序

1. 建唯一editor_editing共享component、visibility、四个公开头和具体实现；依赖仅标准库与compile_time。
2. 先建立入场拒绝、失败所有权、分支/no-op和prepare失败测试，再实现历史流程。
3. 补StateId/Revision/event_sequence、SaveTicket、预算/裁剪、clear/close；提交后不再发生正常可失败工作。
4. 完成TextBufferFixture和RecordDocumentFixture的真实操作、plan和独立期望；业务代码不进入core编译单元。
5. 实现ActiveEditHistory/Registration生命周期、Controller；实际bindGlobal/state/invoke验证两target和失败信号。
6. 复用现有meta和安装流程，consumer自有两种业务，跨模块销毁正确，不读源码/私有头。
7. 实际跑矩阵、依赖检查、fresh-prefix/relocation/no-op及有限绝对成本，绑定最终代码身份。

## 5. 不能改变的关键接口与行为

execute(EditOperationPtr&)失败保留指针及memento；CHANGE成功移入历史，NO_CHANGE成功安全释放但不改历史。

prepare不改live模型和选择；apply不分配/通知/执行可失败Registry；publish在历史一致后。错误日志不是历史权威。

新操作校验初次base；Undo/Redo按条目方向回放，Revision不回退。失败/no-op不删redo；裁剪仅成功后最旧已应用前缀。

一个pending SaveTicket，确认的是票据state不是完成时current；clear不伪clean；close不因计数耗尽漏资源。

live token busy reset保留；回调内不销毁target；source/target或文档类型不改变核心。单核心实现发行ID，不能多DLL静态计数冲突。

## 6. 验证要求

完成ACCEPTANCE.csv中全部ED-1逻辑用例，不把用例数冒充CTest注册数。所有测试用RelWithDebInfo并真实启用assert，构建/测试/计时不并行。实际启用相应Editor层配置，不能只跑排除了新target的profile。

失败对拍包括model、selection、memento、entries/cursor、saved/current、revision/event和输入指针。不同准备失败独立命中；错误分支目标业务必须为零，随后合法重试成功。死亡测试仅按精确预期原因通过。

实际CommandRouter与LuxObject信号，不用仿制路由。core安装consumer无Scene/UI依赖；route测试可以使用真实context的既有依赖，范围分开。

headless通过不写成真实键盘、窗口焦点、IME、材质/场景统一历史通过。环境受阻记录具体项，禁止stub依赖冒充工程资格。

有限成本按主规范固定工作量；无等价旧core不编造加速率。不重复Script微基准全集，不单独开启每个小残余优化。

## 7. 最终交付与停止

交付实际代码/提交、target/include依赖、D01—D20映射、全部原始日志和身份、consumer/relocation、两业务trace、route关闭与资源回收、成本和限制。

分别报告共享机制、通用路由、安装与失败协议结果。明确：真实Inspector/Graph/Material/FlowForge未在本轮迁移；完整GUI未验证。

保护未知修改；不reset/clean/stash/rebase、升级依赖、合并main、强推、tag、发布或冻结。本包送达并授权后可按原目标分支普通提交/推送。ED-1完成后停止等待独立审阅，不进入ED-2。
