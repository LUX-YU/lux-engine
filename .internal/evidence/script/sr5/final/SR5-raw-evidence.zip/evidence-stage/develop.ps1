$ErrorActionPreference = 'Stop'
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$env:LUX_FLOWFORGE_LINKER = Join-Path $env:VCToolsInstallDir 'bin/Hostx64/x64/link.exe'
$taskRoot = 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5'
cmake -S "$taskRoot/source" -B "$taskRoot/d" -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo -DLUX_BUILD_PROFILE=DEVELOPER -DLUX_LUA_VM=LUAJIT -DLUX_SCRIPT_HAS_LUA=ON -DLUX_BUILD_PHYSICS2D=ON -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DCMAKE_TOOLCHAIN_FILE=D:/Development/vcpkg/scripts/buildsystems/vcpkg.cmake '-DCMAKE_PREFIX_PATH=E:/SyncForder/CodeRepos/install/q2/toolset;E:/SyncForder/CodeRepos/install/q2/c;E:/SyncForder/CodeRepos/install/RelWithDebInfo' -DCMAKE_INSTALL_PREFIX=E:/SyncForder/CodeRepos/install/s5/d -DLUX_LUA_PORTABILITY_ARTIFACT=E:/SyncForder/CodeRepos/build/RelWithDebInfo/m4/t/engine/toolchain/lua/lua_portability_fixture.lxsa -DLUX_PHYSICS2D_LUA_ARTIFACT=E:/SyncForder/CodeRepos/build/RelWithDebInfo/m4/t/engine/toolchain/physics2d/physics2d_lua_fixture.lxsa -DLUX_PHYSICS2D_FLOWFORGE_ARTIFACT=E:/SyncForder/CodeRepos/build/RelWithDebInfo/m4/t/engine/toolchain/physics2d/physics2d_flowforge_fixture.lxsa *> "$taskRoot/configure.log"
if ($LASTEXITCODE) { throw 'configure failed' }
cmake --build "$taskRoot/d" --target all -j 4 -- -k 0 *> "$taskRoot/all.log"
if ($LASTEXITCODE) { throw 'all failed' }
