import csv,json,os,subprocess,sys,time,statistics,hashlib,ctypes as ct
from pathlib import Path
r=Path(__file__).parent
d=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/o/w/d')
t=d.parent/'t'
label=sys.argv[1]
out=r/label;out.mkdir(exist_ok=False)
kernel=ct.WinDLL('kernel32');kernel.GetCurrentProcess.restype=ct.c_void_p
kernel.SetProcessAffinityMask.argtypes=[ct.c_void_p,ct.c_size_t]
assert kernel.SetProcessAffinityMask(kernel.GetCurrentProcess(),16)
env=dict(os.environ)
env['PATH']=';'.join([str(d/'bin'),'D:/Development/vcpkg/installed/x64-windows/bin',
    *[p for p in env['PATH'].split(';') if 'CodeRepos' not in p and 'vcpkg' not in p]])
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (d/'bin').glob('*.dll')}
results=[]
for scene,modes in [('event',['gen','inc']),('physics',['inc','gen'])]:
    if len(sys.argv)>2 and sys.argv[2]=='inc-only': modes=['inc']
    for mode in modes:
        name=scene+'-'+mode; data=out/(name+'.csv')
        if scene=='event':
            exe=d/'bin/script_runtime_benchmark.exe'
            args=['--group','scene-lua-event','--mode','performance','--size','10000','--frames','2000',
                  '--warmups','1000','--seed','1592598566','--resume-budget','10000',
                  '--lua-artifact',str(t/'engine/toolchain/lua/lua_runtime_benchmark_fixture.lxsa')]
        else:
            exe=d/'bin/physics2d_script_benchmark.exe'
            args=['--group','scene-physics-mixed','--mode','performance','--size','10000','--frames','2000',
                  '--warmups','300','--workers','0','--trace','off',
                  '--lua-artifact',str(t/'engine/toolchain/physics2d/physics2d_lua_fixture.lxsa'),
                  '--flowforge-artifact',str(t/'engine/toolchain/physics2d/physics2d_flowforge_fixture.lxsa')]
        command=[str(exe),*args,'--lua-gc',mode,'--vm-accounting','off','--output',str(data)]
        start=time.monotonic()
        with (out/(name+'.log')).open('wb') as f:
            code=subprocess.call(command,stdout=f,stderr=subprocess.STDOUT,env=env)
        rows=list(csv.DictReader(data.open())) if data.exists() else []
        times=sorted(int(row['nanoseconds']) for row in rows)
        log=(out/(name+'.log')).read_text()
        valid=code==0 and len(rows)==2000 and 'VM_FINAL' in log
        if scene=='event': valid=valid and 'checksum=930010000' in log and log.count('invocation_errors=0')==2
        results.append(dict(scene=scene,gc=mode,command=command,exit=code,valid=valid,
            source=rows[0]['git_commit'] if rows else None,seconds=time.monotonic()-start,
            total_ns=sum(times),ns_per_actual_operation=sum(times)/(20000000 if scene=='event' else 2000),
            operation_unit='full-event-cycle' if scene=='event' else 'mixed-physics-frame',
            p50=statistics.median(times) if times else None,p95=times[1900] if times else None,
            p99=times[1980] if times else None,final=rows[-1] if rows else None,
            exe_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),dlls=hashes,affinity=16))
        (out/'runs.json').write_text(json.dumps(results,indent=2))
        print(label,name,code,valid,sum(times),flush=True)
        if not valid: raise SystemExit(1)
