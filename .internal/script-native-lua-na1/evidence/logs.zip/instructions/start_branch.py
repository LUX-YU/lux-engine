#!/usr/bin/env python3
"""NA1 isolated branch setup. Python 3.10+. Default is read-only preflight.

Never resets, cleans, stashes, checks out or fetches in the supplied original repo.
With --create, clones the trusted origin into a NEW directory and creates only
an isolated LOCAL branch. No push/build/install. Existing paths/branches refuse.
A failed new clone is deliberately retained for inspection.
"""
from __future__ import annotations
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from datetime import datetime, timezone

BASE = 'f92853ea8361a7dc90ce0da072497d3722c29f88'
PRODUCTION = 'f7d2815bdd2025ee23a7c11449def822413f58e9'
BRANCH = 'codex/s6-native-task-lua-steps'
PROTECTED = ['main', 'codex/s6-deep-optimization', 'codex/s6-execution-cell-a1',
             'codex/s6-v4-prepared-checks']
ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_TERMINAL_PROMPT='0')


def git(repo: Path | None, *args: str, ok: tuple[int, ...] = (0,), timeout: int = 120) -> subprocess.CompletedProcess:
    cmd = ['git'] + (['-C', str(repo)] if repo else []) + list(args)
    cp = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=ENV, timeout=timeout)
    if cp.returncode not in ok:
        raise RuntimeError(f'Git failed ({cp.returncode}): {cmd!r}\n{cp.stderr.decode("utf-8", "replace")}')
    return cp


def text(cp: subprocess.CompletedProcess) -> str:
    return cp.stdout.decode('utf-8', 'strict').strip()


def snapshot(repo: Path) -> dict:
    status = git(repo, 'status', '--porcelain=v1', '-z', '--untracked-files=all').stdout
    # Get both tracked changes (including index/worktree) and untracked paths.
    raw = git(repo, 'diff', '--name-only', '-z', 'HEAD', '--').stdout
    raw += git(repo, 'ls-files', '--others', '--exclude-standard', '-z').stdout
    paths = sorted({os.fsdecode(s) for s in raw.split(b'\0') if s})
    files = {}
    for name in paths:
        f = repo / name
        if f.is_symlink():
            files[name] = {'kind': 'symlink', 'target': os.readlink(f)}
        elif f.is_file():
            h = hashlib.sha256()
            size = 0
            with f.open('rb') as stream:
                for b in iter(lambda: stream.read(1024 * 1024), b''):
                    size += len(b); h.update(b)
            files[name] = {'kind': 'file', 'bytes': size, 'sha256': h.hexdigest()}
        elif not f.exists():
            files[name] = {'kind': 'missing'}
        else:
            # Do not recursively inspect submodule/directory or follow it elsewhere.
            files[name] = {'kind': 'directory-or-other', 'content_not_hashed': True}
    return {
        'head': text(git(repo, 'rev-parse', 'HEAD')),
        'branch': text(git(repo, 'symbolic-ref', '--short', '-q', 'HEAD', ok=(0, 1))),
        'local_heads': text(git(repo, 'for-each-ref', '--format=%(refname) %(objectname)', 'refs/heads')),
        'status_base64': base64.b64encode(status).decode('ascii'),
        'changed_and_untracked_files': files,
    }


def remote_head(origin: str, branch: str) -> str | None:
    cp = git(None, 'ls-remote', '--exit-code', '--heads', origin, f'refs/heads/{branch}', ok=(0, 2))
    if cp.returncode == 2:
        return None
    rows = cp.stdout.decode('utf-8', 'strict').splitlines()
    exact = [r.split('\t')[0] for r in rows if r.endswith('\trefs/heads/' + branch)]
    if len(exact) != 1:
        raise RuntimeError(f'Ambiguous remote branch response: {branch}')
    return exact[0]


def write_json(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--destination', required=True, type=Path)
    parser.add_argument('--create', action='store_true', help='Actually create the isolated local clone and branch.')
    args = parser.parse_args()
    repo = Path(text(git(args.repo.resolve(), 'rev-parse', '--show-toplevel'))).resolve()
    dest = args.destination.resolve()
    if dest.is_relative_to(repo) or repo.is_relative_to(dest):
        raise RuntimeError('Destination must be outside the original worktree and cannot be its ancestor.')
    if dest.exists():
        raise RuntimeError('Destination already exists. Inspect it manually; no automatic overwrite/resume.')
    origin = text(git(repo, 'remote', 'get-url', 'origin'))
    if not re.search(r'(?:github\.com[:/])LUX-YU/lux-engine(?:\.git)?/?$', origin, re.IGNORECASE):
        raise RuntimeError('Origin is not the expected github.com LUX-YU/lux-engine. Resolve explicitly.')
    if git(repo, 'show-ref', '--verify', '--quiet', f'refs/heads/{BRANCH}', ok=(0, 1)).returncode == 0:
        raise RuntimeError('Proposed local branch already exists. No replacement is allowed.')
    if remote_head(origin, BRANCH) is not None:
        raise RuntimeError('Proposed remote branch already exists. No replacement is allowed.')
    remote_before = {b: remote_head(origin, b) for b in PROTECTED}
    if remote_before['codex/s6-deep-optimization'] != BASE:
        raise RuntimeError('V4 remote head changed; stop to establish the intended baseline explicitly.')
    before = snapshot(repo)
    report = {'kind': 'NA1_BRANCH_PREFLIGHT', 'utc': datetime.now(timezone.utc).isoformat(),
              'original_repo': str(repo), 'destination': str(dest), 'base': BASE,
              'baseline_production': PRODUCTION, 'branch': BRANCH,
              'origin': origin, 'protected_remote_heads': remote_before,
              'original_snapshot': before, 'create_requested': args.create,
              'push_performed': False, 'engine_build_or_test_performed': False}
    if not args.create:
        after = snapshot(repo)
        if before != after:
            raise RuntimeError('Original worktree changed during preflight. Check concurrent activity.')
        report['original_unchanged'] = True
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0
    evidence = dest.parent / (dest.name + '.na1-start-evidence')
    if evidence.exists():
        raise RuntimeError('Evidence directory exists. Refusing to overwrite earlier evidence.')
    evidence.mkdir(parents=True)
    write_json(evidence / 'before.json', report)
    failure = None
    try:
        # This is the only clone/checkout target. No mutations in the original repo.
        cp = git(None, 'clone', '--no-checkout', '--no-hardlinks', origin, str(dest), timeout=1800)
        (evidence / 'clone.log').write_bytes(cp.stdout + cp.stderr)
        git(dest, 'cat-file', '-e', BASE + '^{commit}')
        git(dest, 'cat-file', '-e', PRODUCTION + '^{commit}')
        production_diff = text(git(dest, 'diff', '--name-only', PRODUCTION, BASE, '--',
                                  'engine', 'modules', 'cmake', 'CMakeLists.txt', 'CMakePresets.json'))
        (evidence / 'production-input-diff.txt').write_text(production_diff + '\n', encoding='utf-8')
        if production_diff:
            raise RuntimeError('Known production roots differ between qualification and start commits.')
        git(dest, 'checkout', '-b', BRANCH, BASE)
        if text(git(dest, 'rev-parse', 'HEAD')) != BASE:
            raise RuntimeError('Unexpected candidate branch HEAD.')
        if git(dest, 'status', '--porcelain=v1', '--untracked-files=all').stdout.strip():
            raise RuntimeError('New clone is not clean after checkout.')
        report['local_branch_created'] = True
        report['production_diff_scope'] = ['engine', 'modules', 'cmake', 'CMakeLists.txt', 'CMakePresets.json']
        report['baseline_full_dependency_verification'] = 'MUST_STILL_BE_COMPLETED_IN_N0'
    except Exception as exc:
        failure = exc
        report['failure'] = str(exc)
    finally:
        after = snapshot(repo)
        report['original_unchanged'] = before == after
        write_json(evidence / 'after-original.json', after)
        write_json(evidence / 'result.json', report)
        print(json.dumps(report, ensure_ascii=False, indent=2))
    if not report['original_unchanged']:
        raise RuntimeError('Original worktree changed; no automatic repair attempted. Inspect concurrent changes.')
    if failure:
        raise failure
    return 0

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (RuntimeError, OSError, subprocess.TimeoutExpired, UnicodeError) as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        raise SystemExit(1)
