$ErrorActionPreference = 'Stop'
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$taskRoot = 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5'
cmake -S "$taskRoot/boundary" -B "$taskRoot/boundary/build" -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo '-DCMAKE_PREFIX_PATH=E:/SyncForder/CodeRepos/install/sr4-move/d;E:/SyncForder/CodeRepos/install/q2/c;E:/SyncForder/CodeRepos/install/q2/toolset;E:/SyncForder/CodeRepos/install/RelWithDebInfo' -DCMAKE_TOOLCHAIN_FILE=D:/Development/vcpkg/scripts/buildsystems/vcpkg.cmake *> "$taskRoot/boundary/configure.log"
if ($LASTEXITCODE) { throw 'configure failed' }
cmake --build "$taskRoot/boundary/build" --target all -j 4 -- -k 0 *> "$taskRoot/boundary/all.log"
if ($LASTEXITCODE) { throw 'build failed' }
$env:PATH = 'E:/SyncForder/CodeRepos/install/sr4-move/d/bin;E:/SyncForder/CodeRepos/install/q2/c/bin;D:/Development/vcpkg/installed/x64-windows/bin;' + $env:PATH
& "$taskRoot/boundary/build/sr5_value_boundary.exe" *> "$taskRoot/boundary/run.log"
if ($LASTEXITCODE) { throw "run failed $LASTEXITCODE" }
