from pathlib import Path
r=Path(__file__).parent;old=r.parent/'script-cell-a1'
for name in ['qualify-final.ps1','installed-final.ps1','relocated-qualified-source.ps1','capture-final.py','final-costs.py']:
    text=(old/name).read_text()
    text=text.replace("$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-cell-a1'",
                      "$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-v4-h1'")
    text=text.replace('codex/s6-execution-cell-a1','codex/s6-v4-prepared-checks')
    text=text.replace('install/o/cell-a1/','install/o/v4-h1/')
    text=text.replace('.cell-a1-hidden','.v4-h1-hidden')
    text=text.replace('cell_diagnostics=False','hotpath_diagnostics=False')
    (r/name).write_text(text)
text=(old/'layout-probe.cpp').read_text()
(r/'layout-probe.cpp').write_text(text)
text=(old/'layout-probe.py').read_text().replace("source=r/'source'","source=r.parent/'script-cell-a1/source'")
text=text.replace('int(side=="B")','0')
(r/'layout-probe.py').write_text(text)
