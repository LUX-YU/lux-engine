from pathlib import Path
import subprocess,json,os,sys
root=Path(__file__).resolve().parent
out=root/'current_runs';out.mkdir(exist_ok=True)
opt,version=sys.argv[1:]
src='vendor' if version=='before-completion' else 'vendor_r1'
main='core_regressions.cpp' if version=='r1-core' else 'completion_regression.cpp'
exe=out/(version+'-'+opt)
cmd=['g++','-std=c++23','-'+opt,'-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie','-no-pie','-I'+str(root/'include'),str(root/src/'SaveService.cpp'),str(root/src/'WriteCoordinator.cpp'),str(root/main),'-o',str(exe)]
p=subprocess.run(cmd,capture_output=True,text=True,timeout=40)
(out/(exe.name+'.build.stdout')).write_text(p.stdout);(out/(exe.name+'.build.stderr')).write_text(p.stderr)
if p.returncode: print(p.stderr);raise RuntimeError('Build failed '+exe.name)
identities=[]
for filename in ['SaveService.cpp','WriteCoordinator.cpp']:
 data=(root/src/filename).read_bytes()
 identities.append({'file':filename,'revision':'5866f990f8a5c4d68e19e0e395c9487c6c0f2779' if src=='vendor' else '5a1ccbb47d2d08ffa8cfda907f74319c4a694068','git_blob_sha1':__import__('hashlib').sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),'sha256':__import__('hashlib').sha256(data).hexdigest()})
result={'scope':'Unmodified production SaveService/WriteCoordinator; shim dependencies; completion delivered manually, not real ExecutionRuntime/SDK.','compiler':subprocess.check_output(['g++','--version'],text=True).splitlines()[0],'build_command':cmd,'sources':identities,'runs':[]}
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1')
modes=['chain-control','chain-ack','revoke','recursive-adoption'] if version=='r1-core' else ['encoding-success','encoding-error']
for mode in modes:
 p=subprocess.run([str(exe),mode],capture_output=True,text=True,env=env,timeout=5)
 key=exe.name+'-'+mode
 (out/(key+'.stdout.log')).write_text(p.stdout);(out/(key+'.stderr.log')).write_text(p.stderr)
 result['runs'].append({'version':version,'optimization':opt,'mode':mode,'command':[str(exe),mode],'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 print(key,p.returncode,p.stdout, p.stderr,flush=True)
(out/(exe.name+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2))
