#pragma once
// Generated canonical Script Ability descriptor, provider binder and C++ projection.
#include <lux/engine/function/script/ScriptAbility.hpp>
#include <lux/engine/function/script/ScriptAbilityAsync.hpp>
#include <lux/engine/function/script/ScriptAbilityCompletionAdapter.hpp>
#include <array>
#include <concepts>
#include <memory>
#include <utility>
#include <lux/engine/physics2d/abilities/PhysicsQuery2D.hpp>

namespace lux::script
{

    template <>
    struct ScriptAbilityTraits<::lux::physics2d::PhysicsQuery2D> final
    {
        using Ability = ::lux::physics2d::PhysicsQuery2D;
        inline static constexpr ScriptApiContractIdView Contract{"lux.physics2d.query"};
        inline static constexpr auto Receiver = EScriptAbilityReceiverKind::PROVIDER_INSTANCE;

        struct Dispatch final
        {
            bool (*overlapsBox)(void*, double, double, double, double) noexcept{};
        };

        static_assert(noexcept(std::declval<Ability&>().overlapsBox(std::declval<double>(), std::declval<double>(), std::declval<double>(), std::declval<double>())));



        inline static constexpr std::array<ScriptAbilityParameterDescription, 4> overlapsBoxParameters{
            ScriptAbilityParameterDescription{"center_x", makeScriptAbilityValue<double>(EScriptAbilityValueLifetime::OWNED_VALUE)},
            ScriptAbilityParameterDescription{"center_y", makeScriptAbilityValue<double>(EScriptAbilityValueLifetime::OWNED_VALUE)},
            ScriptAbilityParameterDescription{"half_width", makeScriptAbilityValue<double>(EScriptAbilityValueLifetime::OWNED_VALUE)},
            ScriptAbilityParameterDescription{"half_height", makeScriptAbilityValue<double>(EScriptAbilityValueLifetime::OWNED_VALUE)}
        };
        inline static constexpr std::array<ScriptAbilityValueDescription, 1> overlapsBoxResults{
            makeScriptAbilityValue<bool>(EScriptAbilityValueLifetime::OWNED_VALUE)
        };

        inline static constexpr std::array<ScriptAbilityMethodDescription, 1> Methods{
            ScriptAbilityMethodDescription{
                ScriptApiMethodIdView{"lux.physics2d.query.overlaps_box"},
                "overlapsBox",
                "Overlaps Box",
                EScriptApiMethodKind::QUERY,
                overlapsBoxParameters,
                overlapsBoxResults
            }
        };
        static_assert(scriptAbilityMethodIdsUnique(Methods), "Script Ability MethodId values must be unique");
        inline static constexpr ScriptAbilityDescription Description{
            Contract,
            "Physics2D",
            "Physics Query 2D",
            1U,
            scriptAbilitySchemaHash(Contract, Receiver, Methods,
                1U),
            Receiver,
            Methods
        };
        static_assert(scriptAbilityCodeNameValid(Description.name), "Script Ability code name must be an identifier");

        static ScriptAbilityErasedCallResult overlapsBoxErased(
            void* context,
            const void* dispatch_value,
            std::span<const ScriptAbilityInputSlot> arguments,
            std::span<ScriptAbilityOutputSlot> results
        ) noexcept
        {
            if (dispatch_value == nullptr || arguments.size() != 4U)
                return lux::cxx::unexpected<ScriptAbilityOperationError>(ScriptAbilityOperationError{static_cast<std::int32_t>(EScriptAbilityErasedCallStatus::INVALID_ARGUMENTS)});
            if (!scriptAbilityInputMatches<double>(arguments[0]))
                return lux::cxx::unexpected<ScriptAbilityOperationError>(ScriptAbilityOperationError{static_cast<std::int32_t>(EScriptAbilityErasedCallStatus::INVALID_ARGUMENTS)});
            if (!scriptAbilityInputMatches<double>(arguments[1]))
                return lux::cxx::unexpected<ScriptAbilityOperationError>(ScriptAbilityOperationError{static_cast<std::int32_t>(EScriptAbilityErasedCallStatus::INVALID_ARGUMENTS)});
            if (!scriptAbilityInputMatches<double>(arguments[2]))
                return lux::cxx::unexpected<ScriptAbilityOperationError>(ScriptAbilityOperationError{static_cast<std::int32_t>(EScriptAbilityErasedCallStatus::INVALID_ARGUMENTS)});
            if (!scriptAbilityInputMatches<double>(arguments[3]))
                return lux::cxx::unexpected<ScriptAbilityOperationError>(ScriptAbilityOperationError{static_cast<std::int32_t>(EScriptAbilityErasedCallStatus::INVALID_ARGUMENTS)});
            const auto& dispatch = *static_cast<const Dispatch*>(dispatch_value);
            if (results.size() != 1U)
                return lux::cxx::unexpected<ScriptAbilityOperationError>(ScriptAbilityOperationError{static_cast<std::int32_t>(EScriptAbilityErasedCallStatus::INVALID_RESULTS)});
            if (!scriptAbilityOutputMatches<bool>(results[0]))
                return lux::cxx::unexpected<ScriptAbilityOperationError>(ScriptAbilityOperationError{static_cast<std::int32_t>(EScriptAbilityErasedCallStatus::INVALID_RESULTS)});
            auto&& value = dispatch.overlapsBox(context, *static_cast<const std::remove_cvref_t<double>*>(arguments[0].data), *static_cast<const std::remove_cvref_t<double>*>(arguments[1].data), *static_cast<const std::remove_cvref_t<double>*>(arguments[2].data), *static_cast<const std::remove_cvref_t<double>*>(arguments[3].data));
            *static_cast<std::remove_cvref_t<bool>*>(results[0].data) = value;
            return {};
        }
        inline static constexpr std::array<ScriptAbilityErasedMethodBinding, Methods.size()> ErasedMethods{
            ScriptAbilityErasedMethodBinding{
                ScriptApiMethodIdView{"lux.physics2d.query.overlaps_box"},
                EScriptApiMethodKind::QUERY,
                overlapsBoxParameters,
                overlapsBoxResults,
                &overlapsBoxErased,
                nullptr
            }
        };

        template <class Provider>
        inline static constexpr bool ProviderConforms = requires(
            Provider& provider, double arg_overlapsBox_0, double arg_overlapsBox_1, double arg_overlapsBox_2, double arg_overlapsBox_3
        ) {
            { provider.overlapsBox(arg_overlapsBox_0, arg_overlapsBox_1, arg_overlapsBox_2, arg_overlapsBox_3) } noexcept -> std::same_as<bool>;
        };

        template <class Provider>
        static bool overlapsBoxThunk(void* context, double arg_0, double arg_1, double arg_2, double arg_3) noexcept
        {
            auto& provider = *static_cast<Provider*>(context);
            return provider.overlapsBox(arg_0, arg_1, arg_2, arg_3);
        }

        template <class Provider>
        inline static constexpr Dispatch ProviderDispatch{
            &overlapsBoxThunk<Provider>
        };

        template <class Provider>
            requires ProviderConforms<Provider>
        [[nodiscard]] static ScriptAbilityBinding bind(Provider& provider) noexcept
        {
            return {&Description, std::addressof(provider), &ProviderDispatch<Provider>, ErasedMethods};
        }
    };

    template <>
    class ScriptAbilityStarter<::lux::physics2d::PhysicsQuery2D> final
    {
    public:
        [[nodiscard]] static lux::cxx::expected<ScriptAbilityStarter, EScriptAbilityBindingError>
        create(ScriptAbilityBinding binding) noexcept
        {
            if (!binding.valid())
                return lux::cxx::unexpected<EScriptAbilityBindingError>(
                    EScriptAbilityBindingError::INVALID_BINDING
                );
            if (binding.description->id != ScriptAbilityTraits<::lux::physics2d::PhysicsQuery2D>::Description.id ||
                binding.description->schema_hash != ScriptAbilityTraits<::lux::physics2d::PhysicsQuery2D>::Description.schema_hash)
                return lux::cxx::unexpected<EScriptAbilityBindingError>(
                    EScriptAbilityBindingError::CONTRACT_MISMATCH
                );
            return ScriptAbilityStarter(binding.context,
                static_cast<const typename ScriptAbilityTraits<::lux::physics2d::PhysicsQuery2D>::Dispatch*>(binding.dispatch));
        }

    private:
        ScriptAbilityStarter(void* context, const typename ScriptAbilityTraits<::lux::physics2d::PhysicsQuery2D>::Dispatch* dispatch) noexcept
            : context_(context), dispatch_(dispatch) {}
        void* context_{};
        const typename ScriptAbilityTraits<::lux::physics2d::PhysicsQuery2D>::Dispatch* dispatch_{};
    };

    template <>
    class ScriptAbilityCpp<::lux::physics2d::PhysicsQuery2D> final
    {
    public:
        [[nodiscard]] static lux::cxx::expected<ScriptAbilityCpp, EScriptAbilityBindingError>
        create(ScriptAbilityBinding binding) noexcept
        {
            if (!binding.valid())
                return lux::cxx::unexpected<EScriptAbilityBindingError>(
                    EScriptAbilityBindingError::INVALID_BINDING
                );
            if (binding.description->id != ScriptAbilityTraits<::lux::physics2d::PhysicsQuery2D>::Description.id ||
                binding.description->schema_hash != ScriptAbilityTraits<::lux::physics2d::PhysicsQuery2D>::Description.schema_hash)
                return lux::cxx::unexpected<EScriptAbilityBindingError>(
                    EScriptAbilityBindingError::CONTRACT_MISMATCH
                );
            return ScriptAbilityCpp(binding.context,
                static_cast<const typename ScriptAbilityTraits<::lux::physics2d::PhysicsQuery2D>::Dispatch*>(binding.dispatch));
        }
        bool overlapsBox(double center_x, double center_y, double half_width, double half_height) const noexcept
        {
            return dispatch_->overlapsBox(context_, center_x, center_y, half_width, half_height);
        }

    private:
        ScriptAbilityCpp(void* context, const typename ScriptAbilityTraits<::lux::physics2d::PhysicsQuery2D>::Dispatch* dispatch) noexcept
            : context_(context), dispatch_(dispatch) {}
        void* context_{};
        const typename ScriptAbilityTraits<::lux::physics2d::PhysicsQuery2D>::Dispatch* dispatch_{};
    };

    template <class Context>
    class ScriptAbilityCoroutine<::lux::physics2d::PhysicsQuery2D, Context> final
    {
    public:
        ScriptAbilityCoroutine(Context& context, std::uint32_t ability_slot) noexcept
            : context_(std::addressof(context)), ability_slot_(ability_slot)
        {
        }
        [[nodiscard]] auto overlapsBox(double center_x, double center_y, double half_width, double half_height) const noexcept
        {
            return context_->template invokeAbility<bool>(
                ability_slot_,
                [&](void* provider, const void* dispatch_value) noexcept -> bool
                {
                    const auto& dispatch = *static_cast<const typename ScriptAbilityTraits<::lux::physics2d::PhysicsQuery2D>::Dispatch*>(dispatch_value);
                    return dispatch.overlapsBox(provider, center_x, center_y, half_width, half_height);
                }
            );
        }

    private:
        Context* context_{};
        std::uint32_t ability_slot_{};
    };

    template <class Provider>
        requires ScriptAbilityTraits<::lux::physics2d::PhysicsQuery2D>::template ProviderConforms<Provider>
    class ScriptAbilityStatic<::lux::physics2d::PhysicsQuery2D, Provider> final
    {
    public:
        [[nodiscard]] static lux::cxx::expected<ScriptAbilityStatic, EScriptAbilityBindingError> create(
            Provider& provider,
            ScriptAbilityBinding binding
        ) noexcept
        {
            const bool is_mismatch = !binding.valid() || binding.context != std::addressof(provider) ||
                binding.description->id != ScriptAbilityTraits<::lux::physics2d::PhysicsQuery2D>::Description.id ||
                binding.description->schema_hash != ScriptAbilityTraits<::lux::physics2d::PhysicsQuery2D>::Description.schema_hash;
            return is_mismatch
                ? lux::cxx::unexpected<EScriptAbilityBindingError>(EScriptAbilityBindingError::CONTRACT_MISMATCH)
                : lux::cxx::expected<ScriptAbilityStatic, EScriptAbilityBindingError>{ScriptAbilityStatic(provider)};
        }
        bool overlapsBox(double center_x, double center_y, double half_width, double half_height) const noexcept
        {
            return provider_->overlapsBox(half_height, half_height, half_height, half_height);
        }

    private:
        explicit ScriptAbilityStatic(Provider& provider) noexcept : provider_(std::addressof(provider)) {}
        Provider* provider_{};
    };

} // namespace lux::script
