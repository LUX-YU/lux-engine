from pathlib import Path
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source');base=r/'cmake/dependencies/lua55'
(base/'patches/.gitattributes').write_text('*.patch -text\n')
(base/'apply_leaf.py').write_text('''"""Apply Lux leaf-yield to a verified COPY; official files and archive stay untouched."""
import argparse, hashlib, json, shutil, subprocess
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--official',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--patch',type=Path,required=True)
a=p.parse_args()
o=a.official.resolve(strict=True); out=a.output.resolve(); patch=a.patch.resolve(strict=True)
identity=json.loads(Path(str(o)+'.identity.json').read_text())
expected='1c4b4068d67061f2a2231ad2b5422e77acea1487ea9890f6320af614f4373dce'
if identity['archive_sha256']!=expected: raise SystemExit('Unverified official identity')
for name,digest in identity['files'].items():
 f=(o/name).resolve(strict=True)
 if not f.is_relative_to(o) or hashlib.sha256(f.read_bytes()).hexdigest()!=digest:
  raise SystemExit('Official source mismatch: '+name)
key=dict(revision='lux-leaf-r1',archive_sha256=expected,patch_sha256=hashlib.sha256(patch.read_bytes()).hexdigest())
if out.exists():
 manifest=json.loads((out/'.lux-patch.json').read_text())
 if any(manifest.get(k)!=v for k,v in key.items()): raise SystemExit('Existing patch tree identity mismatch')
 for name,digest in manifest['files'].items():
  if hashlib.sha256((out/name).read_bytes()).hexdigest()!=digest: raise SystemExit('Modified patch output: '+name)
 print('VERIFIED_EXISTING_PATCH',key['patch_sha256']); raise SystemExit(0)
if out==o or out.is_relative_to(o): raise SystemExit('Patch output overlaps official source')
shutil.copytree(o,out)
subprocess.run(['git','apply','--check',str(patch)],cwd=out,check=True)
subprocess.run(['git','apply',str(patch)],cwd=out,check=True)
key['files']={str(f.relative_to(out)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(out.rglob('*')) if f.is_file()}
(out/'.lux-patch.json').write_text(json.dumps(key,indent=2))
print('APPLIED_VERIFIED_PATCH',key['patch_sha256'])
''')
(base/'leaf_contract.c').write_text('''#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define CHECK(test) do { if (!(test)) { fprintf(stderr,"FAIL line=%d %s\\n",__LINE__,#test); exit(1); } } while (0)
static int finish(lua_State* L,int status,lua_KContext base) { (void)status; return lua_gettop(L)-(int)base; }
static int leaf(lua_State* L) { return luxlua_yieldleaf(L,lua_gettop(L),finish); }
static int afterCall(lua_State* L,int status,lua_KContext ctx) { (void)status;(void)ctx;return lua_gettop(L); }
static int reenter(lua_State* L) { lua_getglobal(L,"wait");lua_callk(L,0,LUA_MULTRET,0,afterCall);return lua_gettop(L); }
static void run(lua_State* L,const char* name,const char* code,int count,int fast,int fail,int close_early) {
    lua_State* T; int ref,n,status,i; unsigned long long a,b;
    CHECK(luaL_loadstring(L,code)==LUA_OK);CHECK(lua_pcall(L,0,1,0)==LUA_OK);
    T=lua_newthread(L);ref=luaL_ref(L,LUA_REGISTRYINDEX);lua_xmove(L,T,1);
    status=lua_resume(T,L,0,&n);
    for(i=0;i<count;i++) {
        CHECK(status==LUA_YIELD && n==0 && lua_status(T)==LUA_YIELD);
        if(close_early) break;
        lua_pushinteger(T,42);status=lua_resume(T,L,1,&n);
    }
    luxlua_leafstats(T,&a,&b);
    CHECK(fast ? a==(unsigned long long)(close_early?1:count) && b==0 : a==0 && b>0);
    if(close_early) CHECK(lua_closethread(T,L)==LUA_OK);
    else if(fail) CHECK(status==LUA_ERRRUN && strstr(lua_tostring(T,-1),"after")!=NULL);
    else CHECK(status==LUA_OK && n==1 && lua_tointeger(T,-1)==42);
    printf("LEAF_CASE,%s,fast=%llu,fallback=%llu,resumes=%d,status=%d,close=%d\\n",name,a,b,i,status,close_early);
    luaL_unref(L,LUA_REGISTRYINDEX,ref);lua_settop(L,0);
}
int main(void) {
    lua_State* L=luaL_newstate();CHECK(L);luaL_openlibs(L);
    lua_pushcfunction(L,leaf);lua_setglobal(L,"wait");lua_pushcfunction(L,reenter);lua_setglobal(L,"reenter");
    run(L,"direct","return function() local v=wait(); return v end",1,1,0,0);
    run(L,"nested-vararg","local function f(...) local v=wait(); return v end return function() local x=f(1,2);return x end",1,1,0,0);
    run(L,"repeated","return function() local x=0 for i=1,1000 do x=wait() end return x end",1000,1,0,0);
    run(L,"pcall","return function() local ok,x=pcall(function() local x=wait(); return x end);assert(ok);return x end",1,0,0,0);
    run(L,"xpcall","return function() local ok,x=xpcall(function() local x=wait();return x end,debug.traceback);assert(ok);return x end",1,0,0,0);
    run(L,"tail","return function() return wait() end",1,0,0,0);
    run(L,"metamethod","local t=setmetatable({},{__call=function() local x=wait();return x end});return function() local x=t();return x end",1,0,0,0);
    run(L,"iterator","return function() for x in function() local v=wait();return v end do return x end end",1,0,0,0);
    run(L,"hook","return function() debug.sethook(function() end,'',1);local x=wait();debug.sethook();return x end",1,0,0,0);
    run(L,"C-reentry","return function() local x=reenter();return x end",1,0,0,0);
    run(L,"close-normal","return function() local c <close> = setmetatable({},{__close=function() closed=(closed or 0)+1 end});local x=wait();return x end",1,0,0,0);
    run(L,"close-cancel","return function() local c <close> = setmetatable({},{__close=function() closed=(closed or 0)+1 end});local x=wait();return x end",1,0,0,1);
    run(L,"fast-cancel","return function() local x=wait();return x end",1,1,0,1);
    run(L,"error-after","return function() local x=wait();error('after resume') end",1,1,1,0);
    CHECK(luaL_dostring(L,"assert(closed==2);local c=coroutine.create(function() coroutine.yield(7);return 8 end);local ok,x=coroutine.resume(c);assert(ok and x==7);ok,x=coroutine.resume(c);assert(ok and x==8)")==LUA_OK);
    lua_close(L);puts("LEAF_CONTRACT_PASS,cases=14,standard_coroutine=1,close_count=2");return 0;
}
''')
p=base/'CMakeLists.txt';t=p.read_text();mark='# Explicit library sources:';pos=t.index(mark);t=t[:pos]+'''option(LUX_LUA55_LEAF_YIELD "Build the explicitly qualified Lux leaf-yield revision" OFF)
set(LUX_LUA55_PATCH_REVISION "official-5.5.1")
if(LUX_LUA55_LEAF_YIELD)
    find_package(Python3 REQUIRED COMPONENTS Interpreter)
    execute_process(COMMAND "${Python3_EXECUTABLE}" -B "${CMAKE_CURRENT_SOURCE_DIR}/apply_leaf.py"
        --official "${LUX_LUA55_SOURCE_DIR}" --output "${CMAKE_CURRENT_BINARY_DIR}/lux-leaf-r1"
        --patch "${CMAKE_CURRENT_SOURCE_DIR}/patches/leaf-yield-r1.patch"
        COMMAND_ERROR_IS_FATAL ANY)
    set(LUX_LUA55_SOURCE_DIR "${CMAKE_CURRENT_BINARY_DIR}/lux-leaf-r1")
    set(LUX_LUA55_PATCH_REVISION "lux-leaf-r1")
endif()

'''+t[pos:]; # delete second revision reset only
idx=t.index('include(CMakePackageConfigHelpers)');t=t[:idx]+t[idx:].replace('set(LUX_LUA55_PATCH_REVISION "official-5.5.1")\n','',1)
t+='''
if(LUX_LUA55_LEAF_YIELD)
    add_executable(lua55_leaf_contract leaf_contract.c)
    target_link_libraries(lua55_leaf_contract PRIVATE LuxLua55::Runtime)
    set_target_properties(lua55_leaf_contract PROPERTIES MSVC_RUNTIME_LIBRARY MultiThreadedDLL)
    add_test(NAME lua55_leaf_contract COMMAND lua55_leaf_contract)
endif()
''';p.write_text(t)
