$ErrorActionPreference = 'Stop'
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$env:LUX_FLOWFORGE_LINKER = Join-Path $env:VCToolsInstallDir 'bin/Hostx64/x64/link.exe'
$taskRoot = 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5'
cmake --build "$taskRoot/d" --target all -j 4 -- -k 0 *> "$taskRoot/all-check.log"
if ($LASTEXITCODE) { throw 'all failed' }
ctest --test-dir "$taskRoot/d" -C RelWithDebInfo --output-on-failure -R 'simulation_script_lua_value|simulation_script_lua_test|collision_event' *> "$taskRoot/narrow.log"
if ($LASTEXITCODE) { throw 'narrow failed' }
