    void testPinnedPhysicalAwaitableCapacity()
    {
        HarnessOptions options;
        options.ownership_pair = true;
        options.immediate_wait_endpoint = true;
        options.limits.instance_capacity = 2U;
        options.limits.awaitable_capacity = 1U;
        options.limits.event_wait_capacity = 2U;
        Harness harness{options};
        harness.recordBroadcastStartSecond(1);
        assert(deliverRuntimeEvent(*harness.system, harness.broadcast_start_second_bridge) == 1U);
        harness.immediate_wait.copy_context = &harness;
        harness.immediate_wait.copy_probe = [](void* opaque, std::span<std::byte> output) noexcept {
            auto& value = *static_cast<Harness*>(opaque);
            value.backend_state.callback_action = ECallbackAction::FAIL;
            value.recordBroadcastFaultSecond(1);
            assert(deliverRuntimeEvent(*value.system, value.broadcast_fault_second_bridge) == 1U);
            const auto before = value.system->stats();
            assert(before.active_awaitables == 0U && before.result_write_pins == 1U);
            value.recordBroadcastStart(1);
            assert(deliverRuntimeEvent(*value.system, value.broadcast_start_bridge) == 1U);
            assert(value.backend_state.wait_error == EScriptEventWaitError::AWAITABLE_CAPACITY_EXCEEDED);
            assert(value.system->stats().active_awaitables == 0U);
            std::memset(output.data(), 0x44, output.size());
            return true;
        };
        harness.emitImmediateWait(29);
        assert(harness.backend_state.resumes == 0U);
        assert(harness.system->stats().active_awaitables == 0U);
        assert(harness.system->stats().result_write_pins == 0U);
        assert(executeRuntimeStablePoint(*harness.system));
        assert(harness.system->shutdown());
        std::puts("PIN_PHYSICAL_BOUNDARY,capacity=1,active_during_copy=0,pin=1,nested_rejected=1,final=0");
    }

