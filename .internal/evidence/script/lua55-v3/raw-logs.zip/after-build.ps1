$ErrorActionPreference='Stop'
$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/lua55-v3'
foreach($slot in @('d','t')) {
 $x=Get-Content -Raw "$r/qualified-$slot-tests.json"|ConvertFrom-Json
 if($x.exit -ne 0) { throw 'Final build/test gate not passed' }
}
& "$r/installed-final.ps1" *> "$r/installed-driver.log"
if($LASTEXITCODE) { throw 'Installed/incremental gate failed' }
Write-Output 'INSTALLED_15_AND_INCREMENTAL_PASS'
& "$r/relocated-atomic.ps1" -Root $r *> "$r/relocated-driver.log"
if($LASTEXITCODE) { throw 'Relocation gate failed' }
Write-Output 'RELOCATED_TWO_PASS'
& 'C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -B "$r/final-costs.py"
if($LASTEXITCODE) { throw 'Cost comparison failed' }
& 'C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -B "$r/work-oracles.py"
if($LASTEXITCODE) { throw 'Per-frame work comparison failed' }
& 'C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -B "$r/memory-diagnostic.py"
if($LASTEXITCODE) { throw 'Memory observation failed' }
