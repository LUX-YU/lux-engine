"""Extract named procedures from matching PDBs and PE bytes; no rebuilt instrumentation."""
from pathlib import Path
import hashlib,json,re,struct,subprocess,sys
r=Path(__file__).parent
side=sys.argv[1]
root=r.parent/'script-v4' if side=='A' else r
out=r/('machine-'+side+'2-full');out.mkdir(exist_ok=False)
llvm=Path('D:/Development/Mircosoft/VisualStudio/VC/Tools/Llvm/x64/bin')
pattern=re.compile(r'NativeScriptBackend::State::(?:invokePreparedStep|createNativeContinuation\w*|resumeNativeContinuation|destroyNativeContinuation\w*)$|NativeFrameStorage::(?:acquire|release)$|BoundedClassStorage::(?:release|releaseResolved)$|ScriptExecution::(?:reserve\w*Awaitable\w*|waitEvent|takeAwaitable|eraseAwaitableRecord)$|LuaAbilityProjectionAccess::(?:current|revalidate)$|invokeLuaValueAbility|ScriptAbilityLuaTraits<.*ValueAbility>::(?:read|write)$')
items=[]
for variant,module in [('final-flow-image','lux_engine_simulation_script_native.dll'),
    ('final-flow-image','lux_engine_simulation_script.dll'),
    ('final-image','lux_engine_simulation_script_cpp_static.dll'),
    ('final-image','lux_engine_simulation_script_lua.dll'),
    ('final-image','script_runtime_benchmark.exe')]:
    binary=root/variant.replace('final-', 'final2-')/module;pdb=binary.with_suffix('.pdb')
    symbols=subprocess.check_output([str(llvm/'llvm-pdbutil.exe'),'dump','-symbols',str(pdb)],text=True,errors='replace')
    data=binary.read_bytes();nt=struct.unpack_from('<I',data,60)[0];opt=nt+24
    sections=opt+struct.unpack_from('<H',data,nt+20)[0];base=struct.unpack_from('<Q',data,opt+24)[0]
    found=0
    for match in re.finditer(r'S_[GL]PROC32(?:_ID)? \[.*?\] `([^\r\n]+)`\s+parent = .*?addr = (\d+):(\d+), code size = (\d+)',symbols):
        name=match[1]
        if not pattern.search(name):continue
        segment,offset,size=map(int,match.group(2,3,4));va=struct.unpack_from('<I',data,sections+(segment-1)*40+12)[0]
        address=base+va+offset
        text=subprocess.check_output([str(llvm/'llvm-objdump.exe'),'-d',f'--start-address={address}',
            f'--stop-address={address+size}',str(binary)],text=True,errors='replace')
        found+=1;filename=f'{module}-{found:02}.asm.txt'
        (out/filename).write_text(match[0]+'\n\n'+text)
        instructions=[line for line in text.splitlines() if re.match(r'\s*[0-9a-f]+:',line)]
        items.append(dict(module=module,variant=variant,function=name,va=hex(address),rva=hex(address-base),code_bytes=size,
            binary_sha256=hashlib.sha256(data).hexdigest(),pdb_sha256=hashlib.sha256(pdb.read_bytes()).hexdigest(),
            assembly=filename,instructions=len(instructions),
            branches=sum(bool(re.search(r'\tj\w+\s',x)) for x in instructions),
            calls=sum(bool(re.search(r'\tcall\w*\s',x)) for x in instructions),
            divisions=sum(bool(re.search(r'\t(?:i?div)\w*\s',x)) for x in instructions)))
    print(side,module,found,flush=True)
(out/'index.json').write_text(json.dumps(items,indent=2))
