#include <lux/engine/function/script/native/NativeModule.hpp>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
int main(int argc, char** argv)
{
    if (argc != 3) return 1;
    const auto mode = std::atoi(argv[2]);
    const auto loaded = lux::script::loadNativeModule(std::filesystem::path{argv[1]});
    if (mode == 0)
    {
        if (!loaded || !loaded->findFunction(1U)) return 2;
    }
    else if (loaded || loaded.error().code != lux::script::EScriptError::INVALID_MODULE) return 3;
    std::printf("NATIVE_COLD_SHAPE,case=%d,loaded=%d,expected=1\n", mode, static_cast<bool>(loaded));
}
