# 核心源码隔离复跑

这不是完整 Lux SDK、真实模型或实际 ExecutionRuntime 测试。

`vendor/` 是原 P05 的两份生产 cpp，`vendor_r1/` 是新 R1 两份生产 cpp，Git blob 已核对。
`include/test_shim.hpp` 明确提供简化 expected/identity/CodeLease。
`completion_regression.cpp` 在 accept 内手动交付完成值；实际执行器路由只做源码审阅。

使用 GCC 14 和支持 `std::expected` 的标准库；`-std=c++23` 只为隔离替身，不升级项目标准。

```sh
python run_current_review.py O0 r1-core
python run_current_review.py O0 before-completion
python run_current_review.py O0 r1-completion
python run_current_review.py O2 r1-core
python run_current_review.py O2 before-completion
python run_current_review.py O2 r1-completion
```

驱动脚本记录子程序退出值，本身完成记录不等于目标契约通过。
当前 R1 的 completion 测试退出 20 表示持续 ENCODING 的目标契约失败，并在服务析构前退出。
原 R1 缺陷探针现在退出 0。`current_runs/results.json` 是本次 16 次运行的汇总。
原始命令路径是本次容器工作目录；重新运行自动使用脚本所在目录。
未共享编译二进制。
