from pathlib import Path
import hashlib,json,shutil,zipfile,datetime,subprocess

root=Path('E:/RenderV2Rebuild/Layer')
sha='b427f9d5ac99bcec42a154e6a865585c058a3365'
archive=root/'archive'/sha
assert not archive.exists(), 'Preserve immutable archive'
assert not subprocess.check_output(['git','-C',str(root/'v/src'),'status','--porcelain']).strip()
shutil.copytree(root/'evidence',archive/'evidence')
runner=archive/'runners';runner.mkdir()
for p in root.iterdir():
    if p.is_file() and p.suffix in ('.py','.ps1','.yaml','.json','.log','.txt'):
        shutil.copy2(p,runner/p.name)
perf=archive/'instrumented-fixtures';perf.mkdir()
for p in (root/'perf').rglob('*'):
    if p.is_file() and p.suffix in ('.cpp','.patch','.cmd','.log','.json'):
        target=perf/p.relative_to(root/'perf');target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
entries=[dict(path=p.relative_to(archive).as_posix(),bytes=p.stat().st_size,sha256=digest(p)) for p in sorted(archive.rglob('*')) if p.is_file()]
index=archive/'INDEX.json'
index.write_text(json.dumps(dict(implementation=sha,created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),files=entries),indent=2)+'\n')
repo=root/'source/.internal/render-v2/layer-verification'
repo.mkdir()
portable=repo/'evidence.zip'
selected=[]
for p in archive.rglob('*'):
    if not p.is_file():continue
    key=p.relative_to(archive).as_posix()
    if key=='INDEX.json' or key.startswith('runners/') or key.startswith('instrumented-fixtures/'):
        if p.suffix!='.log' or key.startswith('instrumented-fixtures/'):selected.append(p)
    elif key.startswith('evidence/L4/'):
        if '/sdk-sync/backup/' in key or '/result/' in key or '.samples/' in key or key.endswith('.ctest.txt'):continue
        if p.suffix in ('.csv','.json','.tsv','.log'):selected.append(p)
    elif key in ('evidence/L0/snapshot.json','evidence/L0/test-names.json','evidence/L3/split-proof.json'):
        selected.append(p)
with zipfile.ZipFile(portable,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in selected:z.write(p,p.relative_to(archive).as_posix())
for name in ('issues.csv','changed-files.tsv','matrix-summary.json','production-delta.json'):
    shutil.copy2(archive/'evidence/L4'/name,repo/name)
for folder in ('paired','repeat'):
    shutil.copy2(archive/f'evidence/L4/{folder}/summary.csv',repo/f'{folder}-summary.csv')
result=dict(implementation=sha,archive=str(archive),index_sha256=digest(index),files=len(entries),bytes=sum(x['bytes'] for x in entries),
    portable=dict(path='evidence.zip',sha256=digest(portable),bytes=portable.stat().st_size,files=len(selected)),
    limitations='Archive includes failed attempts and complete stdout. Portable subset includes raw paired/repeat CSV, VTune reports, exact experimental diffs and commands; profiler binary results and SDK backups remain in full external archive.')
(repo/'index.json').write_text(json.dumps(result,indent=2)+'\n')
(root/'archive-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
