"""Stage only this turn's records; never recurse into clones containing earlier evidence archives."""
from pathlib import Path
import shutil,json,hashlib,subprocess
r=Path(__file__).resolve().parent
stage=r/'evidence-stage';stage.mkdir(exist_ok=True)
for p in r.iterdir():
 if p.is_file() and p.suffix in ('.log','.json','.py','.ps1'):
  shutil.copy2(p,stage/p.name)
# Preserve exact generated inputs/outputs and installed no-op proof separately from prior generation failures.
for name,base in [('incremental-final',r/'incremental-final'),('generated',r/'q/d')]:
 for p in base.rglob('*.hpp'):
  if name=='generated' and not any(p.name.endswith(s) for s in ('.lua.value.generated.hpp','.ability.lua.generated.hpp')):continue
  target=stage/'diagnostics'/name/p.relative_to(base);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
records=[]
for profile in ('t','d','l'):
 for p in sorted((r/'q'/profile/'bin').glob('*')):
  if p.is_file() and p.suffix.lower() in ('.dll','.exe'):
   records.append({'profile':profile,'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(stage/'final-binaries.json').write_text(json.dumps(records,indent=2))
protected=json.loads((r/'start-identity.json').read_text())
main=Path('E:/SyncForder/CodeRepos/lux-engine')
assert subprocess.check_output(['git','-C',str(main),'rev-parse','HEAD'],text=True).strip()==protected['main_head']
for x in protected['main_files']:assert hashlib.sha256((main/x['path']).read_bytes()).hexdigest()==x['sha256']
for x in json.loads((r/'header-sync.json').read_text()):assert hashlib.sha256(Path(x['target']).read_bytes()).hexdigest()==x['sha256']
print('Staged records, exact generated headers, final binaries and protected state checked')
