$ErrorActionPreference = 'Stop'
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$root = 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5'
$source = "$root/source"
$dep = 'E:/SyncForder/CodeRepos/install/q2/c;E:/SyncForder/CodeRepos/install/q2/toolset;E:/SyncForder/CodeRepos/install/RelWithDebInfo'
$base = 'E:/SyncForder/CodeRepos/install/sr4-move/d'
$final = 'E:/SyncForder/CodeRepos/install/s5/q/d'
& 'C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -B "$source/cmake/RunScriptSR3Scale.py" --baseline-source 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/sr4-move/candidate-source' --candidate-source "$root/candidate-source" --baseline-prefix $base --candidate-prefix $final --dependencies $dep --output "$root/scale-replay"
if ($LASTEXITCODE) { throw 'scale failed' }
& 'C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -B "$source/cmake/RunScriptSR2Probes.py" --baseline-source 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/sr4-move/candidate-source' --candidate-source "$root/candidate-source" --baseline-prefix $base --candidate-prefix $final --dependencies $dep --output "$root/probes"
if ($LASTEXITCODE) { throw 'cold and trace probes failed' }
& "$source/cmake/RunScriptV3Measurements.ps1" -BaselineBin 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/m4/d/bin' -FinalBin "$root/q/d/bin" -BaselineToolBin 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/m4/t/bin' -FinalToolBin "$root/q/t/bin" -LuaArtifact "$root/q/t/engine/toolchain/lua/lua_runtime_benchmark_fixture.lxsa" -PhysicsLuaArtifact "$root/q/t/engine/toolchain/physics2d/physics2d_lua_fixture.lxsa" -PhysicsFlowArtifact "$root/q/t/engine/toolchain/physics2d/physics2d_flowforge_fixture.lxsa" -OutputRoot "$root/performance" -Only @('cpp-update-10k','lua-update-10k','lua-ability-10k','lua-event-10k','lua-coroutine-10k','flow-update-10k','flow-event-10k','event-fanout-10k') -Pairs 5
