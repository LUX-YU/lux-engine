#pragma once
// Generated canonical Script Ability descriptor, provider binder and C++ projection.
#include <lux/engine/function/script/ScriptAbility.hpp>
#include <lux/engine/function/script/ScriptAbilityAsync.hpp>
#include <lux/engine/function/script/ScriptAbilityCompletionAdapter.hpp>
#include <array>
#include <concepts>
#include <memory>
#include <utility>
#include <Ability.hpp>

namespace lux::script
{

    template <>
    struct ScriptAbilityTraits<::ValueAbility> final
    {
        using Ability = ::ValueAbility;
        inline static constexpr ScriptApiContractIdView Contract{"consumer.values"};
        inline static constexpr auto Receiver = EScriptAbilityReceiverKind::PROVIDER_INSTANCE;

        struct Dispatch final
        {
            Item (*echo)(void*, const Item &) noexcept{};
        };

        static_assert(noexcept(std::declval<Ability&>().echo(std::declval<const Item &>())));



        inline static constexpr std::array<ScriptAbilityParameterDescription, 1> echoParameters{
            ScriptAbilityParameterDescription{"item", makeScriptAbilityValue<const Item &>(EScriptAbilityValueLifetime::BORROWED_STEP)}
        };
        inline static constexpr std::array<ScriptAbilityValueDescription, 1> echoResults{
            makeScriptAbilityValue<Item>(EScriptAbilityValueLifetime::OWNED_VALUE)
        };

        inline static constexpr std::array<ScriptAbilityMethodDescription, 1> Methods{
            ScriptAbilityMethodDescription{
                ScriptApiMethodIdView{"consumer.values.echo"},
                "echo",
                "Echo",
                EScriptApiMethodKind::QUERY,
                echoParameters,
                echoResults
            }
        };
        static_assert(scriptAbilityMethodIdsUnique(Methods), "Script Ability MethodId values must be unique");
        inline static constexpr ScriptAbilityDescription Description{
            Contract,
            "Values",
            "Values",
            1U,
            scriptAbilitySchemaHash(Contract, Receiver, Methods,
                1U),
            Receiver,
            Methods
        };
        static_assert(scriptAbilityCodeNameValid(Description.name), "Script Ability code name must be an identifier");

        static ScriptAbilityErasedCallResult echoErased(
            void* context,
            const void* dispatch_value,
            std::span<const ScriptAbilityInputSlot> arguments,
            std::span<ScriptAbilityOutputSlot> results
        ) noexcept
        {
            if (dispatch_value == nullptr || arguments.size() != 1U)
                return lux::cxx::unexpected<ScriptAbilityOperationError>(ScriptAbilityOperationError{static_cast<std::int32_t>(EScriptAbilityErasedCallStatus::INVALID_ARGUMENTS)});
            if (!scriptAbilityInputMatches<const Item &>(arguments[0]))
                return lux::cxx::unexpected<ScriptAbilityOperationError>(ScriptAbilityOperationError{static_cast<std::int32_t>(EScriptAbilityErasedCallStatus::INVALID_ARGUMENTS)});
            const auto& dispatch = *static_cast<const Dispatch*>(dispatch_value);
            if (results.size() != 1U)
                return lux::cxx::unexpected<ScriptAbilityOperationError>(ScriptAbilityOperationError{static_cast<std::int32_t>(EScriptAbilityErasedCallStatus::INVALID_RESULTS)});
            if (!scriptAbilityOutputMatches<Item>(results[0]))
                return lux::cxx::unexpected<ScriptAbilityOperationError>(ScriptAbilityOperationError{static_cast<std::int32_t>(EScriptAbilityErasedCallStatus::INVALID_RESULTS)});
            auto&& value = dispatch.echo(context, *static_cast<const std::remove_cvref_t<const Item &>*>(arguments[0].data));
            *static_cast<std::remove_cvref_t<Item>*>(results[0].data) = value;
            return {};
        }
        inline static constexpr std::array<ScriptAbilityErasedMethodBinding, Methods.size()> ErasedMethods{
            ScriptAbilityErasedMethodBinding{
                ScriptApiMethodIdView{"consumer.values.echo"},
                EScriptApiMethodKind::QUERY,
                echoParameters,
                echoResults,
                &echoErased,
                nullptr
            }
        };

        template <class Provider>
        inline static constexpr bool ProviderConforms = requires(
            Provider& provider, const Item & arg_echo_0
        ) {
            { provider.echo(arg_echo_0) } noexcept -> std::same_as<Item>;
        };

        template <class Provider>
        static Item echoThunk(void* context, const Item & arg_0) noexcept
        {
            auto& provider = *static_cast<Provider*>(context);
            return provider.echo(arg_0);
        }

        template <class Provider>
        inline static constexpr Dispatch ProviderDispatch{
            &echoThunk<Provider>
        };

        template <class Provider>
            requires ProviderConforms<Provider>
        [[nodiscard]] static ScriptAbilityBinding bind(Provider& provider) noexcept
        {
            return {&Description, std::addressof(provider), &ProviderDispatch<Provider>, ErasedMethods};
        }
    };

    template <>
    class ScriptAbilityStarter<::ValueAbility> final
    {
    public:
        [[nodiscard]] static lux::cxx::expected<ScriptAbilityStarter, EScriptAbilityBindingError>
        create(ScriptAbilityBinding binding) noexcept
        {
            if (!binding.valid())
                return lux::cxx::unexpected<EScriptAbilityBindingError>(
                    EScriptAbilityBindingError::INVALID_BINDING
                );
            if (binding.description->id != ScriptAbilityTraits<::ValueAbility>::Description.id ||
                binding.description->schema_hash != ScriptAbilityTraits<::ValueAbility>::Description.schema_hash)
                return lux::cxx::unexpected<EScriptAbilityBindingError>(
                    EScriptAbilityBindingError::CONTRACT_MISMATCH
                );
            return ScriptAbilityStarter(binding.context,
                static_cast<const typename ScriptAbilityTraits<::ValueAbility>::Dispatch*>(binding.dispatch));
        }

    private:
        ScriptAbilityStarter(void* context, const typename ScriptAbilityTraits<::ValueAbility>::Dispatch* dispatch) noexcept
            : context_(context), dispatch_(dispatch) {}
        void* context_{};
        const typename ScriptAbilityTraits<::ValueAbility>::Dispatch* dispatch_{};
    };

    template <>
    class ScriptAbilityCpp<::ValueAbility> final
    {
    public:
        [[nodiscard]] static lux::cxx::expected<ScriptAbilityCpp, EScriptAbilityBindingError>
        create(ScriptAbilityBinding binding) noexcept
        {
            if (!binding.valid())
                return lux::cxx::unexpected<EScriptAbilityBindingError>(
                    EScriptAbilityBindingError::INVALID_BINDING
                );
            if (binding.description->id != ScriptAbilityTraits<::ValueAbility>::Description.id ||
                binding.description->schema_hash != ScriptAbilityTraits<::ValueAbility>::Description.schema_hash)
                return lux::cxx::unexpected<EScriptAbilityBindingError>(
                    EScriptAbilityBindingError::CONTRACT_MISMATCH
                );
            return ScriptAbilityCpp(binding.context,
                static_cast<const typename ScriptAbilityTraits<::ValueAbility>::Dispatch*>(binding.dispatch));
        }
        Item echo(const Item & item) const noexcept
        {
            return dispatch_->echo(context_, item);
        }

    private:
        ScriptAbilityCpp(void* context, const typename ScriptAbilityTraits<::ValueAbility>::Dispatch* dispatch) noexcept
            : context_(context), dispatch_(dispatch) {}
        void* context_{};
        const typename ScriptAbilityTraits<::ValueAbility>::Dispatch* dispatch_{};
    };

    template <class Context>
    class ScriptAbilityCoroutine<::ValueAbility, Context> final
    {
    public:
        ScriptAbilityCoroutine(Context& context, std::uint32_t ability_slot) noexcept
            : context_(std::addressof(context)), ability_slot_(ability_slot)
        {
        }
        [[nodiscard]] auto echo(const Item & item) const noexcept
        {
            return context_->template invokeAbility<Item>(
                ability_slot_,
                [&](void* provider, const void* dispatch_value) noexcept -> Item
                {
                    const auto& dispatch = *static_cast<const typename ScriptAbilityTraits<::ValueAbility>::Dispatch*>(dispatch_value);
                    return dispatch.echo(provider, item);
                }
            );
        }

    private:
        Context* context_{};
        std::uint32_t ability_slot_{};
    };

    template <class Provider>
        requires ScriptAbilityTraits<::ValueAbility>::template ProviderConforms<Provider>
    class ScriptAbilityStatic<::ValueAbility, Provider> final
    {
    public:
        [[nodiscard]] static lux::cxx::expected<ScriptAbilityStatic, EScriptAbilityBindingError> create(
            Provider& provider,
            ScriptAbilityBinding binding
        ) noexcept
        {
            const bool is_mismatch = !binding.valid() || binding.context != std::addressof(provider) ||
                binding.description->id != ScriptAbilityTraits<::ValueAbility>::Description.id ||
                binding.description->schema_hash != ScriptAbilityTraits<::ValueAbility>::Description.schema_hash;
            return is_mismatch
                ? lux::cxx::unexpected<EScriptAbilityBindingError>(EScriptAbilityBindingError::CONTRACT_MISMATCH)
                : lux::cxx::expected<ScriptAbilityStatic, EScriptAbilityBindingError>{ScriptAbilityStatic(provider)};
        }
        Item echo(const Item & item) const noexcept
        {
            return provider_->echo(item);
        }

    private:
        explicit ScriptAbilityStatic(Provider& provider) noexcept : provider_(std::addressof(provider)) {}
        Provider* provider_{};
    };

} // namespace lux::script
