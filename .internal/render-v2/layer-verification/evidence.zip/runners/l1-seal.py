from pathlib import Path
b=Path('E:/RenderV2Rebuild/Layer/source/modules/function/render')
p=b/'protocol/include/lux/engine/render/protocol/Protocol.hpp';s=p.read_text();a=s.index('    // The erased call');z=s.index('    [[nodiscard]] RenderResult<void> validateCommand',a)
s=s[:a]+'''    namespace protocol_detail { struct CommandHandlerAudit; }

    class CommandHandler
    {
    public:
        CommandHandler() noexcept = default;
        [[nodiscard]] const CommandDescriptor* descriptor() const noexcept { return descriptor_; }
        [[nodiscard]] bool valid() const noexcept { return descriptor_ && invoke_; }
        [[nodiscard]] RenderResult<void> invoke(CommandInvocation& invocation) const noexcept
        {
            return invoke_(user_, invocation);
        }

        template <RenderCommand C, auto Function, class State>
            requires std::same_as<decltype(Function),
                RenderResult<void> (*)(State&, const typename C::Request&, CommandContext<C>&) noexcept>
        [[nodiscard]] static CommandHandler bind(State* state) noexcept
        {
            return {&commandDescriptor<C>(), [](void* owner, CommandInvocation& invocation) noexcept {
                CommandContext<C> context(invocation);
                return Function(*static_cast<State*>(owner), context.request(), context);
            }, state};
        }

    private:
        friend struct protocol_detail::CommandHandlerAudit;
        using Invoke = RenderResult<void> (*)(void*, CommandInvocation&) noexcept;
        CommandHandler(const CommandDescriptor* descriptor, Invoke invoke, void* user) noexcept
            : descriptor_(descriptor), invoke_(invoke), user_(user) {}
        const CommandDescriptor* descriptor_ = nullptr;
        Invoke invoke_ = nullptr;
        void* user_ = nullptr;
    };

    template <RenderCommand C, auto Function, class State>
        requires std::same_as<decltype(Function),
            RenderResult<void> (*)(State&, const typename C::Request&, CommandContext<C>&) noexcept>
    [[nodiscard]] CommandHandler bindCommand(State& state) noexcept
    {
        return CommandHandler::bind<C, Function>(&state);
    }

'''+s[z:];p.write_text(s)
p=b/'resource/include/lux/engine/render/resource/Registration.hpp';s=p.read_text();a=s.index('    struct CommandRegistration');z=s.index('    // Cold declaration',a)
s=s[:a]+'''    namespace registration_detail { struct NativeBinding; struct CommandRegistrationAudit; }

    class CommandRegistration final : public CommandHandler
    {
    public:
        CommandRegistration() noexcept = default;
        CommandRegistration(CommandHandler handler) noexcept : CommandHandler(handler) {}
        [[nodiscard]] bool gpuCompletion() const noexcept { return gpu_completion_; }
        void bindNative(void* owner) noexcept
        {
            if (bind_native_) static_cast<CommandHandler&>(*this) = bind_native_(owner);
        }

    private:
        friend struct registration_detail::NativeBinding;
        friend struct registration_detail::CommandRegistrationAudit;
        CommandHandler (*bind_native_)(void*) noexcept = nullptr;
        bool gpu_completion_ = false;
    };

'''+s[z:];p.write_text(s)
p=b/'native/vulkan/include/lux/engine/render/native/vulkan/Registration.hpp';p.write_text('''#pragma once

#include <lux/engine/render/resource/Registration.hpp>
#include <lux/engine/render/native/vulkan/DeviceSession.hpp>

namespace lux::render::registration_detail
{
    // Installed template implementation for external Native extension modules.
    struct NativeBinding final
    {
        template <RenderCommand C, auto Function>
        static CommandRegistration bind() noexcept
        {
            CommandRegistration result{CommandHandler::bind<C, Function>(static_cast<vulkan::DeviceSession*>(nullptr))};
            result.bind_native_ = [](void* owner) noexcept {
                return bindCommand<C, Function>(*static_cast<vulkan::DeviceSession*>(owner));
            };
            result.gpu_completion_ = commandDescriptor<C>().completion == ECompletionContract::RESOURCE_GPU_READY;
            return result;
        }
    };
}

namespace lux::render::vulkan
{
    template <RenderCommand C, auto Function>
        requires std::same_as<decltype(Function),
            RenderResult<void> (*)(DeviceSession&, const typename C::Request&, CommandContext<C>&) noexcept>
    [[nodiscard]] CommandRegistration nativeCommand() noexcept
    {
        return registration_detail::NativeBinding::bind<C, Function>();
    }
}
''')
p=b/'runtime/src/RenderServer.cpp';s=p.read_text();a=s.index('            addCommand(CommandHandler{');z=s.index('\n        }',a)
s=s[:a]+'''            static constexpr auto handler = +[](Impl& owner, const typename C::Request&, CommandContext<C>& context) noexcept {
                auto& invocation = protocol_detail::CommandContextAccess::invocation(context);
                return (owner.*Method)(static_cast<GpuAdmission*>(invocation.completion_owner)->request);
            };
            addCommand(bindCommand<C, handler>(*this), commandTransport<C>(), nullptr, config.implementation_code_pin);'''+s[z:]
s=s.replace('            binding.descriptor = transport.descriptor;\n','')
s=s.replace('handler.descriptor','handler.descriptor()').replace('old.binding.descriptor','old.binding.descriptor()').replace('handlers[previous].descriptor','handlers[previous].descriptor()').replace('entry.binding.descriptor','entry.binding.descriptor()').replace('entry->binding.descriptor','entry->binding.descriptor()')
s=s.replace('!handler.descriptor() || !handler.invoke','!handler.valid()').replace('handler.gpu_completion','handler.gpuCompletion()').replace('entry->binding.gpu_completion','entry->binding.gpuCompletion()')
s=s.replace('entry->binding.invoke(entry->binding.user, invocation)','entry->binding.invoke(invocation)')
s=s.replace('            if (entry.binding.bind_native)\n                static_cast<CommandHandler&>(entry.binding) = entry.binding.bind_native(entry.binding, s.device.get());','            entry.binding.bindNative(s.device.get());')
p.write_text(s)
# Raw fault tests construct through an explicitly test-only friend, never a supported author API.
p=b/'runtime/test/ErasedRegistrationFixture.hpp';p.write_text('''#pragma once

#include <lux/engine/render/resource/Registration.hpp>

namespace lux::render::protocol_detail
{
    struct CommandHandlerAudit final
    {
        static CommandHandler make(const CommandDescriptor* descriptor,
            RenderResult<void> (*invoke)(void*, CommandInvocation&) noexcept, void* user) noexcept
        {
            return {descriptor, invoke, user};
        }
        static CommandHandler owner(CommandHandler handler, void* user) noexcept
        {
            handler.user_ = user;
            return handler;
        }
    };
}

namespace lux::render::registration_detail
{
    struct CommandRegistrationAudit final
    {
        // Tests requiring malformed descriptors/physical qualification deliberately bypass author API.
        // Each native thunk has its own static template instantiation, not a mutable global dispatch table.
        template <auto Invoke>
        static CommandRegistration native(const CommandDescriptor* descriptor, bool gpu) noexcept
        {
            CommandRegistration result{protocol_detail::CommandHandlerAudit::make(descriptor, Invoke, nullptr)};
            result.gpu_completion_ = gpu;
            return result;
        }
        static void gpu(CommandRegistration& value, bool enabled) noexcept { value.gpu_completion_ = enabled; }
    };
}

namespace lux::render::test_registration
{
    enum class EOwner { PROVIDED, DEVICE_SESSION };

    // Compatibility only inside historical fault fixtures, removed from production registration.
    inline CommandRegistration erased(const CommandDescriptor* descriptor,
        RenderResult<void> (*invoke)(void*, CommandInvocation&) noexcept,
        void* user = nullptr, EOwner owner = EOwner::PROVIDED, bool gpu = false) noexcept
    {
        // Native fixtures are migrated to nativeCommand before this branch may be used.
        if (owner != EOwner::PROVIDED) std::terminate();
        CommandRegistration result{protocol_detail::CommandHandlerAudit::make(descriptor, invoke, user)};
        registration_detail::CommandRegistrationAudit::gpu(result, gpu);
        return result;
    }
}
''')
p=b/'runtime/test/StorageRegistration.cpp';s=p.read_text().replace('auto handler = registration.handlers[0];\n    handler.gpu_completion = false;','CommandRegistration handler{static_cast<const CommandHandler&>(registration.handlers[0])};');p.write_text(s)
p=b/'protocol/test/Binding.cpp';s=p.read_text().replace('handler.invoke(handler.user, invocation)','handler.invoke(invocation)');p.write_text(s)
