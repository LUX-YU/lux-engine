from pathlib import Path
import hashlib,json,subprocess,csv,zipfile,os
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1');s=r/'source';o=s/'.internal/script-native-lua-na1';e=o/'evidence';e.mkdir(exist_ok=True)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
# Reconstructable binary identity includes actual artifacts; never add binary payloads to source evidence.
identity=[]
for p in sorted((r/'images').rglob('*')):
 if p.is_file() and p.suffix.lower() in {'.dll','.exe','.pdb','.lxsa','.json'}:
  identity.append(dict(path=str(p),relative=p.relative_to(r).as_posix(),bytes=p.stat().st_size,sha256=sha(p)))
(r/'final-image-identities.json').write_text(json.dumps(identity,indent=2))
raw=[]
for folder in ['profiles','profiles2','profiles-pose']:
 for p in sorted((r/folder).rglob('*')):
  if p.is_file():raw.append(dict(path=str(p),relative=p.relative_to(r).as_posix(),bytes=p.stat().st_size,sha256=sha(p)))
(r/'final-profile-identities.json').write_text(json.dumps(raw,indent=2))
source=dict(head=subprocess.check_output(['git','-C',str(s),'rev-parse','HEAD'],text=True).strip(),qualification_head=subprocess.check_output(['git','-C',str(r/'qualification-source'),'rev-parse','HEAD'],text=True).strip(),qualification_status=subprocess.check_output(['git','-C',str(r/'qualification-source'),'status','--porcelain'],text=True),branch=subprocess.check_output(['git','-C',str(s),'branch','--show-current'],text=True).strip(),changed_production_paths=subprocess.check_output(['git','-C',str(s),'diff','--name-only','f92853ea','HEAD','--','engine','modules','cmake'],text=True).splitlines(),commits=subprocess.check_output(['git','-C',str(s),'log','--format=%H %s','f92853ea..HEAD'],text=True).splitlines())
assert not source['qualification_status'];(r/'final-source-identity.json').write_text(json.dumps(source,indent=2))
failed=[]
for p in sorted(r.glob('*.json')):
 try:x=json.loads(p.read_text(encoding='utf-8-sig'))
 except:continue
 if isinstance(x,dict) and isinstance(x.get('exit'),int) and x['exit']!=0:failed.append(dict(record=p.name,exit=x['exit'],kind='historical build/test/driver failure; superseded; retained'))
for x in json.loads((r/'profiles/runs.json').read_text()):failed.append(dict(record=x,kind='initial ROI observer invalid: target stdout/business verification missing; do not count as valid sampling'))
(r/'failed-attempt-index.json').write_text(json.dumps(failed,ensure_ascii=False,indent=2))
# Captures exact source/commands for supplemental probes, all timing/profile originals, and final qualification logs.
files=set()
for p in r.iterdir():
 if p.is_file() and p.suffix.lower() in {'.json','.jsonl','.log','.txt','.csv','.py','.ps1','.zip'}:files.add(p)
folders=['instructions','source.na1-start-evidence','final-costs','resources','profiles','profiles2','profiles-pose','machine-code','machine-code2','current-class-layout','current-class-layout2','installed','value-incremental','new-incremental','relocated','protocol-probes','supplemental-contract']
text_ext={'.json','.jsonl','.log','.txt','.csv','.py','.ps1','.cmake','.cpp','.hpp','.h','.lua','.symbols','.template','.md','.asm'}
for name in folders:
 p=r/name
 if not p.exists():continue
 for f in p.rglob('*'):
  if not f.is_file():continue
  if name.startswith('profiles') or f.suffix.lower() in text_ext:
   if any(x in f.parts for x in ['.git','vcpkg_installed']):continue
   files.add(f)
# Exclude SDK/source snapshots copied for relocation; relocation logs/compile input probes remain.
files={f for f in files if not any(part in f.relative_to(r).parts for part in ['sdk','tools','vm','source','build','CMakeFiles']) or f.suffix.lower() in {'.log','.json','.jsonl','.csv'}}
manifest=[];archive=e/'logs.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(files):
  rel=f.relative_to(r).as_posix();data=f.read_bytes();z.writestr(rel,data);manifest.append(dict(path=rel,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(e/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
info=dict(archive='logs.zip',sha256=sha(archive),bytes=archive.stat().st_size,entries=len(manifest),uncompressed_bytes=sum(x['bytes'] for x in manifest),qualification_source=source['head'],compiled_binaries_in_archive=False,vtune_raw_included=True)
(e/'archive.json').write_text(json.dumps(info,indent=2)+'\n');(e/'logs.zip.sha256').write_text(info['sha256']+'  logs.zip\n')
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(manifest)
 for m in manifest:assert hashlib.sha256(z.read(m['path'])).hexdigest()==m['sha256']
print(json.dumps(info,indent=2));print('Local archive all entries verified')
