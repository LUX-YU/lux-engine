import json,statistics
from pathlib import Path
r=Path(__file__).resolve().parent
s=r.parent/'s5/source'
d=json.loads((r/'summary/costs.json').read_text())
med=statistics.median
def fmt(v):return f'{v:,.3f}'
def classify(values):
 if all(v>0 for v in values):return 'REGRESSION_UNRESOLVED'
 if all(v<0 for v in values):return 'IMPROVED（本次观测）'
 return 'NO_MEASURABLE_GAIN（配对异号）'
def perc(values):return ' / '.join(f'{v:+.2f}%' for v in values)
rows=[]
for c in d['eight']['comparisons']:
 p=c['pairs'];counts=p[0]['baseline']['counts']
 key=next(k for k in ('provider_calls','actual_new_calls','resumes') if k in counts)
 n=counts[key]
 delta=med(x['delta_ns'] for x in p)
 values=[x['percent'] for x in p]
 rows.append(f"| {c['case']} | {n:,} {key} | {fmt(c['median_baseline_ns']/1e6)} / {fmt(c['median_candidate_ns']/1e6)} | {fmt(delta/1e6)} | {fmt(delta/n)} | {perc(values)} | {classify(values)} |")
value_rows=[]
for c in d['values']:
 values=[p['percent'] for p in c['pairs']]
 value_rows.append(f"| {c['case']} | {c['pairs'][0]['E']['count']:,} | {fmt(c['median_E_ns']/1e6)} / {fmt(c['median_F_ns']/1e6)} | {fmt(c['median_delta_ns_per_operation'])} | {perc(values)} | {classify(values)} |")
scale_rows=[]
for c in d['scale']:
 values=[p['percent'] for p in c['pairs']]
 scale_rows.append(f"| {c['configs']:,} | {fmt(med(p['E']['elapsed_ns'] for p in c['pairs'])/1e6)} / {fmt(med(p['F']['elapsed_ns'] for p in c['pairs'])/1e6)} | {fmt(c['median_delta_ns_per_rebuild'])} | {perc(values)} | {classify(values)} |")
cold_rows=[]
for field,label,n in [('prepare_ns','首次 create+prepare（8配置容量，1实例）',1),('late_ns','迟到挂载（同批7实例）',7),('remount_128_ns','退休重建',128)]:
 pairs=d['cold']['pairs'];values=[p['percent'][field] for p in pairs]
 cold_rows.append(f"| {label} | {n} | {fmt(med(p['E'][field] for p in pairs)/1e6)} / {fmt(med(p['F'][field] for p in pairs)/1e6)} | {fmt(med(p['F'][field]-p['E'][field] for p in pairs)/n)} | {perc(values)} | {classify(values)} |")
extra_rows=[]
for c in d['extra']:
 for i,group in enumerate(c['pairs'][0]['F']['groups']):
  a=[p['E']['groups'][i] for p in c['pairs']];b=[p['F']['groups'][i] for p in c['pairs']]
  values=[p['percent'] for p in b]
  extra_rows.append(f"| {group['scenario']} | {group['samples']} | {fmt(med(p['total_ns'] for p in a)/1e6)} / {fmt(med(p['total_ns'] for p in b)/1e6)} | {perc(values)} | {classify(values)} |")
text='''本轮在2026-09-08完成串行验证；资格源码F为上列7b5e1dd4，后续报告/证据提交不改变该产物身份。

| 状态 | 本轮结论 | 原始记录（归档内相对路径） |
|---|---|---|
| IMPLEMENTATION | PASS，安装纵向缺口已补齐；正式运行时/模板未修改 | audit/formal-paths.json；evidence-stage/final-identity.json |
| CORRECTNESS | PASS于本轮矩阵；Toolchain全量108/108、Developer全量123/123、Lua54受影响子集110/110 | q/qualification.json及t/d/l的CTest日志 |
| CODEGEN_INSTALL | PASS，15个消费者、13项增量检查、新位置生成/编译/纵向执行；第二次构建均no-op | consumers-final、incremental-final、relocation |
| PERFORMANCE | 已完成同量记录，保留旧债务；按下表单项分类，不授予统一性能PASS | performance、record-costs、probes、scale、extra-costs、summary/costs.json |
| EXTRA_PLATFORMS | NOT_TESTED：Linux/Android/额外Debug或Release/完整Editor、Lua54全profile与全部消费者 | 本轮只有Windows RelWithDebInfo；Lua54仅上述子集 |

没有新增CTest注册；新增的是已安装消费者内的断言和独立诊断。原六项Scene Lua测试使用匹配的实际资产通过，
本轮既不重新修这些预期，也不继续记作失败。七点重入、同步错误、Bindings回滚、身份复用、Event/pin/frontier/预算、
装配规模、四项真实Lua资格负例和合法recovery/standalone/lifecycle都包含在实际受影响验证中。

完整构建均为`cmake --build <build> --target all -j 4 -- -k 0`，固定clean tracked源码，构建、测试、计时串行。
未改modules公共头，无新的三前缀同步内容；私有owner头未进入SDK，实际direct runtime链接无World/Scene/Process，
description leaf未携带Scene runtime或Process。资产、VM、生成器、EXE/DLL、SDK和实际链接身份见identity及final-identity。

### 安装纵向链和relocation

原codec/contribution断言仍先执行。真实provider按阶段累计为2→2→2→3，两个错误阶段各自增量0，随后恢复成功；
Begin/End各1次，普通合法调用2次，总provider调用4次。provider构造/析构1/1，资产lease/release1/1，
第二次shutdown无重复释放，active/continuation/awaitable/waiter/queue与prepared slots均归零。

relocation在新`s6/relocation/sdk/{d,t}`安装位置，从consumer自有类型重新生成；原候选源码、构建和SDK目录实际临时移开，
禁用包注册表/旧搜索前缀，所有解析的Engine包目录及编译/链接/命令路径检查通过。原目录在finally中恢复。
仅LuaJIT的这个纵向消费者做了relocation，不扩大为Lua54全部SDK迁移资格。

### 同量成本E→F

每场景五对独立进程，偶数对E/F、奇数对F/E；Windows 24逻辑CPU，MSVC19.44，RWDI /O2 /Ob1，
固定工作量/seed/容量/预算/warmup/VM默认GC，不锁频、不绑定CPU亲和性。没有并发构建或测试，保留所有配对，未丢弃慢样本。
完整参数与顺序见evidence-stage/cost-plan.json及各runs.json，正式计时与trace/分配诊断分开。

下表E/F分别为各自批量总时间中位数；差值及百分比按同一对计算后取中位，不能用两个边际中位数相减替代配对差。
单位成本摊销完整批量，不是单独的resume、handler或权限检查成本。IMPROVED只是这五对的观测，生产源码相同，不能当作本轮优化收益。
配对异号标NO_MEASURABLE_GAIN仅表示没有一致方向，不构成统计等价证明；五对同正标未解释回退，不用源码相同或旧债务豁免。

| 场景 | 实际操作分母/进程 | E / F总时间 ms | 配对差中位 ms | 配对差 ns/操作 | 五对变化（0..4） | 分类 |
|---|---|---|---|---|---|---|
'''+ '\n'.join(rows)+'''

除fan-out外，逐frame工作量、checksum、起停计数、continuation/awaitable/waiter/queue均逐行对拍。
Lua scalar为30M provider，普通Update按实际new-call而非handler候选计；Flow Update每次new-call含两次provider。
Lua coroutine和Flow Event各50M Hook候选、10M实际新调用/恢复，持续backlog=8000；不得把50M当作provider分母。
Lua Event沿原场景使用实际10000恢复预算，50M实际新调用/恢复、每frame一个Event，backlog=0；CLI的2000不是该场景实际预算。
fan-out一次occurrence、10000完成/恢复，5个原预算2000的真实drain step。INTEGRITY是计时外可观测范围，
旧errors/failures缺列仍为null；不是零，也不承诺捕获所有已由Lua pcall处理的错误。

| 值场景 | 实际输出/provider数 | E / F总时间 ms | 配对差 ns/操作 | 五对变化 | 分类 |
|---|---|---|---|---|---|
'''+ '\n'.join(value_rows)+'''

typed指当前首批Pose真实双向provider，不制造旧版本不存在功能的历史比值。两字段record和typed均保留errors=0、backlog=0和完整业务数。
每个独立进程仅一个批量结果，不提供虚构的逐操作p95/p99。

| 冷期/退休批次 | 操作数 | E / F总时间 ms | 配对差 ns/操作 | 五对变化 | 分类 |
|---|---|---|---|---|---|
'''+ '\n'.join(cold_rows)+'''

冷期每进程create/destroy=152/152，prepare/release=456/456。保留6个生命周期与8个Event轨迹的实际CASE/事件计数，
所有插桩替换准确命中，非空轨迹E/F一致，wire golden 288字节一致。单次prepare/late没有逐操作尾部，128次重建尾部另见规模测试。

| 配置数（只重建一个） | 128次E / F总时间 ms | 配对差 ns/重建 | 五对变化 | 分类 |
|---|---|---|---|---|
'''+ '\n'.join(scale_rows)+'''

两种规模固定16次warmup、128次计时重建；仅触及128个配置槽位、0个endpoint计数，已发布地址稳定，backing不增长。

| 实际集成场景/帧类别 | 样本数/进程 | E / F总时间 ms | 五对变化 | 分类 |
|---|---|---|---|---|
'''+ '\n'.join(extra_rows)+'''

sequence完整路径停止生产后，按原来源/时间/预算在10步内业务完成：最终calls/provider=150000、suspend/resume=450000、
checksum=6000000，执行资源与队列均0。该drain发生在shutdown前，不是取消伪装完成。
regions使用两个worker、65536元素、每frame两个真实CppStatic Script Hook；每帧工作量/checksum及图规模E/F一致。
另外独立完整窗口排他诊断记录worker=21、owner=82、violations=0，保留原双Simulation barrier及失败路径断言。

### 尾部、实际恢复延迟与内存

`summary/costs.json`按每run/场景列p50/p95/p99、总时间和maximum，nearest-rank，禁止平均不同run的分位数。
至少20个样本才提供p95，100个才提供p99；fan-out/短drain/prepare等不足样本字段为null。scale单独保留128次重建的p50/p95/p99。
创建、持续帧、恢复drain、图prepare各自分组，record/typed逐操作尾部未测。

独立协议诊断E/F均：step0完成17个结果并reset Channel，原预算3，在step1/1/1/2/2/2/3/3/3/4/4/4/5/5/5/6/6实际恢复，
每次结果73，17次destroy、errors/backlog=0；没有额外稳定点。该诊断无stale通知，stale pop仍由既有测试与源码扣预算位置核对，
不把这17项当作新的stale实测。它使用测试fixture，不混同只用公开头的安装consumer。

内存分层记录：scale分别给mount/prepared method/binding/feedback/Awaitable固定bytes；READY诊断给17个执行资源/queue和574?bytes实值；
continuation与来源的独立字节未由接口暴露，保留计数/高水位而不虚构字节。具体backing数以scale/protocol日志为准。
typed内存诊断Item=16、slots=24、failure=258、input/result frame上界各3000字节；后两者是保守构造规划上界，不能合计成常驻栈或堆开销。
record单独10000输出VM诊断20000次分配、1120000 bytes、30000 protected C调用；typed 100000调用VM分配800000次。
EXE-local allocation关闭时的0均为未观测；打开后冷期prepare/late/remount计数5/33/535，scale重复重建诊断独立列出。
`extra-costs/runs.json`保留每进程peak working set与peak pagefile，覆盖整个启动/准备/计时/关闭，不等于具体owner存储，更不把arena当RSS。

### 保留的历史债务、无效尝试和限制

历史C0→E scalar +9.151%/+6.9321ns/provider、coroutine +8.099%/+78.8398ns/new-call；H→E scalar +25.648%/+16.7296ns/provider，
当前record相对特定protected手写诊断的约116.4941ns残余，均保留原f64资格/原始证据及其安全差别。
本轮没有重测H/C0，不把上述比值改标签为H/C0→F，也不跨轮相加相乘。SR3/4 Event及冷期/内存债务继续按原版本记录。
新增配对变化按本轮表格独立报告；没有为了追平删除安全、少做业务、改单侧优化选项或制造生产补丁。

两项无效开发尝试保留：首次consumer遗漏唯一稳定Hook，公开入口正确拒绝，修正fixture后通过；首次memory脚本将Select-String参数颠倒，
EXE已成功，读日志驱动失败，改为显式参数后在新目录通过。均非生产runtime回退，不混入有效计时，也未删除原日志。
未发现新的联合正确性缺陷。性能接受与否由最终审阅决定；本轮不以架构收益或安全检查存在证明全部残余合理。

所有原始记录及固定下载入口见[evidence/script/sr6/README.md](evidence/script/sr6/README.md)。
本轮完成SR-6联合候选，等待最终审阅；不合并main、不打tag、不冻结框架、不自动开始下一阶段。
'''
# The protocol bytes are read from a captured diagnostic, not estimated.
text=text.replace('574?bytes实值','57544字节backing')
path=s/'.internal/script-system-sr6-qualification-2026-09-07.zh-CN.md'
body=path.read_text(encoding='utf-8')
assert body.count('<!-- RESULTS -->')==1
path.write_text(body.replace('<!-- RESULTS -->',text),encoding='utf-8')
print('Wrote final detailed results')
