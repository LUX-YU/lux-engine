from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).parent;repo=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source')
candidate='e06208deb29b9b1de52fe49a129091f693bb7e08'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def git(p,*args):return subprocess.check_output(['git',*args],cwd=p).decode().strip()
initial=json.loads((r/'r0-start.json').read_text())['repositories'][0];main=Path(initial['path'])
current={f:sha(main/f) for f in initial['files']}
status=subprocess.check_output(['git','status','--porcelain=v1','-z'],cwd=main).decode()
assert git(main,'rev-parse','HEAD')==initial['head'] and status==initial['status'] and current==initial['files']
(r/'protected-workspace-final.json').write_text(json.dumps(dict(path=str(main),head=initial['head'],status=status,files=current,unchanged=True),indent=2))
clones=[]
for p in [repo,r.parent/'script-region-opt/final-source']:
 head=git(p,'rev-parse','HEAD');s=git(p,'status','--porcelain=v1');assert head==candidate and s==''
 result=subprocess.run(['git','fsck','--connectivity-only','--no-dangling'],cwd=p,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (r/('source-fsck.log' if p==repo else 'qualification-fsck.log')).write_bytes(result.stdout)
 assert result.returncode==0
 clones.append(dict(path=str(p),head=head,status=s,fsck_connectivity_exit=result.returncode))
(r/'git-final-integrity.json').write_text(json.dumps(clones,indent=2))
manifest=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in sorted((r/'final-image').iterdir()) if p.is_file()]
(r/'final-image-manifest.json').write_text(json.dumps(manifest,indent=2))
installed=[]
for prefix in ['sdk','tools','lua55']:
 directory=Path('E:/SyncForder/CodeRepos/install/o/v3')/prefix
 for p in sorted(directory.rglob('*')):
  if p.is_file():installed.append(dict(prefix=prefix,path=p.relative_to(directory).as_posix(),bytes=p.stat().st_size,sha256=sha(p)))
(r/'installed-final-manifest.json').write_text(json.dumps(installed,indent=2))
sources=[]
for p in sorted((repo/'cmake/dependencies/lua55').rglob('*')):
 if p.is_file():sources.append(dict(path=p.relative_to(repo).as_posix(),sha256=sha(p)))
(r/'vm-source-manifest.json').write_text(json.dumps(sources,indent=2))
files=git(repo,'diff','--name-only','10a70e80e6e2879ecb09f14ffc083516d0666752',candidate).splitlines()
(r/'source-changes.json').write_text(json.dumps(dict(reference=initial.get('reference','10a70e80e6e2879ecb09f14ffc083516d0666752'),candidate=candidate,files=files),indent=2))
print('AUDIT_PASS',len(installed),len(manifest),len(sources),len(current))
