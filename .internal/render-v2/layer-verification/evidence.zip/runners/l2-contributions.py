from pathlib import Path
b=Path('E:/RenderV2Rebuild/Layer/source/modules/function/render')
p=b/'native/vulkan/test/TextureSceneFixture.hpp';s=p.read_text();line='        draw.arguments.push_back({"shared:texture", *encodeWire(TextureBinding{c.texture, c.lod}, {}, {12, 0})});\n';assert line in s;s=s.replace(line,'');s=s.replace('inline std::vector<StorageArgument> arguments(Config c) { return *programArguments(programs(c)); }','''inline std::vector<StorageArgument> arguments(Config c)
    {
        return {{"shared:texture", *encodeWire(TextureBinding{c.texture, c.lod}, {}, {12, 0})}};
    }''');p.write_text(s)
p=b/'native/vulkan/test/extension/Feature.hpp';s=p.read_text();s=s.replace('RenderResult<std::vector<PassProgram>> programs','RenderResult<ProgramContribution> programs');s=s.replace('        draw.arguments.push_back','        result.arguments.push_back');s=s.replace('        PassProgram draw{','        ProgramContribution result;\n        PassProgram draw{').replace('        std::vector<PassProgram> result;\n','').replace('        result.push_back','        result.programs.push_back');s=s.replace('#pragma once','#pragma once\n\n#include <lux/engine/render/features/Registration.hpp>');p.write_text(s)
for p in (b/'runtime/test').rglob('*'):
 if p.suffix not in ('.hpp','.cpp'):continue
 s=p.read_text();t=s.replace('RenderResult<std::vector<PassProgram>>','RenderResult<ProgramContribution>')
 import re
 t=re.sub(r'return native_fixture::programs\(([^;]+)\);',r'return ProgramContribution{native_fixture::programs(\1), {}};',t)
 t=t.replace('return texture_fixture::programs(*config, name);','return ProgramContribution{texture_fixture::programs(*config, name), texture_fixture::arguments(*config)};')
 if p.name=='Programs.cpp':
  t=t.replace('return values;','return ProgramContribution{std::move(values), {}};').replace('return std::vector<PassProgram>{};','return ProgramContribution{};')
 if t!=s:p.write_text(t)
p=b/'native/vulkan/test/StorageBindings.cpp';s=p.read_text().replace('auto programs = take(extension_test::programs(', 'auto contribution = take(extension_test::programs(');s=s.replace('    const auto count_before =','    auto& programs = contribution.programs;\n    const auto count_before =').replace('auto arguments = take(programArguments(programs));','auto& arguments = contribution.arguments;');p.write_text(s)
p=b/'runtime/src/RenderServer.cpp';s=p.read_text().replace('            std::vector<PassProgram> programs;','            std::vector<PassProgram> programs;\n            std::vector<StorageArgument> arguments;').replace('values->size()','values->programs.size()').replace('(*values)[p]','values->programs[p]').replace('(*values)[previous]','values->programs[previous]').replace('for (auto& value : *values) programs.push_back(std::move(value));','''for (auto& value : values->programs) programs.push_back(std::move(value));
                for (auto& argument : values->arguments)
                {
                    const auto existing = std::ranges::find(arguments, argument.resource_key, &StorageArgument::resource_key);
                    if (existing == arguments.end()) arguments.push_back(std::move(argument));
                    else if (!std::ranges::equal(existing->bytes.view(), argument.bytes.view()))
                        return cxx::unexpected(RenderError{kStorageMismatch});
                }''')
s=s.replace('            auto compiled = vulkan::compileGraph','''            for (const auto pass : assembly->analysis.execution_order)
                if (std::ranges::find(programs, assembly->definition.passes()[pass.index].key, &PassProgram::pass_key) == programs.end())
                    return cxx::unexpected(RenderError{kFeatureContract, {pass.index}});
            auto compiled = vulkan::compileGraph''');s=s.replace('            auto arguments = programArguments(programs);\n            if (!arguments) return cxx::unexpected(arguments.error());\n','').replace('std::move(*arguments)}','std::move(arguments)}');p.write_text(s)
