from pathlib import Path
import json,hashlib
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/lua55-v3');old=r.parent/'lua55-v2';repo=r.parent/'s5/source'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((old/'final-image-manifest.json').read_text())
for f in manifest:
 p=old/'final-image'/f['path'];assert sha(p)==f['sha256'],str(p)
b0=json.loads((old/'final-image/identity.json').read_text());assert b0['source']=='a6f16d6de6a67f6a4422553d31b42c1ac2b3e4c0'
identity=json.loads((repo/'.internal/evidence/script/sr6/identity.json').read_text())
checks=[]
for prefix in identity['prefixes']:
 if not prefix['prefix'].replace('\\','/').endswith(('/q2/c','/q2/toolset')):continue
 for f in prefix['files']:
  p=Path(prefix['prefix'])/f['path'];checks.append(dict(path=str(p),matches=sha(p).lower()==f['sha256'].lower()))
assert checks and all(x['matches'] for x in checks)
(r/'baseline-dependency-verification.json').write_text(json.dumps(dict(baseline=b0['source'],matching_image_files=len(manifest),matching_dependency_files=len(checks),checks=checks),indent=2))
print('VERIFIED',len(manifest),len(checks))
# Reuse bounded v2 drivers; old results are not changed.
for name in ['qualify-accepted.ps1','installed-final.ps1','relocated-atomic.ps1']:
 s=(old/name).read_text().replace('lua55-v2','lua55-v3').replace('/o/v2/','/o/v3/').replace('.v2-hidden','.v3-hidden')
 (r/name).write_text(s)
s=(r/'r3-vm.ps1').read_text().replace("'r3-vm-","'final-vm-").replace(",'1','-R','smoke|leaf|callinfo'",",'1'")
(r/'final-vm.ps1').write_text(s)
s=(old/'final-costs.py').read_text().replace("baseline=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-lua55-s0-s1-20260909/images/final-lua55/d')","baseline=r.parent/'lua55-v2/final-image'").replace('/o/v2/','/o/v3/').replace("b0['commit']","b0['source']").replace('55dcb3fa85a9a2b7dcc87b178dd9ff76ba75c644','a6f16d6de6a67f6a4422553d31b42c1ac2b3e4c0')
a="""            elif scene=='physics' and side=='baseline':
                error_scope='retained failures checked each frame; original shutdown ignored, cumulative count unobserved'
                backlog=counters.get('queue_depth')
"""
assert a in s;s=s.replace(a,'')
(r/'final-costs.py').write_text(s)
s=(old/'memory-diagnostic.py').read_text().replace("base=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-lua55-s0-s1-20260909/images/final-lua55/d')","base=r.parent/'lua55-v2/final-image'")
(r/'memory-diagnostic.py').write_text(s)
