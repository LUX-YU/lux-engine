#include <lux/engine/scene/script/ScriptRuntimeAssembly.hpp>
#include <lux/engine/flowforge/Compiler.hpp>
#include <lux/engine/simulation/ScriptBindingAuthoring.hpp>
#include <lux/engine/scene/script/ScriptSystemDescriptionCodec.hpp>
#include <lux/engine/flowforge/graph/FlowGraph.hpp>
#include <lux/engine/flowforge/graph/FunctionalNode.hpp>
#include <lux/engine/flowforge/graph/ArithmeticNode.hpp>
#include <lux/engine/flowforge/graph/ObjectNode.hpp>
#include <lux/engine/flowforge/script/ScriptAbilityNode.hpp>
#include <lux/engine/flowforge/script/ScriptEventAwaitNode.hpp>
#include <lux/engine/function/script/native/NativeModule.hpp>
#include <lux/engine/simulation/Simulation.hpp>
#include <lux/engine/simulation/SimulationBuilder.hpp>
#include <lux/engine/simulation/SimulationDescriptionBuilder.hpp>
#include <lux/engine/simulation/ScriptSystem.hpp>
#include <lux/engine/scene/script/ScriptSystemDescription.hpp>
#include <lux/engine/simulation/abilities/DelayAbility.hpp>
#include "DelayAbility.ability.generated.hpp"
#include "DelayAbility.ability.native.generated.hpp"
#include <lux/engine/simulation/scripting/native/NativeScriptBackend.hpp>
#include <lux/engine/simulation/scripting/native/NativeScriptAbilityProjection.hpp>
#include <lux/engine/task/TaskExecutor.hpp>

#include <array>
#include <cassert>
#include <charconv>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <memory>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

#ifndef LUX_BENCHMARK_GIT_COMMIT
#define LUX_BENCHMARK_GIT_COMMIT "unknown"
#endif
#ifndef LUX_BENCHMARK_BUILD_TYPE
#define LUX_BENCHMARK_BUILD_TYPE "unknown"
#endif

namespace
{
    using namespace lux;
    using namespace lux::simulation;
    using namespace lux::simulation::script;
    using namespace lux::scene::script;

    inline constexpr system::SystemInstanceId kProbeSystem{0x8301U};
    inline constexpr HookPointId kTickHook{0x8302U};
    inline constexpr lux::script::ScriptSymbolId kTickSymbol{0x8303U};
    inline constexpr EventPointId kPayloadEvent{0x8304U};
    inline constexpr lux::script::ScriptSymbolId kEventWaitSymbol{0x8305U};
    inline constexpr auto kTestContract = lux::script::ScriptApiContractIdView{"lux.test.flowforge.runtime"};
    inline constexpr auto kTestMethod = lux::script::ScriptApiMethodIdView{"lux.test.flowforge.runtime.write"};
    inline constexpr auto kReadMethod = lux::script::ScriptApiMethodIdView{"lux.test.flowforge.runtime.read"};
    inline constexpr auto kEagerMethod = lux::script::ScriptApiMethodIdView{"lux.test.flowforge.runtime.eager"};
    inline constexpr std::uint64_t kTestSchema{0x83048304ULL};
    std::size_t g_hook_capacity{1U};

    [[nodiscard]] asset::AssetId assetId()
    {
        std::array<std::uint8_t, 16U> bytes{};
        bytes[0] = 0x83U;
        return asset::AssetId{bytes};
    }

    struct ProbeSystem final
    {
        inline static constexpr auto Access = makeSystemAccessSpec<>();
        inline static constexpr std::array Hooks{makeHookPointSpec<void()>(kTickHook, "tick", true, true)};
        inline static constexpr std::array Events{
            makeEventPointSpec<std::int32_t>(
                kPayloadEvent,
                "payload",
                kTickHook,
                EEventRoute::SIMULATION_BROADCAST,
                "lux.i32",
                1U
            )
        };
        inline static constexpr SimulationSystemDescription Description{
            .type = {.canonical_name = "lux.test.flowforge.runtime.probe", .version = 1U},
            .hooks = Hooks,
            .events = Events
        };

        using Channel = HookChannel<SimulationBroadcastRoute, std::int32_t>;
        explicit ProbeSystem(Channel& channel) noexcept
            : endpoint(kProbeSystem, kTickHook, hook), event(channel), event_endpoint(kProbeSystem, kPayloadEvent, event)
        {
            ready = hook.prepare(g_hook_capacity) == EEndpointMutationError::NONE;
        }

        void execute() noexcept
        {
            if (pending_payload)
            {
                auto writer = event_writer.begin();
                assert(writer.record(*pending_payload));
                pending_payload.reset();
            }
        }

        HookPoint<void()> hook;
        ScriptHookEndpoint<void()> endpoint;
        Channel& event;
        Channel::Producer event_writer;
        ScriptEventEndpoint<SimulationBroadcastRoute, std::int32_t> event_endpoint;
        bool ready{};
        bool tick_enabled{true};
        std::optional<std::int32_t> pending_payload;
    };

    ProbeSystem* g_probe{};

    [[nodiscard]] lux::cxx::expected<void, SimulationSystemBuildFailure> installProbe(
        SimulationBuilder& builder,
        SimulationSystemView description
    ) noexcept
    {
        auto channel = builder.createHookChannel<SimulationBroadcastRoute, std::int32_t>(
            description.instanceId(), kPayloadEvent, {1U, 8U});
        if (!channel)
            return lux::cxx::unexpected(channel.error());
        auto probe = builder.emplaceSystem<ProbeSystem>(description.instanceId(), **channel);
        if (!probe)
            return lux::cxx::unexpected(probe.error());
        if (!(*probe)->ready)
        {
            return lux::cxx::unexpected(SimulationSystemBuildFailure{
                ESimulationSystemBuildError::CONSTRUCTION_FAILURE,
                description.instanceId()
            });
        }
        g_probe = *probe;
        auto writer = builder.bindHookChannelProducer(description.instanceId(), PrimarySimulationTask, **channel);
        if (!writer)
            return lux::cxx::unexpected(writer.error());
        (*probe)->event_writer = *writer;
        auto published = builder.publishScriptHook(description.instanceId(), (*probe)->endpoint.descriptor());
        if (!published)
            return published;
        published = builder.publishScriptEvent(description.instanceId(), (*probe)->event_endpoint.descriptor());
        if (!published)
            return published;
        auto task = builder.addSystemTask<ProbeSystem>(
            description.instanceId(),
            [](ProbeSystem& value) noexcept { value.execute(); }
        );
        if (!task)
            return task;
        return builder.addSystemHookTask<ProbeSystem>(description.instanceId(), kTickHook,
            [](ProbeSystem& value, const HookInvocation& invocation) noexcept {
                if (value.tick_enabled)
                    static_cast<void>(value.hook.dispatch(invocation));
            });
    }

    [[nodiscard]] bool addProbeExecution(SimulationDescriptionBuilder& builder)
    {
        return static_cast<bool>(builder.addExecutionDependency(
            SimulationExecutionPoint::task(kProbeSystem), SimulationExecutionPoint::hook(kProbeSystem, kTickHook))) &&
            static_cast<bool>(builder.addChannelProducer({kProbeSystem, kPayloadEvent, kProbeSystem, PrimarySimulationTask}));
    }

    struct RuntimeBinding final
    {
        ScriptSystem* runtime{};
        [[nodiscard]] auto bind(Simulation& simulation) noexcept
        {
            return simulation.bindHookCallbacks({this,
                [](void* context, const SimulationClockSnapshot&, bool stable) noexcept {
                    auto* runtime = static_cast<RuntimeBinding*>(context)->runtime;
                    if (runtime == nullptr)
                        return true;
                    if (stable)
                        runtime->beginStableAdmission();
                    return static_cast<bool>(runtime->processLifecycle());
                },
                [](void* context, const SimulationClockSnapshot&, bool stable) noexcept {
                    auto* runtime = static_cast<RuntimeBinding*>(context)->runtime;
                    return runtime == nullptr || !stable || static_cast<bool>(runtime->executeStablePoint());
                },
                [](void* context, const SimulationClockSnapshot&) noexcept {
                    auto* runtime = static_cast<RuntimeBinding*>(context)->runtime;
                    return runtime == nullptr || static_cast<bool>(runtime->processLifecycle());
                }});
        }
    };

    [[nodiscard]] SimulationSystemRegistration probeRegistration() noexcept
    {
        return {
            .type = system::systemTypeId(ProbeSystem::Description.type.canonical_name),
            .cpp_type = cxx::typeToken<ProbeSystem>(),
            .description = &ProbeSystem::Description,
            .access = ProbeSystem::Access.spec(),
            .configuration = {},
            .install = &installProbe
        };
    }

    struct TestProvider final
    {
        std::int32_t value{};
        std::size_t calls{};
        std::size_t eager_starts{};
        std::uint64_t checksum{};

        static lux::script::ScriptAbilityErasedCallResult write(
            void* opaque,
            const void*,
            std::span<const lux::script::ScriptAbilityInputSlot> arguments,
            std::span<lux::script::ScriptAbilityOutputSlot> results
        ) noexcept
        {
            if (arguments.size() != 1U || arguments.front().data == nullptr || !results.empty())
                return lux::cxx::unexpected(lux::script::ScriptAbilityOperationError{91});
            auto& self = *static_cast<TestProvider*>(opaque);
            self.value = *static_cast<const std::int32_t*>(arguments.front().data);
            self.checksum += static_cast<std::uint32_t>(self.value);
            ++self.calls;
            return {};
        }

        static lux::script::ScriptAbilityErasedCallResult read(
            void* opaque,
            const void*,
            std::span<const lux::script::ScriptAbilityInputSlot> arguments,
            std::span<lux::script::ScriptAbilityOutputSlot> results
        ) noexcept
        {
            if (arguments.size() != 1U || arguments.front().data == nullptr || results.size() != 1U ||
                results.front().data == nullptr)
            {
                return lux::cxx::unexpected(lux::script::ScriptAbilityOperationError{94});
            }
            auto& self = *static_cast<TestProvider*>(opaque);
            *static_cast<std::int32_t*>(results.front().data) =
                self.value + *static_cast<const std::int32_t*>(arguments.front().data);
            ++self.calls;
            return {};
        }

        static lux::script::ScriptAbilityStartResult eager(
            void* opaque,
            const void*,
            std::span<const lux::script::ScriptAbilityInputSlot> arguments,
            lux::script::ScriptAbilityErasedCompletion completion
        ) noexcept
        {
            if (!arguments.empty())
                return lux::cxx::unexpected(lux::script::ScriptAbilityOperationError{92});
            auto& self = *static_cast<TestProvider*>(opaque);
            ++self.eager_starts;
            const auto completed = completion.success();
            if (!completed)
                return lux::cxx::unexpected(lux::script::ScriptAbilityOperationError{93});
            return {};
        }
    };

    static constexpr auto kI32 = lux::script::makeScriptAbilityValue<std::int32_t>(
        lux::script::EScriptAbilityValueLifetime::OWNED_VALUE
    );
    static constexpr std::array kWriteParameters{
        lux::script::ScriptAbilityParameterDescription{"value", kI32}
    };
    static constexpr std::array kTestMethods{
        lux::script::ScriptAbilityMethodDescription{
            kTestMethod,
            "write",
            "Write",
            lux::script::EScriptApiMethodKind::COMMAND,
            kWriteParameters,
            {}
        },
        lux::script::ScriptAbilityMethodDescription{
            kReadMethod,
            "read",
            "Read",
            lux::script::EScriptApiMethodKind::QUERY,
            kWriteParameters,
            std::span{&kI32, 1U}
        },
        lux::script::ScriptAbilityMethodDescription{
            kEagerMethod,
            "eager",
            "Eager",
            lux::script::EScriptApiMethodKind::ASYNC_OPERATION,
            {},
            {}
        }
    };
    static constexpr lux::script::ScriptAbilityDescription kTestAbility{
        kTestContract,
        "RuntimeTest",
        "Runtime Test",
        1U,
        kTestSchema,
        lux::script::EScriptAbilityReceiverKind::PROVIDER_INSTANCE,
        kTestMethods
    };

    void writeDirect(void* opaque, const void*, std::int32_t value) noexcept
    {
        auto& provider = *static_cast<TestProvider*>(opaque);
        provider.value = value;
        provider.checksum += static_cast<std::uint32_t>(value);
        ++provider.calls;
    }

    std::int32_t readDirect(void* opaque, const void*, std::int32_t value) noexcept
    {
        auto& provider = *static_cast<TestProvider*>(opaque);
        ++provider.calls;
        return provider.value + value;
    }

    int eagerDirect(
        void* invocation,
        void* opaque,
        const void*,
        lux_script_async_token* waiting_on
    ) noexcept
    {
        return lux::simulation::script::detail::startNativeAbility<void>(
            invocation,
            waiting_on,
            [opaque](lux::script::ScriptAbilityCompletion<void> completion) noexcept {
                auto& provider = *static_cast<TestProvider*>(opaque);
                ++provider.eager_starts;
                const auto completed = completion.success();
                return completed
                    ? lux::script::ScriptAbilityStartResult{}
                    : lux::script::ScriptAbilityStartResult{lux::cxx::unexpected(
                        lux::script::ScriptAbilityOperationError{93}
                    )};
            }
        );
    }

    inline const std::array kTestNativeMethods{
        lux::script::native::ScriptAbilityNativeMethodProjection{
            kTestMethod,
            reinterpret_cast<lux_script_ability_direct_entry_fn>(&writeDirect)
        },
        lux::script::native::ScriptAbilityNativeMethodProjection{
            kReadMethod,
            reinterpret_cast<lux_script_ability_direct_entry_fn>(&readDirect)
        },
        lux::script::native::ScriptAbilityNativeMethodProjection{
            kEagerMethod,
            reinterpret_cast<lux_script_ability_direct_entry_fn>(&eagerDirect)
        }
    };
    inline const lux::script::native::ScriptAbilityNativeContribution kTestNativeContribution{
        std::addressof(kTestAbility),
        kTestNativeMethods
    };
    inline const std::array kNativeContributions{
        kTestNativeContribution,
        lux::script::native::makeScriptAbilityNativeContribution<DelayAbility>()
    };
    static constexpr std::array kTestErasedMethods{
        lux::script::ScriptAbilityErasedMethodBinding{
            kTestMethod,
            lux::script::EScriptApiMethodKind::COMMAND,
            kWriteParameters,
            {},
            &TestProvider::write,
            nullptr
        },
        lux::script::ScriptAbilityErasedMethodBinding{
            kReadMethod,
            lux::script::EScriptApiMethodKind::QUERY,
            kWriteParameters,
            std::span{&kI32, 1U},
            &TestProvider::read,
            nullptr
        },
        lux::script::ScriptAbilityErasedMethodBinding{
            kEagerMethod,
            lux::script::EScriptApiMethodKind::ASYNC_OPERATION,
            {},
            {},
            nullptr,
            &TestProvider::eager
        }
    };
    static constexpr std::array kTestNodes{
        lux::flowforge::ScriptAbilityNodeDescription{
            kTestContract,
            kTestMethod,
            "Runtime Test",
            "Write",
            1U,
            kTestSchema,
            lux::script::EScriptAbilityReceiverKind::PROVIDER_INSTANCE,
            lux::script::EScriptApiMethodKind::COMMAND,
            kWriteParameters,
            {}
        },
        lux::flowforge::ScriptAbilityNodeDescription{
            kTestContract,
            kReadMethod,
            "Runtime Test",
            "Read",
            1U,
            kTestSchema,
            lux::script::EScriptAbilityReceiverKind::PROVIDER_INSTANCE,
            lux::script::EScriptApiMethodKind::QUERY,
            kWriteParameters,
            std::span{&kI32, 1U}
        },
        lux::flowforge::ScriptAbilityNodeDescription{
            kTestContract,
            kEagerMethod,
            "Runtime Test",
            "Eager",
            1U,
            kTestSchema,
            lux::script::EScriptAbilityReceiverKind::PROVIDER_INSTANCE,
            lux::script::EScriptApiMethodKind::ASYNC_OPERATION,
            {},
            {}
        }
    };

    [[nodiscard]] flowforge::FlowGraph makeGraph(
        const flowforge::ScriptAbilityNodeDescription& next_step
    )
    {
        flowforge::FlowGraph graph;
        const auto* i32 = &meta::ref_type_of_v<std::int32_t>;
        const auto counter = graph.addVariable("counter", i32, meta::RuntimeObject(std::int32_t{}));
        const flowforge::DataPinInfo counter_info{"counter", i32};
        auto event = std::make_unique<flowforge::OnEventNode>("tick");
        auto eager = std::make_unique<flowforge::ScriptAbilityNode>(kTestNodes[2]);
        auto next = std::make_unique<flowforge::ScriptAbilityNode>(next_step);
        auto get = std::make_unique<flowforge::GetVariableNode>(counter, counter_info);
        auto add = std::make_unique<flowforge::BinaryOpNode>(flowforge::ENodeOperation::ADD, i32);
        auto set = std::make_unique<flowforge::SetVariableNode>(counter, counter_info);
        auto write = std::make_unique<flowforge::ScriptAbilityNode>(kTestNodes.front());
        assert(const_cast<flowforge::DataInPin&>(add->rhs()).setConstantData(meta::RuntimeObject(std::int32_t{111})));
        auto* event_ptr = event.get();
        auto* eager_ptr = eager.get();
        auto* next_ptr = next.get();
        auto* get_ptr = get.get();
        auto* add_ptr = add.get();
        auto* set_ptr = set.get();
        auto* write_ptr = write.get();
        const auto event_slot = graph.addNodes(std::move(event));
        graph.addNodes(std::move(eager));
        graph.addNodes(std::move(next));
        graph.addNodes(std::move(get));
        graph.addNodes(std::move(add));
        graph.addNodes(std::move(set));
        graph.addNodes(std::move(write));
        flowforge::LastLink previous;
        assert(event_ptr->execOutPin().linkTo(&eager_ptr->execInPin(), previous) == flowforge::ELinkError::SUCCESS);
        assert(eager_ptr->execOutPin().linkTo(&next_ptr->execInPin(), previous) == flowforge::ELinkError::SUCCESS);
        assert(next_ptr->execOutPin().linkTo(&set_ptr->execInPin(), previous) == flowforge::ELinkError::SUCCESS);
        assert(set_ptr->execOutPin().linkTo(&write_ptr->execInPin(), previous) == flowforge::ELinkError::SUCCESS);
        assert(const_cast<flowforge::DataOutPin&>(get_ptr->valuePin()).linkTo(
            const_cast<flowforge::DataInPin*>(&add_ptr->lhs()), previous) == flowforge::ELinkError::SUCCESS);
        assert(const_cast<flowforge::DataOutPin&>(add_ptr->result()).linkTo(
            const_cast<flowforge::DataInPin*>(&set_ptr->valueIn()), previous) == flowforge::ELinkError::SUCCESS);
        assert(const_cast<flowforge::DataOutPin&>(set_ptr->valueOut()).linkTo(
            write_ptr->parameterPins().front().get(), previous) == flowforge::ELinkError::SUCCESS);
        assert(graph.addExport({
            flowforge::FlowForgeExportNodeId{1U},
            graph.getNode(event_slot).node->id(),
            kTickSymbol,
            {{lux::script::EScriptBindingHintKind::HOOK, "probe.tick"}}
        }));
        return graph;
    }

    [[nodiscard]] flowforge::FlowGraph makeSyncGraph()
    {
        flowforge::FlowGraph graph;
        const auto* i32 = &meta::ref_type_of_v<std::int32_t>;
        const auto counter = graph.addVariable("counter", i32, meta::RuntimeObject(std::int32_t{}));
        const flowforge::DataPinInfo counter_info{"counter", i32};
        auto event = std::make_unique<flowforge::OnEventNode>("tick");
        auto get = std::make_unique<flowforge::GetVariableNode>(counter, counter_info);
        auto add = std::make_unique<flowforge::BinaryOpNode>(flowforge::ENodeOperation::ADD, i32);
        auto set = std::make_unique<flowforge::SetVariableNode>(counter, counter_info);
        auto write = std::make_unique<flowforge::ScriptAbilityNode>(kTestNodes.front());
        auto read = std::make_unique<flowforge::ScriptAbilityNode>(kTestNodes[1]);
        assert(const_cast<flowforge::DataInPin&>(add->rhs()).setConstantData(meta::RuntimeObject(std::int32_t{17})));
        assert(read->parameterPins().front()->setConstantData(meta::RuntimeObject(std::int32_t{1})));
        auto* event_ptr = event.get();
        auto* write_ptr = write.get();
        auto* read_ptr = read.get();
        auto* get_ptr = get.get();
        auto* add_ptr = add.get();
        auto* set_ptr = set.get();
        const auto event_slot = graph.addNodes(std::move(event));
        graph.addNodes(std::move(write));
        graph.addNodes(std::move(read));
        graph.addNodes(std::move(get));
        graph.addNodes(std::move(add));
        graph.addNodes(std::move(set));
        flowforge::LastLink previous;
        assert(event_ptr->execOutPin().linkTo(&set_ptr->execInPin(), previous) == flowforge::ELinkError::SUCCESS);
        assert(set_ptr->execOutPin().linkTo(&write_ptr->execInPin(), previous) == flowforge::ELinkError::SUCCESS);
        assert(write_ptr->execOutPin().linkTo(&read_ptr->execInPin(), previous) == flowforge::ELinkError::SUCCESS);
        assert(const_cast<flowforge::DataOutPin&>(get_ptr->valuePin()).linkTo(
            const_cast<flowforge::DataInPin*>(&add_ptr->lhs()), previous) == flowforge::ELinkError::SUCCESS);
        assert(const_cast<flowforge::DataOutPin&>(add_ptr->result()).linkTo(
            const_cast<flowforge::DataInPin*>(&set_ptr->valueIn()), previous) == flowforge::ELinkError::SUCCESS);
        assert(const_cast<flowforge::DataOutPin&>(set_ptr->valueOut()).linkTo(
            write_ptr->parameterPins().front().get(), previous) == flowforge::ELinkError::SUCCESS);
        assert(graph.addExport({
            flowforge::FlowForgeExportNodeId{2U},
            graph.getNode(event_slot).node->id(),
            kTickSymbol,
            {{lux::script::EScriptBindingHintKind::HOOK, "Probe.tick"}}
        }));
        return graph;
    }

    [[nodiscard]] lux::script::ScriptEventSourceDescription eventSource()
    {
        SimulationDescriptionBuilder builder;
        assert(builder.addSystem(kProbeSystem, "Probe", ProbeSystem::Description));
        assert(addProbeExecution(builder));
        auto simulation = std::move(builder).build();
        assert(simulation);
        const auto hook = simulation->findHookPoint(kProbeSystem, kTickHook);
        return {
            "Probe",
            "payload",
            kProbeSystem.value,
            kPayloadEvent.value,
            lux::script::EScriptEventRoute::SIMULATION_BROADCAST,
            {
                "lux.i32",
                lux::semantic::typeId("lux.i32"),
                LUX_SCRIPT_VK_INT32,
                sizeof(std::int32_t),
                alignof(std::int32_t)
            },
            lux::semantic::typeId("lux.i32"),
            1U, hook.id().value, hook.contractHash(), hook.contractVersion()
        };
    }

    [[nodiscard]] flowforge::FlowGraph makeEventWaitGraph(
        const lux::script::ScriptEventSourceDescription& source
    )
    {
        flowforge::FlowGraph graph;
        auto event = std::make_unique<flowforge::OnEventNode>("wait_event");
        auto wait = std::make_unique<flowforge::ScriptEventAwaitNode>(source);
        auto write = std::make_unique<flowforge::ScriptAbilityNode>(kTestNodes.front());
        auto* event_pointer = event.get();
        auto* wait_pointer = wait.get();
        auto* write_pointer = write.get();
        const auto event_slot = graph.addNodes(std::move(event));
        graph.addNodes(std::move(wait));
        graph.addNodes(std::move(write));
        flowforge::LastLink previous;
        assert(event_pointer->execOutPin().linkTo(&wait_pointer->execInPin(), previous) ==
            flowforge::ELinkError::SUCCESS);
        assert(wait_pointer->execOutPin().linkTo(&write_pointer->execInPin(), previous) ==
            flowforge::ELinkError::SUCCESS);
        assert(const_cast<flowforge::DataOutPin&>(wait_pointer->payloadPin()).linkTo(
            write_pointer->parameterPins().front().get(),
            previous
        ) == flowforge::ELinkError::SUCCESS);
        assert(graph.addExport({
            flowforge::FlowForgeExportNodeId{4U},
            graph.getNode(event_slot).node->id(),
            kEventWaitSymbol
        }));
        return graph;
    }

    [[nodiscard]] flowforge::FlowGraph makeSequenceGraph(
        const lux::script::ScriptEventSourceDescription& source,
        const flowforge::ScriptAbilityNodeDescription& next_step,
        const flowforge::ScriptAbilityNodeDescription& simulation_delay
    )
    {
        using namespace flowforge;
        FlowGraph graph;
        const auto* i32 = &meta::ref_type_of_v<std::int32_t>;
        const auto counter = graph.addVariable("counter", i32, meta::RuntimeObject(std::int32_t{1}));
        const DataPinInfo info{"counter", i32};
        auto entry = std::make_unique<OnEventNode>("sequence");
        auto get = std::make_unique<GetVariableNode>(counter, info);
        auto increment = std::make_unique<BinaryOpNode>(ENodeOperation::ADD, i32);
        auto set = std::make_unique<SetVariableNode>(counter, info);
        auto next = std::make_unique<ScriptAbilityNode>(next_step);
        auto wait = std::make_unique<ScriptEventAwaitNode>(source);
        auto delay = std::make_unique<ScriptAbilityNode>(simulation_delay);
        auto combine = std::make_unique<BinaryOpNode>(ENodeOperation::ADD, i32);
        auto write = std::make_unique<ScriptAbilityNode>(kTestNodes.front());
        assert(const_cast<DataInPin&>(increment->rhs()).setConstantData(meta::RuntimeObject(std::int32_t{1})));
        assert(delay->parameterPins().front()->setConstantData(meta::RuntimeObject(0.001)));
        auto* entry_ptr = entry.get();
        auto* get_ptr = get.get();
        auto* increment_ptr = increment.get();
        auto* set_ptr = set.get();
        auto* next_ptr = next.get();
        auto* wait_ptr = wait.get();
        auto* delay_ptr = delay.get();
        auto* combine_ptr = combine.get();
        auto* write_ptr = write.get();
        const auto entry_slot = graph.addNodes(std::move(entry));
        graph.addNodes(std::move(get));
        graph.addNodes(std::move(increment));
        graph.addNodes(std::move(set));
        graph.addNodes(std::move(next));
        graph.addNodes(std::move(wait));
        graph.addNodes(std::move(delay));
        graph.addNodes(std::move(combine));
        graph.addNodes(std::move(write));
        LastLink previous;
        assert(entry_ptr->execOutPin().linkTo(&set_ptr->execInPin(), previous) == ELinkError::SUCCESS);
        assert(set_ptr->execOutPin().linkTo(&next_ptr->execInPin(), previous) == ELinkError::SUCCESS);
        assert(next_ptr->execOutPin().linkTo(&wait_ptr->execInPin(), previous) == ELinkError::SUCCESS);
        assert(wait_ptr->execOutPin().linkTo(&delay_ptr->execInPin(), previous) == ELinkError::SUCCESS);
        assert(delay_ptr->execOutPin().linkTo(&write_ptr->execInPin(), previous) == ELinkError::SUCCESS);
        assert(const_cast<DataOutPin&>(get_ptr->valuePin()).linkTo(
            const_cast<DataInPin*>(&increment_ptr->lhs()), previous) == ELinkError::SUCCESS);
        assert(const_cast<DataOutPin&>(increment_ptr->result()).linkTo(
            const_cast<DataInPin*>(&set_ptr->valueIn()), previous) == ELinkError::SUCCESS);
        assert(const_cast<DataOutPin&>(set_ptr->valueOut()).linkTo(
            const_cast<DataInPin*>(&combine_ptr->lhs()), previous) == ELinkError::SUCCESS);
        assert(const_cast<DataOutPin&>(wait_ptr->payloadPin()).linkTo(
            const_cast<DataInPin*>(&combine_ptr->rhs()), previous) == ELinkError::SUCCESS);
        assert(const_cast<DataOutPin&>(combine_ptr->result()).linkTo(
            write_ptr->parameterPins().front().get(), previous) == ELinkError::SUCCESS);
        assert(graph.addExport({FlowForgeExportNodeId{5U}, graph.getNode(entry_slot).node->id(), kEventWaitSymbol}));
        return graph;
    }

    [[nodiscard]] flowforge::FlowGraph makeQueryGraph()
    {
        flowforge::FlowGraph graph;
        auto event = std::make_unique<flowforge::OnEventNode>("tick");
        auto read = std::make_unique<flowforge::ScriptAbilityNode>(kTestNodes[1]);
        assert(read->parameterPins().front()->setConstantData(meta::RuntimeObject(std::int32_t{1})));
        auto* event_ptr = event.get();
        auto* read_ptr = read.get();
        const auto event_slot = graph.addNodes(std::move(event));
        graph.addNodes(std::move(read));
        flowforge::LastLink previous;
        assert(event_ptr->execOutPin().linkTo(&read_ptr->execInPin(), previous) == flowforge::ELinkError::SUCCESS);
        assert(graph.addExport({
            flowforge::FlowForgeExportNodeId{3U},
            graph.getNode(event_slot).node->id(),
            kTickSymbol
        }));
        return graph;
    }

    struct ArtifactSource final
    {
        const lux::script::ScriptArtifact* artifact{};
        const lux::script::NativeModule* module{};

        static bool resolveArtifact(
            void* opaque,
            const asset::AssetId& requested,
            ResolvedScriptArtifact& result
        ) noexcept
        {
            const auto& self = *static_cast<ArtifactSource*>(opaque);
            if (requested != assetId())
                return false;
            result.artifact = self.artifact;
            return true;
        }

        static bool resolveModule(
            void* opaque,
            const asset::AssetId& requested,
            const lux::script::ScriptArtifact&,
            ResolvedNativeModule& result
        ) noexcept
        {
            const auto& self = *static_cast<ArtifactSource*>(opaque);
            if (requested != assetId())
                return false;
            result.module = self.module;
            return true;
        }
    };

    struct BenchmarkOptions final
    {
        std::string group;
        std::size_t size{2500U};
        std::size_t frames{30U};
        std::size_t warmups{5U};
        std::size_t resume_budget{2000U};
        std::uint64_t seed{0x5EED2026ULL};
        std::filesystem::path output{"flowforge_script_runtime_benchmark.csv"};
    };

    [[nodiscard]] bool parseSize(std::string_view text, std::size_t& value) noexcept
    {
        const auto parsed = std::from_chars(text.data(), text.data() + text.size(), value);
        return parsed.ec == std::errc{} && parsed.ptr == text.data() + text.size() && value != 0U;
    }

    [[nodiscard]] std::optional<BenchmarkOptions> parseBenchmarkOptions(int argc, char** argv)
    {
        if (argc == 1)
            return std::nullopt;
        BenchmarkOptions result;
        for (int index{1}; index < argc; ++index)
        {
            if (index + 1 >= argc)
                return std::nullopt;
            const std::string_view key{argv[index++]};
            const std::string_view value{argv[index]};
            if (key == "--group")
                result.group = value;
            else if (key == "--size")
            {
                if (!parseSize(value, result.size))
                    return std::nullopt;
            }
            else if (key == "--frames")
            {
                if (!parseSize(value, result.frames))
                    return std::nullopt;
            }
            else if (key == "--warmups")
            {
                if (!parseSize(value, result.warmups))
                    return std::nullopt;
            }
            else if (key == "--resume-budget")
            {
                if (!parseSize(value, result.resume_budget))
                    return std::nullopt;
            }
            else if (key == "--seed")
            {
                const auto parsed = std::from_chars(value.data(), value.data() + value.size(), result.seed);
                if (parsed.ec != std::errc{} || parsed.ptr != value.data() + value.size())
                    return std::nullopt;
            }
            else if (key == "--output")
                result.output = value;
            else if (key == "--mode")
            {
                if (value == "performance" && result.warmups == 5U && result.frames == 30U)
                {
                    result.warmups = 300U;
                    result.frames = 5000U;
                }
                else if (value != "diagnostic" && value != "performance")
                    return std::nullopt;
            }
            else
                return std::nullopt;
        }
        constexpr std::array groups{
            std::string_view{"micro-flowforge-sync"},
            std::string_view{"micro-flowforge-ability-query"},
            std::string_view{"micro-flowforge-suspend"},
            std::string_view{"micro-flowforge-resume"},
            std::string_view{"scene-flowforge-update-heavy"},
            std::string_view{"scene-flowforge-gameplay-mixed"},
            std::string_view{"scene-flowforge-suspended-idle"},
            std::string_view{"scene-flowforge-resume-storm"},
            std::string_view{"micro-flowforge-event"},
            std::string_view{"scene-flowforge-event"},
            std::string_view{"scene-flowforge-event-idle"},
            std::string_view{"scene-flowforge-event-storm"},
            std::string_view{"scene-flowforge-sequence"}
        };
        return std::ranges::find(groups, result.group) == groups.end()
            ? std::nullopt
            : std::optional<BenchmarkOptions>{std::move(result)};
    }
}

namespace
{
    int runBenchmark(const BenchmarkOptions& options)
    {
        using Clock = std::chrono::steady_clock;
        using namespace lux;
        using namespace lux::simulation;
        using namespace lux::simulation::script;
    using namespace lux::scene::script;
        const bool query_only = options.group == "micro-flowforge-ability-query";
        const bool sync = options.group == "micro-flowforge-sync" || query_only ||
            options.group == "scene-flowforge-update-heavy";
        const bool idle = options.group == "scene-flowforge-suspended-idle";
        const bool storm = options.group == "scene-flowforge-resume-storm" ||
            options.group == "micro-flowforge-resume";
        const bool suspend_only = options.group == "micro-flowforge-suspend";
        const bool sequence = options.group == "scene-flowforge-sequence";
        const bool event_mode = sequence || options.group.find("flowforge-event") != std::string::npos;
        const bool event_idle = options.group == "scene-flowforge-event-idle";
        const bool event_storm = options.group == "scene-flowforge-event-storm";
        g_hook_capacity = options.size;

        flowforge::ScriptAbilityNodeCatalog catalog;
        if (!catalog.add(flowforge::makeScriptAbilityCatalogContribution<DelayAbility>()) ||
            !catalog.add({kTestNodes}))
        {
            return 10;
        }
        const auto* next_step = catalog.view().find(
            lux::script::ScriptApiContractIdView{"lux.simulation.delay"},
            lux::script::ScriptApiMethodIdView{"lux.simulation.delay.next_step"}
        );
        if (next_step == nullptr)
            return 11;
        const auto* simulation_delay = catalog.view().find(
            lux::script::ScriptApiContractIdView{"lux.simulation.delay"},
            lux::script::ScriptApiMethodIdView{"lux.simulation.delay.simulation_seconds"});
        if (simulation_delay == nullptr) return 11;
        const auto event_source = eventSource();
        auto graph = sequence ? makeSequenceGraph(event_source, *next_step, *simulation_delay) :
            event_mode ? makeEventWaitGraph(event_source) :
            query_only ? makeQueryGraph() : sync ? makeSyncGraph() : makeGraph(*next_step);
        const auto module_name = event_mode ? "lux.benchmark.flowforge.event" :
            sync ? "lux.benchmark.flowforge.sync" : "lux.benchmark.flowforge.async";
        auto artifact = flowforge::compileFlowForgeScript(
            graph,
            flowforge::FlowForgeCompileOptions{
                .module_name = module_name,
                .script_abilities = catalog.view(),
                .script_events = event_mode ? std::span{&event_source, 1U} :
                    std::span<const lux::script::ScriptEventSourceDescription>{}
            }
        );
        if (!artifact)
        {
            std::fprintf(
                stderr,
                "FlowForge benchmark compile failed: %u %s\n",
                static_cast<unsigned>(artifact.error().code),
                artifact.error().message.c_str()
            );
            return 12;
        }
        auto native_module = lux::script::loadNativeModule(
            artifact->payload(),
            module_name
        );
        if (!native_module)
            return 13;

        SimulationDescriptionBuilder simulation_builder;
        if (!simulation_builder.addSystem(kProbeSystem, "probe", ProbeSystem::Description))
            return 14;
        if (!addProbeExecution(simulation_builder))
            return 14;
        auto simulation_description = std::move(simulation_builder).build();
        if (!simulation_description)
            return 15;
        ecs::Registry registry;
        SimulationSystemRegistry system_types;
        if (!system_types.add(probeRegistration()))
            return 16;
        auto simulation = Simulation::create(
            registry,
            std::make_shared<SimulationDescription>(std::move(*simulation_description)),
            system_types
        );
        if (!simulation)
            return 17;

        ScriptSystemDescriptionBuilder script_builder;
        for (std::size_t index{}; index < options.size; ++index)
        {
            if (!script_builder.addMount({
                ScriptMountId{index + 1U},
                assetId(),
                SimulationScriptMount{},
                true,
                {{event_mode ? kEventWaitSymbol : kTickSymbol, HookScriptTarget{kProbeSystem, kTickHook}}}
            }))
            {
                return 18;
            }
        }
        auto script_description = std::move(script_builder).build(simulation->description());
        if (!script_description)
            return 19;

        ArtifactSource source{std::addressof(*artifact), std::addressof(*native_module)};
        NativeScriptBackend backend{
            {std::addressof(source), &ArtifactSource::resolveModule},
            NativeScriptBackendConfig{
                .module_capacity = 1U,
                .instance_capacity = options.size,
                .prepared_call_capacity = options.size * (sync ? 1U : 2U),
                .continuation_capacity = options.size,
                .max_ability_imports_per_module = 4U,
                .max_continuation_frame_bytes = 8192U,
                .continuation_frame_storage_bytes =
                    2U * ((std::max)(std::size_t{8192U}, options.size * 256U)) + 4096U,
                .abilities = kNativeContributions,
                .storage_populations = std::array{
                    lux::simulation::script::NativeScriptStoragePopulation{
                        std::addressof(*native_module), options.size, options.size
                    }
                },
                .state_storage_bytes = 64U * 1024U * 1024U
            }
        };
        if (!backend)
            return 20;
        TestProvider provider;
        const lux::script::ScriptAbilityBinding test_binding{
            &kTestAbility,
            std::addressof(provider),
            std::addressof(provider),
            kTestErasedMethods
        };
        const std::array capabilities{publishScriptAbility(test_binding)};
        const auto backend_descriptor = backend.descriptor();
        auto system = ScriptSystem::create(
            simulation->description(),
            *planScriptRuntimeCapacity(*script_description),
            *resolveScriptRuntimeMounts(*script_description, {}, registry),
            registry,
            simulation->clock(),
            ScriptRuntimeLimits{
            16U,
            options.size,
            options.size,
            1U,
            options.size,
            options.size,
            64U,
            (std::min)(options.resume_budget, options.size),
            options.size,
            options.size,
            options.size,
            options.size
            },
            {std::addressof(source), &ArtifactSource::resolveArtifact},
            capabilities,
            std::span{&backend_descriptor, 1U},
            simulation->scriptHookEndpoints(),
            simulation->scriptEventEndpoints()
        );
        if (!system)
            return 21;
        const auto prepared = system->prepare();
        if (!prepared)
        {
            std::fprintf(stderr, "FlowForge benchmark prepare failed: %u\n", static_cast<unsigned>(prepared.error()));
            return 21;
        }
        auto executor = task::TaskExecutor::create({0U, 1U});
        if (!executor)
            return 22;
        RuntimeBinding runtime_binding{&*system};
        auto hook_connection = runtime_binding.bind(*simulation);
        if (!hook_connection)
            return 22;
        std::uint64_t previous_resumes{};
        const auto normal_frame = [&] {
            if (event_mode)
                g_probe->pending_payload = 31;
            const auto executed = simulation->execute(*executor, SimulationDuration{sequence ? 16'666'667 : 1});
            const auto resumes = system->stats().backend_resume_calls;
            const bool budget_ok = resumes - previous_resumes <= options.resume_budget;
            previous_resumes = resumes;
            return executed.has_value() && budget_ok;
        };
        if (idle || storm || event_idle || event_storm)
        {
            if (!simulation->execute(*executor, SimulationDuration{1}))
                return 23;
            if (event_storm)
                g_probe->pending_payload = 37;
            g_probe->tick_enabled = false;
            while (!event_storm && system->stats().resume_queue_depth != 0U)
            {
                if (!simulation->execute(*executor, SimulationDuration{1}))
                    return 23;
            }
        }
        else if (!suspend_only)
        {
            for (std::size_t frame{}; frame < options.warmups; ++frame)
            {
                if (!normal_frame())
                    return 25;
            }
        }

        std::error_code directory_error;
        if (!options.output.parent_path().empty())
            std::filesystem::create_directories(options.output.parent_path(), directory_error);
        std::ofstream output(options.output, std::ios::trunc);
        if (!output)
            return 26;
        output << "git_commit,build_type,scenario,backend,size,seed,frame,nanoseconds,active_instances,calls,"
                  "continuations,awaitables,event_waiters,event_dispatch_visits,queue_depth,queue_high_water,"
                  "continuation_frame_bytes,artifact_bytes,checksum,started,resumes,suspensions,completed,phase\n";
        const auto* exported = native_module->findFunction(event_mode ? kEventWaitSymbol : kTickSymbol);
        const auto frame_bytes = exported != nullptr && exported->step != nullptr ? exported->step->frame_size : 0U;
        bool draining{};
        const auto record = [&](std::size_t frame, std::uint64_t nanoseconds) {
            const auto stats = system->stats();
            output << LUX_BENCHMARK_GIT_COMMIT << ',' << LUX_BENCHMARK_BUILD_TYPE << ',' << options.group
                   << ",flowforge-aot," << options.size << ',' << options.seed << ',' << frame << ',' << nanoseconds
                   << ',' << stats.active_instances << ',' << provider.calls << ',' << stats.active_continuations << ','
                   << stats.active_awaitables << ',' << stats.active_event_waiters << ','
                   << stats.event_waiter_dispatch_visits << ',' << stats.resume_queue_depth << ','
                   << stats.resume_queue_high_water
                   << ',' << frame_bytes << ',' << artifact->payload().size() << ','
                   << (provider.checksum ^ provider.calls) << ',' << stats.step_invocations << ','
                   << stats.backend_resume_calls << ',' << stats.suspensions_admitted << ','
                   << (sequence ? provider.calls : 0U) << ',' << (draining ? "drain" : "steady") << '\n';
        };

        if (suspend_only)
        {
            const auto begin = Clock::now();
            if (!simulation->execute(*executor, SimulationDuration{1}))
                return 27;
            record(0U, std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now() - begin).count());
        }
        else if (storm || event_storm)
        {
            std::size_t frame{};
            do
            {
                const auto begin = Clock::now();
                if (!simulation->execute(*executor, SimulationDuration{1}))
                    return 28;
                record(frame++, std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now() - begin).count());
            } while (system->activeContinuationCount() != 0U && frame < options.frames);
            const auto expected_frames = (options.size + options.resume_budget - 1U) / options.resume_budget;
            if (event_storm && frame != expected_frames)
                return 31;
        }
        else
        {
            for (std::size_t frame{}; frame < options.frames; ++frame)
            {
                const auto begin = Clock::now();
                const bool success = idle || event_idle ?
                    static_cast<bool>(simulation->execute(*executor, SimulationDuration{1})) :
                    normal_frame();
                const auto elapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now() - begin).count();
                if (!success)
                    return 29;
                record(frame, elapsed);
            }
        }
        if (sequence)
        {
            draining = true;
            g_probe->tick_enabled = false;
            std::size_t drain{};
            const auto max_drain = 3U * ((options.size + options.resume_budget - 1U) / options.resume_budget) + 64U;
            while (system->activeContinuationCount() != 0U)
            {
                if (drain >= max_drain) return 32;
                const auto begin = Clock::now();
                if (!normal_frame()) return 33;
                record(drain++, std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now() - begin).count());
            }
            const auto stats = system->stats();
            if (stats.step_invocations == 0U || stats.step_invocations != provider.calls ||
                stats.suspensions_admitted != 3U * provider.calls || stats.backend_resume_calls != 3U * provider.calls ||
                stats.active_awaitables != 0U || stats.active_event_waiters != 0U) return 34;
        }
        // Observe integrity outside every measured interval. failures() contains retained records,
        // not a total-error counter; a full bounded log may have omitted additional failures.
        const auto retained = system->failures().size();
        const auto stopped_at = system->stats();
        std::printf("INTEGRITY,steady,retained=%zu,calls=%zu,checksum=%llu,queue=%zu,continuations=%zu,"
            "awaitables=%zu,waiters=%zu\n", retained, provider.calls, static_cast<unsigned long long>(provider.checksum),
            stopped_at.resume_queue_depth, stopped_at.active_continuations,
            stopped_at.active_awaitables, stopped_at.active_event_waiters);
        const bool closed = system->shutdown().has_value();
        const auto final = system->stats();
        const auto retained_after = system->failures().size();
        std::printf("INTEGRITY,shutdown,retained=%zu,calls=%zu,checksum=%llu,queue=%zu,continuations=%zu,"
            "awaitables=%zu,waiters=%zu\n", retained_after, provider.calls,
            static_cast<unsigned long long>(provider.checksum),
            final.resume_queue_depth, final.active_continuations, final.active_awaitables, final.active_event_waiters);
        const bool released = final.active_instances == 0U && final.active_continuations == 0U &&
            final.active_awaitables == 0U && final.active_event_waiters == 0U && final.resume_queue_depth == 0U;
        if (retained != 0U || retained_after != 0U || !released)
            return 35;
        return closed ? 0 : 30;
    }
}

int main(int argc, char** argv)
{
    if (argc > 1)
    {
        const auto options = parseBenchmarkOptions(argc, argv);
        return options ? runBenchmark(*options) : 2;
    }
    using namespace lux;
    using namespace lux::simulation;
    using namespace lux::simulation::script;
    using namespace lux::scene::script;

    flowforge::ScriptAbilityNodeCatalog catalog;
    assert(catalog.add(flowforge::makeScriptAbilityCatalogContribution<DelayAbility>()));
    assert(catalog.add({kTestNodes}));
    const auto* next_step = catalog.view().find(
        lux::script::ScriptApiContractIdView{"lux.simulation.delay"},
        lux::script::ScriptApiMethodIdView{"lux.simulation.delay.next_step"}
    );
    assert(next_step != nullptr);
    auto graph = makeGraph(*next_step);
    auto artifact = flowforge::compileFlowForgeScript(
        graph,
        flowforge::FlowForgeCompileOptions{
            .module_name = "lux.test.flowforge.runtime",
            .script_abilities = catalog.view()
        }
    );
    if (!artifact)
    {
        std::fprintf(
            stderr,
            "FlowForge runtime compile failed: %u %s\n",
            static_cast<unsigned>(artifact.error().code),
            artifact.error().message.c_str()
        );
    }
    assert(artifact);
    auto native_module = lux::script::loadNativeModule(artifact->payload(), "lux.test.flowforge.runtime");
    assert(native_module);

    SimulationDescriptionBuilder simulation_builder;
    assert(simulation_builder.addSystem(kProbeSystem, "probe", ProbeSystem::Description));
    assert(addProbeExecution(simulation_builder));
    auto simulation_description = std::move(simulation_builder).build();
    assert(simulation_description);
    ecs::Registry registry;
    SimulationSystemRegistry system_types;
    assert(system_types.add(probeRegistration()));
    auto simulation = Simulation::create(
        registry,
        std::make_shared<SimulationDescription>(std::move(*simulation_description)),
        system_types
    );
    assert(simulation);

    ScriptSystemDescriptionBuilder script_builder;
    const auto hints = flowforge::describeFlowForgeBindingHints(graph);
    assert(hints && hints->size() == 1U);
    const auto selected = selectScriptBindingFromHints(*artifact, kTickSymbol, simulation->description(),
        false, nullptr, *hints);
    assert(selected && selected->symbol == kTickSymbol);
    assert(script_builder.addMount({
        ScriptMountId{1U},
        assetId(),
        SimulationScriptMount{},
        true,
        {*selected}
    }));
    auto script_description = std::move(script_builder).build(simulation->description());
    assert(script_description);

    const ScriptSystemCodecLimits binding_limits{65536U, 65536U, 65536U};
    auto saved_bindings = encodeScriptSystemDescription(*script_description, binding_limits);
    assert(saved_bindings);
    const auto original_name = artifact->findExport(kTickSymbol)->name;
    graph.findNodeById(graph.exports().front().entry_node_id)->setName("renamed_script_entry");
    auto renamed_artifact = flowforge::compileFlowForgeScript(graph,
        {.module_name = "lux.test.flowforge.runtime", .script_abilities = catalog.view()});
    assert(renamed_artifact && renamed_artifact->findExport(kTickSymbol)->name != original_name);
    auto renamed_module = lux::script::loadNativeModule(renamed_artifact->payload(), "lux.test.flowforge.runtime");
    assert(renamed_module);
    *artifact = std::move(*renamed_artifact);
    *native_module = std::move(*renamed_module);
    script_description = decodeScriptSystemDescription(*saved_bindings, simulation->description(), binding_limits);
    assert(script_description && script_description->mounts().front().bindings.front().symbol == kTickSymbol);

    ArtifactSource source{std::addressof(*artifact), std::addressof(*native_module)};
    NativeScriptBackend backend{
        {std::addressof(source), &ArtifactSource::resolveModule},
        NativeScriptBackendConfig{
            .module_capacity = 1U,
            .instance_capacity = 1U,
            .prepared_call_capacity = 4U,
            .continuation_capacity = 2U,
            .max_ability_imports_per_module = 4U,
            .max_continuation_frame_bytes = 8192U,
            .continuation_frame_storage_bytes =
                2U * (16384U) + 4096U,
            .abilities = kNativeContributions,
            .storage_populations = std::array{
                lux::simulation::script::NativeScriptStoragePopulation{
                    std::addressof(*native_module), 1U, 2U
                }
            },
            .state_storage_bytes = 64U * 1024U * 1024U
        }
    };
    assert(backend);
    TestProvider provider;
    const lux::script::ScriptAbilityBinding test_binding{
        &kTestAbility,
        std::addressof(provider),
        std::addressof(provider),
        kTestErasedMethods
    };
    const std::array capabilities{publishScriptAbility(test_binding)};
    const auto backend_descriptor = backend.descriptor();
    auto missing = ScriptSystem::create(
        simulation->description(),
        *planScriptRuntimeCapacity(*script_description),
        *resolveScriptRuntimeMounts(*script_description, {}, registry),
        registry,
        simulation->clock(),
        ScriptRuntimeLimits{8U, 1U, 4U, 4U, 4U, 4U, 64U, 1U, 4U, 4U, 4U, 4U},
        {std::addressof(source), &ArtifactSource::resolveArtifact},
        {},
        std::span{&backend_descriptor, 1U},
        simulation->scriptHookEndpoints(),
        simulation->scriptEventEndpoints()
    );
    assert(missing);
    const auto missing_prepared = missing->prepare();
    assert(!missing_prepared && missing_prepared.error() == EScriptSystemError::SCRIPT_CAPABILITY_NOT_FOUND);
    assert(missing->shutdown());

    auto mismatch_capability = capabilities.front();
    ++mismatch_capability.schema_hash;
    const std::array mismatch_capabilities{mismatch_capability};
    auto mismatch = ScriptSystem::create(
        simulation->description(),
        *planScriptRuntimeCapacity(*script_description),
        *resolveScriptRuntimeMounts(*script_description, {}, registry),
        registry,
        simulation->clock(),
        ScriptRuntimeLimits{8U, 1U, 4U, 4U, 4U, 4U, 64U, 1U, 4U, 4U, 4U, 4U},
        {std::addressof(source), &ArtifactSource::resolveArtifact},
        mismatch_capabilities,
        std::span{&backend_descriptor, 1U},
        simulation->scriptHookEndpoints(),
        simulation->scriptEventEndpoints()
    );
    assert(mismatch);
    const auto mismatch_prepared = mismatch->prepare();
    assert(!mismatch_prepared && mismatch_prepared.error() == EScriptSystemError::SCRIPT_CAPABILITY_SCHEMA_MISMATCH);
    assert(mismatch->shutdown());

    auto system = ScriptSystem::create(
        simulation->description(),
        *planScriptRuntimeCapacity(*script_description),
        *resolveScriptRuntimeMounts(*script_description, {}, registry),
        registry,
        simulation->clock(),
        ScriptRuntimeLimits{8U, 1U, 4U, 4U, 4U, 4U, 64U, 1U, 4U, 4U, 4U, 4U},
        {std::addressof(source), &ArtifactSource::resolveArtifact},
        capabilities,
        std::span{&backend_descriptor, 1U},
        simulation->scriptHookEndpoints(),
        simulation->scriptEventEndpoints()
    );
    assert(system);
    assert(system->prepare());

    RuntimeBinding runtime_binding{&*system};
    auto hook_connection = runtime_binding.bind(*simulation);
    assert(hook_connection);

    auto executor = task::TaskExecutor::create({0U, 1U});
    assert(executor);
    assert(simulation->execute(*executor, SimulationDuration{1}));
    assert(system->activeContinuationCount() == 1U);
    assert(provider.eager_starts == 1U);
    assert(provider.calls == 0U);
    assert(system->activeContinuationCount() == 1U);
    assert(provider.calls == 0U);
    assert(simulation->execute(*executor, SimulationDuration{1}));
    assert(system->activeContinuationCount() == 1U);
    assert(simulation->execute(*executor, SimulationDuration{1}));
    assert(system->activeContinuationCount() == 0U);
    assert(system->activeAwaitableCount() == 0U);
    assert(provider.calls == 1U && provider.value == 111);
    assert(system->shutdown());
    runtime_binding.runtime = nullptr;

    const auto event_source = eventSource();
    auto event_graph = makeEventWaitGraph(event_source);
    auto event_artifact = flowforge::compileFlowForgeScript(
        event_graph,
        flowforge::FlowForgeCompileOptions{
            .module_name = "lux.test.flowforge.event-wait",
            .script_abilities = catalog.view(),
            .script_events = std::span{&event_source, 1U}
        }
    );
    assert(event_artifact);
    assert(event_artifact->description().event_requirements ==
        std::vector<lux::script::ScriptEventSourceDescription>{event_source});
    auto event_module = lux::script::loadNativeModule(
        event_artifact->payload(),
        "lux.test.flowforge.event-wait"
    );
    if (!event_module)
    {
        std::fprintf(
            stderr,
            "FlowForge Event module load failed: %u %s\n",
            static_cast<unsigned>(event_module.error().code),
            event_module.error().detail.c_str()
        );
    }
    assert(event_module);
    ScriptSystemDescriptionBuilder event_script_builder;
    assert(event_script_builder.addMount({
        ScriptMountId{2U},
        assetId(),
        SimulationScriptMount{},
        true,
        {{kEventWaitSymbol, HookScriptTarget{kProbeSystem, kTickHook}}}
    }));
    auto event_script_description = std::move(event_script_builder).build(simulation->description());
    assert(event_script_description);
    ArtifactSource event_artifact_source{
        std::addressof(*event_artifact),
        std::addressof(*event_module)
    };
    NativeScriptBackend event_backend{
        {std::addressof(event_artifact_source), &ArtifactSource::resolveModule},
        NativeScriptBackendConfig{
            .module_capacity = 1U,
            .instance_capacity = 1U,
            .prepared_call_capacity = 2U,
            .continuation_capacity = 2U,
            .max_ability_imports_per_module = 2U,
            .max_continuation_frame_bytes = 8192U,
            .continuation_frame_storage_bytes =
                2U * (16384U) + 4096U,
            .max_event_wait_imports_per_module = 2U,
            .abilities = kNativeContributions,
            .storage_populations = std::array{
                lux::simulation::script::NativeScriptStoragePopulation{
                    std::addressof(*event_module), 1U, 2U
                }
            },
            .state_storage_bytes = 64U * 1024U * 1024U
        }
    };
    assert(event_backend);
    auto mismatched_description = event_artifact->description();
    ++mismatched_description.event_requirements.front().payload_schema_version;
    auto mismatched_artifact = lux::script::ScriptArtifact::create(
        std::move(mismatched_description),
        std::vector<std::byte>(event_artifact->payload().begin(), event_artifact->payload().end())
    );
    assert(mismatched_artifact);
    ArtifactSource mismatched_source{std::addressof(*mismatched_artifact), std::addressof(*event_module)};
    NativeScriptBackend mismatched_backend{
        {std::addressof(mismatched_source), &ArtifactSource::resolveModule},
        NativeScriptBackendConfig{
            .module_capacity = 1U,
            .instance_capacity = 1U,
            .prepared_call_capacity = 2U,
            .continuation_capacity = 2U,
            .max_ability_imports_per_module = 2U,
            .max_continuation_frame_bytes = 8192U,
            .continuation_frame_storage_bytes =
                2U * (16384U) + 4096U,
            .max_event_wait_imports_per_module = 2U,
            .abilities = kNativeContributions,
            .storage_populations = std::array{
                lux::simulation::script::NativeScriptStoragePopulation{
                    std::addressof(*event_module), 1U, 2U
                }
            },
            .state_storage_bytes = 64U * 1024U * 1024U
        }
    };
    assert(mismatched_backend);
    auto mismatched_descriptor = mismatched_backend.descriptor();
    ScriptBackendInstance mismatched_instance;
    const auto& mismatched_events = mismatched_artifact->description().event_requirements;
    const std::array mismatched_admissions{PreparedScriptEventAdmission{&mismatched_events.front(), {}, {}, {}}};
    assert(mismatched_descriptor.createInstance(
        mismatched_descriptor.context,
        ScriptInstanceCreateContext{
            assetId(),
            SimulationScriptScope{},
            nullptr,
            {1U, 1U},
            {},
            mismatched_admissions
        },
        *mismatched_artifact,
        mismatched_instance
    ) == EScriptBackendResult::EXECUTABLE_CONTRACT_MISMATCH);
    TestProvider event_wait_provider;
    const lux::script::ScriptAbilityBinding event_wait_binding{
        &kTestAbility,
        std::addressof(event_wait_provider),
        std::addressof(event_wait_provider),
        kTestErasedMethods
    };
    const std::array event_wait_capabilities{publishScriptAbility(event_wait_binding)};
    const auto event_backend_descriptor = event_backend.descriptor();
    auto event_wait_system = ScriptSystem::create(
        simulation->description(),
        *planScriptRuntimeCapacity(*event_script_description),
        *resolveScriptRuntimeMounts(*event_script_description, {}, registry),
        registry,
        simulation->clock(),
        ScriptRuntimeLimits{8U, 1U, 4U, 4U, 4U, 4U, 64U, 1U, 4U, 4U, 4U, 4U},
        {std::addressof(event_artifact_source), &ArtifactSource::resolveArtifact},
        event_wait_capabilities,
        std::span{&event_backend_descriptor, 1U},
        simulation->scriptHookEndpoints(),
        simulation->scriptEventEndpoints()
    );
    assert(event_wait_system);
    assert(event_wait_system->prepare());
    runtime_binding.runtime = &*event_wait_system;
    assert(g_probe != nullptr);
    assert(simulation->execute(*executor, SimulationDuration{1}));
    assert(event_wait_system->activeContinuationCount() == 1U);
    assert(event_wait_system->stats().active_event_waiters == 1U);
    assert(event_wait_provider.value == 0);
    g_probe->pending_payload = 73;
    assert(simulation->execute(*executor, SimulationDuration{1}));
    assert(event_wait_system->stats().active_event_waiters == 0U);
    assert(event_wait_provider.value == 73);
    assert(event_wait_system->activeContinuationCount() == 0U);
    assert(event_wait_system->activeAwaitableCount() == 0U);
    assert(event_wait_system->shutdown());
    runtime_binding.runtime = nullptr;

    auto retiring_event_wait = ScriptSystem::create(
        simulation->description(),
        *planScriptRuntimeCapacity(*event_script_description),
        *resolveScriptRuntimeMounts(*event_script_description, {}, registry),
        registry,
        simulation->clock(),
        ScriptRuntimeLimits{8U, 1U, 4U, 4U, 4U, 4U, 64U, 1U, 4U, 4U, 4U, 4U},
        {std::addressof(event_artifact_source), &ArtifactSource::resolveArtifact},
        event_wait_capabilities,
        std::span{&event_backend_descriptor, 1U},
        simulation->scriptHookEndpoints(),
        simulation->scriptEventEndpoints()
    );
    assert(retiring_event_wait);
    assert(retiring_event_wait->prepare());
    runtime_binding.runtime = &*retiring_event_wait;
    assert(simulation->execute(*executor, SimulationDuration{1}));
    assert(retiring_event_wait->stats().active_event_waiters == 1U);
    const auto writes_before_event_retirement = event_wait_provider.calls;
    assert(retiring_event_wait->shutdown());
    runtime_binding.runtime = nullptr;
    g_probe->pending_payload = 101;
    assert(simulation->execute(*executor, SimulationDuration{1}));
    assert(event_wait_provider.calls == writes_before_event_retirement);

    auto retiring = ScriptSystem::create(
        simulation->description(),
        *planScriptRuntimeCapacity(*script_description),
        *resolveScriptRuntimeMounts(*script_description, {}, registry),
        registry,
        simulation->clock(),
        ScriptRuntimeLimits{8U, 1U, 4U, 4U, 4U, 4U, 64U, 1U, 4U, 4U, 4U, 4U},
        {std::addressof(source), &ArtifactSource::resolveArtifact},
        capabilities,
        std::span{&backend_descriptor, 1U},
        simulation->scriptHookEndpoints(),
        simulation->scriptEventEndpoints()
    );
    assert(retiring);
    assert(retiring->prepare());
    runtime_binding.runtime = &*retiring;
    const auto calls_before_retirement = provider.calls;
    assert(simulation->execute(*executor, SimulationDuration{1}));
    assert(retiring->activeContinuationCount() == 1U);
    assert(retiring->shutdown());
    runtime_binding.runtime = nullptr;
    assert(retiring->activeContinuationCount() == 0U);
    assert(retiring->activeAwaitableCount() == 0U);
    assert(simulation->execute(*executor, SimulationDuration{1}));
    assert(provider.calls == calls_before_retirement);
    return 0;
}
