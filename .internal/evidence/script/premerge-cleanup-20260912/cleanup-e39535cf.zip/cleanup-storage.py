from pathlib import Path
import re
r=Path(__file__).parent/'source'
def edit(path, fn):
 p=r/path; old=p.read_text(); new=fn(old); assert new!=old,path; p.write_text(new)
ex='engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptExecution.hpp'
edit(ex,lambda t: re.sub(r'        \[\[nodiscard\]\] static constexpr ScriptAwaitableId awaitableId\(AwaitableKey key\) noexcept\n        \{.*?\n        \}\n','', ''.join(l for l in t.splitlines(True) if 'resume_enqueued' not in l), flags=re.S))
lua='engine/domain/simulation/scripting/lua/src/LuaScriptBackend.cpp'
edit(lua,lambda t: t[:t.index('        union ScalarStorage final')]+t[t.index('        [[nodiscard]] static bool pushAbilityResult('):])
header='engine/domain/simulation/scripting/core/include/lux/engine/simulation/scripting/detail/BoundedClassStorage.hpp'
def storage(t):
 start=t.index('            const auto& page = pages_[value.page];')
 end=t.index('\n        }',start)
 t=t[:start]+'''            auto& page = pages_[value.page];
            if (value.slot >= page.slot_count) return false;
            auto& slot = slots_[page.metadata_first + value.slot];
            return releaseResolved(value.page, value.slot, value.generation, page, slot);
'''.rstrip()+t[end:]
 start=t.index('            const bool is_invalid_slot = !slot.active')
 end=t.index('\n        [[nodiscard]] Stats stats()',start)
 t=t[:start]+'''            const bool is_invalid_allocation = slot.size != allocation.size || allocation.data != expected;
            if (is_invalid_allocation)
                return false;
            return releaseResolved(allocation.page, allocation.slot, allocation.generation, page, slot);
        }
''' +t[end:]
 at=t.index('        [[nodiscard]] static bool powerOfTwo')
 helper='''        // The checked adapters resolve storage once; this operation owns the generation check and free-list update.
        [[nodiscard]] bool releaseResolved(
            std::uint32_t page_index, std::uint32_t slot_index, std::uint64_t generation, Page& page, Slot& slot
        ) noexcept
        {
            if (!slot.active || slot.generation != generation)
                return false;
            slot.active = false;
            --page.active;
            --active_;
            if (stats_.observation_collected)
            {
                stats_.release_steps += 3U;
                stats_.live_bytes -= slot.size;
                stats_.occupied_bytes -= classes_[page.class_index].stride;
            }
            slot.size = 0U;
            if (page.free_head == Invalid)
            {
                const auto steps = linkPage(page_index);
                if (stats_.observation_collected) stats_.release_steps += steps;
            }
            slot.next = page.free_head;
            page.free_head = slot_index;
            return true;
        }

'''
 return t[:at]+helper+t[at:]
edit(header,storage)
edit('engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptInstances.hpp', lambda t:t.replace('        std::vector<std::uint32_t> changes_;','        std::vector<std::uint32_t> changes_;\n        std::size_t changes_first_{}, changes_count_{};'))
def feedback(t):
 t=t.replace('changes_.reserve(capacity.mount_capacity);','changes_.resize(capacity.mount_capacity);')
 t=t.replace('if (changes_.size() == changes_.capacity())','if (changes_count_ == changes_.size())')
 t=t.replace('        changes_.push_back(slot);','''        auto position = changes_first_ + changes_count_;
        if (position >= changes_.size()) position -= changes_.size();
        changes_[position] = slot;
        ++changes_count_;''')
 t=t.replace('(std::min)(output.size(), changes_.size())','(std::min)(output.size(), changes_count_)')
 t=t.replace('            const auto slot = changes_[index];','''            const auto slot = changes_[changes_first_];
            if (++changes_first_ == changes_.size()) changes_first_ = 0U;''')
 return t.replace('        changes_.erase(changes_.begin(), changes_.begin() + count);\n        return {count, changes_.size()};','        changes_count_ -= count;\n        return {count, changes_count_};')
edit('engine/domain/simulation/builtin/script/src/ScriptInstances.cpp',feedback)
edit('engine/domain/simulation/builtin/script/benchmark/script_runtime_benchmark.cpp',lambda t:t.replace('invocation_errors=%llu,idle_page_backing=%zu','invocation_errors=%llu,retained_failures=%zu'))
def current_only(t):
 # This diagnostic used a deleted SR-5 interface only in its historical baseline branch.
 t=re.sub(r'#if !SR5_VALUES\n.*?#endif\n','',t,flags=re.S)
 return re.sub(r'#if SR5_VALUES\n(.*?)#else\n.*?#endif\n',r'\1',t,flags=re.S)
edit('cmake/installed-consumers/script-lua-value-costs/main.cpp',current_only)
edit('cmake/installed-consumers/script-lua-value-costs/CMakeLists.txt',lambda t:t[:t.index('if(SR5_VALUES)')]+'''include_component_cmake_scripts(lux::engine::function::script_lua)
lux_script_lua_values(TARGET script_lua_value_cost SOURCES ${CMAKE_CURRENT_SOURCE_DIR}/CollisionValue.hpp)
''')
edit('engine/domain/simulation/builtin/script/src/ScriptTimers.cpp',lambda t:t.replace('#include <limits>', '#include <limits>\n#include <type_traits>'))
