from pathlib import Path
import hashlib,json,re,subprocess
r=Path(__file__).parent;source=r/'source';old=r.parent/'script-v4'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda p,*a:subprocess.check_output(['git','-C',str(p),*a]).decode()
start=json.loads((r/'start.json').read_text());checks={}
protected=json.loads((old/'final-audit.json').read_text())['protected_workspaces'][0]
p=Path(protected['path']);assert git(p,'rev-parse','HEAD').strip()==protected['head']
assert git(p,'status','--porcelain','-z')==protected['status']
for name,digest in protected['files'].items():assert sha(p/name)==digest,name
checks['protected_main']={**protected,'unchanged':True,'note':'A0 start capture omitted first status-file hash; all seven verified against v4 final audit, including .gitignore. Original start.json retained.'}
checks['other_original_worktree']={'path':str(r.parent/'s5/source'),'head':git(r.parent/'s5/source','rev-parse','HEAD').strip(),
 'status':git(r.parent/'s5/source','status','--porcelain','-z')}
dependencies=json.loads((r/'fixed-dependencies.json').read_text())
for entry in dependencies['files']:assert sha(Path(entry['path']))==entry['sha256'],entry['path']
checks['dependency_hashes_verified']=len(dependencies['files'])
checks['images']=[]
for parent in [old,r]:
 for name in ['final-image','final-flow-image']:
  folder=parent/name;identity=json.loads((folder/'identity.json').read_text());verified=[]
  for file,entry in identity['images'].items():
   assert sha(folder/file)==entry['sha256'],(folder,file)
   verified.append(file)
  for file,digest in identity.get('fixtures',{}).items():assert sha(folder/file)==digest
  checks['images'].append({'path':str(folder),'source':identity['source'],'identity_sha256':sha(folder/'identity.json'),'files_verified':verified})
checks['unchanged_workload_files']=[]
for file in json.loads((r/'final-image/identity.json').read_text())['fixtures']:
 assert sha(r/'final-image'/file)==sha(old/'final-image'/file)
 checks['unchanged_workload_files'].append({'file':file,'sha256':sha(r/'final-image'/file)})
checks['unchanged_lua_dll']=sha(r/'final-image/lux_lua55.dll')
assert checks['unchanged_lua_dll']==sha(old/'final-image/lux_lua55.dll')
checks['source_diff_files']=git(source,'diff','--name-only','f7d2815b..caf34bd3').splitlines()
for name in checks['source_diff_files']:
 assert not any(x in name for x in ['LuaPageAllocator','LuaValue','NativeFrameStorage','BoundedClassStorage','NativeABI','assets/']),name
assert git(source,'diff','--check','f92853ea..caf34bd3')==''
checks['caches']=[]
for slot in ['d','t']:
 cache=r.parent/'o/w'/slot/'CMakeCache.txt';values={}
 for line in cache.read_text().splitlines():
  if re.match(r'(CMAKE_(CXX_COMPILER|CXX_FLAGS|C_COMPILER|C_FLAGS|BUILD_TYPE|HOME_DIRECTORY|INSTALL_PREFIX|PREFIX_PATH)|LUX_(BUILD_PROFILE|SCRIPT_HOTPATH|LUA55|META_GENERATOR)|LuxLua55_DIR)',line) and '=' in line:
   k,v=line.split('=',1);values[k]=v
 assert values['CMAKE_BUILD_TYPE:STRING']=='RelWithDebInfo'
 assert values['LUX_SCRIPT_HOTPATH_OBSERVATION:BOOL']=='OFF'
 checks['caches'].append({'path':str(cache),'sha256':sha(cache),'values':values})
checks['installed_headers']=[]
for prefix in ['sdk','tools']:
 root=Path('E:/SyncForder/CodeRepos/install/o/cell-a1')/prefix/'include'
 for src,name in [('engine/domain/simulation/builtin/script/include/lux/engine/simulation/ScriptSystem.hpp','lux/engine/simulation/ScriptSystem.hpp'),
  ('engine/domain/simulation/scripting/core/include/lux/engine/simulation/scripting/ScriptRuntime.hpp','lux/engine/simulation/scripting/ScriptRuntime.hpp')]:
  qualified=r.parent/'script-region-opt/final-source'/src
  assert sha(root/name)==sha(qualified)
  assert (root/name).read_text()==(source/src).read_text()
  checks['installed_headers'].append({'path':str(root/name),'sha256':sha(root/name),
   'qualified_source_sha256':sha(qualified),'development_worktree_sha256':sha(source/src),
   'text_equal_after_newline_decoding':True})
 for private in ['ScriptOperationStorage.hpp','ScriptExecution.hpp','ScriptInstances.hpp','ScriptTimers.hpp','ScriptEventWaits.hpp']:
  assert not list(root.rglob(private)),private
checks['private_headers_installed']=False
checks['qualified_commit']='caf34bd307912450d894da922b59af4238154508'
checks['candidate_status_before_report']=git(source,'status','--porcelain','-z')
checks['result']='PASS'
(r/'final-audit.json').write_text(json.dumps(checks,indent=2));print('FINAL_AUDIT_PASS deps',len(dependencies['files']),'protected',len(protected['files']))
