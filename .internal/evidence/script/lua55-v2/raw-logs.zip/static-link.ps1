$ErrorActionPreference='Stop'
$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/lua55-v2'
$dev='E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source'
$clang='D:/Development/Mircosoft/VisualStudio/VC/Tools/Llvm/x64/bin/clang-cl.exe'
$link='D:/Development/Mircosoft/VisualStudio/VC/Tools/Llvm/x64/bin/lld-link.exe'
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
function Run([string]$name,[string[]]$command) {
    $path="$r/$name.log"
    if(Test-Path -LiteralPath $path) { throw 'Existing diagnostic log' }
    $command|ConvertTo-Json -Compress|Set-Content -LiteralPath $path
    & $command[0] $command[1..($command.Length-1)] *>>$path
    $code=$LASTEXITCODE
    @{command=$command;exit=$code;source='75d025e75';graph_sha256=(Get-FileHash "$r/gameplay.ability.bc").Hash} |
        ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$r/$name.json"
    Write-Output "$name exit=$code"
    if($code) { throw "$name failed" }
}
Run 'p8-static-provider' @($clang,'/c','/O2','/MD','/Zi','/DNDEBUG','/clang:-flto=thin',
    "/I$dev/modules/function/script/core/include","$r/static-provider.cpp","/Fo$r/static-provider.obj")
Run 'p8-static-graph' @($clang,'/c','/O2','/MD','/Zi','/clang:-flto=thin',
    "$r/gameplay.ability.bc","/Fo$r/static-graph.obj")
Run 'p8-static-link' @($link,"$r/static-provider.obj","$r/static-graph.obj","/out:$r/static-flowforge.exe",
    '/subsystem:console','/debug','/opt:ref','/opt:icf','/lldsavetemps','/export:runActualGraph')
Run 'p8-static-run' @("$r/static-flowforge.exe")
