# 给实施 LLM 的启动指令

你将实施 `LUX-YU/lux-engine` 的 **V4-NA1：原生任务编排 + 同步 Lua 步骤**实验。请先完整阅读本包`SPEC.zh-CN.md`，再执行；不要只根据聊天摘要、这里的短提示或文件名猜测需求。

## 任务不是包装旧Lua协程

目标是：C++脚本使用现有`ScriptCoroutine`和真正的`co_await`保存跨等待控制流；Lua每个步骤正常返回。等待期间不存在需要resume的Lua调用链。框架不得为这些任务创建Lua thread、Lua backend continuation、per-task Lua closure/context table或thread root。

原Event/Timer/Awaitable/core continuation/Ready/稳定点/预算/权限仍由V4处理；不新增scheduler，不采用A1 cell bank，不用C++ coroutine驱动`lua_resume`。

## 分支与对照

从`f92853ea8361a7dc90ce0da072497d3722c29f88`在隔离clone建立`codex/s6-native-task-lua-steps`。V4生产对照是`f7d2815bdd2025ee23a7c11449def822413f58e9`，先证明两者生产输入一致。原main/V4/A1/H1和未知修改不动，不reset/clean/stash/force。新分支存在时先核对，不覆盖。

本轮只使用Lua55与匹配V4依赖，不合入prepared-checks的H1/H3，不修改VM/GC/allocator/codec表示/Native ABI6/编译器选项。最终只推新实验分支，不合并main/V4，不发tag。

## 实际集成落点

实现本包规定的高层`NativeLuaTaskBackend`组合facade。它在本次composition中占用唯一LUA kind descriptor，未映射Lua资产/方法走旧Lua入口。选定任务通过显式冷期plan映射到**真实CppStatic任务制品**，不是根据方法名跳过合同。

一个core mount、一个ScriptInstanceId、一个ScriptBehavior/权限和lifecycle；内部有Lua self子实例和CppStatic任务子实例。禁止为同一实体另挂一套独立脚本系统。依赖/来源必须是原挂载允许集合的子集，子制品真实身份/lease分别管理，不能将Lua资产送入CppStatic并关闭contract验证。

准备期建立同步step集合，CppStatic上下文只借用稳定视图。同步call按实际值与当前资格检查，所有Lua错误封闭在保护范围内；不跨user callback保存ACTIVE。开始/结束和取消仍走现有owner顺序。

现有`ScriptCoroutine`只有void promise，不能照抄先前示意的`Task<Result<void>>`或`co_return unexpected`。按规格实现窄的终止fail awaitable：设置FAILED、无A/Ready、回到adapter销毁。不要把Lua错误抛成C++未处理异常触发terminate。

只允许当前已有record输入和scalar/void返回；不要误把Ability的record双向codec当成已有的任意Lua export record返回。跨等待保存native值，不保存临时span、packet指针或Lua局部context table。

## 执行顺序

按N0→N7连续子提交。N2先完成一条真实Event链并观察完整backing，确认结构真的是路线A；之后完成N3/N4的失败、并发、连续等待、record与Physics，不因为初步结果稍慢就偷换业务。

本轮强制完整范围是C++原生编排+Lua同步步骤。新FlowForge→Lua桥不在本轮范围，不增加图节点/Native ABI来扩项目；原FlowForge回归仍必须实际跑。不得宣称新增跨语言编排已覆盖FlowForge。

## 比较和验证

`TEST_MATRIX.csv`列54条合同要求，逐条映射实际断言，不是54个已存在EXE。

`PERFORMANCE_PLAN.json`列9条正式比较，每条3对AB/BA/AB，共54个有效进程。A/B按共同业务trace和实际完成数对齐；长期32wait两侧都一项任务32wait。Lua业务不得搬到C++。A原task body不额外helper化；共同fixture新同步方法和B原生制品如实标识。

必须准确ROI；P1/P3各一份A/B Hotspots，正式timing无observer。GC照常，task创建/完成/销毁不能搬出ROI。有效慢组全部保留，不恢复旧VM，不追加无界参数搜索。

同时记录nativeframe/参数/header、组合/step表、Lua主栈/self/prototype/余留根、core/source/transport的完整资源；null不是零。同步-only模式不需要Lua任务池，实际是否删除预留与是否没有创建thread分别报告。

N6完成最终clean Developer/Toolchain/VM、原15consumer+新增consumer、原13增量+有限新探针、旧2迁址+新consumer迁址。真实错误导致不能完成时标具体PARTIAL，不写“适用工作全部完成”。

## 交付结论

写清实施/合同/成本/采用四层状态。负结果允许，安全不允许降低。保留代码、测量和反例，只推新分支并提供固定归档和回取验证。你实施的是一个可被否定的实验，不是必须证明比V4快的营销任务。
