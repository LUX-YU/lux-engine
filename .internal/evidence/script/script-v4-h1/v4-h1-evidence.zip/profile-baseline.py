"""One software sample per original V4 workload; no production instrumentation."""
from pathlib import Path
import csv, ctypes as ct, hashlib, json, os, re, subprocess, sys, time

r = Path(__file__).parent
source = r.parent/'script-cell-a1/source'
v4 = r.parent/'script-v4'
out = r/'baseline-profile'
out.mkdir(exist_ok=False)
vtune = 'D:/Softwares/Intel/oneAPI/vtune/2026.3/bin64/vtune.exe'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def git(p,*args): return subprocess.check_output(['git','-C',str(p),*args],text=True).rstrip('\r\n')
main = Path('E:/SyncForder/CodeRepos/lux-engine')
status = git(main,'status','--porcelain','--untracked-files=all')
start = dict(source=str(source),head=git(source,'rev-parse','HEAD'),branch=git(source,'branch','--show-current'),
             main_head=git(main,'rev-parse','HEAD'),main_status=status,
             protected={line[3:]:sha(main/line[3:]) for line in status.splitlines() if (main/line[3:]).is_file()},images={})
for name in ['final-image','final-flow-image']:
    image=v4/name; identity=json.loads((image/'identity.json').read_text())
    assert identity['source']=='f7d2815bdd2025ee23a7c11449def822413f58e9'
    for name2,entry in identity['images'].items(): assert sha(image/name2)==entry['sha256'],name2
    start['images'][name]=identity
(r/'start.json').write_text(json.dumps(start,indent=2))
k=ct.WinDLL('kernel32');k.GetCurrentProcess.restype=ct.c_void_p
k.SetProcessAffinityMask.argtypes=[ct.c_void_p,ct.c_size_t]
assert k.SetProcessAffinityMask(k.GetCurrentProcess(),16)
cache=(r.parent/'o/w/t/CMakeCache.txt').read_text()
linker=re.search(r'CMAKE_LINKER:FILEPATH=(.*)',cache)[1].strip()
records=[]
for scene in ['event','flowforge-event','scalar','record','cpp-sequence']:
    directory=out/scene;directory.mkdir()
    image=v4/('final-flow-image' if scene=='flowforge-event' else 'final-image')
    if scene=='record':
        app=[str(image/'simulation_script_lua_value_runtime_test.exe'),'--benchmark','1000000']
    else:
        short=scene in ['cpp-sequence','flowforge-event']
        group={'event':'scene-lua-event','scalar':'micro-lua-ability-query','cpp-sequence':'scene-cpp-sequence',
               'flowforge-event':'scene-flowforge-event'}[scene]
        app=[str(image/('flowforge_script_runtime_benchmark.exe' if scene=='flowforge-event' else 'script_runtime_benchmark.exe')),
             '--group',group,'--mode','performance','--size','10000','--warmups','300' if short else '1000',
             '--frames','1000' if short else '2000','--resume-budget','10000','--seed','1592598566',
             '--output',str(directory/'business.csv')]
        if not short: app+=['--vm-accounting','off','--lua-artifact',str(image/'lua_runtime_benchmark_fixture.lxsa')]
    env=dict(os.environ);env['LUX_FLOWFORGE_LINKER']=linker
    env['PATH']=';'.join([str(image),'D:/Development/vcpkg/installed/x64-windows/bin',
                         *[p for p in env['PATH'].split(';') if 'CodeRepos' not in p and 'vcpkg' not in p]])
    (directory/'target-command.json').write_text(json.dumps(app,indent=2))
    command=[vtune,'-collect','hotspots','-knob','sampling-mode=sw','-knob','enable-stack-collection=true',
             '-knob','enable-characterization-insights=false','-return-app-exitcode','-result-dir',str(directory/'result'),
             '-search-dir',str(image),'-source-search-dir',str(source),
             '--',sys.executable,'-B',str(r/'profile-target.py'),str(directory)]
    def run(name,cmd):
        begin=time.monotonic()
        with (directory/(name+'.log')).open('wb') as f:code=subprocess.call(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
        records.append(dict(scene=scene,name=name,command=cmd,exit=code,seconds=time.monotonic()-begin))
        (out/'runs.json').write_text(json.dumps(records,indent=2));print(scene,name,code,flush=True)
        return code
    code=run('collect',command)
    target=json.loads((directory/'target-exit.json').read_text()) if (directory/'target-exit.json').exists() else {}
    text=(directory/'target.log').read_text(errors='replace') if (directory/'target.log').exists() else ''
    rows=list(csv.DictReader((directory/'business.csv').open())) if (directory/'business.csv').exists() else []
    valid=code==0 and target.get('exit')==0
    if scene=='record': valid=valid and 'operations=1000000 errors=0 backlog=0' in text and 'VALUE_CLEANUP invocation_errors=0' in text
    else:
        valid=valid and len([x for x in rows if not x['scenario'].endswith('-drain')])==(1000 if short else 2000)
        valid=valid and all(x['git_commit']=='f7d2815bdd2025ee23a7c11449def822413f58e9' for x in rows)
        if scene!='cpp-sequence': valid=valid and text.count('invocation_errors=0')>=2
        if scene=='event': valid=valid and 'checksum=930010000' in text
        if scene=='flowforge-event': valid=valid and 'checksum=403000000,source=provider-payload' in text
    (directory/'identity.json').write_text(json.dumps(dict(valid=valid,source='f7d2815bdd2025ee23a7c11449def822413f58e9',
        image=str(image),scope='whole target process: existing frozen executable has no ITT ROI; setup/warmup/oracle/cleanup included',
        timing_qualification=False,PMU=False,errors_observed=scene!='cpp-sequence'),indent=2))
    if valid:
        for name in ['summary','hotspots','top-down','bottom-up']:
            run(name,[vtune,'-report',name,'-r',str(directory/'result'),'-format','csv','-csv-delimiter','comma',
                      '-limit','10000','-filter','process='+Path(app[0]).name,'-report-output',str(directory/(name+'.csv'))])

