#pragma once
// Generated typed Lua projection. Include the matching .ability.generated.hpp first.
#include <lux/engine/simulation/scripting/lua/LuaScriptAbilityProjection.hpp>

#include <array>
#include <type_traits>
#include <utility>

namespace lux::script::lua
{

    template <>
    struct ScriptAbilityLuaTraits<::lux::physics2d::PhysicsQuery2D> final
    {
        using AbilityTraits = ScriptAbilityTraits<::lux::physics2d::PhysicsQuery2D>;
        using Policy = typename ScriptAbilityLuaPolicy<::lux::physics2d::PhysicsQuery2D>::Type;

        using Values_overlapsBox = LuaAbilityValueSignature<Policy, bool, double, double, double, double>;
        [[nodiscard]] static int overlapsBox(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, bool, double, double, double, double>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, double center_x, double center_y, double half_width, double half_height) noexcept -> bool
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.overlapsBox(access.context, center_x, center_y, half_width, half_height);
                }
            );
        }

        inline static constexpr std::array<ScriptAbilityLuaMethodProjection, AbilityTraits::Methods.size()> Methods{
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.physics2d.query.overlaps_box"},
                &overlapsBox, Values_overlapsBox::Parameters, Values_overlapsBox::Results
            }
        };
    };
} // namespace lux::script::lua
