$ErrorActionPreference = 'Stop'
$taskRoot = 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/sr4-move'
& "$taskRoot/candidate-source/cmake/RunScriptV3Consumers.ps1" -SourceDir "$taskRoot/candidate-source" `
    -OutputRoot "$taskRoot/consumers-retry" `
    -PrefixPath 'E:/SyncForder/CodeRepos/install/sr4-move/d;E:/SyncForder/CodeRepos/install/sr4-move/t;E:/SyncForder/CodeRepos/install/q2/c;E:/SyncForder/CodeRepos/install/q2/toolset;E:/SyncForder/CodeRepos/install/RelWithDebInfo' `
    -DependencyRoot 'D:/Development/vcpkg/installed' -Names @('lua-script-packager', 'script-authoring')
