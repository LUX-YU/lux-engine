import json,hashlib,subprocess
from pathlib import Path
r=Path('../../s5c').resolve(); main=Path('E:/SyncForder/CodeRepos/lux-engine'); source=Path.cwd()
def git(p,*args):return subprocess.check_output(['git','-C',str(p),*args],text=True).strip()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
state={ 'source_head':git(source,'rev-parse','HEAD'),'source_status':git(source,'status','--porcelain'),'main_head':git(main,'rev-parse','HEAD'),'main_status':git(main,'status','--porcelain'),'main_files':[],'dependencies':{},'C0':[]}
assert state['source_head']=='ebf081158ced81c2115e5ac9c8a1f364526c255a' and not state['source_status']
for line in subprocess.check_output(['git','-C',str(main),'status','--porcelain'],text=True).splitlines():
 p=line[3:];state['main_files'].append({'path':p,'sha256':digest(main/p)})
for n,sha in [('lux-cxx-v3r','3100f54d0743c5ed94a4ccf5943df04e933de255'),('lux-cmake-toolset-s6-relocation','99c3d0480d1db816779b1dfa7f3c06cb7d39a94f')]:
 p=main.parent/n;state['dependencies'][n]={'head':git(p,'rev-parse','HEAD'),'status':git(p,'status','--porcelain')};assert state['dependencies'][n]=={'head':sha,'status':''}
for p in sorted(Path('../q/d/bin').glob('*')):
 if p.suffix in ('.exe','.dll'):state['C0'].append({'path':str(p.resolve()),'sha256':digest(p)})
(r/'start-identity.json').write_text(json.dumps(state,indent=2));print('baseline and protected state fixed')
