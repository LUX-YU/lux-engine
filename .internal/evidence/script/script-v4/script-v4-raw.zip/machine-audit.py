from pathlib import Path
import re,json,hashlib
r=Path(__file__).parent
results=[]
groups=[('final-native-frame-disassembly.log',['?acquire@NativeFrameStorage','?release@NativeFrameStorage',
 '?link@NativeFrameStorage','?unlink@NativeFrameStorage']),
 ('final-cpp-storage-disassembly.log',['?allocateFrame@ScriptCoroutineContext','?releaseFrame@ScriptCoroutineContext',
 '?acquire@BoundedClassStorage','?release@BoundedClassStorage']),
 ('final-cpp-frame-disassembly.log',['?run@CppSequenceScript'])]
snippets=[]
for file,needles in groups:
 text=(r/file).read_text(encoding='utf-8-sig')
 sections=re.split(r'(?=^\?[^\n]*:\s*$)',text,flags=re.M)
 for needle in needles:
  found=[x for x in sections if x.startswith(needle)]
  assert found,(file,needle)
  for block in found:
   calls=re.findall(r'^.*\b(?:call|jmp)\s+.*(?:\?|__imp_|\[rax|\[rcx|memcpy|memset).*$',block,re.M)
   item=dict(file=file,symbol=block.splitlines()[0],call_or_tail_targets=calls,
     direct_heap_entry_reference=bool(re.search(r'(malloc|calloc|realloc|operator new|\?\?2@)',block)))
   if needle.startswith('?run@CppSequenceScript'):
    item['compiler_body_bytes']=int(re.search(r'mov\s+edx,([0-9A-F]+)h',block)[1],16)
   results.append(item);snippets.append(block)
(r/'hot-storage-machinery.log').write_text('\n'.join(snippets))
(r/'hot-storage-machinery.json').write_text(json.dumps(results,indent=2))
for x in results:print(x['symbol'].split(' (')[0],x['direct_heap_entry_reference'],x.get('compiler_body_bytes'),x['call_or_tail_targets'])
