$ErrorActionPreference = 'Stop'
$root = 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5'
$python = 'C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
& $python -B "$root/stage-evidence.py"
if ($LASTEXITCODE) { throw 'stage failed' }
$arguments = @('-B',"$root/source/cmake/CollectScriptSR3Evidence.py",'--archive-name','SR5-raw-evidence.zip')
foreach ($name in @('evidence-stage','q','b7-qualification','b8-qualification','boundary','consumers','consumers-final','incremental','incremental-final','performance','performance-final','scale-replay','probes','diagnostics','value-costs','value-costs-valid')) {
    $arguments += @('--root', "$root/$name")
}
foreach ($name in @("$root/candidate-source",'E:/SyncForder/CodeRepos/build/RelWithDebInfo/sr4-move/candidate-source','E:/SyncForder/CodeRepos/lux-cxx-v3r','E:/SyncForder/CodeRepos/lux-cmake-toolset-s6-relocation')) {
    $arguments += @('--source',$name)
}
foreach ($name in @('E:/SyncForder/CodeRepos/install/s5/q/t','E:/SyncForder/CodeRepos/install/s5/q/d','E:/SyncForder/CodeRepos/install/s5/q/l','E:/SyncForder/CodeRepos/install/q2/c','E:/SyncForder/CodeRepos/install/q2/toolset')) {
    $arguments += @('--prefix',$name)
}
$arguments += @('--consumers',"$root/consumers-final",'--output',"$root/source/.internal/evidence/script/sr5/final")
& $python @arguments
if ($LASTEXITCODE) { throw 'archive failed' }

