from pathlib import Path
s=Path(r'E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1/source')
p=s/'engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptExecution.hpp'
t=p.read_text().replace('                    free_head_ = slot;\n                }\n            }\n            [[nodiscard]] bool empty()', '                    free_head_ = slot;\n                }\n                else record.id.generation = 0U;\n            }\n            [[nodiscard]] bool empty()').replace('if (record.id.generation == NoSlot) continue;', 'if (record.id.generation == 0U) continue;')
p.write_text(t,encoding='utf-8')
p=s/'.internal/script-native-lua-na1/LOCAL-WAIT-CHANGES.zh-CN.md'
t=p.read_text()+'''
## 已执行

- `459a3671`：结果内嵌事件关系，删除 EventWaiter SlotMap；恢复通知由 24 B 改为 8 B。
  `local-wait-first-build/tests`：Developer all 成功、脚本/Lua 88/88。
- 后续固定结果存储替换 StableSlotMap：物理对象在准备时建立，归还逻辑槽不销毁物理对象；
  每次登记仍更新公开等待代次。来源关系和实例等待链直接使用稳定记录地址。
  接受/取消/正常 take/写 pin 最后释放均走同一结果存储，没有第二个结果池。
- `testClaimedCancellationAndSlotReuse`：两槽满载，在第一项 copy 内取消第二项并重用旧槽，
  旧 occurrence 快照被拒绝，替代等待只收到下一 occurrence（91、92），三个 frame 各销毁一次。
- `testRepeatedWaitStorageReuse`：等待/事件容量均为 1，连续 64 轮，实际值、恢复和销毁各 64，
  backing 不增长、每轮最终等待数为零。
- `local-wait-bank-regression-build/tests`：all 无工作检查成功，脚本/Lua 88/88。
  先前 `local-wait-bank-tests` 的筛选只命中两个测试，不能代替后续 88 项结果。

尚未测量本轮性能。全局事件任务数组、按事件批次压缩通知及大 payload 共享需要独立核对：
现有链已直接访问稳定结果，不再查第二个目录；不能仅为替换容器增加按 endpoint 成倍预留。
'''
p.write_text(t,encoding='utf-8')
