$ErrorActionPreference = 'Stop'
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$root = 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5'
$source = "$root/source"
$dep = 'E:/SyncForder/CodeRepos/install/q2/c;E:/SyncForder/CodeRepos/install/q2/toolset;E:/SyncForder/CodeRepos/install/RelWithDebInfo'
$bins = @{}
$envOriginal = $env:PATH
foreach ($variant in @('baseline','candidate')) {
    $prefix = if ($variant -eq 'baseline') { 'E:/SyncForder/CodeRepos/install/sr4-move/d' } else { 'E:/SyncForder/CodeRepos/install/s5/q/d' }
    $probe = "$root/value-costs/$variant"
    New-Item -ItemType Directory -Force -Path $probe | Out-Null
    $flag = if ($variant -eq 'baseline') { 'OFF' } else { 'ON' }
    cmake -S "$source/cmake/installed-consumers/script-lua-value-costs" -B "$probe/build" -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo "-DSR5_VALUES=$flag" -DCMAKE_TOOLCHAIN_FILE=D:/Development/vcpkg/scripts/buildsystems/vcpkg.cmake "-DCMAKE_PREFIX_PATH=$prefix;$dep" -DCMAKE_FIND_USE_PACKAGE_REGISTRY=OFF -DCMAKE_FIND_USE_SYSTEM_PACKAGE_REGISTRY=OFF *> "$probe/configure.log"
    if ($LASTEXITCODE) { throw "$variant value cost configure failed" }
    cmake --build "$probe/build" --target all -j 4 -- -k 0 *> "$probe/all.log"
    if ($LASTEXITCODE) { throw "$variant value cost all failed" }
    cmake --build "$probe/build" --target all -j 4 -- -k 0 *> "$probe/noop.log"
    if ($LASTEXITCODE) { throw "$variant value cost second all failed" }
    $bins[$variant] = @{exe="$probe/build/script_lua_value_cost.exe";prefix=$prefix}
}
$records = @()
foreach ($pair in 0..4) {
    $order = if ($pair % 2) { @('candidate','baseline') } else { @('baseline','candidate') }
    foreach ($variant in $order) {
        $info = $bins[$variant]
        $env:PATH = "$($info.prefix)/bin;D:/Development/vcpkg/installed/x64-windows/bin;$envOriginal"
        $log = "$root/value-costs/$variant-$pair.log"
        & $info.exe *> $log
        if ($LASTEXITCODE) { throw 'value cost failed' }
        $records += @{variant=$variant;pair=$pair;log=$log;exe_sha256=(Get-FileHash $info.exe).Hash;prefix=$info.prefix}
    }
}
foreach ($variant in $bins.Keys) {
    $info = $bins[$variant]
    $env:PATH = "$($info.prefix)/bin;D:/Development/vcpkg/installed/x64-windows/bin;$envOriginal"
    & $info.exe diagnostics *> "$root/value-costs/$variant-diagnostics.log"
    if ($LASTEXITCODE) { throw 'value allocation diagnostic failed' }
}
$records | ConvertTo-Json -Depth 4 | Set-Content "$root/value-costs/runs.json"
$env:PATH = "$root/q/d/bin;D:/Development/vcpkg/installed/x64-windows/bin;$envOriginal"
foreach ($pair in 0..4) {
    & "$root/q/d/bin/simulation_script_lua_value_runtime_test.exe" --benchmark 100000 *> "$root/value-costs/typed-runtime-$pair.log"
    if ($LASTEXITCODE) { throw 'typed runtime benchmark failed' }
}

& "$root/q/d/bin/simulation_script_lua_value_runtime_test.exe" --benchmark 100000 --allocations *> "$root/value-costs/typed-runtime-allocations.log"
if ($LASTEXITCODE) { throw 'typed runtime allocation diagnostic failed' }
