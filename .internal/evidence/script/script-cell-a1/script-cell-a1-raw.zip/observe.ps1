$ErrorActionPreference='Stop'
$root='E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-cell-a1'
$build='E:/SyncForder/CodeRepos/build/RelWithDebInfo/o/w/d'
$source='E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-region-opt/final-source'
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
function Run([string]$name,[string[]]$command) {
    $path=Join-Path $root "$name.log"
    if (Test-Path -LiteralPath $path) { throw "Existing log $path" }
    $watch=[Diagnostics.Stopwatch]::StartNew()
    & $command[0] $command[1..($command.Length-1)] *> $path
    $code=$LASTEXITCODE
    [ordered]@{source=(git -C $source rev-parse HEAD);command=$command;exit=$code;seconds=$watch.Elapsed.TotalSeconds} |
        ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $root "$name.json")
    Write-Output "$name exit=$code"
    if ($code) { throw "$name failed" }
}
try {
    Run 'observer-configure' @('cmake','-S',$source,'-B',$build,'-DLUX_SCRIPT_HOTPATH_OBSERVATION=ON')
    Run 'observer-build' @('cmake','--build',$build,'--target','all','-j','4','--','-k','0')
    $env:PATH="$build/bin;D:/Development/vcpkg/installed/x64-windows/bin;$env:PATH"
    Run 'observer-tests' @('ctest','--test-dir',$build,'--output-on-failure','-j','1','-R','simulation_script_(operation_storage|continuation|event_wait)_test')
    Run 'observer-diagnostic' @('C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe','-B',"$root/observe.py")
} finally {
    Run 'restore-standard-configure' @('cmake','-S',$source,'-B',$build,'-DLUX_SCRIPT_HOTPATH_OBSERVATION=OFF')
    Run 'restore-standard-build' @('cmake','--build',$build,'--target','all','-j','4','--','-k','0')
    Run 'restore-standard-noop' @('cmake','--build',$build,'--target','all','-j','4','--','-k','0')
}
