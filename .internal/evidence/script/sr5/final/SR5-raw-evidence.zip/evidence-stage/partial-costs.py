import csv,statistics,json
from pathlib import Path
r=Path('../performance-final'); out=[]
for case in ['cpp-update-10k','lua-update-10k','lua-ability-10k']:
 ps=[]
 for i in range(5):
  totals=[]
  for side in ['baseline','final']:
   rows=list(csv.DictReader((r/f'{case}-p{i}-{side}.csv').open()));totals.append(sum(int(x['nanoseconds']) for x in rows))
  ps.append(100*(totals[1]/totals[0]-1))
 out.append({'case':case,'percent':ps,'median':statistics.median(ps)})
print(json.dumps(out,indent=2))
