from pathlib import Path
b=Path('E:/RenderV2Rebuild/Layer/source/modules/function/render')
p=b/'resource/include/lux/engine/render/resource/Factory.hpp';s=p.read_text().replace('#include <memory>','#include <memory>\n#include <concepts>\n#include <lux/cxx/compile_time/TypeToken.hpp>');pos=s.index('    struct StorageFactory final');s=s[:pos]+'''    struct StorageCppType final
    {
        cxx::TypeToken type;
        std::size_t size = 0;
        std::size_t alignment = 0;
        bool operator==(const StorageCppType&) const noexcept = default;
    };

    template <class T>
    [[nodiscard]] constexpr StorageCppType storageCppType() noexcept
    {
        return {cxx::typeToken<T>(), sizeof(T), alignof(T)};
    }

'''+s[pos:];s=s.replace('        void (*collect)(void*) noexcept = nullptr;','        void (*collect)(void*) noexcept = nullptr;\n        StorageCppType config_type;\n        StorageCppType ops_type;');pos=s.index('    [[nodiscard]] RenderResult<void>')
s=s[:pos]+'''    // Create and compatible callbacks are typed before the only erasure boundary.
    template <class Declaration, class Native, class Device, auto Create, auto Compatible>
        requires std::same_as<decltype(Create), RenderResult<std::unique_ptr<Native>> (*)(
            Device&, const typename Declaration::Config&) noexcept> &&
            std::same_as<decltype(Compatible), bool (*)(const Native&, const typename Declaration::Config&) noexcept>
    [[nodiscard]] StorageFactory makeStorageFactory(
        EGraphicsApi api, const typename Declaration::Ops& ops, const void* binding_ops = nullptr,
        void (*collect)(void*) noexcept = nullptr, std::shared_ptr<const void> code_pin = {}
    ) noexcept
    {
        return {&Declaration::description, api, &ops,
            [](void* device, const void* config) noexcept -> RenderResult<NativeStorage> {
                auto candidate = Create(*static_cast<Device*>(device), *static_cast<const typename Declaration::Config*>(config));
                if (!candidate) return cxx::unexpected(candidate.error());
                return NativeStorage{candidate->release(), [](void* value) noexcept { delete static_cast<Native*>(value); }};
            }, [](const void* instance, const void* config) noexcept {
                return Compatible(*static_cast<const Native*>(instance), *static_cast<const typename Declaration::Config*>(config));
            }, std::move(code_pin), binding_ops, collect,
            storageCppType<typename Declaration::Config>(), storageCppType<typename Declaration::Ops>()};
    }

'''+s[pos:];p.write_text(s)
# Check actual cxx function spelling separately before build.
p=b/'resource/include/lux/engine/render/resource/Registration.hpp';s=p.read_text().replace('        std::shared_ptr<const void> configuration;','        std::shared_ptr<const void> configuration;\n        StorageCppType configuration_type;');p.write_text(s)
p=b/'runtime/include/lux/engine/render/runtime/RenderServer.hpp';s=p.read_text().replace('            registration.configuration =','            registration.configuration_type = storageCppType<typename T::Config>();\n            registration.configuration =');p.write_text(s)
p=b/'runtime/src/RenderServer.cpp';s=p.read_text().replace('resources.configureType(*type.description, type.configuration)','resources.configureType(*type.description, type.configuration, type.configuration_type)');p.write_text(s)
p=b/'resource/include/lux/engine/render/resource/ResourceRegistry.hpp';s=p.read_text().replace('configureType(const StorageDescriptor& type, std::shared_ptr<const void> configuration) noexcept;', '''configureType(const StorageDescriptor& type, std::shared_ptr<const void> configuration, StorageCppType actual) noexcept;

        template <class Config>
        [[nodiscard]] RenderResult<void>
        configureType(const StorageDescriptor& type, std::shared_ptr<const Config> configuration) noexcept
        {
            return configureType(type, std::move(configuration), storageCppType<Config>());
        }''')
# Before any typed Ops cast, validate exact type even when schemas/sizes agree.
s=s.replace('            const auto& entry = *entries_.find(*id);\n            return typename T::Access', '''            const auto& entry = *entries_.find(*id);
            if (types_[entry.type].factory.ops_type != storageCppType<typename T::Ops>())
                return cxx::unexpected(RenderError{kStorageMismatch});
            return typename T::Access''')
a=s.index('        [[nodiscard]] RenderResult<StorageInstanceId> getOrCreate(\n');z=s.index('        [[nodiscard]] RenderResult<StorageInstanceId> find(',a)
s=s[:a]+'''        template <class Config>
            requires (!std::is_void_v<Config>)
        [[nodiscard]] RenderResult<StorageInstanceId> getOrCreate(
            const ResourceDomain& domain, std::string_view key, const StorageDescriptor& type, const Config* config
        ) noexcept
        {
            return getOrCreateImpl(domain, key, type, config, storageCppType<Config>());
        }

        [[nodiscard]] RenderResult<StorageInstanceId> getOrCreate(
            const ResourceDomain& domain, std::string_view key, const StorageDescriptor& type, std::nullptr_t
        ) noexcept
        {
            return getOrCreateImpl(domain, key, type, nullptr, {});
        }

'''+s[z:];s=s.replace('        struct Domain final', '''        [[nodiscard]] RenderResult<StorageInstanceId> getOrCreateImpl(
            const ResourceDomain&, std::string_view, const StorageDescriptor&, const void*, StorageCppType
        ) noexcept;

        struct Domain final''');p.write_text(s)
p=b/'resource/src/ResourceRegistry.cpp';s=p.read_text().replace('const StorageDescriptor& type, std::shared_ptr<const void> configuration','const StorageDescriptor& type, std::shared_ptr<const void> configuration, StorageCppType actual').replace('        if (installed.configuration || (type.config && !configuration))','        if (installed.factory.config_type != actual) return cxx::unexpected(RenderError{kStorageMismatch});\n        if (installed.configuration || (type.config && !configuration))');s=s.replace('ResourceRegistry::getOrCreate(','ResourceRegistry::getOrCreateImpl(').replace('const ResourceDomain& domain, std::string_view key, const StorageDescriptor& type, const void* config','const ResourceDomain& domain, std::string_view key, const StorageDescriptor& type, const void* config, StorageCppType actual');s=s.replace('        if (!config) config = installed.configuration.get();','        if (config && installed.factory.config_type != actual) return cxx::unexpected(RenderError{kStorageMismatch});\n        if (!config) config = installed.configuration.get();');p.write_text(s)
p=b/'resource/src/Storage.cpp';s=p.read_text().replace('!factory.compatible_config || factory.api != api;', '!factory.compatible_config || factory.api != api || factory.config_type.size == 0 || factory.ops_type.size == 0;');p.write_text(s)
p=b/'native/vulkan/src/transfer/Transfer.cpp';s=p.read_text().replace('        if (!resources_->installFactory(textureStorageFactory())) std::terminate();\n','');p.write_text(s)
# Texture uses the production typed factory generator.
p=b/'native/vulkan/src/texture/TextureStorage.cpp';s=p.read_text();a=s.index('        static const StorageFactory factory{');z=s.index('        return factory;',a)
s=s[:a]+'''        static const auto compatible = +[](const vulkan::TextureStorage& value, const TextureStorageConfig& config) noexcept {
            return value.compatibleConfig(config);
        };
        static const auto factory = makeStorageFactory<lux::render::TextureStorage, vulkan::TextureStorage,
            DeviceSession, &vulkan::TextureStorage::create, compatible>(EGraphicsApi::VULKAN, ops, &binding_ops,
                [](void* value) noexcept { static_cast<TextureStorage*>(value)->collect(); });
'''+s[z:];p.write_text(s)
# External extension uses same generator, no Server change.
p=b/'native/vulkan/test/extension/NativeBuffer.hpp';s=p.read_text();a=s.index('        return {&TestBufferStorage::description');z=s.index('\n    }\n}',a)
s=s[:a]+'''        static const auto create = +[](vk::DeviceSession& session, const TestBufferStorage::Config& config) noexcept
            -> RenderResult<std::unique_ptr<NativeBuffer>> {
            auto result = std::make_unique<NativeBuffer>(session, config);
            if (auto ready = result->initialize(); !ready) return lux::cxx::unexpected(ready.error());
            return result;
        };
        static const auto compatible = +[](const NativeBuffer& value, const TestBufferStorage::Config& config) noexcept {
            return value.compatible(config);
        };
        return makeStorageFactory<TestBufferStorage, NativeBuffer, vk::DeviceSession, create, compatible>(
            EGraphicsApi::VULKAN, ops, &binding, [](void* object) noexcept { static_cast<NativeBuffer*>(object)->collect(); });'''+s[z:];p.write_text(s)
