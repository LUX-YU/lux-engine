from pathlib import Path
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/lua55-v3')
s=(r/'r3-vm.ps1').read_text().replace("'r3-vm-","'diagnostic-vm-").replace('-DLUX_LUA55_DIAGNOSTICS=OFF','-DLUX_LUA55_DIAGNOSTICS=ON')
s=s[:s.index("Run 'diagnostic-vm-install'")]+'''
$dest=Join-Path $root 'diagnostic-vm'
New-Item -ItemType Directory -Path $dest | Out-Null
foreach($file in @('lux_lua55.dll','lux_lua55.pdb','lua.exe','lua55_leaf_contract.exe','lua55_callinfo_contract.exe','identity.json')) {
 Copy-Item -LiteralPath "$depbuild/$file" -Destination "$dest/$file"
}
'''
(r/'diagnostic-vm.ps1').write_text(s)
