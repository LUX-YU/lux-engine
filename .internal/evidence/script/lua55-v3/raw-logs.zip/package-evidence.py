from pathlib import Path
import hashlib,json,zipfile
r=Path(__file__).parent;repo=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source')
out=repo/'.internal/evidence/script/lua55-v3';out.mkdir(parents=True,exist_ok=True)
candidate='e06208deb29b9b1de52fe49a129091f693bb7e08'
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
selected=set();extensions={'.log','.json','.txt','.ps1','.py','.cpp','.c','.patch'}
for f in r.iterdir():
 if f.is_file() and f.suffix.lower() in extensions:selected.add(f)
for folder in ['final-costs','memory-diagnostic','value-incremental','machine-code','configuration','failed-style','failed-integration']:
 for f in (r/folder).rglob('*'):
  if f.is_file() and f.suffix.lower() in {'.log','.json','.csv','.hpp','.txt'}:selected.add(f)
for f in (r/'r0-profile').iterdir():
 if f.is_file() and f.suffix.lower() in {'.log','.json','.csv'}:selected.add(f)
for folder in ['installed','relocated']:
 for f in (r/folder).glob('*.json'):selected.add(f)
 for consumer in (r/folder).iterdir():
  if not consumer.is_dir() or consumer.name in {'sdk','vm','tools'}:continue
  selected.update(consumer.glob('*.log'))
  selected.update((consumer/'build').glob('compile_commands.json'))
  for f in (consumer/'source').rglob('*'):
   if f.is_file() and f.suffix.lower() in {'.cpp','.hpp','.cmake','.txt','.lua'}:selected.add(f)
assert not any(f.suffix.lower() in {'.exe','.dll','.pdb','.obj','.lib','.bc','.zip','.lxsa'} for f in selected)
files=[dict(path=f.relative_to(r).as_posix(),bytes=f.stat().st_size,sha256=digest(f)) for f in sorted(selected)]
assert len(files)<1000,len(files)
archive=out/'raw-logs.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f,item in zip(sorted(selected),files):z.write(f,item['path'])
 z.writestr('MANIFEST.json',json.dumps(dict(qualification=candidate,baseline='a6f16d6de6a67f6a4422553d31b42c1ac2b3e4c0',files=files),indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for f in files:assert hashlib.sha256(z.read(f['path'])).hexdigest()==f['sha256']
sha=digest(archive);(out/'raw-logs.zip.sha256').write_text(sha+'  raw-logs.zip\n')
(out/'archive.json').write_text(json.dumps(dict(qualification=candidate,vm_test_source='5985cc4d49fba8aecfcb40fa9bdb70ea0204f55a',sha256=sha,bytes=archive.stat().st_size,files=len(files),binary_products_included=False,all_file_hashes_reverified=True),indent=2)+'\n')
(out/'INDEX.md').write_text('''# Lua55 v3 原始证据

Engine 资格源码：`e06208deb29b9b1de52fe49a129091f693bb7e08`。v2 实际镜像：`a6f16d6de6a67f6a4422553d31b42c1ac2b3e4c0`。
VM 实测源码 `5985cc4d49fba8aecfcb40fa9bdb70ea0204f55a` 与最终候选的 VM 生产输入相同（见 continuity）；不把文档提交当新测试。

[结果报告](../../../lua55-v3/RESULT.zh-CN.md) · [result.json](../../../lua55-v3/result.json)

[原始 ZIP](raw-logs.zip) · [SHA-256](raw-logs.zip.sha256) · [归档身份](archive.json)

MANIFEST.json 记录每项路径、大小、SHA-256；打包后已逐项读回核验。
没有 EXE/DLL/PDB/OBJ/LIB/bitcode 或 cooked 二进制。实际 matched image 在受控本地 lua55-v3/final-image 保留；
哈希在 final-image-manifest.json。完整原始 VTune 数据库留本地 r0-profile/result，归档保留其命令、退出码和导出报告。

| 内容 | ZIP 内入口 |
|---|---|
| 开工/固定依赖/未知修改 | r0-start.json；baseline-dependency-verification.json；fixed-dependency-additional-files.json；protected-workspace-final.json |
| 最终 clean clone 和构建/测试 | git-final-integrity.json；qualified-tracked.*；qualified-d-*；qualified-t-*；configuration/ |
| Lua55 正式与独立诊断合同 | final-vm-*；diagnostic-vm-*；vm-source-continuity.json；vm-patched-inputs.json；vm-source-manifest.json |
| R0 软件 VTune | r0-profile/runs.json、target-exit.json、target.log、hotspots.csv、top-down.csv、modules.csv |
| 真实机器码 | machine-code/commands.json、rvas.json、*-uf.log；sequence-frame-before/after.log |
| R1 allocator / R2 local route / R4 codec | r1-*、r2-routes-*、r4-codec-*、integrated-protocols-*、generated-d/t-tests.log |
| 实际 SDK 与 15 consumers | installed/consumers.json；installed/*/configure/build/run/second-build.log；installed-final-manifest.json |
| 两条迁址执行 | relocated/results.json；relocated/unavailable-paths.json；relocated/*/run.log；relocated-qualified-source-driver.log |
| 13 类生成增量 | value-incremental/probes.json、每次 generated.hpp、log |
| 五腿三对整体成本 | final-costs/identities.json、runs.json、summary.json、work-oracles.json、各次 CSV/log |
| 独立内存 | memory-diagnostic/results.json、analysis.json、两侧 CSV/log |
| 修前失败与修正 | failed-style/；failed-integration/；sequence-diagnostic-*；sequence-frame-comparison.json；sequence-fixed-* |
| 迁址环境限制 | relocation-initial-limitation.json；relocated-driver.log；首次开发克隆 rename 被拒，已原子恢复 |

阶段命令里的历史 source 身份保留原值。最终引擎资格使用 qualified-*；不能把前面的格式/错误 profile/新 frame 超容量失败当成通过。
正式 VM counters OFF 的原始零输出不解释为“零工作”；解释后的 result.json/analysis.json 使用 null。
计时只含 30 个有效 AB/BA/AB 进程，不含 profile、内存或 debugger。
迁址隐藏了实际资格源码/两构建树/原 SDK；开发克隆因占用保持可见，不能声称所有源码都消失。
''',encoding='utf-8')
print(json.dumps(dict(files=len(files),bytes=archive.stat().st_size,sha256=sha)))
