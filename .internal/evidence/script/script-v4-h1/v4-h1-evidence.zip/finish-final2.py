from pathlib import Path
r=Path(__file__).parent
s=(r/'machine-code.py').read_text().replace("('machine-'+side+'-full')", "('machine-'+side+'2-full')")
s=s.replace("binary=root/variant/module", "binary=root/variant.replace('final-', 'final2-')/module")
(r/'machine-final2.py').write_text(s)
s=(r/'layout-probe.py').read_text().replace("out=r/'layout'", "out=r/'layout-final2'")
s=s.replace("image=(r.parent/'script-v4' if side=='A' else r)/'final-image'", "image=r.parent/'script-v4/final-image' if side=='A' else r/'final2-image'")
(r/'layout-final2.py').write_text(s)
s=(r/'installed-final.ps1').read_text().replace('$r/installed','$r/installed-final2').replace('$r/value-incremental','$r/value-incremental-final2')
(r/'installed-final2.ps1').write_text(s)
s=(r/'relocated-qualified-source.ps1').read_text().replace("'relocated'", "'relocated-final2'")
(r/'relocated-final2.ps1').write_text(s)
