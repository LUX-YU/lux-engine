from pathlib import Path
import subprocess,re,json
r=Path('E:/RenderV2Rebuild/Layer/v/src');base='7ca2828d60df50e54ed299efeb1cbab20cf369ad'
def git(*a):return subprocess.check_output(['git','-C',str(r),*a],text=True).strip()
paths=git('diff','--no-renames','--name-only',base,'HEAD').splitlines()
production=[p for p in paths if p.endswith(('.hpp','.cpp')) and '/test/' not in p and not p.startswith('.internal/')]
def types(s):
 return set(re.findall(r'^\s*(?:class|struct|enum class)\s+(?:\w+::)*(\w+)(?:\s+final|\s*[:{])',s,re.M))
old=set();new=set()
for p in production:
 exists=subprocess.run(['git','-C',str(r),'cat-file','-e',base+':'+p],capture_output=True).returncode==0
 if exists:old|=types(git('show',base+':'+p))
 if (r/p).exists():new|=types((r/p).read_text())
out={'implementation':git('rev-parse','HEAD'),'production_cpp_headers':production,'added_definition_names':sorted(new-old),'removed_definition_names':sorted(old-new),'note':'Definition names, excludes tests, forwards, concepts and aliases; relocation across changed files cancels; namespace overloads share a name. Owner semantics audited separately.'}
p=Path('E:/RenderV2Rebuild/Layer/evidence/L4/production-delta.json');p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='production_cpp_headers'},indent=2))
