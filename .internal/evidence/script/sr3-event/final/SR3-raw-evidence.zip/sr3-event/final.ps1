$ErrorActionPreference='Stop'
$base='E:/SyncForder/CodeRepos'
$repo="$base/lux-engine-sr3-event"
$logs="$base/build/RelWithDebInfo/sr3-event"
$python='C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
$deps="$base/install/q2/toolset;$base/install/q2/c;$base/install/RelWithDebInfo"
& "$repo/cmake/RunScriptV3Qualification.ps1" -SourceDir $repo -BuildRoot "$base/build/RelWithDebInfo/sr3-e" -InstallRoot "$base/install/sr3-e" -CxxPrefix "$base/install/q2/c" -ToolsetPrefix "$base/install/q2/toolset" -FoundationPrefix "$base/install/RelWithDebInfo" -Profiles toolchain,developer *> "$logs/qualification-driver.log"
$q=@(Get-Content "$base/build/RelWithDebInfo/sr3-e/qualification.json" -Raw | ConvertFrom-Json)
if($q.Count -ne 2 -or @($q | Where-Object status -eq 'BLOCKED').Count) { throw 'Final qualification blocked' }
Write-Output 'Qualification complete; expected historical six failures require separate review.'
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$env:LUX_FLOWFORGE_LINKER=Join-Path $env:VCToolsInstallDir 'bin/Hostx64/x64/link.exe'
foreach($old in @('sr3-reference','sr3-c3')) {
 New-Item -ItemType Directory -Force "$logs/reference-refresh/$old" | Out-Null
 foreach($profile in @('t','d')) {
  cmake --build "$base/build/RelWithDebInfo/$old/$profile" --target all -j 4 -- -k 0 *> "$logs/reference-refresh/$old/$profile-all.log"
  if($LASTEXITCODE -ne 0) { throw 'Reference refresh build failed' }
 }
 ctest --test-dir "$base/build/RelWithDebInfo/$old/d" -R '^scene_script_lua_runtime' --output-on-failure *> "$logs/reference-refresh/$old/historical-lua.log"
 "ctest_exit=$LASTEXITCODE" | Set-Content "$logs/reference-refresh/$old/exit.log"
}
& "$repo/cmake/RunScriptSR3Validation.ps1" -BaselineSource "$base/lux-engine-sr3-reference" -CandidateSource $repo -BaselineInstall "$base/install/sr3-reference" -CandidateInstall "$base/install/sr3-e" -OutputRoot "$base/build/RelWithDebInfo/sr3-e-checks" -Python $python -SkipMeasurements *> "$logs/validation-driver.log"
Write-Output 'Consumers, B0 traces/wire, scale, cold and allocation checks complete.'
foreach($v in @(@('b0','lux-engine-sr3-reference','sr3-reference'),@('b3','lux-engine-sr3-event','sr3-e'))) {
 & $python -B "$repo/cmake/BuildScriptEventBenchmark.py" --source $repo --runtime-source "$base/$($v[1])" --prefix "$base/install/$($v[2])/t" --dependencies $deps --output "$logs/observer-$($v[0])" *> "$logs/observer-$($v[0])-driver.log"
 if($LASTEXITCODE -ne 0) { throw 'Matched observer build failed' }
}
foreach($pair in @(@('b2-b3','sr3-c3','b2'),@('b0-b3','sr3-reference','b0'))) {
 & $python -B "$repo/cmake/RunScriptSR2Measurements.py" --baseline "$base/install/$($pair[1])" --candidate "$base/install/sr3-e" --output "$logs/final-$($pair[0])" --short-path-frames 3000 --event-frames 3000 --affinity-mask 1 --baseline-flow-executable "$logs/observer-$($pair[2])/build/script_event_observer.exe" --candidate-flow-executable "$logs/observer-b3/build/script_event_observer.exe" *> "$logs/$($pair[0])-driver.log"
 if($LASTEXITCODE -ne 0) { throw 'Final matched measurements failed' }
 Write-Output "Measured $($pair[0])."
}
& $python -B "$repo/cmake/SummarizeScriptCost.py" --root $logs --comparisons b2-b3 b0-b3 --output "$logs/cost-results.json" *> "$logs/cost-summary.log"
if($LASTEXITCODE -ne 0) { throw 'Work normalization failed' }
$common=@('--baseline-source',"$base/lux-engine-sr3-cost-final",'--candidate-source',$repo,'--baseline-prefix',"$base/install/sr3-c3/d",'--candidate-prefix',"$base/install/sr3-e/d",'--dependencies',$deps)
& $python -B "$repo/cmake/RunScriptSR3Scale.py" @common --output "$logs/b2-b3-scale" *> "$logs/b2-b3-scale-driver.log"
if($LASTEXITCODE -ne 0) { throw 'Scale check failed' }
& $python -B "$repo/cmake/RunScriptSR2Probes.py" @common --output "$logs/b2-b3-probes" *> "$logs/b2-b3-probes-driver.log"
if($LASTEXITCODE -ne 0) { throw 'Cold check failed' }
Write-Output 'Final event closeout validation complete.'
