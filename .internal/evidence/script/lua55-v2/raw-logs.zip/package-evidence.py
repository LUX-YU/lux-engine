from pathlib import Path
import hashlib,json,zipfile,subprocess
r=Path(__file__).parent;repo=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source');out=repo/'.internal/evidence/script/lua55-v2';out.mkdir(parents=True,exist_ok=True)
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
manifest=[dict(path=str(f.relative_to(r/'final-image')),bytes=f.stat().st_size,sha256=digest(f)) for f in sorted((r/'final-image').iterdir()) if f.is_file()]
(r/'final-image-manifest.json').write_text(json.dumps(manifest,indent=2))
(r/'git-final-integrity.json').write_text(json.dumps(dict(source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),status=subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True),fsck_connectivity_exit=0,protected_main='protected-workspace-final.json',note='Partial development-clone relocation restored; source and qualification clones were clean before cost capture.'),indent=2))
(r/'relocation-tool-limit.json').write_text(json.dumps(dict(action='Remove verified empty partial relocation directory',outcome='tool automatic approval rejected before execution',reported_reason='blocked by policy',retained_path='E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source.v2-unavailable',files=0),indent=2))
source_manifest=[]
for prefix in ['sdk','tools','lua55']:
 p=Path('E:/SyncForder/CodeRepos/install/o/v2')/prefix
 # Installed binary/header/tool identities, without putting products into the evidence ZIP.
 for f in sorted(p.rglob('*')):
  if f.is_file():source_manifest.append(dict(prefix=prefix,path=str(f.relative_to(p)),bytes=f.stat().st_size,sha256=digest(f)))
(r/'installed-final-manifest.json').write_text(json.dumps(source_manifest,indent=2))
selected=set()
root_extensions={'.log','.json','.txt','.ps1','.py','.cpp','.c','.patch'}
for f in r.iterdir():
 if f.is_file() and f.suffix.lower() in root_extensions:selected.add(f)
for folder in ['p3-gc-msvc','p6-clang-inc','final-costs','memory-diagnostic','value-incremental']:
 for f in (r/folder).rglob('*'):
  if f.is_file() and f.suffix.lower() in {'.log','.json','.csv','.hpp'}:selected.add(f)
for folder in ['installed','relocated']:
 for f in (r/folder).glob('*.json'):selected.add(f)
 for consumer in (r/folder).iterdir():
  if not consumer.is_dir():continue
  for f in consumer.glob('*.log'):selected.add(f)
  for f in (consumer/'build').glob('compile_commands.json'):selected.add(f)
# Reject products; source code/patches and text records only.
assert not any(f.suffix.lower() in {'.exe','.dll','.pdb','.obj','.lib','.bc','.zip'} for f in selected)
files=[dict(path=str(f.relative_to(r)).replace('\\','/'),bytes=f.stat().st_size,sha256=digest(f)) for f in sorted(selected)]
assert len(files)<1000,len(files)
archive=out/'raw-logs.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f,item in zip(sorted(selected),files):z.write(f,item['path'])
 z.writestr('MANIFEST.json',json.dumps(dict(qualification='a6f16d6de6a67f6a4422553d31b42c1ac2b3e4c0',files=files),indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for f in files:assert hashlib.sha256(z.read(f['path'])).hexdigest()==f['sha256']
sha=digest(archive);(out/'raw-logs.zip.sha256').write_text(sha+'  raw-logs.zip\n')
(out/'archive.json').write_text(json.dumps(dict(qualification='a6f16d6de6a67f6a4422553d31b42c1ac2b3e4c0',sha256=sha,bytes=archive.stat().st_size,files=len(files),binary_products_included=False),indent=2))
(out/'INDEX.md').write_text('''# Lua55 v2 原始证据

资格源码：`a6f16d6de6a67f6a4422553d31b42c1ac2b3e4c0`。文档提交不产生新测试身份。

[原始记录 ZIP](raw-logs.zip) · [SHA-256](raw-logs.zip.sha256) · [归档身份](archive.json)

归档内 MANIFEST.json 逐项记录路径、字节数和 SHA-256；打包后已逐项重新读取核验。
没有 EXE、DLL、PDB、LIB、OBJ 或 bitcode 产品。最终产品与 PDB 在受控本地 final-image 保留，哈希在包内 final-image-manifest.json。

| 内容 | ZIP 内入口 |
|---|---|
| 开工、固定依赖与工作区 | start.json；fixed-dependencies-audit.json；fixed-dependency-additional-files.json；protected-workspace-final.json |
| 最终 Developer / Toolchain | qualified-d-*；qualified-t-*；qualified-tracked.* |
| 最终 VM r2 | p8-vm-r2-linkage-*；vm-final-noop.log；installed-final-manifest.json |
| 旧接口拒绝 | legacy-selector-rejected.*；legacy-selector-restore.log |
| 当前 SDK | installed/closure-consumers.json；installed/*/closure-*.log |
| 迁址 SDK 实际执行 | relocated/results.json；relocated/unavailable-paths.json；relocated/*/run.log |
| 值生成增量 | value-incremental/probes.json 与各次 generated.hpp/log |
| 冷期容量修前/修后 | p7-reload-before-*；qualified-d-LastTest.log 的 COLD_CONTENT/COLD_RELOAD |
| 整体三轮成本 | final-costs/identities.json、runs.json、summary.json、work-oracles.json 与各次 CSV/log |
| 独立内存诊断 | memory-diagnostic/results.json 与两侧 CSV/log |
| 一次 GC / compiler 对照 | p3-gc-msvc/runs.json；p6-clang-inc/runs.json |
| 静态真实 FlowForge 尝试 | flow-bitcode.patch；static-provider.cpp；static-link.ps1；p8-static-* |
| 上游测试适配 | upstream-windows-devices-final.patch；p8-vm-r2-linkage-tests.log |
| 无效迁址与恢复 | relocated*-driver.log；partial-relocation-restored.json；relocation-tool-limit.json |

早期失败、未采用实验和原始退出码均保留。`final-*` 是收尾复核前的 0333ef0f 一轮，最终资格必须使用 `qualified-*`；
`closure-*` 包含扩展头 C++ linkage 修前失败，不能当作最终通过记录。
''')
print(json.dumps(dict(files=len(files),bytes=archive.stat().st_size,sha256=sha),indent=2))
