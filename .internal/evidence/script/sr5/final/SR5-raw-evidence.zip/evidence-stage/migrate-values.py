from pathlib import Path
root = Path(__file__).parent / 'source'
test = root / 'engine/domain/simulation/scripting/lua/test'
for name, function, variable in [('lua_backend_test.cpp','pushCollisionEvent','collision_marshaller'),('collision_event_chain_test.cpp','pushCollision','marshaller')]:
    p = test / name
    s = '#include "CollisionValue.lua.value.generated.hpp"\n' + p.read_text()
    a = s.index('    struct CollisionEvent final')
    b = s.index('    };', a) + len('    };')
    s = s[:a] + s[b:]
    a = s.index('    bool ' + function + '(')
    b = s.index('\n    }', a) + len('\n    }')
    s = s[:a] + s[b:]
    a = s.index('    const LuaRecordMarshaller ' + variable + '{')
    b = s.index(';',a)+1
    s = s[:a] + '    constexpr auto ' + variable + ' = lux::script::lua::makeLuaValueOperation<CollisionEvent>();' + s[b:]
    s = s.replace('.record_marshallers = ', '.values = ')
    p.write_text(s)
p = root / 'engine/domain/simulation/scripting/lua/CMakeLists.txt'
with p.open('a') as out:
    out.write('''
# SR-5 fixtures have one generated value owner shared by their real consumers.
include_component_cmake_scripts(script_lua)
add_library(simulation_script_lua_value_fixtures STATIC test/lua_value_fixtures.cpp)
target_link_libraries(simulation_script_lua_value_fixtures PUBLIC lux::engine::simulation::simulation_script_lua)
target_include_directories(simulation_script_lua_value_fixtures PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/test)
lux_script_lua_values(TARGET simulation_script_lua_value_fixtures
    SOURCES ${CMAKE_CURRENT_SOURCE_DIR}/test/CollisionValue.hpp ${CMAKE_CURRENT_SOURCE_DIR}/test/LuaValueTestTypes.hpp
    RULE_HEADERS ${CMAKE_CURRENT_SOURCE_DIR}/test/LuaValueTestRules.hpp)
lux_classify_target(TARGET simulation_script_lua_value_fixtures LAYER SIMULATION PRODUCT TEST ROLE DOMAIN)
target_link_libraries(simulation_script_lua_test PRIVATE simulation_script_lua_value_fixtures)
if(TARGET simulation_script_collision_event_test)
    target_link_libraries(simulation_script_collision_event_test PRIVATE simulation_script_lua_value_fixtures)
endif()
add_executable(simulation_script_lua_value_boundary_test
    ${PROJECT_SOURCE_DIR}/modules/function/script/lua/test/lua_value_test.cpp)
target_link_libraries(simulation_script_lua_value_boundary_test PRIVATE lux::engine::function::script_lua
    lux::engine::function::script_lua_vm)
if(MSVC)
    target_compile_options(simulation_script_lua_value_boundary_test PRIVATE /UNDEBUG)
else()
    target_compile_options(simulation_script_lua_value_boundary_test PRIVATE -UNDEBUG)
endif()
lux_classify_target(TARGET simulation_script_lua_value_boundary_test LAYER SIMULATION PRODUCT TEST ROLE DOMAIN)
add_test(NAME simulation_script_lua_value_boundary_test COMMAND simulation_script_lua_value_boundary_test)
''')
