from pathlib import Path
p=Path(r'E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1/source/engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptExecution.hpp')
t=p.read_text().replace('std::vector<ResumeRecord> records;', 'std::vector<ScriptAwaitableId> records;').replace('bool push(ResumeRecord record)', 'bool push(ScriptAwaitableId record)').replace('std::optional<ResumeRecord> pop()', 'std::optional<ScriptAwaitableId> pop()')
t=t.replace('resumes_.push({record.instance, record.continuation, record.id})', 'resumes_.push(record.id)').replace('resumes_.push({instance, continuation, awaitable})', 'resumes_.push(awaitable)')
t=t.replace('ResumeRecord resume, ExecutionAccess access, std::optional<AwaitableOutcome>& outcome', 'AwaitableRecord& value, ExecutionAccess access, std::optional<AwaitableOutcome>& outcome')
a=t.index('            auto* record = awaitables_.find(awaitableKey(resume.awaitable));',t.index('        [[nodiscard]] bool takeAwaitable('))
b=t.index('            outcome.emplace',a)
t=t[:a]+'''            auto* record = &value;
            if (record->state != EScriptAwaitableState::READY && record->state != EScriptAwaitableState::FAILED)
                return false;
'''+t[b:]
t=t.replace('resumeOne(ResumeRecord resume) noexcept\n        {', '''resumeOne(ScriptAwaitableId ready) noexcept
        {
            auto* wait = awaitables_.find(awaitableKey(ready));
            if (wait == nullptr) return {};
            const ResumeRecord resume{wait->instance, wait->continuation, ready};''')
t=t.replace('takeAwaitable(resume, execution, outcome)', 'takeAwaitable(*wait, execution, outcome)')
t=t.replace('            const auto symbol = instance_owner_.methodSymbol(continuation->method_slot);\n            if (result.state', '            if (result.state')
t=t.replace('                const auto error = attached.error();\n                destroyContinuation', '                const auto error = attached.error();\n                const auto symbol = instance_owner_.methodSymbol(continuation->method_slot);\n                destroyContinuation')
t=t.replace('            const auto status = result.error.status;\n            destroyContinuation', '            const auto status = result.error.status;\n            const auto symbol = instance_owner_.methodSymbol(continuation->method_slot);\n            destroyContinuation')
p.write_text(t,encoding='utf-8')
