from pathlib import Path
b=Path('E:/RenderV2Rebuild/Layer/source/modules/function/render')
p=b/'runtime/test/Offscreen.cpp';s=p.read_text().replace('std::make_shared<const buffer_fixture::Config>()}));','std::make_shared<const buffer_fixture::Config>(), storageCppType<buffer_fixture::Config>()}));');p.write_text(s)
p=b/'runtime/src/RenderServer.cpp';s=p.read_text().replace('        for (const auto& existing : storage_types)','        if (storage.configuration && storage.configuration_type != storage.factory.config_type)\n            return cxx::unexpected(RenderError{kStorageMismatch});\n        for (const auto& existing : storage_types)');p.write_text(s)
