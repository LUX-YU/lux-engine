#!/usr/bin/env python3
"""Run a reduced control-flow probe, not the Lux engine test suite.
An exit code of 0 means the observations and illustrative comparison completed.
It does not mean the original implementation passed the target safety contract.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import tempfile

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=Path(__file__).with_name('results.json'))
    args = parser.parse_args()
    source = Path(__file__).with_name('reload_input_lifetime.cpp')
    report = {'scope': 'reduced C++20 control-flow probe; NOT actual Lux engine execution',
              'reviewed_commit': '7ead91c5f111c5edfd7d9f156e23e3f00af4a8eb',
              'dll_loaded': False, 'repository_modified': False, 'runs': [], 'skipped_compilers': []}
    with tempfile.TemporaryDirectory(prefix='lux-p03-probe-') as temp:
        for compiler_name in ('clang++', 'g++'):
            compiler = shutil.which(compiler_name)
            if not compiler:
                report['skipped_compilers'].append(compiler_name)
                continue
            version = subprocess.run([compiler, '--version'], text=True, capture_output=True, check=True).stdout.splitlines()[0]
            for level in ('-O0', '-O2'):
                output = Path(temp) / (compiler_name.replace('+', 'p') + level)
                command = [compiler, '-std=c++20', level, '-Wall', '-Wextra', '-pedantic', str(source), '-o', str(output)]
                built = subprocess.run(command, capture_output=True, text=True, timeout=30)
                row = {'compiler': version, 'optimization': level, 'build_command': command,
                       'build_exit_code': built.returncode, 'build_stdout': built.stdout, 'build_stderr': built.stderr}
                if built.returncode:
                    report['runs'].append(row)
                    continue
                ran = subprocess.run([str(output)], capture_output=True, text=True, timeout=10)
                row.update({'run_exit_code': ran.returncode, 'stdout': ran.stdout, 'stderr': ran.stderr})
                rows = [json.loads(line) for line in ran.stdout.splitlines() if line.strip()]
                for case in rows:
                    case['safe_under_target_contract'] = (case['accepted'] == 0 and case['destructions'] == 1
                         and case['nested_edit'] == 0 and case['author_value'] == 0 and case['expired_in_destructor'] == 0)
                row['observations'] = rows
                report['runs'].append(row)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    complete = bool(report['runs']) and all(r.get('run_exit_code') == 0 and len(r.get('observations', [])) == 6 for r in report['runs'])
    expected_failures = complete and all(not r['observations'][0]['safe_under_target_contract'] for r in report['runs'])
    illustrative_safe = complete and all(all(x['safe_under_target_contract'] for x in r['observations'][3:]) for r in report['runs'])
    print(json.dumps({'probe_completed': complete, 'original_failure_observed': expected_failures,
                      'illustrative_local_ownership_safe_in_probe': illustrative_safe,
                      'lux_engine_tests_run': False, 'report': str(args.out)}, ensure_ascii=False))
    return 0 if complete and expected_failures and illustrative_safe else 1

if __name__ == '__main__':
    raise SystemExit(main())
