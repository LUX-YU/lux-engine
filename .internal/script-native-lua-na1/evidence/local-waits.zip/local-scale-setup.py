from pathlib import Path
r=Path.cwd();p=r/'local-source/cmake/RunScriptSR3Scale.py';t=p.read_text();t=t.replace('from RunScriptSR2Probes import','import sys\nsys.path.insert(0, str(Path(__file__).parent / "local-source/cmake"))\nfrom RunScriptSR2Probes import');assert t.count('range(5)')==1;t=t.replace('range(5)','range(1)');(r/'local-scale.py').write_text(t)
