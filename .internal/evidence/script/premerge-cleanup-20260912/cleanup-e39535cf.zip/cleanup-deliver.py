from pathlib import Path
import csv,hashlib,json,re,shutil,subprocess,zipfile
r=Path(__file__).parent;s=r/'source';e=s/'.internal/evidence/script/premerge-cleanup-20260912';e.mkdir(parents=True,exist_ok=True)
q=r/'local-source'
source=subprocess.check_output(['git','-C',str(q),'rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','-C',str(q),'status','--porcelain'],text=True).strip()
def read(p):return json.loads((r/p).read_text(encoding='utf-8-sig'))
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for name in ['devpass','toolpass']:
 for step in ['configure','build','noop','tests','install']:
  x=read(f'cleanup-20260912/{name}-{step}.json');assert x['exit']==0 and x['source']==source
 assert 'no work to do' in (r/f'cleanup-20260912/{name}-noop.log').read_text()
consumers=read('cleanup-installed/consumers.json'); assert len(consumers)==16 and all(x['status']=='PASS' for x in consumers)
increments=read('cleanup-value-incremental/probes.json');assert len(increments)==13
assert all((x['exit']==0)==x['expected_success'] for x in increments)
steps=read('cleanup-new-incremental/results.json');assert len(steps)==5 and all(x['negative_rejected'] and x['restored_execution'] and x['restored_noop'] for x in steps)
relocations=read('cleanup-relocated/results.json');assert len(relocations)==3 and all(x['status']=='PASS' for x in relocations)
costs=read('cleanup-costs/summary.json');runs=read('cleanup-costs/runs.json');assert len(runs)==78 and all(x['valid'] for x in runs)
vm=read('cleanup-vm-tests.json');assert vm['exit']==0
extra=read('cleanup-20260912/retry-retired-diagnostic-protected-errors.json');assert extra['exit']==0
findings=[
 ('F01','FIXED','Lua converted synchronous entry captures original qualification before conversion and rechecks before Lua body; small scalar path unchanged','final-oracles.log: CONVERSION_AUTHORITY modes 2-5'),
 ('F02','FIXED','Shared ceil conversion rejects exact exclusive 2^63 bound before integer cast','final-oracles.log: TIMER_BOUNDARY/TIMER_ROUNDING/REAL_TIMER_BOUNDARY'),
 ('F03','FIXED','Inline resize copies only when moving from spill; inline self-copy removed','final-oracles.log: OWNED_BYTES'),
 ('F04','REMOVED','Write-only resume_enqueued; unused awaitableId and Lua scalar reader removed','source diff; Developer/Toolchain all'),
 ('F05','SIMPLIFIED','Ticket and Allocation checked adapters share releaseResolved; keep owner/generation/active and external data/size checks','final-oracles.log: STORAGE_TICKET; machine-excerpts.asm'),
 ('F06','SIMPLIFIED_NOT_ZERO_COPY','Internal optional metadata borrowed; explicit byte/type clear removes temporary owned result; take still releases logical slot before user resume','machine-excerpts.asm; pin/cancellation/capacity suite'),
 ('F07','HOISTED','Native step layout remains loader/preparation responsibility; resolved kernel receives local step reference','NativeScriptBackend.cpp diff; Native/FlowForge/installed suites'),
 ('F08','PARTIAL_CHECK_RETAINED','One Timer lookup before completion; keep post-callback cancel because the callback may detach/move storage','ScriptTimers.cpp; TIMER_RETRY and cancellation tests'),
 ('F09','SIMPLIFIED','Bounded feedback ring preserves first-dirty/ack order without shifting unconsumed items','final-oracles.log: FEEDBACK_WRAP'),
 ('F10','CORRECTED','INTEGRITY failures size is retained_failures, not idle_page_backing; historical raw files unchanged','benchmark source diff; new raw performance logs'),
 ('F11','MIGRATED','Retired LuaRecordMarshaller branch removed; default diagnostic uses current generated Lua55 codec','retry-retired-diagnostic-* logs'),
 ('F12','FIXED_EXISTING_TOOL_GAP','Relative style source paths resolve absolutely; missing/empty engine scan rejected','style-relative-negative.log and style-relative-positive.log'),
]
with (e/'findings.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.writer(f);w.writerow(['id','status','change','evidence']);w.writerows(findings)
copies={'final-oracles.log':'cleanup-20260912/final-oracles.log','machine-excerpts.asm':'cleanup-20260912/machine-excerpts.asm',
 'machine-summary.json':'cleanup-20260912/machine-summary.json','identity.json':'cleanup-20260912/final-identity.json',
 'artifact-files.json':'cleanup-20260912/artifact-files.json','performance-summary.json':'cleanup-costs/summary.json',
 'performance-runs.json':'cleanup-costs/runs.json','profile-summary.json':'cleanup-20260912/profile-summary.json',
 'resource-summary.json':'cleanup-20260912/resource-summary.json'}
for dest,src in copies.items():shutil.copy2(r/src,e/dest)
(e/'.gitattributes').write_text('* -text -whitespace\n')
# Raw data only. Never add compiled engine/SDK binaries to the repository archive.
files=set()
for folder in ['cleanup-20260912','cleanup-costs','cleanup-resources','cleanup-profiles','cleanup-machine-code',
               'cleanup-class-layout','cleanup-value-incremental','cleanup-new-incremental']:
 for p in (r/folder).rglob('*'):
  if p.is_file() and p.suffix.lower() not in ['.dll','.exe','.pdb','.obj','.lib','.pch']:files.add(p)
for folder in ['cleanup-installed','cleanup-relocated','cleanup-value-cost-consumer']:
 for p in (r/folder).rglob('*'):
  if p.is_file() and (p.suffix in ['.log'] or p.name in ['consumers.json','results.json','unavailable-paths.json','CMakeCache.txt','compile_commands.json']):files.add(p)
for p in r.glob('cleanup-*'):
 if p.is_file() and p.suffix in ['.py','.ps1','.json','.log','.csv']:files.add(p)
files.add(r/'profile-target.py')
entries=[dict(path=p.relative_to(r).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(files)]
(e/'archive-files.json').write_text(json.dumps(entries,indent=2))
archive=e/f'cleanup-{source[:8]}.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(files):z.write(p,p.relative_to(r).as_posix())
 z.writestr('archive-files.json',(e/'archive-files.json').read_bytes())
with zipfile.ZipFile(archive) as z:
 for x in entries:assert hashlib.sha256(z.read(x['path'])).hexdigest()==x['sha256']
archive_sha=sha(archive);(e/(archive.name+'.sha256')).write_text(f'{archive_sha}  {archive.name}\n')
qualification={'developer':{'passed':131,'total':131},'toolchain':{'passed':110,'total':110},'vm_contracts':4,
 'installed_consumers':consumers,'value_incrementals':increments,'step_incrementals':steps,'relocations':relocations,
 'supplemental_generated_codec_diagnostic':'PASS; first invocation omitted compile_commands export, retained as invalid configuration'}
result={'baseline_source':'841320a36e864145eda43fd6b775a10a696d8e7f','working_entry':'7c5b9bcbbc8e0d9a7317c6981a5ab843c1578fb9',
 'qualification_source':source,'production_change_commit':'d45f9523d9d914e3aac151e59cd471310c519dae',
 'branch':'codex/s6-native-task-lua-steps','implementation':'CORRECTNESS_FIXED_AND_BOUNDED_CLEANUP_IMPLEMENTED',
 'contract':'PASS_TESTED_SCOPE','cost':'MIXED_WITH_SMALL_UNEXPLAINED_EVENT_REGRESSIONS','adoption':'NOT_APPROVED_PENDING_REVIEW',
 'findings':[dict(zip(['id','status','change','evidence'],x)) for x in findings],'qualification':qualification,'performance':costs,
 'timing_processes':78,'invalid_timing_processes':0,'resource_diagnostics':12,'profile':read('cleanup-20260912/profile-summary.json'),
 'archive':{'path':f'../evidence/script/premerge-cleanup-20260912/{archive.name}','bytes':archive.stat().st_size,'sha256':archive_sha,'raw_files':len(entries)},
 'limits':['P4 +1.57% and FlowForge Event +1.76% paired medians remain unexplained; not performance equivalence or accepted safety cost.',
 'Single software sample has no PMU evidence of cache misses or branch misprediction; no ns-per-resume inference from whole-frame cost.',
 'Wait record remains 240 bytes; ScriptInstances 576 -> 592 bytes for feedback cursors. Observed VM/owned accounting unchanged in six paired resource settings.',
 'Per-operation latency and uncollected allocations remain null. Windows RelWithDebInfo only; no old Lua VM or Android matrix.',
 'Typed converter errors return failure; raw longjmp through owning/noexcept C++ converter frames is not a supported contract.',
 'Repeated developer-shell initialization emitted command-line-length warnings in the chained driver; actual configure/compiler/build/runtime outputs passed. Retained as an environment warning.',
 'No merge to main, dependency upgrade, VM/GC/compiler change, or wider engine ownership rewrite.']}
(s/'.internal/script-native-lua-na1/cleanup-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
labels={'P1':'原生任务＋Lua：单 Event','P2':'原生任务＋Lua：NextStep','P3':'原生任务＋Lua：三等待','P4':'原生任务＋Lua：32 次 Event','P5':'原生任务＋Lua：ValuePose',
 'S1':'原 Lua scalar Ability','S2':'C++ Sequence','S3':'FlowForge Event','P6':'混合 Physics','L1':'原 Lua Event','L2':'原 Lua NextStep','L3':'C++ Update','L4':'FlowForge Update'}
table=[]
for x in costs:
 scale=1e6 if x['leg'] in ['S2','P6'] else 1;unit='ms/原帧' if scale!=1 else 'ns/完整调用或任务'
 table.append(f"| {labels[x['leg']]} | {x['A_ns']/scale:.3f} | {x['B_ns']/scale:.3f} | {x['median_percent']:+.2f}% | {' / '.join(f'{v:+.2f}%' for v in x['deltas_percent'])} | {unit} |")
doc=f'''# 合并前脚本清理与有限优化结果

正确性修正和本轮有限清理已实施，测试范围内通过。**成本为混合结果，尚不能标为性能收口，也不代表批准合并。** 32 次 Event 长任务和 FlowForge Event 各有约 2% 的新增小回退，原样登记；未用其他场景收益抵消。

## 身份与入口

- 修前生产及封存 E 镜像：`841320a36e864145eda43fd6b775a10a696d8e7f`；任务入口审计提交 `7c5b9bcb`。
- 最终实际资格源码：`{source}`，独立 clean clone、F/F-common/F-flow 镜像。后续报告/归档提交不是新测试身份。
- 固定 lux-cxx `3100f54d`、toolset `99c3d048`；实际安装的 204 项依赖文件重新校验。Lua 5.5.1 原 DLL 哈希、VM patch、INC、16 MiB、Native ABI6、MSVC 19.44/RelWithDebInfo 均保持。
- main 的 7 项未知修改逐项哈希一致。仅在 `codex/s6-native-task-lua-steps` 提交，不合并 main。
- [修前审计和负例](PREMERGE-AUDIT.zh-CN.md)、[本轮逐项结果](../evidence/script/premerge-cleanup-20260912/findings.csv)、[机器可读结果](cleanup-result.json)、[原始归档入口](../evidence/script/premerge-cleanup-20260912/INDEX.md)。

## 实际修改

1. **F01：普通同步 Lua 参数转换。** 准备期将可能执行 converter 的调用选到受保护入口，在转换前捕获原资格，转换后、Lua 函数体前重验。保留 standalone、生命周期和延迟 stop；小 scalar 入口不增加该协议。外层 ExecutionScope 的拥有型状态位于 pcall 外，C callback 只借用对象；typed converter 返回失败，不允许 longjmp 越过其拥有型 C++ 局部对象。
2. **F02/F03：边界正确性。** Simulation/real delay 共用排他 2^63 上界检查，先 ceil 后验证、再 cast；保留原错误优先级。小缓冲扩缩容只有 spill→inline 才复制，移除 inline 的同地址 memcpy。
3. **F04/F05：死代码和释放。** 删除无读者的 resume_enqueued、未调用的 awaitableId 和 Lua scalar reader。Ticket 与 Allocation 各自完成必要外部验证后，共用一个 releaseResolved；不再构造 Allocation 重新验证自己。
4. **F06/F07/F08：短区间复用。** 内部 optional 类型描述改为只读借用；结果槽直接清理 bytes/type，减少临时拥有型结果。Native 准备好的 step 布局不在创建 continuation 时重复验证。Timer 完成前只定位一次，回调后仍按 ID 取消，防止使用已移动/释放的记录。
5. **F09/F10/F11：反馈与工具。** 反馈改有界环形队列，部分 collect 不再搬动所有剩余元素；仍按首次变脏顺序确认。INTEGRITY 中的 failures 数改名 retained_failures，不再冒充空页内存。旧成本 fixture 删除 LuaRecordMarshaller 分支，默认使用当前生成 codec；不同职责的 ProtectedRecord 诊断保留。
6. **F12：检查工具的旧缺口。** 样式脚本现在解析相对路径并拒绝空扫描；原先 `-DLUX_SOURCE_DIR=.` 可能假通过。未扩展到全仓库格式重写。

没有新的 scheduler、结果池、公共 trusted 参数、兼容别名或语言功能。身份/容量/取消/写 pin/事件 cutoff/恢复预算和逻辑槽归还时点保持。

## 正确性与安装

[真实 oracle 输出](../evidence/script/premerge-cleanup-20260912/final-oracles.log)包含：

- 转换保持有效：body=1/provider=1；实际退休：body=0/provider=0；只请求 stop：body=1/provider=1；转换返回失败：body=0/provider=0。关闭后 prepared 槽释放，无新增任务 Lua thread。
- 本地和通用 Timer 各检查边界相邻三个 double；越界 waits=0/errors=1。1.1 ns 在 1 ns 后不恢复、2 ns 后恰好恢复一次；elapsed 叠加溢出被拒绝。real delay 合法输入 endpoint=1，越界 endpoint=0，关闭后旧 completion 失效。
- 内联/溢出存储、移动、自移动、错 alignment；票据错 owner/page/slot、旧 generation、重复释放、外部 data/size 不匹配；反馈绕回和重新变脏顺序 `2,3,1`。

最终 Developer **131/131**、Toolchain **110/110**，两套全量 `all -j 4 -- -k 0` 和第二轮无工作；原 VM 合同 **4/4**。当前安装消费者 **16/16**，13 类值生成增量、5 类步骤/任务/路由负例、3 条迁址链通过；源码/构建/原 SDK 在迁址时不可用，结束均恢复。额外的已迁移成本 fixture 编译执行和 protected-errors 通过。

保留全部失败尝试：初始测试行宽失败；错误地假设登记失败也创建 continuation 的用例；不符合 typed converter 合同的直接 luaL_error 注入；额外诊断首次遗漏 compile_commands 导出。修正测试/驱动后通过，不能把这些初次运行记为 PASS。串联驱动多次进入 VS 环境出现命令行长度警告，实际编译路径、产物和执行已核对；不是生产测试回退。

## 同量成本

九个原完整场景加四个受影响语言控制组；各三对 AB/BA/AB，**78 个有效进程，未丢弃慢组**。固定 seed、affinity=16、预算、资产、warmup；统计/采样另跑。两边逐行业务及最终计数匹配，观测到的错误和 ready backlog 为零。[全部批量时间、实际操作数、p50/p95/p99 和配对](../evidence/script/premerge-cleanup-20260912/performance-runs.json)。

下表 A/B 是三个进程均值的中位数；变化列是三个配对变化的中位数，二者不能直接相除冒充同一个统计量。

| 场景 | A | B | 配对中位变化 | 三对变化 | 单位 |
|---|---:|---:|---:|---|---|
{chr(10).join(table)}

P4 新增约 **91.47 ns/完整 32 等待任务**（三对都慢）；这只是完整任务差异，不能分摊后声称已测到单次 resume 的成本。FlowForge Event 新增约 **3.34 ns/任务**，三对都慢。Physics 为混合场景，约 +0.019 ms/帧，不能归因到单一 backend。C++ Sequence 波动跨正负；FlowForge Update 三对离散很大，不能把中位数当稳定保证。上述差异未被认定为必要安全成本。

## 机器码、资源与热点

[机器码摘录](../evidence/script/premerge-cleanup-20260912/machine-excerpts.asm)：Ticket 入口静态指令 51→38，调用目标由重新 checked 的 Allocation 入口变为释放内核；它仍有一次真实调用。结果槽释放本体的 call 指令 2→1。admitAwaitable 本体仍为 151 条字节指令、9 个 call，不能仅凭 const 引用就宣称它本体变快；变化主要是调用方传递/临时对象，最终以完整业务为准。未全局 forceinline 或单侧 LTO。

AwaitableRecord 仍为 **240 B**；ScriptInstances 从 **576 B→592 B**，增加两个反馈游标。[六组配对资源观察](../evidence/script/premerge-cleanup-20260912/resource-summary.json)的 VM、frame 和 owned backing 计数相同；1000/10000 实例、P1/P4/P5 均保持释放闭环。不把瞬时 RSS/heap walk 差值说成确定内存收益。

新 P4 精确业务 ROI 软件 Hotspots 自耗时合计 3.636 s：waitEvent 9.90%、Lua 字符串键查找 6.85%、resumeOne 6.50%、结果槽释放 5.30%、C++ wait 3.73%。[采样摘要](../evidence/script/premerge-cleanup-20260912/profile-summary.json)及原始 result/导出在归档中。函数内联/归属变化会改变 self time；这次采样不能精确解释约 2% 的正式计时差异，也没有 PMU 证据支持 cache miss/分支预测归因。

## 状态与限制

- 实现：正确性缺口修正，有限清理完成；F08 的回调后取消检查明确保留。
- 合同：指定 Windows RelWithDebInfo 范围通过；未运行 Android、旧 Lua VM 或未授权环境。
- 成本：**混合，Event 小回退未解释，未完全收口**；不称等价、不用历史债务豁免新增差异，也不继续无边界微优化。
- 原 scalar/coroutine/Native metadata 等历史债务继续引用 [既有记录](LOCAL-WAIT-RESULT.zh-CN.md)，未重标旧源码或旧测试身份。
- 合并/正式采用：`NOT_APPROVED_PENDING_REVIEW`。不合并 main、不发布 tag、不开始新架构阶段。
'''
(s/'.internal/script-native-lua-na1/CLEANUP-RESULT.zh-CN.md').write_text(doc,encoding='utf-8')
(e/'INDEX.md').write_text(f'''# 本轮原始证据

实际资格源码 `{source}`；封存 E 参照 `841320a36e864145eda43fd6b775a10a696d8e7f`。

[完整归档]({archive.name})：{archive.stat().st_size} 字节，{len(entries)} 项原始文件及一份内部索引。
SHA-256：`{archive_sha}`。解压后的路径和逐项哈希见 [archive-files.json](archive-files.json)。

- `cleanup-20260912/`：构建、正确性、失败尝试、身份与机器码摘录。
- `cleanup-installed/`、`cleanup-value-incremental/`、`cleanup-new-incremental/`、`cleanup-relocated/`：真实 SDK、增量及迁址。
- `cleanup-costs/`：78 个有效进程的原始 CSV/log、命令、业务、配对分布。
- `cleanup-resources/`：独立资源计数；`cleanup-profiles/`：新软件 Hotspots 的原始 result 与导出。
- `cleanup-machine-code/`、`cleanup-class-layout/`：完整反汇编、类型布局及命令。静态指令计数不等于动态执行次数。

不含编译 DLL/PDB/EXE/OBJ；它们保存在本机封存镜像，身份见 [artifact-files.json](artifact-files.json)。
未采集的性能字段保持 null；历史原始文件不改写。
''',encoding='utf-8')
audit=s/'.internal/script-native-lua-na1/PREMERGE-AUDIT.zh-CN.md'
t=audit.read_text(); marker='后续实施与当前状态见 [清理结果](CLEANUP-RESULT.zh-CN.md)；下文保留修前审计和原始身份，不重标为修后验证。\n\n'
assert marker not in t;t=t.replace('\n\n','\n\n'+marker,1);audit.write_text(t,encoding='utf-8')
index=s/'.internal/UNFINISHED-WORK.md';t=index.read_text();old=next(l for l in t.splitlines() if l.startswith('| Script NA1 pre-merge correctness |'))
t=t.replace(old,'| Script NA1 cleanup / cost review | Correctness fixed; review pending | [Cleanup result](script-native-lua-na1/CLEANUP-RESULT.zh-CN.md) | F01–F03 regressions pass; P4 +1.57% and FlowForge Event +1.76% remain unexplained. No main merge or performance-equivalence approval. |');index.write_text(t,encoding='utf-8')
print('DELIVERY',archive.name,archive.stat().st_size,len(entries),archive_sha)
