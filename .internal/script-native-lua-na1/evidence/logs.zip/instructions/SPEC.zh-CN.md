# V4-NA1：原生任务编排 + 同步 Lua 步骤
## 独立分支实施、合同与完整成本比较规格

版本：1.0 / 2026-09-11  
性质：**待实施指令，不是已执行结果，不预先批准采用**。  
目标分支：`codex/s6-native-task-lua-steps`。  
仓库：`LUX-YU/lux-engine`。

> 核心要求：跨等待的控制流和必要数据由真正的 C++ coroutine frame 保存。Lua 步骤正常调用、正常返回；等待期间没有要继续恢复的 Lua 调用链。严禁实现成“C++ driver coroutine + 原 Lua coroutine”。

本文件是规范性主文档；`WORK_PLAN.json`、`TEST_MATRIX.csv`、`PERFORMANCE_PLAN.json` 和结果模板是它的机器可读索引。发生矛盾时不得自行选择更宽松解释，先以本文件的语义与安全要求为准，记录并修正包内索引。文中的新类型、函数和文件名是**建议实施名称**，不是声称仓库已经具备的 API。标为“示意”的代码不是可直接编译的交付代码。

---

## 0. 要回答的问题与完成范围

### 0.1 唯一主假设

在相同的业务输入、事件交付、稳定点、恢复预算和副作用时序下，用原生任务保存跨等待状态、用同步 Lua 方法执行业务计算，是否比 V4 的 fresh Lua coroutine 更快、更节省资源、更容易明确管理？

比较不是“Lua 和 C++ 算术谁快”。规定保留在 Lua 的业务运算不得搬到 C++ 来帮助候选获胜。比较也不是把 A 的 32 个新任务改成 B 的一个任务：长期任务场景的两侧都必须是一项包含相同次数等待的长期任务。

### 0.2 本轮必须完整实现的范围

1. 一个实际安装可消费的组合后端/适配模块，使用现有 C++ `ScriptCoroutine` 与同步 Lua 入口。
2. 一个逻辑脚本实例的权限、生命周期和多任务并发；不得通过增加第二个独立 ScriptSystem 或第二个实体脚本挂载绕过。
3. 同步步骤准备、标量/已有 record 输入、标量/void 输出、失败传播、取消与物理保活。
4. 原生 C++ 脚本中实际写 `co_await`，经过真实 CppStatic 注册、制品和运行路径；不是测试驱动手写假的状态机代替。
5. 五种主业务形状、三个原路径哨兵，以及一项混合 Physics 对照。全部按本包规定记录。
6. 新旧合同回归、最终 clean 源码构建、现有安装消费者、新消费者、生成增量与迁址验证。

### 0.3 本轮不把 FlowForge 新桥接作为成功前提

FlowForge 现有 Event 和混合 Physics 继续作真实回归。**FlowForge 生成任务调用新 Lua 同步步骤**属于后续第二消费者，不在本轮强制新增 Native C ABI、图节点和生成器能力。不得因完成 C++ 链而宣称“所有语言的新增编排已经打通”。

本轮完整结论的准确名称是 `CPP_NATIVE_ORCHESTRATION_WITH_LUA_STEPS`。不得把未做的 FlowForge 新桥接填成 PASS，也不得借此跳过既有 FlowForge 回归。

### 0.4 允许的最终结论

- 实现：`COMPLETE` / `PARTIAL` / `STRUCTURAL_BLOCKED`。
- 已测合同：`PASS` / `FAIL` / `INCOMPLETE`。
- 成本：`PROMISING` / `MIXED_TRADEOFF` / `NO_CLEAR_GAIN` / `REGRESSION` / `NOT_MEASURED`。
- 产品采用：本轮统一 `NOT_APPROVED_PENDING_REVIEW`。

完整、可信的负结果也是交付。不得因为性能为负就删测试、改业务、追加无界优化或只提交有利指标。

---

## 1. 固定起点、分支隔离与权限

### 1.1 身份

| 用途 | 固定身份 |
|---|---|
| V4 分支参考/开工提交 | `f92853ea8361a7dc90ce0da072497d3722c29f88` |
| V4 实际生产资格源码 | `f7d2815bdd2025ee23a7c11449def822413f58e9` |
| 新实验分支 | `codex/s6-native-task-lua-steps` |
| 不得作为本轮基线 | A1 ExecutionCell、H1 prepared-checks、任意当前 main |

已核对的远端 V4 引用仍指向上述开工提交 [S1]。实施开始必须再核对，不允许把某个后来移动的分支 HEAD 默认为相同源。

`f92853ea8` 与 `f7d2815b` 的引擎/模块/构建生产输入应一致，文档和证据提交不成为新的计时源码。开工比较实际输入列表；若发现生产差异，保留差异并停止基线固定，不自行认定无关。

### 1.2 保护范围

原 main 工作树、未知已跟踪/未跟踪改动、V4、A1、`codex/s6-v4-prepared-checks`、已有 SDK、旧测量镜像均受保护。禁止 `reset --hard`、`clean -fdx`、强制切换、强推、覆盖已存在分支、自动 stash 用户改动、修改旧 ZIP 或旧原始 CSV。

优先使用新的独立 clone。包内 `start_branch.py` 只创建隔离 clone 和本地分支、不推送、不构建，执行前读其说明。分支已存在必须核对并人工决定续行；不得删除重建或自动加后缀回避冲突。

最终可以正常提交并**只向新的同名实验分支推送**；不合并 main/V4，不发布 tag。旧原始证据只引用，不重新打包成新实验结果。

### 1.3 依赖与环境

沿用匹配 V4 的实际安装依赖、Lua DLL/头/PDB、编译器、CRT、ISA、IPO和运行线程约束。历史参考为：Lua 5.5.1 + `lux-lua55-v3-r2`、INC 原参数、16 MiB 完整空页预算、Native ABI6；lux-cxx `3100f54d0743c5ed94a4ccf5943df04e933de255`，toolset `99c3d0480d1db816779b1dfa7f3c06cb7d39a94f` [S2]。

这些是核验目标，不是要求伪造当前机器信息。若不能取得相同环境，可建立一套**双方重新运行的共同环境**并另行标识；不能将新环境 B 与旧历史 A 的纳秒值相减。无须恢复 Lua54/JIT。

### 1.4 三种源码身份分开

- `baseline_production_source`：固定 V4 生产代码。
- `common_test_source`：为本轮新增 fixture、命令、ROI 和业务 oracle 的测试层源码。
- `candidate_qualified_source`：最终 clean B 生产+测试源码。

允许把相同、测试层的驱动和新 Lua fixture用于 A/B；必须证明 A 的生产库没有包含候选桥接/行为修改。确有共同正确性前置补丁时，产生新的 `A_safe` 身份并双方应用；其收益不归给路线 A。

---

## 2. 已确认源码事实与本轮新设计的区别

### 2.1 必须先阅读的实际入口

| 文件/符号 | 已确认事实 | 本轮用途 |
|---|---|---|
| `LuaScriptBackend.hpp`、`LuaScriptBackend.cpp` | 私有 `State` 是 Pimpl；普通 invoke 用主 state，resumable start 创建 thread | 复用同步入口，纠正内部命名 |
| `ScriptBackend.hpp::ScriptInstanceCreateContext` | 带 instance/scope/behavior/capabilities/events | 保留同一逻辑 owner，传冷期同步步骤视图 |
| `ScriptBackendDescriptor` | create/prepare/release/destroy；以 kind 选择 | 组合后端，不新增 scheduler |
| `CppStaticScriptBridge.cpp` | 根据真实 contract/artifact准备；独立原生 frame；start 后检查 outcome | 复用原生任务执行生命周期 |
| `ScriptCoroutine.hpp` | `ScriptCoroutine` 为 void 任务；`unhandled_exception()` 为 terminate；自定义 frame 分配 | 不虚构 `Task<Result<T>>`，新增窄失败收敛 |
| `ScriptRuntime.hpp` | 通用 `{state,resume,destroy}` continuation、A/C、等待与结果 | 原核心协议继续存在 |
| `LuaValue.cpp/.hpp` | typed值、strict shape、内层callback栈额度、错误恢复 | 保留已有值与保护合同 |
| `lua_runtime_benchmark_fixture.lua` | wait_event、update_async、sequence 等实际业务 | 不改 A 原主方法运算/副作用时点 |

完整固定链接见 `SOURCES.md` [S3–S11]。

### 2.2 本轮不重复的历史工作

不重写 page allocator/GC、inline CI、leaf-yield、H1/H3检查收敛、H2入口拆分、table inline cache、userdata uservalue、自共享 prototype、NativeFrameStorage。A1 的结论表明只合并外围 body没有减少 fresh thread工作，还可能增加大量 backing [S2]。本轮要验证**不产生 Lua 挂起状态**，不是再换一次 body 容器。

### 2.3 不能错误地“统一”的对象

- `Lua main thread`：运行同步步骤的 VM 执行环境，不是每任务创建。
- `Lua script instance/self`：任务之间共享的实例业务状态，仍是 Lua 对象。
- `Native task execution`：每条独立跨时间任务的 frame 与当前阶段。
- `Invocation context`：只在一次 start/resume/sync call 的保护范围内有效的借用。
- `Prepared sync step`：冷期确定的函数/类型/实例绑定，不是长寿命 ACTIVE=true 证书。

不得把 Lua 的所有对象称为消失；框架只取消这条路线对**暂停 Lua 调用链**的依赖。

---

## 3. 新作者合同和业务等价边界

### 3.1 本轮批准的变化

迁移后的任务在 C++中表达等待；Lua步骤没有引擎级 await。跨等待必要值成为原生 frame 中的值，或明确有寿命规则的句柄。

不承诺保留旧单体 Lua函数的：coroutine identity、暂停调试栈、任意 Lua局部对象自动跨等待存活、跨等待的 Lua TBC/动态嵌套挂起行为。它们是新作者合同与旧合同的差别，不是“已证明等价”。

### 3.2 必须保持的业务事实

输入/输出、初始 self、每一次业务运算、provider调用及其参数、Event/Timer来源与交付次数、目标实例、clock/deadline、稳定点、命令提交顺序、取消截止点、故障隔离，必须与该场景 oracle匹配。

特别注意：`local scale = self.scale` 在等待前读取的是快照；等待后的 `self.value` 默认是届时的当前值。不能把所有字段提前快照，也不能把原来的快照改成每次恢复时重读。

### 3.3 Lua同步步骤规则

步骤通过非可挂起的受保护调用执行。框架不得为它建立 LuaContinuation/thread/任务root。直接 `coroutine.yield()` 不得越过同步宿主边界；引擎 await入口应在来源登记之前拒绝缺少可挂起上下文的调用。

Lua自行 `pcall` 捕获这个错误后走合法同步恢复，是普通语言行为，可以允许；必须证明没有留下 A/来源或隐式 continuation。不要为阻止“被捕获的错误”发明一套全局sticky故障系统。

本轮不移除标准 coroutine/debug库，不实现静态Lua类型验证。测试fixture自身不得创建用户 coroutine来偷渡任务状态；“框架未创建任务thread”与“任何用户Lua永远不能创建thread”是两项不同承诺。

### 3.4 失败差异必须分类

核心Event/Timer接纳的先后、Ready满策略、C晚接纳等不变。原Lua新thread OOM与候选native frame不足是不同资源阶段：需要分别验证“失败不继续错误业务、回滚完整”，不要求强行命中同一分配序号或伪造相同错误码。

允许错误报告增加stage信息；已有合法副作用不自动事务回滚。若native任务因前置frame容量不足而没有开始，这与Lua backend开始前thread不足同属backend启动失败，但不能借此提前消耗核心C配额或改掉C晚拒绝的副作用。

---

## 4. 具体集成方法：一个逻辑挂载，两个后端子对象

### 4.1 采用的最小组合方式

新增高层模块（建议路径）`engine/domain/simulation/scripting/native_lua_tasks/`，提供 `NativeLuaTaskBackend`。

**它对 ScriptSystem 暴露一个 LUA kind的后端descriptor，取代该次组合中的裸 Lua descriptor；未在组合清单登记的Lua资产/方法继续转发原Lua后端。**不能同时注册两个LUA kind。既有CppStatic/Native后端对其它独立脚本的注册保持原状。

这个facade拥有冷期组合关系、子对象与方法路由，不拥有新的Ready队列，不调用独立tick，不绕过ScriptExecution。

```text
一个 ScriptSystem mount / 一个 ScriptInstanceId / 一个 ScriptBehavior
                      │
          NativeLuaTaskBackend 实例记录
            ├── Lua 子实例：唯一 self / prototype / 同步方法
            ├── CppStatic 子实例：原生任务 contract / context / frame能力
            └── 冷期 prepared step集合和导出路由
                      │
             原 ScriptBackendContinuation
                      │
            原 Execution / Event / Timer / Ready
```

这是**本轮建议的新实现**，不是已经存在的多后端挂载功能。

### 4.2 为什么 facade对外仍是 LUA kind

本轮使用原 Lua资产作为外部方法/Hook/权限声明的参照，并用显式冷期composition plan将选定的可挂起导出交给一个真实 CppStatic任务制品。可保持原挂载和方法symbol，普通Lua路径原样存在，避免顺手修改资产Kind、场景wire和多脚本实体语义。

composition plan是新的作者配置，不是根据函数名猜测的透明编译替换。最终产品的资产组织是否应独立成任务制品，留到实验结论以后；本轮不借“实验facade”隐藏实际资源成本。

### 4.3 冷期组合清单

建议 `NativeLuaTaskPlan` 至少记录：

- 外部 Lua资产ID、期望content identity；
- 原生任务制品ID/期望content identity、真实CppStaticContract；
- 外部导出symbol→原生导出symbol的显式路由；
- 原生任务可调用的同步Lua步骤及完整signature；
- lifecycle路由与容量需求。

准备时验证：方法存在、参数/返回一致、选中任务导出可挂起、Lua步骤不在suspension_capable_exports中、Native制品确为CppStatic且contract匹配、重复路由拒绝、全部依赖与期望来源属于原挂载获准集合。

**不要把Lua资产传给CppStatic createInstance指望其绕过contract检查。**必须从已有asset resolver取得真实、匹配的原生任务制品和lease。Lua子实例仍用原Lua资产/发布域，避免混淆layout token与AssetId来源。

### 4.4 同一身份，正确的子上下文

两子实例共享同一 `ScriptInstanceId`、`ScriptBehavior*`、实体/模拟scope和生命周期资格。各自的asset/content和import序号映射按真实制品冷期建立。

原生任务要求的Ability/Event必须是原挂载权限的子集；给Lua步骤使用的业务provider也必须已经在挂载上合法声明。不得因为CPP contract含多个需求，就把宿主全局所有能力传给它。

可以为子实例建立冷期span映射，容量计入组合backing。不能在每次call/wait重新按名字构造映射。

### 4.5 创建与发布次序

1. 核对两制品、全部导出路由、权限与可计算容量；失败时不发布方法。
2. 取得组合实例槽/资产lease，建立Lua子实例，但不私自执行BeginPlay。
3. 准备该实例的Lua同步步骤集合；所有可能需要的vector容量先reserve，发布后地址不移动。
4. 创建真实CppStatic子实例，传入同一核心owner及这份prepared步骤视图。
5. 成功后才发布组合实例和外部prepared方法；任一失败逆序清理本次已取得资源。

原core仍在它规定的时点执行BeginPlay。默认BeginPlay/EndPlay继续路由原Lua生命周期方法一次；原生伴随contract不额外执行另一轮同名生命周期业务。Native对象的构造/attach不等于第二次BeginPlay。

### 4.6 热路径必须是已选入口

在prepareMethod就选定：

- 普通Lua/生命周期：Lua子实例的checked sync入口；
- 显式映射任务：真实CppStatic子实例的resumable入口。

只需保留releaseMethod所需的冷期路由记录。不要在每次invoke做 `if backendKind + symbol map lookup`。原生任务返回的continuation可直接传给core，组合实例靠core既有“先清任务，再释放method与instance”的生命周期保持子对象存活；**禁止每任务再加一个等待驱动coroutine**。

如必须有一层窄取消/保活包装，提交完整字段与每任务增量理由，并先证明现有owner lifetime不能直接满足。不能把“需要支持所有未来情况”当理由。

### 4.7 释放与失效

核心撤权先发生。等正在执行的Lua步骤/原生resume离开保护区、既有任务已取消或结束以后，依次完成原生子任务与method释放、步骤引用失效、Lua子实例销毁、制品lease归还。

不可跨converter/provider/finalizer调用保留易移动记录裸指针；物理存储pin只维持内存，不赋予已撤销的业务资格。不得在native frame正在执行时调用其destroy。

Lua子实例的`active_continuations==0`不能用来判断整个组合任务已结束：候选所有等待都在native侧，该Lua计数本来就为0。只有外部core任务和在途同步调用真正离开后，才允许销毁Lua子实例/步骤根。

首版不支持等待中替换任务程序/热迁移frame。内容替换按照已有旧实例保活或退休重建规则进行；不能将旧任务的step handle自动重绑定到新内容。每个槽位复用要验证旧handle拒绝。

---

## 5. 同步步骤桥：实际要新增什么

### 5.1 窄核心接口，不让CPP公共头依赖Lua私有布局

在scripting/core定义非Lua专用的prepared同步步骤借用，例如 `PreparedScriptSyncStep`、`ScriptSyncStepSetView`。建议向`ScriptInstanceCreateContext`增加默认空的可选视图；原有消费者默认行为不变，所有C++消费者必须配套重新编译。

CppStatic实例记录保留该稳定视图，创建`ScriptCoroutineContext`时安装一个对它的借用。新`context.callStep<Signature>(ordinal,args...)`只做**同步调用**，不返回awaitable、不产生A/C。

不强制函数名，但必须保证：

- descriptor/codec/固定ordinal在冷期确定；
- 调用关联到当前core实例及相同发布内容；
- 每次进入检查当前资格，跨用户代码按原资格重验；
- 不新增全局map、通用动态TaskContext、per-task `shared_ptr`或永久宽票据；
- 现有不使用步骤的CPP路径不无条件构造步骤表、权限对象或调用Lua。

同一owner/版本不可变事实可以借用，当前ACTIVE不能在准备后永久缓存。`ScriptInvocationValidity`是短借用，不能保存在任务frame跨await使用。

### 5.2 typed调用形状

对外给出小型、`[[nodiscard]]`的 `expected<R, ScriptSyncStepError>`。`R`首版为void或当前已支持的scalar；参数允许当前支持的scalar/enum和已存在的plain record输入。

错误结构优先为stage ordinal + 稳定错误类别 + 原backend状态；错误详情仅在错误路径记录。不要每次成功调用构造字符串、256B完整诊断对象或动态错误容器。

typed wrapper使用函数栈上的确定大小参数/返回slot数组，直接指向本次native值/局部目标，调用返回前完成使用。没有一次等待期间保存这些`span`或stack地址的理由。

**当前Lua export返回支持范围不能凭空扩大。**不要将已有Ability的record双向转换能力误认为所有Lua导出都支持record返回。本轮跨等待record保持原生拥有副本，Lua仅读取record输入并返回scalar/void；不需要新建任意对象图或共享可写view。

### 5.3 同步Lua入口的保护范围

为新的prepared step提供明确的checked入口，可复用/收敛现有同步invoke，但必须审计以下全过程：

```text
保存base与原调用资格
→ 检查/取得当前stack额度
→ 函数/self/参数准备
→ 执行Lua函数
→ 输出转换与检查
→ 清理临时Lua栈
→ 恢复base、原execution context、保活计数
→ 返回显式状态
```

可能Lua longjmp的动作放在适当的受保护C callback内；拥有型C++对象和原生coroutine frame不能被跨越。**只给“Lua函数体”套pcall、不保护参数创建、转换或错误处理，并不足够。**

优先一次受保护的同步调用事务，而不是新入口无条件在旧完整pcall链外再套一轮通用封装。保留自定义codec各自必要的保护；不得为满足“一次保护”而让非平凡C++局部跨Lua错误。实际保护层数和机器码要报告。

当前W0的callback内`lua_checkstack`额度修正保留。不能用装配期检查代替当前callback额度，也不能默认`lua_settop`在任意TBC状态下无用户行为。只清理本入口拥有的临时范围，禁止破坏外层重入Lua帧。

### 5.4 嵌套、重入与错误处理

按当前owner线程串行进入。同步步骤可调用现有同步provider；provider可能触发合法嵌套Lua调用、撤权、延迟stop或分配finalizer。每层保存准确的thread/instance/调用资格和原base，离开时恢复外层，而不是全局`currentTask`覆盖。

输入错误时provider不执行。Lua业务或provider已发生后，输出类型错误只表示此次步骤失败，不能伪造副作用已回滚。将输出先转换到本地typed临时，再在成功时发布给调用者；失败不得把半构造record或默认零当有效结果。

禁止把Lua错误抛成未处理C++ exception。首版不改`unhandled_exception=terminate`的全局政策，以免把另外一项异常架构混进来。

---

## 6. 原生coroutine中的终止失败

### 6.1 不使用并不存在的任务返回类型

现有生产类型是`ScriptCoroutine`，promise有`return_void()`，没有本方案先前示意的`Task<Result<void>>`。实现必须使用真实类型，不得只在文档展示无法编译的`co_return unexpected(...)` [S6]。

### 6.2 采用窄的终止失败awaitable

新增概念性 `context.fail(error)`：

- `await_ready=false`；
- `await_suspend(handle<ScriptCoroutine::promise_type>)`把promise outcome写成FAILED，保存有效错误码；
- 不创建Awaitable、不登记来源、不进入Ready、不产生一个“失败也要恢复”的任务；
- 交还现有start/resume适配器，由其识别FAILED，执行既有销毁/错误报告；
- 终止fail之后的代码不可执行；`await_resume`不是正常可达业务入口。

现有adapter某些失败分支折叠为-1，要有窄修改保留新显式状态，而不是把正常路径和原错误政策全部翻新。已有错误策略变更单独登记；旧消费者测试保持。

典型作者写法如下，**名字为目标API示意，交付必须替换为真实可编译代码**：

```cpp
ScriptCoroutine run(ScriptCoroutineContext& context) noexcept {
    double snapshot;
    {
        auto r = context.callStep<double()>(ReadScale);
        if (!r) {
            co_await context.fail(r.error());
            co_return; // 防误读，正常不会恢复到这里
        }
        snapshot = *r;
    } // 较大的诊断/结果临时不跨等待

    co_await context.delay().nextStep(); // 实际生成API以本仓为准
    const auto payload = co_await context.wait(PreparedBenchmarkEvent);
    co_await context.delay().simulationSeconds(0.001);

    auto applied = context.callStep<void(double, int32_t)>(Apply, snapshot, payload);
    if (!applied) {
        co_await context.fail(applied.error());
        co_return;
    }
}
```

不要通过同一共享全局error变量收敛多个并发任务。错误属于本次任务/步骤；每个frame的有效outcome互不污染。

### 6.3 原生frame要求

只保存实际跨等待的值、紧凑prepared引用和必要上下文；不可保存局部`expected`的重型错误缓冲、整份descriptor、参数vector或含所有可能值类型的巨型union。用真实MSVC结果报告frame字节、header/padding、slot stride、metadata、总容量与峰值。

不静默扩大全局512B等既有限制来让所有测试通过。确需更大业务frame，只能作为本任务明示配置和成本；小任务不得被提升到统一最大尺寸。并发任务即使共享self，也必须有独立native frame，不使用每实例唯一可变payload槽。

---

## 7. 小范围命名纠正

在独立机械子提交里，将新接触的Lua后端私有`State`改为`Impl`、其主Lua指针命名为`main_thread`、同步静态入口命名为`invokePreparedSync`。不改Lua上游`lua_State`名称，不全仓批量改所有State，也不把namespace/文件大搬迁当优化。

新模块中：`Instance`表示组合实例，`TaskExecution`表示一次跨等待执行，`InvocationContext`表示短借用；不要再次使用同一个`state`变量表达以上三者。

该提交主要改善可读性，不记性能收益。若机械改名触及与本轮无关的公开兼容性，缩到私有边界并登记，而不是引入一套兼容别名层。

---

## 8. 必须采用的分阶段实施顺序

每阶段是同一分支中的连续子提交，不需要做完一步等待用户批准。仅在真实合同阻塞、授权/环境障碍或明确的范围边界上停止。不得把所有分析写完、实际代码未做却标为完成。

### N0：固定输入与设计落点

执行分支保护、依赖身份和实际源码检查；读取本文件列出的入口，补出实际owner、preparer、CPP start/resume/destroy和Lua同步error路径映射。建立`BASELINE.json`、`CONTRACT_MAP.md`、`COMPOSITION_LAYOUT.md`。

必须给出一个组合实例/一个native任务的字段表、容量计算、制品lease图和销毁顺序，注明Lua/backend/core三种计数的口径。此时不要创建统一TaskBank，不调整GC。

建立共同fixture扩展：保留原Lua wait_event/update_async/sequence方法不变；增加需要的同步步骤，方法symbol来自真实工具链登记、避免冲突。A/B尽量加载同一份包含原任务函数和新同步步骤的Lua制品，**B不得在失败时退回调用原任务函数**。

### N1：组合模块与同步步骤基础

完成小范围命名子提交。实际实现组合plan、资产解析/lease、子实例、prepared路由、默认空的同步步骤上下文传递、typed scalar bridge。先通过无等待同步调用、错签名、错误参数、非法owner、创建回滚和正常关闭。

新模块依赖core、Lua、CppStatic；不要反过来让core包含Lua私有头、也不要形成Lua↔CPP循环依赖。公共核心view不暴露VM内部类型。

### N2：真实单Event纵向链

用生成/注册的CppStatic coroutine等待真实`Benchmark.event`，恢复后同步Lua执行`self.value = self.value + payload`。使用原EventWaitFactory、原stable point、原resume预算。

先64/1000实例小例，确认payload=31、每实例完整更新、Task/Awaitable/Ready清理。再做一次小型A/B完整任务计时和完整backing，作为早期可解释性检查，不作最终性能资格。

如果仍出现候选任务调用`lua_newthread`、Lua backend continuation或外层C++driver恢复Lua，应在此修正；不能继续迁移全部消费者后才承认并非路线A。

### N3：失败、权限、并发与后续等待

完成终止fail awaitable、同步桥全保护、嵌套context、撤权/延迟stop、取消与延迟物理销毁。增加两个独立任务同self的交错等待；不得采用“一个实例只有一个任务”的默认简化。

接通NextStep、3-wait sequence和32-wait long task，确保同一native执行重新登记等待，A配额在进入恢复用户代码前归还，core C不每个stage新建。

### N4：值、资源与现实业务

接通现有ValuePose输入的跨等待record场景。完成受支持的同步-only Lua子配置：没有框架任务需要Lua continuation时允许0任务thread容量；不预热创建“永远不用”的thread池。旧混合Lua配置保留原能力。

若当前backend拒绝0，需要最小支持修改与测试；不能偷偷设10000又报告“已删除这部分预留”。仍保留未使用reserve时如实报告，不影响“无活跃Lua协程”的事实，但不授予对应内存收益。

把指定Physics Lua异步部分迁移为native任务+Lua步骤，保持CPP/FlowForge其余参与者、业务函数和输入序列。不能为了性能把physics运算从Lua改成native。

### N5：完整观察与成本比较

冻结本轮工作量，执行第9–12节。先取得准确ROI，再做正式无采样运行。每次改代码使结果无效时，最终匹配组重做；不能从不同候选源码拼成三对。

### N6：clean资格、安装和可重放交付

同一最终clean提交完整Developer/Toolchain、VM合同、旧消费者、新消费者、增量和迁址。方法名称与接口的最终变化必须贯穿installed public headers/Config/generated templates。

### N7：统一结论与只推新分支

保留全部有效慢组和无效尝试理由。输出实现/合同/成本三个独立状态；不以“thread为零”自动判定PROMISING。只推新分支，生成原始归档、清单、远端回取验证；不能在工具不支持时伪写已验证。

### 允许的早停与不允许的早停

确定无法在本轮安全边界内组合实例，或新结构不可避免又保留Lua挂起链，应交付`STRUCTURAL_BLOCKED`与最小反例。新增共享身份/队列/存储要求构成另一项架构时也应停止扩范围。

**早期结果只是更慢，不是自动跳过N3–N6的理由。**本轮用户要求完整测试，原则上继续完成规定的窄实验并交付负结论；不进入第二代架构“救成绩”。只有资源/时间/工具真实无法完成时，登记PARTIAL及未运行项。

---

## 9. 公平比较：不是要求两种执行模型内部每个计数相同

### 9.1 两个比较轴

- `MODE_CHANGE`：A为V4 Lua coroutine作者模式；B为native任务+同步Lua步骤。比较共同业务trace、完整成本、服务容量。Lua调用次数/原生frame数可不同，必须解释。
- `UNCHANGED_PATH`：旧同步Lua、原CPP Sequence、原FlowForge Event等完全未迁移脚本，A/B工作量与资产完全相同，用来识别桥接加入后的旁路代价。

不将不同轴混合得出总体“Lua协程快了X%”。最终应说“对已迁移的业务，用native编排模式较旧Lua coroutine模式变化X%”。

### 9.2 A参考如何构造

A使用实际V4生产库。新场景可用共同测试驱动与新Lua制品，但A生产路径仍为原Lua coroutine。新增同步helper对A也可存在于相同prototype中，避免只给B删除旧方法字段或裁剪self所造成的混淆；A原主方法body不额外拆为helper链，不人为增加Lua调用。

如果本轮新增stage绑定必须扩展fixture元数据，保留原始资产hash并在`fixture_map.json`列出共同增量。不能冒称新扩展fixture就是原历史720ns使用的原件。

B额外的CppStatic任务制品和composition plan是模型需要的真实资源，单列source/hash/解析和准备成本。原Lua任务函数可以留在共同fixture中但B不执行；不得使用运行中隐藏模式开关进行自动回退。

### 9.3 共同业务oracle

诊断trace至少包括：逻辑task开始/结束、stage前后、Event occurrence序号、等待来源/目标、模拟step/deadline、可观察副作用与provider输入输出、取消/失败结果。按逻辑task映射比较，不要求A/B内部CId或native地址逐字节相同。

每个场景同时给出每实例最终读回，不只给可碰撞的总和。对交错trace用有界明确序列/rolling digest并保留小例完整trace；正式计时区不逐操作打印。

定义副作用发生时点：例如NextStep前的+1不得挪到恢复后的+10同一个Lua函数中。等待中的snapshot和late-read要分别断言。

### 9.4 同等服务容量，不同表示容量

双方能支持相同N个逻辑实例、相同上限的独立任务/等待/Ready/source/transport。B为native frame准备容量，A为Lua执行准备容量，不要求所有已不用的内部池仍配置相同条数。

主B使用实际推荐的同步-only子配置，Lua coroutine容量为0或已证明的最小值；对此造成的cold/retained差异如实计入路线的资源交换。A/B仍保持相同VM算法与16MiB空页政策，不以提高cache budget换性能。

独立增加一次`B_KEEP_LUA_RESERVE`资源诊断，保留V4的Lua continuation/root预留但不使用它，区分“避免创建对象”与“删除闲置容量”的贡献。它不是第三套产品模式，不参加主性能表，也不允许为了更好数字挑选B配置。

---

## 10. 正式工作负载：固定9条对照，共54次有效主运行

每条A/B三对，顺序AB/BA/AB；定义6个独立进程。9条共54个有效正式进程。诊断/profile/资格/失败注入和无效重跑另外计数，绝不写进54个之内。

### P1：单Event任务（主目标）

A原`wait_event()`；B原生任务先等待，再同步Lua执行同样的value更新。每任务一个等待、一个最终更新。B不能使用常驻callback取代每任务等待登记。

N=10000，1000预热批、2000计时批，每批每实例一个完整任务，ROI=20,000,000完成任务。payload=31，含预热每实例最终值=93001；新driver保持实际派发语义。若oracle的初始化或额外调用与源不同，先修driver不修改公式凑结果。

### P2：NextStep任务（双同步边界成本）

A原update_async：等待前+1，NextStep后+10。B对应两个Lua同步步骤，中间native await。N/预热/计时同P1，ROI20M任务。逐step验证不能提前恢复，也不能把+1和+10合并到一边。

### P3：三等待任务

保持原sequence：开始Lua加1→NextStep→Event→simulationSeconds(0.001)→末尾Lua调用原BenchmarkValue.write(self.value+payload)。B只跨等待保存payload和native控制状态。

默认N=10000，75个完整任务波预热，250波测量；ROI2.5M完整任务/7.5M等待后恢复。一个波允许多个真实simulation step，必须按事先固定的时序驱动；不能为了归零添加不计时drain。输出真实step数、task数、source数和完整区间时间；不能把它直接与历史每帧Sequence数字相减。

### P4：同量32等待长期任务

两侧都一次启动、连续32次Event等待、每次Lua执行同样的业务更新，然后结束。A本身也复用同一Lua thread，禁止A新建32次而B只建一次。

N=10000，16个完整任务波预热，64波测量。ROI640,000任务/20,480,000等待与业务更新。主单位ns/完整32-wait任务，附加ns/实际完成等待，明确两者不是相同指标。该场景专门检查：当A创建成本已经被摊薄时，B是否被更多同步Lua边界反噬。

### P5：ValuePose跨阶段任务

使用仓库已经支持的真实ValuePose字段/schema/codec，不换成两个double的假record。输入在任务开始形成快照；A接收Lua table并跨一个Event保留，B持有typed native副本，分别在等待前和后作为Lua同步步骤输入。两侧计算相同字段结果并相同late-read，不比较对象地址/表身份。

Lua步骤只返回既有scalar/void，不新增record export返回。N=1000，100个完整波预热，1000波测量，ROI1M任务。额外转换和新table是B真实代价，必须计入，不通过传共享可写userdata另换表示来拯救本轮。

八个ValuePose输入/更大native frame可以作为容量和复制诊断，不是自动扩大的第二套正式参数网格。

### S1–S3：未改路径哨兵

- S1：原Lua scalar Ability，按V4实际命令10000实例、1000warm、2000measured。
- S2：原C++ Sequence，按其V4原driver参数和业务计数，不替换为本轮P3。
- S3：原FlowForge Event，10000实例、300warm、1000measured、原生成制品/业务。

S2具体命令以原记录和真实CLI核对，先固定后运行；不能引用历史值代替本轮执行。观察新context字段/共享头修改是否给完全不使用Lua步骤的路径增加成本。

### P6：混合Physics迁移

原10000混合实例、300warm、2000measured，按V4固定worker/输入。只把目标Lua异步业务替换为native编排+对应Lua同步步骤，其余CppStatic和FlowForge业务不变；不得新增第二份实体或多一套simulation。

保留query/provider调用数、state checksum、等待顺序、每帧实际操作和错误/关闭oracle。实际作者资产有差异，单列A/B资产映射；不伪称同字节资产。不具备可匹配迁移路径时此腿标`NOT_COMPARABLE`，不以纯nativePhysics冒充；整体完整性相应登记。

### 10.1 不在热段暗藏工作

不停止GC，不把结果复制/取消/销毁/归还放到ROI外；创建与销毁任务属于完整周期。预热仍执行同量真实逻辑，不对某侧强制全GC。冷期与关闭时间另报，不因主ROI更快而隐去更贵的准备/收尾。

只在原任务完成边界结束ROI。需要drain的场景必须双方相同且计入完整测量；禁止给B免费排空。持久任务场景记录ROI开始/结束的in-flight状态，防止把上一窗口工作转移。

### 10.2 数值处理

保存每批total_ns、actual_completed_tasks、actual_waits、Lua调用数和业务摘要。主归一化分母是真实完成业务，不是配置size的乘积猜测。

每对变化`100*(T_B/T_A - 1)`，再取三对中位；同时显示全部三对、各侧中位、完整ROI秒数。不同场景不把ns直接相加平均。没有独立单task延迟采样时，p95/p99只能叫批次/帧分位。

测试错误使运行无效；正常有效但慢不允许丢弃。环境干扰只有客观日志支持才可标无效，所有原件保留。不给不同阶段数据重新贴最终source标签。

---

## 11. 结构计数与内存总账

### 11.1 独立observer必须证明

对于新模式主任务，计时段框架导致的：

| 量 | 结构要求 |
|---|---|
| 新Lua coroutine thread | 0 |
| Lua backend continuation获取/恢复 | 0 |
| 为任务新增/解除thread root | 0 |
| 引擎Lua yield/resume作为任务驱动 | 0 |
| per-task Lua closure/context table专用保存跨等待状态 | 0 |
| core任务建立/完成、等待/恢复 | 与业务时序相符，不能全部称0 |
| native frame acquire/release | 与实际任务次数对应；长期任务一个frame多次await |
| Lua同步步骤调用 | 与各P场景应有的计算次数一致 |

以上0必须来自实际代码路径/启用的计数/调用栈证据，未采集用null。对包含用户自建coroutine的负例另列，不混入纯fixture的框架计数。

### 11.2 必须核算的资源

native object/continuation/frame/参数copy/header/padding；composition instance与路由、prepared step存储、句柄代次/寿命管理；Lua self/prototype/environment/function roots和主栈；剩余Lua保留池；core C/A/Ready/来源/transport；资产和模块lease。

共享backing只算一次。引用到其它owner的指针不意味又拥有一整份backing；反之，新增companion子实例占用的存储不能因“逻辑实例还是一个”而漏掉。

对1000与10000实例至少取得：准备完/预热完/挂起高水位/正常完成/实例退休后/VM最终关闭各快照。记录requested/live/reserved/idle/峰值的不同口径；进程working set/commit独立列，不能与子系统峰值相加。

frame峰值和实际sizeof来自最终工具链产物，不只用C++源码推测。无VM新增逻辑分配不等于整个DLL/进程零分配；EXE-local new计数必须标范围。

### 11.3 有限稳定性/churn

64实例反复完整创建/运行/取消/退休32轮；再做1000实例的高水位→低活动→重新高水位。相同内容重建不应无限增加prepared根、原生contract映射或资产lease。必须测试同self两个并发task互不覆盖跨等待值。

明确区分“任务结束但Lua实例仍保活”和“VM关闭后的全部内存释放”。最终GC平衡不能靠allocator bulk-free掩盖仍活着的VM对象。

---

## 12. VTune与诊断要求

这轮不再只用完整进程profile替代热段分析。给本轮**共同测试驱动**增加粗粒度ROI：准备/预热完成后resume采集，完成规定业务后pause采集，Lua GC照常运行。ITT库/宏与实际VTune版本记录在manifest [S12]。

只在完整批次或阶段切换标记，不给每个微小Lua API或if逐次打点。正式timing关闭诊断计数/ITT任务标记，observer与profile使用同一源码的单独匹配构建并明确hash。

至少对P1和P3分别采集A/B各一份有效Hotspots；P5若转换成为主要成本再补同口径A/B。必须导出process/线程/模块/self/inclusive/call tree、目标exit与business oracle。采样器成功退出不代表target成功。

反汇编至少查看native任务start/resume、同步Lua桥、错误入口与关键转换，报告实际pcall层数、nativeframe大小、调用边界、成功路径初始化。不能凭源码说某次copy消失或frame必然内联。

软件采样可用即可推进；PMU不可用不阻塞全部交付，不改系统安全策略取得权限。没有硬件证据就不写cache miss/branch mispredict的确定百分比。必要时针对墙钟异常另用WPR/WPA，诊断成本不进入正式表。

如果ITT确实无法使用，允许明确记录的attach/时间区间控制与业务起止标记替代；必须能够证明分析区间。不接受再次只提供setup/warmup/shutdown混合排名并声称稳定期瓶颈已确定。

---

## 13. 正确性矩阵与验收规则

详见`TEST_MATRIX.csv`的54条要求，它们是**要求条目，不是54个独立EXE、也不是已通过测试**。可以将相关用例合并到实际CTest目标，但要逐条映射源码/命令/断言/输出。

必须实际覆盖的重点：

- 重复kind/路由、错误资产/签名、原生依赖越权、Lua异步函数误作sync import。
- 一个core实例、两个child、Begin/End恰好一次、构造失败逆序回滚。
- void/scalar/record输入、NaN/Inf/范围、错误输出不提交、provider副作用不假回滚。
- raw yield和引擎wait在同步上下文拒绝且不留source；Lua内部pcall恢复不制造待恢复Lua栈。
- 函数体/参数构造/codec/traceback/stack增长OOM、TBC清理、自定义转换重入。
- 挂起中退休、执行中撤权、deferred stop保留当前region资格、回收与迟到完成。
- 两任务同self、跨实例/旧epoch拒绝、shared main stack合法嵌套、owner线程边界。
- Event claim/callback/copy顺序、Timer重试、stale pop预算、A释放时点与C晚接纳。
- 原生fail不创建新的wait，不执行fail之后代码，返回失败不是abort，frame一次销毁。
- content替换不把旧task绑定到新function；子制品lease与Lua roots平衡。
- 真实安装新消费者、真实Lua packager+CppStatic生成；无private header泄露。

未覆盖项必须具体写出；不能凭某EXE通过把其中未运行分支全打勾。优化构建中的测试断言必须实际有效。

---

## 14. 构建、安装、增量与交付

### 14.1 最终clean资格

从最终候选提交创建独立clean资格clone。Developer/Toolchain全量build、二次no-op、全CTest；当前VM原4项合同保持，不修改上游VM补丁。历史126/110等数量只是参考，不强求新版本总数相等，报告实际新增/删除并解释。

运行现有15个SDK消费者和13类增量检查、原两条迁址链；新模块另增加一个真实`native-task-lua-steps`消费者并执行迁址。不要把新增消费者算进旧15却漏掉其中一个。范围可共享测试基础，但清单每项有证据。

新消费者必须仅用安装后的public Config/headers/libs/tools/VM完成：真实CppStatic task生成/编译、Lua资产打包、composition plan组装、Event和NextStep、同步结果、失败/取消和关闭。不能引用source `pinclude/sinclude`、原build/generated或工作区绝对路径。

若修改公共C++ context/头，全部consumer重编译；Native C ABI6不变也不意味着旧C++ EXE可与新DLL混用。

### 14.2 新增增量检查（不扩成新网格）

至少验证：Lua步骤函数签名变化→正确重包/准备拒绝；task contract/import变化→正确重生成；composition映射变化→正确失效；恢复后no-op；删掉某步骤→冷期明确失败。复用既有增量框架。

### 14.3 交付目录

建议仓库`.internal/script-native-lua-na1/`：

- `RESULT.zh-CN.md`：分离实施、合同、成本、限制和采用建议。
- `NOTES.zh-CN.md`：实际source/owner/接口/lifecycle，偏离本规格的理由。
- `result.json`：机读状态，完整manifest与所有运行。
- `CHECK_MAPPING.csv`：54条要求的实际证据映射，不把未做填PASS。
- `BASELINE.json`、`fixture_map.json`、`WORKLOAD_LOCK.json`、`RESOURCE_LEDGER.json`。
- `profiles/`导出与原始数据库路径/hash；`costs/`完整CSV与进程日志。
- `failed_attempts/`，保留真实失败、无效运行和修正。
- 新原始archive索引/清单/hash，固定远端提交回取校验。

EXE/DLL/PDB保留本地受控镜像并以hash关联；遵守仓库原有二进制证据存放政策，不上传秘密/凭证。大VTune数据库可留本地，不能没有数据库又称完整原件已交付。

### 14.4 最终必须逐项回答

1. 新路线是否真的没有框架Lua任务thread/root/yield/resume？
2. native实际frame、companion、step桥和Lua余留backing合计是多少？
3. P1少生命周期成本时是否赢；P4 A已经复用Luathread时是否仍赢？
4. P5的重复封送是否抵消收益？
5. Physics是否有真实整帧收益，未改路径是否付出回退？
6. 旧Lua哪些能力因作者模式变化而不再保证，而非被“证明兼容”？
7. 权限/错误/取消是否仍由原owner协议处理；是否新增任何隐藏scheduler/任务对象？
8. 哪些结果未知，哪些平台没跑，哪些单因素没有分解？

---

## 15. 禁止的快捷实现

| 错误做法 | 为什么本轮不接受 |
|---|---|
| C++ coroutine里循环lua_resume旧thread | 两份执行状态，根本不是路线A |
| 每个Lua步骤新建thread/VM | 将需要删除的成本换名保留 |
| 每任务Lua closure/context table保存阶段 | 持久任务状态仍由Lua对象图承载 |
| 每实例唯一payload/snapshot槽 | 两个并发任务覆盖，错误串行化 |
| 额外挂载一个独立脚本实例或ScriptSystem | 改权限/生命周期/调度，逃避组合问题 |
| fail返回0/默认值，继续native业务 | 隐藏错误而不是错误处理 |
| 输入native指针包装成无寿命规则的userdata | 延迟访问后UAF风险，不是零拷贝 |
| 给同一字段每阶段重复name/schema查找 | 没有利用prepared事实，增加中间解释 |
| 把Lua计算搬到C++后报Lua更快 | 工作分工超出实验，无法解释 |
| A每事件新任务、B长任务，仍称同执行寿命 | 混淆两类收益；P4已要求双方同寿命 |
| 只测native frame，不算Lua同步bridge | 不完整业务比较 |
| 停GC/增cache/改单侧编译参数救结果 | 混入其它变量 |
| 私有State改名后宣称架构已优化 | 命名不是性能证据 |
| 用手写Native DLL替代真实FlowForge回归 | 未测试实际生成路径 |

---

## 16. 交给实施方的最终原则

你被授权连续实施并测试**本文件定义的实验**，不是被授权将结果改成正面。先建立能实际运行的最窄纵向链，再闭合规定的错误、生命周期、业务和资源观察，最后完成一次统一资格。

保持V4/A1/H1/main和用户未知修改不动。没有明确性能收益时完成负结果，不继续推进另一套架构、不删除旧Lua协程产品入口，也不宣布将Lua全面降为同步语言。

本轮成功的最低含义是：**我们知道在既定引擎合同和这些业务形状下，将异步控制放到原生任务后，实际删掉了什么、增加了什么，是否值得采用。**
