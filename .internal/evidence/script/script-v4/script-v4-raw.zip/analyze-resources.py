from pathlib import Path
import json,collections
r=Path(__file__).parent
def records(path):
 result=[]
 for line in path.read_text().splitlines():
  if not line.startswith(('VM_','PAGE_PHASE,','PAGE_PHASE_END,','RECORD_MEMORY','NATIVE_STORAGE')):continue
  row={'kind':line.split(',')[0]}
  for value in line.split(',')[1:]:
   if '=' not in value:continue
   k,v=value.split('=',1)
   try:v=int(v)
   except ValueError:v=None if v=='null' else v
   row[k]=v
  result.append(row)
 return result
def analyze(path):
 rows=records(path);result={'path':str(path)}
 for kind in ['VM_FINAL','VM_PAGES','VM_CONFIG','VM_GC','VM_LAYOUT','RECORD_MEMORY','PAGE_PHASE_END']:
  result[kind]=next((x for x in rows if x['kind']==kind),None)
 roi={x['phase']:x for x in rows if x['kind']=='VM_ROI'}
 result['snapshots']=roi
 if 'warm' in roi and 'end' in roi:
  counters=['alloc','realloc','free','heap_alloc','heap_free','page_alloc','page_free','direct_alloc','direct_free']
  result['roi']={k:roi['end'][k]-roi['warm'][k] for k in counters}
 classes={}
 for x in rows:
  if x['kind']=='VM_CLASS':classes.setdefault(x['payload'],{})[x['phase']]=x
 result['classes']=[]
 for payload,pair in classes.items():
  if 'warm' not in pair or 'end' not in pair:continue
  counters=['requests','frees','bytes','supply','same','cross','idle_limit','trim','shutdown','fallback','header_writes']
  result['classes'].append(dict(payload=payload,warm=pair['warm'],end=pair['end'],roi={k:pair['end'][k]-pair['warm'][k] for k in counters}))
 phases=[x for x in rows if x['kind']=='PAGE_PHASE' and x['cycle']>=1000]
 if phases:
  result['observed_peaks']={k:max(x[k] for x in phases) for k in ['active','idle','live','pinned','rounding']}
  result['observed_peaks']['active_plus_idle']=max(x['active']+x['idle'] for x in phases)
  events=collections.defaultdict(lambda:dict(supply=0,release=0,supply_intervals=0,release_intervals=0,live_drops=0))
  previous=phases[0];max_release=None;max_supply=None
  for row in phases[1:]:
   supply=row['supply']-previous['supply'];release=row['release']-previous['release']
   group=events[row['phase']];group['supply']+=supply;group['release']+=release
   group['supply_intervals']+=supply>0;group['release_intervals']+=release>0
   group['live_drops']+=row['live']<previous['live']
   if max_release is None or release>max_release['delta']:max_release=dict(delta=release,before=previous,after=row)
   if max_supply is None or supply>max_supply['delta']:max_supply=dict(delta=supply,before=previous,after=row)
   previous=row
  result['phase_changes']=dict(events);result['max_release_window']=max_release;result['max_supply_window']=max_supply
 return result
paths={'v3_current_w1_observer':r/'w1-diagnostic/w1.log',
 'g0_w2':r/'w3-experiment/g0-event-diagnostic.log','g1_w2':r/'w3-experiment/g1-event-diagnostic.log',
 'g2_w2':r/'w3-experiment/g2-event-diagnostic.log','budget32_w2':r/'w3-budget32/g0-event-diagnostic.log',
 'v3_original_image':r/'memory-diagnostic/baseline.log','v4_final':r/'memory-diagnostic/candidate.log'}
data={name:analyze(path) for name,path in paths.items() if path.exists()}
(r/'resources-analysis.json').write_text(json.dumps(data,indent=2))
for name,entry in data.items():print(name,entry.get('roi'),entry.get('phase_changes'))
