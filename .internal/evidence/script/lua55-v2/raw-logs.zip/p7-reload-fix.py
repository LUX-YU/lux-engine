from pathlib import Path
p=Path('engine/domain/simulation/scripting/lua/src/LuaScriptBackend.cpp');s=p.read_text()
def rep(a,b):
 global s
 assert s.count(a)==1,(a[:80],s.count(a));s=s.replace(a,b)
rep('''            lux::script::ScriptArtifactContentId content;
            int table_ref''','''            lux::script::ScriptArtifactContentId content;
            lux::asset::AssetId asset;
            std::size_t instance_refs{};
            bool superseded{};
            std::vector<std::size_t> function_slots;
            int table_ref''')
rep('            prototypes.reserve(config.instance_capacity);','''            prototypes.reserve(config.instance_capacity);
            latest_prototypes.reserve(config.instance_capacity);''')
rep('            function_bindings.reserve(prepared_call_capacity);','''            function_bindings.resize(prepared_call_capacity);
            free_function_bindings.reserve(prepared_call_capacity);
            for (std::size_t index = prepared_call_capacity; index > 0U; --index)
                free_function_bindings.push_back(index - 1U);''')
rep('''        [[nodiscard]] Prototype* prototypeFor(''','''        void collectPrototype(Prototype& prototype) noexcept
        {
            if (!prototype.superseded || prototype.instance_refs != 0U) return;
            for (const auto index : prototype.function_slots)
            {
                auto& binding = function_bindings[index];
                function_index.erase(FunctionKey{&prototype, binding.signature.symbol_id});
                luaL_unref(state, LUA_REGISTRYINDEX, binding.function_ref);
                binding = {};
                free_function_bindings.push_back(index);
            }
            releasePrototype(prototype);
            prototypes.erase(PrototypeKey{prototype.asset, prototype.content});
        }

        [[nodiscard]] Prototype* prototypeFor(''')
rep('''            Prototype prototype;
            prototype.content = content;
            if (!prepareArtifactLayout(prototype, artifact)) return nullptr;''','''            auto latest = latest_prototypes.find(context.asset);
            if (latest == latest_prototypes.end() && latest_prototypes.size() >= instance_capacity) return nullptr;
            Prototype prototype;
            prototype.content = content;
            prototype.asset = context.asset;
            try
            {
                prototype.function_slots.reserve(artifact.description().exports.size());
            }
            catch (const std::bad_alloc&)
            {
                return nullptr;
            }
            if (!prepareArtifactLayout(prototype, artifact)) return nullptr;''')
rep('''                const auto inserted = prototypes.emplace(key, std::move(prototype));
                if (inserted.second) return std::addressof(inserted.first->second);''','''                const auto inserted = prototypes.emplace(key, std::move(prototype));
                if (inserted.second)
                {
                    auto* current = std::addressof(inserted.first->second);
                    if (latest == latest_prototypes.end())
                    {
                        try
                        {
                            latest_prototypes.emplace(context.asset, current);
                        }
                        catch (const std::bad_alloc&)
                        {
                            releasePrototype(*current);
                            prototypes.erase(inserted.first);
                            return nullptr;
                        }
                    }
                    else
                    {
                        auto* previous = latest->second;
                        latest->second = current;
                        previous->superseded = true;
                        collectPrototype(*previous);
                    }
                    return current;
                }''')
rep('''            result.value = instance;
            return EScriptBackendResult::SUCCESS;''','''            ++prototype->instance_refs;
            result.value = instance;
            return EScriptBackendResult::SUCCESS;''')
rep('''                if (self.function_bindings.size() >= self.prepared_calls.size())''','''                if (self.free_function_bindings.empty())''')
a='''                try
                {
                    const auto binding_index = self.function_bindings.size();'''
start=s.index(a);end=s.index('\n            }\n\n            const auto call_slot',start)
s=s[:start]+'''                try
                {
                    LuaFunctionBinding binding{function, function_ref, std::move(argument_operations)};
                    const auto binding_index = self.free_function_bindings.back();
                    instance->prototype->function_slots.push_back(binding_index);
                    try
                    {
                        if (!self.function_index.emplace(key, binding_index).second)
                        {
                            instance->prototype->function_slots.pop_back();
                            luaL_unref(self.state, LUA_REGISTRYINDEX, function_ref);
                            return EScriptBackendResult::EXECUTABLE_CONTRACT_MISMATCH;
                        }
                    }
                    catch (const std::bad_alloc&)
                    {
                        instance->prototype->function_slots.pop_back();
                        throw;
                    }
                    static_assert(std::is_nothrow_move_assignable_v<LuaFunctionBinding>);
                    self.function_bindings[binding_index] = std::move(binding);
                    self.free_function_bindings.pop_back();
                    function_binding = std::addressof(self.function_bindings[binding_index]);
                }
                catch (const std::bad_alloc&)
                {
                    luaL_unref(self.state, LUA_REGISTRYINDEX, function_ref);
                    return EScriptBackendResult::ALLOCATION_FAILURE;
                }'''+s[end:]
# No semantic throws, including rethrow: handle the allocation failure locally.
s=s.replace('''                        instance->prototype->function_slots.pop_back();
                        throw;''','''                        instance->prototype->function_slots.pop_back();
                        luaL_unref(self.state, LUA_REGISTRYINDEX, function_ref);
                        return EScriptBackendResult::ALLOCATION_FAILURE;''')
rep('''            self.prepared_events.release(instance->prepared_events);
            *instance = {};
            self.free_instances.push_back(instance_slot);''','''            self.prepared_events.release(instance->prepared_events);
            auto* prototype = instance->prototype;
            *instance = {};
            self.free_instances.push_back(instance_slot);
            --prototype->instance_refs;
            self.collectPrototype(*prototype);''')
rep('''        PrototypeMap prototypes;''','''        PrototypeMap prototypes;
        std::unordered_map<lux::asset::AssetId, Prototype*> latest_prototypes;''')
rep('''        std::vector<LuaFunctionBinding> function_bindings;''','''        std::vector<LuaFunctionBinding> function_bindings;
        std::vector<std::size_t> free_function_bindings;''')
p.write_text(s)
