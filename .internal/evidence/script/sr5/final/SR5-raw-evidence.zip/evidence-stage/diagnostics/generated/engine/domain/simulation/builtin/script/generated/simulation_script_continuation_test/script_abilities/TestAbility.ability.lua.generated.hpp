#pragma once
// Generated typed Lua projection. Include the matching .ability.generated.hpp first.
#include <lux/engine/simulation/scripting/lua/LuaScriptAbilityProjection.hpp>

#include <array>
#include <type_traits>
#include <utility>

namespace lux::script::lua
{

    template <>
    struct ScriptAbilityLuaTraits<::lux::simulation::test::TestAbility> final
    {
        using AbilityTraits = ScriptAbilityTraits<::lux::simulation::test::TestAbility>;
        using Policy = typename ScriptAbilityLuaPolicy<::lux::simulation::test::TestAbility>::Type;

        using Values_readValue = LuaAbilityValueSignature<Policy, int, int>;
        [[nodiscard]] static int readValue(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, int, int>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, int input) noexcept -> int
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.readValue(access.context, input);
                }
            );
        }

        using Values_setValue = LuaAbilityValueSignature<Policy, void, int>;
        [[nodiscard]] static int setValue(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, void, int>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, int value) noexcept -> void
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    dispatch.setValue(access.context, value);
                }
            );
        }

        using Values_identity = LuaAbilityValueSignature<Policy, unsigned long long, unsigned long long>;
        [[nodiscard]] static int identity(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, unsigned long long, unsigned long long>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, unsigned long long value) noexcept -> unsigned long long
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.identity(access.context, value);
                }
            );
        }

        using Values_borrowedValue = LuaAbilityValueSignature<Policy, const int &>;
        [[nodiscard]] static int borrowedValue(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, const int &>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access) noexcept -> const int &
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.borrowedValue(access.context);
                }
            );
        }

        using Values_beginOperation = LuaAbilityValueSignature<Policy, unsigned long long, unsigned long long>;
        [[nodiscard]] static int beginOperation(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::startLuaValueAbility<Policy, unsigned long long, unsigned long long>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, unsigned long long request, ScriptAbilityCompletion<unsigned long long> completion) noexcept
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.beginOperation(access.context, request, std::move(completion));
                }
            );
        }

        inline static constexpr std::array<ScriptAbilityLuaMethodProjection, AbilityTraits::Methods.size()> Methods{
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.value.read"},
                &readValue, Values_readValue::Parameters, Values_readValue::Results
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.value.set"},
                &setValue, Values_setValue::Parameters, Values_setValue::Results
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.value.identity"},
                &identity, Values_identity::Parameters, Values_identity::Results
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.value.borrowed"},
                &borrowedValue, Values_borrowedValue::Parameters, Values_borrowedValue::Results
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.value.begin_operation"},
                &beginOperation, Values_beginOperation::Parameters, Values_beginOperation::Results
            }
        };
    };

    template <>
    struct ScriptAbilityLuaTraits<::lux::simulation::test::TestStatelessAbility> final
    {
        using AbilityTraits = ScriptAbilityTraits<::lux::simulation::test::TestStatelessAbility>;
        using Policy = typename ScriptAbilityLuaPolicy<::lux::simulation::test::TestStatelessAbility>::Type;

        using Values_increment = LuaAbilityValueSignature<Policy, int, int>;
        [[nodiscard]] static int increment(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, int, int>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, int value) noexcept -> int
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.increment(access.context, value);
                }
            );
        }

        inline static constexpr std::array<ScriptAbilityLuaMethodProjection, AbilityTraits::Methods.size()> Methods{
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.stateless.increment"},
                &increment, Values_increment::Parameters, Values_increment::Results
            }
        };
    };
} // namespace lux::script::lua
