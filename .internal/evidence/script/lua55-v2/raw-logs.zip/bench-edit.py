from pathlib import Path
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source')
files=[r/'engine/domain/simulation/builtin/script/benchmark/script_runtime_benchmark.cpp',
       r/'engine/domain/simulation/builtin/physics2d/benchmark/physics2d_script_benchmark.cpp']
for p in files:
    s=p.read_text()
    physics='physics2d' in p.name
    marker='        std::filesystem::path lua_artifact;'
    assert s.count(marker)==1
    s=s.replace(marker,marker+'\n        bool lua_incremental_gc{};')
    if physics:
        s=s.replace(marker,marker+'\n        bool vm_accounting{};')
    parse='''            else if (key == "--lua-gc")
            {
                if (value != "gen" && value != "inc") return std::nullopt;
                result.lua_incremental_gc = value == "inc";
            }
'''
    if physics:
        parse+='''            else if (key == "--vm-accounting")
            {
                if (value != "on" && value != "off") return std::nullopt;
                result.vm_accounting = value == "on";
            }
'''
    s=s.replace('            else if (key == "--lua-artifact")',parse+'            else if (key == "--lua-artifact")')
    if physics:
        s=s.replace('                .events = event_sources,','''                .events = event_sources,
                .track_vm_allocations = options.vm_accounting,
                .vm = {.gc_mode = options.lua_incremental_gc ? lux::script::lua::ELuaGcMode::INCREMENTAL :
                    lux::script::lua::ELuaGcMode::GENERATIONAL},''')
    else:
        s=s.replace('            bool vm_accounting = false\n','            bool vm_accounting = false,\n            bool lua_incremental_gc = false\n')
        s=s.replace('                .track_vm_allocations = vm_accounting,','''                .track_vm_allocations = vm_accounting,
                .vm = {.gc_mode = lua_incremental_gc ? lux::script::lua::ELuaGcMode::INCREMENTAL :
                    lux::script::lua::ELuaGcMode::GENERATIONAL},''')
        s=s.replace('            options.vm_accounting\n','            options.vm_accounting, options.lua_incremental_gc\n')
        s=s.replace('options->resume_budget, options->vm_accounting}',
                    'options->resume_budget, options->vm_accounting, options->lua_incremental_gc}')
        s=s.replace('options->resume_budget, options->vm_accounting);',
                    'options->resume_budget, options->vm_accounting, options->lua_incremental_gc);')
    start=s.index('        ~MixedHarness()' if physics else '        ~LuaRuntimeHarness()')
    end=s.index('        }',start)
    expression='lua->stats()' if physics else 'backend->stats()'
    extra='''            const auto stats = EXPRESSION;
            const auto& memory = stats.vm_allocations;
            std::printf("VM_FINAL,accounting=%d,alloc=%llu,realloc=%llu,free=%llu,failures=%llu,"
                "heap_alloc=%llu,heap_free=%llu,hits=%llu,in_place=%llu,live=%zu,peak_live=%zu,"
                "retained=%zu,peak_retained=%zu,threads=%zu,resumes=%zu,released=%zu,"
                "leaf_available=%d,leaf=%llu,standard=%llu\\n",
                memory.enabled, memory.allocations, memory.reallocations, memory.frees, memory.failures,
                memory.system_allocations, memory.system_frees, memory.cache_hits, memory.in_place,
                memory.live_bytes, memory.peak_live_bytes, memory.retained_bytes, memory.peak_retained_bytes,
                stats.vm_coroutine_creations, stats.vm_coroutine_resumes, stats.vm_coroutine_releases,
                stats.leaf_yield_available, stats.leaf_return_yields, stats.standard_leaf_yields);
'''.replace('EXPRESSION',expression)
    s=s[:end]+extra+s[end:]
    p.write_text(s)
