from pathlib import Path
import hashlib,json,subprocess,zipfile
r=Path(__file__).parent;s=r/'source';e=s/'.internal/script-native-lua-na1/evidence'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
source=git(r/'next-source','rev-parse','HEAD');assert source=='7f20191692d3f5e1037a14273a61fc99eef95714'
assert git(r/'next-source','status','--porcelain')==''
initial=json.loads((r/'next-baseline.json').read_text());protected=[]
for x in initial['protected']:
 repo=Path(x['repo']);status=git(repo,'status','--porcelain');head=git(repo,'rev-parse','HEAD')
 assert head==x['head'] and status==x['status'],('Protected status changed',repo)
 for f in x['files']:assert sha(repo/f['path'])==f['sha256'],(repo,f['path'])
 protected.append(x)
for x in initial['dependency_files']:assert sha(Path(x['path']))==x['sha256'],x['path']
for x in initial['images']:assert sha(Path(x['path']))==x['sha256'],x['path']
headers=[]
relative='include/lux/engine/simulation/scripting/ScriptEndpointBridge.hpp'
origin=r/'next-source/engine/domain/simulation/scripting/core'/relative
for prefix in ['next-tools','next-sdk']:
 path=Path('E:/SyncForder/CodeRepos/install/o/na1')/prefix/relative
 assert sha(origin)==sha(path)
 headers.append(dict(path=str(path),sha256=sha(path),source=str(origin)))
(r/'next-protected-final.json').write_text(json.dumps(dict(protected=protected,
 dependency_files_verified=len(initial['dependency_files']),baseline_images_verified=len(initial['images']),
 qualification_source=source,installed_public_headers=headers),indent=2))
identities=[]
for folder in ['C','C-common','C-flow','D','D-common','D-flow','D-preproof','D-common-preproof','D-flow-preproof']:
 root=r/'images'/folder;info=json.loads((root/'identity.json').read_text())
 for name,entry in info['images'].items():assert sha(root/name)==entry['sha256'],(folder,name)
 for p in sorted(root.iterdir()):
  if p.is_file():identities.append(dict(path=str(p),relative=p.relative_to(r).as_posix(),bytes=p.stat().st_size,sha256=sha(p)))
(r/'next-final-image-identities.json').write_text(json.dumps(identities,indent=2))
(r/'next-source-identity.json').write_text(json.dumps(dict(qualification_source=source,clean=True,
 branch=git(s,'branch','--show-current'),production_baseline=initial['comparison_source'],
 code_commits=git(s,'log','--format=%H %s','7d5cd844..'+source).splitlines(),
 changed=git(s,'diff','--name-only','7d5cd844',source).splitlines()),indent=2))
files=set()
allowed={'.json','.jsonl','.log','.txt','.csv','.py','.ps1','.asm','.hpp','.cpp','.cmake','.lua','.template'}
for p in r.iterdir():
 if p.is_file() and p.name.startswith('next-') and p.suffix.lower() in allowed:files.add(p)
for root in r.iterdir():
 if not root.is_dir() or not root.name.startswith('next-') or root.name=='next-source':continue
 for p in root.rglob('*'):
  if not p.is_file() or '.git' in p.parts:continue
  parts=p.relative_to(root).parts
  if root.name=='next-profiles':files.add(p);continue
  if ('installed' in root.name or 'relocated' in root.name) and any(x in parts for x in ['sdk','tools','vm','source','build','CMakeFiles']):continue
  if p.suffix.lower() in allowed:files.add(p)
for folder in ['C','C-common','C-flow','D','D-common','D-flow','D-preproof','D-common-preproof','D-flow-preproof']:
 files.update((r/'images'/folder).glob('*.json'))
files.add(r/'profile-target.py')
assert all(p.suffix.lower() not in {'.exe','.dll','.pdb','.obj','.lib','.a'} for p in files)
archive=e/'next-hotpath.zip';assert not archive.exists(),'Never overwrite a finalized archive'
manifest=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):
  data=p.read_bytes();path=p.relative_to(r).as_posix();z.writestr(path,data)
  manifest.append(dict(path=path,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
info=dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,entries=len(manifest),
 qualification_source=source,production_baseline=initial['comparison_source'],vtune_raw_included=True,
 compiled_images_in_archive=False,manifest=manifest)
(e/'next-hotpath.json').write_text(json.dumps(info,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(manifest)
 for x in manifest:assert hashlib.sha256(z.read(x['path'])).hexdigest()==x['sha256']
print(json.dumps({k:v for k,v in info.items() if k!='manifest'},indent=2))
