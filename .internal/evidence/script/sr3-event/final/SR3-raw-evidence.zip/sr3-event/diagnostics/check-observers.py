import hashlib,json,shutil
from pathlib import Path
root=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/sr3-event')
identities=[]
for label in ('b0','b2','b3'):
    directory=root/f'observer-{label}'
    data=json.loads((directory/'identity.json').read_text())
    assert hashlib.sha256((directory/'probe.cpp').read_bytes()).hexdigest()==data['source_sha256']
    data['lf_normalized_source_sha256']=hashlib.sha256((directory/'probe.cpp').read_bytes().replace(b'\r\n',b'\n')).hexdigest()
    assert hashlib.sha256(Path(data['executable']).read_bytes()).hexdigest()==data['executable_sha256']
    identities.append(data)
    dest=root/f'diagnostics/observer-inputs/{label}'
    dest.mkdir(parents=True,exist_ok=True)
    for p in directory.iterdir():
        if p.is_file() and p.suffix in ('.cpp','.hpp','.json','.txt'):
            shutil.copy2(p,dest/p.name)
assert len({r['lf_normalized_source_sha256'] for r in identities})==1
observed=[]
for comparison in ('b0-b3','b2-b3'):
    records=json.loads((root/f'final-{comparison}/runs.json').read_text())
    assert len(records)==72 and all(r['valid'] and r['exit_code']==0 for r in records)
    flow=[r for r in records if r['case'].startswith('flow-')]
    assert len(flow)==24
    for r in flow:
        x=r['integrity'];assert x['steady']['retained']==x['shutdown']['retained']==0
        assert all(x['shutdown'][key]==0 for key in ('queue','continuations','awaitables','waiters'))
        assert all(x['steady'][key]==x['shutdown'][key] for key in ('calls','checksum'))
        observed.append({'comparison':comparison,**{k:r[k] for k in ('case','mode','pair','variant','integrity')}})
alloc=json.loads((root/'diagnostics/matched-flow-allocations/manifest.json').read_text())
assert len(alloc)==4 and len({r['source_sha256'] for r in alloc})==1
assert all(r['executable_allocations']==['0','0','0'] for r in alloc)
before=json.loads((root/'diagnostics/b2-observed-counts/results.json').read_text())
after=json.loads((root/'diagnostics/final-counts/results.json').read_text())
assert all(before[k]==after[k] for k in ('before','after','delta','final'))
result={'matched_observers':identities,'integrity_records':observed,'matched_allocation_records':alloc,
    'source_match_rule':'CRLF to LF only. Initial raw-byte equality audit failed: B2 has 20 fewer CR characters. Normalized text is exactly equal; raw hashes remain recorded, no semantic source differences.',
    'b2_b3_branch_accounting_equal':True,
    'superseded':'sr3-e-checks/flow-allocations used each historical fixture source. Counts retained but not used as the final matched-source comparison.'}
(root/'diagnostics/observer-verification.json').write_text(json.dumps(result,indent=2))
invalid=json.loads((root/'diagnostics/invalid-trials.json').read_text())
if len(invalid)==2:
    invalid.append({'path':'../../sr3-e-checks/flow-allocations','reason':result['superseded']+' Replaced by diagnostics/matched-flow-allocations; no timing from either allocation probe is a formal performance result.'})
    (root/'diagnostics/invalid-trials.json').write_text(json.dumps(invalid,indent=2))
print('Three matched observer inputs, 48 integrity runs, four matched allocation runs and equal branch accounting verified.')
