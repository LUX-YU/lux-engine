#!/usr/bin/env python3
"""Strict paired-run arithmetic, not a benchmark driver or a qualification tool."""
from __future__ import annotations
import argparse
import json
import math
from pathlib import Path
import re
from statistics import median


def positive_number(value: object, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f'{name} must be a number')
    if not math.isfinite(value) or value <= 0:
        raise ValueError(f'{name} must be finite and positive')
    return float(value)


def analyse(data: dict) -> dict:
    comparisons = data.get('comparisons')
    if not isinstance(comparisons, list) or not comparisons:
        raise ValueError('Nonempty comparisons list required')
    output = []
    seen_ids = set()
    for comp in comparisons:
        cid = comp.get('id')
        if not isinstance(cid, str) or not cid or cid in seen_ids:
            raise ValueError('Each comparison needs a unique id')
        seen_ids.add(cid)
        runs = comp.get('runs')
        if not isinstance(runs, list):
            raise ValueError(f'{cid}: runs must be a list')
        index, rejected = {}, []
        side_sources = {'A': set(), 'B': set()}
        fingerprints = set()
        for run in runs:
            if run.get('valid') is False:
                if not run.get('invalid_reason'):
                    raise ValueError(f'{cid}: invalid run without recorded reason')
                rejected.append(run)
                continue
            if run.get('valid') is not True or run.get('oracle_pass') is not True:
                raise ValueError(f'{cid}: missing true valid/oracle_pass')
            side, pair = run.get('side'), run.get('pair')
            if side not in ('A', 'B') or isinstance(pair, bool) or pair not in (0, 1, 2):
                raise ValueError(f'{cid}: side/pair invalid')
            source = run.get('source')
            if not isinstance(source, str) or not re.fullmatch(r'[0-9a-f]{40}', source):
                raise ValueError(f'{cid}: full lowercase source SHA required')
            key = (pair, side)
            if key in index:
                raise ValueError(f'{cid}: duplicate valid run {key}; cannot pick the faster one')
            time = positive_number(run.get('total_ns'), 'total_ns')
            units = run.get('completed_units')
            if isinstance(units, bool) or not isinstance(units, int) or units <= 0:
                raise ValueError(f'{cid}: completed_units must be positive int')
            if not isinstance(run.get('unit'), str) or not run['unit']:
                raise ValueError(f'{cid}: unit required')
            fp = run.get('workload_fingerprint')
            digest = run.get('business_oracle_digest')
            if not isinstance(fp, str) or not fp or not isinstance(digest, str) or not digest:
                raise ValueError(f'{cid}: workload fingerprint and common business digest required')
            fingerprints.add(fp)
            side_sources[side].add(source)
            index[key] = (run, time / units)
        if set(index) != {(pair, side) for pair in range(3) for side in ('A', 'B')}:
            raise ValueError(f'{cid}: exactly three complete valid pairs required')
        if len(fingerprints) != 1 or any(len(v) != 1 for v in side_sources.values()):
            raise ValueError(f'{cid}: mixed workload or mixed source on the same side')
        a, b, deltas, pairs = [], [], [], []
        units_used = set()
        for pair in range(3):
            ra, va = index[(pair, 'A')]
            rb, vb = index[(pair, 'B')]
            for field in ('unit', 'completed_units', 'business_oracle_digest', 'workload_fingerprint'):
                if ra[field] != rb[field]:
                    raise ValueError(f'{cid} pair{pair}: unmatched {field}')
            units_used.add(ra['unit'])
            delta = 100 * (vb / va - 1)
            a.append(va); b.append(vb); deltas.append(delta)
            pairs.append({'pair': pair, 'A_ns_per_unit': va, 'B_ns_per_unit': vb,
                          'delta_percent': delta, 'A_total_seconds': ra['total_ns'] / 1e9,
                          'B_total_seconds': rb['total_ns'] / 1e9})
        if len(units_used) != 1:
            raise ValueError(f'{cid}: changing unit between pairs')
        output.append({'id': cid, 'unit': next(iter(units_used)), 'pairs': pairs,
                       'A_side_median_ns': median(a), 'B_side_median_ns': median(b),
                       'paired_median_percent': median(deltas), 'all_deltas_percent': deltas,
                       'faster_pairs': sum(x < 0 for x in deltas),
                       'slower_pairs': sum(x > 0 for x in deltas),
                       'invalid_runs_retained': rejected, 'equivalence_granted': False})
    return {'kind': 'ARITHMETIC_RECOMPUTATION_ONLY', 'source_causality_proven': False,
            'comparisons': output}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    data = json.loads(args.input.read_text(encoding='utf-8-sig'))
    result = analyse(data)
    if args.output.exists():
        raise ValueError('Output exists; refusing to overwrite previous arithmetic evidence')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(str(args.output))

if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, TypeError, KeyError) as exc:
        raise SystemExit(f'ERROR: {exc}')
