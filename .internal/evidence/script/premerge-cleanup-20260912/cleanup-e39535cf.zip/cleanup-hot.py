from pathlib import Path
r=Path(__file__).parent/'source'
def edit(path, fn):
 p=r/path; old=p.read_text(); new=fn(old); assert new!=old,path; p.write_text(new)
def native(t):
 start=t.index('        [[nodiscard]] NativeContinuation* createNativeContinuation(')
 end=t.index('            const auto slot = free_continuations.back();',start)
 t=t[:start]+'''        [[nodiscard]] NativeContinuation* createNativeContinuation(
            PreparedCall& call, const lux_script_step_vtable& step
        ) noexcept
        {
            // Loader validation and prepareMethod fixed this step's layout; capacity and frame lifetime remain dynamic.
            if (free_continuations.empty())
                return nullptr;
'''+t[end:]
 t=t.replace('            auto* continuation = prepared.owner->createNativeContinuation(prepared);',
 '''            const auto& step = *prepared.function->step;
            auto* continuation = prepared.owner->createNativeContinuation(prepared, step);''')
 return t.replace('const auto status = prepared.function->step->start(', 'const auto status = step.start(')
# Resolve the exact ABI type from the source header, do not invent a new ABI type.
abi=(r/'modules/function/script/core/include/lux/engine/function/script/ScriptABI.h').read_text() if False else ''
# Filled below after verifying the declared step type.
def result_path(t):
 t=t.replace('                record.value = {};','                record.value.bytes.clear();\n                record.value.type = {};')
 for old,new in [
  ('std::optional<PreparedResumeType> type, bool external)', 'const std::optional<PreparedResumeType>& type, bool external)'),
  ('            std::optional<PreparedResumeType> result_type,','            const std::optional<PreparedResumeType>& result_type,'),
  ('admitAwaitable(ExecutionInstance& owner, std::optional<PreparedResumeType> result_type,','admitAwaitable(ExecutionInstance& owner, const std::optional<PreparedResumeType>& result_type,'),
  ('ScriptInstanceId instance, std::optional<PreparedResumeType> result_type) noexcept','ScriptInstanceId instance, const std::optional<PreparedResumeType>& result_type) noexcept'),
  ('createAwaitable(ScriptInstanceId instance, std::optional<PreparedResumeType> type)', 'createAwaitable(ScriptInstanceId instance, const std::optional<PreparedResumeType>& type)'),
  ('std::move(result_type)', 'result_type'),('std::move(type)', 'type')]:
  t=t.replace(old,new)
 return t
edit('engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptExecution.hpp',result_path)
edit('engine/domain/simulation/scripting/core/include/lux/engine/simulation/scripting/ScriptRuntime.hpp',lambda t:t.replace('        [[nodiscard]] std::byte* data() noexcept','        void clear() noexcept { reset(); }\n\n        [[nodiscard]] std::byte* data() noexcept',1))
def timer(t):
 t=t.replace('''        const auto association = waits_[key(id)].association;
        const auto route = waits_[key(id)].route;''','''        const auto& due = waits_[key(id)];
        const auto association = due.association;
        const auto route = due.route;
        const auto external = due.external;''')
 return t.replace('const auto completion = external_[waits_[key(id)].external];', 'const auto completion = external_[external];')
edit('engine/domain/simulation/builtin/script/src/ScriptTimers.cpp',timer)
def feedback_test(t):
 at=t.index('    void testMixedReassociationRollback()')
 t=t[:at]+'''    void testFeedbackWrapAndRedirty()
    {
        Harness harness{3U, true, true, true};
        auto created = harness.create();
        assert(created && created->prepare());
        auto& system = *created;
        const auto backing = system.stats().mount_feedback_backing_bytes;
        std::array<ScriptMountStatus, 1U> one;
        const auto first = system.collectMountStatusChanges(one);
        assert(first && first->written == 1U && first->remaining == 2U && one[0].id.value == 1U);
        harness.registry.destroy(harness.entities[0]);
        assert(system.processLifecycle());
        const auto status = system.queryMountStatus({1U});
        assert(status && *status && (**status).reclaimed);
        const auto zero = system.collectMountStatusChanges({});
        assert(zero && zero->written == 0U && zero->remaining == 3U);
        for (const auto id : {2U, 3U, 1U})
        {
            const auto collected = system.collectMountStatusChanges(one);
            assert(collected && collected->written == 1U && one[0].id.value == id);
            if (id == 1U) assert(one[0].reclaimed && collected->remaining == 0U);
        }
        assert(system.stats().mount_feedback_backing_bytes == backing);
        assert(system.shutdown());
        assert(harness.backend_state.creates == 3U && harness.backend_state.destroys == 3U);
        assert(system.collectMountStatusChanges(one)->written == 1U);
        assert(system.collectMountStatusChanges(one)->written == 1U);
        assert(system.collectMountStatusChanges(one)->remaining == 0U);
        std::puts("FEEDBACK_WRAP first=1 redirty=1 order=2,3,1 zero_no_consume=1 backing_stable=1 PASS");
    }

'''+t[at:]
 return t.replace('    testMixedReassociationRollback();','    testFeedbackWrapAndRedirty();\n    testMixedReassociationRollback();')
edit('engine/domain/simulation/builtin/script/test/script_system_lifecycle_test.cpp',feedback_test)
