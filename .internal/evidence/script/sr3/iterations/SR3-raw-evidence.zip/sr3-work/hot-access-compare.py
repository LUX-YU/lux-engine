import subprocess, os, json, csv, statistics, hashlib
from pathlib import Path
root=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/sr3-work/hot-access-4')
root.mkdir(exist_ok=False)
variants={'baseline':Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/sr3-reference/d/bin'), 'candidate':Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/sr2-work/d/bin')}
records=[]
for pair in range(5):
    for variant in (('baseline','candidate') if pair%2==0 else ('candidate','baseline')):
        directory=variants[variant]
        exe=directory/'script_runtime_benchmark.exe'
        output=root/f'{variant}-{pair}.csv'
        cmd=[str(exe),'--group','scene-cpp-update-heavy','--mode','performance','--size','10000','--warmups','60','--frames','300','--seed','1592598566','--resume-budget','2000','--workers','0','--output',str(output)]
        env=dict(os.environ)
        env['PATH']=str(directory)+';D:/Development/vcpkg/installed/x64-windows/bin;E:/SyncForder/CodeRepos/install/q2/c/bin;'+env['PATH']
        with (root/f'{variant}-{pair}.log').open('w') as stream:
            result=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT,env=env)
        assert result.returncode==0
        rows=list(csv.DictReader(output.open()))
        assert len(rows)==300 and all(int(row['calls'])==10000 and int(row['active_instances'])==10000 and int(row['queue_depth'])==0 for row in rows)
        records.append({'variant':variant,'pair':pair,'command':cmd,'median_ns':statistics.median(float(row['nanoseconds']) for row in rows),'dll_sha256':hashlib.sha256((directory/'lux_engine_simulation_script.dll').read_bytes()).hexdigest()})
(root/'runs.json').write_text(json.dumps(records,indent=2))
print([(r['variant'],r['median_ns']) for r in records])
