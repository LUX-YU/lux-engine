// Isolation only: unmodified service/coordinator, manually delivered owner completion,
// shim expected/identity/CodeLease. Not the actual TaskScope/ExecutionRuntime or SDK.
#define main original_probe_main
#include "core_regressions.cpp"
#undef main
#include <cstdlib>
int main(int argc,char**argv) {
 assert(argc==2); const bool encodeFailure=std::string_view(argv[1])=="encoding-error";
 WriteCoordinator writes; SaveService saves(writes); Source source; Disk disk;
 auto registration=saves.registerSource(source);assert(registration);
 const auto first=save(saves,source,"V1");encode(saves);publish(writes,disk);
 const auto second=save(saves,source,"V2");auto work=saves.takeEncoding();
 assert(work && *work && (**work).id==second);
 PersistenceResult<EncodedArtifact> completed=encodeFailure
   ? PersistenceResult<EncodedArtifact>{lux::cxx::unexpected(PersistenceFailure{EPersistenceError::ENCODE})}
   : (**work).encoding.encode({});
 (**work).encoding={};work->reset();
 bool delivered{},received{};EPersistenceError error=EPersistenceError::INVALID_ARGUMENT;
 source.onAccept=[&]{
   if(delivered)return;delivered=true;
   // SaveExecution makes this same consuming call, discarding the returned status.
   // Here it is recorded only for diagnostics. There is no completion replay.
   auto result=saves.completeEncoding(second,std::move(completed));
   received=bool(result);if(!result)error=result.error().code;
 };
 saves.adoptCompletions();source.onAccept={};
 auto status=saves.status(second);assert(status&&delivered);
 bool stuck=status->stage==ESaveStage::ENCODING;
 std::cout<<"encode_failure="<<encodeFailure<<" delivered="<<delivered
   <<" completion_accepted="<<received<<" rejected_busy="<<(!received&&error==EPersistenceError::BUSY)
   <<" stuck_encoding="<<stuck<<std::endl;
 if(stuck){
   assert(saves.acknowledge(first));auto cancel=saves.requestCancel(second);
   const auto third=save(saves,source,"V3");encode(saves);
   assert(saves.status(third)->stage==ESaveStage::READY);
   auto next=writes.takeReady();assert(next);
   std::cout<<"cancel_requested="<<(cancel&&*cancel==ECancelResult::REQUESTED)
     <<" still_encoding="<<(saves.status(second)->stage==ESaveStage::ENCODING)
     <<" follower_ready=1 follower_blocked="<<!bool(*next)<<" final_disk="<<disk.version<<std::endl;
   // Avoid masking the liveness bug with the intentional destructor terminate on ENCODING.
   std::cout.flush();std::cerr.flush();std::_Exit(20);
 }
 publish(writes,disk);saves.adoptCompletions();
 assert(saves.status(second)->stage==ESaveStage::TERMINAL);
 assert(disk.version==(encodeFailure?"V1":"V2"));
 assert(saves.acknowledge(first)&&saves.acknowledge(second));
 std::cout<<"completed_normally=1 final_disk="<<disk.version<<std::endl;
}
