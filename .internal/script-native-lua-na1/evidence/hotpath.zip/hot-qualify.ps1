$ErrorActionPreference='Stop'
$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1'
$s="$r/opt-source"
$sha=(git -C $s rev-parse HEAD).Trim()
if(git -C $s status --porcelain){throw 'Dirty qualification source'}
& 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
function Run([string]$name,[string[]]$command){
 $log="$r/$name.log"; if(Test-Path -LiteralPath $log){throw "Existing log $log"}
 $command|ConvertTo-Json -Compress|Set-Content $log
 $watch=[Diagnostics.Stopwatch]::StartNew()
 & $command[0] $command[1..($command.Length-1)] *>>$log
 $code=$LASTEXITCODE
 @{source=$sha;command=$command;exit=$code;seconds=$watch.Elapsed.TotalSeconds}|ConvertTo-Json -Depth 5|Set-Content "$r/$name.json"
 Write-Output "$name exit=$code"
 if($code){throw "$name failed"}
}
Run 'hot-qualified-tracked' @('cmake',"-DLUX_SOURCE_DIR=$s",'-P',"$s/cmake/ValidateTrackedSnapshot.cmake")
foreach($slot in @('t','d')){
 $b="E:/SyncForder/CodeRepos/build/RelWithDebInfo/o/w/$slot"
 $taskProfile=if($slot -eq 't'){'TOOLCHAIN'}else{'DEVELOPER'}
 $leaf=if($slot -eq 't'){'optimized-tools'}else{'optimized-sdk'}
 $prefix="E:/SyncForder/CodeRepos/install/o/na1/$leaf"
 Copy-Item -LiteralPath "$b/CMakeCache.txt" -Destination "$r/hot-qualified-$slot-previous-cache.txt"
 Run "hot-qualified-$slot-configure" @('cmake','-S',$s,'-B',$b,'-G','Ninja','-DCMAKE_BUILD_TYPE=RelWithDebInfo',
  "-DLUX_BUILD_PROFILE=$taskProfile",'-DBUILD_TESTING=ON','-DLUX_BUILD_PHYSICS2D=ON','-DLUX_SCRIPT_HOTPATH_OBSERVATION=OFF',
  '-DCMAKE_TOOLCHAIN_FILE=D:/Development/vcpkg/scripts/buildsystems/vcpkg.cmake',
  '-DCMAKE_PREFIX_PATH=E:/SyncForder/CodeRepos/install/q2/toolset;E:/SyncForder/CodeRepos/install/q2/c;E:/SyncForder/CodeRepos/install/RelWithDebInfo',
  '-DLuxLua55_DIR=E:/SyncForder/CodeRepos/install/o/v4/lua55/lib/cmake/LuxLua55',"-DCMAKE_INSTALL_PREFIX=$prefix",
  '-DLUX_LUA_PORTABILITY_ARTIFACT=E:/SyncForder/CodeRepos/build/RelWithDebInfo/o/w/t/engine/toolchain/lua/lua_portability_fixture.lxsa',
  '-DLUX_PHYSICS2D_LUA_ARTIFACT=E:/SyncForder/CodeRepos/build/RelWithDebInfo/o/w/t/engine/toolchain/physics2d/physics2d_lua_fixture.lxsa',
  '-DLUX_PHYSICS2D_FLOWFORGE_ARTIFACT=E:/SyncForder/CodeRepos/build/RelWithDebInfo/o/w/t/engine/toolchain/physics2d/physics2d_flowforge_fixture.lxsa')
 $targets=@('all')
 if($slot -eq 't'){$targets+=@('physics2d_flowforge_fixture','physics2d_lua_fixture','lua_runtime_benchmark_fixture','lua_portability_fixture')}
 Run "hot-qualified-$slot-build" (@('cmake','--build',$b,'--target')+$targets+@('-j','4','--','-k','0'))
 Run "hot-qualified-$slot-noop" @('cmake','--build',$b,'--target','all','-j','4','--','-k','0')
 if(!(Select-String -LiteralPath "$r/hot-qualified-$slot-noop.log" -SimpleMatch 'no work to do' -Quiet)){throw 'Not no-op'}
 $env:PATH="$b/bin;D:/Development/vcpkg/installed/x64-windows/bin;$env:PATH"
 Run "hot-qualified-$slot-tests" @('ctest','--test-dir',$b,'--output-on-failure','-j','1')
 Copy-Item -LiteralPath "$b/Testing/Temporary/LastTest.log" -Destination "$r/hot-qualified-$slot-LastTest.log"
 Run "hot-qualified-$slot-install" @('cmake','--install',$b,'--config','RelWithDebInfo')
 Copy-Item -LiteralPath "$b/install_manifest.txt" -Destination "$r/hot-qualified-$slot-install-manifest.txt"
}
