#pragma once
// Generated typed value operations. No offsets or runtime reflection interpretation.
#include <lux/engine/function/script/lua/LuaValue.hpp>
#include <LuaValueTestTypes.hpp>
#include "E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/candidate-source/engine/domain/simulation/scripting/lua/test/LuaValueTestRules.hpp"

namespace lux::script::lua
{

template <> struct LuaGeneratedValue<::lux::simulation::script::test::ValueMode> : LuaEnumValue<::lux::simulation::script::test::ValueMode, ::lux::simulation::script::test::ValueMode::WALK, ::lux::simulation::script::test::ValueMode::RUN> {};


template <> struct LuaGeneratedValue<::lux::simulation::script::test::ValueVelocity> : LuaRecordValue<::lux::simulation::script::test::ValueVelocity,
    LuaValueField<&::lux::simulation::script::test::ValueVelocity::x, "x">,
    LuaValueField<&::lux::simulation::script::test::ValueVelocity::y, "y">>
{
};
static_assert(LuaValueCodec<::lux::simulation::script::test::ValueVelocity>::bounded, "Lua value expanded frame exceeds 64 KiB or depth 32");

template <> struct LuaGeneratedValue<::lux::simulation::script::test::ValuePose> : LuaRecordValue<::lux::simulation::script::test::ValuePose,
    LuaValueField<&::lux::simulation::script::test::ValuePose::id, "key">,
    LuaValueField<&::lux::simulation::script::test::ValuePose::velocity, "velocity">,
    LuaValueField<&::lux::simulation::script::test::ValuePose::mode, "mode">>
{
};
static_assert(LuaValueCodec<::lux::simulation::script::test::ValuePose>::bounded, "Lua value expanded frame exceeds 64 KiB or depth 32");

template <> struct LuaGeneratedValue<::lux::simulation::script::test::ValueAngle> : LuaRecordValue<::lux::simulation::script::test::ValueAngle,
    LuaValueField<&::lux::simulation::script::test::ValueAngle::radians, "radians">>
{
};
static_assert(LuaValueCodec<::lux::simulation::script::test::ValueAngle>::bounded, "Lua value expanded frame exceeds 64 KiB or depth 32");

template <> struct LuaGeneratedValue<::lux::simulation::script::test::ValueConstRecord> : LuaRecordValue<::lux::simulation::script::test::ValueConstRecord,
    LuaValueField<&::lux::simulation::script::test::ValueConstRecord::id, "id">,
    LuaValueField<&::lux::simulation::script::test::ValueConstRecord::weight, "weight">>
{
};
static_assert(LuaValueCodec<::lux::simulation::script::test::ValueConstRecord>::bounded, "Lua value expanded frame exceeds 64 KiB or depth 32");

template <> struct LuaGeneratedValue<::lux::simulation::script::test::ValuePushOnly> : LuaRecordValue<::lux::simulation::script::test::ValuePushOnly,
    LuaValueField<&::lux::simulation::script::test::ValuePushOnly::radians, "radians">>
{
};
static_assert(LuaValueCodec<::lux::simulation::script::test::ValuePushOnly>::bounded, "Lua value expanded frame exceeds 64 KiB or depth 32");

template <> struct LuaGeneratedValue<::lux::simulation::script::test::ValueToken> : LuaRecordValue<::lux::simulation::script::test::ValueToken>
{
    static LuaValueResult<::lux::simulation::script::test::ValueToken> read(LuaValueReader&) = delete; // Explicit factory/override required for omitted members.
};
static_assert(LuaValueCodec<::lux::simulation::script::test::ValueToken>::bounded, "Lua value expanded frame exceeds 64 KiB or depth 32");
}
