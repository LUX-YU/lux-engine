# P05 R2 有限独立复跑

生产 SaveService.cpp 与 WriteCoordinator.cpp 的字节经 Git Blob SHA-1 核验；来源身份见 verified_sources.json。
使用上一轮隔离测试的基础头 shim（含 std::expected），不是完整 Lux 依赖。使用 GCC 14.2、C++23、ASan/UBSan、O0/O2；C++23 仅供替身使用，项目保持 C++20。

两种优化分别运行：编码成功、编码错误、角色自撤销、递归采用、保留 W1 对照、确认 W1 后衔接，共十二次，均退出 0。

未编译 SaveExecution/ExecutionRuntime/stdexec，完成在 callback 内手动交付；没有真实三模型、磁盘 IO、GPU、Android 或完整 SDK 运行。ASan leak detector 关闭；不能声称无泄漏已证明。

复跑：
```text
python run_r2.py completion O0
python run_r2.py completion O2
python run_r2.py core O0
python run_r2.py core O2
```

结果在 r2_runs/。本包不包含已编译可执行文件。运行脚本只编译本目录中的隔离源码并写本地结果，不修改用户仓库。
