# P05 隔离核心源码探针

## 运行

```bash
python3 run_probes.py --compiler g++
```

要求 GCC/libstdc++ 提供 C++23 std::expected 与 ASan/UBSan。编译生成物放临时目录，运行完成自动删除；日志写入 `runs/`。

本包 **不是引擎补丁**。不要把 include/test_shim.hpp 或 vendor/ 复制进产品模块，也不要用该 shim 替换 lux-cxx。

## 真实使用的生产部分

- `vendor/SaveService.cpp`
- `vendor/WriteCoordinator.cpp`

它们与指定 GitHub 提交返回的 Git Blob 完全一致，脚本在编译前校验。其余 public value/interface 的头在 test_shim.hpp 中整理成隔离形状；低层 expected、身份、CodeLease 使用替身。

本探针没有真实 SessionStore/History/Scene/Material/Flow、ExecutionRuntime、项目文件 IO、插件 DLL 或 GPU。因此结果仅说明两份核心实现的调度/生命周期和链路逻辑，不是完整 SDK 编译资格。

## 四个场景

- `chain-control`：保留 W1 已终态记录时，V4 正常发布。正向对照。
- `chain-ack`：只增加确认并删除 W1，V4 误报冲突。目标正确性断言退出 10。
- `revoke`：describe 撤销注册，Source 对象继续存活；下一次调用触发空指针。
- `recursive-adoption`：accept 一次性递归推进同操作并确认；外层写已释放记录，ASan 报告 heap-use-after-free。

本包运行了 O0 和 O2 共八次。退出 0 的 runner 只表示预期原缺陷/对照观察完整，**不是生产代码通过目标契约**。`results.json` 对每条均有 `target_contract_met` 字段。

## 稳定依据

对应源文件版本：`5866f990f8a5c4d68e19e0e395c9487c6c0f2779`（验收提交；父实现 `8deaee9beaab431c1cfa82282206e7ff2f40d09b`）。

正式 R1 应在实施方实际 SDK 中，使用真实 MaterialSaveSource 包装器和三模型 Fixture 重跑文档列出的场景；不能把本包的受控角色或内存 Disk 作为全部真实 IO 验收。
