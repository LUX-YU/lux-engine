from pathlib import Path
import json,subprocess,hashlib,re
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/lua55-v3');repo=r.parent/'s5/source'
# No historical tests are relabelled; only unchanged dependency source is reused across the final formatting/test fixes.
vm_files=subprocess.check_output(['git','ls-files','cmake/dependencies/lua55'],cwd=repo,text=True).splitlines()
a='5985cc4d49fba8aecfcb40fa9bdb70ea0204f55a';b=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
changes=subprocess.check_output(['git','diff','--name-only',a,b,'--','cmake/dependencies/lua55'],cwd=repo,text=True).splitlines()
assert changes==['cmake/dependencies/lua55/README.md'],changes
(r/'vm-source-continuity.json').write_text(json.dumps(dict(vm_test_source=a,engine_candidate=b,changes=changes,production_vm_inputs_identical=True),indent=2))
# Extra dependency files were separately hashed against the already recorded v2 install, not source HEAD.
print('VM_INPUTS_IDENTICAL',a,b)
