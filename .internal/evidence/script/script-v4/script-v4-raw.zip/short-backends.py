"""Three bounded paired batches per backend; existing subscenes retain their own units."""
from pathlib import Path
import csv,ctypes as ct,hashlib,json,os,re,shutil,statistics,struct,subprocess,time
r=Path(__file__).parent
out=r/'short-backends';out.mkdir(exist_ok=False)
image=r/'final-flow-image';image.mkdir(exist_ok=False)
source=json.loads((r/'final-d-build.json').read_text(encoding='utf-8-sig'))['source']
helper=(r/'save-w1.py').read_text();exec(helper[helper.index('def sha('):helper.index('queue=')])
queue=['flowforge_script_runtime_benchmark.exe'];saved={};external=[]
roots=[r.parent/'o/w/t/bin',r.parent/'o/w/d/bin',Path('D:/Development/vcpkg/installed/x64-windows/bin')]
while queue:
 name=queue.pop()
 if name.lower() in saved:continue
 p=next((root/name for root in roots if (root/name).exists()),None)
 if not p:external.append(name);continue
 shutil.copy2(p,image/name);saved[name.lower()]={'origin':str(p),'sha256':sha(p)}
 if p.with_suffix('.pdb').exists():shutil.copy2(p.with_suffix('.pdb'),image/p.with_suffix('.pdb').name)
 queue+=imports(p)
(image/'identity.json').write_text(json.dumps(dict(source=source,images=saved,system_imports=external),indent=2))
k=ct.WinDLL('kernel32');k.GetCurrentProcess.restype=ct.c_void_p
k.SetProcessAffinityMask.argtypes=[ct.c_void_p,ct.c_size_t];assert k.SetProcessAffinityMask(k.GetCurrentProcess(),16)
linker=re.search(r'CMAKE_LINKER:FILEPATH=(.*)',(r.parent/'o/w/t/CMakeCache.txt').read_text())[1].strip()
groups={'cpp':['scene-cpp-update-heavy','micro-cpp-coroutine','scene-cpp-sequence'],
        'flowforge':['scene-flowforge-update-heavy','micro-flowforge-ability-query','scene-flowforge-sequence','scene-flowforge-event']}
business=['active_instances','calls','ability_calls','events','suspensions','resumes','started','completed',
 'continuations','awaitables','event_waiters','event_dispatch_visits','queue_depth','queue_high_water',
 'checksum','claim_lookups','actual_copy_bytes','completion_capabilities','phase']
runs=[]
for backend,scenes in groups.items():
 for pair in range(3):
  for side in (['baseline','candidate'] if pair%2==0 else ['candidate','baseline']):
   active=(r.parent/'lua55-v3/final-image' if side=='baseline' else r/'final-image') if backend=='cpp' else (r/'v3-flow-image' if side=='baseline' else image)
   for scene in scenes:
    name=f'{backend}-{pair}-{side}-{scene}';data=out/(name+'.csv');log=out/(name+'.log')
    command=[str(active/('script_runtime_benchmark.exe' if backend=='cpp' else 'flowforge_script_runtime_benchmark.exe')),
     '--group',scene,'--mode','performance','--size','10000','--frames','1000','--warmups','300',
     '--seed','1592598566','--resume-budget','10000','--output',str(data)]
    env=dict(os.environ);env['LUX_FLOWFORGE_LINKER']=linker
    env['PATH']=';'.join([str(active),'D:/Development/vcpkg/installed/x64-windows/bin',*[p for p in env['PATH'].split(';') if 'CodeRepos' not in p and 'vcpkg' not in p]])
    start=time.monotonic()
    with log.open('wb') as f:code=subprocess.call(command,stdout=f,stderr=subprocess.STDOUT,env=env)
    rows=list(csv.DictReader(data.open())) if data.exists() else [];text=log.read_text()
    expected='e06208deb29b9b1de52fe49a129091f693bb7e08' if side=='baseline' else source
    valid=code==0 and len(rows)>=1000 and all(x['git_commit']==expected and x['build_type']=='RelWithDebInfo' for x in rows)
    errors=re.findall(r'invocation_errors=(\d+)',text)
    valid=valid and all(int(e)==0 for e in errors)
    measures=[]
    for scenario in dict.fromkeys(x['scenario'] for x in rows):
     for phase in dict.fromkeys(x.get('phase','steady') for x in rows if x['scenario']==scenario):
      selected=[x for x in rows if x['scenario']==scenario and x.get('phase','steady')==phase]
      times=sorted(int(x['nanoseconds']) for x in selected)
      frames='sequence' in scene or phase=='drain'
      operations=len(times) if frames else len(times)*10000
      measures.append(dict(scenario=scenario,phase=phase,total_ns=sum(times),actual_operations=operations,
       unit='simulation-frame' if frames else ('backend-start' if scenario.endswith('-start') else 'backend-resume-and-destroy' if scenario.endswith('-resume') else 'complete-call'),
       ns_per_actual_operation=sum(times)/operations,p50_batch_ns=statistics.median(times),
       p95_batch_ns=times[min(len(times)-1,int(len(times)*.95))],p99_batch_ns=times[min(len(times)-1,int(len(times)*.99))]))
    run=dict(backend=backend,pair=pair,side=side,scene=scene,command=command,exit=code,valid=valid,
     source=expected,wall_seconds=time.monotonic()-start,measurements=measures,
     errors=0 if errors else None,error_scope='outside ROI cumulative runtime counters' if errors else 'backend state/checksum/storage assertions; cumulative error counter unavailable',
     last_business={key:rows[-1][key] for key in business if rows and key in rows[-1]},
     backlog=int(rows[-1]['queue_depth']) if rows else None,diagnostics_enabled=False,
     exe_local_allocations=sum(int(x['allocations']) for x in rows) if rows and rows[0].get('allocation_accounting')=='1' else None,
     provider_order_evidence='same driver, seeded inputs and all per-batch business counters; no separate call-order trace',
     observations=[x for x in text.splitlines() if x.startswith(('INTEGRITY','ERRORS','NATIVE_STORAGE','BUSINESS_ORACLE'))])
    runs.append(run);(out/'runs.json').write_text(json.dumps(runs,indent=2))
    print(name,code,valid,[(m['phase'],round(m['ns_per_actual_operation'],2)) for m in measures],flush=True)
    if not valid:raise SystemExit('invalid short group '+name)
    if side=='candidate' and any(x['scene']==scene and x['side']=='baseline' and x['pair']==pair for x in runs):
     pass
summary=[]
for backend,scenes in groups.items():
 for scene in scenes:
  scene_runs=[x for x in runs if x['scene']==scene]
  for pair in range(3):
   paired={x['side']:x for x in scene_runs if x['pair']==pair}
   raw={side:list(csv.DictReader((out/f'{backend}-{pair}-{side}-{scene}.csv').open())) for side in paired}
   assert len(raw['baseline'])==len(raw['candidate'])
   for a,b in zip(raw['baseline'],raw['candidate']):
    assert all(a[key]==b[key] for key in business if key in a and key in b),(scene,pair,a,b)
  for i,measure in enumerate(scene_runs[0]['measurements']):
   deltas=[];costs={side:[] for side in ['baseline','candidate']}
   for pair in range(3):
    paired={x['side']:x['measurements'][i] for x in scene_runs if x['pair']==pair}
    for side,v in paired.items():costs[side].append(v['ns_per_actual_operation'])
    deltas.append(100*(paired['candidate']['total_ns']/paired['baseline']['total_ns']-1))
   summary.append(dict(scene=scene,scenario=measure['scenario'],phase=measure['phase'],unit=measure['unit'],
    deltas_percent=deltas,median_percent=statistics.median(deltas),baseline_ns=statistics.median(costs['baseline']),candidate_ns=statistics.median(costs['candidate'])))
(out/'summary.json').write_text(json.dumps(summary,indent=2))
print('SHORT_BATCHES_COMPLETE',flush=True)
