$ErrorActionPreference='Stop'
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5c'
cmake --build E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/d --target all -j 4 -- -k 0 *> "$r/fix-all.log"
if ($LASTEXITCODE) { throw 'fix all failed' }
$env:PATH="E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/d/bin;D:/Development/vcpkg/installed/x64-windows/bin;$env:PATH"
$records=@()
foreach ($case in @('retire-scalar','retire-zero','stop-scalar','stop-zero','input-recovery')) {
    & E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/d/bin/simulation_script_lua_value_runtime_test.exe --admission-case $case *> "$r/fix-$case.log"
    $records+=@{case=$case;exit=$LASTEXITCODE;exe_sha256=(Get-FileHash E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/d/bin/simulation_script_lua_value_runtime_test.exe).Hash}
}
$records | ConvertTo-Json | Set-Content "$r/fix-cases.json"
ctest --test-dir E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/d -R 'lua_value|simulation_script_lua_test|collision_event' --output-on-failure *> "$r/fix-narrow.log"
if ($LASTEXITCODE) { throw 'fix narrow failed' }
