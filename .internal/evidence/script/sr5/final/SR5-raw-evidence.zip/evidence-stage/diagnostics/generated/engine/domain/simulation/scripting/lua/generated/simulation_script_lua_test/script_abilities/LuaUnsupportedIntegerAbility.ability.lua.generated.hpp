#pragma once
// Generated typed Lua projection. Include the matching .ability.generated.hpp first.
#include <lux/engine/simulation/scripting/lua/LuaScriptAbilityProjection.hpp>

#include <array>
#include <type_traits>
#include <utility>

namespace lux::script::lua
{

    template <>
    struct ScriptAbilityLuaTraits<::lux::simulation::script::test::LuaUnsupportedIntegerAbility> final
    {
        using AbilityTraits = ScriptAbilityTraits<::lux::simulation::script::test::LuaUnsupportedIntegerAbility>;
        using Policy = typename ScriptAbilityLuaPolicy<::lux::simulation::script::test::LuaUnsupportedIntegerAbility>::Type;

        using Values_echo = LuaAbilityValueSignature<Policy, long long, long long>;
        [[nodiscard]] static int echo(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, long long, long long>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, long long value) noexcept -> long long
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.echo(access.context, value);
                }
            );
        }

        inline static constexpr std::array<ScriptAbilityLuaMethodProjection, AbilityTraits::Methods.size()> Methods{
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.lua_unsupported_integer.echo"},
                &echo, Values_echo::Parameters, Values_echo::Results
            }
        };
    };
} // namespace lux::script::lua
