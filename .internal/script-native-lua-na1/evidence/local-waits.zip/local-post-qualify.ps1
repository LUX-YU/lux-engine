$ErrorActionPreference='Stop'
$r=$PSScriptRoot
$python='C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
& "$r/local-installed.ps1"
if($LASTEXITCODE){throw 'installed failed'}
& "$r/local-new-incremental.ps1"
if($LASTEXITCODE){throw 'incremental failed'}
& "$r/local-relocated.ps1" -Root $r
if($LASTEXITCODE){throw 'relocation failed'}
& "$r/local-benchmark.ps1" -Side B -Label local-bench
if($LASTEXITCODE){throw 'benchmark build/smoke failed'}
& $python -B "$r/local-save-images.py"
if($LASTEXITCODE){throw 'save images failed'}
& "$r/local-class-layout.ps1"
if($LASTEXITCODE){throw 'class layout failed'}
& $python -B "$r/local-machine.py"
if($LASTEXITCODE){throw 'machine capture failed'}
$b='E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-lua55-s0-s1-20260909/dependencies/build-lua55'
$vm='E:/SyncForder/CodeRepos/install/o/v4/lua55/bin/lux_lua55.dll'
if(!(Test-Path $vm)){throw 'VM identity path changed'}
$hash=(Get-FileHash $vm).Hash
if($hash -ne '34F11DF8679A46B2D956462A99A9A3BA49EE29E88B85BB27B1C2B3C5A78BB29E'){throw 'VM changed'}
& ctest --test-dir $b --output-on-failure -j 1 *> "$r/local-vm-tests.log"
$code=$LASTEXITCODE
@{candidate=(git -C "$r/local-source" rev-parse HEAD);unchanged_vm_sha256=$hash;exit=$code;test_location=$b}|ConvertTo-Json | Set-Content "$r/local-vm-tests.json"
if($code){throw 'VM contracts failed'}
Write-Output 'LOCAL_QUALIFICATION_AND_IMAGES_DONE'
