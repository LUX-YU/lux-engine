from pathlib import Path
import hashlib,json,subprocess,zipfile
r=Path(__file__).parent;source=r/'source';dest=source/'.internal/evidence/script/script-cell-a1';dest.mkdir(parents=True,exist_ok=True)
archive=dest/'script-cell-a1-raw.zip';assert not archive.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
selected={}
binary={'.dll','.exe','.pdb','.obj','.lib','.exp','.ilk','.pch','.lxsa','.zip'}
def add(p):
 if p.is_file() and p.suffix.lower() not in binary and '__pycache__' not in p.parts:
  selected[p.relative_to(r).as_posix()]=p
for p in r.iterdir():
 if p.suffix in ['.log','.json','.exit','.txt']:add(p)
drivers=['capture-start.py','build.ps1','qualify-final.ps1','capture-final.py','compare-contracts.py','installed-final.ps1',
 'relocated-qualified-source.ps1','final-costs.py','layout-probe.cpp','layout-probe.py','observe.ps1','observe.py',
 'additional-contracts.py','profile-candidate.py','profile-target.py','final-audit.py','write-result.py','package-evidence.py','verify-remote.py']
for name in drivers:
 p=r/name
 if p.exists():add(p)
for directory in ['final-costs','resource-diagnostic','value-incremental','contract-comparison','contract-attempt1','contract-attempt2',
 'layout','additional-contracts','additional-attempt1','candidate-profile']:
 for p in (r/directory).rglob('*'):add(p)
for directory in ['final-image','final-flow-image','observation-image']:add(r/directory/'identity.json')
for p in (r/'installed').iterdir():
 if p.is_file():add(p)
 else:
  for log in p.glob('*.log'):add(log)
  for inp in (p/'source').rglob('*'):add(inp)
  add(p/'build/CMakeCache.txt')
for name in ['results.json','unavailable-paths.json']:add(r/'relocated'/name)
for consumer in ['script-lua-values','lua-script-packager']:
 folder=r/'relocated'/consumer
 for p in folder.glob('*'):
  if p.is_file():add(p)
 for dirname in ['source','s']:
  for p in (folder/dirname).rglob('*'):add(p)
 for dirname in ['build','b']:add(folder/dirname/'CMakeCache.txt')
patch=r/'qualified-source.patch'
patch.write_bytes(subprocess.check_output(['git','-C',str(source),'diff','f92853ea..caf34bd3','--']))
add(patch)
entries=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(selected.items()):
  data=p.read_bytes();entries.append({'path':name,'bytes':len(data),'sha256':sha(data)});z.writestr(name,data)
 manifest={'qualification_source':'caf34bd307912450d894da922b59af4238154508',
  'baseline_source':'f7d2815bdd2025ee23a7c11449def822413f58e9','files':entries}
 z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for entry in entries:assert sha(z.read(entry['path']))==entry['sha256']
metadata={'path':archive.name,'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'hashed_files':len(entries),'zip_entries':len(entries)+1,
 'qualification_source':manifest['qualification_source'],'baseline_source':manifest['baseline_source'],'verification':'All file hashes and ZIP CRC verified','compiled_product_binaries':False}
(dest/'archive.json').write_text(json.dumps(metadata,indent=2))
(dest/'SHA256SUMS').write_text(metadata['sha256']+'  '+archive.name+'\n')
index=f'''# ExecutionCell A1 原始证据

本包只对应实验分支 `codex/s6-execution-cell-a1`。A 为 `f7d2815bdd2025ee23a7c11449def822413f58e9`；
B 实际完整资格/计时为 `caf34bd307912450d894da922b59af4238154508`。归档/报告提交不作为新测试身份。

[结果报告](../../../script-cell-a1/RESULT.zh-CN.md) · [实际数据](../../../script-cell-a1/result.json) ·
[合同映射](../../../script-cell-a1/TEST_MATRIX.csv) · [原始ZIP]({archive.name}) · [SHA-256](SHA256SUMS)

归档 `{metadata['bytes']}` B，`{metadata['hashed_files']}` 项文件 hash、`{metadata['zip_entries']}` 项ZIP entries，已逐项核验。
SHA-256：`{metadata['sha256']}`。无DLL/PDB/EXE/OBJ产品二进制；匹配镜像保持在原本地目录，身份清单入包。

- `final-*-*.log/json`：clean clone all/no-work/CTest/install与命令退出码；`final-*-LastTest.log`保留实际断言输出。
- `final-costs/`：全部42个有效正式进程、逐帧CSV、原始stdout、命令、批次分位和配对分布；无性能重测替换。
- `resource-diagnostic/`、`layout/`：独立cell/VM观察、内存请求及类型布局，未混入正式计时。
- `contract-comparison/`、`additional-contracts/`：A/B固定DLL上的同一真实fixture业务轨迹，测试源码hash和增强输入保留。
- `installed/`、`value-incremental/`、`relocated/`：15消费者、13增量与2迁址链。
- `candidate-profile/`：一次B软件采样的原始VTune记录、业务、导出表及命令；`candidate-script-disassembly.log`为实际DLL机器码。
- `*attempt*`及早期build/test日志：失败与驱动拒绝原因原样保留，不冒充有效资格。
- `final-audit.json`：204依赖、镜像/资产/安装头、未知修改保护复核；`qualified-source.patch`仅便于查看已提交源码变化。

固定提交下载入口在归档提交产生后登记；本ZIP只打包一次，不改写旧v4归档。
'''
(dest/'INDEX.zh-CN.md').write_text(index,encoding='utf-8')
print('PACKAGED',json.dumps(metadata),flush=True)
