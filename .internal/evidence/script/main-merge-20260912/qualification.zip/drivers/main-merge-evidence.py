from pathlib import Path
import hashlib, json, re, subprocess, zipfile

r = Path(__file__).parent
raw = r / 'main-merge-20260912'
source = r / 'integration-source'
q = r / 'local-source'
evidence = source / '.internal/evidence/script/main-merge-20260912'
evidence.mkdir(parents=True, exist_ok=True)

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

qualified = subprocess.check_output(['git','-C',str(q),'rev-parse','HEAD'], text=True).strip()
assert not subprocess.check_output(['git','-C',str(q),'status','--porcelain']).strip()
results = {}
for slot in ['t','d']:
    for phase in ['configure','build','noop','tests','install']:
        item = read(raw / f'candidate-{slot}-{phase}.json')
        assert item['exit'] == 0 and item['source'] == qualified and not item['status'], (slot,phase,item)
    log = (raw / f'candidate-{slot}-tests.log').read_text(encoding='utf-8-sig')
    total = int(re.search(r'100% tests passed, 0 tests failed out of (\d+)', log)[1])
    assert 'no work to do' in (raw / f'candidate-{slot}-noop.log').read_text(encoding='utf-8-sig')
    results[slot] = dict(passed=total, total=total, seconds=read(raw/f'candidate-{slot}-tests.json')['seconds'])

consumers = read(r/'main-merge-installed/consumers.json')
assert len(consumers) == 16 and all(x['status'] == 'PASS' for x in consumers)
value_incremental = read(r/'main-merge-value-incremental/probes.json')
assert len(value_incremental) == 13
assert all((x['exit'] == 0) == x['expected_success'] for x in value_incremental)
incremental = read(r/'main-merge-new-incremental/results.json')
assert len(incremental) == 5 and all(x['negative_rejected'] and x['restored_execution'] and x['restored_noop'] for x in incremental)
relocated = read(r/'main-merge-relocated/results.json')
assert len(relocated) == 3 and all(x['status'] == 'PASS' and x['source_commit'] == qualified for x in relocated)
vm = read(raw/'vm-tests.json')
assert vm['exit'] == 0 and vm['candidate'] == qualified
assert '100% tests passed, 0 tests failed out of 4' in (raw/'vm-tests.log').read_text(encoding='utf-8-sig')

artifacts = []
roots = [Path('E:/SyncForder/CodeRepos/install/o/na1/main-merge-sdk/bin'),
         Path('E:/SyncForder/CodeRepos/install/o/na1/main-merge-tools/bin')]
for root in roots:
    for p in sorted(root.glob('*')):
        if p.suffix.lower() in ['.dll','.exe','.pdb']:
            artifacts.append(dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p)))
for slot in ['d','t']:
    root = Path(f'E:/SyncForder/CodeRepos/build/RelWithDebInfo/o/w/{slot}/bin')
    for p in sorted(root.glob('*')):
        if p.suffix.lower() in ['.dll','.exe','.pdb'] and any(x in p.name.lower() for x in ['script','lua','flowforge','physics2d']):
            artifacts.append(dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p)))
for root in [r/'main-merge-installed', r/'main-merge-relocated']:
    for p in sorted(root.glob('*/build/*.exe')):
        artifacts.append(dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p)))
(raw/'artifacts.json').write_text(json.dumps(artifacts,indent=2))

files = []
for p in sorted(raw.glob('*')):
    if p.is_file() and p.suffix in ['.log','.json','.txt'] and not p.name.startswith(('original-main','dirty-replay')):
        files.append((p,'qualification/'+p.name))
for name in ['installed','value-incremental','new-incremental','relocated']:
    for p in sorted((r/f'main-merge-{name}').rglob('*')):
        if not p.is_file() or p.suffix not in ['.log','.json','.txt']:
            continue
        relative = p.relative_to(r/f'main-merge-{name}')
        # Keep explicit driver logs/manifests, not CMake's generated build/configuration trees or copied SDK.
        if any(x in relative.parts for x in ['build','source','sdk','tools','vm']):
            continue
        files.append((p,name+'/'+relative.as_posix()))
for p in sorted(r.glob('main-merge-*')):
    if p.is_file() and p.suffix in ['.ps1','.py']:
        files.append((p,'drivers/'+p.name))
archive = evidence / 'qualification.zip'
manifest = []
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p,name in files:
        z.write(p,name)
        manifest.append(dict(path=name,bytes=p.stat().st_size,sha256=sha(p)))
summary = dict(qualification_source=qualified, main_parent='f89e186216ca904055a6be7ffdccabaae3befff1',
    script_parent='70167bb3aaaa498cae682e5e1da502e64f6759d3', merge_commit='43d22937f50fdf6d9716d47dd97100cf13a05055',
    profiles=results, installed_consumers=consumers, value_incremental=value_incremental,
    task_incremental=incremental, relocated=relocated, vm_contracts=dict(passed=4,total=4,**vm),
    archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),files=len(manifest)),
    performance='Not rerun; e39535cf measurements and both unexplained Event regressions remain historical evidence.',
    unverified=['Android','Editor GUI/GPU qualification of this integration commit'])
(evidence/'result.json').write_text(json.dumps(summary,indent=2))
(evidence/'archive-files.json').write_text(json.dumps(manifest,indent=2))
(evidence/'artifacts.json').write_text(json.dumps(artifacts,indent=2))
(evidence/'qualification.zip.sha256').write_text(f'{sha(archive)}  qualification.zip\n')
(evidence/'.gitattributes').write_text('* -text -whitespace\n')
print(json.dumps(dict(source=qualified,profiles=results,consumers=len(consumers),archive=summary['archive']),indent=2))
