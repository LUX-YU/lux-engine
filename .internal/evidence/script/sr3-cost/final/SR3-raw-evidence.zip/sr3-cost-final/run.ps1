$ErrorActionPreference='Stop'
$base='E:/SyncForder/CodeRepos'
$repo="$base/lux-engine-sr3-cost-final"
$logs="$base/build/RelWithDebInfo/sr3-cost-final"
$python='C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
& "$repo/cmake/RunScriptV3Qualification.ps1" -SourceDir $repo -BuildRoot "$base/build/RelWithDebInfo/sr3-c3" -InstallRoot "$base/install/sr3-c3" -CxxPrefix "$base/install/q2/c" -ToolsetPrefix "$base/install/q2/toolset" -FoundationPrefix "$base/install/RelWithDebInfo" -Profiles toolchain,developer *> "$logs/qualification-driver.log"
$qualification=@(Get-Content "$base/build/RelWithDebInfo/sr3-c3/qualification.json" -Raw | ConvertFrom-Json)
if ($qualification.Count -ne 2 -or @($qualification | Where-Object status -eq 'BLOCKED').Count) { throw 'Qualification blocked' }
Write-Output 'Qualification finished; inspect six historical failures separately.'
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$env:LUX_FLOWFORGE_LINKER=Join-Path $env:VCToolsInstallDir 'bin/Hostx64/x64/link.exe'
& "$repo/cmake/RunScriptSR3Validation.ps1" -BaselineSource "$base/lux-engine-sr3-reference" -CandidateSource $repo -BaselineInstall "$base/install/sr3-reference" -CandidateInstall "$base/install/sr3-c3" -OutputRoot "$base/build/RelWithDebInfo/sr3-c3-checks" -Python $python -SkipMeasurements *> "$logs/validation-driver.log"
Write-Output 'Installed consumers, scale, traces, wire and allocation checks finished.'
Copy-Item -LiteralPath "$base/build/RelWithDebInfo/sr3-closeout/final-b0-b1" -Destination "$logs/final-b0-b1" -Recurse
foreach($pair in @(@('b1-b2','sr3-final','sr3-c3'),@('b0-b2','sr3-reference','sr3-c3'))) {
  & $python -B "$repo/cmake/RunScriptSR2Measurements.py" --baseline "$base/install/$($pair[1])" --candidate "$base/install/$($pair[2])" --output "$logs/final-$($pair[0])" --short-path-frames 3000 --affinity-mask 1 *> "$logs/$($pair[0])-driver.log"
  if($LASTEXITCODE -ne 0) { throw "Measurement failed $($pair[0])" }
  Write-Output "Measured $($pair[0])."
}
& $python -B "$repo/cmake/SummarizeScriptCost.py" --root $logs --output "$logs/cost-results.json" *> "$logs/cost-summary.log"
if($LASTEXITCODE -ne 0) { throw 'Work normalization failed' }
$common=@('--baseline-source',"$base/lux-engine-sr3-final",'--candidate-source',$repo,'--baseline-prefix',"$base/install/sr3-final/d",'--candidate-prefix',"$base/install/sr3-c3/d",'--dependencies',"$base/install/q2/toolset;$base/install/q2/c;$base/install/RelWithDebInfo")
& $python -B "$repo/cmake/RunScriptSR3Scale.py" @common --output "$logs/b1-b2-scale" *> "$logs/b1-b2-scale-driver.log"
if($LASTEXITCODE -ne 0) { throw 'Scale pair failed' }
& $python -B "$repo/cmake/RunScriptSR2Probes.py" @common --output "$logs/b1-b2-probes" *> "$logs/b1-b2-probes-driver.log"
if($LASTEXITCODE -ne 0) { throw 'Cold pair failed' }
Write-Output 'Final qualification and three-way checks completed.'
