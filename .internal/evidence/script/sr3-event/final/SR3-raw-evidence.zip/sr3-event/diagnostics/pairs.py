import argparse, csv, ctypes, hashlib, json, os, shutil, statistics, subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--frames',type=int,required=True);p.add_argument('--candidate-dll',required=True)
a=p.parse_args();out=Path(a.output);out.mkdir(parents=True,exist_ok=False);base=Path('E:/SyncForder/CodeRepos')
k=ctypes.windll.kernel32;k.GetCurrentProcess.restype=ctypes.c_void_p;k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
assert k.SetProcessAffinityMask(k.GetCurrentProcess(),1)
records=[]
for v,dll in [('b2',base/'install/sr3-c3/t/bin/lux_engine_simulation_script.dll'),('candidate',Path(a.candidate_dll))]:
 folder=out/v;folder.mkdir();shutil.copy2(dll,folder/dll.name)
 shutil.copy2(base/'build/RelWithDebInfo/sr3-c3/t/bin/flowforge_script_runtime_benchmark.exe',folder/'flowforge_script_runtime_benchmark.exe')
for pair in range(5):
 for v in (('b2','candidate') if pair%2==0 else ('candidate','b2')):
  exe=out/v/'flowforge_script_runtime_benchmark.exe';csvfile=out/f'{v}-{pair}.csv'
  command=[str(exe),'--group','scene-flowforge-event','--mode','performance','--size','10000','--warmups','60','--frames',str(a.frames),'--seed','1592598566','--resume-budget','2000','--output',str(csvfile)]
  env=dict(os.environ);env['PATH']=str(base/'install/sr3-c3/t/bin')+';D:/Development/vcpkg/installed/x64-windows/bin;'+env['PATH']
  with (out/f'{v}-{pair}.log').open('w') as log:subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  rows=list(csv.DictReader(csvfile.open()));assert len(rows)==a.frames
  assert all(int(r['calls'])==int(r['resumes'])==2000*(61+i) and int(r['queue_depth'])==8000 and int(r['started'])==10000+2000*(60+i) for i,r in enumerate(rows))
  records.append({'pair':pair,'variant':v,'frames':a.frames,'work':2000*a.frames,'backlog':8000,'total_ns':sum(int(r['nanoseconds']) for r in rows),'command':command,'dll_sha256':hashlib.sha256((exe.parent/'lux_engine_simulation_script.dll').read_bytes()).hexdigest(),'exe_sha256':hashlib.sha256(exe.read_bytes()).hexdigest()})
  (out/'runs.json').write_text(json.dumps(records,indent=2))
deltas=[]
for i in range(5):
 x,y=[next(r['total_ns'] for r in records if r['pair']==i and r['variant']==v) for v in ('b2','candidate')];deltas.append(100*(y/x-1))
print('paired_percent',deltas,'median',statistics.median(deltas))
