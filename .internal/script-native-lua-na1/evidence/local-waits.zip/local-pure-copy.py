from pathlib import Path
s=Path(r'E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1/source')
p=s/'engine/domain/simulation/scripting/core/include/lux/engine/simulation/scripting/ScriptEndpointBridge.hpp'
t=p.read_text().replace('    struct ScriptEventPayloadProjection final', '    template <class Route, class Payload> class ScriptEventEndpoint;\n\n    struct ScriptEventPayloadProjection final')
a=t.index('        lux::semantic::Layout owned_layout;');b=t.index('    };',a)
t=t[:a]+'''        using Copy = bool (*)(void*, const lux_script_value_slot&, std::span<std::byte>) noexcept;
        ScriptEventPayloadProjection() noexcept = default;
        ScriptEventPayloadProjection(lux::semantic::Layout layout, Copy projection) noexcept
            : owned_layout(layout), copy(projection) {}
        [[nodiscard]] bool mayReenter() const noexcept
        {
            return non_reentrant_copy_ == nullptr || copy != non_reentrant_copy_;
        }
        lux::semantic::Layout owned_layout;
        Copy copy{};
    private:
        template <class Route, class Payload> friend class ScriptEventEndpoint;
        // A callback identity proved by the typed endpoint factory. Replacing the
        // public copy callback invalidates this fact automatically.
        Copy non_reentrant_copy_{};
'''+t[b:]
a=t.index('            return {system_, id_, route,',t.index('class ScriptEventEndpoint final'))
t=t[:a]+'''            ScriptEventPayloadProjection projection{detail::eventPayloadLayout<Payload>(), copy};
            if constexpr (is_default_scalar_layout)
                if (payload_copy_ == detail::defaultEventPayloadCopy<Payload>())
                    projection.non_reentrant_copy_ = copy;
'''+t[a:]
t=t.replace('{detail::eventPayloadLayout<Payload>(), copy},\n                this', 'projection,\n                this')
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptExecution.hpp'
t=p.read_text().replace('        void completeClaimedEventWaiter(const ScriptClaimedEventWait& waiter, lux_script_call_frame& frame) noexcept', '        template <bool CopyMayReenter>\n        void completeClaimedEventWaiter(const ScriptClaimedEventWait& waiter, lux_script_call_frame& frame) noexcept')
pos=t.index('            ResultWritePin pin',t.index('        void completeClaimedEventWaiter'))
t=t[:pos]+'''            if constexpr (!CopyMayReenter)
            {
                // This specific typed copy function cannot execute user code.
                // Keep actual packet validation in that function; no ACTIVE state
                // or short-lived result borrow is carried across a user boundary.
                const bool valid_frame = frame.arg_count == 1U && frame.args != nullptr;
                const bool copied = valid_frame && endpoint.payload_projection.copy(
                    endpoint.context, frame.args[0], record->value.bytes.span());
                if (copied)
                {
                    event_payload_copy_bytes_ += record->value.bytes.size();
                    releaseSource(*record);
                    if (const auto completed = finishPreparedEvent(*record); completed) return;
                }
                // Preserve the old physical-capacity window while error cleanup
                // may reenter, even though the completed scalar copy needed no pin.
                ResultWritePin pin(*this, *record);
                static_cast<void>(eraseAwaitableRecord(*record, execution));
                faultInvocation(owner->mount_slot, lux::script::InvalidScriptSymbolId,
                    copied ? EScriptSystemError::RESUME_QUEUE_FULL : EScriptSystemError::INVOCATION_FAILURE);
                return;
            }
'''+t[pos:]
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/builtin/script/src/ScriptSystem.cpp'
t=p.read_text().replace('''                for (std::size_t index{}; index < claimed.size(); ++index)
                    owner.execution_owner.completeClaimedEventWaiter(claimed.at(index), frame);''','''                if (endpoint.payload_projection.mayReenter())
                {
                    for (std::size_t index{}; index < claimed.size(); ++index)
                        owner.execution_owner.completeClaimedEventWaiter<true>(claimed.at(index), frame);
                }
                else
                {
                    for (std::size_t index{}; index < claimed.size(); ++index)
                        owner.execution_owner.completeClaimedEventWaiter<false>(claimed.at(index), frame);
                }''')
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/builtin/script/test/script_system_event_wait_test.cpp'
t=p.read_text().replace('        assert(disabled.descriptor().payload_projection.copy == nullptr);', '''        assert(disabled.descriptor().payload_projection.copy == nullptr);
        assert(!builtin.descriptor().payload_projection.mayReenter());
        assert(custom.descriptor().payload_projection.mayReenter());
        auto replaced = builtin.descriptor().payload_projection;
        replaced.copy = custom.descriptor().payload_projection.copy;
        assert(replaced.mayReenter());''')
pos=t.index('    void testRepeatedWaitStorageReuse()')
t=t[:pos]+'''    void testDensePageCancellation()
    {
        HarnessOptions options;
        options.ownership_pair = true;
        options.limits.instance_capacity = 2U;
        options.limits.awaitable_capacity = 8U;
        options.limits.event_wait_capacity = 8U;
        Harness harness{options};
        auto start = [&](bool second, unsigned count) {
            for (unsigned i{}; i < count; ++i)
            {
                if (second) harness.recordBroadcastStartSecond(1);
                else harness.recordBroadcastStart(1);
            }
            auto& endpoint = second ? harness.broadcast_start_second_bridge : harness.broadcast_start_bridge;
            assert(deliverRuntimeEvent(*harness.system, endpoint) == count);
        };
        start(false, 1U);
        start(true, 4U);
        start(false, 3U);
        assert(harness.system->stats().active_event_waiters == 8U);
        const auto backing = harness.system->stats().event_page_storage_bytes;
        harness.backend_state.callback_action = ECallbackAction::FAIL;
        harness.recordBroadcastFaultSecond(1);
        assert(deliverRuntimeEvent(*harness.system, harness.broadcast_fault_second_bridge) == 1U);
        assert(harness.system->stats().active_event_waiters == 4U);
        start(false, 4U);
        assert(harness.system->stats().active_event_waiters == 8U);
        harness.recordBroadcastWait(101);
        assert(deliverRuntimeEvent(*harness.system, harness.broadcast_wait_bridge) == 1U);
        assert(executeRuntimeStablePoint(*harness.system));
        assert(harness.backend_state.resume_values == std::vector<std::int32_t>(8U, 101));
        assert(harness.backend_state.continuation_destroys == 12U);
        assert(harness.system->stats().active_event_waiters == 0U);
        assert(harness.system->stats().event_page_storage_bytes == backing);
    }

'''+t[pos:]
t=t.replace('    testRepeatedWaitStorageReuse();', '    testRepeatedWaitStorageReuse();\n    testDensePageCancellation();')
p.write_text(t,encoding='utf-8')
