& 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
& 'C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -B 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1/local-class-layout.py'
