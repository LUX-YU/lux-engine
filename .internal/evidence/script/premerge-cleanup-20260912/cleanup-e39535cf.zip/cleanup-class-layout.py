from pathlib import Path
import json,subprocess
r=Path(__file__).parent;out=r/'cleanup-class-layout';out.mkdir(exist_ok=False)
commands=json.loads((r.parent/'o/w/d/compile_commands.json').read_text(encoding='utf-8-sig'));results=[]
for name,types in [('CppStaticScriptBridge.cpp',['CppStaticScriptBackend','CoroutineContinuation','ScriptCoroutineContext','DescriptorIndex','Instance']),('LuaScriptBackend.cpp',['Impl','LuaContinuation','SyncInvocationRequest','Instance']),('ScriptSystem.cpp',['ScriptExecution','ExecutionInstance','ContinuationRecord','Wait','ScriptInstances','ScriptBindings'])]:
 rows=[x for x in commands if x['file'].replace('\\','/').endswith('/src/'+name)];assert len(rows)==1
 item=rows[0];command=item['command']+' /Zs /Z7 /d1reportAllClassLayout'
 with (out/(name+'.log')).open('wb') as f:code=subprocess.call(command,cwd=item['directory'],stdout=f,stderr=subprocess.STDOUT)
 results.append(dict(source=subprocess.check_output(['git','-C',str(r/'local-source'),'rev-parse','HEAD'],text=True).strip(),file=item['file'],command=command,exit=code,syntax_only=True))
 (out/'commands.json').write_text(json.dumps(results,indent=2));print('CURRENT_LAYOUT',name,code,flush=True)

