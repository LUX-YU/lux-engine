$ErrorActionPreference='Stop'
$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1'
$python='C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
function Child([string]$name,[string[]]$arguments){
 & pwsh -NoProfile -File "$r/$name.ps1" @arguments
 if($LASTEXITCODE){throw "Failed $name"}
}
Child 'next-installed' @()
Child 'next-new-incremental' @()
Child 'next-relocated' @('-Root',$r)
Child 'next-benchmark' @('-Side','B','-Label','next-bench')
& $python -B "$r/next-save-images.py"
if($LASTEXITCODE){throw 'Image capture failed'}
$vm='E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-lua55-s0-s1-20260909/dependencies/build-lua55'
$hash=(Get-FileHash "$vm/lux_lua55.dll").Hash
if($hash -ne (Get-FileHash 'E:/SyncForder/CodeRepos/install/o/v4/lua55/bin/lux_lua55.dll').Hash){throw 'VM identity mismatch'}
& ctest --test-dir $vm --output-on-failure -j 1 *> "$r/next-vm-tests.log"
$exitCode=$LASTEXITCODE
@{candidate=(git -C "$r/next-source" rev-parse HEAD).Trim();unchanged_vm_sha256=$hash;test_location=$vm;exit=$exitCode}|ConvertTo-Json|Set-Content "$r/next-vm-tests.json"
if($exitCode){throw 'VM tests failed'}
Child 'next-class-layout' @()
& $python -B "$r/next-machine.py"
if($LASTEXITCODE){throw 'Machine extraction failed'}
& $python -B "$r/next-costs.py"
if($LASTEXITCODE){throw 'Costs failed'}
& $python -B "$r/next-resources.py"
if($LASTEXITCODE){throw 'Resources failed'}
& $python -B "$r/next-profile.py"
if($LASTEXITCODE){throw 'Profile failed'}
Write-Output 'NEXT_POST_QUALIFICATION_COMPLETE'
