#pragma once
// Application-level routing, NOT part of the domain-blind editing core.
// Production: engine/editor/context/include/lux/engine/editor/ActiveEditHistory.hpp.
#include "EditHistoryTarget.contract.hpp"
#include <memory>
namespace lux::editor
{
    namespace detail { struct ActiveEditHistoryControl; }
    struct HistoryTargetHandle final
    {
        std::uint64_t router{}, registration{};
        [[nodiscard]] constexpr bool valid() const noexcept { return router != 0 && registration != 0; }
        friend bool operator==(const HistoryTargetHandle&, const HistoryTargetHandle&) noexcept = default;
    };
    class ActiveEditHistory;
    class HistoryTargetRegistration final
    {
    public:
        HistoryTargetRegistration() noexcept = default;
        ~HistoryTargetRegistration() noexcept;
        HistoryTargetRegistration(const HistoryTargetRegistration&) = delete;
        HistoryTargetRegistration& operator=(const HistoryTargetRegistration&) = delete;
        HistoryTargetRegistration(HistoryTargetRegistration&& other) noexcept;
        HistoryTargetRegistration& operator=(HistoryTargetRegistration&& other) noexcept;
        [[nodiscard]] HistoryTargetHandle handle() const noexcept;
        // BUSY/WRONG_THREAD failure retains the live registration.
        [[nodiscard]] editing::EditResult<void> reset() noexcept;
    private:
        friend class ActiveEditHistory;
        HistoryTargetRegistration(
            std::weak_ptr<detail::ActiveEditHistoryControl> control, HistoryTargetHandle handle) noexcept;
        std::weak_ptr<detail::ActiveEditHistoryControl> control_;
        HistoryTargetHandle handle_;
    };
    struct ActiveHistoryView final
    {
        HistoryTargetHandle handle;
        bool has_target{};
        editing::HistoryTargetView target;
    };
    class ActiveEditHistory final
    {
    public:
        using CreateResult = editing::EditResult<std::unique_ptr<ActiveEditHistory>>;
        [[nodiscard]] static CreateResult create(std::size_t target_capacity) noexcept;
        ~ActiveEditHistory() noexcept;
        ActiveEditHistory(const ActiveEditHistory&) = delete;
        ActiveEditHistory& operator=(const ActiveEditHistory&) = delete;
        ActiveEditHistory(ActiveEditHistory&&) = delete;
        ActiveEditHistory& operator=(ActiveEditHistory&&) = delete;
        [[nodiscard]] editing::EditResult<HistoryTargetRegistration>
        registerTarget(editing::EditHistoryTarget& target) noexcept;
        [[nodiscard]] editing::EditResult<void> activate(HistoryTargetHandle target) noexcept;
        [[nodiscard]] editing::EditResult<void> deactivate() noexcept;
        // Owner-thread value query; does not call into the target. Empty handle means no active target.
        [[nodiscard]] editing::EditResult<HistoryTargetHandle> activeTarget() const noexcept;
        [[nodiscard]] editing::EditResult<ActiveHistoryView> view() const noexcept;
        [[nodiscard]] editing::EditResult<editing::HistoryTargetResult> undo() noexcept;
        [[nodiscard]] editing::EditResult<editing::HistoryTargetResult> redo() noexcept;
        [[nodiscard]] editing::EditResult<void> close() noexcept;
    private:
        friend class HistoryTargetRegistration;
        struct Impl;
        explicit ActiveEditHistory(std::unique_ptr<Impl> impl) noexcept;
        [[nodiscard]] editing::EditResult<void> unregisterTarget(HistoryTargetHandle target) noexcept;
        std::unique_ptr<Impl> impl_;
    };
}
