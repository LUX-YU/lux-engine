from pathlib import Path
b=Path('E:/RenderV2Rebuild/Layer/source/modules/function/render')
# Neutral graph keys retain their exact representation.
p=b/'graph/include/lux/engine/render/graph/Graph.hpp';s=p.read_text();a=s.index('    inline constexpr auto kGraphInvalidIndex');z=s.index('    struct GraphBufferDesc',a);ids=s[a:z];s=s[:a]+s[z:];s=s.replace('#include <lux/engine/render/core/Target.hpp>','#include <lux/engine/render/core/Target.hpp>\n#include <lux/engine/render/core/Ids.hpp>');p.write_text(s)
p=b/'core/include/lux/engine/render/core/Ids.hpp';s=p.read_text().replace('#include <lux/cxx/container/SlotMap.hpp>','#include <lux/cxx/container/SlotMap.hpp>\n#include <limits>');s=s.replace('    struct SceneTag;',ids+'    struct SceneTag;');p.write_text(s)
# Shader interface and actual artifact are independent of Feature and Storage.
p=b/'resource/include/lux/engine/render/resource/Storage.hpp';s=p.read_text();a=s.index('    enum class EDescriptorKind');z=s.index('    struct StorageRequirement',a);binding=s[a:z];s=s[:a]+s[z:];a=s.index('    // Effect-owned');z=s.index('    // Static metadata',a);argument=s[a:z];s=s[:a]+s[z:];s=s.replace('#include <lux/engine/render/data/Wire.hpp>','#include <lux/engine/render/data/Wire.hpp>\n#include <lux/engine/render/data/ShaderInterface.hpp>');p.write_text(s)
p=b/'features/include/lux/engine/render/features/Program.hpp';s=p.read_text();a=s.index('    struct ShaderInterface');z=s.index('    // Cooked SPIR-V',a);interface=s[a:z];a=z;z=s.index('    // Cold compiler input',a);shader=s[a:z].replace('ShaderArtifact','SpirvArtifact');a=z;z=s.index('    [[nodiscard]] inline',a);program=s[a:z].replace('ShaderArtifact','SpirvArtifact').replace('        std::vector<StorageArgument> arguments;\n','');merge=s[z:s.rfind('}')];p.unlink()
(b/'data/include/lux/engine/render/data/ShaderInterface.hpp').write_text('#pragma once\n\n#include <cstdint>\n#include <vector>\n\nnamespace lux::render\n{\n'+binding+interface+'}\n')
(b/'data/include/lux/engine/render/data/Shader.hpp').write_text('#pragma once\n\n#include <lux/engine/render/data/ShaderInterface.hpp>\n\nnamespace lux::render\n{\n'+shader+'}\n')
(b/'graph/include/lux/engine/render/graph/Program.hpp').write_text('#pragma once\n\n#include <lux/engine/render/data/Shader.hpp>\n#include <array>\n#include <string>\n\nnamespace lux::render\n{\n'+program+'}\n')
p=b/'features/include/lux/engine/render/features/Resources.hpp';s=p.read_text();a=s.index('    struct ResolvedStorageBinding');z=s.index('    // resolved',a);bindings=s[a:z].replace('ResolvedStorageBinding','GraphStorageBinding');s=s[:a]+s[z:];s=s.replace('#include <lux/engine/render/resource/Storage.hpp>','#include <lux/engine/render/resource/Binding.hpp>');p.write_text(s)
(b/'resource/include/lux/engine/render/resource/Binding.hpp').write_text('#pragma once\n\n#include <lux/engine/render/resource/Storage.hpp>\n#include <lux/engine/render/core/Ids.hpp>\n\nnamespace lux::render\n{\n'+bindings+argument+'}\n')
# Only current implementation/consumer files; no historical report/checker changes.
for p in b.rglob('*'):
 if p.is_file() and p.suffix in ('.cpp','.hpp','.txt','.cmake','.md'):
  s=p.read_text();t=s.replace('lux/engine/render/features/Program.hpp','lux/engine/render/graph/Program.hpp').replace('ResolvedStorageBinding','GraphStorageBinding').replace('ShaderArtifact','SpirvArtifact')
  if p.parts[-1]=='DeviceSession.hpp':t=t.replace('lux/engine/render/features/Resources.hpp','lux/engine/render/resource/Binding.hpp')
  if t!=s:p.write_text(t)
# Neutral Program public contract adds only Data, never Feature/Resource or Native.
p=b/'graph/CMakeLists.txt';s=p.read_text().replace('component_add_internal_dependencies(render_graph lux::engine::render::render_core)','component_add_internal_dependencies(render_graph\n    lux::engine::render::render_core\n    lux::engine::render::render_data\n)');p.write_text(s)
for rel in ['graph/test/CMakeLists.txt','graph/test/installed/CMakeLists.txt']:
 p=b/rel;s=p.read_text().replace('STREQUAL "lux::engine::render::render_core"','STREQUAL "lux::engine::render::render_core;lux::engine::render::render_data"');p.write_text(s)
# ProgramContribution is returned by feature code; instance arguments never enter immutable shader identity.
p=b/'features/include/lux/engine/render/features/Registration.hpp';s=p.read_text().replace('namespace lux::render\n{','''namespace lux::render
{
    struct ProgramContribution final
    {
        std::vector<PassProgram> programs;
        std::vector<StorageArgument> arguments;
    };

''').replace('RenderResult<std::vector<PassProgram>> (*programs)','RenderResult<ProgramContribution> (*programs)');p.write_text(s)
# Store the old helper for explicit transformation in the next step, never as production compatibility.
Path('E:/RenderV2Rebuild/Layer/old-program-arguments.txt').write_text(merge)
