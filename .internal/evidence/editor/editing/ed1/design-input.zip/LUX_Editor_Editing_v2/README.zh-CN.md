# LUX Editor Editing 实施包 v2

2026-09-08。**这是实施规范和待实现接口，不是已完成代码。**

## 唯一边界

全部新设施在engine/editor。Editing只管理历史协议。Scene、文本、FlowForge、材质各自定义具体操作、模型和通知；不进入modules，不进入共享核心类型列表。

## 使用顺序

1. 阅读`LUX_Editor_Editing_Implementation_v2_2026-09-08.zh-CN.md`，其中含完整接口附录、算法和验收表。
2. 实施时按`implementation/ED-1_TASK.zh-CN.md`；默认只授权ED-1，不自动迁移所有业务。
3. `contracts/`是同一版本完整声明；`.contract.hpp`不是生产include名。生产路径已在文件注释中写明。
4. `verification/ACCEPTANCE.csv`逐项对照本轮ED-1；FUTURE为后续阶段，不能冒称已完成。
5. `sources/SOURCE_REGISTER.json`区分官方参考、固定源码和被撤回的旧设计。

## 重要纠正

旧v1的modules/function/undo、lux::undo、UndoHistory、UndoCommand、场景类型放Editing的方案不再执行。
本版是EditHistory/EditOperation，具体业务操作放各自业务。最新只读HEAD是0ceedbcdbc75f3b2be4b6be8d0b0cbfc6e0b8db7，接手时重新核对，不回退分支。

ED-1实际交付共享核心、应用级通用路由、两种独立测试业务、真实CommandRouter及安装消费者。
现有InspectorUndoJournal和GraphEditingSession未在本轮迁移；不在它们外面包新历史，不自动接入旧Editor的全局快捷键。

## 验证声明

本包生成时只做文件、引用、接口文本与归档一致性检查，未编译这些头、未链接Engine、未运行Editor或业务测试。
`MANIFEST.json`/`SHA256SUMS`用于本包完整性；它们不是工程通过证据。

主文档附录由contracts和任务/算法文件拼接生成；内容一致，不手工维护两个相互冲突版本。
完成ED-1后等待独立审阅，不自动进入ED-2、合并main、发布或重做脚本阶段。
