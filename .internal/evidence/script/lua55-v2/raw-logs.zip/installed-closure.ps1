$ErrorActionPreference='Stop'
$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/lua55-v2'
$source='E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-region-opt/final-source'
$sdk='E:/SyncForder/CodeRepos/install/o/v2/sdk'
$tools='E:/SyncForder/CodeRepos/install/o/v2/tools'
$prefixes="$sdk;$tools;E:/SyncForder/CodeRepos/install/o/v2/lua55;E:/SyncForder/CodeRepos/install/q2/toolset;E:/SyncForder/CodeRepos/install/q2/c"
$ignore='E:/SyncForder/CodeRepos/install/RelWithDebInfo;E:/SyncForder/CodeRepos/install/o/q/d;E:/SyncForder/CodeRepos/install/o/q/t;E:/SyncForder/CodeRepos/install/o/q/s1-lua55;E:/SyncForder/CodeRepos/install/o/q/s1-t'
$names=@('cpp-generated-script','physics2d-script','system-event-await-runtime','flowforge-compiler',
    'lua-script-packager','scene-script-runtime','script-ability-codegen','system-hook-script-binding',
    'cpp-coroutine-script','script-static-ability-specialization','script-ability-ipo','script-authoring',
    'script-runtime-input','script-description','script-lua-values')
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$d='E:/SyncForder/CodeRepos/build/RelWithDebInfo/o/w/d'
& cmake -S $source -B $d -DLUX_LUA_VM=LuaJIT *> "$r/legacy-selector-rejected.log"
$rejected=$LASTEXITCODE
try {
    if($rejected -eq 0 -or !(Select-String -LiteralPath "$r/legacy-selector-rejected.log" -SimpleMatch 'LUX_LUA_VM was removed' -Quiet)) {
        throw 'Removed selector was not rejected by the actual root configuration'
    }
    @{source=(git -C $source rev-parse HEAD);exit=$rejected;expected='root fatal diagnostic';selector='LuaJIT'} |
        ConvertTo-Json | Set-Content "$r/legacy-selector-rejected.json"
} finally {
    & cmake -S $source -B $d -ULUX_LUA_VM *> "$r/legacy-selector-restore.log"
    if($LASTEXITCODE) { throw 'Restore configure failed' }
}
& cmake --build 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-lua55-s0-s1-20260909/dependencies/build-lua55' --target all -j 4 -- -k 0 *> "$r/vm-final-noop.log"
if($LASTEXITCODE -or !(Select-String -LiteralPath "$r/vm-final-noop.log" -SimpleMatch 'no work to do' -Quiet)) { throw 'VM build not idle' }
& "$r/consumers-closure.ps1" -SourceDir $source -OutputRoot "$r/installed" `
    -PrefixPath $prefixes -DependencyRoot 'D:/Development/vcpkg/installed' -IgnorePrefixes $ignore -Names $names
if($LASTEXITCODE) { throw 'Consumer driver failed' }
$results=Get-Content -Raw -LiteralPath "$r/installed/closure-consumers.json" | ConvertFrom-Json
if($results.Count -ne $names.Count -or @($results | Where-Object status -ne 'PASS').Count) {
    throw 'Not every current SDK consumer passed'
}
Write-Output 'CLOSURE_CURRENT_SDK_15_PASS'
& "$r/relocated.ps1" -Root $r
if($LASTEXITCODE) { throw 'Relocation failed' }
