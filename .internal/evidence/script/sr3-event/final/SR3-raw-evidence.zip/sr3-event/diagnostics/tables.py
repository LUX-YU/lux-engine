import csv, json, statistics
from pathlib import Path
base=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo')
root=base/'sr3-event'
costs=json.loads((root/'cost-results.json').read_text())['comparisons']
summary={'state':'Finite hypotheses did not explain the remaining cost; no production runtime change retained.',
    'identities':{'B0':'8145598c18421d03da1dac21251200af3290e27d','B2':'99c1d095fad6a728c3d808ff2d853ce84b59bfea',
                  'B3_validation':'8a6e6ef468f7eb60265678ab25116719b42a01a6','lux_cxx':'3100f54d0743c5ed94a4ccf5943df04e933de255'},
    'production_delta_from_B2':False,'comparisons':[],'cold':[],'scale':[],'trials':[]}
lines=['| 场景 | B2→B3 中位 % [min,max] | B0→B3 |','|---|---:|---:|']
for case in sorted({r['case'] for r in costs}):
    row=[next(r for r in costs if r['case']==case and r['comparison']==c) for c in ('b2-b3','b0-b3')]
    lines.append('| '+case+' | '+' | '.join(f"{r['median_percent']:+.2f} [{r['range_percent'][0]:+.2f},{r['range_percent'][1]:+.2f}]" for r in row)+' |')
lines+=['','| 对照 / 场景 | 基线/候选批量中位 ms | 实际操作数 | 基线/候选 ns/操作 | 配对差中位 ms |','|---|---:|---:|---:|---:|']
for r in costs:
    key='resumes' if r['case'].endswith('event') or r['case']=='event-fanout' else 'script_calls'
    work=r['pairs'][0]['baseline']['effective_work']; count=work[key]
    a,b=r['median_baseline_ns'],r['median_candidate_ns']
    s={k:r[k] for k in ('comparison','case','median_percent','range_percent','median_baseline_ns','median_candidate_ns','median_delta_ns')}
    s.update(denominator=key, operations=count, baseline_ns_per_operation=a/count,candidate_ns_per_operation=b/count,
        effective_work=work, paired_percent=[p['percent'] for p in r['pairs']], paired_delta_ns=[p['delta_ns'] for p in r['pairs']],
        pairs=[{'pair':p['pair'],'baseline_ns':p['baseline']['total_ns'],'candidate_ns':p['candidate']['total_ns']} for p in r['pairs']])
    summary['comparisons'].append(s)
    lines.append(f"| {r['comparison']} / {r['case']} | {a/1e6:.4f} / {b/1e6:.4f} | {count:,} {key} | {a/count:.3f} / {b/count:.3f} | {r['median_delta_ns']/1e6:+.4f} |")
for comparison,directory in [('b0-b3',base/'sr3-e-checks/probes'),('b2-b3',root/'b2-b3-probes')]:
    pairs=[]
    for i in range(5):
        record={}
        for v in ('baseline','candidate'):
            raw=(directory/f'{v}-{i}.csv.log').read_text().splitlines()
            n=next(i for i,line in enumerate(raw) if line.startswith('prepare_ns,'))
            row=dict(zip(raw[n].split(','),map(int,raw[n+1].split(','))))
            assert [row[k] for k in ('creates','destroys','prepares','releases')]==[152,152,456,456]
            record[v]=row
        pairs.append(record)
    metrics={}
    for key in ('prepare_ns','late_ns','remount_128_ns'):
        ds=[100*(p['candidate'][key]/p['baseline'][key]-1) for p in pairs]
        metrics[key]={'baseline_ns':statistics.median(p['baseline'][key] for p in pairs),
            'candidate_ns':statistics.median(p['candidate'][key] for p in pairs),
            'paired_percent':ds,'median_percent':statistics.median(ds)}
    summary['cold'].append({'comparison':comparison,'metrics':metrics,'pairs':pairs})
lines+=['','| 冷期 | prepare ns | 7 项 late ns | 128 次 remount ns |','|---|---:|---:|---:|']
for c in summary['cold']:
    lines.append('| '+c['comparison']+' | '+' | '.join(f"{m['baseline_ns']:,.0f}→{m['candidate_ns']:,.0f} ({m['median_percent']:+.2f}%)" for m in c['metrics'].values())+' |')
lines+=['','| 128 次重建 | 配置/endpoint 数 | 基线/候选 ns | 配对中位 % [min,max] |','|---|---:|---:|---:|']
for comparison,directory in [('b0-b3',base/'sr3-e-checks/scale'),('b2-b3',root/'b2-b3-scale')]:
    records=json.loads((directory/'runs.json').read_text());assert len(records)==24
    for count in (8,8192):
        a,b=[[r for r in records if r['variant']==v and r['configs']==count and not r['diagnostics']] for v in ('baseline','candidate')]
        assert len(a)==len(b)==5
        assert all(r['errors']==r['backlog']==0 and r['creates']==r['destroys']==count+144 and r['ticks']==count for r in a+b)
        ds=[100*(y['elapsed_ns']/x['elapsed_ns']-1) for x,y in zip(a,b)]
        m1,m2=statistics.median(r['elapsed_ns'] for r in a),statistics.median(r['elapsed_ns'] for r in b)
        summary['scale'].append({'comparison':comparison,'configs':count,'baseline_ns':m1,'candidate_ns':m2,'paired_percent':ds,'records':a+b,
            'diagnostics':[r for r in records if r['configs']==count and r['diagnostics']]})
        lines.append(f'| {comparison} | {count:,} | {m1:,} / {m2:,} | {statistics.median(ds):+.2f} [{min(ds):+.2f},{max(ds):+.2f}] |')
for name in ('gate-300','gate-3000','resume-3000'):
    records=json.loads((root/f'diagnostics/{name}/runs.json').read_text());pairs=[]
    for i in range(5):
        a,b=[next(r for r in records if r['pair']==i and r['variant']==v) for v in ('b2','candidate')]
        assert a['work']==b['work'] and a['backlog']==b['backlog']==8000
        pairs.append({'pair':i,'baseline_ns':a['total_ns'],'candidate_ns':b['total_ns'],
            'percent':100*(b['total_ns']/a['total_ns']-1),'delta_ns':b['total_ns']-a['total_ns']})
    summary['trials'].append({'name':name,'retained':False,'pairs':pairs,'median_percent':statistics.median(p['percent'] for p in pairs)})
summary['final_counts']=json.loads((root/'diagnostics/final-counts/results.json').read_text())
summary['invalid_trials']=json.loads((root/'diagnostics/invalid-trials.json').read_text())
summary['limits']=['Whole-frame cost per resume is amortized, not isolated resume latency.',
    'Clock frequency and background load were not controlled. Process pairs are the statistical units.',
    'Legacy errors/failures remain null. Flow observer reports retained failures outside timing, not a new total-error ABI.',
    'Private branch counters are separate and their timing is invalid. EXE-local new is not all-DLL heap accounting.']
(root/'diagnostics/detailed-summary.json').write_text(json.dumps(summary,indent=2))
compact=dict(summary)
compact['cold']=[{k:v for k,v in r.items() if k!='pairs'} for r in summary['cold']]
compact['scale']=[{k:v for k,v in r.items() if k!='records'} for r in summary['scale']]
compact['final_counts']={k:summary['final_counts'][k] for k in ('delta','after','final','limitation')}
(root/'one-page.json').write_text(json.dumps(compact,indent=2))
with (root/'one-page.csv').open('w',newline='') as f:
    fields=['comparison','case','median_baseline_ns','median_candidate_ns','median_delta_ns','denominator','operations',
            'baseline_ns_per_operation','candidate_ns_per_operation','median_percent','range_percent','paired_percent','paired_delta_ns']
    w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(summary['comparisons'])
(root/'performance-tables.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print('\n'.join(lines))
