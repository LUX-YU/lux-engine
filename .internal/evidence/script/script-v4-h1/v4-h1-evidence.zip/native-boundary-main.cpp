// Appended to the existing Native backend fixture's helpers, against actual A/B DLLs.
#include <Windows.h>
#include <cstring>
#include <cstdlib>

int main(int argc, char** argv)
{
    using namespace lux::simulation::script;
    assert(argc == 3);
    const int mode = std::atoi(argv[2]);
    auto loaded = lux::script::loadNativeModule(std::filesystem::path{argv[1]});
    assert(loaded);
    auto module = std::make_shared<lux::script::NativeModule>(std::move(*loaded));
    const auto library = LoadLibraryA(argv[1]);
    const auto count = reinterpret_cast<unsigned (*)(unsigned)>(GetProcAddress(library, "lux_h1_count"));
    assert(count);
    Provider provider{{module, module}};
    auto owned = std::make_unique<NativeScriptBackend>(NativeModuleResolver{&provider, &Provider::resolve},
        NativeScriptBackendConfig{
        .module_capacity = 1U, .instance_capacity = 1U, .prepared_call_capacity = 1U, .continuation_capacity = 1U,
        .max_ability_imports_per_module = 1U,
        .max_continuation_frame_bytes = 256U, .continuation_frame_storage_bytes = 5120U,
        .storage_populations = std::array{NativeScriptStoragePopulation{module.get(), 1U, 1U}},
        .state_storage_bytes = 65536U, .observe_storage = true});
    auto& backend = *owned;
    assert(backend);
    lux::script::ScriptEventSourceDescription event{"H1", "Payload", 11U, 12U,
        lux::script::EScriptEventRoute::SIMULATION_BROADCAST,
        {"lux.u32", lux::semantic::typeId("lux.u32"), LUX_SCRIPT_VK_UINT32, 4U, 4U}, 13U, 1U, 14U, 15U, 1U};
    const PreparedScriptEventAdmission admission{&event};
    lux::rdesc::Script description;
    description.module_name = "h1_boundary";
    description.body = lux::rdesc::NativeModuleScript{LUX_SCRIPT_ABI_VERSION, module->stateLayoutHash(),
        module->stateSize(), module->stateAlignment(), {}};
    const lux::rdesc::ScriptFunction function{"Step", 1U, {}, {}};
    description.exports = {function}; description.event_requirements = {event};
    auto artifact = lux::script::ScriptArtifact::create(std::move(description), {});
    assert(artifact);
    std::array<std::uint8_t, 16> bytes{}; bytes[0] = 1U;
    auto descriptor = backend.descriptor(); ScriptBackendInstance instance;
    assert(descriptor.createInstance(descriptor.context, ScriptInstanceCreateContext{
        lux::asset::AssetId{bytes}, SimulationScriptScope{}, nullptr, {1U, 1U}, {}, std::span{&admission, 1U}},
        *artifact, instance) == EScriptBackendResult::SUCCESS);
    ScriptBackendPreparedMethod method;
    assert(descriptor.prepareMethod(descriptor.context, instance, function, method) == EScriptBackendResult::SUCCESS);
    unsigned waits{};
    ScriptStepContext context{{1U, 1U}, &waits, nullptr, nullptr,
        [](void* opaque, ScriptInstanceId, ScriptEventAdmissionHandle) noexcept
            -> lux::cxx::expected<ScriptAwaitableId, EScriptEventWaitError> {
            ++*static_cast<unsigned*>(opaque); return ScriptAwaitableId{1U, 1U}; }};
    lux_script_call_frame frame{}; ScriptBackendContinuation continuation;
    const auto started = method.resumable.invoke(method.resumable.context, frame, context, continuation);
    if (mode == 0)
    {
        assert(started.state == EScriptStepState::SUSPENDED && continuation && waits == 1U);
        ScriptOwnedResumeValue value;
        value.type = {lux::semantic::typeId("lux.u32"), LUX_SCRIPT_VK_UINT32, 4U, 4U};
        assert(value.bytes.resize(4U)); const std::uint32_t expected = 29U;
        std::memcpy(value.bytes.data(), &expected, sizeof(expected));
        const auto valid_type = value.type;
        for (unsigned which{}; which < 6U; ++which)
        {
            value.type = valid_type; assert(value.bytes.resize(4U));
            std::memcpy(value.bytes.data(), &expected, sizeof(expected));
            if (which == 0) value.type.type_id = lux::semantic::typeId("lux.i32");
            if (which == 1) value.type.abi_kind = LUX_SCRIPT_VK_INT32;
            if (which == 2) value.type.size = 8U;
            if (which == 3) value.type.alignment = 8U;
            if (which == 4) assert(value.bytes.resize(3U));
            const ScriptResumePacket packet{{1U, 1U}, EScriptAwaitableState::READY,
                which == 5 ? nullptr : &value, {}};
            const auto rejected = continuation.resume(continuation.state, context, packet);
            assert(rejected.state == EScriptStepState::FAILED && rejected.error.status == -1);
            assert(count(1) == 0U && count(2) == 0U && backend.stats().active_frames == 1U);
            std::printf("NATIVE_PACKET_REJECT,case=%u,resumes=0,frame_retained=1\n", which);
        }
        value.type = valid_type; assert(value.bytes.resize(4U));
        std::memcpy(value.bytes.data(), &expected, sizeof(expected));
        const ScriptResumePacket packet{{1U, 1U}, EScriptAwaitableState::READY, &value, {}};
        assert(continuation.resume(continuation.state, context, packet).state == EScriptStepState::COMPLETED);
        assert(count(1) == 1U); continuation.destroy(continuation.state);
    }
    else
    {
        const int error = mode == 3 ? 73 : mode == 6 ? -71 : -1;
        assert(started.state == EScriptStepState::FAILED && started.error.status == error);
        assert(!continuation && waits == 0U && count(1) == 0U);
    }
    assert(count(0) == 1U && count(2) == 1U && backend.stats().active_frames == 0U);
    descriptor.releaseMethod(descriptor.context, instance, method);
    descriptor.destroyInstance(descriptor.context, instance);
    assert(backend.stats().active_states == 0U && count(2) == 1U);
    owned.reset();
    assert(provider.resolves == 1U && provider.releases == 1U);
    std::printf("NATIVE_BOUNDARY,case=%d,start=1,resume=%u,destroy=1,waits=%u,lease_release=1\n",
        mode, count(1), waits);
    FreeLibrary(library);
}
