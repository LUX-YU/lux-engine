# P03 复审 R1 交付包

入口：[REVIEW_AND_INSTRUCTIONS.md](REVIEW_AND_INSTRUCTIONS.md)。

结论：P03 主体进展成立，但私有重载准备的提前拒绝分支有一处输入所有权缺口，先定向补正，再复审是否进入 P04。

本包没有修改 GitHub 仓库，不包含完整引擎构建或 CTest 的独立重跑结果。

`probes/` 为独立 C++20 控制流探针：不需要 Lux SDK，不加载 DLL，不执行 Material 图算法。Clang 17/GCC 14.2 的 O0/O2 输出已保存。正向例子仅说明局部拥有与清理作用域如何改变结果，并非已提交的产品补丁。

运行：

```sh
python3 probes/run_reduced_probe.py
```

退出 0 表示探针完成，原形状的失败被观察到，说明性对照满足探针中的目标契约；不代表原产品验收通过。请阅读 `results.json` 中每个场景的 `safe_under_target_contract`，不要只看脚本退出码。

真实模型的四组回归与文件修改清单在主文档第 5—7 节，必须由实施方在实际仓库中完成。
