from pathlib import Path
import json,re,subprocess,hashlib

root=Path('E:/RenderV2Rebuild/Layer')
evidence=root/'evidence/L4'
baseline=set(json.loads((root/'evidence/L0/test-names.json').read_text()))
results={}
for variant in ('r','d','a'):
    folder=evidence/variant
    logs=list(folder.glob('test-*.log'))
    assert len(logs)==1,(variant,logs)
    raw=logs[0].read_bytes()
    assert b'\0' not in raw
    text=raw.decode('utf-8-sig',errors='replace')
    assert '100% tests passed, 0 tests failed out of 102' in text,variant
    assert 'EXIT=0' in text,variant
    for bad in ('ERROR: AddressSanitizer','Validation Error:','SYNC-HAZARD-'):
        assert bad not in text,(variant,bad)
    names=re.findall(r'^\s*\d+/102 Test\s+#\d+:\s+(\S+)\s+\.+\s+Passed',text,re.M)
    assert len(names)==102,(variant,len(names))
    assert baseline.issubset(names),(variant,baseline-set(names))
    builds=sorted(folder.glob('build-*.log'))
    assert len(builds)==2 and 'ninja: no work to do' in builds[-1].read_text()
    assert all('EXIT=0' in p.read_text() for p in builds)
    warnings=sorted(set(line for line in text.splitlines() if re.search(r'warning|EOS',line,re.I)))
    results[variant]=dict(tests=102,original_names_retained=len(baseline),added=sorted(set(names)-baseline),
        test_seconds=float(re.findall(r'Total Test time \(real\) = ([\d.]+)',text)[-1]),
        complete_stdout_sha256=hashlib.sha256(raw).hexdigest(),warnings=warnings,
        second_build_no_work=True,validation_errors=0,sync_validation_errors=0,
        asan_errors=0 if variant=='a' else 'NOT_APPLICABLE',names=names)
source=root/'v/src'
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain']).strip()
assert not (source/'.git/objects/info/alternates').exists()
(evidence/'matrix-summary.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({k:{x:y for x,y in v.items() if x not in ('names','warnings')} for k,v in results.items()},indent=2))
