import csv,json,re,statistics
from pathlib import Path
r=Path('..').resolve()
def record(path,prefix):
 lines=path.read_text().splitlines(); return next(csv.DictReader(lines[lines.index(next(l for l in lines if l.startswith(prefix))):]))
report={}
for folder,prefix,keys,units in [('probes','prepare_ns,',['prepare_ns','late_ns','remount_128_ns'],[1,1,128]),('scale-replay','configs,',['elapsed_ns'],[128])]:
 groups=[8,8192] if folder=='scale-replay' else [None]
 for group in groups:
  cases=[]
  for i in range(5):
   name=f'{group}-{i}' if group else str(i)
   a=record(r/folder/f'baseline-{name}.csv.log',prefix); b=record(r/folder/f'candidate-{name}.csv.log',prefix)
   for k in a:
    if k not in keys and k not in ('allocation_accounting',): assert a[k]==b[k],(folder,k,a,b)
   if group: assert b['errors']=='0' and b['backlog']=='0' and int(b['rebuilds'])==128
   else: assert b['creates']==b['destroys']=='152' and b['prepares']==b['releases']=='456'
   cases.append({'pair':i,'baseline':a,'candidate':b})
  report[f'{folder}-{group}']={'pairs':cases,'costs':{k:{'baseline_batch_ns':statistics.median(int(p['baseline'][k]) for p in cases),'candidate_batch_ns':statistics.median(int(p['candidate'][k]) for p in cases),'candidate_ns_per_operation':statistics.median(int(p['candidate'][k]) for p in cases)/u,'paired_percent':[100*(int(p['candidate'][k])/int(p['baseline'][k])-1) for p in cases]} for k,u in zip(keys,units)}}
def row(path,tag):
 text=path.read_text(); m=re.search(tag+r' ([^\n]+)',text); assert m
 return {k:int(v) for k,v in re.findall(r'(\w+)=([0-9]+)',m[1])}
f=r/'value-costs-valid'; pairs=[]
for i in range(5):
 a=row(f/f'baseline-{i}.log','VALUE_PUSH');b=row(f/f'candidate-{i}.log','VALUE_PUSH')
 for v in (a,b): assert v['count']==100000 and v['errors']==v['backlog']==0 and v['diagnostics']==0
 pairs.append({'pair':i,'baseline':a,'candidate':b,'percent':100*(b['ns']/a['ns']-1),'ns_per_push_delta':(b['ns']-a['ns'])/100000})
report['isolated-record-push']={'pairs':pairs,'diagnostics':{v:row(f/f'{v}-diagnostics.log','VALUE_PUSH') for v in ['baseline','candidate']},'allocation_scope':'Disabled timing counters are unavailable, not evidence of zero allocations; diagnostic counts cover the Lua allocator only.'}
report['typed-runtime']=[row(f/f'typed-runtime-{i}.log','VALUE_BENCH') for i in range(5)]
for x in report['typed-runtime']: assert x['count']==x['operations']==100000 and x['errors']==x['backlog']==0 and x['vm_accounting']==0
report['typed-runtime-allocations']=row(f/'typed-runtime-allocations.log','VALUE_BENCH')
(r/'diagnostics/cold-and-value-costs.json').write_text(json.dumps(report,indent=2))
for k,v in report.items():
 if 'costs' in v: print(k,v['costs'])
print('record push ns',statistics.median(x['baseline']['ns']/100000 for x in pairs),statistics.median(x['candidate']['ns']/100000 for x in pairs),'pairs',[round(x['percent'],2) for x in pairs])
print('typed ns',statistics.median(x['ns']/100000 for x in report['typed-runtime']))
print('diagnostics',report['isolated-record-push']['diagnostics'],report['typed-runtime-allocations'])
