from pathlib import Path
p=Path(__file__).parent/'source/engine/domain/simulation/builtin/script/test/script_system_continuation_test.cpp'
t=p.read_text()
t=t.replace('        bool simulation_timer{};','        bool simulation_timer{};\n        bool real_timer{};')
t=t.replace('const SimulationClock* clock_override = nullptr) noexcept','const SimulationClock* clock_override = nullptr, ScriptRealDelayEndpoint real_delay = {}) noexcept')
old='                large_bridge ? std::span{&large_endpoint, 1U} : std::span<const ScriptEventEndpointDescriptor>{}\n'
assert t.count(old)==1
t=t.replace(old,old.rstrip()+',\n                {}, real_delay\n')
t=t.replace('auto started = state.simulation_timer\n                        ?', 'auto started = state.real_timer ? state.delay->realSeconds(state.timer_seconds, completion) :\n                        state.simulation_timer\n                        ?')
at=t.index('    void testLocalTimerCapacityAndReuse()')
t=t[:at]+'''    void testTimerRoundingAndDeadline()
    {
        for (const bool local : {false, true})
        for (const bool overflow : {false, true})
        {
            Harness harness{false};
            lux::simulation::script::test::ScriptTestClock clock{harness.registry};
            configureTimerHarness(harness);
            auto& backend = harness.backend_state;
            backend.local_timer = local;
            backend.simulation_timer = true;
            backend.timer_seconds = overflow ? std::nextafter(std::ldexp(1.0, 63) / 1e9, 0.0) : 1.1e-9;
            if (overflow) clock.advance(SimulationDuration{1'000'000'000});
            auto system = harness.create(limits(), {}, true, &clock.clock());
            assert(system && system->prepare() && dispatchRuntimeHook(*system, harness.hook) == 1U);
            if (overflow)
            {
                assert(system->stats().simulation_delay_waits == 0U && system->failures().size() == 1U);
                assert(system->failures().front().status == static_cast<int>(EScriptDelayStatus::DURATION_OVERFLOW));
            }
            else
            {
                clock.advance(SimulationDuration{1});
                assert(executeRuntimeStablePoint(*system));
                assert(backend.resume_calls == 0U && system->stats().simulation_delay_waits == 1U);
                clock.advance(SimulationDuration{1});
                assert(executeRuntimeStablePoint(*system));
                assert(backend.resume_calls == 1U && system->stats().simulation_delay_waits == 0U);
                assert(system->failures().empty());
            }
            assert(system->shutdown() && backend.creates == 1U && backend.destroys == 1U);
            assert(backend.continuation_destroys == static_cast<std::size_t>(!overflow));
            std::printf("TIMER_ROUNDING local=%u overflow=%u resumes=%zu PASS\\n", local, overflow, backend.resume_calls);
        }
    }

    void testRealTimerDurationBoundary()
    {
        const double boundary = std::ldexp(1.0, 63) / 1e9;
        for (const bool accepted : {true, false})
        {
            Harness harness{false};
            configureTimerHarness(harness);
            auto& backend = harness.backend_state;
            backend.real_timer = true;
            backend.timer_seconds = accepted ? std::nextafter(boundary, 0.0) : boundary;
            struct Probe final
            {
                std::size_t calls{};
                std::chrono::nanoseconds duration{};
                lux::script::ScriptAbilityCompletion<void> completion;
            } probe;
            const ScriptRealDelayEndpoint endpoint{&probe,
                [](void* context, std::chrono::nanoseconds duration,
                   lux::script::ScriptAbilityCompletion<void> completion) noexcept -> lux::script::ScriptAbilityStartResult {
                    auto& probe = *static_cast<Probe*>(context);
                    ++probe.calls;
                    probe.duration = duration;
                    probe.completion = std::move(completion);
                    return {};
                }};
            auto system = harness.create(limits(), {}, true, nullptr, endpoint);
            assert(system && system->prepare() && dispatchRuntimeHook(*system, harness.hook) == 1U);
            assert(probe.calls == static_cast<std::size_t>(accepted));
            assert(system->activeAwaitableCount() == static_cast<std::size_t>(accepted));
            if (accepted) assert(probe.duration.count() > 0 && probe.completion.active());
            else assert(system->failures().front().status == static_cast<int>(EScriptDelayStatus::DURATION_OVERFLOW));
            assert(system->shutdown() && !probe.completion.active());
            assert(backend.continuation_destroys == static_cast<std::size_t>(accepted));
            assert(backend.creates == 1U && backend.destroys == 1U);
            std::printf("REAL_TIMER_BOUNDARY accept=%u endpoint_calls=%zu late_active=0 PASS\\n", accepted, probe.calls);
        }
    }

'''+t[at:]
t=t.replace('    testTimerDurationBoundaries();','    testTimerDurationBoundaries();\n    testTimerRoundingAndDeadline();\n    testRealTimerDurationBoundary();')
p.write_text(t)
