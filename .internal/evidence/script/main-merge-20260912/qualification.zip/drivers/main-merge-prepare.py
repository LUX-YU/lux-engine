from pathlib import Path
import hashlib, json, subprocess

r = Path(__file__).parent
out = r / 'main-merge-20260912'
source = r / 'integration-source'
main = Path('E:/SyncForder/CodeRepos/lux-engine')

def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args])

def sha(data):
    return hashlib.sha256(data).hexdigest()

identity = json.loads((r / 'source/.internal/evidence/script/premerge-cleanup-20260912/identity.json').read_text())
dependencies = []
for entry in identity['dependencies']:
    actual = sha(Path(entry['path']).read_bytes())
    if actual.lower() != entry['sha256'].lower():
        raise RuntimeError(f"Dependency changed: {entry['path']}")
    dependencies.append(dict(path=entry['path'], sha256=actual))
(out / 'fixed-dependencies.json').write_text(json.dumps(dependencies, indent=2))

records = json.loads((out / 'original-main-files.json').read_text(encoding='utf-8-sig'))
for entry in records:
    if sha((main / entry['path']).read_bytes()).lower() != entry['sha256'].lower():
        raise RuntimeError(f"Original work changed during merge: {entry['path']}")

prepared = out / 'replayed-main-edits'
prepared.mkdir(exist_ok=True)
changes = {
    'engine/domain/simulation/builtin/script/include/lux/engine/simulation/ScriptSystem.hpp': (
        '            ScriptRealDelayEndpoint real_delay = {}) noexcept;',
        '            ScriptRealDelayEndpoint real_delay = {}\n        ) noexcept;'),
    'engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptExecution.hpp': (
        '        [[nodiscard]] lux::cxx::expected<ScriptAwaitableId, EScriptAwaitableCreateError> createAwaitableRecord(',
        '        [[nodiscard]] lux::cxx::expected<ScriptAwaitableId, EScriptAwaitableCreateError> \n        createAwaitableRecord(')
}
replays = []
for path, (before, after) in changes.items():
    # The original changes in these two headers must remain formatting-only.
    original_base = git(main, 'show', 'HEAD:' + path).decode()
    assert ''.join(original_base.split()) == ''.join((main / path).read_text().split()), path
    content = git(source, 'show', 'HEAD:' + path).decode()
    assert content.count(before) == 1, path
    result = content.replace(before, after)
    assert ''.join(content.split()) == ''.join(result.split()), path
    destination = prepared / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    old_bytes = (main / path).read_bytes()
    newline = '\r\n' if b'\r\n' in old_bytes else '\n'
    destination.write_bytes(result.replace('\n', newline).encode())
    replays.append(dict(path=path, method='reapply original formatting to current signature',
                        original_sha256=sha(old_bytes), replay_sha256=sha(destination.read_bytes()),
                        non_whitespace_tokens_match_candidate=True))
(out / 'dirty-replay-plan.json').write_text(json.dumps(replays, indent=2))
print(f'Fixed dependencies: {len(dependencies)} unchanged; original edits: {len(records)} unchanged; replay: {len(replays)} prepared')
