$ErrorActionPreference='Stop'
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/s6'
$root="$r/relocation"
$installed='E:/SyncForder/CodeRepos/install/s6/q'
if(Test-Path -LiteralPath $root){throw 'Fresh relocation root required'}
New-Item -ItemType Directory -Path "$root/sdk" -Force | Out-Null
Copy-Item -LiteralPath "$r/candidate-source/cmake/installed-consumers/script-lua-values" -Destination "$root/source" -Recurse
Copy-Item -LiteralPath "$installed/d" -Destination "$root/sdk/d" -Recurse
Copy-Item -LiteralPath "$installed/t" -Destination "$root/sdk/t" -Recurse
$moved=[System.Collections.Generic.List[object]]::new()
function Hide-Current([string]$path){
 $resolved=(Resolve-Path -LiteralPath $path).Path
 $allowedBuild=[IO.Path]::GetFullPath($r)+[IO.Path]::DirectorySeparatorChar
 $allowedInstall=[IO.Path]::GetFullPath('E:/SyncForder/CodeRepos/install/s6')+[IO.Path]::DirectorySeparatorChar
 if(!$resolved.StartsWith($allowedBuild,[StringComparison]::OrdinalIgnoreCase) -and !$resolved.StartsWith($allowedInstall,[StringComparison]::OrdinalIgnoreCase)){throw "Outside task directories: $resolved"}
 $off="$resolved-offline"
 if(Test-Path -LiteralPath $off){throw "Occupied offline path: $off"}
 Move-Item -LiteralPath $resolved -Destination $off
 $moved.Add(@{original=$resolved;offline=$off})
}
try {
 Hide-Current "$r/candidate-source"
 Hide-Current "$r/q"
 Hide-Current $installed
 $prefix="$root/sdk/d;$root/sdk/t;E:/SyncForder/CodeRepos/install/q2/c;E:/SyncForder/CodeRepos/install/q2/toolset"
 $ignored="E:/SyncForder/CodeRepos/install/s5;E:/SyncForder/CodeRepos/install/s5c;E:/SyncForder/CodeRepos/install/RelWithDebInfo;$installed;$r/candidate-source;$r/q"
 $env:PATH=(@($prefix.Split(';') | ForEach-Object {"$_/bin"})+@('D:/Development/vcpkg/installed/x64-windows/bin')+@($env:PATH.Split(';') | Where-Object {$_ -notmatch 'CodeRepos[/\\](install|build)' -and $_ -notmatch 'vcpkg[/\\]installed'})) -join ';'
 cmake -S "$root/source" -B "$root/build" -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DCMAKE_TOOLCHAIN_FILE=D:/Development/vcpkg/scripts/buildsystems/vcpkg.cmake "-DCMAKE_PREFIX_PATH=$prefix" "-DCMAKE_IGNORE_PREFIX_PATH=$ignored" -DCMAKE_FIND_USE_PACKAGE_REGISTRY=OFF -DCMAKE_FIND_USE_SYSTEM_PACKAGE_REGISTRY=OFF -DCMAKE_FIND_USE_CMAKE_ENVIRONMENT_PATH=OFF *> "$root/configure.log"
 if($LASTEXITCODE){throw 'Relocation configure failed'}
 cmake --build "$root/build" --target all -j 4 -- -k 0 *> "$root/all.log"
 if($LASTEXITCODE){throw 'Relocation build failed; no old EXE run'}
 & "$root/build/lux_script_lua_values_consumer.exe" *> "$root/run.log"
 if($LASTEXITCODE){throw 'Relocation execution failed'}
 cmake --build "$root/build" --target all -j 4 -- -k 0 *> "$root/noop.log"
 if($LASTEXITCODE -or !(Select-String -LiteralPath "$root/noop.log" -SimpleMatch 'no work to do' -Quiet)){throw 'Relocation not no-op'}
 $business=Get-Content -LiteralPath "$root/run.log" -Raw
 if($business -notmatch 'INSTALLED_RUNTIME legal=2 rejected=2 begin=1 end=1 provider_ctor=1 provider_dtor=1 lease=1 release=1 backlog=0 PASS'){throw 'Missing business closure'}
 $cache=Get-Content -LiteralPath "$root/build/CMakeCache.txt"
 $engineDirs=@($cache | Where-Object {$_ -match '^lux-engine.*_DIR:PATH='})
 if(!$engineDirs.Count){throw 'Missing actual package identities'}
 foreach($line in $engineDirs){if(!$line.Contains("$root/sdk/")){throw "Old Engine package: $line"}}
 $consumed=@(Get-Content -LiteralPath "$root/build/build.ninja" | Where-Object {$_ -match 'INCLUDES =|LINK_LIBRARIES =|COMMAND ='}) -join "`n"
 foreach($old in @('install/s5/','install/s5c/','install/RelWithDebInfo','install/s6/q','s6/candidate-source','s6/q/','s5/source','s5c/candidate-source')){
  if($consumed.Replace('\','/').Contains($old)){throw "Old consumed path: $old"}
 }
 $record=@{result='PASS';source_commit='7b5e1dd4';original_paths_hidden=@($moved);engine_package_directories=$engineDirs;prefixes=$prefix;excluded=$ignored;exe_sha256=(Get-FileHash "$root/build/lux_script_lua_values_consumer.exe").Hash;original_foundation_sdk_excluded=$true;runtime_only_public_consumer=$true}
 $record | ConvertTo-Json -Depth 6 | Set-Content "$root/relocation.json"
} finally {
 for($i=$moved.Count-1;$i -ge 0;--$i){
  $entry=$moved[$i]
  if(Test-Path -LiteralPath $entry.original){throw "Cannot restore occupied path: $($entry.original)"}
  Move-Item -LiteralPath $entry.offline -Destination $entry.original
 }
}
