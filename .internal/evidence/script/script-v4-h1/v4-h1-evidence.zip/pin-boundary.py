"""Run new negative assertions on fixed V4 DLLs and candidate DLLs with matching headers."""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,time
r=Path(__file__).parent;source=r.parent/'script-cell-a1/source';build=r.parent/'o/w/d';v4=r.parent/'script-v4'
out=r/'pin-boundary';out.mkdir(exist_ok=False)
baseline='f7d2815bdd2025ee23a7c11449def822413f58e9'
header='engine/domain/simulation/scripting/core/include/lux/engine/simulation/scripting/detail/BoundedClassStorage.hpp'
tests={'simulation_script_event_wait_test': str(r/'pin-boundary-test.cpp')}
traces={};records=[]
for side in ['A','B']:
    folder=out/side;folder.mkdir();inc=folder/'include'
    hp=inc/('lux/'+header.split('/lux/')[1]);hp.parent.mkdir(parents=True)
    revision=baseline if side=='A' else subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
    hp.write_bytes(subprocess.check_output(['git','-C',str(source),'show',revision+':'+header]))
    image=v4/'final-image' if side=='A' else build/'bin'
    for p in image.glob('*.dll'):shutil.copy2(p,folder/p.name)
    env=dict(os.environ);env['PATH']=';'.join([str(folder),'D:/Development/vcpkg/installed/x64-windows/bin',
        *[p for p in env['PATH'].split(';') if 'CodeRepos' not in p and 'vcpkg' not in p]])
    for name,path in tests.items():
        commands=subprocess.check_output(['ninja','-C',str(build),'-t','commands',name],text=True).splitlines()
        compile=next(x for x in commands if (' /c ' in x or ' -c ' in x) and name+'.dir' in x and '.cpp' in x)
        obj=folder/(name+'.obj');old_obj=re.search(r'/Fo(\S+)',compile)[1]
        compile=compile.replace(' /nologo ',f' /nologo /I{inc} /I{source / "engine/domain/simulation/builtin/script/test"} ',1)
        compile=re.sub(r'/Fo\S+',lambda m:'/Fo'+str(obj),compile)
        compile=re.sub(r'/Fd\S+',lambda m:'/Fd'+str(folder/(name+'.pdb')),compile)
        compile=re.sub(r' [/-]c .*$',lambda m:' /c '+str(source/path),compile)
        link=next(x for x in reversed(commands) if 'vs_link_exe' in x and '/out:bin\\'+name+'.exe' in x).split(' -- ',1)[1].split(' && ',1)[0]
        link=link.replace(old_obj,str(obj)).replace('/out:bin\\'+name+'.exe','/out:'+str(folder/(name+'.exe')))
        link=link.replace('/pdb:bin\\'+name+'.pdb','/pdb:'+str(folder/(name+'-link.pdb')))
        link=link.replace('/implib:lib\\'+name+'.lib','/implib:'+str(folder/(name+'.lib')))
        for stage,cmd in [('compile',compile),('link',link),('run',[str(folder/(name+'.exe'))])]:
            log=folder/(name+'-'+stage+'.log');start=time.monotonic()
            with log.open('wb') as f:code=subprocess.call(cmd,cwd=build,env=env,stdout=f,stderr=subprocess.STDOUT)
            test_source=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
            records.append(dict(side=side,test=name,stage=stage,source=revision,test_source=test_source,command=cmd,exit=code,seconds=time.monotonic()-start,
                test_sha256=hashlib.sha256((source/path).read_bytes()).hexdigest()))
            (out/'runs.json').write_text(json.dumps(records,indent=2))
            print(side,name,stage,code,flush=True)
            if code:raise SystemExit('CONTRACT_ATTEMPT_FAILED')
        lines=[x for x in log.read_text().splitlines() if x.startswith(('PIN_PHYSICAL_BOUNDARY,',))]
        assert len(lines)=={'simulation_script_event_wait_test':1}[name],lines
        traces[side,name]=lines
for name in tests:assert traces['A',name]==traces['B',name],name
(out/'result.json').write_text(json.dumps(dict(equal=True,traces={name:traces['A',name] for name in tests}),indent=2))
print('PIN_A_B_PASS_1_TRACE',flush=True)
