Microsoft (R) COFF/PE Dumper Version 14.44.35228.0
Copyright (C) Microsoft Corporation.  All rights reserved.


Dump of file E:\SyncForder\CodeRepos\build\RelWithDebInfo\s5c\q\d\bin\lux_engine_function_script_lua.dll

File Type: DLL

  0000000180001000: int         3
  0000000180001001: int         3
  0000000180001002: int         3
  0000000180001003: int         3
  0000000180001004: int         3
@ILT+0(?value@?$unexpected@ULuaValueFailure@lua@script@lux@@@tl@@QEGAAAEAULuaValueFailure@lua@script@lux@@XZ):
  0000000180001005: jmp         ?value@?$unexpected@ULuaValueFailure@lua@script@lux@@@tl@@QEGAAAEAULuaValueFailure@lua@script@lux@@XZ
@ILT+5(_DllMainCRTStartup):
  000000018000100A: jmp         _DllMainCRTStartup
@ILT+10(__scrt_exe_initialize_mta):
  000000018000100F: jmp         __scrt_exe_initialize_mta
@ILT+15(?setOnError@ScriptEngine@lua@script@lux@@QEAAXV?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@4@@Z):
  0000000180001014: jmp         ?setOnError@ScriptEngine@lua@script@lux@@QEAAXV?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@4@@Z
@ILT+20(__local_stdio_printf_options):
  0000000180001019: jmp         __local_stdio_printf_options
@ILT+25(_guard_check_icall_nop):
  000000018000101E: jmp         _guard_check_icall_nop
@ILT+30(??2@YAPEAX_K@Z):
  0000000180001023: jmp         ??2@YAPEAX_K@Z
@ILT+35(??$forward@V?$basic_string_view@DU?$char_traits@D@std@@@std@@@std@@YA$$QEAV?$basic_string_view@DU?$char_traits@D@std@@@0@AEAV10@@Z):
  0000000180001028: jmp         ??$forward@V?$basic_string_view@DU?$char_traits@D@std@@@std@@@std@@YA$$QEAV?$basic_string_view@DU?$char_traits@D@std@@@0@AEAV10@@Z
@ILT+40(??1?$_Deleted_copy_assign@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@XZ):
  000000018000102D: jmp         ??1?$_Deleted_copy_assign@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@XZ
@ILT+45(?data@?$basic_string_view@DU?$char_traits@D@std@@@std@@QEBAPEBDXZ):
  0000000180001032: jmp         ?data@?$basic_string_view@DU?$char_traits@D@std@@@std@@QEBAPEBDXZ
@ILT+50(__scrt_dllmain_before_initialize_c):
  0000000180001037: jmp         __scrt_dllmain_before_initialize_c
@ILT+55(__local_stdio_scanf_options):
  000000018000103C: jmp         __local_stdio_scanf_options
@ILT+60(?reset@?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@QEAAXXZ):
  0000000180001041: jmp         ?reset@?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@QEAAXXZ
@ILT+65(?shape@LuaValueAccess@detail@lua@script@lux@@SA?AV?$expected@XULuaValueFailure@lua@script@lux@@@tl@@PEAUlua_State@@HV?$span@$$CBV?$basic_string_view@DU?$char_traits@D@std@@@std@@$0?0@std@@@Z):
  0000000180001046: jmp         ?shape@LuaValueAccess@detail@lua@script@lux@@SA?AV?$expected@XULuaValueFailure@lua@script@lux@@@tl@@PEAUlua_State@@HV?$span@$$CBV?$basic_string_view@DU?$char_traits@D@std@@@std@@$0?0@std@@@Z
@ILT+70(__acrt_thread_detach):
  000000018000104B: jmp         __acrt_thread_detach
@ILT+75(__report_gsfailure):
  0000000180001050: jmp         __report_gsfailure
@ILT+80(?_Unchecked_begin@?$basic_string_view@DU?$char_traits@D@std@@@std@@QEBAPEBDXZ):
  0000000180001055: jmp         ?_Unchecked_begin@?$basic_string_view@DU?$char_traits@D@std@@@std@@QEBAPEBDXZ
@ILT+85(ReadNoFence64):
  000000018000105A: jmp         ReadNoFence64
@ILT+90(?what@exception@std@@UEBAPEBDXZ):
  000000018000105F: jmp         ?what@exception@std@@UEBAPEBDXZ
@ILT+95(??$?0ULuaValueFailure@lua@script@lux@@$0A@@?$expected_copy_base@XULuaValueFailure@lua@script@lux@@$00$00@detail@tl@@QEAA@Uunexpect_t@2@$$QEAULuaValueFailure@lua@script@lux@@@Z):
  0000000180001064: jmp         ??$?0ULuaValueFailure@lua@script@lux@@$0A@@?$expected_copy_base@XULuaValueFailure@lua@script@lux@@$00$00@detail@tl@@QEAA@Uunexpect_t@2@$$QEAULuaValueFailure@lua@script@lux@@@Z
@ILT+100(??0?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@QEAA@XZ):
  0000000180001069: jmp         ??0?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@QEAA@XZ
@ILT+105(??1?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@QEAA@XZ):
  000000018000106E: jmp         ??1?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@QEAA@XZ
@ILT+110(?_Unchecked_end@?$basic_string_view@DU?$char_traits@D@std@@@std@@QEBAPEBDXZ):
  0000000180001073: jmp         ?_Unchecked_end@?$basic_string_view@DU?$char_traits@D@std@@@std@@QEBAPEBDXZ
@ILT+115(__acrt_initialize):
  0000000180001078: jmp         __acrt_initialize
@ILT+120(__scrt_stub_for_is_c_termination_complete):
  000000018000107D: jmp         __scrt_stub_for_is_c_termination_complete
@ILT+125(??0bad_alloc@std@@QEAA@AEBV01@@Z):
  0000000180001082: jmp         ??0bad_alloc@std@@QEAA@AEBV01@@Z
@ILT+130(??C?$unique_ptr@VScriptEngineImpl@lua@script@lux@@U?$default_delete@VScriptEngineImpl@lua@script@lux@@@std@@@std@@QEBAPEAVScriptEngineImpl@lua@script@lux@@XZ):
  0000000180001087: jmp         ??C?$unique_ptr@VScriptEngineImpl@lua@script@lux@@U?$default_delete@VScriptEngineImpl@lua@script@lux@@@std@@@std@@QEBAPEAVScriptEngineImpl@lua@script@lux@@XZ
@ILT+135(??0?$expected_storage_base@XULuaValueFailure@lua@script@lux@@$0A@$00@detail@tl@@QEAA@XZ):
  000000018000108C: jmp         ??0?$expected_storage_base@XULuaValueFailure@lua@script@lux@@$0A@$00@detail@tl@@QEAA@XZ
@ILT+140(?runScript@ScriptEngineImpl@lua@script@lux@@QEAA_NAEBVScriptRef@234@@Z):
  0000000180001091: jmp         ?runScript@ScriptEngineImpl@lua@script@lux@@QEAA_NAEBVScriptRef@234@@Z
@ILT+145(??1?$_Optional_destruct_base@VScriptRef@lua@script@lux@@$0A@@std@@QEAA@XZ):
  0000000180001096: jmp         ??1?$_Optional_destruct_base@VScriptRef@lua@script@lux@@$0A@@std@@QEAA@XZ
@ILT+150(?pushLuaGlobalEnvironment@detail@lua@script@lux@@YAXPEAUlua_State@@@Z):
  000000018000109B: jmp         ?pushLuaGlobalEnvironment@detail@lua@script@lux@@YAXPEAUlua_State@@@Z
@ILT+155(_guard_xfg_dispatch_icall_nop):
  00000001800010A0: jmp         _guard_xfg_dispatch_icall_nop
@ILT+160(_onexit):
  00000001800010A5: jmp         _onexit
@ILT+165(??_Etype_info@@UEAAPEAXI@Z):
  00000001800010AA: jmp         ??_Etype_info@@UEAAPEAXI@Z
@ILT+170(?luaTraceback@ScriptEngineImpl@lua@script@lux@@CAHPEAUlua_State@@@Z):
  00000001800010AF: jmp         ?luaTraceback@ScriptEngineImpl@lua@script@lux@@CAHPEAUlua_State@@@Z
@ILT+175(??0?$_Optional_construct_base@H@std@@QEAA@XZ):
  00000001800010B4: jmp         ??0?$_Optional_construct_base@H@std@@QEAA@XZ
@ILT+180(?__scrt_initialize_type_info@@YAXXZ):
  00000001800010B9: jmp         ?__scrt_initialize_type_info@@YAXXZ
@ILT+185(??0bad_alloc@std@@AEAA@QEBD@Z):
  00000001800010BE: jmp         ??0bad_alloc@std@@AEAA@QEBD@Z
@ILT+190(??$?0AEAULuaValueFailure@lua@script@lux@@$0A@@?$unexpected@ULuaValueFailure@lua@script@lux@@@tl@@QEAA@AEAULuaValueFailure@lua@script@lux@@@Z):
  00000001800010C3: jmp         ??$?0AEAULuaValueFailure@lua@script@lux@@$0A@@?$unexpected@ULuaValueFailure@lua@script@lux@@@tl@@QEAA@AEAULuaValueFailure@lua@script@lux@@@Z
@ILT+195(??B?$optional@H@std@@QEBA_NXZ):
  00000001800010C8: jmp         ??B?$optional@H@std@@QEBA_NXZ
@ILT+200(__acrt_uninitialize):
  00000001800010CD: jmp         __acrt_uninitialize
@ILT+205(__castguard_slow_path_check_nop):
  00000001800010D2: jmp         __castguard_slow_path_check_nop
@ILT+210(__castguard_slow_path_check_user_handled):
  00000001800010D7: jmp         __castguard_slow_path_check_user_handled
@ILT+215(_guard_dispatch_icall_nop):
  00000001800010DC: jmp         _guard_dispatch_icall_nop
@ILT+220(??$forward@AEAPEAVScriptEngineImpl@lua@script@lux@@@std@@YAAEAPEAVScriptEngineImpl@lua@script@lux@@AEAPEAV1234@@Z):
  00000001800010E1: jmp         ??$forward@AEAPEAVScriptEngineImpl@lua@script@lux@@@std@@YAAEAPEAVScriptEngineImpl@lua@script@lux@@AEAPEAV1234@@Z
@ILT+225(__GSHandlerCheckCommon):
  00000001800010E6: jmp         __GSHandlerCheckCommon
@ILT+230(__acrt_thread_attach):
  00000001800010EB: jmp         __acrt_thread_attach
@ILT+235(??1exception@std@@UEAA@XZ):
  00000001800010F0: jmp         ??1exception@std@@UEAA@XZ
@ILT+240(?state@ScriptEngineImpl@lua@script@lux@@QEBAPEAUlua_State@@XZ):
  00000001800010F5: jmp         ?state@ScriptEngineImpl@lua@script@lux@@QEBAPEAUlua_State@@XZ
@ILT+245(__scrt_initialize_onexit_tables):
  00000001800010FA: jmp         __scrt_initialize_onexit_tables
@ILT+250(??0Storage@?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@QEAA@XZ):
  00000001800010FF: jmp         ??0Storage@?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@QEAA@XZ
@ILT+255(??_GScriptRef@lua@script@lux@@QEAAPEAXI@Z):
  0000000180001104: jmp         ??_GScriptRef@lua@script@lux@@QEAAPEAXI@Z
@ILT+260(?size@?$basic_string_view@DU?$char_traits@D@std@@@std@@QEBA_KXZ):
  0000000180001109: jmp         ?size@?$basic_string_view@DU?$char_traits@D@std@@@std@@QEBA_KXZ
@ILT+265(__report_securityfailure):
  000000018000110E: jmp         __report_securityfailure
@ILT+270(__acrt_uninitialize_critical):
  0000000180001113: jmp         __acrt_uninitialize_critical
@ILT+275(??$?0ULuaValueFailure@lua@script@lux@@$0A@@?$expected_move_assign_base@XULuaValueFailure@lua@script@lux@@$00@detail@tl@@QEAA@Uunexpect_t@2@$$QEAULuaValueFailure@lua@script@lux@@@Z):
  0000000180001118: jmp         ??$?0ULuaValueFailure@lua@script@lux@@$0A@@?$expected_move_assign_base@XULuaValueFailure@lua@script@lux@@$00@detail@tl@@QEAA@Uunexpect_t@2@$$QEAULuaValueFailure@lua@script@lux@@@Z
@ILT+280(__scrt_unhandled_exception_filter):
  000000018000111D: jmp         __scrt_unhandled_exception_filter
@ILT+285(__castguard_check_failure_user_handled):
  0000000180001122: jmp         __castguard_check_failure_user_handled
@ILT+290(?__scrt_throw_std_bad_alloc@@YAXXZ):
  0000000180001127: jmp         ?__scrt_throw_std_bad_alloc@@YAXXZ
@ILT+295(??0ScriptRef@lua@script@lux@@QEAA@$$QEAV0123@@Z):
  000000018000112C: jmp         ??0ScriptRef@lua@script@lux@@QEAA@$$QEAV0123@@Z
@ILT+300(??0?$_Span_extent_type@$$CBV?$basic_string_view@DU?$char_traits@D@std@@@std@@$0?0@std@@QEAA@XZ):
  0000000180001131: jmp         ??0?$_Span_extent_type@$$CBV?$basic_string_view@DU?$char_traits@D@std@@@std@@$0?0@std@@QEAA@XZ
@ILT+305(??0?$expected_copy_assign_base@XULuaValueFailure@lua@script@lux@@$00$00@detail@tl@@QEAA@XZ):
  0000000180001136: jmp         ??0?$expected_copy_assign_base@XULuaValueFailure@lua@script@lux@@$00$00@detail@tl@@QEAA@XZ
@ILT+310(__scrt_exe_initialize_mta):
  000000018000113B: jmp         __scrt_exe_initialize_mta
@ILT+315(_guard_icall_checks_enforced):
  0000000180001140: jmp         _guard_icall_checks_enforced
@ILT+320(??$?0VScriptRef@lua@script@lux@@@?$_Deleted_copy@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@@std@@QEAA@Uin_place_t@1@$$QEAVScriptRef@lua@script@lux@@@Z):
  0000000180001145: jmp         ??$?0VScriptRef@lua@script@lux@@@?$_Deleted_copy@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@@std@@QEAA@Uin_place_t@1@$$QEAVScriptRef@lua@script@lux@@@Z
@ILT+325(??0ScriptEngineImpl@lua@script@lux@@QEAA@XZ):
  000000018000114A: jmp         ??0ScriptEngineImpl@lua@script@lux@@QEAA@XZ
@ILT+330(??$?0H$0A@@?$optional@H@std@@QEAA@$$QEAH@Z):
  000000018000114F: jmp         ??$?0H$0A@@?$optional@H@std@@QEAA@$$QEAH@Z
@ILT+335(?length@?$_Narrow_char_traits@DH@std@@SA_KQEBD@Z):
  0000000180001154: jmp         ?length@?$_Narrow_char_traits@DH@std@@SA_KQEBD@Z
@ILT+340(??0ScriptEngine@lua@script@lux@@QEAA@XZ):
  0000000180001159: jmp         ??0ScriptEngine@lua@script@lux@@QEAA@XZ
@ILT+345(?_Unchecked_begin@?$span@$$CBV?$basic_string_view@DU?$char_traits@D@std@@@std@@$0?0@std@@QEBAPEBV?$basic_string_view@DU?$char_traits@D@std@@@2@XZ):
  000000018000115E: jmp         ?_Unchecked_begin@?$span@$$CBV?$basic_string_view@DU?$char_traits@D@std@@@std@@$0?0@std@@QEBAPEBV?$basic_string_view@DU?$char_traits@D@std@@@2@XZ
@ILT+350(__castguard_check_failure_debugbreak):
  0000000180001163: jmp         __castguard_check_failure_debugbreak
@ILT+355(?boolean@LuaValueAccess@detail@lua@script@lux@@SA_NPEAUlua_State@@HAEA_N@Z):
  0000000180001168: jmp         ?boolean@LuaValueAccess@detail@lua@script@lux@@SA_NPEAUlua_State@@HAEA_N@Z
@ILT+360(??0?$span@$$CBV?$basic_string_view@DU?$char_traits@D@std@@@std@@$0?0@std@@QEAA@XZ):
  000000018000116D: jmp         ??0?$span@$$CBV?$basic_string_view@DU?$char_traits@D@std@@@std@@$0?0@std@@QEAA@XZ
@ILT+365(?initialize_environment@__scrt_narrow_environment_policy@@SAHXZ):
  0000000180001172: jmp         ?initialize_environment@__scrt_narrow_environment_policy@@SAHXZ
@ILT+370(??$move@AEAULuaValueFailure@lua@script@lux@@@std@@YA$$QEAULuaValueFailure@lua@script@lux@@AEAU1234@@Z):
  0000000180001177: jmp         ??$move@AEAULuaValueFailure@lua@script@lux@@@std@@YA$$QEAULuaValueFailure@lua@script@lux@@AEAU1234@@Z
@ILT+375(??0ScriptRef@lua@script@lux@@QEAA@HPEAVScriptEngine@123@@Z):
  000000018000117C: jmp         ??0ScriptRef@lua@script@lux@@QEAA@HPEAVScriptEngine@123@@Z
@ILT+380(??_Ebad_array_new_length@std@@UEAAPEAXI@Z):
  0000000180001181: jmp         ??_Ebad_array_new_length@std@@UEAAPEAXI@Z
@ILT+385(__scrt_uninitialize_crt):
  0000000180001186: jmp         __scrt_uninitialize_crt
@ILT+390(__scrt_is_ucrt_dll_in_use):
  000000018000118B: jmp         __scrt_is_ucrt_dll_in_use
@ILT+395(??$?0VScriptRef@lua@script@lux@@@?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@QEAA@Uin_place_t@1@$$QEAVScriptRef@lua@script@lux@@@Z):
  0000000180001190: jmp         ??$?0VScriptRef@lua@script@lux@@@?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@QEAA@Uin_place_t@1@$$QEAVScriptRef@lua@script@lux@@@Z
@ILT+400(??_Etype_info@@UEAAPEAXI@Z):
  0000000180001195: jmp         ??_Etype_info@@UEAAPEAXI@Z
@ILT+405(__scrt_is_nonwritable_in_current_image):
  000000018000119A: jmp         __scrt_is_nonwritable_in_current_image
@ILT+410(??$forward@ULuaValueFailure@lua@script@lux@@@std@@YA$$QEAULuaValueFailure@lua@script@lux@@AEAU1234@@Z):
  000000018000119F: jmp         ??$forward@ULuaValueFailure@lua@script@lux@@@std@@YA$$QEAULuaValueFailure@lua@script@lux@@AEAU1234@@Z
@ILT+415(atexit):
  00000001800011A4: jmp         atexit
@ILT+420(__GSHandlerCheck):
  00000001800011A9: jmp         __GSHandlerCheck
@ILT+425(?parseScript@ScriptEngineImpl@lua@script@lux@@QEAA?AV?$optional@H@std@@V?$basic_string_view@DU?$char_traits@D@std@@@6@@Z):
  00000001800011AE: jmp         ?parseScript@ScriptEngineImpl@lua@script@lux@@QEAA?AV?$optional@H@std@@V?$basic_string_view@DU?$char_traits@D@std@@@6@@Z
@ILT+430(__acrt_thread_detach):
  00000001800011B3: jmp         __acrt_thread_detach
@ILT+435(??0?$basic_string_view@DU?$char_traits@D@std@@@std@@QEAA@QEBD@Z):
  00000001800011B8: jmp         ??0?$basic_string_view@DU?$char_traits@D@std@@@std@@QEAA@QEBD@Z
@ILT+440(??R?$default_delete@VScriptEngineImpl@lua@script@lux@@@std@@QEBAXPEAVScriptEngineImpl@lua@script@lux@@@Z):
  00000001800011BD: jmp         ??R?$default_delete@VScriptEngineImpl@lua@script@lux@@@std@@QEBAXPEAVScriptEngineImpl@lua@script@lux@@@Z
@ILT+445(?yieldLuaInvocation@detail@lua@script@lux@@YAHPEAUlua_State@@H@Z):
  00000001800011C2: jmp         ?yieldLuaInvocation@detail@lua@script@lux@@YAHPEAUlua_State@@H@Z
@ILT+450(ReadPointerNoFence):
  00000001800011C7: jmp         ReadPointerNoFence
@ILT+455(??0bad_array_new_length@std@@QEAA@AEBV01@@Z):
  00000001800011CC: jmp         ??0bad_array_new_length@std@@QEAA@AEBV01@@Z
@ILT+460(?ref@ScriptRef@lua@script@lux@@QEBAHXZ):
  00000001800011D1: jmp         ?ref@ScriptRef@lua@script@lux@@QEBAHXZ
@ILT+465(??1?$optional@VScriptRef@lua@script@lux@@@std@@QEAA@XZ):
  00000001800011D6: jmp         ??1?$optional@VScriptRef@lua@script@lux@@@std@@QEAA@XZ
@ILT+470(??0?$unexpected@ULuaValueFailure@lua@script@lux@@@tl@@QEAA@$$QEAULuaValueFailure@lua@script@lux@@@Z):
  00000001800011DB: jmp         ??0?$unexpected@ULuaValueFailure@lua@script@lux@@@tl@@QEAA@$$QEAULuaValueFailure@lua@script@lux@@@Z
@ILT+475(?state@ScriptEngine@lua@script@lux@@QEAAPEAUlua_State@@XZ):
  00000001800011E0: jmp         ?state@ScriptEngine@lua@script@lux@@QEAAPEAUlua_State@@XZ
@ILT+480(??0?$optional@VScriptRef@lua@script@lux@@@std@@QEAA@Unullopt_t@1@@Z):
  00000001800011E5: jmp         ??0?$optional@VScriptRef@lua@script@lux@@@std@@QEAA@Unullopt_t@1@@Z
@ILT+485(__acrt_uninitialize):
  00000001800011EA: jmp         __acrt_uninitialize
@ILT+490(??4LuaValueAccess@detail@lua@script@lux@@QEAAAEAV01234@$$QEAV01234@@Z):
  00000001800011EF: jmp         ??4LuaValueAccess@detail@lua@script@lux@@QEAAAEAV01234@$$QEAV01234@@Z
@ILT+495(__acrt_uninitialize_critical):
  00000001800011F4: jmp         __acrt_uninitialize_critical
@ILT+500(??0?$_Deleted_copy@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@@std@@QEAA@XZ):
  00000001800011F9: jmp         ??0?$_Deleted_copy@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@@std@@QEAA@XZ
@ILT+505(__acrt_thread_attach):
  00000001800011FE: jmp         __acrt_thread_attach
@ILT+510(??1ScriptEngineImpl@lua@script@lux@@QEAA@XZ):
  0000000180001203: jmp         ??1ScriptEngineImpl@lua@script@lux@@QEAA@XZ
@ILT+515(??1ScriptEngine@lua@script@lux@@QEAA@XZ):
  0000000180001208: jmp         ??1ScriptEngine@lua@script@lux@@QEAA@XZ
@ILT+520(at_quick_exit):
  000000018000120D: jmp         at_quick_exit
@ILT+525(__security_check_cookie):
  0000000180001212: jmp         __security_check_cookie
@ILT+530(DllMain):
  0000000180001217: jmp         DllMain
@ILT+535(??D?$_Optional_construct_base@H@std@@QEGAAAEAHXZ):
  000000018000121C: jmp         ??D?$_Optional_construct_base@H@std@@QEGAAAEAHXZ
@ILT+540(??_GScriptEngineImpl@lua@script@lux@@QEAAPEAXI@Z):
  0000000180001221: jmp         ??_GScriptEngineImpl@lua@script@lux@@QEAAPEAXI@Z
@ILT+545(?absolute@LuaValueAccess@detail@lua@script@lux@@SAHPEAUlua_State@@H@Z):
  0000000180001226: jmp         ?absolute@LuaValueAccess@detail@lua@script@lux@@SAHPEAUlua_State@@H@Z
@ILT+550(??$forward@AEAULuaValueFailure@lua@script@lux@@@std@@YAAEAULuaValueFailure@lua@script@lux@@AEAU1234@@Z):
  000000018000122B: jmp         ??$forward@AEAULuaValueFailure@lua@script@lux@@@std@@YAAEAULuaValueFailure@lua@script@lux@@AEAU1234@@Z
@ILT+555(??0?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@QEAA@XZ):
  0000000180001230: jmp         ??0?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@QEAA@XZ
@ILT+560(__castguard_slow_path_check_fastfail):
  0000000180001235: jmp         __castguard_slow_path_check_fastfail
@ILT+565(?size@?$array@D$0BAA@@std@@QEBA_KXZ):
  000000018000123A: jmp         ?size@?$array@D$0BAA@@std@@QEBA_KXZ
@ILT+570(??$?0ULuaValueFailure@lua@script@lux@@$0A@@?$expected_operations_base@XULuaValueFailure@lua@script@lux@@@detail@tl@@QEAA@Uunexpect_t@2@$$QEAULuaValueFailure@lua@script@lux@@@Z):
  000000018000123F: jmp         ??$?0ULuaValueFailure@lua@script@lux@@$0A@@?$expected_operations_base@XULuaValueFailure@lua@script@lux@@@detail@tl@@QEAA@Uunexpect_t@2@$$QEAULuaValueFailure@lua@script@lux@@@Z
@ILT+575(??1bad_alloc@std@@UEAA@XZ):
  0000000180001244: jmp         ??1bad_alloc@std@@UEAA@XZ
@ILT+580(?configureLuaVm@detail@lua@script@lux@@YA_NPEAUlua_State@@W4ELuaExecutionPolicy@234@AEAULuaRuntimeInfo@234@@Z):
  0000000180001249: jmp         ?configureLuaVm@detail@lua@script@lux@@YA_NPEAUlua_State@@W4ELuaExecutionPolicy@234@AEAULuaRuntimeInfo@234@@Z
@ILT+585(__scrt_stub_for_is_c_termination_complete):
  000000018000124E: jmp         __scrt_stub_for_is_c_termination_complete
@ILT+590(_get_startup_argv_mode):
  0000000180001253: jmp         _get_startup_argv_mode
@ILT+595(?field@LuaValueAccess@detail@lua@script@lux@@SA_NPEAUlua_State@@HV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z):
  0000000180001258: jmp         ?field@LuaValueAccess@detail@lua@script@lux@@SA_NPEAUlua_State@@HV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z
@ILT+600(__scrt_initialize_winrt):
  000000018000125D: jmp         __scrt_initialize_winrt
@ILT+605(?runScript@ScriptEngine@lua@script@lux@@QEAA_NAEBVScriptRef@234@@Z):
  0000000180001262: jmp         ?runScript@ScriptEngine@lua@script@lux@@QEAA_NAEBVScriptRef@234@@Z
@ILT+610(??0?$_Optional_destruct_base@H$00@std@@QEAA@XZ):
  0000000180001267: jmp         ??0?$_Optional_destruct_base@H$00@std@@QEAA@XZ
@ILT+615(__raise_securityfailure):
  000000018000126C: jmp         __raise_securityfailure
@ILT+620(??$?0VScriptRef@lua@script@lux@@@?$_Optional_destruct_base@VScriptRef@lua@script@lux@@$0A@@std@@QEAA@Uin_place_t@1@$$QEAVScriptRef@lua@script@lux@@@Z):
  0000000180001271: jmp         ??$?0VScriptRef@lua@script@lux@@@?$_Optional_destruct_base@VScriptRef@lua@script@lux@@$0A@@std@@QEAA@Uin_place_t@1@$$QEAVScriptRef@lua@script@lux@@@Z
@ILT+625(??0?$expected_default_ctor_base@XULuaValueFailure@lua@script@lux@@$00@detail@tl@@QEAA@Udefault_constructor_tag@12@@Z):
  0000000180001276: jmp         ??0?$expected_default_ctor_base@XULuaValueFailure@lua@script@lux@@$00@detail@tl@@QEAA@Udefault_constructor_tag@12@@Z
@ILT+630(??$?0VScriptRef@lua@script@lux@@$0A@@?$optional@VScriptRef@lua@script@lux@@@std@@QEAA@$$QEAVScriptRef@lua@script@lux@@@Z):
  000000018000127B: jmp         ??$?0VScriptRef@lua@script@lux@@$0A@@?$optional@VScriptRef@lua@script@lux@@@std@@QEAA@$$QEAVScriptRef@lua@script@lux@@@Z
@ILT+635(_RTC_Initialize):
  0000000180001280: jmp         _RTC_Initialize
@ILT+640(?setLuaChunkEnvironment@detail@lua@script@lux@@YA_NPEAUlua_State@@HH@Z):
  0000000180001285: jmp         ?setLuaChunkEnvironment@detail@lua@script@lux@@YA_NPEAUlua_State@@HH@Z
@ILT+645(??_Ebad_alloc@std@@UEAAPEAXI@Z):
  000000018000128A: jmp         ??_Ebad_alloc@std@@UEAAPEAXI@Z
@ILT+650(?table@LuaValueAccess@detail@lua@script@lux@@SA_NPEAUlua_State@@H@Z):
  000000018000128F: jmp         ?table@LuaValueAccess@detail@lua@script@lux@@SA_NPEAUlua_State@@H@Z
@ILT+655(??0?$expected_copy_base@XULuaValueFailure@lua@script@lux@@$00$00@detail@tl@@QEAA@XZ):
  0000000180001294: jmp         ??0?$expected_copy_base@XULuaValueFailure@lua@script@lux@@$00$00@detail@tl@@QEAA@XZ
@ILT+660(??A?$array@D$0BAA@@std@@QEAAAEAD_K@Z):
  0000000180001299: jmp         ??A?$array@D$0BAA@@std@@QEAAAEAD_K@Z
@ILT+665(?configure_argv@__scrt_narrow_argv_policy@@SAHXZ):
  000000018000129E: jmp         ?configure_argv@__scrt_narrow_argv_policy@@SAHXZ
@ILT+670(_RTC_Terminate):
  00000001800012A3: jmp         _RTC_Terminate
@ILT+675(??$?0VScriptRef@lua@script@lux@@@?$_Non_trivial_move@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@Uin_place_t@1@$$QEAVScriptRef@lua@script@lux@@@Z):
  00000001800012A8: jmp         ??$?0VScriptRef@lua@script@lux@@@?$_Non_trivial_move@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@Uin_place_t@1@$$QEAVScriptRef@lua@script@lux@@@Z
@ILT+680(__scrt_set_unhandled_exception_filter):
  00000001800012AD: jmp         __scrt_set_unhandled_exception_filter
@ILT+685(??1bad_array_new_length@std@@UEAA@XZ):
  00000001800012B2: jmp         ??1bad_array_new_length@std@@UEAA@XZ
@ILT+690(??$?0ULuaValueFailure@lua@script@lux@@$0A@@?$expected_copy_assign_base@XULuaValueFailure@lua@script@lux@@$00$00@detail@tl@@QEAA@Uunexpect_t@2@$$QEAULuaValueFailure@lua@script@lux@@@Z):
  00000001800012B7: jmp         ??$?0ULuaValueFailure@lua@script@lux@@$0A@@?$expected_copy_assign_base@XULuaValueFailure@lua@script@lux@@$00$00@detail@tl@@QEAA@Uunexpect_t@2@$$QEAULuaValueFailure@lua@script@lux@@@Z
@ILT+695(??A?$array@D$0BAA@@std@@QEBAAEBD_K@Z):
  00000001800012BC: jmp         ??A?$array@D$0BAA@@std@@QEBAAEBD_K@Z
@ILT+700(??$?0VScriptRef@lua@script@lux@@@?$_Deleted_copy_assign@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@Uin_place_t@1@$$QEAVScriptRef@lua@script@lux@@@Z):
  00000001800012C1: jmp         ??$?0VScriptRef@lua@script@lux@@@?$_Deleted_copy_assign@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@Uin_place_t@1@$$QEAVScriptRef@lua@script@lux@@@Z
@ILT+705(__acrt_thread_detach):
  00000001800012C6: jmp         __acrt_thread_detach
@ILT+710(__acrt_uninitialize):
  00000001800012CB: jmp         __acrt_uninitialize
@ILT+715(?pushNumber@LuaValueAccess@detail@lua@script@lux@@SA_NPEAUlua_State@@N@Z):
  00000001800012D0: jmp         ?pushNumber@LuaValueAccess@detail@lua@script@lux@@SA_NPEAUlua_State@@N@Z
@ILT+720(__acrt_thread_attach):
  00000001800012D5: jmp         __acrt_thread_attach
@ILT+725(??$?0U?$default_delete@VScriptEngineImpl@lua@script@lux@@@std@@$0A@@?$unique_ptr@VScriptEngineImpl@lua@script@lux@@U?$default_delete@VScriptEngineImpl@lua@script@lux@@@std@@@std@@QEAA@PEAVScriptEngineImpl@lua@script@lux@@@Z):
  00000001800012DA: jmp         ??$?0U?$default_delete@VScriptEngineImpl@lua@script@lux@@@std@@$0A@@?$unique_ptr@VScriptEngineImpl@lua@script@lux@@U?$default_delete@VScriptEngineImpl@lua@script@lux@@@std@@@std@@QEAA@PEAVScriptEngineImpl@lua@script@lux@@@Z
@ILT+730(??$?0AEAPEAVScriptEngineImpl@lua@script@lux@@@?$_Compressed_pair@U?$default_delete@VScriptEngineImpl@lua@script@lux@@@std@@PEAVScriptEngineImpl@lua@script@lux@@$00@std@@QEAA@U_Zero_then_variadic_args_t@1@AEAPEAVScriptEngineImpl@lua@script@lux@@@Z):
  00000001800012DF: jmp         ??$?0AEAPEAVScriptEngineImpl@lua@script@lux@@@?$_Compressed_pair@U?$default_delete@VScriptEngineImpl@lua@script@lux@@@std@@PEAVScriptEngineImpl@lua@script@lux@@$00@std@@QEAA@U_Zero_then_variadic_args_t@1@AEAPEAVScriptEngineImpl@lua@script@lux@@@Z
@ILT+735(??1?$_Non_trivial_move_assign@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@XZ):
  00000001800012E4: jmp         ??1?$_Non_trivial_move_assign@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@XZ
@ILT+740(??4LuaValueAccess@detail@lua@script@lux@@QEAAAEAV01234@AEBV01234@@Z):
  00000001800012E9: jmp         ??4LuaValueAccess@detail@lua@script@lux@@QEAAAEAV01234@AEBV01234@@Z
@ILT+745(??$move@AEAV?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@@std@@YA$$QEAV?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@AEAV123@@Z):
  00000001800012EE: jmp         ??$move@AEAV?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@@std@@YA$$QEAV?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@AEAV123@@Z
@ILT+750(??0exception@std@@QEAA@QEBDH@Z):
  00000001800012F3: jmp         ??0exception@std@@QEAA@QEBDH@Z
@ILT+755(?parseScript@ScriptEngine@lua@script@lux@@QEAA?AV?$optional@VScriptRef@lua@script@lux@@@std@@V?$basic_string_view@DU?$char_traits@D@std@@@6@@Z):
  00000001800012F8: jmp         ?parseScript@ScriptEngine@lua@script@lux@@QEAA?AV?$optional@VScriptRef@lua@script@lux@@@std@@V?$basic_string_view@DU?$char_traits@D@std@@@6@@Z
@ILT+760(?prepend@LuaValueFailure@lua@script@lux@@QEAAXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z):
  00000001800012FD: jmp         ?prepend@LuaValueFailure@lua@script@lux@@QEAAXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z
@ILT+765(__scrt_is_managed_app):
  0000000180001302: jmp         __scrt_is_managed_app
@ILT+770(__castguard_set_user_handler):
  0000000180001307: jmp         __castguard_set_user_handler
@ILT+775(??0?$expected_move_base@XULuaValueFailure@lua@script@lux@@$00@detail@tl@@QEAA@XZ):
  000000018000130C: jmp         ??0?$expected_move_base@XULuaValueFailure@lua@script@lux@@$00@detail@tl@@QEAA@XZ
@ILT+780(__acrt_uninitialize_critical):
  0000000180001311: jmp         __acrt_uninitialize_critical
@ILT+785(__security_init_cookie):
  0000000180001316: jmp         __security_init_cookie
@ILT+790(?_Unchecked_end@?$array@D$0BAA@@std@@QEBAPEBDXZ):
  000000018000131B: jmp         ?_Unchecked_end@?$array@D$0BAA@@std@@QEBAPEBDXZ
@ILT+795(?_Get_first@?$_Compressed_pair@U?$default_delete@VScriptEngineImpl@lua@script@lux@@@std@@PEAVScriptEngineImpl@lua@script@lux@@$00@std@@QEAAAEAU?$default_delete@VScriptEngineImpl@lua@script@lux@@@2@XZ):
  0000000180001320: jmp         ?_Get_first@?$_Compressed_pair@U?$default_delete@VScriptEngineImpl@lua@script@lux@@@std@@PEAVScriptEngineImpl@lua@script@lux@@$00@std@@QEAAAEAU?$default_delete@VScriptEngineImpl@lua@script@lux@@@2@XZ
@ILT+800(__castguard_slow_path_check_os_handled):
  0000000180001325: jmp         __castguard_slow_path_check_os_handled
@ILT+805(?moveFrom@?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@AEAAXAEAV123@@Z):
  000000018000132A: jmp         ?moveFrom@?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@AEAAXAEAV123@@Z
@ILT+810(__acrt_initialize):
  000000018000132F: jmp         __acrt_initialize
@ILT+815(__scrt_get_dyn_tls_init_callback):
  0000000180001334: jmp         __scrt_get_dyn_tls_init_callback
@ILT+820(?__scrt_uninitialize_type_info@@YAXXZ):
  0000000180001339: jmp         ?__scrt_uninitialize_type_info@@YAXXZ
@ILT+825(__report_rangecheckfailure):
  000000018000133E: jmp         __report_rangecheckfailure
@ILT+830(??_Ebad_alloc@std@@UEAAPEAXI@Z):
  0000000180001343: jmp         ??_Ebad_alloc@std@@UEAAPEAXI@Z
@ILT+835(_guard_rf_checks_enforced):
  0000000180001348: jmp         _guard_rf_checks_enforced
@ILT+840(??$forward@VScriptRef@lua@script@lux@@@std@@YA$$QEAVScriptRef@lua@script@lux@@AEAV1234@@Z):
  000000018000134D: jmp         ??$forward@VScriptRef@lua@script@lux@@@std@@YA$$QEAVScriptRef@lua@script@lux@@AEAV1234@@Z
@ILT+845(??1?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@QEAA@XZ):
  0000000180001352: jmp         ??1?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@QEAA@XZ
@ILT+850(__scrt_dllmain_uninitialize_critical):
  0000000180001357: jmp         __scrt_dllmain_uninitialize_critical
@ILT+855(??$?0H@?$_Optional_construct_base@H@std@@QEAA@Uin_place_t@1@$$QEAH@Z):
  000000018000135C: jmp         ??$?0H@?$_Optional_construct_base@H@std@@QEAA@Uin_place_t@1@$$QEAH@Z
@ILT+860(__scrt_dllmain_crt_thread_attach):
  0000000180001361: jmp         __scrt_dllmain_crt_thread_attach
@ILT+865(?top@LuaValueAccess@detail@lua@script@lux@@SAHPEAUlua_State@@@Z):
  0000000180001366: jmp         ?top@LuaValueAccess@detail@lua@script@lux@@SAHPEAUlua_State@@@Z
@ILT+870(?failure@LuaValueAccess@detail@lua@script@lux@@SAHPEAUlua_State@@PEBD@Z):
  000000018000136B: jmp         ?failure@LuaValueAccess@detail@lua@script@lux@@SAHPEAUlua_State@@PEBD@Z
@ILT+875(??0?$_Deleted_copy_assign@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@XZ):
  0000000180001370: jmp         ??0?$_Deleted_copy_assign@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@XZ
@ILT+880(?reportAndPopError@ScriptEngineImpl@lua@script@lux@@AEAAXXZ):
  0000000180001375: jmp         ?reportAndPopError@ScriptEngineImpl@lua@script@lux@@AEAAXXZ
@ILT+885(__acrt_initialize):
  000000018000137A: jmp         __acrt_initialize
@ILT+890(__scrt_initialize_default_local_stdio_options):
  000000018000137F: jmp         __scrt_initialize_default_local_stdio_options
@ILT+895(??1?$_Deleted_copy@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@@std@@QEAA@XZ):
  0000000180001384: jmp         ??1?$_Deleted_copy@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@@std@@QEAA@XZ
@ILT+900(__crt_debugger_hook):
  0000000180001389: jmp         __crt_debugger_hook
@ILT+905(?setField@LuaValueAccess@detail@lua@script@lux@@SA_NPEAUlua_State@@HV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z):
  000000018000138E: jmp         ?setField@LuaValueAccess@detail@lua@script@lux@@SA_NPEAUlua_State@@HV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z
@ILT+910(__castguard_slow_path_check_debugbreak):
  0000000180001393: jmp         __castguard_slow_path_check_debugbreak
@ILT+915(__castguard_check_failure_nop):
  0000000180001398: jmp         __castguard_check_failure_nop
@ILT+920(__scrt_dllmain_after_initialize_c):
  000000018000139D: jmp         __scrt_dllmain_after_initialize_c
@ILT+925(??0_Nontrivial_dummy_type@std@@QEAA@XZ):
  00000001800013A2: jmp         ??0_Nontrivial_dummy_type@std@@QEAA@XZ
@ILT+930(??0?$expected_operations_base@XULuaValueFailure@lua@script@lux@@@detail@tl@@QEAA@XZ):
  00000001800013A7: jmp         ??0?$expected_operations_base@XULuaValueFailure@lua@script@lux@@@detail@tl@@QEAA@XZ
@ILT+935(??1ScriptRef@lua@script@lux@@QEAA@XZ):
  00000001800013AC: jmp         ??1ScriptRef@lua@script@lux@@QEAA@XZ
@ILT+940(??3@YAXPEAX_K@Z):
  00000001800013B1: jmp         ??3@YAXPEAX_K@Z
@ILT+945(__scrt_release_startup_lock):
  00000001800013B6: jmp         __scrt_release_startup_lock
@ILT+950(__isa_available_init):
  00000001800013BB: jmp         __isa_available_init
@ILT+955(__scrt_fastfail):
  00000001800013C0: jmp         __scrt_fastfail
@ILT+960(??1?$unique_ptr@VScriptEngineImpl@lua@script@lux@@U?$default_delete@VScriptEngineImpl@lua@script@lux@@@std@@@std@@QEAA@XZ):
  00000001800013C5: jmp         ??1?$unique_ptr@VScriptEngineImpl@lua@script@lux@@U?$default_delete@VScriptEngineImpl@lua@script@lux@@@std@@@std@@QEAA@XZ
@ILT+965(??_Eexception@std@@UEAAPEAXI@Z):
  00000001800013CA: jmp         ??_Eexception@std@@UEAAPEAXI@Z
@ILT+970(??B?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@QEBA_NXZ):
  00000001800013CF: jmp         ??B?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@QEBA_NXZ
@ILT+975(??1?$_Non_trivial_move@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@XZ):
  00000001800013D4: jmp         ??1?$_Non_trivial_move@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@XZ
@ILT+980(??0bad_array_new_length@std@@QEAA@XZ):
  00000001800013D9: jmp         ??0bad_array_new_length@std@@QEAA@XZ
@ILT+985(NtCurrentTeb):
  00000001800013DE: jmp         NtCurrentTeb
@ILT+990(??_Ebad_array_new_length@std@@UEAAPEAXI@Z):
  00000001800013E3: jmp         ??_Ebad_array_new_length@std@@UEAAPEAXI@Z
@ILT+995(__scrt_acquire_startup_lock):
  00000001800013E8: jmp         __scrt_acquire_startup_lock
@ILT+1000(??3@YAXPEAX@Z):
  00000001800013ED: jmp         ??3@YAXPEAX@Z
@ILT+1005(?setErrorCallback@ScriptEngineImpl@lua@script@lux@@QEAAXV?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@4@@Z):
  00000001800013F2: jmp         ?setErrorCallback@ScriptEngineImpl@lua@script@lux@@QEAAXV?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@4@@Z
@ILT+1010(??$?0ULuaValueFailure@lua@script@lux@@$0A@$0A@@?$expected@XULuaValueFailure@lua@script@lux@@@tl@@QEAA@$$QEAV?$unexpected@ULuaValueFailure@lua@script@lux@@@1@@Z):
  00000001800013F7: jmp         ??$?0ULuaValueFailure@lua@script@lux@@$0A@$0A@@?$expected@XULuaValueFailure@lua@script@lux@@@tl@@QEAA@$$QEAV?$unexpected@ULuaValueFailure@lua@script@lux@@@1@@Z
@ILT+1015(__castguard_check_failure_os_handled):
  00000001800013FC: jmp         __castguard_check_failure_os_handled
@ILT+1020(??$?0ULuaValueFailure@lua@script@lux@@$0A@@?$expected_move_base@XULuaValueFailure@lua@script@lux@@$00@detail@tl@@QEAA@Uunexpect_t@2@$$QEAULuaValueFailure@lua@script@lux@@@Z):
  0000000180001401: jmp         ??$?0ULuaValueFailure@lua@script@lux@@$0A@@?$expected_move_base@XULuaValueFailure@lua@script@lux@@$00@detail@tl@@QEAA@Uunexpect_t@2@$$QEAULuaValueFailure@lua@script@lux@@@Z
@ILT+1025(??0?$_Optional_destruct_base@VScriptRef@lua@script@lux@@$0A@@std@@QEAA@XZ):
  0000000180001406: jmp         ??0?$_Optional_destruct_base@VScriptRef@lua@script@lux@@$0A@@std@@QEAA@XZ
@ILT+1030(??R?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@QEAAXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z):
  000000018000140B: jmp         ??R?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@QEAAXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z
@ILT+1035(??$?0VScriptRef@lua@script@lux@@@?$_Non_trivial_move_assign@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@Uin_place_t@1@$$QEAVScriptRef@lua@script@lux@@@Z):
  0000000180001410: jmp         ??$?0VScriptRef@lua@script@lux@@@?$_Non_trivial_move_assign@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@Uin_place_t@1@$$QEAVScriptRef@lua@script@lux@@@Z
@ILT+1040(??0exception@std@@QEAA@AEBV01@@Z):
  0000000180001415: jmp         ??0exception@std@@QEAA@AEBV01@@Z
@ILT+1045(?restoreScratch@LuaValueAccess@detail@lua@script@lux@@SAXPEAUlua_State@@H@Z):
  000000018000141A: jmp         ?restoreScratch@LuaValueAccess@detail@lua@script@lux@@SAXPEAUlua_State@@H@Z
@ILT+1050(?number@LuaValueAccess@detail@lua@script@lux@@SA_NPEAUlua_State@@HAEAN@Z):
  000000018000141F: jmp         ?number@LuaValueAccess@detail@lua@script@lux@@SA_NPEAUlua_State@@HAEAN@Z
@ILT+1055(??$make_unique@VScriptEngineImpl@lua@script@lux@@$$V$0A@@std@@YA?AV?$unique_ptr@VScriptEngineImpl@lua@script@lux@@U?$default_delete@VScriptEngineImpl@lua@script@lux@@@std@@@0@XZ):
  0000000180001424: jmp         ??$make_unique@VScriptEngineImpl@lua@script@lux@@$$V$0A@@std@@YA?AV?$unique_ptr@VScriptEngineImpl@lua@script@lux@@U?$default_delete@VScriptEngineImpl@lua@script@lux@@@std@@@0@XZ
@ILT+1060(??0?$expected@XULuaValueFailure@lua@script@lux@@@tl@@QEAA@XZ):
  0000000180001429: jmp         ??0?$expected@XULuaValueFailure@lua@script@lux@@@tl@@QEAA@XZ
@ILT+1065(?_Unchecked_end@?$span@$$CBV?$basic_string_view@DU?$char_traits@D@std@@@std@@$0?0@std@@QEBAPEBV?$basic_string_view@DU?$char_traits@D@std@@@2@XZ):
  000000018000142E: jmp         ?_Unchecked_end@?$span@$$CBV?$basic_string_view@DU?$char_traits@D@std@@@std@@$0?0@std@@QEBAPEBV?$basic_string_view@DU?$char_traits@D@std@@@2@XZ
@ILT+1070(??0?$_Non_trivial_move_assign@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@XZ):
  0000000180001433: jmp         ??0?$_Non_trivial_move_assign@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@XZ
@ILT+1075(?resumeLuaVm@detail@lua@script@lux@@YA?AULuaResumeResult@1234@PEAUlua_State@@0H@Z):
  0000000180001438: jmp         ?resumeLuaVm@detail@lua@script@lux@@YA?AULuaResumeResult@1234@PEAUlua_State@@0H@Z
@ILT+1080(??4ScriptRef@lua@script@lux@@QEAAAEAV0123@$$QEAV0123@@Z):
  000000018000143D: jmp         ??4ScriptRef@lua@script@lux@@QEAAAEAV0123@$$QEAV0123@@Z
@ILT+1085(??_Eexception@std@@UEAAPEAXI@Z):
  0000000180001442: jmp         ??_Eexception@std@@UEAAPEAXI@Z
@ILT+1090(??0?$_Non_trivial_move@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@XZ):
  0000000180001447: jmp         ??0?$_Non_trivial_move@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@XZ
@ILT+1095(??0?$basic_string_view@DU?$char_traits@D@std@@@std@@QEAA@XZ):
  000000018000144C: jmp         ??0?$basic_string_view@DU?$char_traits@D@std@@@std@@QEAA@XZ
@ILT+1100(??$?0H@?$_Optional_destruct_base@H$00@std@@QEAA@Uin_place_t@1@$$QEAH@Z):
  0000000180001451: jmp         ??$?0H@?$_Optional_destruct_base@H$00@std@@QEAA@Uin_place_t@1@$$QEAH@Z
@ILT+1105(__scrt_initialize_mta):
  0000000180001456: jmp         __scrt_initialize_mta
@ILT+1110(__scrt_dllmain_exception_filter):
  000000018000145B: jmp         __scrt_dllmain_exception_filter
@ILT+1115(__scrt_initialize_crt):
  0000000180001460: jmp         __scrt_initialize_crt
@ILT+1120(?pushBoolean@LuaValueAccess@detail@lua@script@lux@@SA_NPEAUlua_State@@_N@Z):
  0000000180001465: jmp         ?pushBoolean@LuaValueAccess@detail@lua@script@lux@@SA_NPEAUlua_State@@_N@Z
@ILT+1125(??0?$expected_move_assign_base@XULuaValueFailure@lua@script@lux@@$00@detail@tl@@QEAA@XZ):
  000000018000146A: jmp         ??0?$expected_move_assign_base@XULuaValueFailure@lua@script@lux@@$00@detail@tl@@QEAA@XZ
@ILT+1130(__castguard_check_failure_fastfail):
  000000018000146F: jmp         __castguard_check_failure_fastfail
@ILT+1135(??1type_info@@UEAA@XZ):
  0000000180001474: jmp         ??1type_info@@UEAA@XZ
@ILT+1140(?__scrt_throw_std_bad_array_new_length@@YAXXZ):
  0000000180001479: jmp         ?__scrt_throw_std_bad_array_new_length@@YAXXZ
@ILT+1145(??$forward@H@std@@YA$$QEAHAEAH@Z):
  000000018000147E: jmp         ??$forward@H@std@@YA$$QEAHAEAH@Z
@ILT+1150(??0?$optional@H@std@@QEAA@Unullopt_t@1@@Z):
  0000000180001483: jmp         ??0?$optional@H@std@@QEAA@Unullopt_t@1@@Z
@ILT+1155(__scrt_get_show_window_mode):
  0000000180001488: jmp         __scrt_get_show_window_mode
@ILT+1160(__scrt_dllmain_crt_thread_detach):
  000000018000148D: jmp         __scrt_dllmain_crt_thread_detach
@ILT+1165(?_Unchecked_begin@?$array@D$0BAA@@std@@QEBAPEBDXZ):
  0000000180001492: jmp         ?_Unchecked_begin@?$array@D$0BAA@@std@@QEBAPEBDXZ
@ILT+1170(?initialize@LuaValueAccess@detail@lua@script@lux@@SA_NPEAUlua_State@@@Z):
  0000000180001497: jmp         ?initialize@LuaValueAccess@detail@lua@script@lux@@SA_NPEAUlua_State@@@Z
@ILT+1175(??$?0ULuaValueFailure@lua@script@lux@@$0A@@?$expected_storage_base@XULuaValueFailure@lua@script@lux@@$0A@$00@detail@tl@@QEAA@Uunexpect_t@2@$$QEAULuaValueFailure@lua@script@lux@@@Z):
  000000018000149C: jmp         ??$?0ULuaValueFailure@lua@script@lux@@$0A@@?$expected_storage_base@XULuaValueFailure@lua@script@lux@@$0A@$00@detail@tl@@QEAA@Uunexpect_t@2@$$QEAULuaValueFailure@lua@script@lux@@@Z
@ILT+1180(_CRT_INIT):
  00000001800014A1: jmp         _CRT_INIT
@ILT+1185(??4?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@QEAAAEAV012@$$QEAV012@@Z):
  00000001800014A6: jmp         ??4?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@QEAAAEAV012@$$QEAV012@@Z
@ILT+1190(__report_securityfailureEx):
  00000001800014AB: jmp         __report_securityfailureEx
@ILT+1195(?storageAddress@?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@AEAAPEAXXZ):
  00000001800014B0: jmp         ?storageAddress@?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@AEAAPEAXXZ
@ILT+1200(__scrt_dllmain_uninitialize_c):
  00000001800014B5: jmp         __scrt_dllmain_uninitialize_c
@ILT+1205(??0?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@QEAA@$$QEAV012@@Z):
  00000001800014BA: jmp         ??0?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@QEAA@$$QEAV012@@Z
@ILT+1210(??0bad_alloc@std@@QEAA@XZ):
  00000001800014BF: jmp         ??0bad_alloc@std@@QEAA@XZ
@ILT+1215(?size@?$span@$$CBV?$basic_string_view@DU?$char_traits@D@std@@@std@@$0?0@std@@QEBA_KXZ):
  00000001800014C4: jmp         ?size@?$span@$$CBV?$basic_string_view@DU?$char_traits@D@std@@@std@@$0?0@std@@QEBA_KXZ
@ILT+1220(??0LuaValueFailure@lua@script@lux@@QEAA@XZ):
  00000001800014C9: jmp         ??0LuaValueFailure@lua@script@lux@@QEAA@XZ
  00000001800014CE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800014DE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800014EE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800014FE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000150E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000151E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000152E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000153E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000154E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000155E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000156E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000157E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000158E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000159E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800015AE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800015BE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800015CE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800015DE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800015EE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800015FE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000160E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000161E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000162E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000163E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000164E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000165E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000166E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000167E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000168E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000169E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800016AE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800016BE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800016CE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800016DE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800016EE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800016FE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000170E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000171E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000172E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000173E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000174E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000175E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000176E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000177E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000178E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000179E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800017AE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800017BE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800017CE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800017DE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800017EE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800017FE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000180E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000181E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000182E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000183E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000184E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000185E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000186E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000187E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000188E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000189E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800018AE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800018BE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800018CE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800018DE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800018EE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800018FE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000190E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000191E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000192E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000193E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000194E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000195E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000196E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000197E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000198E: CC CC                                            ..
??$?0AEAPEAVScriptEngineImpl@lua@script@lux@@@?$_Compressed_pair@U?$default_delete@VScriptEngineImpl@lua@script@lux@@@std@@PEAVScriptEngineImpl@lua@script@lux@@$00@std@@QEAA@U_Zero_then_variadic_args_t@1@AEAPEAVScriptEngineImpl@lua@script@lux@@@Z:
  0000000180001990: mov         rax,qword ptr [r8]
  0000000180001993: mov         qword ptr [rcx],rax
  0000000180001996: mov         rax,rcx
  0000000180001999: ret
  000000018000199A: CC CC CC CC CC CC                                ......
??$?0H$0A@@?$optional@H@std@@QEAA@$$QEAH@Z:
  00000001800019A0: mov         eax,dword ptr [rdx]
  00000001800019A2: mov         dword ptr [rcx],eax
  00000001800019A4: mov         rax,rcx
  00000001800019A7: mov         byte ptr [rcx+4],1
  00000001800019AB: ret
  00000001800019AC: CC CC CC CC                                      ....
??$?0H@?$_Optional_construct_base@H@std@@QEAA@Uin_place_t@1@$$QEAH@Z:
  00000001800019B0: mov         eax,dword ptr [r8]
  00000001800019B3: mov         dword ptr [rcx],eax
  00000001800019B5: mov         rax,rcx
  00000001800019B8: mov         byte ptr [rcx+4],1
  00000001800019BC: ret
  00000001800019BD: CC CC CC                                         ...
??$?0H@?$_Optional_destruct_base@H$00@std@@QEAA@Uin_place_t@1@$$QEAH@Z:
  00000001800019C0: mov         eax,dword ptr [r8]
  00000001800019C3: mov         dword ptr [rcx],eax
  00000001800019C5: mov         rax,rcx
  00000001800019C8: mov         byte ptr [rcx+4],1
  00000001800019CC: ret
  00000001800019CD: CC CC CC                                         ...
??$?0U?$default_delete@VScriptEngineImpl@lua@script@lux@@@std@@$0A@@?$unique_ptr@VScriptEngineImpl@lua@script@lux@@U?$default_delete@VScriptEngineImpl@lua@script@lux@@@std@@@std@@QEAA@PEAVScriptEngineImpl@lua@script@lux@@@Z:
  00000001800019D0: mov         qword ptr [rcx],rdx
  00000001800019D3: mov         rax,rcx
  00000001800019D6: ret
  00000001800019D7: CC CC CC CC CC CC CC CC CC                       .........
??$?0VScriptRef@lua@script@lux@@$0A@@?$optional@VScriptRef@lua@script@lux@@@std@@QEAA@$$QEAVScriptRef@lua@script@lux@@@Z:
  00000001800019E0: push        rbx
  00000001800019E2: sub         rsp,20h
  00000001800019E6: mov         rbx,rcx
  00000001800019E9: call        @ILT+295(??0ScriptRef@lua@script@lux@@QEAA@$$QEAV0123@@Z)
  00000001800019EE: mov         rax,rbx
  00000001800019F1: mov         byte ptr [rbx+10h],1
  00000001800019F5: add         rsp,20h
  00000001800019F9: pop         rbx
  00000001800019FA: ret
  00000001800019FB: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180001A0B: CC CC CC CC CC                                   .....
??$?0VScriptRef@lua@script@lux@@@?$_Deleted_copy@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@@std@@QEAA@Uin_place_t@1@$$QEAVScriptRef@lua@script@lux@@@Z:
  0000000180001A10: push        rbx
  0000000180001A12: sub         rsp,20h
  0000000180001A16: mov         rdx,r8
  0000000180001A19: mov         rbx,rcx
  0000000180001A1C: call        @ILT+295(??0ScriptRef@lua@script@lux@@QEAA@$$QEAV0123@@Z)
  0000000180001A21: mov         rax,rbx
  0000000180001A24: mov         byte ptr [rbx+10h],1
  0000000180001A28: add         rsp,20h
  0000000180001A2C: pop         rbx
  0000000180001A2D: ret
  0000000180001A2E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180001A3E: CC CC                                            ..
??$?0VScriptRef@lua@script@lux@@@?$_Deleted_copy_assign@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@Uin_place_t@1@$$QEAVScriptRef@lua@script@lux@@@Z:
  0000000180001A40: push        rbx
  0000000180001A42: sub         rsp,20h
  0000000180001A46: mov         rdx,r8
  0000000180001A49: mov         rbx,rcx
  0000000180001A4C: call        @ILT+295(??0ScriptRef@lua@script@lux@@QEAA@$$QEAV0123@@Z)
  0000000180001A51: mov         rax,rbx
  0000000180001A54: mov         byte ptr [rbx+10h],1
  0000000180001A58: add         rsp,20h
  0000000180001A5C: pop         rbx
  0000000180001A5D: ret
  0000000180001A5E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180001A6E: CC CC                                            ..
??$?0VScriptRef@lua@script@lux@@@?$_Non_trivial_move@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@Uin_place_t@1@$$QEAVScriptRef@lua@script@lux@@@Z:
  0000000180001A70: push        rbx
  0000000180001A72: sub         rsp,20h
  0000000180001A76: mov         rdx,r8
  0000000180001A79: mov         rbx,rcx
  0000000180001A7C: call        @ILT+295(??0ScriptRef@lua@script@lux@@QEAA@$$QEAV0123@@Z)
  0000000180001A81: mov         rax,rbx
  0000000180001A84: mov         byte ptr [rbx+10h],1
  0000000180001A88: add         rsp,20h
  0000000180001A8C: pop         rbx
  0000000180001A8D: ret
  0000000180001A8E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180001A9E: CC CC                                            ..
??$?0VScriptRef@lua@script@lux@@@?$_Non_trivial_move_assign@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@Uin_place_t@1@$$QEAVScriptRef@lua@script@lux@@@Z:
  0000000180001AA0: push        rbx
  0000000180001AA2: sub         rsp,20h
  0000000180001AA6: mov         rdx,r8
  0000000180001AA9: mov         rbx,rcx
  0000000180001AAC: call        @ILT+295(??0ScriptRef@lua@script@lux@@QEAA@$$QEAV0123@@Z)
  0000000180001AB1: mov         rax,rbx
  0000000180001AB4: mov         byte ptr [rbx+10h],1
  0000000180001AB8: add         rsp,20h
  0000000180001ABC: pop         rbx
  0000000180001ABD: ret
  0000000180001ABE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180001ACE: CC CC                                            ..
??$?0VScriptRef@lua@script@lux@@@?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@QEAA@Uin_place_t@1@$$QEAVScriptRef@lua@script@lux@@@Z:
  0000000180001AD0: push        rbx
  0000000180001AD2: sub         rsp,20h
  0000000180001AD6: mov         rdx,r8
  0000000180001AD9: mov         rbx,rcx
  0000000180001ADC: call        @ILT+295(??0ScriptRef@lua@script@lux@@QEAA@$$QEAV0123@@Z)
  0000000180001AE1: mov         rax,rbx
  0000000180001AE4: mov         byte ptr [rbx+10h],1
  0000000180001AE8: add         rsp,20h
  0000000180001AEC: pop         rbx
  0000000180001AED: ret
  0000000180001AEE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180001AFE: CC CC                                            ..
??$?0VScriptRef@lua@script@lux@@@?$_Optional_destruct_base@VScriptRef@lua@script@lux@@$0A@@std@@QEAA@Uin_place_t@1@$$QEAVScriptRef@lua@script@lux@@@Z:
  0000000180001B00: push        rbx
  0000000180001B02: sub         rsp,20h
  0000000180001B06: mov         rdx,r8
  0000000180001B09: mov         rbx,rcx
  0000000180001B0C: call        @ILT+295(??0ScriptRef@lua@script@lux@@QEAA@$$QEAV0123@@Z)
  0000000180001B11: mov         rax,rbx
  0000000180001B14: mov         byte ptr [rbx+10h],1
  0000000180001B18: add         rsp,20h
  0000000180001B1C: pop         rbx
  0000000180001B1D: ret
  0000000180001B1E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180001B2E: CC CC                                            ..
??$forward@AEAPEAVScriptEngineImpl@lua@script@lux@@@std@@YAAEAPEAVScriptEngineImpl@lua@script@lux@@AEAPEAV1234@@Z:
  0000000180001B30: mov         rax,rcx
  0000000180001B33: ret
  0000000180001B34: CC CC CC CC CC CC CC CC CC CC CC CC              ............
??$forward@H@std@@YA$$QEAHAEAH@Z:
  0000000180001B40: mov         rax,rcx
  0000000180001B43: ret
  0000000180001B44: CC CC CC CC CC CC CC CC CC CC CC CC              ............
??$forward@V?$basic_string_view@DU?$char_traits@D@std@@@std@@@std@@YA$$QEAV?$basic_string_view@DU?$char_traits@D@std@@@0@AEAV10@@Z:
  0000000180001B50: mov         rax,rcx
  0000000180001B53: ret
  0000000180001B54: CC CC CC CC CC CC CC CC CC CC CC CC              ............
??$forward@VScriptRef@lua@script@lux@@@std@@YA$$QEAVScriptRef@lua@script@lux@@AEAV1234@@Z:
  0000000180001B60: mov         rax,rcx
  0000000180001B63: ret
  0000000180001B64: CC CC CC CC CC CC CC CC CC CC CC CC              ............
??$make_unique@VScriptEngineImpl@lua@script@lux@@$$V$0A@@std@@YA?AV?$unique_ptr@VScriptEngineImpl@lua@script@lux@@U?$default_delete@VScriptEngineImpl@lua@script@lux@@@std@@@0@XZ:
  0000000180001B70: mov         qword ptr [rsp+10h],rbx
  0000000180001B75: mov         qword ptr [rsp+18h],rsi
  0000000180001B7A: push        rdi
  0000000180001B7B: sub         rsp,30h
  0000000180001B7F: mov         rbx,rcx
  0000000180001B82: xor         esi,esi
  0000000180001B84: mov         ecx,30h
  0000000180001B89: call        @ILT+30(??2@YAPEAX_K@Z)
  0000000180001B8E: mov         qword ptr [rsp+40h],rax
  0000000180001B93: mov         rdi,rax
  0000000180001B96: test        rax,rax
  0000000180001B99: je          0000000180001BD3
  0000000180001B9B: mov         qword ptr [rax],rsi
  0000000180001B9E: mov         qword ptr [rax+8],rsi
  0000000180001BA2: mov         qword ptr [rax+28h],rsi
  0000000180001BA6: call        qword ptr [__imp_luaL_newstate]
  0000000180001BAC: mov         qword ptr [rdi],rax
  0000000180001BAF: test        rax,rax
  0000000180001BB2: je          0000000180001BBD
  0000000180001BB4: mov         rcx,rax
  0000000180001BB7: call        qword ptr [__imp_luaL_openlibs]
  0000000180001BBD: mov         qword ptr [rbx],rdi
  0000000180001BC0: mov         rax,rbx
  0000000180001BC3: mov         rbx,qword ptr [rsp+48h]
  0000000180001BC8: mov         rsi,qword ptr [rsp+50h]
  0000000180001BCD: add         rsp,30h
  0000000180001BD1: pop         rdi
  0000000180001BD2: ret
  0000000180001BD3: mov         qword ptr [rbx],rsi
  0000000180001BD6: mov         rax,rbx
  0000000180001BD9: mov         rbx,qword ptr [rsp+48h]
  0000000180001BDE: mov         rsi,qword ptr [rsp+50h]
  0000000180001BE3: add         rsp,30h
  0000000180001BE7: pop         rdi
  0000000180001BE8: ret
  0000000180001BE9: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180001BF9: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180001C09: CC CC CC CC CC CC CC                             .......
??$move@AEAV?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@@std@@YA$$QEAV?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@AEAV123@@Z:
  0000000180001C10: mov         rax,rcx
  0000000180001C13: ret
  0000000180001C14: CC CC CC CC CC CC CC CC CC CC CC CC              ............
??0?$_Deleted_copy@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@@std@@QEAA@XZ:
  0000000180001C20: mov         byte ptr [rcx+10h],0
  0000000180001C24: mov         rax,rcx
  0000000180001C27: ret
  0000000180001C28: CC CC CC CC CC CC CC CC                          ........
??0?$_Deleted_copy_assign@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@XZ:
  0000000180001C30: mov         byte ptr [rcx+10h],0
  0000000180001C34: mov         rax,rcx
  0000000180001C37: ret
  0000000180001C38: CC CC CC CC CC CC CC CC                          ........
??0?$_Non_trivial_move@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@XZ:
  0000000180001C40: mov         byte ptr [rcx+10h],0
  0000000180001C44: mov         rax,rcx
  0000000180001C47: ret
  0000000180001C48: CC CC CC CC CC CC CC CC                          ........
??0?$_Non_trivial_move_assign@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@XZ:
  0000000180001C50: mov         byte ptr [rcx+10h],0
  0000000180001C54: mov         rax,rcx
  0000000180001C57: ret
  0000000180001C58: CC CC CC CC CC CC CC CC                          ........
??0?$_Optional_construct_base@H@std@@QEAA@XZ:
  0000000180001C60: mov         byte ptr [rcx+4],0
  0000000180001C64: mov         rax,rcx
  0000000180001C67: ret
  0000000180001C68: CC CC CC CC CC CC CC CC                          ........
??0?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@QEAA@XZ:
  0000000180001C70: mov         byte ptr [rcx+10h],0
  0000000180001C74: mov         rax,rcx
  0000000180001C77: ret
  0000000180001C78: CC CC CC CC CC CC CC CC                          ........
??0?$_Optional_destruct_base@H$00@std@@QEAA@XZ:
  0000000180001C80: mov         byte ptr [rcx+4],0
  0000000180001C84: mov         rax,rcx
  0000000180001C87: ret
  0000000180001C88: CC CC CC CC CC CC CC CC                          ........
??0?$_Optional_destruct_base@VScriptRef@lua@script@lux@@$0A@@std@@QEAA@XZ:
  0000000180001C90: mov         byte ptr [rcx+10h],0
  0000000180001C94: mov         rax,rcx
  0000000180001C97: ret
  0000000180001C98: CC CC CC CC CC CC CC CC                          ........
??0?$basic_string_view@DU?$char_traits@D@std@@@std@@QEAA@QEBD@Z:
  0000000180001CA0: push        rbx
  0000000180001CA2: sub         rsp,20h
  0000000180001CA6: mov         rbx,rcx
  0000000180001CA9: mov         qword ptr [rcx],rdx
  0000000180001CAC: mov         rcx,rdx
  0000000180001CAF: call        strlen
  0000000180001CB4: mov         qword ptr [rbx+8],rax
  0000000180001CB8: mov         rax,rbx
  0000000180001CBB: add         rsp,20h
  0000000180001CBF: pop         rbx
  0000000180001CC0: ret
  0000000180001CC1: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC     ...............
??0?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@QEAA@$$QEAV012@@Z:
  0000000180001CD0: mov         qword ptr [rsp+8],rbx
  0000000180001CD5: push        rdi
  0000000180001CD6: sub         rsp,20h
  0000000180001CDA: mov         rdi,rdx
  0000000180001CDD: mov         rbx,rcx
  0000000180001CE0: mov         qword ptr [rcx],0
  0000000180001CE7: mov         qword ptr [rcx+20h],0
  0000000180001CEF: mov         rax,qword ptr [rdx+20h]
  0000000180001CF3: test        rax,rax
  0000000180001CF6: je          0000000180001D0A
  0000000180001CF8: mov         qword ptr [rcx+20h],rax
  0000000180001CFC: mov         rax,qword ptr [rax+8]
  0000000180001D00: call        rax
  0000000180001D02: mov         qword ptr [rdi+20h],0
  0000000180001D0A: mov         rax,rbx
  0000000180001D0D: mov         rbx,qword ptr [rsp+30h]
  0000000180001D12: add         rsp,20h
  0000000180001D16: pop         rdi
  0000000180001D17: ret
  0000000180001D18: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180001D28: CC CC CC CC CC CC CC CC                          ........
??0?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@QEAA@XZ:
  0000000180001D30: xor         eax,eax
  0000000180001D32: mov         qword ptr [rcx],rax
  0000000180001D35: mov         qword ptr [rcx+20h],rax
  0000000180001D39: mov         rax,rcx
  0000000180001D3C: ret
  0000000180001D3D: CC CC CC                                         ...
??0?$optional@H@std@@QEAA@Unullopt_t@1@@Z:
  0000000180001D40: mov         byte ptr [rcx+4],0
  0000000180001D44: mov         rax,rcx
  0000000180001D47: ret
  0000000180001D48: CC CC CC CC CC CC CC CC                          ........
??0?$optional@VScriptRef@lua@script@lux@@@std@@QEAA@Unullopt_t@1@@Z:
  0000000180001D50: mov         byte ptr [rcx+10h],0
  0000000180001D54: mov         rax,rcx
  0000000180001D57: ret
  0000000180001D58: CC CC CC CC CC CC CC CC                          ........
??0ScriptEngine@lua@script@lux@@QEAA@XZ:
  0000000180001D60: mov         qword ptr [rsp+10h],rbx
  0000000180001D65: mov         qword ptr [rsp+18h],rsi
  0000000180001D6A: push        rdi
  0000000180001D6B: sub         rsp,20h
  0000000180001D6F: mov         rbx,rcx
  0000000180001D72: xor         esi,esi
  0000000180001D74: mov         ecx,30h
  0000000180001D79: call        @ILT+30(??2@YAPEAX_K@Z)
  0000000180001D7E: mov         qword ptr [rsp+30h],rax
  0000000180001D83: mov         rdi,rax
  0000000180001D86: test        rax,rax
  0000000180001D89: je          0000000180001DC3
  0000000180001D8B: mov         qword ptr [rax],rsi
  0000000180001D8E: mov         qword ptr [rax+8],rsi
  0000000180001D92: mov         qword ptr [rax+28h],rsi
  0000000180001D96: call        qword ptr [__imp_luaL_newstate]
  0000000180001D9C: mov         qword ptr [rdi],rax
  0000000180001D9F: test        rax,rax
  0000000180001DA2: je          0000000180001DAD
  0000000180001DA4: mov         rcx,rax
  0000000180001DA7: call        qword ptr [__imp_luaL_openlibs]
  0000000180001DAD: mov         qword ptr [rbx],rdi
  0000000180001DB0: mov         rax,rbx
  0000000180001DB3: mov         rbx,qword ptr [rsp+38h]
  0000000180001DB8: mov         rsi,qword ptr [rsp+40h]
  0000000180001DBD: add         rsp,20h
  0000000180001DC1: pop         rdi
  0000000180001DC2: ret
  0000000180001DC3: mov         qword ptr [rbx],rsi
  0000000180001DC6: mov         rax,rbx
  0000000180001DC9: mov         rbx,qword ptr [rsp+38h]
  0000000180001DCE: mov         rsi,qword ptr [rsp+40h]
  0000000180001DD3: add         rsp,20h
  0000000180001DD7: pop         rdi
  0000000180001DD8: ret
  0000000180001DD9: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180001DE9: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180001DF9: CC CC CC CC CC CC CC                             .......
??0ScriptEngineImpl@lua@script@lux@@QEAA@XZ:
  0000000180001E00: push        rbx
  0000000180001E02: sub         rsp,20h
  0000000180001E06: xor         eax,eax
  0000000180001E08: mov         rbx,rcx
  0000000180001E0B: mov         qword ptr [rcx],rax
  0000000180001E0E: mov         qword ptr [rcx+8],rax
  0000000180001E12: mov         qword ptr [rcx+28h],rax
  0000000180001E16: call        qword ptr [__imp_luaL_newstate]
  0000000180001E1C: mov         qword ptr [rbx],rax
  0000000180001E1F: test        rax,rax
  0000000180001E22: je          0000000180001E2D
  0000000180001E24: mov         rcx,rax
  0000000180001E27: call        qword ptr [__imp_luaL_openlibs]
  0000000180001E2D: mov         rax,rbx
  0000000180001E30: add         rsp,20h
  0000000180001E34: pop         rbx
  0000000180001E35: ret
  0000000180001E36: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180001E46: CC CC CC CC CC CC CC CC CC CC                    ..........
??0ScriptRef@lua@script@lux@@QEAA@$$QEAV0123@@Z:
  0000000180001E50: mov         eax,dword ptr [rdx]
  0000000180001E52: mov         dword ptr [rcx],eax
  0000000180001E54: mov         rax,qword ptr [rdx+8]
  0000000180001E58: mov         qword ptr [rcx+8],rax
  0000000180001E5C: mov         rax,rcx
  0000000180001E5F: mov         dword ptr [rdx],0FFFFFFFEh
  0000000180001E65: mov         qword ptr [rdx+8],0
  0000000180001E6D: ret
  0000000180001E6E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180001E7E: CC CC                                            ..
??0ScriptRef@lua@script@lux@@QEAA@HPEAVScriptEngine@123@@Z:
  0000000180001E80: mov         dword ptr [rcx],edx
  0000000180001E82: mov         rax,rcx
  0000000180001E85: mov         qword ptr [rcx+8],r8
  0000000180001E89: ret
  0000000180001E8A: CC CC CC CC CC CC                                ......
??0Storage@?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@QEAA@XZ:
  0000000180001E90: mov         qword ptr [rcx],0
  0000000180001E97: mov         rax,rcx
  0000000180001E9A: ret
  0000000180001E9B: CC CC CC CC CC                                   .....
??0_Nontrivial_dummy_type@std@@QEAA@XZ:
  0000000180001EA0: mov         rax,rcx
  0000000180001EA3: ret
  0000000180001EA4: CC CC CC CC CC CC CC CC CC CC CC CC              ............
??1?$_Deleted_copy@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@@std@@QEAA@XZ:
  0000000180001EB0: cmp         byte ptr [rcx+10h],0
  0000000180001EB4: jne         @ILT+935(??1ScriptRef@lua@script@lux@@QEAA@XZ)
  0000000180001EBA: ret
  0000000180001EBB: CC CC CC CC CC                                   .....
??1?$_Deleted_copy_assign@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@XZ:
  0000000180001EC0: cmp         byte ptr [rcx+10h],0
  0000000180001EC4: jne         @ILT+935(??1ScriptRef@lua@script@lux@@QEAA@XZ)
  0000000180001ECA: ret
  0000000180001ECB: CC CC CC CC CC                                   .....
??1?$_Non_trivial_move@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@XZ:
  0000000180001ED0: cmp         byte ptr [rcx+10h],0
  0000000180001ED4: jne         @ILT+935(??1ScriptRef@lua@script@lux@@QEAA@XZ)
  0000000180001EDA: ret
  0000000180001EDB: CC CC CC CC CC                                   .....
??1?$_Non_trivial_move_assign@U?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@VScriptRef@lua@script@lux@@@std@@QEAA@XZ:
  0000000180001EE0: cmp         byte ptr [rcx+10h],0
  0000000180001EE4: jne         @ILT+935(??1ScriptRef@lua@script@lux@@QEAA@XZ)
  0000000180001EEA: ret
  0000000180001EEB: CC CC CC CC CC                                   .....
??1?$_Optional_construct_base@VScriptRef@lua@script@lux@@@std@@QEAA@XZ:
  0000000180001EF0: cmp         byte ptr [rcx+10h],0
  0000000180001EF4: jne         @ILT+935(??1ScriptRef@lua@script@lux@@QEAA@XZ)
  0000000180001EFA: ret
  0000000180001EFB: CC CC CC CC CC                                   .....
??1?$_Optional_destruct_base@VScriptRef@lua@script@lux@@$0A@@std@@QEAA@XZ:
  0000000180001F00: cmp         byte ptr [rcx+10h],0
  0000000180001F04: jne         @ILT+935(??1ScriptRef@lua@script@lux@@QEAA@XZ)
  0000000180001F0A: ret
  0000000180001F0B: CC CC CC CC CC                                   .....
??1?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@QEAA@XZ:
  0000000180001F10: push        rbx
  0000000180001F12: sub         rsp,20h
  0000000180001F16: mov         rbx,rcx
  0000000180001F19: mov         rax,qword ptr [rcx+20h]
  0000000180001F1D: test        rax,rax
  0000000180001F20: je          0000000180001F2F
  0000000180001F22: mov         rax,qword ptr [rax]
  0000000180001F25: call        rax
  0000000180001F27: mov         qword ptr [rbx+20h],0
  0000000180001F2F: add         rsp,20h
  0000000180001F33: pop         rbx
  0000000180001F34: ret
  0000000180001F35: CC CC CC CC CC CC CC CC CC CC CC                 ...........
??1?$optional@VScriptRef@lua@script@lux@@@std@@QEAA@XZ:
  0000000180001F40: cmp         byte ptr [rcx+10h],0
  0000000180001F44: jne         @ILT+935(??1ScriptRef@lua@script@lux@@QEAA@XZ)
  0000000180001F4A: ret
  0000000180001F4B: CC CC CC CC CC                                   .....
??1?$unique_ptr@VScriptEngineImpl@lua@script@lux@@U?$default_delete@VScriptEngineImpl@lua@script@lux@@@std@@@std@@QEAA@XZ:
  0000000180001F50: mov         qword ptr [rsp+8],rbx
  0000000180001F55: push        rdi
  0000000180001F56: sub         rsp,20h
  0000000180001F5A: mov         rbx,qword ptr [rcx]
  0000000180001F5D: test        rbx,rbx
  0000000180001F60: je          0000000180001F99
  0000000180001F62: mov         rcx,qword ptr [rbx]
  0000000180001F65: test        rcx,rcx
  0000000180001F68: je          0000000180001F71
  0000000180001F6A: call        qword ptr [__imp_lua_close]
  0000000180001F70: nop
  0000000180001F71: mov         rax,qword ptr [rbx+28h]
  0000000180001F75: test        rax,rax
  0000000180001F78: je          0000000180001F8B
  0000000180001F7A: mov         rax,qword ptr [rax]
  0000000180001F7D: lea         rcx,[rbx+8]
  0000000180001F81: call        rax
  0000000180001F83: mov         qword ptr [rbx+28h],0
  0000000180001F8B: mov         edx,30h
  0000000180001F90: mov         rcx,rbx
  0000000180001F93: call        @ILT+940(??3@YAXPEAX_K@Z)
  0000000180001F98: nop
  0000000180001F99: mov         rbx,qword ptr [rsp+30h]
  0000000180001F9E: add         rsp,20h
  0000000180001FA2: pop         rdi
  0000000180001FA3: ret
  0000000180001FA4: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180001FB4: CC CC CC CC CC CC CC CC CC CC CC CC              ............
??1ScriptEngine@lua@script@lux@@QEAA@XZ:
  0000000180001FC0: mov         qword ptr [rsp+8],rbx
  0000000180001FC5: push        rdi
  0000000180001FC6: sub         rsp,20h
  0000000180001FCA: mov         rbx,qword ptr [rcx]
  0000000180001FCD: test        rbx,rbx
  0000000180001FD0: je          0000000180002009
  0000000180001FD2: mov         rcx,qword ptr [rbx]
  0000000180001FD5: test        rcx,rcx
  0000000180001FD8: je          0000000180001FE1
  0000000180001FDA: call        qword ptr [__imp_lua_close]
  0000000180001FE0: nop
  0000000180001FE1: mov         rax,qword ptr [rbx+28h]
  0000000180001FE5: test        rax,rax
  0000000180001FE8: je          0000000180001FFB
  0000000180001FEA: mov         rax,qword ptr [rax]
  0000000180001FED: lea         rcx,[rbx+8]
  0000000180001FF1: call        rax
  0000000180001FF3: mov         qword ptr [rbx+28h],0
  0000000180001FFB: mov         edx,30h
  0000000180002000: mov         rcx,rbx
  0000000180002003: call        @ILT+940(??3@YAXPEAX_K@Z)
  0000000180002008: nop
  0000000180002009: mov         rbx,qword ptr [rsp+30h]
  000000018000200E: add         rsp,20h
  0000000180002012: pop         rdi
  0000000180002013: ret
  0000000180002014: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180002024: CC CC CC CC CC CC CC CC CC CC CC CC              ............
??1ScriptEngineImpl@lua@script@lux@@QEAA@XZ:
  0000000180002030: push        rbx
  0000000180002032: sub         rsp,20h
  0000000180002036: mov         rbx,rcx
  0000000180002039: mov         rcx,qword ptr [rcx]
  000000018000203C: test        rcx,rcx
  000000018000203F: je          0000000180002048
  0000000180002041: call        qword ptr [__imp_lua_close]
  0000000180002047: nop
  0000000180002048: mov         rax,qword ptr [rbx+28h]
  000000018000204C: test        rax,rax
  000000018000204F: je          0000000180002062
  0000000180002051: mov         rax,qword ptr [rax]
  0000000180002054: lea         rcx,[rbx+8]
  0000000180002058: call        rax
  000000018000205A: mov         qword ptr [rbx+28h],0
  0000000180002062: add         rsp,20h
  0000000180002066: pop         rbx
  0000000180002067: ret
  0000000180002068: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180002078: CC CC CC CC CC CC CC CC                          ........
??1ScriptRef@lua@script@lux@@QEAA@XZ:
  0000000180002080: push        rbx
  0000000180002082: sub         rsp,20h
  0000000180002086: mov         ebx,dword ptr [rcx]
  0000000180002088: cmp         ebx,0FFFFFFFEh
  000000018000208B: je          00000001800020AD
  000000018000208D: mov         rcx,qword ptr [rcx+8]
  0000000180002091: call        @ILT+475(?state@ScriptEngine@lua@script@lux@@QEAAPEAUlua_State@@XZ)
  0000000180002096: mov         r8d,ebx
  0000000180002099: mov         edx,0FFFFD8F0h
  000000018000209E: mov         rcx,rax
  00000001800020A1: add         rsp,20h
  00000001800020A5: pop         rbx
  00000001800020A6: jmp         qword ptr [__imp_luaL_unref]
  00000001800020AD: add         rsp,20h
  00000001800020B1: pop         rbx
  00000001800020B2: ret
  00000001800020B3: CC CC CC CC CC CC CC CC CC CC CC CC CC           .............
??4?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@QEAAAEAV012@$$QEAV012@@Z:
  00000001800020C0: mov         qword ptr [rsp+8],rbx
  00000001800020C5: push        rdi
  00000001800020C6: sub         rsp,20h
  00000001800020CA: mov         rdi,rdx
  00000001800020CD: mov         rbx,rcx
  00000001800020D0: cmp         rcx,rdx
  00000001800020D3: je          000000018000210C
  00000001800020D5: mov         rax,qword ptr [rcx+20h]
  00000001800020D9: test        rax,rax
  00000001800020DC: je          00000001800020EB
  00000001800020DE: mov         rax,qword ptr [rax]
  00000001800020E1: call        rax
  00000001800020E3: mov         qword ptr [rbx+20h],0
  00000001800020EB: mov         rax,qword ptr [rdi+20h]
  00000001800020EF: test        rax,rax
  00000001800020F2: je          000000018000210C
  00000001800020F4: mov         qword ptr [rbx+20h],rax
  00000001800020F8: mov         rax,qword ptr [rax+8]
  00000001800020FC: mov         rdx,rdi
  00000001800020FF: mov         rcx,rbx
  0000000180002102: call        rax
  0000000180002104: mov         qword ptr [rdi+20h],0
  000000018000210C: mov         rax,rbx
  000000018000210F: mov         rbx,qword ptr [rsp+30h]
  0000000180002114: add         rsp,20h
  0000000180002118: pop         rdi
  0000000180002119: ret
  000000018000211A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000212A: CC CC CC CC CC CC                                ......
??4ScriptRef@lua@script@lux@@QEAAAEAV0123@$$QEAV0123@@Z:
  0000000180002130: mov         qword ptr [rsp+10h],rbx
  0000000180002135: push        rdi
  0000000180002136: sub         rsp,20h
  000000018000213A: mov         rdi,rdx
  000000018000213D: mov         rbx,rcx
  0000000180002140: cmp         rcx,rdx
  0000000180002143: je          0000000180002188
  0000000180002145: cmp         dword ptr [rcx],0FFFFFFFEh
  0000000180002148: mov         qword ptr [rsp+30h],rsi
  000000018000214D: je          0000000180002169
  000000018000214F: mov         rcx,qword ptr [rcx+8]
  0000000180002153: call        @ILT+475(?state@ScriptEngine@lua@script@lux@@QEAAPEAUlua_State@@XZ)
  0000000180002158: mov         r8d,dword ptr [rbx]
  000000018000215B: mov         edx,0FFFFD8F0h
  0000000180002160: mov         rcx,rax
  0000000180002163: call        qword ptr [__imp_luaL_unref]
  0000000180002169: mov         eax,dword ptr [rdi]
  000000018000216B: mov         rsi,qword ptr [rsp+30h]
  0000000180002170: mov         dword ptr [rbx],eax
  0000000180002172: mov         rax,qword ptr [rdi+8]
  0000000180002176: mov         qword ptr [rbx+8],rax
  000000018000217A: mov         dword ptr [rdi],0FFFFFFFEh
  0000000180002180: mov         qword ptr [rdi+8],0
  0000000180002188: mov         rax,rbx
  000000018000218B: mov         rbx,qword ptr [rsp+38h]
  0000000180002190: add         rsp,20h
  0000000180002194: pop         rdi
  0000000180002195: ret
  0000000180002196: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800021A6: CC CC CC CC CC CC CC CC CC CC                    ..........
??B?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@QEBA_NXZ:
  00000001800021B0: cmp         qword ptr [rcx+20h],0
  00000001800021B5: setne       al
  00000001800021B8: ret
  00000001800021B9: CC CC CC CC CC CC CC                             .......
??B?$optional@H@std@@QEBA_NXZ:
  00000001800021C0: movzx       eax,byte ptr [rcx+4]
  00000001800021C4: ret
  00000001800021C5: CC CC CC CC CC CC CC CC CC CC CC                 ...........
??C?$unique_ptr@VScriptEngineImpl@lua@script@lux@@U?$default_delete@VScriptEngineImpl@lua@script@lux@@@std@@@std@@QEBAPEAVScriptEngineImpl@lua@script@lux@@XZ:
  00000001800021D0: mov         rax,qword ptr [rcx]
  00000001800021D3: ret
  00000001800021D4: CC CC CC CC CC CC CC CC CC CC CC CC              ............
??D?$_Optional_construct_base@H@std@@QEGAAAEAHXZ:
  00000001800021E0: mov         rax,rcx
  00000001800021E3: ret
  00000001800021E4: CC CC CC CC CC CC CC CC CC CC CC CC              ............
??R?$default_delete@VScriptEngineImpl@lua@script@lux@@@std@@QEBAXPEAVScriptEngineImpl@lua@script@lux@@@Z:
  00000001800021F0: test        rdx,rdx
  00000001800021F3: je          0000000180002243
  00000001800021F5: mov         qword ptr [rsp+8],rbx
  00000001800021FA: push        rdi
  00000001800021FB: sub         rsp,20h
  00000001800021FF: mov         rbx,rdx
  0000000180002202: mov         rcx,qword ptr [rdx]
  0000000180002205: test        rcx,rcx
  0000000180002208: je          0000000180002211
  000000018000220A: call        qword ptr [__imp_lua_close]
  0000000180002210: nop
  0000000180002211: mov         rax,qword ptr [rbx+28h]
  0000000180002215: test        rax,rax
  0000000180002218: je          000000018000222B
  000000018000221A: mov         rax,qword ptr [rax]
  000000018000221D: lea         rcx,[rbx+8]
  0000000180002221: call        rax
  0000000180002223: mov         qword ptr [rbx+28h],0
  000000018000222B: mov         edx,30h
  0000000180002230: mov         rcx,rbx
  0000000180002233: call        @ILT+940(??3@YAXPEAX_K@Z)
  0000000180002238: nop
  0000000180002239: mov         rbx,qword ptr [rsp+30h]
  000000018000223E: add         rsp,20h
  0000000180002242: pop         rdi
  0000000180002243: ret
  0000000180002244: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180002254: CC CC CC CC CC CC CC CC CC CC CC CC              ............
??R?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@QEAAXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z:
  0000000180002260: sub         rsp,28h
  0000000180002264: mov         rax,qword ptr [rcx+20h]
  0000000180002268: mov         r8,qword ptr [rax+10h]
  000000018000226C: call        r8
  000000018000226F: add         rsp,28h
  0000000180002273: ret
  0000000180002274: CC CC CC CC CC CC CC CC CC CC CC CC              ............
??_GScriptEngineImpl@lua@script@lux@@QEAAPEAXI@Z:
  0000000180002280: mov         qword ptr [rsp+8],rbx
  0000000180002285: mov         qword ptr [rsp+10h],rsi
  000000018000228A: push        rdi
  000000018000228B: sub         rsp,20h
  000000018000228F: mov         esi,edx
  0000000180002291: mov         rbx,rcx
  0000000180002294: mov         rcx,qword ptr [rcx]
  0000000180002297: test        rcx,rcx
  000000018000229A: je          00000001800022A3
  000000018000229C: call        qword ptr [__imp_lua_close]
  00000001800022A2: nop
  00000001800022A3: mov         rax,qword ptr [rbx+28h]
  00000001800022A7: test        rax,rax
  00000001800022AA: je          00000001800022BD
  00000001800022AC: mov         rax,qword ptr [rax]
  00000001800022AF: lea         rcx,[rbx+8]
  00000001800022B3: call        rax
  00000001800022B5: mov         qword ptr [rbx+28h],0
  00000001800022BD: test        sil,1
  00000001800022C1: je          00000001800022D0
  00000001800022C3: mov         edx,30h
  00000001800022C8: mov         rcx,rbx
  00000001800022CB: call        @ILT+940(??3@YAXPEAX_K@Z)
  00000001800022D0: mov         rax,rbx
  00000001800022D3: mov         rbx,qword ptr [rsp+30h]
  00000001800022D8: mov         rsi,qword ptr [rsp+38h]
  00000001800022DD: add         rsp,20h
  00000001800022E1: pop         rdi
  00000001800022E2: ret
  00000001800022E3: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800022F3: CC CC CC CC CC CC CC CC CC CC CC CC CC           .............
??_GScriptRef@lua@script@lux@@QEAAPEAXI@Z:
  0000000180002300: mov         qword ptr [rsp+8],rbx
  0000000180002305: push        rdi
  0000000180002306: sub         rsp,20h
  000000018000230A: mov         ebx,edx
  000000018000230C: mov         rdi,rcx
  000000018000230F: call        @ILT+935(??1ScriptRef@lua@script@lux@@QEAA@XZ)
  0000000180002314: test        bl,1
  0000000180002317: je          0000000180002326
  0000000180002319: mov         edx,10h
  000000018000231E: mov         rcx,rdi
  0000000180002321: call        @ILT+940(??3@YAXPEAX_K@Z)
  0000000180002326: mov         rbx,qword ptr [rsp+30h]
  000000018000232B: mov         rax,rdi
  000000018000232E: add         rsp,20h
  0000000180002332: pop         rdi
  0000000180002333: ret
  0000000180002334: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180002344: CC CC CC CC CC CC CC CC CC CC CC CC              ............
?_Get_first@?$_Compressed_pair@U?$default_delete@VScriptEngineImpl@lua@script@lux@@@std@@PEAVScriptEngineImpl@lua@script@lux@@$00@std@@QEAAAEAU?$default_delete@VScriptEngineImpl@lua@script@lux@@@2@XZ:
  0000000180002350: mov         rax,rcx
  0000000180002353: ret
  0000000180002354: CC CC CC CC CC CC CC CC CC CC CC CC              ............
?data@?$basic_string_view@DU?$char_traits@D@std@@@std@@QEBAPEBDXZ:
  0000000180002360: mov         rax,qword ptr [rcx]
  0000000180002363: ret
  0000000180002364: CC CC CC CC CC CC CC CC CC CC CC CC              ............
?length@?$_Narrow_char_traits@DH@std@@SA_KQEBD@Z:
  0000000180002370: jmp         strlen
  0000000180002375: CC CC CC CC CC CC CC CC CC CC CC                 ...........
?luaTraceback@ScriptEngineImpl@lua@script@lux@@CAHPEAUlua_State@@@Z:
  0000000180002380: mov         qword ptr [rsp+18h],rsi
  0000000180002385: mov         qword ptr [rsp+20h],rdi
  000000018000238A: push        r14
  000000018000238C: sub         rsp,30h
  0000000180002390: xor         r8d,r8d
  0000000180002393: mov         edx,1
  0000000180002398: mov         rdi,rcx
  000000018000239B: call        qword ptr [__imp_lua_tolstring]
  00000001800023A1: mov         edx,0FFFFD8EDh
  00000001800023A6: mov         rcx,rdi
  00000001800023A9: mov         r14,rax
  00000001800023AC: call        qword ptr [__imp_lua_touserdata]
  00000001800023B2: mov         rsi,rax
  00000001800023B5: test        rax,rax
  00000001800023B8: je          0000000180002407
  00000001800023BA: mov         qword ptr [rsp+48h],rbp
  00000001800023BF: mov         rbp,qword ptr [rax+28h]
  00000001800023C3: test        rbp,rbp
  00000001800023C6: je          0000000180002402
  00000001800023C8: mov         qword ptr [rsp+40h],rbx
  00000001800023CD: test        r14,r14
  00000001800023D0: lea         rbx,[??_C@_08IOBKLOJJ@?$CIno?5msg?$CJ@]
  00000001800023D7: cmovne      rbx,r14
  00000001800023DB: mov         rcx,rbx
  00000001800023DE: call        strlen
  00000001800023E3: mov         qword ptr [rsp+28h],rax
  00000001800023E8: lea         rcx,[rsi+8]
  00000001800023EC: mov         qword ptr [rsp+20h],rbx
  00000001800023F1: lea         rdx,[rsp+20h]
  00000001800023F6: mov         r8,qword ptr [rbp+10h]
  00000001800023FA: call        r8
  00000001800023FD: mov         rbx,qword ptr [rsp+40h]
  0000000180002402: mov         rbp,qword ptr [rsp+48h]
  0000000180002407: mov         r9d,1
  000000018000240D: mov         r8,r14
  0000000180002410: mov         rdx,rdi
  0000000180002413: mov         rcx,rdi
  0000000180002416: call        qword ptr [__imp_luaL_traceback]
  000000018000241C: mov         rsi,qword ptr [rsp+50h]
  0000000180002421: mov         eax,1
  0000000180002426: mov         rdi,qword ptr [rsp+58h]
  000000018000242B: add         rsp,30h
  000000018000242F: pop         r14
  0000000180002431: ret
  0000000180002432: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180002442: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180002452: CC CC CC CC CC CC CC CC CC CC CC CC CC CC        ..............
?moveFrom@?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@AEAAXAEAV123@@Z:
  0000000180002460: push        rbx
  0000000180002462: sub         rsp,20h
  0000000180002466: mov         rbx,rdx
  0000000180002469: mov         rax,qword ptr [rdx+20h]
  000000018000246D: test        rax,rax
  0000000180002470: je          0000000180002484
  0000000180002472: mov         qword ptr [rcx+20h],rax
  0000000180002476: mov         rax,qword ptr [rax+8]
  000000018000247A: call        rax
  000000018000247C: mov         qword ptr [rbx+20h],0
  0000000180002484: add         rsp,20h
  0000000180002488: pop         rbx
  0000000180002489: ret
  000000018000248A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000249A: CC CC CC CC CC CC                                ......
?parseScript@ScriptEngine@lua@script@lux@@QEAA?AV?$optional@VScriptRef@lua@script@lux@@@std@@V?$basic_string_view@DU?$char_traits@D@std@@@6@@Z:
  00000001800024A0: mov         qword ptr [rsp+8],rbx
  00000001800024A5: mov         qword ptr [rsp+10h],rsi
  00000001800024AA: push        rdi
  00000001800024AB: sub         rsp,50h
  00000001800024AF: mov         rdi,qword ptr [rcx]
  00000001800024B2: mov         rsi,rcx
  00000001800024B5: movups      xmm1,xmmword ptr [r8]
  00000001800024B9: mov         rbx,rdx
  00000001800024BC: mov         rcx,qword ptr [rdi]
  00000001800024BF: test        rcx,rcx
  00000001800024C2: je          00000001800024FC
  00000001800024C4: movdqa      xmm0,xmm1
  00000001800024C8: lea         rax,[??_C@_01PFHFFBPC@t@]
  00000001800024CF: psrldq      xmm0,8
  00000001800024D4: lea         r9,[??_C@_09IJAKJBPN@blueprint@]
  00000001800024DB: movq        r8,xmm0
  00000001800024E0: mov         qword ptr [rsp+20h],rax
  00000001800024E5: movq        rdx,xmm1
  00000001800024EA: call        qword ptr [__imp_luaL_loadbufferx]
  00000001800024F0: test        eax,eax
  00000001800024F2: je          0000000180002513
  00000001800024F4: mov         rcx,rdi
  00000001800024F7: call        @ILT+880(?reportAndPopError@ScriptEngineImpl@lua@script@lux@@AEAAXXZ)
  00000001800024FC: mov         byte ptr [rbx+10h],0
  0000000180002500: mov         rax,rbx
  0000000180002503: mov         rbx,qword ptr [rsp+60h]
  0000000180002508: mov         rsi,qword ptr [rsp+68h]
  000000018000250D: add         rsp,50h
  0000000180002511: pop         rdi
  0000000180002512: ret
  0000000180002513: mov         rcx,qword ptr [rdi]
  0000000180002516: mov         edx,0FFFFD8F0h
  000000018000251B: call        qword ptr [__imp_luaL_ref]
  0000000180002521: mov         r8,rsi
  0000000180002524: lea         rcx,[rsp+38h]
  0000000180002529: mov         edx,eax
  000000018000252B: call        @ILT+375(??0ScriptRef@lua@script@lux@@QEAA@HPEAVScriptEngine@123@@Z)
  0000000180002530: mov         rdx,rax
  0000000180002533: mov         rcx,rbx
  0000000180002536: call        @ILT+295(??0ScriptRef@lua@script@lux@@QEAA@$$QEAV0123@@Z)
  000000018000253B: lea         rcx,[rsp+38h]
  0000000180002540: mov         byte ptr [rbx+10h],1
  0000000180002544: call        @ILT+935(??1ScriptRef@lua@script@lux@@QEAA@XZ)
  0000000180002549: mov         rsi,qword ptr [rsp+68h]
  000000018000254E: mov         rax,rbx
  0000000180002551: mov         rbx,qword ptr [rsp+60h]
  0000000180002556: add         rsp,50h
  000000018000255A: pop         rdi
  000000018000255B: ret
  000000018000255C: CC CC CC CC                                      ....
??0LuaValueFailure@lua@script@lux@@QEAA@XZ:
  0000000180002560: push        rbx
  0000000180002562: sub         rsp,20h
  0000000180002566: mov         rbx,rcx
  0000000180002569: mov         byte ptr [rcx],0
  000000018000256C: inc         rcx
  000000018000256F: xor         edx,edx
  0000000180002571: mov         r8d,100h
  0000000180002577: call        memset
  000000018000257C: mov         rax,rbx
  000000018000257F: mov         byte ptr [rbx+101h],0
  0000000180002586: add         rsp,20h
  000000018000258A: pop         rbx
  000000018000258B: ret
  000000018000258C: CC CC CC CC                                      ....
?parseScript@ScriptEngineImpl@lua@script@lux@@QEAA?AV?$optional@H@std@@V?$basic_string_view@DU?$char_traits@D@std@@@6@@Z:
  0000000180002590: mov         qword ptr [rsp+8],rbx
  0000000180002595: push        rdi
  0000000180002596: sub         rsp,30h
  000000018000259A: mov         rdi,rcx
  000000018000259D: mov         rax,r8
  00000001800025A0: mov         rcx,qword ptr [rcx]
  00000001800025A3: mov         rbx,rdx
  00000001800025A6: test        rcx,rcx
  00000001800025A9: jne         00000001800025BC
  00000001800025AB: mov         byte ptr [rdx+4],cl
  00000001800025AE: mov         rax,rdx
  00000001800025B1: mov         rbx,qword ptr [rsp+40h]
  00000001800025B6: add         rsp,30h
  00000001800025BA: pop         rdi
  00000001800025BB: ret
  00000001800025BC: mov         r8,qword ptr [r8+8]
  00000001800025C0: lea         rdx,[??_C@_01PFHFFBPC@t@]
  00000001800025C7: mov         qword ptr [rsp+20h],rdx
  00000001800025CC: lea         r9,[??_C@_09IJAKJBPN@blueprint@]
  00000001800025D3: mov         rdx,qword ptr [rax]
  00000001800025D6: call        qword ptr [__imp_luaL_loadbufferx]
  00000001800025DC: test        eax,eax
  00000001800025DE: je          00000001800025FA
  00000001800025E0: mov         rcx,rdi
  00000001800025E3: call        @ILT+880(?reportAndPopError@ScriptEngineImpl@lua@script@lux@@AEAAXXZ)
  00000001800025E8: mov         rax,rbx
  00000001800025EB: mov         byte ptr [rbx+4],0
  00000001800025EF: mov         rbx,qword ptr [rsp+40h]
  00000001800025F4: add         rsp,30h
  00000001800025F8: pop         rdi
  00000001800025F9: ret
  00000001800025FA: mov         rcx,qword ptr [rdi]
  00000001800025FD: mov         edx,0FFFFD8F0h
  0000000180002602: call        qword ptr [__imp_luaL_ref]
  0000000180002608: mov         dword ptr [rbx],eax
  000000018000260A: mov         rax,rbx
  000000018000260D: mov         byte ptr [rbx+4],1
  0000000180002611: mov         rbx,qword ptr [rsp+40h]
  0000000180002616: add         rsp,30h
  000000018000261A: pop         rdi
  000000018000261B: ret
  000000018000261C: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000262C: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000263C: CC CC CC CC                                      ....
?ref@ScriptRef@lua@script@lux@@QEBAHXZ:
  0000000180002640: mov         eax,dword ptr [rcx]
  0000000180002642: ret
  0000000180002643: CC CC CC CC CC CC CC CC CC CC CC CC CC           .............
?reportAndPopError@ScriptEngineImpl@lua@script@lux@@AEAAXXZ:
  0000000180002650: push        rsi
  0000000180002652: sub         rsp,30h
  0000000180002656: cmp         qword ptr [rcx+28h],0
  000000018000265B: mov         rsi,rcx
  000000018000265E: je          00000001800026AE
  0000000180002660: mov         rcx,qword ptr [rcx]
  0000000180002663: xor         r8d,r8d
  0000000180002666: mov         qword ptr [rsp+40h],rbx
  000000018000266B: mov         edx,0FFFFFFFFh
  0000000180002670: mov         qword ptr [rsp+48h],rdi
  0000000180002675: call        qword ptr [__imp_lua_tolstring]
  000000018000267B: mov         rcx,rax
  000000018000267E: mov         rbx,rax
  0000000180002681: call        strlen
  0000000180002686: mov         qword ptr [rsp+28h],rax
  000000018000268B: lea         rdx,[rsp+20h]
  0000000180002690: mov         rax,qword ptr [rsi+28h]
  0000000180002694: lea         rcx,[rsi+8]
  0000000180002698: mov         qword ptr [rsp+20h],rbx
  000000018000269D: mov         r8,qword ptr [rax+10h]
  00000001800026A1: call        r8
  00000001800026A4: mov         rdi,qword ptr [rsp+48h]
  00000001800026A9: mov         rbx,qword ptr [rsp+40h]
  00000001800026AE: mov         rcx,qword ptr [rsi]
  00000001800026B1: mov         edx,0FFFFFFFEh
  00000001800026B6: add         rsp,30h
  00000001800026BA: pop         rsi
  00000001800026BB: jmp         qword ptr [__imp_lua_settop]
  00000001800026C2: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800026D2: CC CC CC CC CC CC CC CC CC CC CC CC CC CC        ..............
?reset@?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@QEAAXXZ:
  00000001800026E0: push        rbx
  00000001800026E2: sub         rsp,20h
  00000001800026E6: mov         rbx,rcx
  00000001800026E9: mov         rax,qword ptr [rcx+20h]
  00000001800026ED: test        rax,rax
  00000001800026F0: je          00000001800026FF
  00000001800026F2: mov         rax,qword ptr [rax]
  00000001800026F5: call        rax
  00000001800026F7: mov         qword ptr [rbx+20h],0
  00000001800026FF: add         rsp,20h
  0000000180002703: pop         rbx
  0000000180002704: ret
  0000000180002705: CC CC CC CC CC CC CC CC CC CC CC                 ...........
?runScript@ScriptEngine@lua@script@lux@@QEAA_NAEBVScriptRef@234@@Z:
  0000000180002710: mov         qword ptr [rsp+10h],rbx
  0000000180002715: push        rsi
  0000000180002716: sub         rsp,20h
  000000018000271A: mov         rbx,qword ptr [rcx]
  000000018000271D: mov         rsi,rdx
  0000000180002720: mov         rcx,qword ptr [rbx]
  0000000180002723: test        rcx,rcx
  0000000180002726: jne         0000000180002735
  0000000180002728: xor         al,al
  000000018000272A: mov         rbx,qword ptr [rsp+38h]
  000000018000272F: add         rsp,20h
  0000000180002733: pop         rsi
  0000000180002734: ret
  0000000180002735: mov         rdx,rbx
  0000000180002738: mov         qword ptr [rsp+30h],rdi
  000000018000273D: call        qword ptr [__imp_lua_pushlightuserdata]
  0000000180002743: mov         rcx,qword ptr [rbx]
  0000000180002746: lea         rdx,[@ILT+170(?luaTraceback@ScriptEngineImpl@lua@script@lux@@CAHPEAUlua_State@@@Z)]
  000000018000274D: mov         r8d,1
  0000000180002753: call        qword ptr [__imp_lua_pushcclosure]
  0000000180002759: mov         rcx,qword ptr [rbx]
  000000018000275C: call        qword ptr [__imp_lua_gettop]
  0000000180002762: mov         r8d,dword ptr [rsi]
  0000000180002765: mov         edx,0FFFFD8F0h
  000000018000276A: mov         rcx,qword ptr [rbx]
  000000018000276D: mov         edi,eax
  000000018000276F: call        qword ptr [__imp_lua_rawgeti]
  0000000180002775: mov         rcx,qword ptr [rbx]
  0000000180002778: mov         r9d,edi
  000000018000277B: xor         r8d,r8d
  000000018000277E: xor         edx,edx
  0000000180002780: call        qword ptr [__imp_lua_pcall]
  0000000180002786: test        eax,eax
  0000000180002788: sete        sil
  000000018000278C: test        eax,eax
  000000018000278E: je          0000000180002798
  0000000180002790: mov         rcx,rbx
  0000000180002793: call        @ILT+880(?reportAndPopError@ScriptEngineImpl@lua@script@lux@@AEAAXXZ)
  0000000180002798: mov         rcx,qword ptr [rbx]
  000000018000279B: mov         edx,edi
  000000018000279D: call        qword ptr [__imp_lua_remove]
  00000001800027A3: mov         rdi,qword ptr [rsp+30h]
  00000001800027A8: movzx       eax,sil
  00000001800027AC: mov         rbx,qword ptr [rsp+38h]
  00000001800027B1: add         rsp,20h
  00000001800027B5: pop         rsi
  00000001800027B6: ret
  00000001800027B7: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800027C7: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800027D7: CC CC CC CC CC CC CC CC CC                       .........
?runScript@ScriptEngineImpl@lua@script@lux@@QEAA_NAEBVScriptRef@234@@Z:
  00000001800027E0: mov         qword ptr [rsp+10h],rbx
  00000001800027E5: push        rsi
  00000001800027E6: sub         rsp,20h
  00000001800027EA: mov         rbx,rcx
  00000001800027ED: mov         rsi,rdx
  00000001800027F0: mov         rcx,qword ptr [rcx]
  00000001800027F3: test        rcx,rcx
  00000001800027F6: jne         0000000180002805
  00000001800027F8: xor         al,al
  00000001800027FA: mov         rbx,qword ptr [rsp+38h]
  00000001800027FF: add         rsp,20h
  0000000180002803: pop         rsi
  0000000180002804: ret
  0000000180002805: mov         rdx,rbx
  0000000180002808: mov         qword ptr [rsp+30h],rdi
  000000018000280D: call        qword ptr [__imp_lua_pushlightuserdata]
  0000000180002813: mov         rcx,qword ptr [rbx]
  0000000180002816: lea         rdx,[@ILT+170(?luaTraceback@ScriptEngineImpl@lua@script@lux@@CAHPEAUlua_State@@@Z)]
  000000018000281D: mov         r8d,1
  0000000180002823: call        qword ptr [__imp_lua_pushcclosure]
  0000000180002829: mov         rcx,qword ptr [rbx]
  000000018000282C: call        qword ptr [__imp_lua_gettop]
  0000000180002832: mov         r8d,dword ptr [rsi]
  0000000180002835: mov         edx,0FFFFD8F0h
  000000018000283A: mov         rcx,qword ptr [rbx]
  000000018000283D: mov         edi,eax
  000000018000283F: call        qword ptr [__imp_lua_rawgeti]
  0000000180002845: mov         rcx,qword ptr [rbx]
  0000000180002848: mov         r9d,edi
  000000018000284B: xor         r8d,r8d
  000000018000284E: xor         edx,edx
  0000000180002850: call        qword ptr [__imp_lua_pcall]
  0000000180002856: test        eax,eax
  0000000180002858: sete        sil
  000000018000285C: test        eax,eax
  000000018000285E: je          0000000180002868
  0000000180002860: mov         rcx,rbx
  0000000180002863: call        @ILT+880(?reportAndPopError@ScriptEngineImpl@lua@script@lux@@AEAAXXZ)
  0000000180002868: mov         rcx,qword ptr [rbx]
  000000018000286B: mov         edx,edi
  000000018000286D: call        qword ptr [__imp_lua_remove]
  0000000180002873: mov         rdi,qword ptr [rsp+30h]
  0000000180002878: movzx       eax,sil
  000000018000287C: mov         rbx,qword ptr [rsp+38h]
  0000000180002881: add         rsp,20h
  0000000180002885: pop         rsi
  0000000180002886: ret
  0000000180002887: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180002897: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800028A7: CC CC CC CC CC CC CC CC CC                       .........
?setErrorCallback@ScriptEngineImpl@lua@script@lux@@QEAAXV?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@4@@Z:
  00000001800028B0: mov         qword ptr [rsp+18h],rbx
  00000001800028B5: push        rdi
  00000001800028B6: sub         rsp,30h
  00000001800028BA: mov         rbx,rdx
  00000001800028BD: mov         qword ptr [rsp+20h],rdx
  00000001800028C2: lea         rdi,[rcx+8]
  00000001800028C6: cmp         rdi,rdx
  00000001800028C9: je          0000000180002905
  00000001800028CB: mov         rax,qword ptr [rdi+20h]
  00000001800028CF: test        rax,rax
  00000001800028D2: je          00000001800028E4
  00000001800028D4: mov         rax,qword ptr [rax]
  00000001800028D7: mov         rcx,rdi
  00000001800028DA: call        rax
  00000001800028DC: mov         qword ptr [rdi+20h],0
  00000001800028E4: mov         rax,qword ptr [rbx+20h]
  00000001800028E8: test        rax,rax
  00000001800028EB: je          0000000180002905
  00000001800028ED: mov         qword ptr [rdi+20h],rax
  00000001800028F1: mov         rax,qword ptr [rax+8]
  00000001800028F5: mov         rdx,rbx
  00000001800028F8: mov         rcx,rdi
  00000001800028FB: call        rax
  00000001800028FD: mov         qword ptr [rbx+20h],0
  0000000180002905: mov         rax,qword ptr [rbx+20h]
  0000000180002909: test        rax,rax
  000000018000290C: je          000000018000291E
  000000018000290E: mov         rax,qword ptr [rax]
  0000000180002911: mov         rcx,rbx
  0000000180002914: call        rax
  0000000180002916: mov         qword ptr [rbx+20h],0
  000000018000291E: mov         rbx,qword ptr [rsp+50h]
  0000000180002923: add         rsp,30h
  0000000180002927: pop         rdi
  0000000180002928: ret
  0000000180002929: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180002939: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180002949: CC CC CC CC CC CC CC                             .......
?setOnError@ScriptEngine@lua@script@lux@@QEAAXV?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@4@@Z:
  0000000180002950: mov         qword ptr [rsp+18h],rbx
  0000000180002955: mov         qword ptr [rsp+20h],rsi
  000000018000295A: push        rdi
  000000018000295B: sub         rsp,50h
  000000018000295F: mov         rbx,rdx
  0000000180002962: mov         qword ptr [rsp+48h],rdx
  0000000180002967: mov         rdi,qword ptr [rcx]
  000000018000296A: xor         esi,esi
  000000018000296C: mov         qword ptr [rsp+20h],rsi
  0000000180002971: mov         ecx,esi
  0000000180002973: mov         qword ptr [rsp+40h],rcx
  0000000180002978: mov         rdx,qword ptr [rdx+20h]
  000000018000297C: mov         eax,esi
  000000018000297E: test        rdx,rdx
  0000000180002981: je          00000001800029A2
  0000000180002983: mov         qword ptr [rsp+40h],rdx
  0000000180002988: mov         rax,qword ptr [rdx+8]
  000000018000298C: mov         rdx,rbx
  000000018000298F: lea         rcx,[rsp+20h]
  0000000180002994: call        rax
  0000000180002996: mov         qword ptr [rbx+20h],rsi
  000000018000299A: mov         rcx,qword ptr [rsp+40h]
  000000018000299F: mov         rax,rcx
  00000001800029A2: add         rdi,8
  00000001800029A6: lea         rdx,[rsp+20h]
  00000001800029AB: cmp         rdi,rdx
  00000001800029AE: je          00000001800029EC
  00000001800029B0: mov         rax,qword ptr [rdi+20h]
  00000001800029B4: test        rax,rax
  00000001800029B7: je          00000001800029CA
  00000001800029B9: mov         rax,qword ptr [rax]
  00000001800029BC: mov         rcx,rdi
  00000001800029BF: call        rax
  00000001800029C1: mov         qword ptr [rdi+20h],rsi
  00000001800029C5: mov         rcx,qword ptr [rsp+40h]
  00000001800029CA: mov         rax,rcx
  00000001800029CD: test        rcx,rcx
  00000001800029D0: je          00000001800029EC
  00000001800029D2: mov         qword ptr [rdi+20h],rcx
  00000001800029D6: mov         rax,qword ptr [rcx+8]
  00000001800029DA: lea         rdx,[rsp+20h]
  00000001800029DF: mov         rcx,rdi
  00000001800029E2: call        rax
  00000001800029E4: mov         qword ptr [rsp+40h],rsi
  00000001800029E9: mov         rax,rsi
  00000001800029EC: test        rax,rax
  00000001800029EF: je          00000001800029FC
  00000001800029F1: mov         rax,qword ptr [rax]
  00000001800029F4: lea         rcx,[rsp+20h]
  00000001800029F9: call        rax
  00000001800029FB: nop
  00000001800029FC: mov         rax,qword ptr [rbx+20h]
  0000000180002A00: test        rax,rax
  0000000180002A03: je          0000000180002A11
  0000000180002A05: mov         rax,qword ptr [rax]
  0000000180002A08: mov         rcx,rbx
  0000000180002A0B: call        rax
  0000000180002A0D: mov         qword ptr [rbx+20h],rsi
  0000000180002A11: mov         rbx,qword ptr [rsp+70h]
  0000000180002A16: mov         rsi,qword ptr [rsp+78h]
  0000000180002A1B: add         rsp,50h
  0000000180002A1F: pop         rdi
  0000000180002A20: ret
  0000000180002A21: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC     ...............
lux::script::lua::detail::`anonymous namespace'::readField:
  0000000180002A30: push        rbx
  0000000180002A32: sub         rsp,20h
  0000000180002A36: mov         r8,qword ptr [rdx+10h]
  0000000180002A3A: mov         rbx,rcx
  0000000180002A3D: mov         rdx,qword ptr [rdx+8]
  0000000180002A41: call        qword ptr [__imp_lua_pushlstring]
  0000000180002A47: mov         edx,2
  0000000180002A4C: mov         rcx,rbx
  0000000180002A4F: call        qword ptr [__imp_lua_rawget]
  0000000180002A55: mov         eax,1
  0000000180002A5A: add         rsp,20h
  0000000180002A5E: pop         rbx
  0000000180002A5F: ret
?size@?$basic_string_view@DU?$char_traits@D@std@@@std@@QEBA_KXZ:
  0000000180002A60: mov         rax,qword ptr [rcx+8]
  0000000180002A64: ret
  0000000180002A65: CC CC CC CC CC CC CC CC CC CC CC                 ...........
?state@ScriptEngine@lua@script@lux@@QEAAPEAUlua_State@@XZ:
  0000000180002A70: mov         rax,qword ptr [rcx]
  0000000180002A73: mov         rax,qword ptr [rax]
  0000000180002A76: ret
  0000000180002A77: CC CC CC CC CC CC CC CC CC                       .........
?state@ScriptEngineImpl@lua@script@lux@@QEBAPEAUlua_State@@XZ:
  0000000180002A80: mov         rax,qword ptr [rcx]
  0000000180002A83: ret
  0000000180002A84: CC CC CC CC CC CC CC CC CC CC CC CC              ............
?storageAddress@?$move_only_function@$$A6AXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z@cxx@lux@@AEAAPEAXXZ:
  0000000180002A90: mov         rax,rcx
  0000000180002A93: ret
  0000000180002A94: CC CC CC CC CC CC CC CC CC CC CC CC              ............
?configureLuaVm@detail@lua@script@lux@@YA_NPEAUlua_State@@W4ELuaExecutionPolicy@234@AEAULuaRuntimeInfo@234@@Z:
  0000000180002AA0: mov         qword ptr [rsp+8],rbx
  0000000180002AA5: mov         qword ptr [rsp+10h],rsi
  0000000180002AAA: push        rdi
  0000000180002AAB: sub         rsp,50h
  0000000180002AAF: cmp         dl,2
  0000000180002AB2: mov         rsi,r8
  0000000180002AB5: movzx       ebx,dl
  0000000180002AB8: mov         rdi,rcx
  0000000180002ABB: setb        al
  0000000180002ABE: test        rcx,rcx
  0000000180002AC1: je          0000000180002B69
  0000000180002AC7: test        al,al
  0000000180002AC9: je          0000000180002B69
  0000000180002ACF: xor         eax,eax
  0000000180002AD1: mov         r8d,100h
  0000000180002AD7: cmp         dl,1
  0000000180002ADA: cmove       r8d,eax
  0000000180002ADE: xor         edx,edx
  0000000180002AE0: call        qword ptr [__imp_luaJIT_setmode]
  0000000180002AE6: test        eax,eax
  0000000180002AE8: je          0000000180002B69
  0000000180002AEA: cmp         bl,1
  0000000180002AED: jne         0000000180002B04
  0000000180002AEF: xor         edx,edx
  0000000180002AF1: mov         r8d,200h
  0000000180002AF7: mov         rcx,rdi
  0000000180002AFA: call        qword ptr [__imp_luaJIT_setmode]
  0000000180002B00: test        eax,eax
  0000000180002B02: je          0000000180002B69
  0000000180002B04: lea         rax,[??_C@_06ELLAGLEF@LuaJIT@]
  0000000180002B0B: mov         qword ptr [rsp+28h],6
  0000000180002B14: mov         qword ptr [rsp+20h],rax
  0000000180002B19: cmp         bl,1
  0000000180002B1C: movups      xmm0,xmmword ptr [rsp+20h]
  0000000180002B21: lea         rax,[??_C@_0BG@BLHDOMJG@LuaJIT?52?41?41771261233@]
  0000000180002B28: mov         qword ptr [rsp+38h],15h
  0000000180002B31: mov         qword ptr [rsp+30h],rax
  0000000180002B36: setne       byte ptr [rsp+41h]
  0000000180002B3B: movups      xmm1,xmmword ptr [rsp+30h]
  0000000180002B40: mov         byte ptr [rsp+40h],1
  0000000180002B45: mov         al,1
  0000000180002B47: movups      xmmword ptr [rsi],xmm0
  0000000180002B4A: movsd       xmm0,mmword ptr [rsp+40h]
  0000000180002B50: movups      xmmword ptr [rsi+10h],xmm1
  0000000180002B54: movsd       mmword ptr [rsi+20h],xmm0
  0000000180002B59: mov         rbx,qword ptr [rsp+60h]
  0000000180002B5E: mov         rsi,qword ptr [rsp+68h]
  0000000180002B63: add         rsp,50h
  0000000180002B67: pop         rdi
  0000000180002B68: ret
  0000000180002B69: mov         rbx,qword ptr [rsp+60h]
  0000000180002B6E: xor         al,al
  0000000180002B70: mov         rsi,qword ptr [rsp+68h]
  0000000180002B75: add         rsp,50h
  0000000180002B79: pop         rdi
  0000000180002B7A: ret
  0000000180002B7B: CC CC CC CC CC                                   .....
lux::script::lua::detail::`anonymous namespace'::initializeTrampoline:
  0000000180002B80: push        rbx
  0000000180002B82: sub         rsp,20h
  0000000180002B86: lea         rdx,[18000E474h]
  0000000180002B8D: mov         rbx,rcx
  0000000180002B90: call        qword ptr [__imp_lua_pushlightuserdata]
  0000000180002B96: xor         r8d,r8d
  0000000180002B99: lea         rdx,[180003380h]
  0000000180002BA0: mov         rcx,rbx
  0000000180002BA3: call        qword ptr [__imp_lua_pushcclosure]
  0000000180002BA9: mov         edx,0FFFFD8F0h
  0000000180002BAE: mov         rcx,rbx
  0000000180002BB1: call        qword ptr [__imp_lua_rawset]
  0000000180002BB7: xor         eax,eax
  0000000180002BB9: add         rsp,20h
  0000000180002BBD: pop         rbx
  0000000180002BBE: ret
  0000000180002BBF: CC                                               .
?pushLuaGlobalEnvironment@detail@lua@script@lux@@YAXPEAUlua_State@@@Z:
  0000000180002BC0: mov         edx,0FFFFD8EEh
  0000000180002BC5: jmp         qword ptr [__imp_lua_pushvalue]
  0000000180002BCC: CC CC CC CC                                      ....
?resumeLuaVm@detail@lua@script@lux@@YA?AULuaResumeResult@1234@PEAUlua_State@@0H@Z:
  0000000180002BD0: push        rdi
  0000000180002BD2: sub         rsp,20h
  0000000180002BD6: mov         rdi,rcx
  0000000180002BD9: test        rcx,rcx
  0000000180002BDC: je          0000000180002C10
  0000000180002BDE: test        r8d,r8d
  0000000180002BE1: js          0000000180002C10
  0000000180002BE3: mov         edx,r8d
  0000000180002BE6: mov         qword ptr [rsp+30h],rbx
  0000000180002BEB: call        qword ptr [__imp_lua_resume]
  0000000180002BF1: mov         rcx,rdi
  0000000180002BF4: mov         ebx,eax
  0000000180002BF6: call        qword ptr [__imp_lua_gettop]
  0000000180002BFC: mov         eax,eax
  0000000180002BFE: shl         rax,20h
  0000000180002C02: or          rax,rbx
  0000000180002C05: mov         rbx,qword ptr [rsp+30h]
  0000000180002C0A: add         rsp,20h
  0000000180002C0E: pop         rdi
  0000000180002C0F: ret
  0000000180002C10: mov         eax,2
  0000000180002C15: add         rsp,20h
  0000000180002C19: pop         rdi
  0000000180002C1A: ret
  0000000180002C1B: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180002C2B: CC CC CC CC CC                                   .....
?setLuaChunkEnvironment@detail@lua@script@lux@@YA_NPEAUlua_State@@HH@Z:
  0000000180002C30: mov         qword ptr [rsp+8],rbx
  0000000180002C35: mov         qword ptr [rsp+10h],rsi
  0000000180002C3A: push        rdi
  0000000180002C3B: sub         rsp,20h
  0000000180002C3F: mov         ebx,r8d
  0000000180002C42: mov         edi,edx
  0000000180002C44: mov         rsi,rcx
  0000000180002C47: test        rcx,rcx
  0000000180002C4A: je          0000000180002C9D
  0000000180002C4C: call        qword ptr [__imp_lua_gettop]
  0000000180002C52: test        edi,edi
  0000000180002C54: jns         0000000180002C5A
  0000000180002C56: inc         edi
  0000000180002C58: add         edi,eax
  0000000180002C5A: test        ebx,ebx
  0000000180002C5C: jns         0000000180002C62
  0000000180002C5E: inc         ebx
  0000000180002C60: add         ebx,eax
  0000000180002C62: test        edi,edi
  0000000180002C64: jle         0000000180002C9D
  0000000180002C66: test        ebx,ebx
  0000000180002C68: jle         0000000180002C9D
  0000000180002C6A: cmp         edi,eax
  0000000180002C6C: jg          0000000180002C9D
  0000000180002C6E: cmp         ebx,eax
  0000000180002C70: jg          0000000180002C9D
  0000000180002C72: mov         edx,ebx
  0000000180002C74: mov         rcx,rsi
  0000000180002C77: call        qword ptr [__imp_lua_pushvalue]
  0000000180002C7D: mov         edx,edi
  0000000180002C7F: mov         rcx,rsi
  0000000180002C82: call        qword ptr [__imp_lua_setfenv]
  0000000180002C88: test        eax,eax
  0000000180002C8A: setne       al
  0000000180002C8D: mov         rbx,qword ptr [rsp+30h]
  0000000180002C92: mov         rsi,qword ptr [rsp+38h]
  0000000180002C97: add         rsp,20h
  0000000180002C9B: pop         rdi
  0000000180002C9C: ret
  0000000180002C9D: mov         rbx,qword ptr [rsp+30h]
  0000000180002CA2: xor         al,al
  0000000180002CA4: mov         rsi,qword ptr [rsp+38h]
  0000000180002CA9: add         rsp,20h
  0000000180002CAD: pop         rdi
  0000000180002CAE: ret
  0000000180002CAF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180002CBF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180002CCF: CC                                               .
?yieldLuaInvocation@detail@lua@script@lux@@YAHPEAUlua_State@@H@Z:
  0000000180002CD0: mov         qword ptr [rsp+8],rbx
  0000000180002CD5: push        rdi
  0000000180002CD6: sub         rsp,20h
  0000000180002CDA: mov         edi,edx
  0000000180002CDC: mov         rbx,rcx
  0000000180002CDF: test        rcx,rcx
  0000000180002CE2: je          0000000180002D08
  0000000180002CE4: test        edx,edx
  0000000180002CE6: js          0000000180002D08
  0000000180002CE8: call        qword ptr [__imp_lua_gettop]
  0000000180002CEE: cmp         edi,eax
  0000000180002CF0: jg          0000000180002D08
  0000000180002CF2: mov         edx,edi
  0000000180002CF4: mov         rcx,rbx
  0000000180002CF7: mov         rbx,qword ptr [rsp+30h]
  0000000180002CFC: add         rsp,20h
  0000000180002D00: pop         rdi
  0000000180002D01: jmp         qword ptr [__imp_lua_yield]
  0000000180002D08: lea         rdx,[??_C@_0CD@KLFICOLN@invalid?5Lux?5Lua?5yield?5result?5co@]
  0000000180002D0F: mov         rcx,rbx
  0000000180002D12: mov         rbx,qword ptr [rsp+30h]
  0000000180002D17: add         rsp,20h
  0000000180002D1B: pop         rdi
  0000000180002D1C: jmp         qword ptr [__imp_luaL_error]
  0000000180002D23: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180002D33: CC CC CC CC CC CC CC CC CC CC CC CC CC           .............
??$?0AEAULuaValueFailure@lua@script@lux@@$0A@@?$unexpected@ULuaValueFailure@lua@script@lux@@@tl@@QEAA@AEAULuaValueFailure@lua@script@lux@@@Z:
  0000000180002D40: mov         r9,rcx
  0000000180002D43: mov         rax,rcx
  0000000180002D46: mov         r8d,2
  0000000180002D4C: nop         dword ptr [rax]
  0000000180002D50: lea         rax,[rax+80h]
  0000000180002D57: movups      xmm0,xmmword ptr [rdx]
  0000000180002D5A: lea         rdx,[rdx+80h]
  0000000180002D61: movups      xmmword ptr [rax-80h],xmm0
  0000000180002D65: movups      xmm1,xmmword ptr [rdx-70h]
  0000000180002D69: movups      xmmword ptr [rax-70h],xmm1
  0000000180002D6D: movups      xmm0,xmmword ptr [rdx-60h]
  0000000180002D71: movups      xmmword ptr [rax-60h],xmm0
  0000000180002D75: movups      xmm1,xmmword ptr [rdx-50h]
  0000000180002D79: movups      xmmword ptr [rax-50h],xmm1
  0000000180002D7D: movups      xmm0,xmmword ptr [rdx-40h]
  0000000180002D81: movups      xmmword ptr [rax-40h],xmm0
  0000000180002D85: movups      xmm1,xmmword ptr [rdx-30h]
  0000000180002D89: movups      xmmword ptr [rax-30h],xmm1
  0000000180002D8D: movups      xmm0,xmmword ptr [rdx-20h]
  0000000180002D91: movups      xmmword ptr [rax-20h],xmm0
  0000000180002D95: movups      xmm1,xmmword ptr [rdx-10h]
  0000000180002D99: movups      xmmword ptr [rax-10h],xmm1
  0000000180002D9D: sub         r8,1
  0000000180002DA1: jne         0000000180002D50
  0000000180002DA3: movzx       ecx,word ptr [rdx]
  0000000180002DA6: mov         word ptr [rax],cx
  0000000180002DA9: mov         rax,r9
  0000000180002DAC: ret
  0000000180002DAD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180002DBD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180002DCD: CC CC CC                                         ...
??$?0ULuaValueFailure@lua@script@lux@@$0A@$0A@@?$expected@XULuaValueFailure@lua@script@lux@@@tl@@QEAA@$$QEAV?$unexpected@ULuaValueFailure@lua@script@lux@@@1@@Z:
  0000000180002DD0: mov         r9,rcx
  0000000180002DD3: mov         rax,rcx
  0000000180002DD6: mov         r8d,2
  0000000180002DDC: nop         dword ptr [rax]
  0000000180002DE0: lea         rax,[rax+80h]
  0000000180002DE7: movups      xmm0,xmmword ptr [rdx]
  0000000180002DEA: lea         rdx,[rdx+80h]
  0000000180002DF1: movups      xmmword ptr [rax-80h],xmm0
  0000000180002DF5: movups      xmm1,xmmword ptr [rdx-70h]
  0000000180002DF9: movups      xmmword ptr [rax-70h],xmm1
  0000000180002DFD: movups      xmm0,xmmword ptr [rdx-60h]
  0000000180002E01: movups      xmmword ptr [rax-60h],xmm0
  0000000180002E05: movups      xmm1,xmmword ptr [rdx-50h]
  0000000180002E09: movups      xmmword ptr [rax-50h],xmm1
  0000000180002E0D: movups      xmm0,xmmword ptr [rdx-40h]
  0000000180002E11: movups      xmmword ptr [rax-40h],xmm0
  0000000180002E15: movups      xmm1,xmmword ptr [rdx-30h]
  0000000180002E19: movups      xmmword ptr [rax-30h],xmm1
  0000000180002E1D: movups      xmm0,xmmword ptr [rdx-20h]
  0000000180002E21: movups      xmmword ptr [rax-20h],xmm0
  0000000180002E25: movups      xmm1,xmmword ptr [rdx-10h]
  0000000180002E29: movups      xmmword ptr [rax-10h],xmm1
  0000000180002E2D: sub         r8,1
  0000000180002E31: jne         0000000180002DE0
  0000000180002E33: movzx       ecx,word ptr [rdx]
  0000000180002E36: mov         word ptr [rax],cx
  0000000180002E39: mov         rax,r9
  0000000180002E3C: mov         byte ptr [r9+102h],r8b
  0000000180002E43: ret
  0000000180002E44: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180002E54: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180002E64: CC CC CC CC CC CC CC CC CC CC CC CC              ............
??$?0ULuaValueFailure@lua@script@lux@@$0A@@?$expected_copy_assign_base@XULuaValueFailure@lua@script@lux@@$00$00@detail@tl@@QEAA@Uunexpect_t@2@$$QEAULuaValueFailure@lua@script@lux@@@Z:
  0000000180002E70: mov         r9,rcx
  0000000180002E73: mov         rax,rcx
  0000000180002E76: mov         edx,2
  0000000180002E7B: nop         dword ptr [rax+rax]
  0000000180002E80: lea         rax,[rax+80h]
  0000000180002E87: movups      xmm0,xmmword ptr [r8]
  0000000180002E8B: lea         r8,[r8+80h]
  0000000180002E92: movups      xmmword ptr [rax-80h],xmm0
  0000000180002E96: movups      xmm1,xmmword ptr [r8-70h]
  0000000180002E9B: movups      xmmword ptr [rax-70h],xmm1
  0000000180002E9F: movups      xmm0,xmmword ptr [r8-60h]
  0000000180002EA4: movups      xmmword ptr [rax-60h],xmm0
  0000000180002EA8: movups      xmm1,xmmword ptr [r8-50h]
  0000000180002EAD: movups      xmmword ptr [rax-50h],xmm1
  0000000180002EB1: movups      xmm0,xmmword ptr [r8-40h]
  0000000180002EB6: movups      xmmword ptr [rax-40h],xmm0
  0000000180002EBA: movups      xmm1,xmmword ptr [r8-30h]
  0000000180002EBF: movups      xmmword ptr [rax-30h],xmm1
  0000000180002EC3: movups      xmm0,xmmword ptr [r8-20h]
  0000000180002EC8: movups      xmmword ptr [rax-20h],xmm0
  0000000180002ECC: movups      xmm1,xmmword ptr [r8-10h]
  0000000180002ED1: movups      xmmword ptr [rax-10h],xmm1
  0000000180002ED5: sub         rdx,1
  0000000180002ED9: jne         0000000180002E80
  0000000180002EDB: movzx       ecx,word ptr [r8]
  0000000180002EDF: mov         word ptr [rax],cx
  0000000180002EE2: mov         rax,r9
  0000000180002EE5: mov         byte ptr [r9+102h],dl
  0000000180002EEC: ret
  0000000180002EED: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180002EFD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180002F0D: CC CC CC                                         ...
??$?0ULuaValueFailure@lua@script@lux@@$0A@@?$expected_copy_base@XULuaValueFailure@lua@script@lux@@$00$00@detail@tl@@QEAA@Uunexpect_t@2@$$QEAULuaValueFailure@lua@script@lux@@@Z:
  0000000180002F10: mov         r9,rcx
  0000000180002F13: mov         rax,rcx
  0000000180002F16: mov         edx,2
  0000000180002F1B: nop         dword ptr [rax+rax]
  0000000180002F20: lea         rax,[rax+80h]
  0000000180002F27: movups      xmm0,xmmword ptr [r8]
  0000000180002F2B: lea         r8,[r8+80h]
  0000000180002F32: movups      xmmword ptr [rax-80h],xmm0
  0000000180002F36: movups      xmm1,xmmword ptr [r8-70h]
  0000000180002F3B: movups      xmmword ptr [rax-70h],xmm1
  0000000180002F3F: movups      xmm0,xmmword ptr [r8-60h]
  0000000180002F44: movups      xmmword ptr [rax-60h],xmm0
  0000000180002F48: movups      xmm1,xmmword ptr [r8-50h]
  0000000180002F4D: movups      xmmword ptr [rax-50h],xmm1
  0000000180002F51: movups      xmm0,xmmword ptr [r8-40h]
  0000000180002F56: movups      xmmword ptr [rax-40h],xmm0
  0000000180002F5A: movups      xmm1,xmmword ptr [r8-30h]
  0000000180002F5F: movups      xmmword ptr [rax-30h],xmm1
  0000000180002F63: movups      xmm0,xmmword ptr [r8-20h]
  0000000180002F68: movups      xmmword ptr [rax-20h],xmm0
  0000000180002F6C: movups      xmm1,xmmword ptr [r8-10h]
  0000000180002F71: movups      xmmword ptr [rax-10h],xmm1
  0000000180002F75: sub         rdx,1
  0000000180002F79: jne         0000000180002F20
  0000000180002F7B: movzx       ecx,word ptr [r8]
  0000000180002F7F: mov         word ptr [rax],cx
  0000000180002F82: mov         rax,r9
  0000000180002F85: mov         byte ptr [r9+102h],dl
  0000000180002F8C: ret
  0000000180002F8D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180002F9D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180002FAD: CC CC CC                                         ...
??$?0ULuaValueFailure@lua@script@lux@@$0A@@?$expected_move_assign_base@XULuaValueFailure@lua@script@lux@@$00@detail@tl@@QEAA@Uunexpect_t@2@$$QEAULuaValueFailure@lua@script@lux@@@Z:
  0000000180002FB0: mov         r9,rcx
  0000000180002FB3: mov         rax,rcx
  0000000180002FB6: mov         edx,2
  0000000180002FBB: nop         dword ptr [rax+rax]
  0000000180002FC0: lea         rax,[rax+80h]
  0000000180002FC7: movups      xmm0,xmmword ptr [r8]
  0000000180002FCB: lea         r8,[r8+80h]
  0000000180002FD2: movups      xmmword ptr [rax-80h],xmm0
  0000000180002FD6: movups      xmm1,xmmword ptr [r8-70h]
  0000000180002FDB: movups      xmmword ptr [rax-70h],xmm1
  0000000180002FDF: movups      xmm0,xmmword ptr [r8-60h]
  0000000180002FE4: movups      xmmword ptr [rax-60h],xmm0
  0000000180002FE8: movups      xmm1,xmmword ptr [r8-50h]
  0000000180002FED: movups      xmmword ptr [rax-50h],xmm1
  0000000180002FF1: movups      xmm0,xmmword ptr [r8-40h]
  0000000180002FF6: movups      xmmword ptr [rax-40h],xmm0
  0000000180002FFA: movups      xmm1,xmmword ptr [r8-30h]
  0000000180002FFF: movups      xmmword ptr [rax-30h],xmm1
  0000000180003003: movups      xmm0,xmmword ptr [r8-20h]
  0000000180003008: movups      xmmword ptr [rax-20h],xmm0
  000000018000300C: movups      xmm1,xmmword ptr [r8-10h]
  0000000180003011: movups      xmmword ptr [rax-10h],xmm1
  0000000180003015: sub         rdx,1
  0000000180003019: jne         0000000180002FC0
  000000018000301B: movzx       ecx,word ptr [r8]
  000000018000301F: mov         word ptr [rax],cx
  0000000180003022: mov         rax,r9
  0000000180003025: mov         byte ptr [r9+102h],dl
  000000018000302C: ret
  000000018000302D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000303D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000304D: CC CC CC                                         ...
??$?0ULuaValueFailure@lua@script@lux@@$0A@@?$expected_move_base@XULuaValueFailure@lua@script@lux@@$00@detail@tl@@QEAA@Uunexpect_t@2@$$QEAULuaValueFailure@lua@script@lux@@@Z:
  0000000180003050: mov         r9,rcx
  0000000180003053: mov         rax,rcx
  0000000180003056: mov         edx,2
  000000018000305B: nop         dword ptr [rax+rax]
  0000000180003060: lea         rax,[rax+80h]
  0000000180003067: movups      xmm0,xmmword ptr [r8]
  000000018000306B: lea         r8,[r8+80h]
  0000000180003072: movups      xmmword ptr [rax-80h],xmm0
  0000000180003076: movups      xmm1,xmmword ptr [r8-70h]
  000000018000307B: movups      xmmword ptr [rax-70h],xmm1
  000000018000307F: movups      xmm0,xmmword ptr [r8-60h]
  0000000180003084: movups      xmmword ptr [rax-60h],xmm0
  0000000180003088: movups      xmm1,xmmword ptr [r8-50h]
  000000018000308D: movups      xmmword ptr [rax-50h],xmm1
  0000000180003091: movups      xmm0,xmmword ptr [r8-40h]
  0000000180003096: movups      xmmword ptr [rax-40h],xmm0
  000000018000309A: movups      xmm1,xmmword ptr [r8-30h]
  000000018000309F: movups      xmmword ptr [rax-30h],xmm1
  00000001800030A3: movups      xmm0,xmmword ptr [r8-20h]
  00000001800030A8: movups      xmmword ptr [rax-20h],xmm0
  00000001800030AC: movups      xmm1,xmmword ptr [r8-10h]
  00000001800030B1: movups      xmmword ptr [rax-10h],xmm1
  00000001800030B5: sub         rdx,1
  00000001800030B9: jne         0000000180003060
  00000001800030BB: movzx       ecx,word ptr [r8]
  00000001800030BF: mov         word ptr [rax],cx
  00000001800030C2: mov         rax,r9
  00000001800030C5: mov         byte ptr [r9+102h],dl
  00000001800030CC: ret
  00000001800030CD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800030DD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800030ED: CC CC CC                                         ...
??$?0ULuaValueFailure@lua@script@lux@@$0A@@?$expected_operations_base@XULuaValueFailure@lua@script@lux@@@detail@tl@@QEAA@Uunexpect_t@2@$$QEAULuaValueFailure@lua@script@lux@@@Z:
  00000001800030F0: mov         r9,rcx
  00000001800030F3: mov         rax,rcx
  00000001800030F6: mov         edx,2
  00000001800030FB: nop         dword ptr [rax+rax]
  0000000180003100: lea         rax,[rax+80h]
  0000000180003107: movups      xmm0,xmmword ptr [r8]
  000000018000310B: lea         r8,[r8+80h]
  0000000180003112: movups      xmmword ptr [rax-80h],xmm0
  0000000180003116: movups      xmm1,xmmword ptr [r8-70h]
  000000018000311B: movups      xmmword ptr [rax-70h],xmm1
  000000018000311F: movups      xmm0,xmmword ptr [r8-60h]
  0000000180003124: movups      xmmword ptr [rax-60h],xmm0
  0000000180003128: movups      xmm1,xmmword ptr [r8-50h]
  000000018000312D: movups      xmmword ptr [rax-50h],xmm1
  0000000180003131: movups      xmm0,xmmword ptr [r8-40h]
  0000000180003136: movups      xmmword ptr [rax-40h],xmm0
  000000018000313A: movups      xmm1,xmmword ptr [r8-30h]
  000000018000313F: movups      xmmword ptr [rax-30h],xmm1
  0000000180003143: movups      xmm0,xmmword ptr [r8-20h]
  0000000180003148: movups      xmmword ptr [rax-20h],xmm0
  000000018000314C: movups      xmm1,xmmword ptr [r8-10h]
  0000000180003151: movups      xmmword ptr [rax-10h],xmm1
  0000000180003155: sub         rdx,1
  0000000180003159: jne         0000000180003100
  000000018000315B: movzx       ecx,word ptr [r8]
  000000018000315F: mov         word ptr [rax],cx
  0000000180003162: mov         rax,r9
  0000000180003165: mov         byte ptr [r9+102h],dl
  000000018000316C: ret
  000000018000316D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000317D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000318D: CC CC CC                                         ...
??$?0ULuaValueFailure@lua@script@lux@@$0A@@?$expected_storage_base@XULuaValueFailure@lua@script@lux@@$0A@$00@detail@tl@@QEAA@Uunexpect_t@2@$$QEAULuaValueFailure@lua@script@lux@@@Z:
  0000000180003190: mov         r9,rcx
  0000000180003193: mov         rax,rcx
  0000000180003196: mov         edx,2
  000000018000319B: nop         dword ptr [rax+rax]
  00000001800031A0: lea         rax,[rax+80h]
  00000001800031A7: movups      xmm0,xmmword ptr [r8]
  00000001800031AB: lea         r8,[r8+80h]
  00000001800031B2: movups      xmmword ptr [rax-80h],xmm0
  00000001800031B6: movups      xmm1,xmmword ptr [r8-70h]
  00000001800031BB: movups      xmmword ptr [rax-70h],xmm1
  00000001800031BF: movups      xmm0,xmmword ptr [r8-60h]
  00000001800031C4: movups      xmmword ptr [rax-60h],xmm0
  00000001800031C8: movups      xmm1,xmmword ptr [r8-50h]
  00000001800031CD: movups      xmmword ptr [rax-50h],xmm1
  00000001800031D1: movups      xmm0,xmmword ptr [r8-40h]
  00000001800031D6: movups      xmmword ptr [rax-40h],xmm0
  00000001800031DA: movups      xmm1,xmmword ptr [r8-30h]
  00000001800031DF: movups      xmmword ptr [rax-30h],xmm1
  00000001800031E3: movups      xmm0,xmmword ptr [r8-20h]
  00000001800031E8: movups      xmmword ptr [rax-20h],xmm0
  00000001800031EC: movups      xmm1,xmmword ptr [r8-10h]
  00000001800031F1: movups      xmmword ptr [rax-10h],xmm1
  00000001800031F5: sub         rdx,1
  00000001800031F9: jne         00000001800031A0
  00000001800031FB: movzx       ecx,word ptr [r8]
  00000001800031FF: mov         word ptr [rax],cx
  0000000180003202: mov         rax,r9
  0000000180003205: mov         byte ptr [r9+102h],dl
  000000018000320C: ret
  000000018000320D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000321D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000322D: CC CC CC                                         ...
??$forward@AEAULuaValueFailure@lua@script@lux@@@std@@YAAEAULuaValueFailure@lua@script@lux@@AEAU1234@@Z:
  0000000180003230: mov         rax,rcx
  0000000180003233: ret
  0000000180003234: CC CC CC CC CC CC CC CC CC CC CC CC              ............
??$forward@ULuaValueFailure@lua@script@lux@@@std@@YA$$QEAULuaValueFailure@lua@script@lux@@AEAU1234@@Z:
  0000000180003240: mov         rax,rcx
  0000000180003243: ret
  0000000180003244: CC CC CC CC CC CC CC CC CC CC CC CC              ............
??$move@AEAULuaValueFailure@lua@script@lux@@@std@@YA$$QEAULuaValueFailure@lua@script@lux@@AEAU1234@@Z:
  0000000180003250: mov         rax,rcx
  0000000180003253: ret
  0000000180003254: CC CC CC CC CC CC CC CC CC CC CC CC              ............
??0?$_Span_extent_type@$$CBV?$basic_string_view@DU?$char_traits@D@std@@@std@@$0?0@std@@QEAA@XZ:
  0000000180003260: xor         eax,eax
  0000000180003262: mov         qword ptr [rcx],rax
  0000000180003265: mov         qword ptr [rcx+8],rax
  0000000180003269: mov         rax,rcx
  000000018000326C: ret
  000000018000326D: CC CC CC                                         ...
??0?$basic_string_view@DU?$char_traits@D@std@@@std@@QEAA@XZ:
  0000000180003270: xor         eax,eax
  0000000180003272: mov         qword ptr [rcx],rax
  0000000180003275: mov         qword ptr [rcx+8],rax
  0000000180003279: mov         rax,rcx
  000000018000327C: ret
  000000018000327D: CC CC CC                                         ...
??0?$expected@XULuaValueFailure@lua@script@lux@@@tl@@QEAA@XZ:
  0000000180003280: mov         byte ptr [rcx+102h],1
  0000000180003287: mov         rax,rcx
  000000018000328A: ret
  000000018000328B: CC CC CC CC CC                                   .....
??0?$expected_copy_assign_base@XULuaValueFailure@lua@script@lux@@$00$00@detail@tl@@QEAA@XZ:
  0000000180003290: mov         byte ptr [rcx+102h],1
  0000000180003297: mov         rax,rcx
  000000018000329A: ret
  000000018000329B: CC CC CC CC CC                                   .....
??0?$expected_copy_base@XULuaValueFailure@lua@script@lux@@$00$00@detail@tl@@QEAA@XZ:
  00000001800032A0: mov         byte ptr [rcx+102h],1
  00000001800032A7: mov         rax,rcx
  00000001800032AA: ret
  00000001800032AB: CC CC CC CC CC                                   .....
??0?$expected_default_ctor_base@XULuaValueFailure@lua@script@lux@@$00@detail@tl@@QEAA@Udefault_constructor_tag@12@@Z:
  00000001800032B0: mov         rax,rcx
  00000001800032B3: ret
  00000001800032B4: CC CC CC CC CC CC CC CC CC CC CC CC              ............
??0?$expected_move_assign_base@XULuaValueFailure@lua@script@lux@@$00@detail@tl@@QEAA@XZ:
  00000001800032C0: mov         byte ptr [rcx+102h],1
  00000001800032C7: mov         rax,rcx
  00000001800032CA: ret
  00000001800032CB: CC CC CC CC CC                                   .....
??0?$expected_move_base@XULuaValueFailure@lua@script@lux@@$00@detail@tl@@QEAA@XZ:
  00000001800032D0: mov         byte ptr [rcx+102h],1
  00000001800032D7: mov         rax,rcx
  00000001800032DA: ret
  00000001800032DB: CC CC CC CC CC                                   .....
??0?$expected_operations_base@XULuaValueFailure@lua@script@lux@@@detail@tl@@QEAA@XZ:
  00000001800032E0: mov         byte ptr [rcx+102h],1
  00000001800032E7: mov         rax,rcx
  00000001800032EA: ret
  00000001800032EB: CC CC CC CC CC                                   .....
??0?$expected_storage_base@XULuaValueFailure@lua@script@lux@@$0A@$00@detail@tl@@QEAA@XZ:
  00000001800032F0: mov         byte ptr [rcx+102h],1
  00000001800032F7: mov         rax,rcx
  00000001800032FA: ret
  00000001800032FB: CC CC CC CC CC                                   .....
??0?$span@$$CBV?$basic_string_view@DU?$char_traits@D@std@@@std@@$0?0@std@@QEAA@XZ:
  0000000180003300: xor         eax,eax
  0000000180003302: mov         qword ptr [rcx],rax
  0000000180003305: mov         qword ptr [rcx+8],rax
  0000000180003309: mov         rax,rcx
  000000018000330C: ret
  000000018000330D: CC CC CC                                         ...
??0?$unexpected@ULuaValueFailure@lua@script@lux@@@tl@@QEAA@$$QEAULuaValueFailure@lua@script@lux@@@Z:
  0000000180003310: mov         r9,rcx
  0000000180003313: mov         rax,rcx
  0000000180003316: mov         r8d,2
  000000018000331C: nop         dword ptr [rax]
  0000000180003320: lea         rax,[rax+80h]
  0000000180003327: movups      xmm0,xmmword ptr [rdx]
  000000018000332A: lea         rdx,[rdx+80h]
  0000000180003331: movups      xmmword ptr [rax-80h],xmm0
  0000000180003335: movups      xmm1,xmmword ptr [rdx-70h]
  0000000180003339: movups      xmmword ptr [rax-70h],xmm1
  000000018000333D: movups      xmm0,xmmword ptr [rdx-60h]
  0000000180003341: movups      xmmword ptr [rax-60h],xmm0
  0000000180003345: movups      xmm1,xmmword ptr [rdx-50h]
  0000000180003349: movups      xmmword ptr [rax-50h],xmm1
  000000018000334D: movups      xmm0,xmmword ptr [rdx-40h]
  0000000180003351: movups      xmmword ptr [rax-40h],xmm0
  0000000180003355: movups      xmm1,xmmword ptr [rdx-30h]
  0000000180003359: movups      xmmword ptr [rax-30h],xmm1
  000000018000335D: movups      xmm0,xmmword ptr [rdx-20h]
  0000000180003361: movups      xmmword ptr [rax-20h],xmm0
  0000000180003365: movups      xmm1,xmmword ptr [rdx-10h]
  0000000180003369: movups      xmmword ptr [rax-10h],xmm1
  000000018000336D: sub         r8,1
  0000000180003371: jne         0000000180003320
  0000000180003373: movzx       ecx,word ptr [rdx]
  0000000180003376: mov         word ptr [rax],cx
  0000000180003379: mov         rax,r9
  000000018000337C: ret
  000000018000337D: CC CC CC                                         ...
lux::script::lua::detail::`anonymous namespace'::trampoline:
  0000000180003380: push        rbx
  0000000180003382: sub         rsp,20h
  0000000180003386: mov         edx,1
  000000018000338B: mov         rbx,rcx
  000000018000338E: call        qword ptr [__imp_lua_touserdata]
  0000000180003394: mov         rdx,rax
  0000000180003397: mov         rcx,rbx
  000000018000339A: mov         r8,qword ptr [rax]
  000000018000339D: add         rsp,20h
  00000001800033A1: pop         rbx
  00000001800033A2: jmp         r8
  00000001800033A5: CC CC CC CC CC CC CC CC CC CC CC                 ...........
??4LuaValueAccess@detail@lua@script@lux@@QEAAAEAV01234@$$QEAV01234@@Z:
  00000001800033B0: mov         rax,rcx
  00000001800033B3: ret
  00000001800033B4: CC CC CC CC CC CC CC CC CC CC CC CC              ............
??4LuaValueAccess@detail@lua@script@lux@@QEAAAEAV01234@AEBV01234@@Z:
  00000001800033C0: mov         rax,rcx
  00000001800033C3: ret
  00000001800033C4: CC CC CC CC CC CC CC CC CC CC CC CC              ............
??A?$array@D$0BAA@@std@@QEAAAEAD_K@Z:
  00000001800033D0: lea         rax,[rdx+rcx]
  00000001800033D4: ret
  00000001800033D5: CC CC CC CC CC CC CC CC CC CC CC                 ...........
??A?$array@D$0BAA@@std@@QEBAAEBD_K@Z:
  00000001800033E0: lea         rax,[rdx+rcx]
  00000001800033E4: ret
  00000001800033E5: CC CC CC CC CC CC CC CC CC CC CC                 ...........
?_Unchecked_begin@?$array@D$0BAA@@std@@QEBAPEBDXZ:
  00000001800033F0: mov         rax,rcx
  00000001800033F3: ret
  00000001800033F4: CC CC CC CC CC CC CC CC CC CC CC CC              ............
?_Unchecked_begin@?$basic_string_view@DU?$char_traits@D@std@@@std@@QEBAPEBDXZ:
  0000000180003400: mov         rax,qword ptr [rcx]
  0000000180003403: ret
  0000000180003404: CC CC CC CC CC CC CC CC CC CC CC CC              ............
?_Unchecked_begin@?$span@$$CBV?$basic_string_view@DU?$char_traits@D@std@@@std@@$0?0@std@@QEBAPEBV?$basic_string_view@DU?$char_traits@D@std@@@2@XZ:
  0000000180003410: mov         rax,qword ptr [rcx]
  0000000180003413: ret
  0000000180003414: CC CC CC CC CC CC CC CC CC CC CC CC              ............
?_Unchecked_end@?$array@D$0BAA@@std@@QEBAPEBDXZ:
  0000000180003420: lea         rax,[rcx+100h]
  0000000180003427: ret
  0000000180003428: CC CC CC CC CC CC CC CC                          ........
?_Unchecked_end@?$basic_string_view@DU?$char_traits@D@std@@@std@@QEBAPEBDXZ:
  0000000180003430: mov         rax,qword ptr [rcx+8]
  0000000180003434: add         rax,qword ptr [rcx]
  0000000180003437: ret
  0000000180003438: CC CC CC CC CC CC CC CC                          ........
?_Unchecked_end@?$span@$$CBV?$basic_string_view@DU?$char_traits@D@std@@@std@@$0?0@std@@QEBAPEBV?$basic_string_view@DU?$char_traits@D@std@@@2@XZ:
  0000000180003440: mov         rax,qword ptr [rcx+8]
  0000000180003444: shl         rax,4
  0000000180003448: add         rax,qword ptr [rcx]
  000000018000344B: ret
  000000018000344C: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000345C: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000346C: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000347C: CC CC CC CC                                      ....
?absolute@LuaValueAccess@detail@lua@script@lux@@SAHPEAUlua_State@@H@Z:
  0000000180003480: push        rbx
  0000000180003482: sub         rsp,20h
  0000000180003486: lea         eax,[rdx+270Fh]
  000000018000348C: mov         ebx,edx
  000000018000348E: cmp         eax,270Fh
  0000000180003493: ja          00000001800034A5
  0000000180003495: call        qword ptr [__imp_lua_gettop]
  000000018000349B: inc         eax
  000000018000349D: add         eax,ebx
  000000018000349F: add         rsp,20h
  00000001800034A3: pop         rbx
  00000001800034A4: ret
  00000001800034A5: mov         eax,ebx
  00000001800034A7: add         rsp,20h
  00000001800034AB: pop         rbx
  00000001800034AC: ret
  00000001800034AD: CC CC CC                                         ...
lux::script::lua::detail::`anonymous namespace'::writeField:
  00000001800034B0: push        rbx
  00000001800034B2: sub         rsp,20h
  00000001800034B6: mov         r8,qword ptr [rdx+10h]
  00000001800034BA: mov         rbx,rcx
  00000001800034BD: mov         rdx,qword ptr [rdx+8]
  00000001800034C1: call        qword ptr [__imp_lua_pushlstring]
  00000001800034C7: mov         edx,3
  00000001800034CC: mov         rcx,rbx
  00000001800034CF: call        qword ptr [__imp_lua_pushvalue]
  00000001800034D5: mov         edx,2
  00000001800034DA: mov         rcx,rbx
  00000001800034DD: call        qword ptr [__imp_lua_rawset]
  00000001800034E3: xor         eax,eax
  00000001800034E5: add         rsp,20h
  00000001800034E9: pop         rbx
  00000001800034EA: ret
  00000001800034EB: CC CC CC CC CC                                   .....
?boolean@LuaValueAccess@detail@lua@script@lux@@SA_NPEAUlua_State@@HAEA_N@Z:
  00000001800034F0: mov         qword ptr [rsp+8],rbx
  00000001800034F5: mov         qword ptr [rsp+10h],rsi
  00000001800034FA: push        rdi
  00000001800034FB: sub         rsp,20h
  00000001800034FF: mov         rsi,r8
  0000000180003502: mov         ebx,edx
  0000000180003504: mov         rdi,rcx
  0000000180003507: call        qword ptr [__imp_lua_type]
  000000018000350D: cmp         eax,1
  0000000180003510: je          0000000180003524
  0000000180003512: xor         al,al
  0000000180003514: mov         rbx,qword ptr [rsp+30h]
  0000000180003519: mov         rsi,qword ptr [rsp+38h]
  000000018000351E: add         rsp,20h
  0000000180003522: pop         rdi
  0000000180003523: ret
  0000000180003524: mov         edx,ebx
  0000000180003526: mov         rcx,rdi
  0000000180003529: call        qword ptr [__imp_lua_toboolean]
  000000018000352F: mov         rbx,qword ptr [rsp+30h]
  0000000180003534: test        eax,eax
  0000000180003536: setne       al
  0000000180003539: mov         byte ptr [rsi],al
  000000018000353B: mov         al,1
  000000018000353D: mov         rsi,qword ptr [rsp+38h]
  0000000180003542: add         rsp,20h
  0000000180003546: pop         rdi
  0000000180003547: ret
  0000000180003548: CC CC CC CC CC CC CC CC                          ........
lux::script::lua::detail::`anonymous namespace'::checkShape:
  0000000180003550: mov         qword ptr [rsp+10h],rdx
  0000000180003555: push        r14
  0000000180003557: push        r15
  0000000180003559: sub         rsp,68h
  000000018000355D: mov         r15,rdx
  0000000180003560: mov         r14,rcx
  0000000180003563: mov         edx,2
  0000000180003568: call        qword ptr [__imp_lua_type]
  000000018000356E: cmp         eax,5
  0000000180003571: je          0000000180003583
  0000000180003573: mov         byte ptr [r15+30h],0
  0000000180003578: xor         eax,eax
  000000018000357A: add         rsp,68h
  000000018000357E: pop         r15
  0000000180003580: pop         r14
  0000000180003582: ret
  0000000180003583: mov         qword ptr [rsp+80h],rbx
  000000018000358B: mov         rcx,r14
  000000018000358E: mov         qword ptr [rsp+60h],rbp
  0000000180003593: mov         qword ptr [rsp+58h],rsi
  0000000180003598: mov         qword ptr [rsp+50h],rdi
  000000018000359D: mov         qword ptr [rsp+48h],r12
  00000001800035A2: xor         r12d,r12d
  00000001800035A5: mov         qword ptr [rsp+40h],r13
  00000001800035AA: call        qword ptr [__imp_lua_pushnil]
  00000001800035B0: mov         edx,2
  00000001800035B5: mov         rcx,r14
  00000001800035B8: call        qword ptr [__imp_lua_next]
  00000001800035BE: test        eax,eax
  00000001800035C0: je          000000018000369E
  00000001800035C6: nop         word ptr [rax+rax]
  00000001800035D0: inc         r12
  00000001800035D3: cmp         r12,qword ptr [r15+20h]
  00000001800035D7: ja          000000018000370E
  00000001800035DD: mov         edx,0FFFFFFFEh
  00000001800035E2: mov         rcx,r14
  00000001800035E5: call        qword ptr [__imp_lua_type]
  00000001800035EB: cmp         eax,4
  00000001800035EE: jne         000000018000370E
  00000001800035F4: lea         r8,[rsp+90h]
  00000001800035FC: mov         qword ptr [rsp+90h],0
  0000000180003608: mov         edx,0FFFFFFFEh
  000000018000360D: mov         rcx,r14
  0000000180003610: call        qword ptr [__imp_lua_tolstring]
  0000000180003616: mov         rbx,qword ptr [r15+18h]
  000000018000361A: xor         dil,dil
  000000018000361D: mov         rsi,qword ptr [r15+20h]
  0000000180003621: mov         r13,rax
  0000000180003624: shl         rsi,4
  0000000180003628: add         rsi,rbx
  000000018000362B: cmp         rbx,rsi
  000000018000362E: je          000000018000370E
  0000000180003634: mov         rbp,qword ptr [rsp+90h]
  000000018000363C: mov         r15d,1
  0000000180003642: cmp         qword ptr [rbx+8],rbp
  0000000180003646: jne         0000000180003660
  0000000180003648: mov         rcx,qword ptr [rbx]
  000000018000364B: mov         r8,rbp
  000000018000364E: mov         rdx,r13
  0000000180003651: call        memcmp
  0000000180003656: test        eax,eax
  0000000180003658: movzx       edi,dil
  000000018000365C: cmove       edi,r15d
  0000000180003660: add         rbx,10h
  0000000180003664: cmp         rbx,rsi
  0000000180003667: jne         0000000180003642
  0000000180003669: mov         r15,qword ptr [rsp+88h]
  0000000180003671: test        dil,dil
  0000000180003674: je          000000018000370E
  000000018000367A: mov         edx,0FFFFFFFEh
  000000018000367F: mov         rcx,r14
  0000000180003682: call        qword ptr [__imp_lua_settop]
  0000000180003688: mov         edx,2
  000000018000368D: mov         rcx,r14
  0000000180003690: call        qword ptr [__imp_lua_next]
  0000000180003696: test        eax,eax
  0000000180003698: jne         00000001800035D0
  000000018000369E: mov         rbx,qword ptr [r15+18h]
  00000001800036A2: mov         rdi,qword ptr [r15+20h]
  00000001800036A6: shl         rdi,4
  00000001800036AA: add         rdi,rbx
  00000001800036AD: movaps      xmmword ptr [rsp+30h],xmm6
  00000001800036B2: cmp         rbx,rdi
  00000001800036B5: je          000000018000373C
  00000001800036BB: nop         dword ptr [rax+rax]
  00000001800036C0: movups      xmm6,xmmword ptr [rbx]
  00000001800036C3: mov         r8,qword ptr [rbx+8]
  00000001800036C7: mov         rcx,r14
  00000001800036CA: movq        rdx,xmm6
  00000001800036CF: call        qword ptr [__imp_lua_pushlstring]
  00000001800036D5: mov         edx,2
  00000001800036DA: mov         rcx,r14
  00000001800036DD: call        qword ptr [__imp_lua_rawget]
  00000001800036E3: mov         edx,0FFFFFFFFh
  00000001800036E8: mov         rcx,r14
  00000001800036EB: call        qword ptr [__imp_lua_type]
  00000001800036F1: test        eax,eax
  00000001800036F3: je          000000018000371C
  00000001800036F5: mov         edx,0FFFFFFFEh
  00000001800036FA: mov         rcx,r14
  00000001800036FD: call        qword ptr [__imp_lua_settop]
  0000000180003703: add         rbx,10h
  0000000180003707: cmp         rbx,rdi
  000000018000370A: jne         00000001800036C0
  000000018000370C: jmp         000000018000373C
  000000018000370E: mov         rax,qword ptr [r15+28h]
  0000000180003712: mov         byte ptr [rax],3
  0000000180003715: mov         byte ptr [r15+30h],0
  000000018000371A: jmp         0000000180003741
  000000018000371C: mov         rax,qword ptr [r15+28h]
  0000000180003720: lea         rdx,[rsp+20h]
  0000000180003725: movdqa      xmmword ptr [rsp+20h],xmm6
  000000018000372B: mov         byte ptr [rax],2
  000000018000372E: mov         rcx,qword ptr [r15+28h]
  0000000180003732: call        @ILT+760(?prepend@LuaValueFailure@lua@script@lux@@QEAAXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z)
  0000000180003737: mov         byte ptr [r15+30h],0
  000000018000373C: movaps      xmm6,xmmword ptr [rsp+30h]
  0000000180003741: mov         r12,qword ptr [rsp+48h]
  0000000180003746: xor         eax,eax
  0000000180003748: mov         rdi,qword ptr [rsp+50h]
  000000018000374D: mov         rsi,qword ptr [rsp+58h]
  0000000180003752: mov         rbp,qword ptr [rsp+60h]
  0000000180003757: mov         rbx,qword ptr [rsp+80h]
  000000018000375F: mov         r13,qword ptr [rsp+40h]
  0000000180003764: add         rsp,68h
  0000000180003768: pop         r15
  000000018000376A: pop         r14
  000000018000376C: ret
  000000018000376D: CC CC CC                                         ...
?failure@LuaValueAccess@detail@lua@script@lux@@SAHPEAUlua_State@@PEBD@Z:
  0000000180003770: mov         qword ptr [rsp+8],rbx
  0000000180003775: push        rdi
  0000000180003776: sub         rsp,70h
  000000018000377A: lea         rax,[180003930h]
  0000000180003781: mov         byte ptr [rsp+60h],1
  0000000180003786: mov         qword ptr [rsp+30h],rax
  000000018000378B: xorps       xmm0,xmm0
  000000018000378E: xor         eax,eax
  0000000180003790: mov         rdi,rcx
  0000000180003793: movups      xmmword ptr [rsp+48h],xmm0
  0000000180003798: mov         rcx,rdx
  000000018000379B: mov         qword ptr [rsp+48h],rax
  00000001800037A0: mov         qword ptr [rsp+50h],rax
  00000001800037A5: mov         rbx,rdx
  00000001800037A8: mov         qword ptr [rsp+58h],rax
  00000001800037AD: mov         dword ptr [rsp+64h],eax
  00000001800037B1: call        strlen
  00000001800037B6: xor         r9d,r9d
  00000001800037B9: mov         qword ptr [rsp+38h],rbx
  00000001800037BE: xor         r8d,r8d
  00000001800037C1: mov         qword ptr [rsp+40h],rax
  00000001800037C6: lea         rdx,[rsp+30h]
  00000001800037CB: mov         dword ptr [rsp+20h],2
  00000001800037D3: mov         rcx,rdi
  00000001800037D6: call        0000000180003E40
  00000001800037DB: test        al,al
  00000001800037DD: jne         0000000180003813
  00000001800037DF: mov         edx,2
  00000001800037E4: mov         rcx,rdi
  00000001800037E7: call        qword ptr [__imp_lua_checkstack]
  00000001800037ED: test        eax,eax
  00000001800037EF: jne         00000001800037FF
  00000001800037F1: mov         rbx,qword ptr [rsp+80h]
  00000001800037F9: add         rsp,70h
  00000001800037FD: pop         rdi
  00000001800037FE: ret
  00000001800037FF: xor         edx,edx
  0000000180003801: mov         rcx,rdi
  0000000180003804: call        qword ptr [__imp_lua_pushboolean]
  000000018000380A: mov         rcx,rdi
  000000018000380D: call        qword ptr [__imp_lua_pushnil]
  0000000180003813: mov         rbx,qword ptr [rsp+80h]
  000000018000381B: mov         eax,2
  0000000180003820: add         rsp,70h
  0000000180003824: pop         rdi
  0000000180003825: ret
  0000000180003826: CC CC CC CC CC CC CC CC CC CC                    ..........
?initialize@LuaValueAccess@detail@lua@script@lux@@SA_NPEAUlua_State@@@Z:
  0000000180003830: push        rsi
  0000000180003832: sub         rsp,20h
  0000000180003836: mov         rsi,rcx
  0000000180003839: test        rcx,rcx
  000000018000383C: je          0000000180003897
  000000018000383E: mov         edx,2
  0000000180003843: call        qword ptr [__imp_lua_checkstack]
  0000000180003849: test        eax,eax
  000000018000384B: je          0000000180003897
  000000018000384D: mov         qword ptr [rsp+30h],rbx
  0000000180003852: mov         rcx,rsi
  0000000180003855: mov         qword ptr [rsp+38h],rdi
  000000018000385A: call        qword ptr [__imp_lua_gettop]
  0000000180003860: xor         r8d,r8d
  0000000180003863: lea         rdx,[180002B80h]
  000000018000386A: mov         rcx,rsi
  000000018000386D: mov         edi,eax
  000000018000386F: call        qword ptr [__imp_lua_cpcall]
  0000000180003875: mov         edx,edi
  0000000180003877: mov         rcx,rsi
  000000018000387A: mov         ebx,eax
  000000018000387C: call        qword ptr [__imp_lua_settop]
  0000000180003882: mov         rdi,qword ptr [rsp+38h]
  0000000180003887: test        ebx,ebx
  0000000180003889: mov         rbx,qword ptr [rsp+30h]
  000000018000388E: sete        al
  0000000180003891: add         rsp,20h
  0000000180003895: pop         rsi
  0000000180003896: ret
  0000000180003897: xor         al,al
  0000000180003899: add         rsp,20h
  000000018000389D: pop         rsi
  000000018000389E: ret
  000000018000389F: CC                                               .
?pushNumber@LuaValueAccess@detail@lua@script@lux@@SA_NPEAUlua_State@@N@Z:
  00000001800038A0: push        rbx
  00000001800038A2: sub         rsp,30h
  00000001800038A6: movaps      xmmword ptr [rsp+20h],xmm6
  00000001800038AB: mov         edx,1
  00000001800038B0: movaps      xmm6,xmm1
  00000001800038B3: mov         rbx,rcx
  00000001800038B6: call        qword ptr [__imp_lua_checkstack]
  00000001800038BC: test        eax,eax
  00000001800038BE: jne         00000001800038CB
  00000001800038C0: movaps      xmm6,xmmword ptr [rsp+20h]
  00000001800038C5: add         rsp,30h
  00000001800038C9: pop         rbx
  00000001800038CA: ret
  00000001800038CB: movaps      xmm1,xmm6
  00000001800038CE: mov         rcx,rbx
  00000001800038D1: call        qword ptr [__imp_lua_pushnumber]
  00000001800038D7: movaps      xmm6,xmmword ptr [rsp+20h]
  00000001800038DC: mov         al,1
  00000001800038DE: add         rsp,30h
  00000001800038E2: pop         rbx
  00000001800038E3: ret
  00000001800038E4: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800038F4: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003904: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003914: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003924: CC CC CC CC CC CC CC CC CC CC CC CC              ............
lux::script::lua::detail::`anonymous namespace'::failureValues:
  0000000180003930: mov         qword ptr [rsp+8],rbx
  0000000180003935: push        rdi
  0000000180003936: sub         rsp,20h
  000000018000393A: mov         rbx,rdx
  000000018000393D: mov         rdi,rcx
  0000000180003940: xor         edx,edx
  0000000180003942: call        qword ptr [__imp_lua_pushboolean]
  0000000180003948: mov         r8,qword ptr [rbx+10h]
  000000018000394C: mov         rcx,rdi
  000000018000394F: mov         rdx,qword ptr [rbx+8]
  0000000180003953: call        qword ptr [__imp_lua_pushlstring]
  0000000180003959: mov         rbx,qword ptr [rsp+30h]
  000000018000395E: mov         eax,2
  0000000180003963: add         rsp,20h
  0000000180003967: pop         rdi
  0000000180003968: ret
  0000000180003969: CC CC CC CC CC CC CC                             .......
?table@LuaValueAccess@detail@lua@script@lux@@SA_NPEAUlua_State@@H@Z:
  0000000180003970: mov         r11,rsp
  0000000180003973: sub         rsp,78h
  0000000180003977: lea         rax,[180003B30h]
  000000018000397E: mov         dword ptr [rsp+20h],1
  0000000180003986: mov         qword ptr [r11-48h],rax
  000000018000398A: xorps       xmm0,xmm0
  000000018000398D: xor         eax,eax
  000000018000398F: xor         r9d,r9d
  0000000180003992: mov         qword ptr [r11-40h],rax
  0000000180003996: xor         r8d,r8d
  0000000180003999: mov         qword ptr [r11-38h],rax
  000000018000399D: movups      xmmword ptr [rsp+48h],xmm0
  00000001800039A2: mov         qword ptr [r11-30h],rax
  00000001800039A6: mov         qword ptr [r11-28h],rax
  00000001800039AA: mov         qword ptr [r11-20h],rax
  00000001800039AE: mov         dword ptr [rsp+64h],edx
  00000001800039B2: lea         rdx,[r11-48h]
  00000001800039B6: mov         byte ptr [rsp+60h],1
  00000001800039BB: call        0000000180003E40
  00000001800039C0: add         rsp,78h
  00000001800039C4: ret
  00000001800039C5: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800039D5: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800039E5: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800039F5: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003A05: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003A15: CC CC CC CC CC CC CC CC CC CC CC                 ...........
?field@LuaValueAccess@detail@lua@script@lux@@SA_NPEAUlua_State@@HV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z:
  0000000180003A20: sub         rsp,78h
  0000000180003A24: xorps       xmm0,xmm0
  0000000180003A27: mov         byte ptr [rsp+60h],1
  0000000180003A2C: movups      xmmword ptr [rsp+48h],xmm0
  0000000180003A31: lea         rax,[180002A30h]
  0000000180003A38: xor         r9d,r9d
  0000000180003A3B: movups      xmm0,xmmword ptr [r8]
  0000000180003A3F: mov         qword ptr [rsp+30h],rax
  0000000180003A44: mov         r8d,edx
  0000000180003A47: xor         eax,eax
  0000000180003A49: mov         dword ptr [rsp+20h],1
  0000000180003A51: lea         rdx,[rsp+30h]
  0000000180003A56: mov         qword ptr [rsp+48h],rax
  0000000180003A5B: movups      xmmword ptr [rsp+38h],xmm0
  0000000180003A60: mov         qword ptr [rsp+50h],rax
  0000000180003A65: mov         qword ptr [rsp+58h],rax
  0000000180003A6A: mov         dword ptr [rsp+64h],eax
  0000000180003A6E: call        0000000180003E40
  0000000180003A73: add         rsp,78h
  0000000180003A77: ret
  0000000180003A78: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003A88: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003A98: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003AA8: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003AB8: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003AC8: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003AD8: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003AE8: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003AF8: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003B08: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003B18: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003B28: CC CC CC CC CC CC CC CC                          ........
lux::script::lua::detail::`anonymous namespace'::makeTable:
  0000000180003B30: sub         rsp,28h
  0000000180003B34: mov         r8d,dword ptr [rdx+34h]
  0000000180003B38: xor         edx,edx
  0000000180003B3A: call        qword ptr [__imp_lua_createtable]
  0000000180003B40: mov         eax,1
  0000000180003B45: add         rsp,28h
  0000000180003B49: ret
  0000000180003B4A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003B5A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003B6A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003B7A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003B8A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003B9A: CC CC CC CC CC CC                                ......
?number@LuaValueAccess@detail@lua@script@lux@@SA_NPEAUlua_State@@HAEAN@Z:
  0000000180003BA0: mov         qword ptr [rsp+8],rbx
  0000000180003BA5: mov         qword ptr [rsp+10h],rsi
  0000000180003BAA: push        rdi
  0000000180003BAB: sub         rsp,20h
  0000000180003BAF: mov         rsi,r8
  0000000180003BB2: mov         ebx,edx
  0000000180003BB4: mov         rdi,rcx
  0000000180003BB7: call        qword ptr [__imp_lua_type]
  0000000180003BBD: cmp         eax,3
  0000000180003BC0: je          0000000180003BD4
  0000000180003BC2: xor         al,al
  0000000180003BC4: mov         rbx,qword ptr [rsp+30h]
  0000000180003BC9: mov         rsi,qword ptr [rsp+38h]
  0000000180003BCE: add         rsp,20h
  0000000180003BD2: pop         rdi
  0000000180003BD3: ret
  0000000180003BD4: mov         edx,ebx
  0000000180003BD6: mov         rcx,rdi
  0000000180003BD9: call        qword ptr [__imp_lua_tonumber]
  0000000180003BDF: mov         rbx,qword ptr [rsp+30h]
  0000000180003BE4: mov         al,1
  0000000180003BE6: movsd       mmword ptr [rsi],xmm0
  0000000180003BEA: mov         rsi,qword ptr [rsp+38h]
  0000000180003BEF: add         rsp,20h
  0000000180003BF3: pop         rdi
  0000000180003BF4: ret
  0000000180003BF5: CC CC CC CC CC CC CC CC CC CC CC                 ...........
?prepend@LuaValueFailure@lua@script@lux@@QEAAXV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z:
  0000000180003C00: sub         rsp,108h
  0000000180003C07: mov         r9,rcx
  0000000180003C0A: lea         rax,[rcx+1]
  0000000180003C0E: mov         ecx,2
  0000000180003C13: lea         r8,[rsp]
  0000000180003C17: mov         r10,rdx
  0000000180003C1A: nop         word ptr [rax+rax]
  0000000180003C20: lea         r8,[r8+80h]
  0000000180003C27: movups      xmm0,xmmword ptr [rax]
  0000000180003C2A: movups      xmm1,xmmword ptr [rax+10h]
  0000000180003C2E: lea         rax,[rax+80h]
  0000000180003C35: movups      xmmword ptr [r8-80h],xmm0
  0000000180003C3A: movups      xmm0,xmmword ptr [rax-60h]
  0000000180003C3E: movups      xmmword ptr [r8-70h],xmm1
  0000000180003C43: movups      xmm1,xmmword ptr [rax-50h]
  0000000180003C47: movups      xmmword ptr [r8-60h],xmm0
  0000000180003C4C: movups      xmm0,xmmword ptr [rax-40h]
  0000000180003C50: movups      xmmword ptr [r8-50h],xmm1
  0000000180003C55: movups      xmm1,xmmword ptr [rax-30h]
  0000000180003C59: movups      xmmword ptr [r8-40h],xmm0
  0000000180003C5E: movups      xmm0,xmmword ptr [rax-20h]
  0000000180003C62: movups      xmmword ptr [r8-30h],xmm1
  0000000180003C67: movups      xmm1,xmmword ptr [rax-10h]
  0000000180003C6B: movups      xmmword ptr [r8-20h],xmm0
  0000000180003C70: movups      xmmword ptr [r8-10h],xmm1
  0000000180003C75: sub         rcx,1
  0000000180003C79: jne         0000000180003C20
  0000000180003C7B: mov         rdx,qword ptr [rdx]
  0000000180003C7E: xor         eax,eax
  0000000180003C80: mov         r10,qword ptr [r10+8]
  0000000180003C84: add         r10,rdx
  0000000180003C87: cmp         rdx,r10
  0000000180003C8A: je          0000000180003CB7
  0000000180003C8C: mov         r8,r9
  0000000180003C8F: sub         r8,rdx
  0000000180003C92: cmp         rax,0FFh
  0000000180003C98: je          0000000180003CAF
  0000000180003C9A: movzx       ecx,byte ptr [rdx]
  0000000180003C9D: inc         rax
  0000000180003CA0: mov         byte ptr [rdx+r8+1],cl
  0000000180003CA5: inc         rdx
  0000000180003CA8: cmp         rdx,r10
  0000000180003CAB: jne         0000000180003C92
  0000000180003CAD: jmp         0000000180003CB7
  0000000180003CAF: mov         byte ptr [r9+101h],1
  0000000180003CB7: cmp         byte ptr [rsp],0
  0000000180003CBB: je          0000000180003CCE
  0000000180003CBD: cmp         rax,0FFh
  0000000180003CC3: jae         0000000180003CCE
  0000000180003CC5: mov         byte ptr [r9+rax+1],2Eh
  0000000180003CCB: inc         rax
  0000000180003CCE: lea         rdx,[r9+1]
  0000000180003CD2: add         rdx,rax
  0000000180003CD5: lea         rcx,[rsp]
  0000000180003CD9: nop         dword ptr [rax]
  0000000180003CE0: movzx       r8d,byte ptr [rcx]
  0000000180003CE4: test        r8b,r8b
  0000000180003CE7: je          0000000180003D20
  0000000180003CE9: cmp         rax,0FFh
  0000000180003CEF: je          0000000180003D18
  0000000180003CF1: mov         byte ptr [rdx],r8b
  0000000180003CF4: inc         rax
  0000000180003CF7: inc         rdx
  0000000180003CFA: lea         r8,[rsp+100h]
  0000000180003D02: inc         rcx
  0000000180003D05: cmp         rcx,r8
  0000000180003D08: jne         0000000180003CE0
  0000000180003D0A: mov         byte ptr [r9+rax+1],0
  0000000180003D10: add         rsp,108h
  0000000180003D17: ret
  0000000180003D18: mov         byte ptr [r9+101h],1
  0000000180003D20: mov         byte ptr [r9+rax+1],0
  0000000180003D26: add         rsp,108h
  0000000180003D2D: ret
  0000000180003D2E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003D3E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003D4E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003D5E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003D6E: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003D7E: CC CC                                            ..
?pushBoolean@LuaValueAccess@detail@lua@script@lux@@SA_NPEAUlua_State@@_N@Z:
  0000000180003D80: mov         qword ptr [rsp+8],rbx
  0000000180003D85: push        rdi
  0000000180003D86: sub         rsp,20h
  0000000180003D8A: movzx       edi,dl
  0000000180003D8D: mov         rbx,rcx
  0000000180003D90: mov         edx,1
  0000000180003D95: call        qword ptr [__imp_lua_checkstack]
  0000000180003D9B: test        eax,eax
  0000000180003D9D: jne         0000000180003DAA
  0000000180003D9F: mov         rbx,qword ptr [rsp+30h]
  0000000180003DA4: add         rsp,20h
  0000000180003DA8: pop         rdi
  0000000180003DA9: ret
  0000000180003DAA: mov         edx,edi
  0000000180003DAC: mov         rcx,rbx
  0000000180003DAF: call        qword ptr [__imp_lua_pushboolean]
  0000000180003DB5: mov         rbx,qword ptr [rsp+30h]
  0000000180003DBA: mov         al,1
  0000000180003DBC: add         rsp,20h
  0000000180003DC0: pop         rdi
  0000000180003DC1: ret
  0000000180003DC2: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003DD2: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003DE2: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003DF2: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003E02: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003E12: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003E22: CC CC CC CC CC CC CC CC CC CC CC CC CC CC        ..............
?restoreScratch@LuaValueAccess@detail@lua@script@lux@@SAXPEAUlua_State@@H@Z:
  0000000180003E30: jmp         qword ptr [__imp_lua_settop]
  0000000180003E37: CC CC CC CC CC CC CC CC CC                       .........
lux::script::lua::detail::`anonymous namespace'::run:
  0000000180003E40: mov         qword ptr [rsp+10h],rbx
  0000000180003E45: mov         qword ptr [rsp+18h],rbp
  0000000180003E4A: push        rsi
  0000000180003E4B: push        r14
  0000000180003E4D: push        r15
  0000000180003E4F: sub         rsp,20h
  0000000180003E53: mov         esi,r9d
  0000000180003E56: mov         r14d,r8d
  0000000180003E59: mov         rbp,rdx
  0000000180003E5C: mov         rbx,rcx
  0000000180003E5F: call        qword ptr [__imp_lua_gettop]
  0000000180003E65: mov         edx,5
  0000000180003E6A: mov         rcx,rbx
  0000000180003E6D: mov         r15d,eax
  0000000180003E70: call        qword ptr [__imp_lua_checkstack]
  0000000180003E76: test        eax,eax
  0000000180003E78: je          0000000180003F24
  0000000180003E7E: lea         rdx,[18000E474h]
  0000000180003E85: mov         rcx,rbx
  0000000180003E88: call        qword ptr [__imp_lua_pushlightuserdata]
  0000000180003E8E: mov         edx,0FFFFD8F0h
  0000000180003E93: mov         rcx,rbx
  0000000180003E96: call        qword ptr [__imp_lua_rawget]
  0000000180003E9C: mov         edx,0FFFFFFFFh
  0000000180003EA1: mov         rcx,rbx
  0000000180003EA4: call        qword ptr [__imp_lua_type]
  0000000180003EAA: mov         rcx,rbx
  0000000180003EAD: cmp         eax,6
  0000000180003EB0: je          0000000180003EB9
  0000000180003EB2: mov         edx,0FFFFFFFEh
  0000000180003EB7: jmp         0000000180003F1E
  0000000180003EB9: mov         rdx,rbp
  0000000180003EBC: mov         qword ptr [rsp+40h],rdi
  0000000180003EC1: call        qword ptr [__imp_lua_pushlightuserdata]
  0000000180003EC7: mov         edi,1
  0000000180003ECC: test        r14d,r14d
  0000000180003ECF: je          0000000180003EE2
  0000000180003ED1: mov         edx,r14d
  0000000180003ED4: mov         rcx,rbx
  0000000180003ED7: call        qword ptr [__imp_lua_pushvalue]
  0000000180003EDD: mov         edi,2
  0000000180003EE2: test        esi,esi
  0000000180003EE4: je          0000000180003EF3
  0000000180003EE6: mov         edx,esi
  0000000180003EE8: mov         rcx,rbx
  0000000180003EEB: call        qword ptr [__imp_lua_pushvalue]
  0000000180003EF1: inc         edi
  0000000180003EF3: mov         r8d,dword ptr [rsp+60h]
  0000000180003EF8: xor         r9d,r9d
  0000000180003EFB: mov         edx,edi
  0000000180003EFD: mov         rcx,rbx
  0000000180003F00: call        qword ptr [__imp_lua_pcall]
  0000000180003F06: mov         rdi,qword ptr [rsp+40h]
  0000000180003F0B: test        eax,eax
  0000000180003F0D: jne         0000000180003F18
  0000000180003F0F: cmp         byte ptr [rbp+30h],al
  0000000180003F12: je          0000000180003F18
  0000000180003F14: mov         al,1
  0000000180003F16: jmp         0000000180003F26
  0000000180003F18: mov         edx,r15d
  0000000180003F1B: mov         rcx,rbx
  0000000180003F1E: call        qword ptr [__imp_lua_settop]
  0000000180003F24: xor         al,al
  0000000180003F26: mov         rbx,qword ptr [rsp+48h]
  0000000180003F2B: mov         rbp,qword ptr [rsp+50h]
  0000000180003F30: add         rsp,20h
  0000000180003F34: pop         r15
  0000000180003F36: pop         r14
  0000000180003F38: pop         rsi
  0000000180003F39: ret
  0000000180003F3A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003F4A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003F5A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003F6A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003F7A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003F8A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003F9A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003FAA: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003FBA: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003FCA: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003FDA: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003FEA: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180003FFA: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000400A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000401A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000402A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000403A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000404A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000405A: CC CC CC CC CC CC                                ......
?setField@LuaValueAccess@detail@lua@script@lux@@SA_NPEAUlua_State@@HV?$basic_string_view@DU?$char_traits@D@std@@@std@@@Z:
  0000000180004060: mov         qword ptr [rsp+8],rbx
  0000000180004065: mov         qword ptr [rsp+10h],rsi
  000000018000406A: push        rdi
  000000018000406B: sub         rsp,70h
  000000018000406F: xor         esi,esi
  0000000180004071: mov         byte ptr [rsp+60h],1
  0000000180004076: xorps       xmm0,xmm0
  0000000180004079: mov         qword ptr [rsp+58h],rsi
  000000018000407E: movups      xmmword ptr [rsp+48h],xmm0
  0000000180004083: lea         rax,[1800034B0h]
  000000018000408A: mov         ebx,edx
  000000018000408C: movups      xmm0,xmmword ptr [r8]
  0000000180004090: mov         rdi,rcx
  0000000180004093: mov         qword ptr [rsp+30h],rax
  0000000180004098: mov         qword ptr [rsp+48h],rsi
  000000018000409D: movups      xmmword ptr [rsp+38h],xmm0
  00000001800040A2: mov         qword ptr [rsp+50h],rsi
  00000001800040A7: mov         dword ptr [rsp+64h],esi
  00000001800040AB: call        qword ptr [__imp_lua_gettop]
  00000001800040B1: mov         r8d,ebx
  00000001800040B4: mov         dword ptr [rsp+20h],esi
  00000001800040B8: mov         r9d,eax
  00000001800040BB: lea         rdx,[rsp+30h]
  00000001800040C0: mov         rcx,rdi
  00000001800040C3: call        0000000180003E40
  00000001800040C8: lea         r11,[rsp+70h]
  00000001800040CD: mov         rbx,qword ptr [r11+10h]
  00000001800040D1: mov         rsi,qword ptr [r11+18h]
  00000001800040D5: mov         rsp,r11
  00000001800040D8: pop         rdi
  00000001800040D9: ret
  00000001800040DA: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800040EA: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800040FA: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000410A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000411A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000412A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000413A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000414A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000415A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000416A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000417A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000418A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000419A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800041AA: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800041BA: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800041CA: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800041DA: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800041EA: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800041FA: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000420A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000421A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000422A: CC CC CC CC CC CC                                ......
?size@?$array@D$0BAA@@std@@QEBA_KXZ:
  0000000180004230: mov         eax,100h
  0000000180004235: ret
  0000000180004236: CC CC CC CC CC CC CC CC CC CC                    ..........
?size@?$span@$$CBV?$basic_string_view@DU?$char_traits@D@std@@@std@@$0?0@std@@QEBA_KXZ:
  0000000180004240: mov         rax,qword ptr [rcx+8]
  0000000180004244: ret
  0000000180004245: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004255: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004265: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004275: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004285: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004295: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800042A5: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800042B5: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800042C5: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800042D5: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800042E5: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800042F5: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004305: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004315: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004325: CC CC CC CC CC CC CC CC CC CC CC                 ...........
?top@LuaValueAccess@detail@lua@script@lux@@SAHPEAUlua_State@@@Z:
  0000000180004330: jmp         qword ptr [__imp_lua_gettop]
  0000000180004337: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004347: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004357: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004367: CC CC CC CC CC CC CC CC CC                       .........
?value@?$unexpected@ULuaValueFailure@lua@script@lux@@@tl@@QEGAAAEAULuaValueFailure@lua@script@lux@@XZ:
  0000000180004370: mov         rax,rcx
  0000000180004373: ret
  0000000180004374: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004384: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004394: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800043A4: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800043B4: CC CC CC CC CC                                   .....
lua_close:
  00000001800043B9: jmp         qword ptr [__imp_lua_close]
lua_gettop:
  00000001800043BF: jmp         qword ptr [__imp_lua_gettop]
lua_settop:
  00000001800043C5: jmp         qword ptr [__imp_lua_settop]
lua_remove:
  00000001800043CB: jmp         qword ptr [__imp_lua_remove]
lua_tolstring:
  00000001800043D1: jmp         qword ptr [__imp_lua_tolstring]
lua_touserdata:
  00000001800043D7: jmp         qword ptr [__imp_lua_touserdata]
lua_pushcclosure:
  00000001800043DD: jmp         qword ptr [__imp_lua_pushcclosure]
lua_pushlightuserdata:
  00000001800043E3: jmp         qword ptr [__imp_lua_pushlightuserdata]
lua_rawgeti:
  00000001800043E9: jmp         qword ptr [__imp_lua_rawgeti]
lua_pcall:
  00000001800043EF: jmp         qword ptr [__imp_lua_pcall]
luaL_ref:
  00000001800043F5: jmp         qword ptr [__imp_luaL_ref]
luaL_unref:
  00000001800043FB: jmp         qword ptr [__imp_luaL_unref]
luaL_newstate:
  0000000180004401: jmp         qword ptr [__imp_luaL_newstate]
luaL_loadbufferx:
  0000000180004407: jmp         qword ptr [__imp_luaL_loadbufferx]
luaL_traceback:
  000000018000440D: jmp         qword ptr [__imp_luaL_traceback]
luaL_openlibs:
  0000000180004413: jmp         qword ptr [__imp_luaL_openlibs]
lua_pushvalue:
  0000000180004419: jmp         qword ptr [__imp_lua_pushvalue]
lua_setfenv:
  000000018000441F: jmp         qword ptr [__imp_lua_setfenv]
lua_yield:
  0000000180004425: jmp         qword ptr [__imp_lua_yield]
lua_resume:
  000000018000442B: jmp         qword ptr [__imp_lua_resume]
luaL_error:
  0000000180004431: jmp         qword ptr [__imp_luaL_error]
luaJIT_setmode:
  0000000180004437: jmp         qword ptr [__imp_luaJIT_setmode]
lua_checkstack:
  000000018000443D: jmp         qword ptr [__imp_lua_checkstack]
lua_type:
  0000000180004443: jmp         qword ptr [__imp_lua_type]
lua_tonumber:
  0000000180004449: jmp         qword ptr [__imp_lua_tonumber]
lua_toboolean:
  000000018000444F: jmp         qword ptr [__imp_lua_toboolean]
lua_pushnil:
  0000000180004455: jmp         qword ptr [__imp_lua_pushnil]
lua_pushnumber:
  000000018000445B: jmp         qword ptr [__imp_lua_pushnumber]
lua_pushlstring:
  0000000180004461: jmp         qword ptr [__imp_lua_pushlstring]
lua_pushboolean:
  0000000180004467: jmp         qword ptr [__imp_lua_pushboolean]
lua_rawget:
  000000018000446D: jmp         qword ptr [__imp_lua_rawget]
lua_createtable:
  0000000180004473: jmp         qword ptr [__imp_lua_createtable]
lua_rawset:
  0000000180004479: jmp         qword ptr [__imp_lua_rawset]
lua_cpcall:
  000000018000447F: jmp         qword ptr [__imp_lua_cpcall]
lua_next:
  0000000180004485: jmp         qword ptr [__imp_lua_next]
  000000018000448B: CC                                               .
??2@YAPEAX_K@Z:
  000000018000448C: push        rbx
  000000018000448E: sub         rsp,20h
  0000000180004492: mov         rbx,rcx
  0000000180004495: jmp         00000001800044A6
  0000000180004497: mov         rcx,rbx
  000000018000449A: call        _callnewh
  000000018000449F: test        eax,eax
  00000001800044A1: je          00000001800044B6
  00000001800044A3: mov         rcx,rbx
  00000001800044A6: call        malloc
  00000001800044AB: test        rax,rax
  00000001800044AE: je          0000000180004497
  00000001800044B0: add         rsp,20h
  00000001800044B4: pop         rbx
  00000001800044B5: ret
  00000001800044B6: cmp         rbx,0FFFFFFFFFFFFFFFFh
  00000001800044BA: je          00000001800044C2
  00000001800044BC: call        @ILT+290(?__scrt_throw_std_bad_alloc@@YAXXZ)
  00000001800044C1: int         3
  00000001800044C2: call        @ILT+1140(?__scrt_throw_std_bad_array_new_length@@YAXXZ)
  00000001800044C7: int         3
  00000001800044C8: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
??3@YAXPEAX_K@Z:
  00000001800044D8: jmp         @ILT+1000(??3@YAXPEAX@Z)
  00000001800044DD: CC CC CC                                         ...
__GSHandlerCheck:
  00000001800044E0: sub         rsp,28h
  00000001800044E4: mov         r8,qword ptr [r9+38h]
  00000001800044E8: mov         rcx,rdx
  00000001800044EB: mov         rdx,r9
  00000001800044EE: call        @ILT+225(__GSHandlerCheckCommon)
  00000001800044F3: mov         eax,1
  00000001800044F8: add         rsp,28h
  00000001800044FC: ret
  00000001800044FD: CC CC CC CC CC CC CC                             .......
__GSHandlerCheckCommon:
  0000000180004504: push        rbx
  0000000180004506: mov         r11d,dword ptr [r8]
  0000000180004509: mov         rbx,rdx
  000000018000450C: and         r11d,0FFFFFFF8h
  0000000180004510: mov         r9,rcx
  0000000180004513: test        byte ptr [r8],4
  0000000180004517: mov         r10,rcx
  000000018000451A: je          000000018000452F
  000000018000451C: mov         eax,dword ptr [r8+8]
  0000000180004520: movsxd      r10,dword ptr [r8+4]
  0000000180004524: neg         eax
  0000000180004526: add         r10,rcx
  0000000180004529: movsxd      rcx,eax
  000000018000452C: and         r10,rcx
  000000018000452F: movsxd      rax,r11d
  0000000180004532: mov         rdx,qword ptr [rax+r10]
  0000000180004536: mov         rax,qword ptr [rbx+10h]
  000000018000453A: mov         ecx,dword ptr [rax+8]
  000000018000453D: mov         rax,qword ptr [rbx+8]
  0000000180004541: test        byte ptr [rcx+rax+3],0Fh
  0000000180004546: je          0000000180004558
  0000000180004548: movzx       eax,byte ptr [rcx+rax+3]
  000000018000454D: mov         ecx,0FFFFFFF0h
  0000000180004552: and         rax,rcx
  0000000180004555: add         r9,rax
  0000000180004558: xor         r9,rdx
  000000018000455B: mov         rcx,r9
  000000018000455E: pop         rbx
  000000018000455F: jmp         @ILT+525(__security_check_cookie)
  0000000180004564: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004574: CC CC CC CC CC CC CC CC CC CC CC CC              ............
  0000000180004580: int         3
  0000000180004581: int         3
  0000000180004582: int         3
  0000000180004583: int         3
  0000000180004584: int         3
  0000000180004585: int         3
  0000000180004586: nop         word ptr [rax+rax]
__security_check_cookie:
  0000000180004590: cmp         rcx,qword ptr [__security_cookie]
  0000000180004597: jne         00000001800045A9
  0000000180004599: rol         rcx,10h
  000000018000459D: test        cx,0FFFFh
  00000001800045A2: jne         00000001800045A5
  00000001800045A4: ret
  00000001800045A5: ror         rcx,10h
  00000001800045A9: jmp         @ILT+75(__report_gsfailure)
  00000001800045AE: CC CC CC CC CC CC CC CC CC CC CC CC CC CC        ..............
dllmain_crt_dispatch:
  00000001800045BC: sub         rsp,28h
  00000001800045C0: test        edx,edx
  00000001800045C2: je          00000001800045FD
  00000001800045C4: sub         edx,1
  00000001800045C7: je          00000001800045F1
  00000001800045C9: sub         edx,1
  00000001800045CC: je          00000001800045E4
  00000001800045CE: cmp         edx,1
  00000001800045D1: je          00000001800045DD
  00000001800045D3: mov         eax,1
  00000001800045D8: add         rsp,28h
  00000001800045DC: ret
  00000001800045DD: call        @ILT+1160(__scrt_dllmain_crt_thread_detach)
  00000001800045E2: jmp         00000001800045E9
  00000001800045E4: call        @ILT+860(__scrt_dllmain_crt_thread_attach)
  00000001800045E9: movzx       eax,al
  00000001800045EC: add         rsp,28h
  00000001800045F0: ret
  00000001800045F1: mov         rdx,r8
  00000001800045F4: add         rsp,28h
  00000001800045F8: jmp         0000000180004620
  00000001800045FD: test        r8,r8
  0000000180004600: setne       cl
  0000000180004603: add         rsp,28h
  0000000180004607: jmp         000000018000477C
  000000018000460C: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000461C: CC CC CC CC                                      ....
dllmain_crt_process_attach:
  0000000180004620: mov         qword ptr [rsp+8],rbx
  0000000180004625: mov         qword ptr [rsp+10h],rsi
  000000018000462A: mov         qword ptr [rsp+20h],rdi
  000000018000462F: push        r14
  0000000180004631: sub         rsp,20h
  0000000180004635: mov         rsi,rdx
  0000000180004638: mov         r14,rcx
  000000018000463B: xor         ecx,ecx
  000000018000463D: call        @ILT+1115(__scrt_initialize_crt)
  0000000180004642: test        al,al
  0000000180004644: je          0000000180004712
  000000018000464A: call        @ILT+995(__scrt_acquire_startup_lock)
  000000018000464F: mov         bl,al
  0000000180004651: mov         byte ptr [rsp+40h],al
  0000000180004655: mov         dil,1
  0000000180004658: cmp         dword ptr [__scrt_current_native_startup_state],0
  000000018000465F: jne         000000018000472A
  0000000180004665: mov         dword ptr [__scrt_current_native_startup_state],1
  000000018000466F: call        @ILT+50(__scrt_dllmain_before_initialize_c)
  0000000180004674: test        al,al
  0000000180004676: je          00000001800046C7
  0000000180004678: call        @ILT+635(_RTC_Initialize)
  000000018000467D: call        @ILT+180(?__scrt_initialize_type_info@@YAXXZ)
  0000000180004682: call        @ILT+890(__scrt_initialize_default_local_stdio_options)
  0000000180004687: lea         rdx,[__xi_z]
  000000018000468E: lea         rcx,[__xi_a]
  0000000180004695: call        _initterm_e
  000000018000469A: test        eax,eax
  000000018000469C: jne         00000001800046C7
  000000018000469E: call        @ILT+920(__scrt_dllmain_after_initialize_c)
  00000001800046A3: test        al,al
  00000001800046A5: je          00000001800046C7
  00000001800046A7: lea         rdx,[__xc_z]
  00000001800046AE: lea         rcx,[__xc_a]
  00000001800046B5: call        _initterm
  00000001800046BA: mov         dword ptr [__scrt_current_native_startup_state],2
  00000001800046C4: xor         dil,dil
  00000001800046C7: mov         cl,bl
  00000001800046C9: call        @ILT+945(__scrt_release_startup_lock)
  00000001800046CE: test        dil,dil
  00000001800046D1: jne         0000000180004712
  00000001800046D3: call        @ILT+815(__scrt_get_dyn_tls_init_callback)
  00000001800046D8: mov         rbx,rax
  00000001800046DB: cmp         qword ptr [rax],0
  00000001800046DF: je          0000000180004705
  00000001800046E1: mov         rcx,rax
  00000001800046E4: call        @ILT+405(__scrt_is_nonwritable_in_current_image)
  00000001800046E9: test        al,al
  00000001800046EB: je          0000000180004705
  00000001800046ED: mov         r8,rsi
  00000001800046F0: mov         edx,2
  00000001800046F5: mov         rcx,r14
  00000001800046F8: mov         rax,qword ptr [rbx]
  00000001800046FB: mov         r9,qword ptr [__guard_dispatch_icall_fptr]
  0000000180004702: call        r9
  0000000180004705: inc         dword ptr [18000E478h]
  000000018000470B: mov         eax,1
  0000000180004710: jmp         0000000180004714
  0000000180004712: xor         eax,eax
  0000000180004714: mov         rbx,qword ptr [rsp+30h]
  0000000180004719: mov         rsi,qword ptr [rsp+38h]
  000000018000471E: mov         rdi,qword ptr [rsp+48h]
  0000000180004723: add         rsp,20h
  0000000180004727: pop         r14
  0000000180004729: ret
  000000018000472A: mov         ecx,7
  000000018000472F: call        @ILT+955(__scrt_fastfail)
  0000000180004734: nop
  0000000180004735: int         3
  0000000180004736: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004746: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004756: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004766: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004776: CC CC CC CC CC CC                                ......
dllmain_crt_process_detach:
  000000018000477C: mov         qword ptr [rsp+8],rbx
  0000000180004781: push        rdi
  0000000180004782: sub         rsp,30h
  0000000180004786: mov         dil,cl
  0000000180004789: mov         eax,dword ptr [18000E478h]
  000000018000478F: test        eax,eax
  0000000180004791: jg          00000001800047A0
  0000000180004793: xor         eax,eax
  0000000180004795: mov         rbx,qword ptr [rsp+40h]
  000000018000479A: add         rsp,30h
  000000018000479E: pop         rdi
  000000018000479F: ret
  00000001800047A0: dec         eax
  00000001800047A2: mov         dword ptr [18000E478h],eax
  00000001800047A8: call        @ILT+995(__scrt_acquire_startup_lock)
  00000001800047AD: mov         bl,al
  00000001800047AF: mov         byte ptr [rsp+20h],al
  00000001800047B3: cmp         dword ptr [__scrt_current_native_startup_state],2
  00000001800047BA: jne         00000001800047F2
  00000001800047BC: call        @ILT+1200(__scrt_dllmain_uninitialize_c)
  00000001800047C1: call        @ILT+820(?__scrt_uninitialize_type_info@@YAXXZ)
  00000001800047C6: call        @ILT+670(_RTC_Terminate)
  00000001800047CB: mov         dword ptr [__scrt_current_native_startup_state],0
  00000001800047D5: mov         cl,bl
  00000001800047D7: call        @ILT+945(__scrt_release_startup_lock)
  00000001800047DC: xor         edx,edx
  00000001800047DE: mov         cl,dil
  00000001800047E1: call        @ILT+385(__scrt_uninitialize_crt)
  00000001800047E6: movzx       ebx,al
  00000001800047E9: call        @ILT+850(__scrt_dllmain_uninitialize_critical)
  00000001800047EE: mov         eax,ebx
  00000001800047F0: jmp         0000000180004795
  00000001800047F2: mov         ecx,7
  00000001800047F7: call        @ILT+955(__scrt_fastfail)
  00000001800047FC: nop
  00000001800047FD: nop
  00000001800047FE: int         3
  00000001800047FF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000480F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000481F: CC                                               .
dllmain_dispatch:
  0000000180004820: mov         rax,rsp
  0000000180004823: mov         qword ptr [rax+20h],rbx
  0000000180004827: mov         qword ptr [rax+18h],r8
  000000018000482B: mov         dword ptr [rax+10h],edx
  000000018000482E: mov         qword ptr [rax+8],rcx
  0000000180004832: push        rsi
  0000000180004833: push        rdi
  0000000180004834: push        r14
  0000000180004836: sub         rsp,40h
  000000018000483A: mov         rsi,r8
  000000018000483D: mov         edi,edx
  000000018000483F: mov         r14,rcx
  0000000180004842: test        edx,edx
  0000000180004844: jne         0000000180004855
  0000000180004846: cmp         dword ptr [18000E478h],edx
  000000018000484C: jg          0000000180004855
  000000018000484E: xor         eax,eax
  0000000180004850: jmp         000000018000493A
  0000000180004855: lea         eax,[rdx-1]
  0000000180004858: cmp         eax,1
  000000018000485B: ja          000000018000489D
  000000018000485D: mov         rax,qword ptr [_pDefaultRawDllMain]
  0000000180004864: test        rax,rax
  0000000180004867: jne         000000018000486E
  0000000180004869: lea         ebx,[rax+1]
  000000018000486C: jmp         0000000180004876
  000000018000486E: call        qword ptr [__guard_dispatch_icall_fptr]
  0000000180004874: mov         ebx,eax
  0000000180004876: mov         dword ptr [rsp+30h],ebx
  000000018000487A: test        ebx,ebx
  000000018000487C: je          0000000180004930
  0000000180004882: mov         r8,rsi
  0000000180004885: mov         edx,edi
  0000000180004887: mov         rcx,r14
  000000018000488A: call        00000001800045BC
  000000018000488F: mov         ebx,eax
  0000000180004891: mov         dword ptr [rsp+30h],eax
  0000000180004895: test        eax,eax
  0000000180004897: je          0000000180004930
  000000018000489D: mov         r8,rsi
  00000001800048A0: mov         edx,edi
  00000001800048A2: mov         rcx,r14
  00000001800048A5: call        @ILT+530(DllMain)
  00000001800048AA: mov         ebx,eax
  00000001800048AC: mov         dword ptr [rsp+30h],eax
  00000001800048B0: cmp         edi,1
  00000001800048B3: jne         00000001800048EB
  00000001800048B5: test        eax,eax
  00000001800048B7: jne         00000001800048EB
  00000001800048B9: mov         r8,rsi
  00000001800048BC: xor         edx,edx
  00000001800048BE: mov         rcx,r14
  00000001800048C1: call        @ILT+530(DllMain)
  00000001800048C6: test        rsi,rsi
  00000001800048C9: setne       cl
  00000001800048CC: call        000000018000477C
  00000001800048D1: mov         rax,qword ptr [_pDefaultRawDllMain]
  00000001800048D8: test        rax,rax
  00000001800048DB: je          00000001800048EB
  00000001800048DD: mov         r8,rsi
  00000001800048E0: xor         edx,edx
  00000001800048E2: mov         rcx,r14
  00000001800048E5: call        qword ptr [__guard_dispatch_icall_fptr]
  00000001800048EB: test        edi,edi
  00000001800048ED: je          00000001800048F4
  00000001800048EF: cmp         edi,3
  00000001800048F2: jne         0000000180004930
  00000001800048F4: mov         r8,rsi
  00000001800048F7: mov         edx,edi
  00000001800048F9: mov         rcx,r14
  00000001800048FC: call        00000001800045BC
  0000000180004901: mov         ebx,eax
  0000000180004903: mov         dword ptr [rsp+30h],eax
  0000000180004907: test        eax,eax
  0000000180004909: je          0000000180004930
  000000018000490B: mov         rax,qword ptr [_pDefaultRawDllMain]
  0000000180004912: test        rax,rax
  0000000180004915: jne         000000018000491C
  0000000180004917: lea         ebx,[rax+1]
  000000018000491A: jmp         000000018000492C
  000000018000491C: mov         r8,rsi
  000000018000491F: mov         edx,edi
  0000000180004921: mov         rcx,r14
  0000000180004924: call        qword ptr [__guard_dispatch_icall_fptr]
  000000018000492A: mov         ebx,eax
  000000018000492C: mov         dword ptr [rsp+30h],ebx
  0000000180004930: jmp         0000000180004938
  0000000180004932: xor         ebx,ebx
  0000000180004934: mov         dword ptr [rsp+30h],ebx
  0000000180004938: mov         eax,ebx
  000000018000493A: mov         rbx,qword ptr [rsp+78h]
  000000018000493F: add         rsp,40h
  0000000180004943: pop         r14
  0000000180004945: pop         rdi
  0000000180004946: pop         rsi
  0000000180004947: ret
  0000000180004948: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004958: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004968: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004978: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004988: CC CC CC CC CC CC CC CC CC CC CC CC              ............
dllmain_raw:
  0000000180004994: mov         rax,qword ptr [_pDefaultRawDllMain]
  000000018000499B: test        rax,rax
  000000018000499E: jne         00000001800049A6
  00000001800049A0: mov         eax,1
  00000001800049A5: ret
  00000001800049A6: jmp         qword ptr [__guard_dispatch_icall_fptr]
  00000001800049AD: CC CC CC CC CC CC CC                             .......
_CRT_INIT:
  00000001800049B4: jmp         00000001800045BC
  00000001800049B9: CC CC CC                                         ...
_DllMainCRTStartup:
  00000001800049BC: mov         qword ptr [rsp+8],rbx
  00000001800049C1: mov         qword ptr [rsp+10h],rsi
  00000001800049C6: push        rdi
  00000001800049C7: sub         rsp,20h
  00000001800049CB: mov         rdi,r8
  00000001800049CE: mov         ebx,edx
  00000001800049D0: mov         rsi,rcx
  00000001800049D3: cmp         edx,1
  00000001800049D6: jne         00000001800049DD
  00000001800049D8: call        @ILT+785(__security_init_cookie)
  00000001800049DD: mov         r8,rdi
  00000001800049E0: mov         edx,ebx
  00000001800049E2: mov         rcx,rsi
  00000001800049E5: mov         rbx,qword ptr [rsp+30h]
  00000001800049EA: mov         rsi,qword ptr [rsp+38h]
  00000001800049EF: add         rsp,20h
  00000001800049F3: pop         rdi
  00000001800049F4: jmp         0000000180004820
  00000001800049F9: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC     ...............
??0bad_alloc@std@@AEAA@QEBD@Z:
  0000000180004A08: lea         rax,[??_7bad_alloc@std@@6B@]
  0000000180004A0F: mov         qword ptr [rcx+10h],0
  0000000180004A17: mov         qword ptr [rcx],rax
  0000000180004A1A: mov         rax,rcx
  0000000180004A1D: mov         qword ptr [rcx+8],rdx
  0000000180004A21: ret
  0000000180004A22: CC CC CC CC CC CC                                ......
??0bad_alloc@std@@QEAA@AEBV01@@Z:
  0000000180004A28: push        rbx
  0000000180004A2A: sub         rsp,20h
  0000000180004A2E: mov         rbx,rcx
  0000000180004A31: mov         rax,rdx
  0000000180004A34: lea         rcx,[??_7exception@std@@6B@]
  0000000180004A3B: xorps       xmm0,xmm0
  0000000180004A3E: mov         qword ptr [rbx],rcx
  0000000180004A41: lea         rdx,[rbx+8]
  0000000180004A45: lea         rcx,[rax+8]
  0000000180004A49: movups      xmmword ptr [rdx],xmm0
  0000000180004A4C: call        __std_exception_copy
  0000000180004A51: lea         rax,[??_7bad_alloc@std@@6B@]
  0000000180004A58: mov         qword ptr [rbx],rax
  0000000180004A5B: mov         rax,rbx
  0000000180004A5E: add         rsp,20h
  0000000180004A62: pop         rbx
  0000000180004A63: ret
  0000000180004A64: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
??0bad_alloc@std@@QEAA@XZ:
  0000000180004A74: lea         rax,[??_C@_0P@GHFPNOJB@bad?5allocation@]
  0000000180004A7B: mov         qword ptr [rcx+10h],0
  0000000180004A83: mov         qword ptr [rcx+8],rax
  0000000180004A87: lea         rax,[??_7bad_alloc@std@@6B@]
  0000000180004A8E: mov         qword ptr [rcx],rax
  0000000180004A91: mov         rax,rcx
  0000000180004A94: ret
  0000000180004A95: CC CC CC CC CC CC CC CC CC CC CC                 ...........
??0bad_array_new_length@std@@QEAA@AEBV01@@Z:
  0000000180004AA0: push        rbx
  0000000180004AA2: sub         rsp,20h
  0000000180004AA6: mov         rbx,rcx
  0000000180004AA9: mov         rax,rdx
  0000000180004AAC: lea         rcx,[??_7exception@std@@6B@]
  0000000180004AB3: xorps       xmm0,xmm0
  0000000180004AB6: mov         qword ptr [rbx],rcx
  0000000180004AB9: lea         rdx,[rbx+8]
  0000000180004ABD: lea         rcx,[rax+8]
  0000000180004AC1: movups      xmmword ptr [rdx],xmm0
  0000000180004AC4: call        __std_exception_copy
  0000000180004AC9: lea         rax,[??_7bad_array_new_length@std@@6B@]
  0000000180004AD0: mov         qword ptr [rbx],rax
  0000000180004AD3: mov         rax,rbx
  0000000180004AD6: add         rsp,20h
  0000000180004ADA: pop         rbx
  0000000180004ADB: ret
  0000000180004ADC: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
??0bad_array_new_length@std@@QEAA@XZ:
  0000000180004AEC: lea         rax,[??_C@_0BF@KINCDENJ@bad?5array?5new?5length@]
  0000000180004AF3: mov         qword ptr [rcx+10h],0
  0000000180004AFB: mov         qword ptr [rcx+8],rax
  0000000180004AFF: lea         rax,[??_7bad_array_new_length@std@@6B@]
  0000000180004B06: mov         qword ptr [rcx],rax
  0000000180004B09: mov         rax,rcx
  0000000180004B0C: ret
  0000000180004B0D: CC CC CC CC CC CC CC CC CC CC CC                 ...........
??0exception@std@@QEAA@AEBV01@@Z:
  0000000180004B18: push        rbx
  0000000180004B1A: sub         rsp,20h
  0000000180004B1E: mov         rbx,rcx
  0000000180004B21: mov         rax,rdx
  0000000180004B24: lea         rcx,[??_7exception@std@@6B@]
  0000000180004B2B: xorps       xmm0,xmm0
  0000000180004B2E: mov         qword ptr [rbx],rcx
  0000000180004B31: lea         rdx,[rbx+8]
  0000000180004B35: lea         rcx,[rax+8]
  0000000180004B39: movups      xmmword ptr [rdx],xmm0
  0000000180004B3C: call        __std_exception_copy
  0000000180004B41: mov         rax,rbx
  0000000180004B44: add         rsp,20h
  0000000180004B48: pop         rbx
  0000000180004B49: ret
  0000000180004B4A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC        ..............
??0exception@std@@QEAA@QEBDH@Z:
  0000000180004B58: lea         rax,[??_7exception@std@@6B@]
  0000000180004B5F: mov         qword ptr [rcx],rax
  0000000180004B62: mov         rax,rcx
  0000000180004B65: mov         qword ptr [rcx+10h],0
  0000000180004B6D: mov         qword ptr [rcx+8],rdx
  0000000180004B71: ret
  0000000180004B72: CC CC CC CC CC CC                                ......
??1bad_alloc@std@@UEAA@XZ:
  0000000180004B78: lea         rax,[??_7exception@std@@6B@]
  0000000180004B7F: mov         qword ptr [rcx],rax
  0000000180004B82: add         rcx,8
  0000000180004B86: jmp         __std_exception_destroy
  0000000180004B8B: CC CC CC CC CC                                   .....
??1bad_array_new_length@std@@UEAA@XZ:
  0000000180004B90: lea         rax,[??_7exception@std@@6B@]
  0000000180004B97: mov         qword ptr [rcx],rax
  0000000180004B9A: add         rcx,8
  0000000180004B9E: jmp         __std_exception_destroy
  0000000180004BA3: CC CC CC CC CC                                   .....
??1exception@std@@UEAA@XZ:
  0000000180004BA8: lea         rax,[??_7exception@std@@6B@]
  0000000180004BAF: mov         qword ptr [rcx],rax
  0000000180004BB2: add         rcx,8
  0000000180004BB6: jmp         __std_exception_destroy
  0000000180004BBB: CC CC CC CC CC                                   .....
??_Ebad_alloc@std@@UEAAPEAXI@Z:
  0000000180004BC0: mov         qword ptr [rsp+8],rbx
  0000000180004BC5: push        rdi
  0000000180004BC6: sub         rsp,20h
  0000000180004BCA: lea         rax,[??_7exception@std@@6B@]
  0000000180004BD1: mov         rdi,rcx
  0000000180004BD4: mov         qword ptr [rcx],rax
  0000000180004BD7: mov         ebx,edx
  0000000180004BD9: add         rcx,8
  0000000180004BDD: call        __std_exception_destroy
  0000000180004BE2: test        bl,1
  0000000180004BE5: je          0000000180004BF4
  0000000180004BE7: mov         edx,18h
  0000000180004BEC: mov         rcx,rdi
  0000000180004BEF: call        @ILT+940(??3@YAXPEAX_K@Z)
  0000000180004BF4: mov         rbx,qword ptr [rsp+30h]
  0000000180004BF9: mov         rax,rdi
  0000000180004BFC: add         rsp,20h
  0000000180004C00: pop         rdi
  0000000180004C01: ret
  0000000180004C02: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004C12: CC CC                                            ..
??_Ebad_array_new_length@std@@UEAAPEAXI@Z:
  0000000180004C14: mov         qword ptr [rsp+8],rbx
  0000000180004C19: push        rdi
  0000000180004C1A: sub         rsp,20h
  0000000180004C1E: lea         rax,[??_7exception@std@@6B@]
  0000000180004C25: mov         rdi,rcx
  0000000180004C28: mov         qword ptr [rcx],rax
  0000000180004C2B: mov         ebx,edx
  0000000180004C2D: add         rcx,8
  0000000180004C31: call        __std_exception_destroy
  0000000180004C36: test        bl,1
  0000000180004C39: je          0000000180004C48
  0000000180004C3B: mov         edx,18h
  0000000180004C40: mov         rcx,rdi
  0000000180004C43: call        @ILT+940(??3@YAXPEAX_K@Z)
  0000000180004C48: mov         rbx,qword ptr [rsp+30h]
  0000000180004C4D: mov         rax,rdi
  0000000180004C50: add         rsp,20h
  0000000180004C54: pop         rdi
  0000000180004C55: ret
  0000000180004C56: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004C66: CC CC                                            ..
??_Eexception@std@@UEAAPEAXI@Z:
  0000000180004C68: mov         qword ptr [rsp+8],rbx
  0000000180004C6D: push        rdi
  0000000180004C6E: sub         rsp,20h
  0000000180004C72: lea         rax,[??_7exception@std@@6B@]
  0000000180004C79: mov         rdi,rcx
  0000000180004C7C: mov         qword ptr [rcx],rax
  0000000180004C7F: mov         ebx,edx
  0000000180004C81: add         rcx,8
  0000000180004C85: call        __std_exception_destroy
  0000000180004C8A: test        bl,1
  0000000180004C8D: je          0000000180004C9C
  0000000180004C8F: mov         edx,18h
  0000000180004C94: mov         rcx,rdi
  0000000180004C97: call        @ILT+940(??3@YAXPEAX_K@Z)
  0000000180004C9C: mov         rbx,qword ptr [rsp+30h]
  0000000180004CA1: mov         rax,rdi
  0000000180004CA4: add         rsp,20h
  0000000180004CA8: pop         rdi
  0000000180004CA9: ret
  0000000180004CAA: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004CBA: CC CC                                            ..
?__scrt_throw_std_bad_alloc@@YAXXZ:
  0000000180004CBC: sub         rsp,48h
  0000000180004CC0: lea         rcx,[rsp+20h]
  0000000180004CC5: call        @ILT+1210(??0bad_alloc@std@@QEAA@XZ)
  0000000180004CCA: lea         rdx,[_TI2?AVbad_alloc@std@@]
  0000000180004CD1: lea         rcx,[rsp+20h]
  0000000180004CD6: call        _CxxThrowException
  0000000180004CDB: int         3
  0000000180004CDC: CC CC CC CC CC CC CC CC                          ........
?__scrt_throw_std_bad_array_new_length@@YAXXZ:
  0000000180004CE4: sub         rsp,48h
  0000000180004CE8: lea         rcx,[rsp+20h]
  0000000180004CED: call        @ILT+980(??0bad_array_new_length@std@@QEAA@XZ)
  0000000180004CF2: lea         rdx,[_TI3?AVbad_array_new_length@std@@]
  0000000180004CF9: lea         rcx,[rsp+20h]
  0000000180004CFE: call        _CxxThrowException
  0000000180004D03: int         3
  0000000180004D04: CC CC CC CC CC CC CC CC                          ........
?what@exception@std@@UEBAPEBDXZ:
  0000000180004D0C: cmp         qword ptr [rcx+8],0
  0000000180004D11: lea         rax,[??_C@_0BC@EOODALEL@Unknown?5exception@]
  0000000180004D18: cmovne      rax,qword ptr [rcx+8]
  0000000180004D1D: ret
  0000000180004D1E: CC CC CC CC CC CC                                ......
??3@YAXPEAX@Z:
  0000000180004D24: jmp         free
  0000000180004D29: CC CC CC                                         ...
__raise_securityfailure:
  0000000180004D2C: push        rbx
  0000000180004D2E: sub         rsp,20h
  0000000180004D32: mov         rbx,rcx
  0000000180004D35: xor         ecx,ecx
  0000000180004D37: call        qword ptr [__imp_SetUnhandledExceptionFilter]
  0000000180004D3D: mov         rcx,rbx
  0000000180004D40: call        qword ptr [__imp_UnhandledExceptionFilter]
  0000000180004D46: call        qword ptr [__imp_GetCurrentProcess]
  0000000180004D4C: mov         rcx,rax
  0000000180004D4F: mov         edx,0C0000409h
  0000000180004D54: add         rsp,20h
  0000000180004D58: pop         rbx
  0000000180004D59: jmp         qword ptr [__imp_TerminateProcess]
  0000000180004D60: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
__report_gsfailure:
  0000000180004D70: mov         qword ptr [rsp+8],rcx
  0000000180004D75: sub         rsp,38h
  0000000180004D79: mov         ecx,17h
  0000000180004D7E: call        qword ptr [__imp_IsProcessorFeaturePresent]
  0000000180004D84: test        eax,eax
  0000000180004D86: je          0000000180004D8F
  0000000180004D88: mov         ecx,2
  0000000180004D8D: int         29h
  0000000180004D8F: lea         rcx,[18000E520h]
  0000000180004D96: call        0000000180005138
  0000000180004D9B: mov         rax,qword ptr [rsp+38h]
  0000000180004DA0: mov         qword ptr [18000E618h],rax
  0000000180004DA7: lea         rax,[rsp+38h]
  0000000180004DAC: add         rax,8
  0000000180004DB0: mov         qword ptr [18000E5B8h],rax
  0000000180004DB7: mov         rax,qword ptr [18000E618h]
  0000000180004DBE: mov         qword ptr [18000E490h],rax
  0000000180004DC5: mov         rax,qword ptr [rsp+40h]
  0000000180004DCA: mov         qword ptr [18000E5A0h],rax
  0000000180004DD1: mov         dword ptr [18000E480h],0C0000409h
  0000000180004DDB: mov         dword ptr [18000E484h],1
  0000000180004DE5: mov         dword ptr [18000E498h],1
  0000000180004DEF: mov         eax,8
  0000000180004DF4: imul        rax,rax,0
  0000000180004DF8: lea         rcx,[18000E4A0h]
  0000000180004DFF: mov         qword ptr [rcx+rax],2
  0000000180004E07: mov         eax,8
  0000000180004E0C: imul        rax,rax,0
  0000000180004E10: mov         rcx,qword ptr [__security_cookie]
  0000000180004E17: mov         qword ptr [rsp+rax+20h],rcx
  0000000180004E1C: mov         eax,8
  0000000180004E21: imul        rax,rax,1
  0000000180004E25: mov         rcx,qword ptr [__security_cookie_complement]
  0000000180004E2C: mov         qword ptr [rsp+rax+20h],rcx
  0000000180004E31: lea         rcx,[18000A9C0h]
  0000000180004E38: call        @ILT+615(__raise_securityfailure)
  0000000180004E3D: nop
  0000000180004E3E: add         rsp,38h
  0000000180004E42: ret
  0000000180004E43: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004E53: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004E63: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004E73: CC CC CC CC CC                                   .....
__report_rangecheckfailure:
  0000000180004E78: sub         rsp,28h
  0000000180004E7C: mov         ecx,8
  0000000180004E81: call        @ILT+265(__report_securityfailure)
  0000000180004E86: nop
  0000000180004E87: add         rsp,28h
  0000000180004E8B: ret
  0000000180004E8C: CC CC CC CC CC CC CC CC                          ........
__report_securityfailure:
  0000000180004E94: mov         dword ptr [rsp+8],ecx
  0000000180004E98: sub         rsp,28h
  0000000180004E9C: mov         ecx,17h
  0000000180004EA1: call        qword ptr [__imp_IsProcessorFeaturePresent]
  0000000180004EA7: test        eax,eax
  0000000180004EA9: je          0000000180004EB3
  0000000180004EAB: mov         eax,dword ptr [rsp+30h]
  0000000180004EAF: mov         ecx,eax
  0000000180004EB1: int         29h
  0000000180004EB3: lea         rcx,[18000E520h]
  0000000180004EBA: call        00000001800050AC
  0000000180004EBF: mov         rax,qword ptr [rsp+28h]
  0000000180004EC4: mov         qword ptr [18000E618h],rax
  0000000180004ECB: lea         rax,[rsp+28h]
  0000000180004ED0: add         rax,8
  0000000180004ED4: mov         qword ptr [18000E5B8h],rax
  0000000180004EDB: mov         rax,qword ptr [18000E618h]
  0000000180004EE2: mov         qword ptr [18000E490h],rax
  0000000180004EE9: mov         dword ptr [18000E480h],0C0000409h
  0000000180004EF3: mov         dword ptr [18000E484h],1
  0000000180004EFD: mov         dword ptr [18000E498h],1
  0000000180004F07: mov         eax,8
  0000000180004F0C: imul        rax,rax,0
  0000000180004F10: lea         rcx,[18000E4A0h]
  0000000180004F17: mov         edx,dword ptr [rsp+30h]
  0000000180004F1B: mov         qword ptr [rcx+rax],rdx
  0000000180004F1F: lea         rcx,[18000A9C0h]
  0000000180004F26: call        @ILT+615(__raise_securityfailure)
  0000000180004F2B: nop
  0000000180004F2C: add         rsp,28h
  0000000180004F30: ret
  0000000180004F31: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004F41: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180004F51: CC CC CC CC CC CC CC                             .......
__report_securityfailureEx:
  0000000180004F58: mov         qword ptr [rsp+18h],r8
  0000000180004F5D: mov         dword ptr [rsp+10h],edx
  0000000180004F61: mov         dword ptr [rsp+8],ecx
  0000000180004F65: sub         rsp,38h
  0000000180004F69: mov         ecx,17h
  0000000180004F6E: call        qword ptr [__imp_IsProcessorFeaturePresent]
  0000000180004F74: test        eax,eax
  0000000180004F76: je          0000000180004F80
  0000000180004F78: mov         eax,dword ptr [rsp+40h]
  0000000180004F7C: mov         ecx,eax
  0000000180004F7E: int         29h
  0000000180004F80: lea         rcx,[18000E520h]
  0000000180004F87: call        00000001800050AC
  0000000180004F8C: mov         rax,qword ptr [rsp+38h]
  0000000180004F91: mov         qword ptr [18000E618h],rax
  0000000180004F98: lea         rax,[rsp+38h]
  0000000180004F9D: add         rax,8
  0000000180004FA1: mov         qword ptr [18000E5B8h],rax
  0000000180004FA8: mov         rax,qword ptr [18000E618h]
  0000000180004FAF: mov         qword ptr [18000E490h],rax
  0000000180004FB6: mov         dword ptr [18000E480h],0C0000409h
  0000000180004FC0: mov         dword ptr [18000E484h],1
  0000000180004FCA: cmp         dword ptr [rsp+48h],0
  0000000180004FCF: jbe         0000000180004FE1
  0000000180004FD1: cmp         qword ptr [rsp+50h],0
  0000000180004FD7: jne         0000000180004FE1
  0000000180004FD9: mov         dword ptr [rsp+48h],0
  0000000180004FE1: cmp         dword ptr [rsp+48h],0Eh
  0000000180004FE6: jbe         0000000180004FF2
  0000000180004FE8: mov         eax,dword ptr [rsp+48h]
  0000000180004FEC: dec         eax
  0000000180004FEE: mov         dword ptr [rsp+48h],eax
  0000000180004FF2: mov         eax,dword ptr [rsp+48h]
  0000000180004FF6: inc         eax
  0000000180004FF8: mov         dword ptr [18000E498h],eax
  0000000180004FFE: mov         eax,8
  0000000180005003: imul        rax,rax,0
  0000000180005007: lea         rcx,[18000E4A0h]
  000000018000500E: mov         edx,dword ptr [rsp+40h]
  0000000180005012: mov         qword ptr [rcx+rax],rdx
  0000000180005016: mov         dword ptr [rsp+20h],0
  000000018000501E: jmp         000000018000502A
  0000000180005020: mov         eax,dword ptr [rsp+20h]
  0000000180005024: inc         eax
  0000000180005026: mov         dword ptr [rsp+20h],eax
  000000018000502A: mov         eax,dword ptr [rsp+48h]
  000000018000502E: cmp         dword ptr [rsp+20h],eax
  0000000180005032: jae         0000000180005056
  0000000180005034: mov         eax,dword ptr [rsp+20h]
  0000000180005038: mov         ecx,dword ptr [rsp+20h]
  000000018000503C: inc         ecx
  000000018000503E: mov         ecx,ecx
  0000000180005040: lea         rdx,[18000E4A0h]
  0000000180005047: mov         r8,qword ptr [rsp+50h]
  000000018000504C: mov         rax,qword ptr [r8+rax*8]
  0000000180005050: mov         qword ptr [rdx+rcx*8],rax
  0000000180005054: jmp         0000000180005020
  0000000180005056: lea         rcx,[18000A9C0h]
  000000018000505D: call        @ILT+615(__raise_securityfailure)
  0000000180005062: nop
  0000000180005063: add         rsp,38h
  0000000180005067: ret
  0000000180005068: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180005078: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180005088: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180005098: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800050A8: CC CC CC CC                                      ....
capture_current_context:
  00000001800050AC: mov         qword ptr [rsp+20h],rbx
  00000001800050B1: push        rdi
  00000001800050B2: sub         rsp,40h
  00000001800050B6: mov         rbx,rcx
  00000001800050B9: call        qword ptr [__imp_RtlCaptureContext]
  00000001800050BF: mov         rdi,qword ptr [rbx+0F8h]
  00000001800050C6: lea         rdx,[rsp+50h]
  00000001800050CB: mov         rcx,rdi
  00000001800050CE: xor         r8d,r8d
  00000001800050D1: call        qword ptr [__imp_RtlLookupFunctionEntry]
  00000001800050D7: test        rax,rax
  00000001800050DA: je          0000000180005111
  00000001800050DC: mov         rdx,qword ptr [rsp+50h]
  00000001800050E1: lea         rcx,[rsp+58h]
  00000001800050E6: mov         qword ptr [rsp+38h],0
  00000001800050EF: mov         r9,rax
  00000001800050F2: mov         qword ptr [rsp+30h],rcx
  00000001800050F7: mov         r8,rdi
  00000001800050FA: lea         rcx,[rsp+60h]
  00000001800050FF: mov         qword ptr [rsp+28h],rcx
  0000000180005104: xor         ecx,ecx
  0000000180005106: mov         qword ptr [rsp+20h],rbx
  000000018000510B: call        qword ptr [__imp_RtlVirtualUnwind]
  0000000180005111: mov         rbx,qword ptr [rsp+68h]
  0000000180005116: add         rsp,40h
  000000018000511A: pop         rdi
  000000018000511B: ret
  000000018000511C: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000512C: CC CC CC CC CC CC CC CC CC CC CC CC              ............
capture_previous_context:
  0000000180005138: push        rbx
  000000018000513A: push        rsi
  000000018000513B: push        rdi
  000000018000513C: sub         rsp,40h
  0000000180005140: mov         rbx,rcx
  0000000180005143: call        qword ptr [__imp_RtlCaptureContext]
  0000000180005149: mov         rsi,qword ptr [rbx+0F8h]
  0000000180005150: xor         edi,edi
  0000000180005152: xor         r8d,r8d
  0000000180005155: lea         rdx,[rsp+60h]
  000000018000515A: mov         rcx,rsi
  000000018000515D: call        qword ptr [__imp_RtlLookupFunctionEntry]
  0000000180005163: test        rax,rax
  0000000180005166: je          00000001800051A4
  0000000180005168: mov         rdx,qword ptr [rsp+60h]
  000000018000516D: lea         rcx,[rsp+68h]
  0000000180005172: mov         qword ptr [rsp+38h],0
  000000018000517B: mov         r9,rax
  000000018000517E: mov         qword ptr [rsp+30h],rcx
  0000000180005183: mov         r8,rsi
  0000000180005186: lea         rcx,[rsp+70h]
  000000018000518B: mov         qword ptr [rsp+28h],rcx
  0000000180005190: xor         ecx,ecx
  0000000180005192: mov         qword ptr [rsp+20h],rbx
  0000000180005197: call        qword ptr [__imp_RtlVirtualUnwind]
  000000018000519D: inc         edi
  000000018000519F: cmp         edi,2
  00000001800051A2: jl          0000000180005152
  00000001800051A4: add         rsp,40h
  00000001800051A8: pop         rdi
  00000001800051A9: pop         rsi
  00000001800051AA: pop         rbx
  00000001800051AB: ret
  00000001800051AC: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800051BC: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
__get_entropy:
  00000001800051CC: push        rbp
  00000001800051CE: mov         rbp,rsp
  00000001800051D1: sub         rsp,20h
  00000001800051D5: lea         rcx,[rbp+18h]
  00000001800051D9: mov         qword ptr [rbp+18h],0
  00000001800051E1: call        qword ptr [__imp_GetSystemTimeAsFileTime]
  00000001800051E7: mov         rax,qword ptr [rbp+18h]
  00000001800051EB: mov         qword ptr [rbp+10h],rax
  00000001800051EF: call        qword ptr [__imp_GetCurrentThreadId]
  00000001800051F5: mov         eax,eax
  00000001800051F7: xor         qword ptr [rbp+10h],rax
  00000001800051FB: call        qword ptr [__imp_GetCurrentProcessId]
  0000000180005201: mov         eax,eax
  0000000180005203: lea         rcx,[rbp+20h]
  0000000180005207: xor         qword ptr [rbp+10h],rax
  000000018000520B: call        qword ptr [__imp_QueryPerformanceCounter]
  0000000180005211: mov         eax,dword ptr [rbp+20h]
  0000000180005214: lea         rcx,[rbp+10h]
  0000000180005218: shl         rax,20h
  000000018000521C: xor         rax,qword ptr [rbp+20h]
  0000000180005220: xor         rax,qword ptr [rbp+10h]
  0000000180005224: xor         rax,rcx
  0000000180005227: mov         rcx,0FFFFFFFFFFFFh
  0000000180005231: and         rax,rcx
  0000000180005234: add         rsp,20h
  0000000180005238: pop         rbp
  0000000180005239: ret
  000000018000523A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000524A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC        ..............
__security_init_cookie:
  0000000180005258: mov         qword ptr [rsp+18h],rbx
  000000018000525D: push        rbp
  000000018000525E: mov         rbp,rsp
  0000000180005261: sub         rsp,30h
  0000000180005265: mov         rax,qword ptr [__security_cookie]
  000000018000526C: mov         rbx,2B992DDFA232h
  0000000180005276: cmp         rax,rbx
  0000000180005279: jne         00000001800052F2
  000000018000527B: lea         rcx,[rbp+10h]
  000000018000527F: mov         qword ptr [rbp+10h],0
  0000000180005287: call        qword ptr [__imp_GetSystemTimeAsFileTime]
  000000018000528D: mov         rax,qword ptr [rbp+10h]
  0000000180005291: mov         qword ptr [rbp-10h],rax
  0000000180005295: call        qword ptr [__imp_GetCurrentThreadId]
  000000018000529B: mov         eax,eax
  000000018000529D: xor         qword ptr [rbp-10h],rax
  00000001800052A1: call        qword ptr [__imp_GetCurrentProcessId]
  00000001800052A7: mov         eax,eax
  00000001800052A9: lea         rcx,[rbp+18h]
  00000001800052AD: xor         qword ptr [rbp-10h],rax
  00000001800052B1: call        qword ptr [__imp_QueryPerformanceCounter]
  00000001800052B7: mov         eax,dword ptr [rbp+18h]
  00000001800052BA: lea         rcx,[rbp-10h]
  00000001800052BE: shl         rax,20h
  00000001800052C2: xor         rax,qword ptr [rbp+18h]
  00000001800052C6: xor         rax,qword ptr [rbp-10h]
  00000001800052CA: xor         rax,rcx
  00000001800052CD: mov         rcx,0FFFFFFFFFFFFh
  00000001800052D7: and         rax,rcx
  00000001800052DA: mov         rcx,2B992DDFA233h
  00000001800052E4: cmp         rax,rbx
  00000001800052E7: cmove       rax,rcx
  00000001800052EB: mov         qword ptr [__security_cookie],rax
  00000001800052F2: mov         rbx,qword ptr [rsp+50h]
  00000001800052F7: not         rax
  00000001800052FA: mov         qword ptr [__security_cookie_complement],rax
  0000000180005301: add         rsp,30h
  0000000180005305: pop         rbp
  0000000180005306: ret
  0000000180005307: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180005317: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180005327: CC CC CC CC CC CC CC CC CC CC CC CC CC           .............
DllMain:
  0000000180005334: sub         rsp,28h
  0000000180005338: cmp         edx,1
  000000018000533B: jne         000000018000534D
  000000018000533D: cmp         qword ptr [_pDefaultRawDllMain],0
  0000000180005345: jne         000000018000534D
  0000000180005347: call        qword ptr [__imp_DisableThreadLibraryCalls]
  000000018000534D: mov         eax,1
  0000000180005352: add         rsp,28h
  0000000180005356: ret
  0000000180005357: CC CC CC CC CC CC CC CC CC                       .........
?__scrt_initialize_type_info@@YAXXZ:
  0000000180005360: lea         rcx,[?__type_info_root_node@@3U__type_info_node@@A]
  0000000180005367: jmp         qword ptr [__imp_InitializeSListHead]
  000000018000536E: CC CC CC CC CC CC                                ......
?__scrt_uninitialize_type_info@@YAXXZ:
  0000000180005374: lea         rcx,[?__type_info_root_node@@3U__type_info_node@@A]
  000000018000537B: jmp         __std_type_info_destroy_list
  0000000180005380: CC CC CC CC                                      ....
__local_stdio_printf_options:
  0000000180005384: lea         rax,[?_OptionsStorage@?1??__local_stdio_printf_options@@9@4_KA]
  000000018000538B: ret
  000000018000538C: CC CC CC CC                                      ....
__local_stdio_scanf_options:
  0000000180005390: lea         rax,[?_OptionsStorage@?1??__local_stdio_scanf_options@@9@4_KA]
  0000000180005397: ret
  0000000180005398: CC CC CC CC                                      ....
__scrt_initialize_default_local_stdio_options:
  000000018000539C: sub         rsp,28h
  00000001800053A0: call        @ILT+20(__local_stdio_printf_options)
  00000001800053A5: or          qword ptr [rax],24h
  00000001800053A9: call        @ILT+55(__local_stdio_scanf_options)
  00000001800053AE: or          qword ptr [rax],2
  00000001800053B2: add         rsp,28h
  00000001800053B6: ret
  00000001800053B7: CC CC CC CC CC CC CC CC CC                       .........
?configure_argv@__scrt_narrow_argv_policy@@SAHXZ:
  00000001800053C0: sub         rsp,28h
  00000001800053C4: call        @ILT+590(_get_startup_argv_mode)
  00000001800053C9: mov         ecx,eax
  00000001800053CB: add         rsp,28h
  00000001800053CF: jmp         _configure_narrow_argv
  00000001800053D4: CC CC CC CC CC CC CC CC                          ........
find_pe_section:
  00000001800053DC: movsxd      r8,dword ptr [rcx+3Ch]
  00000001800053E0: movzx       eax,word ptr [r8+rcx+14h]
  00000001800053E6: lea         r9,[r8+rcx]
  00000001800053EA: add         rax,18h
  00000001800053EE: add         r9,rax
  00000001800053F1: movzx       eax,word ptr [r8+rcx+6]
  00000001800053F7: lea         rcx,[rax+rax*4]
  00000001800053FB: lea         r8,[r9+rcx*8]
  00000001800053FF: jmp         0000000180005419
  0000000180005401: mov         ecx,dword ptr [r9+0Ch]
  0000000180005405: cmp         rdx,rcx
  0000000180005408: jb          0000000180005415
  000000018000540A: mov         eax,dword ptr [r9+8]
  000000018000540E: add         eax,ecx
  0000000180005410: cmp         rdx,rax
  0000000180005413: jb          0000000180005421
  0000000180005415: add         r9,28h
  0000000180005419: cmp         r9,r8
  000000018000541C: jne         0000000180005401
  000000018000541E: xor         eax,eax
  0000000180005420: ret
  0000000180005421: mov         rax,r9
  0000000180005424: ret
  0000000180005425: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180005435: CC CC CC                                         ...
?initialize_environment@__scrt_narrow_environment_policy@@SAHXZ:
  0000000180005438: jmp         _initialize_narrow_environment
  000000018000543D: CC CC CC                                         ...
is_potentially_valid_image_base:
  0000000180005440: test        rcx,rcx
  0000000180005443: je          000000018000546A
  0000000180005445: mov         eax,5A4Dh
  000000018000544A: cmp         word ptr [rcx],ax
  000000018000544D: jne         000000018000546A
  000000018000544F: movsxd      rax,dword ptr [rcx+3Ch]
  0000000180005453: cmp         dword ptr [rax+rcx],4550h
  000000018000545A: jne         000000018000546A
  000000018000545C: mov         edx,20Bh
  0000000180005461: cmp         word ptr [rax+rcx+18h],dx
  0000000180005466: sete        al
  0000000180005469: ret
  000000018000546A: xor         al,al
  000000018000546C: ret
  000000018000546D: CC CC CC CC CC CC CC CC CC CC CC                 ...........
NtCurrentTeb:
  0000000180005478: mov         rax,qword ptr gs:[30h]
  0000000180005481: ret
  0000000180005482: CC CC                                            ..
__scrt_acquire_startup_lock:
  0000000180005484: sub         rsp,28h
  0000000180005488: call        @ILT+390(__scrt_is_ucrt_dll_in_use)
  000000018000548D: test        eax,eax
  000000018000548F: je          00000001800054B2
  0000000180005491: mov         rax,qword ptr gs:[30h]
  000000018000549A: mov         rcx,qword ptr [rax+8]
  000000018000549E: jmp         00000001800054A5
  00000001800054A0: cmp         rcx,rax
  00000001800054A3: je          00000001800054B9
  00000001800054A5: xor         eax,eax
  00000001800054A7: lock cmpxchg qword ptr [__scrt_native_startup_lock],rcx
  00000001800054B0: jne         00000001800054A0
  00000001800054B2: xor         al,al
  00000001800054B4: add         rsp,28h
  00000001800054B8: ret
  00000001800054B9: mov         al,1
  00000001800054BB: jmp         00000001800054B4
  00000001800054BD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC     ...............
__scrt_dllmain_after_initialize_c:
  00000001800054CC: sub         rsp,28h
  00000001800054D0: call        @ILT+390(__scrt_is_ucrt_dll_in_use)
  00000001800054D5: test        eax,eax
  00000001800054D7: je          00000001800054E0
  00000001800054D9: call        @ILT+950(__isa_available_init)
  00000001800054DE: jmp         00000001800054F9
  00000001800054E0: call        @ILT+590(_get_startup_argv_mode)
  00000001800054E5: mov         ecx,eax
  00000001800054E7: call        _configure_narrow_argv
  00000001800054EC: test        eax,eax
  00000001800054EE: je          00000001800054F4
  00000001800054F0: xor         al,al
  00000001800054F2: jmp         00000001800054FB
  00000001800054F4: call        _initialize_narrow_environment
  00000001800054F9: mov         al,1
  00000001800054FB: add         rsp,28h
  00000001800054FF: ret
  0000000180005500: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
__scrt_dllmain_before_initialize_c:
  0000000180005510: sub         rsp,28h
  0000000180005514: xor         ecx,ecx
  0000000180005516: call        @ILT+245(__scrt_initialize_onexit_tables)
  000000018000551B: test        al,al
  000000018000551D: setne       al
  0000000180005520: add         rsp,28h
  0000000180005524: ret
  0000000180005525: CC CC CC CC CC CC CC                             .......
__scrt_dllmain_crt_thread_attach:
  000000018000552C: sub         rsp,28h
  0000000180005530: call        @ILT+230(__acrt_thread_attach)
  0000000180005535: test        al,al
  0000000180005537: jne         000000018000553D
  0000000180005539: xor         al,al
  000000018000553B: jmp         000000018000554F
  000000018000553D: call        @ILT+505(__acrt_thread_attach)
  0000000180005542: test        al,al
  0000000180005544: jne         000000018000554D
  0000000180005546: call        @ILT+430(__acrt_thread_detach)
  000000018000554B: jmp         0000000180005539
  000000018000554D: mov         al,1
  000000018000554F: add         rsp,28h
  0000000180005553: ret
  0000000180005554: CC CC CC CC CC CC CC CC CC CC CC CC              ............
__scrt_dllmain_crt_thread_detach:
  0000000180005560: sub         rsp,28h
  0000000180005564: call        @ILT+705(__acrt_thread_detach)
  0000000180005569: call        @ILT+430(__acrt_thread_detach)
  000000018000556E: mov         al,1
  0000000180005570: add         rsp,28h
  0000000180005574: ret
  0000000180005575: CC CC CC CC CC CC CC                             .......
__scrt_dllmain_exception_filter:
  000000018000557C: mov         qword ptr [rsp+8],rbx
  0000000180005581: mov         qword ptr [rsp+10h],rbp
  0000000180005586: mov         qword ptr [rsp+18h],rsi
  000000018000558B: push        rdi
  000000018000558C: sub         rsp,20h
  0000000180005590: mov         rdi,r9
  0000000180005593: mov         rsi,r8
  0000000180005596: mov         ebx,edx
  0000000180005598: mov         rbp,rcx
  000000018000559B: call        @ILT+390(__scrt_is_ucrt_dll_in_use)
  00000001800055A0: test        eax,eax
  00000001800055A2: jne         00000001800055BA
  00000001800055A4: cmp         ebx,1
  00000001800055A7: jne         00000001800055BA
  00000001800055A9: mov         r8,rsi
  00000001800055AC: xor         edx,edx
  00000001800055AE: mov         rcx,rbp
  00000001800055B1: mov         rax,rdi
  00000001800055B4: call        qword ptr [__guard_dispatch_icall_fptr]
  00000001800055BA: mov         rdx,qword ptr [rsp+58h]
  00000001800055BF: mov         ecx,dword ptr [rsp+50h]
  00000001800055C3: mov         rbx,qword ptr [rsp+30h]
  00000001800055C8: mov         rbp,qword ptr [rsp+38h]
  00000001800055CD: mov         rsi,qword ptr [rsp+40h]
  00000001800055D2: add         rsp,20h
  00000001800055D6: pop         rdi
  00000001800055D7: jmp         _seh_filter_dll
  00000001800055DC: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800055EC: CC CC CC CC CC CC CC CC                          ........
__scrt_dllmain_uninitialize_c:
  00000001800055F4: sub         rsp,28h
  00000001800055F8: call        @ILT+390(__scrt_is_ucrt_dll_in_use)
  00000001800055FD: test        eax,eax
  00000001800055FF: je          0000000180005611
  0000000180005601: lea         rcx,[18000EB60h]
  0000000180005608: add         rsp,28h
  000000018000560C: jmp         _execute_onexit_table
  0000000180005611: call        @ILT+120(__scrt_stub_for_is_c_termination_complete)
  0000000180005616: test        eax,eax
  0000000180005618: jne         000000018000561F
  000000018000561A: call        _cexit
  000000018000561F: add         rsp,28h
  0000000180005623: ret
  0000000180005624: CC CC CC CC CC CC CC CC CC CC CC CC              ............
__scrt_dllmain_uninitialize_critical:
  0000000180005630: sub         rsp,28h
  0000000180005634: xor         ecx,ecx
  0000000180005636: call        @ILT+495(__acrt_uninitialize_critical)
  000000018000563B: add         rsp,28h
  000000018000563F: jmp         @ILT+780(__acrt_uninitialize_critical)
  0000000180005644: CC CC CC CC CC CC CC CC                          ........
__scrt_initialize_crt:
  000000018000564C: sub         rsp,28h
  0000000180005650: test        ecx,ecx
  0000000180005652: jne         000000018000565B
  0000000180005654: mov         byte ptr [18000EB58h],1
  000000018000565B: call        @ILT+950(__isa_available_init)
  0000000180005660: call        @ILT+115(__acrt_initialize)
  0000000180005665: test        al,al
  0000000180005667: jne         000000018000566D
  0000000180005669: xor         al,al
  000000018000566B: jmp         0000000180005681
  000000018000566D: call        @ILT+885(__acrt_initialize)
  0000000180005672: test        al,al
  0000000180005674: jne         000000018000567F
  0000000180005676: xor         ecx,ecx
  0000000180005678: call        @ILT+200(__acrt_uninitialize)
  000000018000567D: jmp         0000000180005669
  000000018000567F: mov         al,1
  0000000180005681: add         rsp,28h
  0000000180005685: ret
  0000000180005686: CC CC CC CC CC CC CC CC CC CC CC CC CC CC        ..............
__scrt_initialize_onexit_tables:
  0000000180005694: push        rbx
  0000000180005696: sub         rsp,20h
  000000018000569A: cmp         byte ptr [18000EB59h],0
  00000001800056A1: mov         ebx,ecx
  00000001800056A3: jne         000000018000570C
  00000001800056A5: cmp         ecx,1
  00000001800056A8: ja          0000000180005714
  00000001800056AA: call        @ILT+390(__scrt_is_ucrt_dll_in_use)
  00000001800056AF: test        eax,eax
  00000001800056B1: je          00000001800056DB
  00000001800056B3: test        ebx,ebx
  00000001800056B5: jne         00000001800056DB
  00000001800056B7: lea         rcx,[18000EB60h]
  00000001800056BE: call        _initialize_onexit_table
  00000001800056C3: test        eax,eax
  00000001800056C5: jne         00000001800056D7
  00000001800056C7: lea         rcx,[18000EB78h]
  00000001800056CE: call        _initialize_onexit_table
  00000001800056D3: test        eax,eax
  00000001800056D5: je          0000000180005705
  00000001800056D7: xor         al,al
  00000001800056D9: jmp         000000018000570E
  00000001800056DB: movdqa      xmm0,xmmword ptr [__xmm@ffffffffffffffffffffffffffffffff]
  00000001800056E3: or          rax,0FFFFFFFFFFFFFFFFh
  00000001800056E7: movdqu      xmmword ptr [18000EB60h],xmm0
  00000001800056EF: mov         qword ptr [18000EB70h],rax
  00000001800056F6: movdqu      xmmword ptr [18000EB78h],xmm0
  00000001800056FE: mov         qword ptr [18000EB88h],rax
  0000000180005705: mov         byte ptr [18000EB59h],1
  000000018000570C: mov         al,1
  000000018000570E: add         rsp,20h
  0000000180005712: pop         rbx
  0000000180005713: ret
  0000000180005714: mov         ecx,5
  0000000180005719: call        @ILT+955(__scrt_fastfail)
  000000018000571E: int         3
  000000018000571F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000572F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000573F: CC CC CC CC CC                                   .....
__scrt_is_nonwritable_in_current_image:
  0000000180005744: sub         rsp,18h
  0000000180005748: mov         r8,rcx
  000000018000574B: mov         eax,5A4Dh
  0000000180005750: cmp         word ptr [180000000h],ax
  0000000180005757: jne         00000001800057D1
  0000000180005759: movsxd      rcx,dword ptr [18000003Ch]
  0000000180005760: lea         rdx,[180000000h]
  0000000180005767: add         rcx,rdx
  000000018000576A: cmp         dword ptr [rcx],4550h
  0000000180005770: jne         00000001800057D1
  0000000180005772: mov         eax,20Bh
  0000000180005777: cmp         word ptr [rcx+18h],ax
  000000018000577B: jne         00000001800057D1
  000000018000577D: sub         r8,rdx
  0000000180005780: movzx       edx,word ptr [rcx+14h]
  0000000180005784: add         rdx,18h
  0000000180005788: add         rdx,rcx
  000000018000578B: movzx       eax,word ptr [rcx+6]
  000000018000578F: lea         rcx,[rax+rax*4]
  0000000180005793: lea         r9,[rdx+rcx*8]
  0000000180005797: mov         qword ptr [rsp],rdx
  000000018000579B: cmp         rdx,r9
  000000018000579E: je          00000001800057B8
  00000001800057A0: mov         ecx,dword ptr [rdx+0Ch]
  00000001800057A3: cmp         r8,rcx
  00000001800057A6: jb          00000001800057B2
  00000001800057A8: mov         eax,dword ptr [rdx+8]
  00000001800057AB: add         eax,ecx
  00000001800057AD: cmp         r8,rax
  00000001800057B0: jb          00000001800057BA
  00000001800057B2: add         rdx,28h
  00000001800057B6: jmp         0000000180005797
  00000001800057B8: xor         edx,edx
  00000001800057BA: test        rdx,rdx
  00000001800057BD: jne         00000001800057C3
  00000001800057BF: xor         al,al
  00000001800057C1: jmp         00000001800057D7
  00000001800057C3: cmp         dword ptr [rdx+24h],0
  00000001800057C7: jge         00000001800057CD
  00000001800057C9: xor         al,al
  00000001800057CB: jmp         00000001800057D7
  00000001800057CD: mov         al,1
  00000001800057CF: jmp         00000001800057D7
  00000001800057D1: xor         al,al
  00000001800057D3: jmp         00000001800057D7
  00000001800057D5: xor         al,al
  00000001800057D7: add         rsp,18h
  00000001800057DB: ret
  00000001800057DC: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800057EC: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800057FC: CC CC CC CC CC CC CC CC                          ........
__scrt_release_startup_lock:
  0000000180005804: push        rbx
  0000000180005806: sub         rsp,20h
  000000018000580A: mov         bl,cl
  000000018000580C: call        @ILT+390(__scrt_is_ucrt_dll_in_use)
  0000000180005811: xor         edx,edx
  0000000180005813: test        eax,eax
  0000000180005815: je          0000000180005822
  0000000180005817: test        bl,bl
  0000000180005819: jne         0000000180005822
  000000018000581B: xchg        rdx,qword ptr [__scrt_native_startup_lock]
  0000000180005822: add         rsp,20h
  0000000180005826: pop         rbx
  0000000180005827: ret
  0000000180005828: CC CC CC CC CC CC CC CC CC CC CC CC              ............
__scrt_uninitialize_crt:
  0000000180005834: push        rbx
  0000000180005836: sub         rsp,20h
  000000018000583A: cmp         byte ptr [18000EB58h],0
  0000000180005841: mov         bl,cl
  0000000180005843: je          0000000180005849
  0000000180005845: test        dl,dl
  0000000180005847: jne         0000000180005855
  0000000180005849: call        @ILT+710(__acrt_uninitialize)
  000000018000584E: mov         cl,bl
  0000000180005850: call        @ILT+200(__acrt_uninitialize)
  0000000180005855: mov         al,1
  0000000180005857: add         rsp,20h
  000000018000585B: pop         rbx
  000000018000585C: ret
  000000018000585D: CC CC CC CC CC CC CC CC CC CC CC                 ...........
_onexit:
  0000000180005868: push        rbx
  000000018000586A: sub         rsp,20h
  000000018000586E: cmp         qword ptr [18000EB60h],0FFFFFFFFFFFFFFFFh
  0000000180005876: mov         rbx,rcx
  0000000180005879: jne         0000000180005882
  000000018000587B: call        _crt_atexit
  0000000180005880: jmp         0000000180005891
  0000000180005882: mov         rdx,rbx
  0000000180005885: lea         rcx,[18000EB60h]
  000000018000588C: call        _register_onexit_function
  0000000180005891: xor         edx,edx
  0000000180005893: test        eax,eax
  0000000180005895: cmove       rdx,rbx
  0000000180005899: mov         rax,rdx
  000000018000589C: add         rsp,20h
  00000001800058A0: pop         rbx
  00000001800058A1: ret
  00000001800058A2: CC CC CC CC CC CC CC CC CC CC CC CC CC CC        ..............
at_quick_exit:
  00000001800058B0: cmp         qword ptr [18000EB78h],0FFFFFFFFFFFFFFFFh
  00000001800058B8: je          _crt_at_quick_exit
  00000001800058BE: mov         rdx,rcx
  00000001800058C1: lea         rcx,[18000EB78h]
  00000001800058C8: jmp         _register_onexit_function
  00000001800058CD: CC CC CC CC CC CC CC                             .......
atexit:
  00000001800058D4: sub         rsp,28h
  00000001800058D8: call        @ILT+160(_onexit)
  00000001800058DD: neg         rax
  00000001800058E0: sbb         eax,eax
  00000001800058E2: neg         eax
  00000001800058E4: dec         eax
  00000001800058E6: add         rsp,28h
  00000001800058EA: ret
  00000001800058EB: CC CC CC CC CC                                   .....
__scrt_get_dyn_tls_init_callback:
  00000001800058F0: lea         rax,[__dyn_tls_init_callback]
  00000001800058F7: ret
  00000001800058F8: CC CC CC CC                                      ....
__crt_debugger_hook:
  00000001800058FC: mov         dword ptr [__scrt_debugger_hook_flag],0
  0000000180005906: ret
  0000000180005907: CC CC CC CC CC                                   .....
__scrt_fastfail:
  000000018000590C: mov         qword ptr [rsp+8],rbx
  0000000180005911: push        rbp
  0000000180005912: lea         rbp,[rsp-4C0h]
  000000018000591A: sub         rsp,5C0h
  0000000180005921: mov         ebx,ecx
  0000000180005923: mov         ecx,17h
  0000000180005928: call        qword ptr [__imp_IsProcessorFeaturePresent]
  000000018000592E: test        eax,eax
  0000000180005930: je          0000000180005936
  0000000180005932: mov         ecx,ebx
  0000000180005934: int         29h
  0000000180005936: mov         ecx,3
  000000018000593B: call        @ILT+900(__crt_debugger_hook)
  0000000180005940: xor         edx,edx
  0000000180005942: lea         rcx,[rbp-10h]
  0000000180005946: mov         r8d,4D0h
  000000018000594C: call        memset
  0000000180005951: lea         rcx,[rbp-10h]
  0000000180005955: call        qword ptr [__imp_RtlCaptureContext]
  000000018000595B: mov         rbx,qword ptr [rbp+0E8h]
  0000000180005962: lea         rdx,[rbp+4D8h]
  0000000180005969: mov         rcx,rbx
  000000018000596C: xor         r8d,r8d
  000000018000596F: call        qword ptr [__imp_RtlLookupFunctionEntry]
  0000000180005975: test        rax,rax
  0000000180005978: je          00000001800059B9
  000000018000597A: mov         rdx,qword ptr [rbp+4D8h]
  0000000180005981: lea         rcx,[rbp+4E0h]
  0000000180005988: mov         qword ptr [rsp+38h],0
  0000000180005991: mov         r9,rax
  0000000180005994: mov         qword ptr [rsp+30h],rcx
  0000000180005999: mov         r8,rbx
  000000018000599C: lea         rcx,[rbp+4E8h]
  00000001800059A3: mov         qword ptr [rsp+28h],rcx
  00000001800059A8: lea         rcx,[rbp-10h]
  00000001800059AC: mov         qword ptr [rsp+20h],rcx
  00000001800059B1: xor         ecx,ecx
  00000001800059B3: call        qword ptr [__imp_RtlVirtualUnwind]
  00000001800059B9: mov         rax,qword ptr [rbp+4C8h]
  00000001800059C0: lea         rcx,[rsp+50h]
  00000001800059C5: mov         qword ptr [rbp+0E8h],rax
  00000001800059CC: xor         edx,edx
  00000001800059CE: lea         rax,[rbp+4C8h]
  00000001800059D5: mov         r8d,98h
  00000001800059DB: add         rax,8
  00000001800059DF: mov         qword ptr [rbp+88h],rax
  00000001800059E6: call        memset
  00000001800059EB: mov         rax,qword ptr [rbp+4C8h]
  00000001800059F2: mov         qword ptr [rsp+60h],rax
  00000001800059F7: mov         dword ptr [rsp+50h],40000015h
  00000001800059FF: mov         dword ptr [rsp+54h],1
  0000000180005A07: call        qword ptr [__imp_IsDebuggerPresent]
  0000000180005A0D: mov         ebx,eax
  0000000180005A0F: xor         ecx,ecx
  0000000180005A11: lea         rax,[rsp+50h]
  0000000180005A16: mov         qword ptr [rsp+40h],rax
  0000000180005A1B: lea         rax,[rbp-10h]
  0000000180005A1F: mov         qword ptr [rsp+48h],rax
  0000000180005A24: call        qword ptr [__imp_SetUnhandledExceptionFilter]
  0000000180005A2A: lea         rcx,[rsp+40h]
  0000000180005A2F: call        qword ptr [__imp_UnhandledExceptionFilter]
  0000000180005A35: test        eax,eax
  0000000180005A37: jne         0000000180005A46
  0000000180005A39: cmp         ebx,1
  0000000180005A3C: je          0000000180005A46
  0000000180005A3E: lea         ecx,[rax+3]
  0000000180005A41: call        @ILT+900(__crt_debugger_hook)
  0000000180005A46: mov         rbx,qword ptr [rsp+5D0h]
  0000000180005A4E: add         rsp,5C0h
  0000000180005A55: pop         rbp
  0000000180005A56: ret
  0000000180005A57: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180005A67: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180005A77: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180005A87: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180005A97: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180005AA7: CC CC CC CC CC                                   .....
__scrt_get_show_window_mode:
  0000000180005AAC: sub         rsp,98h
  0000000180005AB3: xor         edx,edx
  0000000180005AB5: lea         rcx,[rsp+20h]
  0000000180005ABA: lea         r8d,[rdx+68h]
  0000000180005ABE: call        memset
  0000000180005AC3: lea         rcx,[rsp+20h]
  0000000180005AC8: call        qword ptr [__imp_GetStartupInfoW]
  0000000180005ACE: test        byte ptr [rsp+5Ch],1
  0000000180005AD3: mov         eax,0Ah
  0000000180005AD8: cmovne      ax,word ptr [rsp+60h]
  0000000180005ADE: add         rsp,98h
  0000000180005AE5: ret
  0000000180005AE6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC        ..............
__scrt_initialize_mta:
  0000000180005AF4: jmp         @ILT+10(__scrt_exe_initialize_mta)
  0000000180005AF9: CC CC CC                                         ...
__scrt_initialize_winrt:
  0000000180005AFC: xor         eax,eax
  0000000180005AFE: ret
  0000000180005AFF: CC                                               .
__scrt_is_managed_app:
  0000000180005B00: sub         rsp,28h
  0000000180005B04: xor         ecx,ecx
  0000000180005B06: call        qword ptr [__imp_GetModuleHandleW]
  0000000180005B0C: test        rax,rax
  0000000180005B0F: je          0000000180005B4B
  0000000180005B11: mov         ecx,5A4Dh
  0000000180005B16: cmp         word ptr [rax],cx
  0000000180005B19: jne         0000000180005B4B
  0000000180005B1B: movsxd      rcx,dword ptr [rax+3Ch]
  0000000180005B1F: cmp         dword ptr [rcx+rax],4550h
  0000000180005B26: jne         0000000180005B4B
  0000000180005B28: mov         edx,20Bh
  0000000180005B2D: cmp         word ptr [rcx+rax+18h],dx
  0000000180005B32: jne         0000000180005B4B
  0000000180005B34: cmp         dword ptr [rcx+rax+84h],0Eh
  0000000180005B3C: jbe         0000000180005B4B
  0000000180005B3E: cmp         dword ptr [rcx+rax+0F8h],0
  0000000180005B46: setne       al
  0000000180005B49: jmp         0000000180005B4D
  0000000180005B4B: xor         al,al
  0000000180005B4D: add         rsp,28h
  0000000180005B51: ret
  0000000180005B52: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180005B62: CC CC CC CC CC CC                                ......
__scrt_set_unhandled_exception_filter:
  0000000180005B68: lea         rcx,[@ILT+280(__scrt_unhandled_exception_filter)]
  0000000180005B6F: jmp         qword ptr [__imp_SetUnhandledExceptionFilter]
  0000000180005B76: CC CC CC CC CC CC                                ......
__scrt_exe_initialize_mta:
  0000000180005B7C: xor         eax,eax
  0000000180005B7E: ret
  0000000180005B7F: CC                                               .
__scrt_unhandled_exception_filter:
  0000000180005B80: mov         qword ptr [rsp+8],rbx
  0000000180005B85: push        rdi
  0000000180005B86: sub         rsp,20h
  0000000180005B8A: mov         rbx,qword ptr [rcx]
  0000000180005B8D: mov         rdi,rcx
  0000000180005B90: cmp         dword ptr [rbx],0E06D7363h
  0000000180005B96: jne         0000000180005BBC
  0000000180005B98: cmp         dword ptr [rbx+18h],4
  0000000180005B9C: jne         0000000180005BBC
  0000000180005B9E: mov         edx,dword ptr [rbx+20h]
  0000000180005BA1: cmp         edx,19930520h
  0000000180005BA7: je          0000000180005BC9
  0000000180005BA9: lea         eax,[rdx-19930521h]
  0000000180005BAF: cmp         eax,1
  0000000180005BB2: jbe         0000000180005BC9
  0000000180005BB4: cmp         edx,1994000h
  0000000180005BBA: je          0000000180005BC9
  0000000180005BBC: mov         rbx,qword ptr [rsp+30h]
  0000000180005BC1: xor         eax,eax
  0000000180005BC3: add         rsp,20h
  0000000180005BC7: pop         rdi
  0000000180005BC8: ret
  0000000180005BC9: call        __current_exception
  0000000180005BCE: mov         qword ptr [rax],rbx
  0000000180005BD1: mov         rbx,qword ptr [rdi+8]
  0000000180005BD5: call        __current_exception_context
  0000000180005BDA: mov         qword ptr [rax],rbx
  0000000180005BDD: call        terminate
  0000000180005BE2: int         3
  0000000180005BE3: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180005BF3: CC CC CC CC CC CC CC CC CC                       .........
_RTC_Initialize:
  0000000180005BFC: mov         qword ptr [rsp+8],rbx
  0000000180005C01: push        rdi
  0000000180005C02: sub         rsp,20h
  0000000180005C06: lea         rbx,[18000B598h]
  0000000180005C0D: lea         rdi,[__rtc_izz]
  0000000180005C14: jmp         0000000180005C28
  0000000180005C16: mov         rax,qword ptr [rbx]
  0000000180005C19: test        rax,rax
  0000000180005C1C: je          0000000180005C24
  0000000180005C1E: call        qword ptr [__guard_dispatch_icall_fptr]
  0000000180005C24: add         rbx,8
  0000000180005C28: cmp         rbx,rdi
  0000000180005C2B: jb          0000000180005C16
  0000000180005C2D: mov         rbx,qword ptr [rsp+30h]
  0000000180005C32: add         rsp,20h
  0000000180005C36: pop         rdi
  0000000180005C37: ret
  0000000180005C38: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
_RTC_Terminate:
  0000000180005C48: mov         qword ptr [rsp+8],rbx
  0000000180005C4D: push        rdi
  0000000180005C4E: sub         rsp,20h
  0000000180005C52: lea         rbx,[18000B7B8h]
  0000000180005C59: lea         rdi,[__rtc_tzz]
  0000000180005C60: jmp         0000000180005C74
  0000000180005C62: mov         rax,qword ptr [rbx]
  0000000180005C65: test        rax,rax
  0000000180005C68: je          0000000180005C70
  0000000180005C6A: call        qword ptr [__guard_dispatch_icall_fptr]
  0000000180005C70: add         rbx,8
  0000000180005C74: cmp         rbx,rdi
  0000000180005C77: jb          0000000180005C62
  0000000180005C79: mov         rbx,qword ptr [rsp+30h]
  0000000180005C7E: add         rsp,20h
  0000000180005C82: pop         rdi
  0000000180005C83: ret
  0000000180005C84: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
_guard_check_icall_nop:
  0000000180005C94: ret         0
  0000000180005C97: CC                                               .
ReadNoFence64:
  0000000180005C98: mov         rax,qword ptr [rcx]
  0000000180005C9B: ret
ReadPointerNoFence:
  0000000180005C9C: mov         rax,qword ptr [rcx]
  0000000180005C9F: ret
__castguard_check_failure_debugbreak:
  0000000180005CA0: lea         rdx,[18000AD80h]
  0000000180005CA7: lea         rax,[__CastGuardVftablesEnd]
  0000000180005CAE: sub         rcx,rdx
  0000000180005CB1: sub         rax,rdx
  0000000180005CB4: cmp         rcx,rax
  0000000180005CB7: ja          0000000180005CBA
  0000000180005CB9: int         3
  0000000180005CBA: ret
  0000000180005CBB: CC CC CC CC CC CC CC CC CC                       .........
__castguard_check_failure_fastfail:
  0000000180005CC4: lea         rdx,[18000AD80h]
  0000000180005CCB: lea         rax,[__CastGuardVftablesEnd]
  0000000180005CD2: sub         rcx,rdx
  0000000180005CD5: sub         rax,rdx
  0000000180005CD8: cmp         rcx,rax
  0000000180005CDB: ja          0000000180005CE4
  0000000180005CDD: mov         ecx,41h
  0000000180005CE2: int         29h
  0000000180005CE4: ret
  0000000180005CE5: CC CC CC CC CC CC CC CC CC CC CC                 ...........
__castguard_check_failure_nop:
  0000000180005CF0: ret         0
  0000000180005CF3: CC                                               .
__castguard_check_failure_os_handled:
  0000000180005CF4: sub         rsp,28h
  0000000180005CF8: lea         r8,[18000AD80h]
  0000000180005CFF: mov         rax,rcx
  0000000180005D02: lea         rdx,[__CastGuardVftablesEnd]
  0000000180005D09: sub         rax,r8
  0000000180005D0C: sub         rdx,r8
  0000000180005D0F: cmp         rax,rdx
  0000000180005D12: ja          0000000180005D22
  0000000180005D14: mov         rax,qword ptr [__castguard_check_failure_os_handled_fptr]
  0000000180005D1B: test        rax,rax
  0000000180005D1E: je          0000000180005D22
  0000000180005D20: call        rax
  0000000180005D22: add         rsp,28h
  0000000180005D26: ret
  0000000180005D27: CC CC CC CC CC CC CC CC CC CC CC CC CC           .............
__castguard_check_failure_os_handled_wrapper:
  0000000180005D34: sub         rsp,28h
  0000000180005D38: mov         rax,qword ptr [__castguard_check_failure_os_handled_fptr]
  0000000180005D3F: test        rax,rax
  0000000180005D42: je          0000000180005D46
  0000000180005D44: call        rax
  0000000180005D46: add         rsp,28h
  0000000180005D4A: ret
  0000000180005D4B: CC CC CC CC CC                                   .....
__castguard_check_failure_user_handled:
  0000000180005D50: sub         rsp,28h
  0000000180005D54: lea         r8,[18000AD80h]
  0000000180005D5B: mov         rax,rcx
  0000000180005D5E: lea         rdx,[__CastGuardVftablesEnd]
  0000000180005D65: sub         rax,r8
  0000000180005D68: sub         rdx,r8
  0000000180005D6B: cmp         rax,rdx
  0000000180005D6E: ja          0000000180005D82
  0000000180005D70: mov         rax,qword ptr [__castguard_check_failure_user_handled_fptr]
  0000000180005D77: test        rax,rax
  0000000180005D7A: je          0000000180005D82
  0000000180005D7C: call        qword ptr [__guard_dispatch_icall_fptr]
  0000000180005D82: add         rsp,28h
  0000000180005D86: ret
  0000000180005D87: CC CC CC CC CC CC CC CC CC CC CC CC CC           .............
__castguard_check_failure_user_handled_wrapper:
  0000000180005D94: sub         rsp,28h
  0000000180005D98: mov         rax,qword ptr [__castguard_check_failure_user_handled_fptr]
  0000000180005D9F: test        rax,rax
  0000000180005DA2: je          0000000180005DAA
  0000000180005DA4: call        qword ptr [__guard_dispatch_icall_fptr]
  0000000180005DAA: add         rsp,28h
  0000000180005DAE: ret
  0000000180005DAF: CC CC CC CC CC CC CC CC CC                       .........
__castguard_compat_check:
  0000000180005DB8: lea         rax,[18000AD80h]
  0000000180005DBF: sub         rcx,rax
  0000000180005DC2: lea         rdx,[__CastGuardVftablesEnd]
  0000000180005DC9: sub         rdx,rax
  0000000180005DCC: xor         eax,eax
  0000000180005DCE: cmp         rcx,rdx
  0000000180005DD1: setbe       al
  0000000180005DD4: ret
  0000000180005DD5: CC CC CC CC CC CC CC                             .......
__castguard_set_user_handler:
  0000000180005DDC: xchg        rcx,qword ptr [__castguard_check_failure_user_handled_fptr]
  0000000180005DE3: mov         rax,rcx
  0000000180005DE6: ret
  0000000180005DE7: CC CC CC CC CC                                   .....
__castguard_slow_path_check_debugbreak:
  0000000180005DEC: mov         rax,rcx
  0000000180005DEF: sub         rax,rdx
  0000000180005DF2: lea         rdx,[__CastGuardVftablesStart]
  0000000180005DF9: sub         rax,rdx
  0000000180005DFC: add         rax,0FFFFFFFFFFFFFF80h
  0000000180005E00: cmp         rax,r8
  0000000180005E03: jbe         0000000180005E1F
  0000000180005E05: lea         rdx,[18000AD80h]
  0000000180005E0C: lea         rax,[__CastGuardVftablesEnd]
  0000000180005E13: sub         rcx,rdx
  0000000180005E16: sub         rax,rdx
  0000000180005E19: cmp         rcx,rax
  0000000180005E1C: ja          0000000180005E1F
  0000000180005E1E: int         3
  0000000180005E1F: ret
  0000000180005E20: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
__castguard_slow_path_check_fastfail:
  0000000180005E30: mov         rax,rcx
  0000000180005E33: sub         rax,rdx
  0000000180005E36: lea         rdx,[__CastGuardVftablesStart]
  0000000180005E3D: sub         rax,rdx
  0000000180005E40: add         rax,0FFFFFFFFFFFFFF80h
  0000000180005E44: cmp         rax,r8
  0000000180005E47: jbe         0000000180005E69
  0000000180005E49: lea         rdx,[18000AD80h]
  0000000180005E50: lea         rax,[__CastGuardVftablesEnd]
  0000000180005E57: sub         rcx,rdx
  0000000180005E5A: sub         rax,rdx
  0000000180005E5D: cmp         rcx,rax
  0000000180005E60: ja          0000000180005E69
  0000000180005E62: mov         ecx,41h
  0000000180005E67: int         29h
  0000000180005E69: ret
  0000000180005E6A: CC CC CC CC CC CC CC CC CC CC CC CC CC CC        ..............
__castguard_slow_path_check_nop:
  0000000180005E78: ret         0
  0000000180005E7B: CC                                               .
__castguard_slow_path_check_os_handled:
  0000000180005E7C: sub         rsp,28h
  0000000180005E80: mov         rax,rcx
  0000000180005E83: sub         rax,rdx
  0000000180005E86: lea         rdx,[__CastGuardVftablesStart]
  0000000180005E8D: sub         rax,rdx
  0000000180005E90: add         rax,0FFFFFFFFFFFFFF80h
  0000000180005E94: cmp         rax,r8
  0000000180005E97: jbe         0000000180005EC3
  0000000180005E99: lea         r8,[18000AD80h]
  0000000180005EA0: mov         rdx,rcx
  0000000180005EA3: lea         rax,[__CastGuardVftablesEnd]
  0000000180005EAA: sub         rdx,r8
  0000000180005EAD: sub         rax,r8
  0000000180005EB0: cmp         rdx,rax
  0000000180005EB3: ja          0000000180005EC3
  0000000180005EB5: mov         rax,qword ptr [__castguard_check_failure_os_handled_fptr]
  0000000180005EBC: test        rax,rax
  0000000180005EBF: je          0000000180005EC3
  0000000180005EC1: call        rax
  0000000180005EC3: add         rsp,28h
  0000000180005EC7: ret
  0000000180005EC8: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180005ED8: CC CC CC CC                                      ....
__castguard_slow_path_check_user_handled:
  0000000180005EDC: sub         rsp,28h
  0000000180005EE0: mov         rax,rcx
  0000000180005EE3: sub         rax,rdx
  0000000180005EE6: lea         rdx,[__CastGuardVftablesStart]
  0000000180005EED: sub         rax,rdx
  0000000180005EF0: add         rax,0FFFFFFFFFFFFFF80h
  0000000180005EF4: cmp         rax,r8
  0000000180005EF7: jbe         0000000180005F27
  0000000180005EF9: lea         r8,[18000AD80h]
  0000000180005F00: mov         rdx,rcx
  0000000180005F03: lea         rax,[__CastGuardVftablesEnd]
  0000000180005F0A: sub         rdx,r8
  0000000180005F0D: sub         rax,r8
  0000000180005F10: cmp         rdx,rax
  0000000180005F13: ja          0000000180005F27
  0000000180005F15: mov         rax,qword ptr [__castguard_check_failure_user_handled_fptr]
  0000000180005F1C: test        rax,rax
  0000000180005F1F: je          0000000180005F27
  0000000180005F21: call        qword ptr [__guard_dispatch_icall_fptr]
  0000000180005F27: add         rsp,28h
  0000000180005F2B: ret
  0000000180005F2C: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180005F3C: CC CC CC CC                                      ....
__castguard_slow_path_compat_check:
  0000000180005F40: sub         rcx,rdx
  0000000180005F43: lea         rax,[__CastGuardVftablesStart]
  0000000180005F4A: sub         rcx,rax
  0000000180005F4D: xor         eax,eax
  0000000180005F4F: add         rcx,0FFFFFFFFFFFFFF80h
  0000000180005F53: cmp         rcx,r8
  0000000180005F56: seta        al
  0000000180005F59: ret
  0000000180005F5A: CC CC CC CC CC CC                                ......
_guard_icall_checks_enforced:
  0000000180005F60: mov         rcx,qword ptr [__guard_check_icall_fptr]
  0000000180005F67: lea         rdx,[@ILT+25(_guard_check_icall_nop)]
  0000000180005F6E: xor         eax,eax
  0000000180005F70: cmp         rcx,rdx
  0000000180005F73: setne       al
  0000000180005F76: ret
  0000000180005F77: CC CC CC CC CC                                   .....
_guard_rf_checks_enforced:
  0000000180005F7C: xor         eax,eax
  0000000180005F7E: ret
  0000000180005F7F: CC                                               .
??1type_info@@UEAA@XZ:
  0000000180005F80: lea         rax,[??_7type_info@@6B@]
  0000000180005F87: mov         qword ptr [rcx],rax
  0000000180005F8A: ret
  0000000180005F8B: CC CC CC CC CC                                   .....
??_Etype_info@@UEAAPEAXI@Z:
  0000000180005F90: push        rbx
  0000000180005F92: sub         rsp,20h
  0000000180005F96: lea         rax,[??_7type_info@@6B@]
  0000000180005F9D: mov         rbx,rcx
  0000000180005FA0: mov         qword ptr [rcx],rax
  0000000180005FA3: test        dl,1
  0000000180005FA6: je          0000000180005FB2
  0000000180005FA8: mov         edx,18h
  0000000180005FAD: call        @ILT+940(??3@YAXPEAX_K@Z)
  0000000180005FB2: mov         rax,rbx
  0000000180005FB5: add         rsp,20h
  0000000180005FB9: pop         rbx
  0000000180005FBA: ret
  0000000180005FBB: CC CC CC CC CC CC CC CC CC CC CC CC CC           .............
__isa_available_init:
  0000000180005FC8: mov         qword ptr [rsp+10h],rbx
  0000000180005FCD: mov         qword ptr [rsp+18h],rbp
  0000000180005FD2: mov         qword ptr [rsp+20h],rsi
  0000000180005FD7: push        rdi
  0000000180005FD8: sub         rsp,10h
  0000000180005FDC: xor         eax,eax
  0000000180005FDE: xor         ecx,ecx
  0000000180005FE0: cpuid
  0000000180005FE2: xor         ecx,6C65746Eh
  0000000180005FE8: xor         edx,49656E69h
  0000000180005FEE: or          edx,ecx
  0000000180005FF0: mov         ebp,eax
  0000000180005FF2: mov         eax,1
  0000000180005FF7: xor         ebx,756E6547h
  0000000180005FFD: or          edx,ebx
  0000000180005FFF: lea         ecx,[rax-1]
  0000000180006002: cpuid
  0000000180006004: mov         edi,ecx
  0000000180006006: jne         0000000180006066
  0000000180006008: and         eax,0FFF3FF0h
  000000018000600D: mov         qword ptr [__memset_fast_string_threshold],8000h
  0000000180006018: mov         qword ptr [__memset_nt_threshold],0FFFFFFFFFFFFFFFFh
  0000000180006023: cmp         eax,106C0h
  0000000180006028: je          0000000180006052
  000000018000602A: cmp         eax,20660h
  000000018000602F: je          0000000180006052
  0000000180006031: cmp         eax,20670h
  0000000180006036: je          0000000180006052
  0000000180006038: add         eax,0FFFCF9B0h
  000000018000603D: cmp         eax,20h
  0000000180006040: ja          0000000180006066
  0000000180006042: mov         rcx,100010001h
  000000018000604C: bt          rcx,rax
  0000000180006050: jae         0000000180006066
  0000000180006052: mov         r8d,dword ptr [__favor]
  0000000180006059: or          r8d,1
  000000018000605D: mov         dword ptr [__favor],r8d
  0000000180006064: jmp         000000018000606D
  0000000180006066: mov         r8d,dword ptr [__favor]
  000000018000606D: xor         r9d,r9d
  0000000180006070: mov         esi,r9d
  0000000180006073: mov         r10d,r9d
  0000000180006076: mov         r11d,r9d
  0000000180006079: cmp         ebp,7
  000000018000607C: jl          00000001800060BE
  000000018000607E: lea         eax,[r9+7]
  0000000180006082: xor         ecx,ecx
  0000000180006084: cpuid
  0000000180006086: mov         esi,edx
  0000000180006088: mov         r9d,ebx
  000000018000608B: bt          ebx,9
  000000018000608F: jae         000000018000609C
  0000000180006091: or          r8d,2
  0000000180006095: mov         dword ptr [__favor],r8d
  000000018000609C: cmp         eax,1
  000000018000609F: jl          00000001800060AE
  00000001800060A1: mov         eax,7
  00000001800060A6: lea         ecx,[rax-6]
  00000001800060A9: cpuid
  00000001800060AB: mov         r10d,edx
  00000001800060AE: mov         eax,24h
  00000001800060B3: cmp         ebp,eax
  00000001800060B5: jl          00000001800060BE
  00000001800060B7: xor         ecx,ecx
  00000001800060B9: cpuid
  00000001800060BB: mov         r11d,ebx
  00000001800060BE: mov         rax,qword ptr [__isa_inverted]
  00000001800060C5: and         rax,0FFFFFFFFFFFFFFFEh
  00000001800060C9: mov         dword ptr [__isa_available],1
  00000001800060D3: mov         dword ptr [__isa_enabled],2
  00000001800060DD: mov         qword ptr [__isa_inverted],rax
  00000001800060E4: bt          edi,14h
  00000001800060E8: jae         0000000180006109
  00000001800060EA: and         rax,0FFFFFFFFFFFFFFEFh
  00000001800060EE: mov         dword ptr [__isa_available],2
  00000001800060F8: mov         qword ptr [__isa_inverted],rax
  00000001800060FF: mov         dword ptr [__isa_enabled],6
  0000000180006109: bt          edi,1Bh
  000000018000610D: jae         0000000180006246
  0000000180006113: xor         ecx,ecx
  0000000180006115: xgetbv
  0000000180006118: shl         rdx,20h
  000000018000611C: or          rdx,rax
  000000018000611F: mov         qword ptr [rsp+20h],rdx
  0000000180006124: bt          edi,1Ch
  0000000180006128: jae         000000018000622A
  000000018000612E: mov         rax,qword ptr [rsp+20h]
  0000000180006133: and         al,6
  0000000180006135: cmp         al,6
  0000000180006137: jne         000000018000622A
  000000018000613D: mov         eax,dword ptr [__isa_enabled]
  0000000180006143: mov         dl,0E0h
  0000000180006145: or          eax,8
  0000000180006148: mov         dword ptr [__isa_available],3
  0000000180006152: mov         dword ptr [__isa_enabled],eax
  0000000180006158: test        r9b,20h
  000000018000615C: je          00000001800061C0
  000000018000615E: or          eax,20h
  0000000180006161: mov         dword ptr [__isa_available],5
  000000018000616B: mov         dword ptr [__isa_enabled],eax
  0000000180006171: mov         ecx,0D0030000h
  0000000180006176: mov         rax,qword ptr [__isa_inverted]
  000000018000617D: and         r9d,ecx
  0000000180006180: and         rax,0FFFFFFFFFFFFFFFDh
  0000000180006184: mov         qword ptr [__isa_inverted],rax
  000000018000618B: cmp         r9d,ecx
  000000018000618E: jne         00000001800061C7
  0000000180006190: mov         rax,qword ptr [rsp+20h]
  0000000180006195: and         al,dl
  0000000180006197: cmp         al,dl
  0000000180006199: jne         00000001800061C0
  000000018000619B: mov         rax,qword ptr [__isa_inverted]
  00000001800061A2: or          dword ptr [__isa_enabled],40h
  00000001800061A9: and         rax,0FFFFFFFFFFFFFFDBh
  00000001800061AD: mov         dword ptr [__isa_available],6
  00000001800061B7: mov         qword ptr [__isa_inverted],rax
  00000001800061BE: jmp         00000001800061C7
  00000001800061C0: mov         rax,qword ptr [__isa_inverted]
  00000001800061C7: bt          esi,17h
  00000001800061CB: jae         00000001800061D9
  00000001800061CD: btr         rax,18h
  00000001800061D2: mov         qword ptr [__isa_inverted],rax
  00000001800061D9: bt          r10d,13h
  00000001800061DE: jae         000000018000622A
  00000001800061E0: mov         rax,qword ptr [rsp+20h]
  00000001800061E5: and         al,dl
  00000001800061E7: cmp         al,dl
  00000001800061E9: jne         000000018000622A
  00000001800061EB: mov         ecx,r11d
  00000001800061EE: mov         eax,r11d
  00000001800061F1: shr         rcx,10h
  00000001800061F5: and         eax,400FFh
  00000001800061FA: and         ecx,6
  00000001800061FD: mov         dword ptr [__avx10_version],eax
  0000000180006203: or          rcx,1000029h
  000000018000620A: not         rcx
  000000018000620D: and         rcx,qword ptr [__isa_inverted]
  0000000180006214: mov         qword ptr [__isa_inverted],rcx
  000000018000621B: cmp         al,1
  000000018000621D: jbe         000000018000622A
  000000018000621F: and         rcx,0FFFFFFFFFFFFFFBFh
  0000000180006223: mov         qword ptr [__isa_inverted],rcx
  000000018000622A: bt          r10d,15h
  000000018000622F: jae         0000000180006246
  0000000180006231: mov         rax,qword ptr [rsp+20h]
  0000000180006236: bt          rax,13h
  000000018000623B: jae         0000000180006246
  000000018000623D: btr         qword ptr [__isa_inverted],7
  0000000180006246: mov         rbx,qword ptr [rsp+28h]
  000000018000624B: xor         eax,eax
  000000018000624D: mov         rbp,qword ptr [rsp+30h]
  0000000180006252: mov         rsi,qword ptr [rsp+38h]
  0000000180006257: add         rsp,10h
  000000018000625B: pop         rdi
  000000018000625C: ret
  000000018000625D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000626D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000627D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000628D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000629D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800062AD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800062BD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800062CD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800062DD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800062ED: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800062FD: CC CC CC CC CC CC CC                             .......
_get_startup_argv_mode:
  0000000180006304: mov         eax,1
  0000000180006309: ret
  000000018000630A: CC CC                                            ..
__scrt_is_ucrt_dll_in_use:
  000000018000630C: xor         eax,eax
  000000018000630E: cmp         dword ptr [__scrt_ucrt_dll_is_in_use],eax
  0000000180006314: setne       al
  0000000180006317: ret
  0000000180006318: CC CC CC CC CC CC CC CC                          ........
__std_terminate:
  0000000180006320: jmp         qword ptr [__imp___std_terminate]
__CxxFrameHandler4:
  0000000180006326: jmp         qword ptr [__imp___CxxFrameHandler4]
memcmp:
  000000018000632C: jmp         qword ptr [__imp_memcmp]
memset:
  0000000180006332: jmp         qword ptr [__imp_memset]
__C_specific_handler:
  0000000180006338: jmp         qword ptr [__imp___C_specific_handler]
__std_exception_copy:
  000000018000633E: jmp         qword ptr [__imp___std_exception_copy]
__std_exception_destroy:
  0000000180006344: jmp         qword ptr [__imp___std_exception_destroy]
_CxxThrowException:
  000000018000634A: jmp         qword ptr [__imp__CxxThrowException]
__std_type_info_destroy_list:
  0000000180006350: jmp         qword ptr [__imp___std_type_info_destroy_list]
__current_exception:
  0000000180006356: jmp         qword ptr [__imp___current_exception]
__current_exception_context:
  000000018000635C: jmp         qword ptr [__imp___current_exception_context]
strlen:
  0000000180006362: jmp         qword ptr [__imp_strlen]
_callnewh:
  0000000180006368: jmp         qword ptr [__imp__callnewh]
malloc:
  000000018000636E: jmp         qword ptr [__imp_malloc]
_initterm:
  0000000180006374: jmp         qword ptr [__imp__initterm]
_initterm_e:
  000000018000637A: jmp         qword ptr [__imp__initterm_e]
free:
  0000000180006380: jmp         qword ptr [__imp_free]
_seh_filter_dll:
  0000000180006386: jmp         qword ptr [__imp__seh_filter_dll]
_configure_narrow_argv:
  000000018000638C: jmp         qword ptr [__imp__configure_narrow_argv]
_initialize_narrow_environment:
  0000000180006392: jmp         qword ptr [__imp__initialize_narrow_environment]
_initialize_onexit_table:
  0000000180006398: jmp         qword ptr [__imp__initialize_onexit_table]
_register_onexit_function:
  000000018000639E: jmp         qword ptr [__imp__register_onexit_function]
_execute_onexit_table:
  00000001800063A4: jmp         qword ptr [__imp__execute_onexit_table]
_crt_atexit:
  00000001800063AA: jmp         qword ptr [__imp__crt_atexit]
_crt_at_quick_exit:
  00000001800063B0: jmp         qword ptr [__imp__crt_at_quick_exit]
_cexit:
  00000001800063B6: jmp         qword ptr [__imp__cexit]
terminate:
  00000001800063BC: jmp         qword ptr [__imp_terminate]
RtlCaptureContext:
  00000001800063C2: jmp         qword ptr [__imp_RtlCaptureContext]
RtlLookupFunctionEntry:
  00000001800063C8: jmp         qword ptr [__imp_RtlLookupFunctionEntry]
RtlVirtualUnwind:
  00000001800063CE: jmp         qword ptr [__imp_RtlVirtualUnwind]
UnhandledExceptionFilter:
  00000001800063D4: jmp         qword ptr [__imp_UnhandledExceptionFilter]
SetUnhandledExceptionFilter:
  00000001800063DA: jmp         qword ptr [__imp_SetUnhandledExceptionFilter]
GetCurrentProcess:
  00000001800063E0: jmp         qword ptr [__imp_GetCurrentProcess]
TerminateProcess:
  00000001800063E6: jmp         qword ptr [__imp_TerminateProcess]
IsProcessorFeaturePresent:
  00000001800063EC: jmp         qword ptr [__imp_IsProcessorFeaturePresent]
QueryPerformanceCounter:
  00000001800063F2: jmp         qword ptr [__imp_QueryPerformanceCounter]
GetCurrentProcessId:
  00000001800063F8: jmp         qword ptr [__imp_GetCurrentProcessId]
GetCurrentThreadId:
  00000001800063FE: jmp         qword ptr [__imp_GetCurrentThreadId]
GetSystemTimeAsFileTime:
  0000000180006404: jmp         qword ptr [__imp_GetSystemTimeAsFileTime]
DisableThreadLibraryCalls:
  000000018000640A: jmp         qword ptr [__imp_DisableThreadLibraryCalls]
InitializeSListHead:
  0000000180006410: jmp         qword ptr [__imp_InitializeSListHead]
IsDebuggerPresent:
  0000000180006416: jmp         qword ptr [__imp_IsDebuggerPresent]
GetStartupInfoW:
  000000018000641C: jmp         qword ptr [__imp_GetStartupInfoW]
GetModuleHandleW:
  0000000180006422: jmp         qword ptr [__imp_GetModuleHandleW]
__acrt_initialize:
  0000000180006428: mov         al,1
  000000018000642A: ret
  000000018000642B: CC                                               .
__acrt_thread_attach:
  000000018000642C: mov         al,1
  000000018000642E: ret
  000000018000642F: CC                                               .
__acrt_thread_detach:
  0000000180006430: mov         al,1
  0000000180006432: ret
  0000000180006433: CC                                               .
__acrt_uninitialize:
  0000000180006434: mov         al,1
  0000000180006436: ret
  0000000180006437: CC                                               .
__acrt_uninitialize_critical:
  0000000180006438: mov         al,1
  000000018000643A: ret
  000000018000643B: CC                                               .
__scrt_stub_for_is_c_termination_complete:
  000000018000643C: xor         eax,eax
  000000018000643E: ret
memcpy:
  000000018000643F: jmp         qword ptr [__imp_memcpy]
  0000000180006445: CC CC CC CC CC CC CC CC CC CC CC                 ...........
?shape@LuaValueAccess@detail@lua@script@lux@@SA?AV?$expected@XULuaValueFailure@lua@script@lux@@@tl@@PEAUlua_State@@HV?$span@$$CBV?$basic_string_view@DU?$char_traits@D@std@@@std@@$0?0@std@@@Z:
  0000000180006450: push        rbx
  0000000180006452: push        rbp
  0000000180006453: push        rsi
  0000000180006454: push        rdi
  0000000180006455: sub         rsp,198h
  000000018000645C: mov         rax,qword ptr [__security_cookie]
  0000000180006463: xor         rax,rsp
  0000000180006466: mov         qword ptr [rsp+180h],rax
  000000018000646E: mov         edi,r8d
  0000000180006471: mov         byte ptr [rsp+70h],0
  0000000180006476: mov         rsi,rdx
  0000000180006479: mov         rbp,rcx
  000000018000647C: xor         edx,edx
  000000018000647E: lea         rcx,[rsp+71h]
  0000000180006483: mov         r8d,100h
  0000000180006489: mov         rbx,r9
  000000018000648C: call        memset
  0000000180006491: movups      xmm0,xmmword ptr [rbx]
  0000000180006494: xor         ecx,ecx
  0000000180006496: mov         byte ptr [rsp+171h],0
  000000018000649E: lea         rax,[180003550h]
  00000001800064A5: mov         qword ptr [rsp+38h],rcx
  00000001800064AA: mov         qword ptr [rsp+30h],rax
  00000001800064AF: lea         rdx,[rsp+30h]
  00000001800064B4: lea         rax,[rsp+70h]
  00000001800064B9: mov         qword ptr [rsp+40h],rcx
  00000001800064BE: mov         dword ptr [rsp+64h],ecx
  00000001800064C2: xor         r9d,r9d
  00000001800064C5: mov         dword ptr [rsp+20h],ecx
  00000001800064C9: mov         r8d,edi
  00000001800064CC: mov         rcx,rsi
  00000001800064CF: mov         qword ptr [rsp+58h],rax
  00000001800064D4: mov         byte ptr [rsp+60h],1
  00000001800064D9: movups      xmmword ptr [rsp+48h],xmm0
  00000001800064DE: call        0000000180003E40
  00000001800064E3: test        al,al
  00000001800064E5: je          0000000180006503
  00000001800064E7: xor         edx,edx
  00000001800064E9: mov         r8d,106h
  00000001800064EF: mov         rcx,rbp
  00000001800064F2: call        memset
  00000001800064F7: mov         byte ptr [rbp+102h],1
  00000001800064FE: jmp         0000000180006590
  0000000180006503: movzx       eax,byte ptr [rsp+70h]
  0000000180006508: mov         ecx,5
  000000018000650D: cmp         byte ptr [rsp+60h],0
  0000000180006512: mov         rdx,rbp
  0000000180006515: cmovne      eax,ecx
  0000000180006518: mov         ecx,2
  000000018000651D: mov         byte ptr [rsp+70h],al
  0000000180006521: lea         rax,[rsp+70h]
  0000000180006526: nop         word ptr [rax+rax]
  0000000180006530: lea         rdx,[rdx+80h]
  0000000180006537: movups      xmm0,xmmword ptr [rax]
  000000018000653A: movups      xmm1,xmmword ptr [rax+10h]
  000000018000653E: lea         rax,[rax+80h]
  0000000180006545: movups      xmmword ptr [rdx-80h],xmm0
  0000000180006549: movups      xmm0,xmmword ptr [rax-60h]
  000000018000654D: movups      xmmword ptr [rdx-70h],xmm1
  0000000180006551: movups      xmm1,xmmword ptr [rax-50h]
  0000000180006555: movups      xmmword ptr [rdx-60h],xmm0
  0000000180006559: movups      xmm0,xmmword ptr [rax-40h]
  000000018000655D: movups      xmmword ptr [rdx-50h],xmm1
  0000000180006561: movups      xmm1,xmmword ptr [rax-30h]
  0000000180006565: movups      xmmword ptr [rdx-40h],xmm0
  0000000180006569: movups      xmm0,xmmword ptr [rax-20h]
  000000018000656D: movups      xmmword ptr [rdx-30h],xmm1
  0000000180006571: movups      xmm1,xmmword ptr [rax-10h]
  0000000180006575: movups      xmmword ptr [rdx-20h],xmm0
  0000000180006579: movups      xmmword ptr [rdx-10h],xmm1
  000000018000657D: sub         rcx,1
  0000000180006581: jne         0000000180006530
  0000000180006583: movzx       ecx,word ptr [rax]
  0000000180006586: mov         word ptr [rdx],cx
  0000000180006589: mov         byte ptr [rbp+102h],0
  0000000180006590: mov         rax,rbp
  0000000180006593: mov         rcx,qword ptr [rsp+180h]
  000000018000659B: xor         rcx,rsp
  000000018000659E: call        @ILT+525(__security_check_cookie)
  00000001800065A3: add         rsp,198h
  00000001800065AA: pop         rdi
  00000001800065AB: pop         rsi
  00000001800065AC: pop         rbp
  00000001800065AD: pop         rbx
  00000001800065AE: ret
  00000001800065AF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800065BF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800065CF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800065DF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800065EF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800065FF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000660F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000661F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000662F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000663F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000664F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000665F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000666F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000667F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000668F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000669F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800066AF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800066BF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800066CF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800066DF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800066EF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800066FF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000670F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000671F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000672F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000673F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000674F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000675F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000676F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000677F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000678F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000679F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800067AF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800067BF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800067CF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800067DF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800067EF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800067FF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000680F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000681F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000682F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000683F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000684F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000685F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000686F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000687F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000688F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000689F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800068AF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800068BF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800068CF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800068DF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800068EF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800068FF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000690F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000691F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000692F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000693F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000694F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000695F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000696F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000697F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000698F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000699F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800069AF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800069BF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800069CF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800069DF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800069EF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800069FF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006A0F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006A1F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006A2F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006A3F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006A4F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006A5F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006A6F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006A7F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006A8F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006A9F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006AAF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006ABF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006ACF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006ADF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006AEF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006AFF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006B0F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006B1F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006B2F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006B3F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006B4F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006B5F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006B6F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006B7F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006B8F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006B9F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006BAF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006BBF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006BCF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006BDF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006BEF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006BFF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006C0F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006C1F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006C2F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006C3F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006C4F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006C5F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006C6F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006C7F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006C8F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006C9F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006CAF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006CBF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006CCF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006CDF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006CEF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006CFF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006D0F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006D1F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006D2F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006D3F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006D4F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006D5F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006D6F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006D7F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006D8F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006D9F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006DAF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006DBF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006DCF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006DDF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006DEF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006DFF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006E0F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006E1F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006E2F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006E3F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006E4F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006E5F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006E6F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006E7F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006E8F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006E9F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006EAF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006EBF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006ECF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006EDF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006EEF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006EFF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006F0F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006F1F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006F2F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006F3F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006F4F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006F5F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006F6F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006F7F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006F8F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006F9F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006FAF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006FBF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006FCF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006FDF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006FEF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180006FFF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000700F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000701F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000702F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000703F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000704F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000705F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000706F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000707F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000708F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000709F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800070AF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800070BF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800070CF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800070DF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800070EF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800070FF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000710F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000711F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000712F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000713F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000714F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000715F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000716F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000717F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000718F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000719F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800071AF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800071BF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800071CF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800071DF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800071EF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800071FF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000720F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000721F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000722F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000723F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000724F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000725F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000726F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000727F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000728F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000729F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800072AF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800072BF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800072CF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800072DF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800072EF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800072FF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000730F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000731F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000732F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000733F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000734F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000735F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000736F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000737F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000738F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000739F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800073AF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800073BF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800073CF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800073DF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800073EF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800073FF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000740F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000741F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000742F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000743F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000744F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000745F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000746F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000747F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000748F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000749F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800074AF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800074BF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800074CF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800074DF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800074EF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800074FF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000750F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000751F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000752F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000753F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000754F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000755F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000756F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000757F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000758F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000759F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800075AF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800075BF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800075CF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800075DF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800075EF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800075FF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000760F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000761F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000762F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000763F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000764F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000765F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000766F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000767F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000768F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000769F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800076AF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800076BF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800076CF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800076DF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800076EF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800076FF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000770F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000771F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000772F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000773F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000774F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000775F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000776F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000777F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000778F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000779F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800077AF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800077BF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800077CF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800077DF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800077EF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800077FF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000780F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000781F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000782F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000783F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000784F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000785F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000786F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000787F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000788F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000789F: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800078AF: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800078BF: CC                                               .
  00000001800078C0: int         3
  00000001800078C1: int         3
  00000001800078C2: int         3
  00000001800078C3: int         3
  00000001800078C4: int         3
  00000001800078C5: int         3
  00000001800078C6: nop         word ptr [rax+rax]
_guard_dispatch_icall_nop:
  00000001800078D0: jmp         rax
  00000001800078D2: CC CC CC CC CC CC CC CC CC CC CC CC CC CC        ..............
  00000001800078E0: int         3
  00000001800078E1: int         3
  00000001800078E2: int         3
  00000001800078E3: int         3
  00000001800078E4: int         3
  00000001800078E5: int         3
  00000001800078E6: nop         word ptr [rax+rax]
_guard_xfg_dispatch_icall_nop:
  00000001800078F0: jmp         qword ptr [__guard_dispatch_icall_fptr]
  00000001800078F6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007906: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007916: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007926: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007936: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007946: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007956: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007966: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007976: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007986: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007996: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800079A6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800079B6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800079C6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800079D6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800079E6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800079F6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007A06: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007A16: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007A26: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007A36: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007A46: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007A56: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007A66: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007A76: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007A86: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007A96: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007AA6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007AB6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007AC6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007AD6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007AE6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007AF6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007B06: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007B16: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007B26: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007B36: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007B46: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007B56: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007B66: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007B76: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007B86: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007B96: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007BA6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007BB6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007BC6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007BD6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007BE6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007BF6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007C06: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007C16: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007C26: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007C36: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007C46: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007C56: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007C66: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007C76: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007C86: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007C96: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007CA6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007CB6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007CC6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007CD6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007CE6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007CF6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007D06: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007D16: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007D26: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007D36: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007D46: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007D56: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007D66: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007D76: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007D86: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007D96: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007DA6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007DB6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007DC6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007DD6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007DE6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007DF6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007E06: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007E16: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007E26: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007E36: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007E46: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007E56: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007E66: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007E76: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007E86: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007E96: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007EA6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007EB6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007EC6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007ED6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007EE6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007EF6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007F06: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007F16: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007F26: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007F36: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007F46: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007F56: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007F66: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007F76: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007F86: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007F96: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007FA6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007FB6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007FC6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007FD6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007FE6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180007FF6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008006: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008016: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008026: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008036: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008046: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008056: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008066: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008076: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008086: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008096: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800080A6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800080B6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800080C6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800080D6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800080E6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800080F6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008106: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008116: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008126: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008136: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008146: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008156: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008166: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008176: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008186: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008196: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800081A6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800081B6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800081C6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800081D6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800081E6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800081F6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008206: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008216: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008226: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008236: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008246: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008256: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008266: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008276: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008286: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008296: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800082A6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800082B6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800082C6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800082D6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800082E6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800082F6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008306: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008316: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008326: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008336: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008346: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008356: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008366: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008376: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008386: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008396: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800083A6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800083B6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800083C6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800083D6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800083E6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800083F6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008406: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008416: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008426: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008436: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008446: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008456: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008466: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008476: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008486: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008496: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800084A6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800084B6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800084C6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800084D6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800084E6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800084F6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008506: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008516: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008526: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008536: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008546: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008556: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008566: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008576: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008586: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008596: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800085A6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800085B6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800085C6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800085D6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800085E6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800085F6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008606: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008616: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008626: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008636: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008646: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008656: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008666: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008676: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008686: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008696: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800086A6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800086B6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800086C6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800086D6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800086E6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800086F6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008706: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008716: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008726: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008736: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008746: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008756: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008766: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008776: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008786: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008796: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800087A6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800087B6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800087C6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800087D6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800087E6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800087F6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008806: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008816: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008826: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008836: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008846: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008856: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008866: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008876: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008886: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008896: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800088A6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800088B6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800088C6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800088D6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800088E6: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800088F6: CC CC CC CC CC CC CC CC                          ........
`dllmain_crt_process_attach'::`1'::fin$0:
  00000001800088FE: push        rbp
  0000000180008900: sub         rsp,20h
  0000000180008904: mov         rbp,rdx
  0000000180008907: mov         cl,byte ptr [rbp+40h]
  000000018000890A: add         rsp,20h
  000000018000890E: pop         rbp
  000000018000890F: jmp         @ILT+945(__scrt_release_startup_lock)
  0000000180008914: int         3
  0000000180008915: CC CC CC CC CC                                   .....
`dllmain_crt_process_detach'::`1'::fin$0:
  000000018000891A: push        rbp
  000000018000891C: sub         rsp,20h
  0000000180008920: mov         rbp,rdx
  0000000180008923: mov         cl,byte ptr [rbp+20h]
  0000000180008926: call        @ILT+945(__scrt_release_startup_lock)
  000000018000892B: nop
  000000018000892C: add         rsp,20h
  0000000180008930: pop         rbp
  0000000180008931: ret
  0000000180008932: int         3
`dllmain_crt_process_detach'::`1'::fin$1:
  0000000180008933: push        rbp
  0000000180008935: sub         rsp,20h
  0000000180008939: mov         rbp,rdx
  000000018000893C: add         rsp,20h
  0000000180008940: pop         rbp
  0000000180008941: jmp         @ILT+850(__scrt_dllmain_uninitialize_critical)
  0000000180008946: int         3
  0000000180008947: CC CC CC CC CC CC CC CC CC CC CC                 ...........
`dllmain_dispatch'::`1'::filt$0:
  0000000180008952: push        rbp
  0000000180008954: sub         rsp,30h
  0000000180008958: mov         rbp,rdx
  000000018000895B: mov         rax,qword ptr [rcx]
  000000018000895E: mov         edx,dword ptr [rax]
  0000000180008960: mov         qword ptr [rsp+28h],rcx
  0000000180008965: mov         dword ptr [rsp+20h],edx
  0000000180008969: lea         r9,[1800045BCh]
  0000000180008970: mov         r8,qword ptr [rbp+70h]
  0000000180008974: mov         edx,dword ptr [rbp+68h]
  0000000180008977: mov         rcx,qword ptr [rbp+60h]
  000000018000897B: call        @ILT+1110(__scrt_dllmain_exception_filter)
  0000000180008980: nop
  0000000180008981: add         rsp,30h
  0000000180008985: pop         rbp
  0000000180008986: ret
  0000000180008987: int         3
  0000000180008988: CC CC CC CC CC CC CC CC CC CC CC CC CC           .............
__scrt_is_nonwritable_in_current_image$filt$0:
  0000000180008995: push        rbp
  0000000180008997: mov         rbp,rdx
  000000018000899A: mov         rax,qword ptr [rcx]
  000000018000899D: xor         ecx,ecx
  000000018000899F: cmp         dword ptr [rax],0C0000005h
  00000001800089A5: sete        cl
  00000001800089A8: mov         eax,ecx
  00000001800089AA: pop         rbp
  00000001800089AB: ret
  00000001800089AC: int         3
  00000001800089AD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800089BD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800089CD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800089DD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800089ED: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800089FD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008A0D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008A1D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008A2D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008A3D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008A4D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008A5D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008A6D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008A7D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008A8D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008A9D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008AAD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008ABD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008ACD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008ADD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008AED: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008AFD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008B0D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008B1D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008B2D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008B3D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008B4D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008B5D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008B6D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008B7D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008B8D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008B9D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008BAD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008BBD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008BCD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008BDD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008BED: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008BFD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008C0D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008C1D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008C2D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008C3D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008C4D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008C5D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008C6D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008C7D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008C8D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008C9D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008CAD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008CBD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008CCD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008CDD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008CED: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008CFD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008D0D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008D1D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008D2D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008D3D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008D4D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008D5D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008D6D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008D7D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008D8D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008D9D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008DAD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008DBD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008DCD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008DDD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008DED: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008DFD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008E0D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008E1D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008E2D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008E3D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008E4D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008E5D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008E6D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008E7D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008E8D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008E9D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008EAD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008EBD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008ECD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008EDD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008EED: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008EFD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008F0D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008F1D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008F2D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008F3D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008F4D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008F5D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008F6D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008F7D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008F8D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008F9D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008FAD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008FBD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008FCD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008FDD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008FED: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  0000000180008FFD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000900D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000901D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000902D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000903D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000904D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000905D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000906D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000907D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000908D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000909D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800090AD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800090BD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800090CD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800090DD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800090ED: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800090FD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000910D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000911D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000912D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000913D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000914D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000915D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000916D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000917D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000918D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000919D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800091AD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800091BD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800091CD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800091DD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800091ED: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800091FD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000920D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000921D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000922D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000923D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000924D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000925D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000926D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000927D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000928D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000929D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800092AD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800092BD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800092CD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800092DD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800092ED: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800092FD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000930D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000931D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000932D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000933D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000934D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000935D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000936D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000937D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000938D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000939D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800093AD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800093BD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800093CD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800093DD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800093ED: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800093FD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000940D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000941D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000942D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000943D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000944D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000945D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000946D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000947D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000948D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000949D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800094AD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800094BD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800094CD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800094DD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800094ED: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800094FD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000950D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000951D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000952D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000953D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000954D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000955D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000956D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000957D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000958D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000959D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800095AD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800095BD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800095CD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800095DD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800095ED: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800095FD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000960D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000961D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000962D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000963D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000964D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000965D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000966D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000967D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000968D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000969D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800096AD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800096BD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800096CD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800096DD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800096ED: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800096FD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000970D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000971D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000972D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000973D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000974D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000975D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000976D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000977D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000978D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000979D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800097AD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800097BD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800097CD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800097DD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800097ED: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800097FD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000980D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000981D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000982D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000983D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000984D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000985D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000986D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000987D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000988D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000989D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800098AD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800098BD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800098CD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800098DD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800098ED: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800098FD: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000990D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000991D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000992D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000993D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000994D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000995D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000996D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000997D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000998D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  000000018000999D: CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC CC  ................
  00000001800099AD: CC CC CC CC CC CC CC 00 00 00 00 00 00 00 00 00  ................

  Summary

        1000 .00cfg
        1000 .data
        2000 .idata
        1000 .pdata
        4000 .rdata
        1000 .reloc
        1000 .rsrc
        9000 .text
