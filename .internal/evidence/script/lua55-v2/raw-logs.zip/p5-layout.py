from pathlib import Path
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source')
p=r/'engine/toolchain/flowforge/pinclude/lux/engine/flowforge/compiler/ContinuationFrameLayout.hpp'
p.write_text('''#pragma once
#include <llvm/IR/CFG.h>
#include <llvm/IR/Instructions.h>
#include <llvm/IR/IntrinsicInst.h>
#include <llvm/ADT/SmallPtrSet.h>
#include <llvm/ADT/SmallVector.h>
#include <span>

namespace lux::flowforge::detail
{
    // Queries incoming-value liveness on the actual CFG after resume edges and PHI lowering.
    // Worklists preserve CFG order; membership sets never determine layout or cooked hashes.
    class ContinuationFrameLayout final
    {
    public:
        [[nodiscard]] static bool readsIncoming(llvm::AllocaInst& slot, llvm::BasicBlock* entry)
        {
            llvm::SmallPtrSet<llvm::Value*, 16> addresses;
            llvm::SmallVector<llvm::Value*, 16> aliases{&slot};
            addresses.insert(&slot);
            while (!aliases.empty())
            {
                auto* address = aliases.pop_back_val();
                for (auto* user : address->users())
                {
                    if (llvm::isa<llvm::GetElementPtrInst, llvm::BitCastInst>(user))
                    {
                        if (addresses.insert(user).second) aliases.push_back(user);
                    }
                    else if (auto* store = llvm::dyn_cast<llvm::StoreInst>(user))
                    {
                        if (store->getValueOperand() == address) return true; // Address escapes.
                    }
                    else if (!llvm::isa<llvm::LoadInst, llvm::DbgInfoIntrinsic, llvm::LifetimeIntrinsic>(user))
                        return true; // Unknown aliasing/call contracts remain conservative.
                }
            }
            llvm::SmallPtrSet<llvm::BasicBlock*, 32> visited;
            llvm::SmallVector<llvm::BasicBlock*, 16> work{entry};
            while (!work.empty())
            {
                auto* block = work.pop_back_val();
                if (!visited.insert(block).second) continue;
                bool killed{};
                for (auto& instruction : *block)
                {
                    if (auto* load = llvm::dyn_cast<llvm::LoadInst>(&instruction))
                        if (addresses.contains(load->getPointerOperand())) return true;
                    if (auto* store = llvm::dyn_cast<llvm::StoreInst>(&instruction))
                    {
                        const bool full_store = store->getPointerOperand() == &slot &&
                            store->getValueOperand()->getType() == slot.getAllocatedType() &&
                            llvm::cast<llvm::ConstantInt>(slot.getArraySize())->isOne();
                        if (full_store) { killed = true; break; }
                    }
                }
                if (!killed)
                    for (auto* successor : llvm::successors(block)) work.push_back(successor);
            }
            return false;
        }
        [[nodiscard]] static bool persists(llvm::AllocaInst& slot, std::span<llvm::BasicBlock* const> resumes)
        {
            for (auto* entry : resumes) if (readsIncoming(slot, entry)) return true;
            return false;
        }
        [[nodiscard]] static bool argumentPersists(llvm::Argument& argument,
            std::span<llvm::BasicBlock* const> resumes)
        {
            llvm::SmallPtrSet<llvm::BasicBlock*, 32> visited;
            llvm::SmallVector<llvm::BasicBlock*, 16> work(resumes.begin(), resumes.end());
            while (!work.empty())
            {
                auto* block = work.pop_back_val();
                if (!visited.insert(block).second) continue;
                for (auto* user : argument.users())
                    if (auto* instruction = llvm::dyn_cast<llvm::Instruction>(user))
                        if (instruction->getParent() == block) return true;
                for (auto* successor : llvm::successors(block)) work.push_back(successor);
            }
            return false;
        }
    };
}
''')
p=r/'engine/toolchain/flowforge/src/AOT.cpp';t=p.read_text();t=t.replace('#include "lux/engine/flowforge/compiler/SuspensionAnalysis.hpp"','#include "lux/engine/flowforge/compiler/SuspensionAnalysis.hpp"\n#include "lux/engine/flowforge/compiler/ContinuationFrameLayout.hpp"');t=t.replace('wrapper pulls the explicit native instance context from the v5 frame,','wrapper receives the explicit native instance context (ABI v6),');
# Delay all persistence layout until after actual resume CFG and dominance repair.
a=t.index('            struct FrameSlot final'); b=t.index('            auto* cloned_entry',a)
t=t[:a]+'''            struct FrameSlot final
            {
                std::uint64_t offset{}, size{}, alignment{};
                bool needs_initial_value{};
            };
            std::vector<std::uint64_t> argument_offsets(target->arg_size(), UINT64_MAX);
            std::vector<FrameSlot> slots;
            std::uint64_t frame_size{sizeof(std::uint32_t)};
            std::uint64_t frame_alignment{alignof(std::uint32_t)};
            const auto& layout = module.getDataLayout();
            std::vector<llvm::BasicBlock*> resume_entries;

'''+t[b:]
t=t.replace('            auto* pc = dispatch_builder.CreateLoad(i32, frame_argument, "pc");','''            auto* token_storage = dispatch_builder.CreateAlloca(i64, nullptr, "wait.token.local");
            auto* pc = dispatch_builder.CreateLoad(i32, frame_argument, "pc");''')
t=t.replace('''                auto* scratch =
                    suspend_builder.CreateGEP(i8, frame_argument, llvm::ConstantInt::get(i64, scratch_offset));
                auto* token = scratch;''','''                auto* token = token_storage;''')
# Split admission failure BEFORE reading token; no load/select of unwritten bytes.
a=t.index('                const auto next_pc =');b=t.index('                auto* resume_entry =',a)
t=t[:a]+'''                const auto next_pc = static_cast<std::uint32_t>(await_index + 1U);
                auto* accepted = llvm::BasicBlock::Create(context, "wait.accepted", core);
                auto* rejected = llvm::BasicBlock::Create(context, "wait.rejected", core);
                suspend_builder.CreateCondBr(
                    suspend_builder.CreateICmpEQ(status, llvm::ConstantInt::get(i32, 0U)), accepted, rejected
                );
                llvm::IRBuilder<> rejected_builder(rejected);
                storeOutcomeField(rejected_builder, outcome_argument, offsetof(lux_script_step_outcome, state),
                    llvm::ConstantInt::get(i8, LUX_SCRIPT_STEP_FAILED));
                storeOutcomeField(rejected_builder, outcome_argument, offsetof(lux_script_step_outcome, status), status);
                rejected_builder.CreateRetVoid();
                llvm::IRBuilder<> accepted_builder(accepted);
                accepted_builder.CreateStore(llvm::ConstantInt::get(i32, next_pc), frame_argument);
                storeOutcomeField(accepted_builder, outcome_argument, offsetof(lux_script_step_outcome, state),
                    llvm::ConstantInt::get(i8, LUX_SCRIPT_STEP_SUSPENDED));
                const auto token_offset = offsetof(lux_script_step_outcome, waiting_on);
                auto* token_value = accepted_builder.CreateLoad(i64, token);
                storeOutcomeField(accepted_builder, outcome_argument, token_offset, token_value);
                storeOutcomeField(accepted_builder, outcome_argument, offsetof(lux_script_step_outcome, status),
                    llvm::ConstantInt::get(i32, 0U));
                accepted_builder.CreateRetVoid();

'''+t[b:]
t=t.replace('                dispatch_switch->addCase(llvm::ConstantInt::get(i32, next_pc), resume_entry);','                dispatch_switch->addCase(llvm::ConstantInt::get(i32, next_pc), resume_entry);\n                resume_entries.push_back(resume_entry);')
# Hoist original stack allocation addresses before added resume entries. Data still follows CFG writes.
pos=t.index('            for (std::size_t repair{};');t=t[:pos]+'''            llvm::SmallVector<llvm::AllocaInst*, 16> local_allocations;
            for (auto& block : *core)
                for (auto& instruction : block)
                    if (auto* allocation = llvm::dyn_cast<llvm::AllocaInst>(&instruction))
                        if (allocation->getParent() != dispatch) local_allocations.push_back(allocation);
            for (auto* allocation : local_allocations)
                allocation->moveBefore(&*dispatch->getFirstInsertionPt());

'''+t[pos:]
# Allocate argument cells only if reachable use after a suspension.
pos=t.index('            std::vector<llvm::AllocaInst*> repair_allocations;'); t=t[:pos]+'''            for (std::size_t index{}; index < target->arg_size(); ++index)
            {
                if (!detail::ContinuationFrameLayout::argumentPersists(*core->getArg(index), resume_entries))
                    continue;
                auto* type = target->getFunctionType()->getParamType(index);
                const auto alignment = layout.getABITypeAlign(type).value();
                frame_size = alignFrameOffset(frame_size, alignment);
                argument_offsets[index] = frame_size;
                frame_size += layout.getTypeAllocSize(type);
                frame_alignment = (std::max)(frame_alignment, static_cast<std::uint64_t>(alignment));
            }
'''+t[pos:]
pos=t.index('            for (auto* allocation : repair_allocations)'); end=t.index('            frame_size = alignFrameOffset(frame_size, frame_alignment);',pos)
s=t[pos:end]; s=s.replace('''                const auto alignment = layout.getABITypeAlign(allocation->getAllocatedType()).value();''','''                if (allocation == token_storage) continue; // Known write-on-success bridge; never survives return.
                const bool persistent = detail::ContinuationFrameLayout::persists(*allocation, resume_entries);
                const bool needs_initial = detail::ContinuationFrameLayout::readsIncoming(*allocation, cloned_entry);
                if (!persistent)
                {
                    if (needs_initial)
                    {
                        llvm::IRBuilder<> local_builder(dispatch->getTerminator());
                        local_builder.CreateMemSet(allocation, llvm::ConstantInt::get(i8, 0U),
                            layout.getTypeAllocSize(allocation->getAllocatedType()) * count->getZExtValue(),
                            allocation->getAlign());
                    }
                    continue;
                }
                const auto alignment = layout.getABITypeAlign(allocation->getAllocatedType()).value();'''); s=s.replace('slots.push_back({nullptr, offset, size, alignment});','slots.push_back({offset, size, alignment, needs_initial});');t=t[:pos]+s+t[end:]
# Precise entry init and skipped arg stores/loads.
t=t.replace('''            for (std::size_t index{}; index < start_core_arguments.size(); ++index)
            {
                auto* address =''','''            for (const auto& slot : slots)
                if (slot.needs_initial_value)
                    start_builder.CreateMemSet(start_field(start_frame, slot.offset),
                        llvm::ConstantInt::get(i8, 0U), slot.size, llvm::MaybeAlign(slot.alignment));
            for (std::size_t index{}; index < start_core_arguments.size(); ++index)
            {
                if (argument_offsets[index] == UINT64_MAX) continue;
                auto* address =''')
t=t.replace('''            for (std::size_t index{}; index < target->arg_size(); ++index)
            {
                auto* address =
                    resume_wrapper''','''            for (std::size_t index{}; index < target->arg_size(); ++index)
            {
                if (argument_offsets[index] == UINT64_MAX)
                {
                    resume_core_arguments.push_back(llvm::PoisonValue::get(
                        target->getFunctionType()->getParamType(index)));
                    continue;
                }
                auto* address =
                    resume_wrapper''')
t=t.replace('LUX_SCRIPT_FRAME_ZEROED_BY_HOST','LUX_SCRIPT_FRAME_INITIALIZED_BY_ENTRY');t=t.replace('frame_hash = appendFrameHash(frame_hash, slot.alignment);','frame_hash = appendFrameHash(frame_hash, slot.alignment);\n                frame_hash = appendFrameHash(frame_hash, slot.needs_initial_value);')
p.write_text(t)
# Actual generated-frame tests now poison reused memory; each start must establish valid bytes.
p=r/'engine/toolchain/flowforge/test/script_artifact_compiler_test.cpp';t=p.read_text();import re
n=0
def poison(m):
 global n
 n+=1
 return m[0].replace(', 0,',', '+('0xA5' if n%2 else '0x5A')+',')
t=re.sub(r'std::memset\([^,]+, 0, [^;]+;',poison,t); t=t.replace('    const auto& event_wait_step = *event_wait_function->step;','    const auto& event_wait_step = *event_wait_function->step;\n    assert(event_wait_step.initialization == LUX_SCRIPT_FRAME_INITIALIZED_BY_ENTRY);');p.write_text(t)
print('poisoned starts',n)
