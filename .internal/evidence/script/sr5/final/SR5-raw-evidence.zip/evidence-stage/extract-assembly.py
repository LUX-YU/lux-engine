import json,hashlib
from pathlib import Path
r=Path('..').resolve(); out=[]
for phase in ['b8','final']:
 p=r/'diagnostics'/f'{phase}-disassembly.log'; lines=p.read_text().splitlines(); hits=[]
 for i,line in enumerate(lines):
  if 'call' in line and '__imp_?absolute@LuaValueAccess' in line:
   hits.append('\n'.join(lines[max(0,i-11):i+5]))
 (r/'diagnostics'/f'{phase}-absolute-sites.log').write_text('\n\n'.join(hits))
 out.append({'phase':phase,'disassembly_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'absolute_call_sites':len(hits),'note':'Static call-site count, not a dynamic execution count. Final remaining site has a positive-index branch bypass.'})
(r/'diagnostics/absolute-sites.json').write_text(json.dumps(out,indent=2));print(out)
