# V4-H1 实施结果

> 模板，未执行；所有占位由实际结果填写。没有证据使用 null/NOT_RUN，不预填 PASS。

## 身份

V4基线源码与镜像：
候选资格源码与镜像：
报告提交（不能重标为计时源码）：
实际工具链、VM、依赖、资产与配置：
A1隔离、工作区保护：

## 状态

implementation = COMPLETE / PARTIAL
contract = PASS / BLOCKED / INCOMPLETE
cost = IMPROVEMENT / MIXED / NO_CLEAR_GAIN / REGRESSION
recommendation =

## 实际变化

| 阶段 | 实际代码/提交 | 进入了哪条真实路径 | 未采用或受阻原因 |
|---|---|---|---|
| H0 | | | |
| H1 | | | |
| H2 | | | |
| H3 | | | |
| H4 | | | |
| H5 | | | |

## 检查审计

列出实际移出热路径的P、合并的D，以及保持的B/L/R。
引用CHECK_AUDIT.csv：每个删除谓词的证明位置、有效期、错误归属、机器码与回归。
不得仅报告if减少数量。说明哪些源码变化被优化器抵消、没有机器码差异。

## 当前V4与候选热点

数据源/ROI范围/目标线程/样本质量/PDB：
self与inclusive各自含义：
重点检查占比是否真的较高：
未使用PMU时明确不能归因cache miss/branch miss。

## 成本

| 原业务腿 | 单位和实际操作数 | 三对原值A/B | 每对变化 | 配对中位 | 分布/限制 |
|---|---|---|---|---|---|
| Lua Event | | | | | |
| Lua NextStep | | | | | |
| Lua scalar | | | | | |
| ValuePose record | | | | | |
| FlowForge Event | | | | | |
| C++ Sequence | | | | | |
| Physics mixed | | | | | |

原业务oracle、errors及最终backlog：
诊断不混入计时：

## 资源与布局

prepared / C / A / Ready / Event / Timer / storage Class实际sizeof和capacity：
总owned backing、冷期新增存储与metadata：
代码体积、栈上临时对象：
证明没有新的持久票据或隐藏目录：

## 验证

真实CTest数量/配置与结果：
对应被删除谓词的反例：
实际SDK、增量、迁址：
继承但本轮未重跑的范围：
既有MSVC深层public expected包装器限制：

## 失败与遗留

失败尝试原始记录：
未采用候选及原因：
V4 scalar/Native metadata等既有债务：
本轮没有解决或没有测到的其他热点：

## 结论

实现收益、合同范围与成本结论分别写。
不以“安全检查必然如此”豁免未解释成本；不以“checks reduced”宣称必然提速。
是否建议采用哪些独立提交；保持不合并V4/main的停点。
