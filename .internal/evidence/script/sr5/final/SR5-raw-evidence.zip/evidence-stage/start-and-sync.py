from pathlib import Path
import hashlib, json, shutil, subprocess
root = Path(__file__).parent
source = root / 'source'
repos = Path('E:/SyncForder/CodeRepos')
def git(path, *args): return subprocess.check_output(['git','-C',str(path),*args],text=True).strip()
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
manifest = root / 'start-identity.json'
if not manifest.exists():
    main = repos / 'lux-engine'
    status = git(main,'status','--porcelain=v1')
    paths = [line[3:] for line in subprocess.check_output(['git','-C',str(main),'status','--porcelain=v1'],text=True).splitlines()]
    data = {'entry':'764fc5d3da2e1e6b85270fd1ffe1cda2d4093971', 'main_head':git(main,'rev-parse','HEAD'),
            'main_status':status, 'main_files':[{'path':p,'sha256':sha(main/p)} for p in paths], 'dependencies':{}}
    for name in ['lux-cxx-v3r','lux-cmake-toolset-s6-relocation']:
        data['dependencies'][name] = {'head':git(repos/name,'rev-parse','HEAD'),'status':git(repos/name,'status','--short')}
    manifest.write_text(json.dumps(data,indent=2))
rows = []
headers = ['LuaValue.hpp','ScriptAbilityLua.hpp']
for prefix in ['Debug','RelWithDebInfo','Android/lux-engine']:
    for name in headers:
        relative = Path('lux/engine/function/script/lua') / name
        target = repos / 'install' / prefix / 'include' / relative
        backup = root / 'header-backup' / prefix / relative
        if target.exists() and not backup.exists():
            backup.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(target,backup)
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(source/'modules/function/script/lua/include'/relative,target)
        rows.append({'target':str(target),'sha256':sha(target),'previous':str(backup) if backup.exists() else None})
(root/'header-sync.json').write_text(json.dumps(rows,indent=2))
print('Identity fixed; two changed module public headers synchronized to the three required prefixes')
