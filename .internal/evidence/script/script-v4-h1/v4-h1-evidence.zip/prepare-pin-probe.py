from pathlib import Path
import re
r=Path(__file__).parent;source=r.parent/'script-cell-a1/source'
p=source/'engine/domain/simulation/builtin/script/test/script_system_event_wait_test.cpp'
s=p.read_text();anchor='    void testCopyRetirementPin()'
assert s.count(anchor)==1 and s.count('    testCopyRetirementPin();')==1
s=s.replace(anchor,(r/'pin-boundary-snippet.cpp').read_text()+anchor)
s=s.replace('    testCopyRetirementPin();','    testCopyRetirementPin();\n    testPinnedPhysicalAwaitableCapacity();')
(r/'pin-boundary-test.cpp').write_text(s)
s=(r/'compare-contracts.py').read_text().replace("out=r/'contract-comparison-final'", "out=r/'pin-boundary'")
s=re.sub(r'tests=\{.*?\}\ntraces=',lambda m:"tests={'simulation_script_event_wait_test': str(r/'pin-boundary-test.cpp')}\ntraces=",s,flags=re.S)
s=s.replace("('EVENT_PREFLIGHT,','EVENT_PREPARED_SHAPE,','STORAGE_RELEASE_BOUNDARIES,','NATIVE_RELEASED_PREPARED,')", "('PIN_PHYSICAL_BOUNDARY,',)")
s=s.replace("{'simulation_script_event_wait_test':5,'simulation_script_class_storage_test':2,'simulation_script_native_test':1}", "{'simulation_script_event_wait_test':1}")
s=s.replace('CONTRACT_A_B_PASS_8_TRACES','PIN_A_B_PASS_1_TRACE')
s=s.replace("f' /nologo /I{inc} '", "f' /nologo /I{inc} /I{source / \"engine/domain/simulation/builtin/script/test\"} '")
(r/'pin-boundary.py').write_text(s)
