$ErrorActionPreference='Stop'
& 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/s6/relocate.ps1'