from pathlib import Path
import csv,json,hashlib,subprocess,re,statistics,datetime
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1');s=r/'source';o=s/'.internal/script-native-lua-na1';o.mkdir(exist_ok=True)
sha='4a8812e9813fe90b241dba29e3e668e4a4239b26';a='f7d2815bdd2025ee23a7c11449def822413f58e9'
def put(name,obj): (o/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
# Reports preserve original per-run observations; no relabelling of binary identity.
runs=json.loads((r/'final-costs/runs.json').read_text());pairs=json.loads((r/'final-costs/summary.json').read_text());assert len(runs)==54 and all(x['valid'] and x['exit']==0 for x in runs)
resources=json.loads((r/'resources/runs.json').read_text());assert len(resources)==13
snaps=[]
for x in resources:
 for line in x['observation']:
  if not line.startswith(('MEMORY ','PROCESS_MEMORY ','NATIVE_MEMORY ')):continue
  values={k:(int(v) if v.isdigit() else v) for k,v in re.findall(r'(\w+)=([^ ]+)',line)}
  snaps.append(dict(run=x['name'],kind=line.split()[0],**values))
profiles=[]
for leg,folder in [('P1','profiles2'),('P3','profiles2'),('P5','profiles-pose')]:
 for side in ['A','B']:
  p=r/folder/f'{leg}-{side}'; rows=list(csv.DictReader((p/'top-down.csv').open(encoding='utf-8-sig')))
  selected=[]
  for x in rows:
   if any(t in x['Function Stack'] for t in ['invokeSyncStep','executeSyncStep','writePlan','writePlain','traversestrongtable','stack_init','lua_resume','luaH_Hgetshortstr']):
    selected.append(dict(stack=x['Function Stack'],inclusive_percent=float(x['CPU Time:Total'] or 0),self_cpu_seconds=float(x['CPU Time:Self'] or 0)))
  profiles.append(dict(leg=leg,side=side,path=str(p),samples=selected,nested_inclusive_values_must_not_be_summed=True))
put('PROFILE_ANALYSIS.json',profiles)
# Actual backing has separate accounting domains: process heap includes all owners, owner counters are subsets.
ledger=dict(source=sha,units='bytes',diagnostics_separate_from_timing=True,raw='evidence/logs.zip:resources/runs.json',snapshots=snaps,
 accounting_contract=['HeapWalk busy bytes is one measured whole-process heap total, not an owner sum or RSS.','VM live bytes, active/idle pages, class rounding and pinned free slots overlap; never add them as separate allocations.','composition/frame/metadata/prepared/association are subsets of process heap; fixed frame reserve is not compiler frame live size.','closed is after ScriptSystem shutdown, before backend/VM object destruction; reserved capacity and dead VM objects can remain without a leak.','Derived per-owner vector entries below are structural accounting, not fresh allocation observations. Missing map node/bucket bytes remain null.'],
 measured_owners=['ScriptInstances: mount/method/feedback counters','ScriptBindings: binding counter','ScriptExecution: awaitable storage and external ticket backing counters','Lua allocator: VM live/peak + actual page supply/idle/pinned/rounding + lower heap calls','NativeLuaTaskBackend: composition_backing_bytes includes plans/routes/step arrays/import remaps/instances/methods','CppStatic: frame arena/metadata/prepared methods/artifact associations','OS process: HeapWalk all heaps busy bytes; private commit and working/peak working set separate'],
 compiler_layout='current-class-layout2/sizes.json in archive',frames=json.loads((r/'machine-code2/frame-sizes.json').read_text()),
 derived_per_N=[
 {'owner':'ScriptExecution','storage':'ExecutionInstance','bytes_per_N':64,'N':'instance_capacity'},
 {'owner':'ScriptExecution','storage':'HookFlight','bytes_per_N':16,'N':'core_method_capacity = 4 * instance_capacity'},
 {'owner':'ScriptExecution','storage':'Continuation SlotMap value/slot/dense-to-slot','bytes_per_N':84,'N':'continuation_capacity'},
 {'owner':'ScriptExecution','storage':'ResumeRing notifications','bytes_per_N':24,'N':'resume_capacity'},
 {'owner':'ScriptEventWaits','storage':'waiter SlotMap value/slot/dense-to-slot','bytes_per_N':100,'N':'waiter_capacity'},
 {'owner':'ScriptEventWaits','storage':'claimed handles','bytes_per_N':8,'N':'waiter_capacity'},
 {'owner':'ScriptEventWaits','storage':'instance chains','bytes_per_N':16,'N':'instance_capacity'},
 {'owner':'ScriptTimers','storage':'Wait SlotMap value/slot/dense-to-slot','bytes_per_N':116,'N':'min(nextstep + delay capacities, awaitable_capacity)'},
 {'owner':'ScriptTimers','storage':'external completion SlotMap','bytes_per_N':100,'N':'same Timer capacity'},
 {'owner':'ScriptTimers','storage':'heap indices','bytes_per_N':8,'N':'same Timer capacity'},
 {'owner':'ScriptTimers','storage':'instance chains','bytes_per_N':16,'N':'instance_capacity'},
 {'owner':'ScriptCompletionIngress','storage':'transport ring Cell','bytes_per_N':80,'N':'external_capacity'},
 {'owner':'Lua','storage':'instances/free indices','bytes_per_N':184,'N':'instance_capacity'},
 {'owner':'Lua','storage':'prepared calls/free indices','bytes_per_N':32,'N':'prepared_call_capacity (A=4N, B=10N)'},
 {'owner':'Lua','storage':'continuations/free indices','bytes_per_N':72,'N':'A=N, B=0, KEEP=N'},
 {'owner':'CppStatic','storage':'instances/free indices','bytes_per_N':136,'N':'native instance_capacity'},
 {'owner':'CppStatic','storage':'continuations/free indices','bytes_per_N':184,'N':'native coroutine_capacity'}],
 remaining_attribution=[{'owner':x,'bytes':None,'reason':reason} for x,reason in [
 ('Lua native-side preparation','prepared_binding_bytes was not emitted in this resource fixture; bounded block storage is inside whole HeapWalk total'),
 ('Lua prototypes/function bindings/indices','variable hash nodes/buckets and per-function argument arrays were not separately observed'),
 ('Instances/Bindings/Event directories','dense_map bucket allocations not all separately exposed; measured public counters are not the complete owner'),
 ('CppStatic catalogs/object/index overhead','public four storage counters exclude some instance vectors/object slab/hash directory bookkeeping'),
 ('System/fixture/Registry/CRT','included in whole-process heap, not individually tagged')]],
 owner_grand_total_bytes=None,owner_attribution_status='PARTIAL_EXPLICIT_UNATTRIBUTED',
 keep_lua_reserve=dict(case='P1 N=10000',prepared_heap_A=63343906,prepared_heap_B=95702697,prepared_heap_B_KEEP=96514063,
 added_measured_heap_bytes=811366,derived_continuation_vectors_bytes=720000,additional_VM_live_bytes=90052,task_threads_created=0),
 conclusions=['B removes per-task Lua thread/stack/root churn for these routes, but increases cold fixed storage.','P1 N=10000 B prepared heap is 32,358,791 bytes above A; B lower peak working set does not prove universally lower memory.','16 MiB is idle-page retention budget, not whole VM or total runtime memory budget.'])
put('RESOURCE_LEDGER.json',ledger)
put('fixture_map.json',dict(production_A=a,production_B=sha,common_fixture_source=sha,original_A_bodies_preserved=True,
 common_source='engine/domain/simulation/scripting/native_lua_tasks/benchmark',common_build='cmake/benchmarks/native-lua-complete',
 physics='engine/domain/simulation/builtin/physics2d/benchmark/PhysicsLuaTask.hpp',
 raw_images='evidence/logs.zip:final-image-identities.json',assets='A/B common packaged assets have matching SHA; Physics both sides use identical extended Lua artifact with unchanged original async body',
 shape={'P1':'invoke -> Event31 -> stable -> apply31','P2':'invoke -> NextStep -> stable -> apply11','P3':'Lua before -> NextStep -> Event31 -> simulationSeconds .001 -> Lua late read/apply','P4':'one task/frame/thread per 32 Event waits on both sides','P5':'ValuePose snapshot typed copy -> Lua before -> Event31 -> Lua after','P6':'only target Lua async portion native-orchestrated; original C++/FlowForge participation and queries retained'},
 observed_script_task_units={'P1':20000000,'P2':20000000,'P3':2500000,'P4':640000,'P5':1000000},
 observed_wait_units={'P1':20000000,'P2':20000000,'P3':7500000,'P4':20480000,'P5':1000000},
 setup={'worker':0,'affinity_mask':16,'priority':'NORMAL','seed':1592598566,'seed_scope':'old scene drivers; deterministic common fixture uses fixed payload and no PRNG','resume_budget':'N unchanged','GC':'INC upstream parameters, normal execution','idle_page_budget_bytes':16777216},
 intervals={'P1_P5':'includes task create/complete/destroy and necessary stable drain','S2_P6':'original simulation frame intervals; final shutdown remains outside original timing, no complete-task interpretation'},
 unavailable=['per-wave errors and backlog','individual resume latency','formal run allocator counters'],
 assertions=['per-instance result','actual complete tasks/waits/resumes','provider business count','process errors and backlog when exposed','final leases and core resources','identical original business columns for old fixtures']))
# Stable source/test anchors. Evidence names are archive paths, not fictitious repository files.
core='engine/domain/simulation/builtin/script/test/'
main='engine/domain/simulation/scripting/native_lua_tasks/test/native_lua_tasks_test.cpp'
prod='engine/domain/simulation/scripting/native_lua_tasks/src/NativeLuaTaskBackend.cpp'
lua='engine/domain/simulation/scripting/lua/src/LuaScriptBackend.cpp'
cpp='engine/domain/simulation/scripting/cpp_static/src/CppStaticScriptBridge.cpp'
# id: assertions/evidence/specific limitation, retaining explicit narrow coverage gaps.
rows=[
('T01','PASS','A f7 binary hashes; f928 docs only; candidate branch from f928','v4-image-mirror.json;flow-image-mirror.json;qualification-identity.json',''),
('T02','EXTERNAL_CHANGE_PRESERVED','V4/H1 refs unchanged; main 7 status entries and 6 captured file hashes unchanged','protected-before.json;final-protected-dependencies.json;main-external-change.txt','main moved c77 to f89 by other Editor merge; do not report HEAD unchanged; .gitignore initial hash not captured'),
('T03','PASS','one LUA descriptor; duplicate backend-kind core test; duplicate plan/route/step cold reject','qualified-d-LastTest.log;supplemental-contract/run.log',''),
('T04','PASS_WITH_SCOPE','content/signature/host/contract checks before native construction; companion rejection and old CppStatic artifact tests','qualified-d-LastTest.log;n4-cold-cases.log','facade wrong-kind vs wrong-contract predicates inspected; not every conjunction independently injected'),
('T05','PASS','missing Event/Delay imports rejects before object; reorder maps owned by instance','qualified-d-LastTest.log;CASE cold-reject kind=3/4',''),
('T06','PASS','resumable export as step rejected, objects=0 leases=0','qualified-d-LastTest.log;CASE cold-reject kind=5',''),
('T07','PARTIAL_FAILURE_INJECTION','invalid host/content/import/step capacity/native child capacity rollback and lease zero','qualified-d-LastTest.log;CASE companion-reject kind=11/12','not every cold std::vector allocation site fault-injected'),
('T08','PASS','one core status identity, mixed native/Lua two continuations with one Begin/End','qualified-d-LastTest.log;CASE mixed-routes',''),
('T09','PASS','begins=ends=instance count; 33 churn lifecycle pairs; no duplicate create Begin','qualified-d-LastTest.log;CASE churn',''),
('T10','PASS','typed scalar31/void side effects, synchronous step zero new waits, stack restores','qualified-d-LastTest.log;CASE typed-boundary',''),
('T11','PASS_WITH_SCOPE','bool/NaN/Inf/fractional/i32 overflow result reject without publishing; typed signature rejects bad args','qualified-d-LastTest.log;CASE output-reject;script-lua-values','existing direction-specific policy retained: C++ float input push is not newly prohibited NaN/Inf'),
('T12','PASS','provider executes once then output invalid -> no task result; no claimed business rollback','qualified-d-LastTest.log;CASE output-reject/close-error',''),
('T13','PASS','64/1000 real Event31 each instance; 20M formal tasks business matched','qualified-d-LastTest.log;final-costs/P1-*.log',''),
('T14','PASS_WITH_SCOPE','enabled resource observer B thread/resume/release increments0 vs A nonzero','resources/runs.json;CASE event;CASE mixed-routes','task root/yield zero follows zero acquisition + no Step + sync rejection source mapping; no separate VM root/yield counter'),
('T15','PASS','generated actual C++ coroutine start/resume; compiler frame allocation immediates','machine-code2/frame-sizes.json;qualified-d-LastTest.log',''),
('T16','PASS','native frame owns phase values; only instance/self/prototype/prepared roots; no per-task Lua allocation increase in P1','resources/runs.json;PROFILE_ANALYSIS.json','not transparent Lua thread semantics'),
('T17','PASS','raw yield returns controlled error, no A/remaining native frame','qualified-d-LastTest.log;CASE step-error',''),
('T18','PASS','Event and Delay in no-Step sync context rejected before source admission','qualified-d-LastTest.log;CASE step-error',''),
('T19','PASS','Lua pcall catches illegal wait and returns31, no remaining A','qualified-d-LastTest.log;CASE ordinary-error-recovery',''),
('T20','PASS','fail before/after await -771/-772 preserved; unreachable0; frame1; no new ready','qualified-d-LastTest.log;CASE fail',''),
('T21','PASS','body/nested/close errors contained by pcall; frames destroyed and stack restored','qualified-d-LastTest.log;CASE step-error/close-error',''),
('T22','PARTIAL_FAILURE_INJECTION','body allocations allowed0/1/3 fail; protected return, provider0, frame1, stack restored','qualified-d-LastTest.log;CASE step-oom','actual inner checkstack present and VM contracts rerun; dedicated main-stack-growth OOM not isolated'),
('T23','PASS_WITH_SCOPE','record argument allocation fails before provider/wait; typed frame cleanup1','qualified-d-LastTest.log;CASE record-argument-oom','error-string/traceback allocations not individually distinguished from body OOM'),
('T24','PASS','close once/close error result unpublished; nested call preserves outer live TBC','qualified-d-LastTest.log;supplemental-contract/run.log',''),
('T25','PASS','Lua provider nested Lua depth2/base restore; ordinary error recovery and nested fault restriction','qualified-d-LastTest.log;CASE nested-lua/converter-qualification',''),
('T26','PASS','custom push faults original instance through real nested dispatch; later provider0','qualified-d-LastTest.log;CASE converter-qualification fault=1',''),
('T27','PASS','deferred stop retains region; legal providers2; no early End/destroy; lifecycle then shutdown','qualified-d-LastTest.log;CASE deferred-stop',''),
('T28','PASS','64 pending frames cancelled once; waiters and leases0; churn lateEvent no old task resume','qualified-d-LastTest.log;CASE pending-cancel/churn',''),
('T29','PASS','in-Lua requestStop observes live frame/leases and zero early cleanup; ends after region','qualified-d-LastTest.log;CASE deferred-stop',''),
('T30','PASS','old events after retirement cannot revive cancelled task; old publication/foreign identity reject','qualified-d-LastTest.log;CASE churn/checked-publication',''),
('T31','PASS','same self two tasks independently wait/complete, result163','qualified-d-LastTest.log;CASE typed-boundary mode=9',''),
('T32','PASS','full old epoch and foreign identity rejected before entry; invalidated in call result not published','qualified-d-LastTest.log;CASE checked-publication mode=0..3',''),
('T33','PASS','registration cutoff, nested dispatch, copy retirement pin and callback order existing tests','qualified-d-LastTest.log;script_system_event_wait_test',''),
('T34','PASS','A/Event dual-full source priority proved on A/B; existing ready queue fault tests','protocol-probes/A-run.log;protocol-probes/B-run.log;qualified-d-LastTest.log',''),
('T35','PASS_WITH_SCOPE','Timer local next/delay paths and existing capacity/queue retry tests; core source unchanged','qualified-d-LastTest.log;script_system_continuation_test','capacity priority source review plus existing tests; no new scheduler policy'),
('T36','PASS','frontier retained per pop, stale budget tests rerun','qualified-d-LastTest.log;script_ingress_frontier_test',''),
('T37','PASS','A=1 task32wait complete993; no premature retention','qualified-d-LastTest.log;CASE one-wait-slot',''),
('T38','PASS','C=1 two starts both before-wait side effects; one admitted, frames2 final','qualified-d-LastTest.log;CASE continuation-late',''),
('T39','PASS','write pin/copy growth/cancel physical storage tests retained','qualified-d-LastTest.log;testCopyRetirementPin/testCopyNestedAdmission',''),
('T40','PASS','NextStep->Event31->simulation delay real steps; original snapshot/late read oracles','qualified-d-LastTest.log;final-costs/P3-*.log',''),
('T41','PASS','one task32 waits both A/B; 640000 tasks20480000 waits; no each-event task unfairness','final-costs/P4-*.log;machine-code2/frame-sizes.json',''),
('T42','PASS','ValuePose snapshot43/after74 despite caller mutation; 1M real nested record tasks','qualified-d-LastTest.log;final-costs/P5-*.log',''),
('T43','PASS','16 volatile records exceed512 frame before body, no wait; limit unchanged','qualified-d-LastTest.log;CASE large-record-frame','size reject occurs before storage allocator counter; counter0 is not absence of failure'),
('T44','PASS','B Lua continuation0 supports lifecycle+sync; mixed route explicit reserve creates1 thread','qualified-d-LastTest.log;resources/runs.json',''),
('T45','PASS','32 retirement/rematerialization rounds fixed composition bytes; frame32 life33 lease0','qualified-d-LastTest.log;CASE churn',''),
('T46','PASS','resolver new content does not change old prepared task result32; next mount cold rejects plan mismatch','supplemental-contract/run.log;CASE supplemental-content','explicit immutable plan; no hot reload'),
('T47','PASS_WITH_SCOPE','existing TaskGraph owner serial tests and Scene workers; no new thread entry/scheduler','qualified-d-LastTest.log;NOTES.zh-CN.md','owner contract is precondition; production does not add cross-thread mutex/check; affinity probe not enabled'),
('T48','PASS','same Physics frame business columns; original CPP/Flow retained; only Lua orchestration changed','final-costs/P6-*.csv;final-costs/runs.json','cost regression reported, not invalidated'),
('T49','PASS','same original A functions; matching actual tasks/waits and per-instance payload','fixture_map.json;final-costs/runs.json;final-image-identities.json',''),
('T50','PASS','54 valid processes no removed slow pair; P1/P3 ROI A/B + P5; 4 initial observations invalid retained','final-costs/runs.json;profiles2;profiles-pose;profiles/runs.json','no PMU; sample times are not formal times'),
('T51','PARTIAL_ATTRIBUTION','13 resource observations including KEEP; complete HeapWalk process total + owner counters and compiler layouts','RESOURCE_LEDGER.json;resources/runs.json;current-class-layout2','some owner hash directories/bookkeeping not individually tagged; owner grand total null, not a fabricated exact sum'),
('T52','PASS','D127/T110/VM4; old15 consumers all rebuild/run;13 increments; real Flow generation','qualified-d-tests2.log;qualified-t-tests2.log;final-vm-tests.log;installed/consumers.json;value-incremental/probes.json',''),
('T53','PASS','new SDK public consumer generates Cpp+Lua, events/nextstep/result/fail/cancel/close','installed/consumers.json;new-incremental/results.json',''),
('T54','PENDING_REMOTE_READBACK','3 relocated public chains execute with original sources/build/prefix hidden; inputs restored','relocated/results.json;relocated/unavailablepaths.json;new-incremental/results.json','remote archive readback follows evidence commit/push')]
orig=list(csv.DictReader((r/'instructions/TEST_MATRIX.csv').open(encoding='utf-8-sig')));assert len(orig)==len(rows)==54
with (o/'CHECK_MAPPING.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['id','phase','case','status','source','assertions','evidence_in_archive','limitation']);w.writeheader()
 for base,item in zip(orig,rows):
  id,status,asserts,evidence,limit=item;assert id==base['id'];anchor=main if id not in ['T01','T02','T33','T34','T35','T36','T39','T48','T49','T50','T51','T52','T53','T54'] else core if id in ['T33','T34','T35','T36','T39'] else 'fixture_map.json'
  w.writerow(dict(id=id,phase=base['phase'],case=base['case'],status=status,source=anchor,assertions=asserts,evidence_in_archive=evidence,limitation=limit))
put('result.json',dict(schema='lux-script-native-lua-na1-result-1',implementation='IMPLEMENTED',contract='TESTED_WITH_EXPLICIT_COVERAGE_GAPS',cost='MIXED_NO_GENERAL_GAIN',adoption='NOT_APPROVED_PENDING_REVIEW',
 identities=dict(baseline_production=a,branch_base='f92853ea8361a7dc90ce0da072497d3722c29f88',common_fixture_source=sha,qualified_candidate_source=sha,report_commit_is_test_identity=False,branch='codex/s6-native-task-lua-steps',lux_cxx='3100f54d0743c5ed94a4ccf5943df04e933de255',toolset='99c3d0480d1db816779b1dfa7f3c06cb7d39a94f',Lua='5.5.1 lux-lua55-v3-r2',native_abi=6,config='RelWithDebInfo MSVC19.44 /O2 /Ob1 /MD /Zi',GC='INC upstream',idle_page_budget_bytes=16777216),
 qualification=dict(Developer={'passed':127,'total':127},Toolchain={'passed':110,'total':110},VM={'passed':4,'total':4},old_consumers={'passed':15,'total':15},new_consumer={'passed':1,'total':1},old_incrementals={'passed':13,'total':13},new_incrementals={'passed':4,'total':4},relocation={'passed':3,'total':3},source_style='PASS',clean_clone=True,all_and_second_noop=True),
 performance=dict(valid_processes=54,order='AB/BA/AB',pairs=pairs,runs=runs),
 resource_ledger='RESOURCE_LEDGER.json',profiles='PROFILE_ANALYSIS.json',requirements='CHECK_MAPPING.csv',fixture_map='fixture_map.json',
 limitations=['T07: cold allocation fault injection not exhaustive','T22: main-stack-growth OOM not isolated','T51: exact individual-owner heap attribution incomplete; whole heap and major counters measured','Main independently fast-forwarded; unknown file hashes/status preserved','No PMU, individual resume latency or formal-run allocation collection','Only Windows x64 MSVC Lua55; no Android/other VM/other platform','Per-batch error/backlog null; old fixture unexposed counters stay null','P4/P5 and Physics slow results retained; no automatic adoption'],
 evidence=dict(archive='evidence/logs.zip',manifest='evidence/manifest.json',download_verification='PENDING_PUSH',local_images=str(r/'images'),local_raw_vtune=[str(r/x) for x in ['profiles','profiles2','profiles-pose']])) )
print('Reports generated: 54 rows, 54 valid processes, 13 resource runs, 6 ROI exports')
