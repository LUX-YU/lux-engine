from pathlib import Path
import re
b=Path('E:/RenderV2Rebuild/Layer/source/modules/function/render')
p=b/'native/vulkan/include/lux/engine/render/native/vulkan/CompiledGraph.hpp';s=p.read_text().replace('#include <lux/engine/render/features/Feature.hpp>','#include <lux/engine/render/graph/Analysis.hpp>\n#include <lux/engine/render/resource/Binding.hpp>');s=s.replace('const DeviceSession&, const FeatureAssembly&, std::span<const PassProgram>, const TargetDesc&','const DeviceSession&, const RenderGraphDefinition&, const GraphAnalysis&,\n            std::span<const GraphStorageBinding>, std::span<const PassProgram>, const TargetDesc&').replace('        const FeatureAssembly& assembly,','        const RenderGraphDefinition& graph,\n        const GraphAnalysis& analysis,\n        std::span<const GraphStorageBinding> external_bindings,').replace('// INVARIANT: assembly is the exact successful G5 result; reuse its Analysis, never analyze again.','// INVARIANT: analysis belongs to this immutable definition; never analyze again here.');p.write_text(s)
p=b/'native/vulkan/src/Compile.cpp';s=p.read_text().replace('        const FeatureAssembly& assembly,','        const RenderGraphDefinition& graph,\n        const GraphAnalysis& analysis,\n        std::span<const GraphStorageBinding> external_bindings,').replace('        const auto& graph = assembly.definition;\n','').replace('assembly.external_bindings','external_bindings').replace('assembly.analysis','analysis').replace('kFeatureContract','kInvalidArgument').replace('exact G5 analysis','exact Graph analysis');
a=s.index('        for (std::size_t i = 0; i < programs.size(); ++i)');z=s.index('        std::vector<Access> previous',a)
s=s[:a]+'''        // Resolve author keys once at the cold compiler boundary, then index by GraphPassId.
        std::vector<const PassProgram*> pass_programs(graph.passes().size(), nullptr);
        for (const auto& program : programs)
        {
            const auto found = std::ranges::find(graph.passes(), program.pass_key, &GraphPass::key);
            if (found == graph.passes().end()) return cxx::unexpected(RenderError{kInvalidArgument});
            const auto index = static_cast<std::size_t>(found - graph.passes().begin());
            if (pass_programs[index]) return cxx::unexpected(RenderError{kInvalidArgument});
            pass_programs[index] = &program;
        }
'''+s[z:]
a=s.index('            const auto binding = std::find_if(programs.begin()');z=s.index('            const bool is_unsupported_pass',a)
s=s[:a]+'''            const auto* binding = pass_programs[id.index];
            if (!binding) return cxx::unexpected(RenderError{kInvalidArgument, {id.index}});
'''+s[z:];p.write_text(s)
for p in b.rglob('*'):
 if p.suffix not in ('.cpp','.hpp'):continue
 s=p.read_text();t=re.sub(r'\bResourcePlan\b','NativeResourcePlan',s)
 if 'compileGraph(' in t and p.name not in ('Compile.cpp','CompiledGraph.hpp'):
  t=re.sub(r'compileGraph\(([^,\n]+),\s*(\*?\w+),',lambda m:'compileGraph('+m[1]+', ('+m[2]+').definition, ('+m[2]+').analysis, ('+m[2]+').external_bindings,',t)
 if t!=s:p.write_text(t)
p=b/'graph/test/installed/CMakeLists.txt';s=p.read_text().replace('foreach(forbidden render_data render_protocol','foreach(forbidden render_protocol');p.write_text(s)
# Generic image source borrow, same existing Transfer and same accepted-submit LastUse merge.
p=b/'native/vulkan/include/lux/engine/render/native/vulkan/DeviceSession.hpp';s=p.read_text().replace('const ImageAllocation* clone = nullptr, bool graphics_queue = false) noexcept;','const ImageAllocation* clone = nullptr, bool graphics_queue = false,\n            SubmissionRequirements* clone_last_use = nullptr) noexcept;');p.write_text(s)
p=b/'native/vulkan/src/transfer/Transfer.cpp';s=p.read_text().replace('#include <lux/engine/render/native/vulkan/texture/TextureStorage.hpp>\n','').replace('std::span<const ImageTransferRegion> regions, const ImageAllocation* clone, bool graphics_queue','std::span<const ImageTransferRegion> regions, const ImageAllocation* clone, bool graphics_queue,\n        SubmissionRequirements* clone_last_use').replace('|| (clone && !graphics_queue);','|| (clone && !graphics_queue) ||\n            ((clone == nullptr) != (clone_last_use == nullptr));').replace('        result->clone_ = clone;','        result->clone_ = clone;\n        result->clone_last_use_ = clone_last_use;');p.write_text(s)
p=b/'native/vulkan/include/lux/engine/render/native/vulkan/transfer/Transfer.hpp';s=p.read_text().replace('        friend class TextureStorage;\n','');p.write_text(s)
p=b/'native/vulkan/src/DeviceSession.cpp';s=p.read_text().replace('#include <lux/engine/render/native/vulkan/texture/TextureStorage.hpp>\n','');p.write_text(s)
p=b/'native/vulkan/include/lux/engine/render/native/vulkan/texture/TextureStorage.hpp';s=p.read_text().replace('std::span<const std::byte>, std::optional<TextureRegion> = {}) noexcept;','std::span<const std::byte>, std::optional<TextureRegion> = {}, Backing* base = nullptr) noexcept;');p.write_text(s)
p=b/'native/vulkan/src/texture/TextureStorage.cpp';s=p.read_text().replace('const rdesc::TextureInfo& info, std::span<const std::byte> source, std::optional<TextureRegion> region','const rdesc::TextureInfo& info, std::span<const std::byte> source, std::optional<TextureRegion> region, Backing* base').replace('return session.uploadImage(description, source, regions, nullptr, region.has_value());','return session.uploadImage(description, source, regions, base ? base->image_ : nullptr,\n            region.has_value(), base ? &base->last_use_ : nullptr);').replace('prepareImage(info, input.source.bytes().view(), input.region)','prepareImage(info, input.source.bytes().view(), input.region, record->current)').replace('        (*transfer)->clone_ = record->current->image_;\n        (*transfer)->clone_last_use_ = &record->current->last_use_;\n','');p.write_text(s)
