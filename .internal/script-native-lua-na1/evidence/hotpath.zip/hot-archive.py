from pathlib import Path
import hashlib,json,subprocess,zipfile
r=Path(__file__).parent;s=r/'source';d=s/'.internal/script-native-lua-na1';e=d/'evidence'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
source=git(r/'opt-source','rev-parse','HEAD');assert source=='21d106014e05cf0a7746d45fd05eac8ae01575f2'
assert git(r/'opt-source','status','--porcelain')==''
original=json.loads((r/'hot-fixed-identities.json').read_text());protected=[]
for x in original['protected']:
 repo=Path(x['repo']);current=dict(repo=str(repo),head=git(repo,'rev-parse','HEAD'),status=git(repo,'status','--porcelain'),files=[])
 assert current['head']==x['head'] and current['status']==x['status'],('External/protected state changed',repo)
 for f in x['files']:
  h=sha(repo/f['path']);assert h==f['sha256'],(repo,f['path'])
  current['files'].append(dict(path=f['path'],sha256=h))
 protected.append(current)
for x in original['dependency_files']:assert sha(Path(x['path']))==x['sha256']
(r/'hot-protected-final.json').write_text(json.dumps(dict(protected=protected,dependency_files_unchanged=len(original['dependency_files']),qualification_source=source),indent=2))
identities=[]
for folder in ['B','B-common','B-flow','C','C-common','C-flow']:
 root=r/'images'/folder;data=json.loads((root/'identity.json').read_text())
 for name,info in data['images'].items():assert sha(root/name)==info['sha256'],(folder,name)
 for p in sorted(root.iterdir()):
  if p.is_file():identities.append(dict(path=str(p),relative=p.relative_to(r).as_posix(),size=p.stat().st_size,sha256=sha(p)))
(r/'hot-final-image-identities.json').write_text(json.dumps(identities,indent=2))
source_info=dict(qualification_source=source,qualification_clean=True,branch=git(s,'branch','--show-current'),production_baseline='4a8812e9813fe90b241dba29e3e668e4a4239b26',commits=git(s,'log','--format=%H %s','96eef624..HEAD').splitlines(),changed=git(s,'diff','--name-only','96eef624','HEAD').splitlines())
(r/'hot-source-identity.json').write_text(json.dumps(source_info,indent=2))
failures=[]
for p in r.iterdir():
 if p.suffix=='.json' and p.name.startswith(('hot','opt1','opt2','opt3','opt4')):
  try:x=json.loads(p.read_text(encoding='utf-8-sig'))
  except (ValueError,UnicodeError):continue
  if isinstance(x,dict) and isinstance(x.get('exit'),int) and x['exit']!=0:failures.append(dict(record=p.name,exit=x['exit']))
(r/'hot-failures.json').write_text(json.dumps(dict(records=failures,formal_timing_invalid=0,formal_timing_discarded=0,notes=['Template lua_pushcfunction comma macro compile failure fixed','Old source cache rejected: fresh configure used','Intermediate second build ran TableGen; final both second builds no work','Duplicate log label stopped rather than overwrote history','Original incremental list omitted new shape case; independently executed hot-shape-incremental','Repeated DevShell bootstrap line-too-long warnings retained; actual compiler/tests exit statuses recorded']),indent=2))
files=set()
for p in r.iterdir():
 if p.is_file() and p.name.startswith(('hot','opt1','opt2','opt3','opt4')) and p.suffix.lower() in {'.json','.jsonl','.log','.txt','.csv','.py','.ps1'}:files.add(p)
for folder in ['hot-costs','hot-resources','hot-profiles','hot-machine-code','hot-class-layout','hot-analysis','hot-installed','hot-value-incremental','hot-new-incremental','hot-shape-incremental','hot-relocated']:
 for p in (r/folder).rglob('*'):
  if not p.is_file() or '.git' in p.parts:continue
  parts=p.relative_to(r/folder).parts
  if folder=='hot-profiles':files.add(p);continue
  if folder in ['hot-installed','hot-relocated'] and any(x in parts for x in ['sdk','tools','vm','source','build','CMakeFiles']):continue
  if p.suffix.lower() in {'.json','.jsonl','.log','.txt','.csv','.asm','.hpp','.lua','.cpp','.cmake','.template'}:files.add(p)
for image in ['B','B-common','B-flow','C','C-common','C-flow']:
 files.update((r/'images'/image).glob('*.json'))
files.add(r/'profile-target.py')
assert all(p.suffix.lower() not in {'.exe','.dll','.pdb','.obj','.lib','.a'} for p in files)
manifest=[];archive=e/'hotpath.zip';assert not archive.exists(),'Do not overwrite finalized archive'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):
  data=p.read_bytes();path=p.relative_to(r).as_posix();z.writestr(path,data)
  manifest.append(dict(path=path,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
info=dict(archive='hotpath.zip',sha256=sha(archive),bytes=archive.stat().st_size,entries=len(manifest),uncompressed_bytes=sum(x['bytes'] for x in manifest),qualification_source=source,production_baseline=source_info['production_baseline'],compiled_binaries_in_archive=False,vtune_raw_included=True,manifest=manifest)
(e/'hotpath.json').write_text(json.dumps(info,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(manifest)
 for m in manifest:assert hashlib.sha256(z.read(m['path'])).hexdigest()==m['sha256']
print(json.dumps({k:v for k,v in info.items() if k!='manifest'},indent=2))
