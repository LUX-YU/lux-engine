from pathlib import Path
import json, statistics, sys
base=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo')
validation=base/'sr3-validation-final'
result={}
for variant,folder in [('reference','sr3-reference'),('candidate','sr3-final')]:
    data=json.loads((base/folder/'qualification.json').read_text(encoding='utf-8-sig'))
    data=[row for row in data if row['source_sha']==('8145598c18421d03da1dac21251200af3290e27d' if variant=='reference' else '3e2bcbd29580d2e744744b64149b7d8fedcc8950')]
    assert len(data)==2
    for row in data:
        assert row['install_exit']==0 and row['second_build_noop']
        assert row['ctest_exit']==(0 if row['profile']=='toolchain' else 8)
    result[variant+'_qualification']=data
    failed=base/folder/'d/Testing/Temporary/LastTestsFailed.log'
    result[variant+'_failed_tests']=[line.split(':',1)[1] for line in failed.read_text().splitlines() if line]
assert len(result['reference_failed_tests'])==6
assert result['reference_failed_tests']==result['candidate_failed_tests']
consumers=json.loads((validation/'consumers/consumers.json').read_text(encoding='utf-8-sig'))
assert len(consumers)==14 and all(row['status']=='PASS' for row in consumers)
result['installed_consumers']=consumers
trace=json.loads((validation/'probes/manifest.json').read_text())
assert trace['trace_equal'] and trace['event_trace_equal'] and trace['wire_equal']
assert len(trace['lifecycle_coverage'][0])==6 and len(trace['event_coverage'][0])==8
result['traces']=trace
rows=json.loads((validation/'measurements/runs.json').read_text())
assert len(rows)==72 and all(row['valid'] for row in rows)
comparisons=json.loads((validation/'measurements/business-comparisons.json').read_text())
assert len(comparisons)==36 and all(row['business_equal'] for row in comparisons)
result['runtime_performance']=[]
for case in sorted({row['case'] for row in rows}):
    group=[row for row in rows if row['case']==case and row['mode']=='performance']
    report={'case':case}
    for measure in ('total_ns','median_ns'):
        ratios=[]
        for pair in range(5):
            b=next(row for row in group if row['pair']==pair and row['variant']=='baseline')[measure]
            c=next(row for row in group if row['pair']==pair and row['variant']=='candidate')[measure]
            ratios.append(100*(c/b-1))
        report[measure]={'paired_percent':ratios,'median_percent':statistics.median(ratios)}
    report['diagnostics']=[row for row in rows if row['case']==case and row['mode']=='diagnostic']
    result['runtime_performance'].append(report)
scale=json.loads((validation/'scale/runs.json').read_text())
assert len(scale)==24
result['scale']=[]
for size in (8,8192):
    report={'configs':size}
    for variant in ('baseline','candidate'):
        group=[row for row in scale if row['configs']==size and row['variant']==variant]
        assert len(group)==6
        assert all(row['creates']==size+144 and row['destroys']==size+144 and row['ticks']==size and row['errors']==0 and row['backlog']==0 for row in group)
        report[variant]={'samples_ns':[row['elapsed_ns'] for row in group if not row['diagnostics']], 'diagnostic':next(row for row in group if row['diagnostics'])}
        report[variant]['median_ns']=statistics.median(report[variant]['samples_ns'])
        if variant=='candidate':
            assert all(row['slot_visits']==128 and row['endpoint_count_visits']==0 for row in group)
    result['scale'].append(report)
result['flow_allocations']=json.loads((validation/'flow-allocations/manifest.json').read_text())
Path(sys.argv[1]).write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({'performance':[{ 'case':row['case'], 'total_percent':row['total_ns']['median_percent'], 'frame_median_percent':row['median_ns']['median_percent']} for row in result['runtime_performance']], 'scale':result['scale']},indent=2))
