"""Run a reduced algorithm model; this does not compile or validate the Lux engine."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

root = Path(__file__).resolve().parent
source = root / 'id_high_water_probe.cpp'
records = []
for name in ('clang++', 'g++'):
    compiler = shutil.which(name)
    if not compiler:
        records.append({'compiler': name, 'status': 'UNAVAILABLE'})
        continue
    version = subprocess.run([compiler, '--version'], text=True, capture_output=True, check=True).stdout.splitlines()[0]
    for opt in ('-O0', '-O2'):
        tag = ('clang' if name == 'clang++' else 'gcc') + '_' + opt[1:]
        binary = root / ('probe_' + tag)
        argv = [compiler, '-std=c++20', opt, '-Wall', '-Wextra', '-pedantic', str(source), '-o', str(binary)]
        built = subprocess.run(argv, text=True, capture_output=True, timeout=30)
        row = {'compiler': version, 'argv': argv, 'build_exit_code': built.returncode,
               'build_stderr': built.stderr}
        if built.returncode == 0:
            ran = subprocess.run([str(binary)], text=True, capture_output=True, timeout=5)
            (root / (tag + '.log')).write_text(ran.stdout + ran.stderr, encoding='utf-8')
            row.update(run_exit_code=ran.returncode, observations=json.loads(ran.stdout), log=tag + '.log')
            binary.unlink()
        records.append(row)
result = {'scope': 'independent reduced C++20 algorithm model, NOT Lux compilation or CTest',
          'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'runs': records}
(root / 'results.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
assert len(records) == 4 and all(r.get('run_exit_code') == 0 for r in records)
print(json.dumps(result, ensure_ascii=False, indent=2))
