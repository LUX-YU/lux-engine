from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).parent;out=r/'configuration';out.mkdir(exist_ok=True)
dep=r.parent/'script-lua55-s0-s1-20260909/dependencies'
for name,build in [('developer',r.parent/'o/w/d'),('toolchain',r.parent/'o/w/t'),('vm',dep/'build-lua55')]:
 for filename in ['CMakeCache.txt','compile_commands.json']:
  shutil.copy2(build/filename,out/(name+'-'+filename))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
data=[]
for filename in ['ldo.c','lstate.c','lstate.h','lvm.c']:
 original=dep/'qualified-lua-5.5.1/src'/filename
 patched=dep/'build-lua55/lux-lua55-v3-r2/src'/filename
 assert original.is_file() and patched.is_file()
 data.append(dict(file=filename,original=str(original),original_sha256=digest(original),patched=str(patched),patched_sha256=digest(patched)))
(r/'vm-patched-inputs.json').write_text(json.dumps(data,indent=2))
print('BUILD_INPUTS_RECORDED',len(data))
