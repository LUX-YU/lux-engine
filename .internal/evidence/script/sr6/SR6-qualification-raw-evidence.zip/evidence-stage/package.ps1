$ErrorActionPreference = 'Stop'
$taskRoot = $PSScriptRoot
$taskSource = Join-Path (Split-Path $taskRoot) 's5/source'
$python = 'C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
$arguments = @('-B', "$taskSource/cmake/CollectScriptSR3Evidence.py")
foreach ($name in @('evidence-stage', 'q', 'consumers-final', 'incremental-final', 'relocation',
    'memory-consumer', 'memory-consumer-2', 'protocol-development', 'protocol-E', 'protocol-F',
    'regions', 'probes', 'scale', 'record-costs', 'extra-costs', 'performance', 'audit', 'summary',
    'consumer-development', 'consumer-development-2')) {
    $path = Join-Path $taskRoot $name
    if (Test-Path -LiteralPath $path) { $arguments += @('--root', $path) }
}
foreach ($path in @("$taskRoot/candidate-source", "$(Split-Path $taskRoot)/s5c/candidate-source",
    'E:/SyncForder/CodeRepos/lux-cxx-v3r', 'E:/SyncForder/CodeRepos/lux-cmake-toolset-s6-relocation')) {
    $arguments += @('--source', $path)
}
foreach ($path in @('E:/SyncForder/CodeRepos/install/s6/q/t', 'E:/SyncForder/CodeRepos/install/s6/q/d',
    'E:/SyncForder/CodeRepos/install/s6/q/l', 'E:/SyncForder/CodeRepos/install/q2/c',
    'E:/SyncForder/CodeRepos/install/q2/toolset', "$taskRoot/relocation/sdk/d")) {
    $arguments += @('--prefix', $path)
}
$arguments += @('--consumers', "$taskRoot/consumers-final", '--output',
    "$taskSource/.internal/evidence/script/sr6", '--archive-name', 'SR6-qualification-raw-evidence.zip')
& $python @arguments *> "$taskRoot/package.log"
if ($LASTEXITCODE -ne 0) { throw "Evidence collection failed: $LASTEXITCODE" }
Get-Content "$taskRoot/package.log"
