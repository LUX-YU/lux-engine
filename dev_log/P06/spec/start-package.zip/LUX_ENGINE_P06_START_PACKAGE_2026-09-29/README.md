# P06 启动包

先读 `START.md`，再读 `reference/v4/phases/P06_scene_runtime.md`。

`START.md` 是本次 P05 R2 复审与 P06 交接；其后续设计内容是实施要求，不是已完成报告。
原 V4 整体作为不可变历史参考保留，内部链接仍使用原相对结构；不得将种子账本、旧目录或检查脚本覆盖当前仓库。当前账本与已验收代码优先。

仅授权 P06。前置验收 HEAD：fae890a2a848ee68a16ff976e8047ea1b2a3a560。

`review/probes/` 是本次十二次独立核心源码隔离运行，非完整引擎/SDK/runtime 验收。详见其中 README。
`PACKAGE_MANIFEST.json` 记录包内条目的 SHA256；不代表已核对全部远端仓库证据。
