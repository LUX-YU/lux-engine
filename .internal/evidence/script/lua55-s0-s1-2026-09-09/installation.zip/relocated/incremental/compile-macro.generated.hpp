#pragma once
// Generated typed value operations. No offsets or runtime reflection interpretation.
#include <lux/engine/function/script/lua/LuaValue.hpp>
#include <Values.hpp>
#include "E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-lua55-s0-s1-20260909/relocated/script-lua-values/source/Rules.hpp"

namespace lux::script::lua
{


template <> struct LuaGeneratedValue<::Item> : LuaRecordValue<::Item,
    LuaValueField<&::Item::id, "key">,
    LuaValueField<&::Item::weight, "weight">>
{
};
static_assert(LuaValueCodec<::Item>::bounded, "Lua value expanded frame exceeds 64 KiB or depth 32");
}
