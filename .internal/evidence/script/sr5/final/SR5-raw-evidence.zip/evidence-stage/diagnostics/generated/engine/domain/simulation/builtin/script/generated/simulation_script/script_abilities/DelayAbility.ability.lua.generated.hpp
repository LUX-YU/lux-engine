#pragma once
// Generated typed Lua projection. Include the matching .ability.generated.hpp first.
#include <lux/engine/simulation/scripting/lua/LuaScriptAbilityProjection.hpp>

#include <array>
#include <type_traits>
#include <utility>

namespace lux::script::lua
{

    template <>
    struct ScriptAbilityLuaTraits<::lux::simulation::script::DelayAbility> final
    {
        using AbilityTraits = ScriptAbilityTraits<::lux::simulation::script::DelayAbility>;
        using Policy = typename ScriptAbilityLuaPolicy<::lux::simulation::script::DelayAbility>::Type;

        using Values_nextStep = LuaAbilityValueSignature<Policy, void>;
        [[nodiscard]] static int nextStep(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::startLuaValueAbility<Policy, void>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, ScriptAbilityCompletion<void> completion) noexcept
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.nextStep(access.context, std::move(completion));
                }
            );
        }

        using Values_seconds = LuaAbilityValueSignature<Policy, void, double>;
        [[nodiscard]] static int seconds(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::startLuaValueAbility<Policy, void, double>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, double duration, ScriptAbilityCompletion<void> completion) noexcept
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.seconds(access.context, duration, std::move(completion));
                }
            );
        }

        using Values_simulationSeconds = LuaAbilityValueSignature<Policy, void, double>;
        [[nodiscard]] static int simulationSeconds(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::startLuaValueAbility<Policy, void, double>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, double duration, ScriptAbilityCompletion<void> completion) noexcept
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.simulationSeconds(access.context, duration, std::move(completion));
                }
            );
        }

        using Values_realSeconds = LuaAbilityValueSignature<Policy, void, double>;
        [[nodiscard]] static int realSeconds(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::startLuaValueAbility<Policy, void, double>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, double duration, ScriptAbilityCompletion<void> completion) noexcept
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.realSeconds(access.context, duration, std::move(completion));
                }
            );
        }

        inline static constexpr std::array<ScriptAbilityLuaMethodProjection, AbilityTraits::Methods.size()> Methods{
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.simulation.delay.next_step"},
                &nextStep, Values_nextStep::Parameters, Values_nextStep::Results
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.simulation.delay.seconds"},
                &seconds, Values_seconds::Parameters, Values_seconds::Results
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.simulation.delay.simulation_seconds"},
                &simulationSeconds, Values_simulationSeconds::Parameters, Values_simulationSeconds::Results
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.simulation.delay.real_seconds"},
                &realSeconds, Values_realSeconds::Parameters, Values_realSeconds::Results
            }
        };
    };
} // namespace lux::script::lua
