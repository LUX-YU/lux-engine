from pathlib import Path
r=Path(__file__).parent
for name in ['installed.ps1','new-incremental.py','new-incremental.ps1','relocated.ps1',
             'benchmark.ps1','save-images.py','class-layout.py','class-layout.ps1','machine.py','post-qualify.ps1']:
 t=(r/('local-'+name)).read_text(encoding='utf-8-sig')
 # Preserve the qualification clone and controlled engine/benchmark build slots; separate outputs and SDKs.
 t=t.replace('local-','cleanup-').replace('cleanup-source','local-source')
 if name=='save-images.py':
  t=t.replace("save('E'", "save('F'").replace("save('E-flow'", "save('F-flow'").replace("save('E-common'", "save('F-common'")
  t=t.replace("['D-common','D','D-flow','E-common','E','E-flow']", "['E-common','E','E-flow','F-common','F','F-flow']")
 if name=='machine.py':
  t=t.replace("['E']", "['F']")
  t=t.replace("'ScriptSystem.cpp.obj']", "'ScriptSystem.cpp.obj','ScriptTimers.cpp.obj','NativeScriptBackend.cpp.obj']")
 if name=='post-qualify.ps1':
  # The optional old stop marker is neither used nor removed by this run.
  t=t.replace('Write-Output \'LOCAL_QUALIFICATION_AND_IMAGES_DONE\'', 'Write-Output \'CLEANUP_QUALIFICATION_AND_IMAGES_DONE\'')
 (r/('cleanup-'+name)).write_text(t)
t=(r/'local-costs.py').read_text()
t=t.replace("out=r/'local-costs'", "out=r/'cleanup-costs'")
t=t.replace("image_side='D' if side=='A' else 'E'", "image_side='E' if side=='A' else 'F'")
t=t.replace('7f20191692d3f5e1037a14273a61fc99eef95714','841320a36e864145eda43fd6b775a10a696d8e7f')
(r/'cleanup-costs.py').write_text(t)
print('Prepared existing qualification drivers with isolated output and F images')
