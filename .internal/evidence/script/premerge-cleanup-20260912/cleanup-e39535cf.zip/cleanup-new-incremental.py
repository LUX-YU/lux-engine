from pathlib import Path
import hashlib,json,os,re,subprocess
r=Path(__file__).parent;c=r/'cleanup-installed/native-task-lua-steps';s=c/'source';b=c/'build';out=r/'cleanup-new-incremental';out.mkdir(exist_ok=False)
prefixes=re.search(r'^CMAKE_PREFIX_PATH:[^=]*=(.*)$',(b/'CMakeCache.txt').read_text(),re.M)[1].strip().split(';')
os.environ['PATH']=';'.join([*[p+'/bin' for p in prefixes],'D:/Development/vcpkg/installed/x64-windows/bin',os.environ['PATH']])
original={p:p.read_bytes() for p in [s/'steps.lua',s/'ConsumerBehavior.hpp',s/'main.cpp']};results=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,command):
 with (out/(name+'.log')).open('wb') as f:code=subprocess.call(command,stdout=f,stderr=subprocess.STDOUT)
 return code,(out/(name+'.log')).read_text(errors='replace')
def build(name):return run(name,['cmake','--build',str(b),'--target','all','-j','4','--','-k','0'])
def execute(name):return run(name,[str(b/'lux_native_task_lua_steps_consumer.exe')])
def restore():
 for p,data in original.items():p.write_bytes(data)
def expected_contract():
 # This supplemental installed client keeps the declared step contract independent of changed artifact metadata.
 return change(s/'main.cpp','const std::array steps{*lua.findExport(scenario == 1U ? 79U : 78U)};',
 'const std::array steps{lux::rdesc::ScriptFunction{scenario == 1U ? "bad" : "apply", scenario == 1U ? 79U : 78U, {lux::rdesc::makeScriptValueType<std::int32_t>()}, {lux::rdesc::makeScriptValueType<std::int32_t>()}}};')
def change(path,old,new):
 text=path.read_text();assert text.count(old)==1,(path,old,text.count(old));path.write_text(text.replace(old,new));return 1
try:
 code,text=build('initial-noop');assert code==0 and 'no work to do' in text
 expected_contract();code,text=build('declared-contract-build');assert code==0
 code,text=execute('declared-contract-run');assert code==0
 for case in ['step-signature','task-contract','composition-route','deleted-step','native-step-shape']:
  before=sha(b/'steps.lxsa');hits=0
  if case=='step-signature':hits=change(s/'steps.lua','---@param value lux.i32\n---@return lux.i32\nfunction Steps:apply(value)','---@param value lux.f64\n---@return lux.i32\nfunction Steps:apply(value)')
  elif case=='task-contract':hits=change(s/'ConsumerBehavior.hpp','script_export = "consumer.run"','script_export = "consumer.run.changed"')
  elif case=='native-step-shape':hits=change(s/'ConsumerBehavior.hpp','scriptSyncStepShape<std::int32_t(std::int32_t)>()','scriptSyncStepShape<double(double)>()')
  elif case=='composition-route':hits=change(s/'main.cpp','NativeLuaTaskRoute{75U, 75U}','NativeLuaTaskRoute{75U, 76U}')
  else:
   text=(s/'steps.lua').read_text();start=text.index('---@lux.method\n---@param value lux.i32\n---@return lux.i32\nfunction Steps:apply(value)');end=text.index('---@lux.method',start+1)
   hits=change(s/'steps.lua',text[start:end],'')
  code,text=build(case+'-build');exe_code=None
  if code==0:
   exe_code,runtext=execute(case+'-negative');assert exe_code!=0,('invalid accepted',case)
  else:
   assert any(x in text.lower() for x in ['symbol','export','contract','ledger','function']),('wrong failure',case,text[-500:])
  after=sha(b/'steps.lxsa')
  results.append(dict(case=case,replacement_hits=hits,build_exit=code,execution_exit=exe_code,before_asset=before,after_asset=after,negative_rejected=True))
  restore();expected_contract();code,text=build(case+'-restore-build');assert code==0,(case,text[-500:])
  code,text=execute(case+'-restore-run');assert code==0 and len(re.findall(r'INSTALLED_NATIVE_LUA scenario=',text))==3
  code,text=build(case+'-restore-noop');assert code==0 and 'no work to do' in text
  results[-1].update(restored_execution=True,restored_noop=True)
  (out/'results.json').write_text(json.dumps(results,indent=2));print(case,'PASS',flush=True)
finally:
 restore()
 code,text=build('original-source-restore-build');assert code==0
 code,text=execute('original-source-restore-run');assert code==0
 code,text=build('original-source-restore-noop');assert code==0 and 'no work to do' in text

