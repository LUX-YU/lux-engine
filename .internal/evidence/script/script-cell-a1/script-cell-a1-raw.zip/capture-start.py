import hashlib, json, pathlib, subprocess, datetime
root = pathlib.Path(__file__).parent
v4 = root.parent / 'script-v4'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def git(path, *args): return subprocess.check_output(['git', '-C', str(path), *args], text=True).strip()
out = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'candidate_source': str(root/'source'),
       'candidate_head': git(root/'source', 'rev-parse', 'HEAD'), 'candidate_status': git(root/'source','status','--porcelain'),
       'candidate_branch': git(root/'source','branch','--show-current'), 'images':{}, 'protected':{}}
for name in ['final-image','final-flow-image']:
    directory=v4/name
    identity=json.loads((directory/'identity.json').read_text())
    assert identity['source']=='f7d2815bdd2025ee23a7c11449def822413f58e9'
    entries={}
    for filename, item in identity['images'].items():
        file=directory/filename
        actual=sha(file)
        assert actual==item['sha256'], (file, actual, item['sha256'])
        entries[filename]={'sha256':actual,'bytes':file.stat().st_size}
    out['images'][name]={'directory':str(directory),'identity_sha256':sha(directory/'identity.json'),'source':identity['source'],'files':entries}
original=pathlib.Path('E:/SyncForder/CodeRepos/lux-engine')
out['protected']['head']=git(original,'rev-parse','HEAD')
out['protected']['status']=git(original,'status','--porcelain','--untracked-files=all')
out['protected']['files']={}
for line in out['protected']['status'].splitlines():
    p=original/line[3:]
    if p.is_file(): out['protected']['files'][line[3:]]=sha(p)
out['fixed_dependency_manifest']={'path':str(v4/'fixed-dependencies.json'),'sha256':sha(v4/'fixed-dependencies.json')}
(root/'start.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in out.items() if k not in ['images','protected']},indent=2))
print('Matched immutable A image files:',sum(len(x['files']) for x in out['images'].values()))
