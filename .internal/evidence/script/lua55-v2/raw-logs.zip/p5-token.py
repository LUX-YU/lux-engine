from pathlib import Path
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source');p=r/'engine/toolchain/flowforge/src/AOT.cpp';t=p.read_text().replace('''                auto* token_value = accepted_builder.CreateLoad(i64, token);
                storeOutcomeField(accepted_builder, outcome_argument, token_offset, token_value);''','''                storeOutcomeField(accepted_builder, outcome_argument, token_offset,
                    accepted_builder.CreateLoad(i32, token));
                auto* generation_address = accepted_builder.CreateGEP(i8, token,
                    llvm::ConstantInt::get(i64, offsetof(lux_script_async_token, generation)));
                storeOutcomeField(accepted_builder, outcome_argument,
                    token_offset + offsetof(lux_script_async_token, generation),
                    accepted_builder.CreateLoad(i32, generation_address));''');p.write_text(t)
p=r/'engine/toolchain/flowforge/pinclude/lux/engine/flowforge/compiler/ContinuationFrameLayout.hpp';t=p.read_text().replace('                        if (full_store) { killed = true; break; }','                        if (full_store)\n                        {\n                            killed = true;\n                            break;\n                        }');p.write_text(t)
