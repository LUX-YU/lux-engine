$ErrorActionPreference='Stop'
$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5c'
$s="$r/candidate-source"
$dep='E:/SyncForder/CodeRepos/install/q2/c;E:/SyncForder/CodeRepos/install/q2/toolset;E:/SyncForder/CodeRepos/install/RelWithDebInfo'
& "$s/cmake/RunScriptV3Consumers.ps1" -SourceDir $s -OutputRoot "$r/consumers-final" -PrefixPath "E:/SyncForder/CodeRepos/install/s5c/q/d;E:/SyncForder/CodeRepos/install/s5c/q/t;$dep" -DependencyRoot D:/Development/vcpkg/installed -Names @('cpp-generated-script','physics2d-script','system-event-await-runtime','flowforge-compiler','lua-script-packager','scene-script-runtime','script-ability-codegen','system-hook-script-binding','cpp-coroutine-script','script-static-ability-specialization','script-ability-ipo','script-authoring','script-runtime-input','script-description','script-lua-values')
& "$s/cmake/RunScriptSR5ValueIncremental.ps1" -ConsumerRoot "$r/consumers-final/script-lua-values" -InstalledTemplate 'E:/SyncForder/CodeRepos/install/s5c/q/d/share/lux-engine-function/script_lua/cmake_scripts/template/lua_value.template' -EvidenceRoot "$r/incremental-final"
$original=$env:PATH
New-Item -ItemType Directory -Force -Path "$r/final-cases" | Out-Null
$cases=@()
foreach($vm in @('d','l')){
 $env:PATH="$r/q/$vm/bin;E:/SyncForder/CodeRepos/build/deps/lua54-vcpkg/x64-windows/bin;D:/Development/vcpkg/installed/x64-windows/bin;$original"
 foreach($case in @('retire-scalar','retire-zero','stop-scalar','stop-zero','input-recovery')){
  & "$r/q/$vm/bin/simulation_script_lua_value_runtime_test.exe" --admission-case $case *> "$r/final-cases/$vm-$case.log"
  if($LASTEXITCODE){throw "$vm $case failed"}
  $cases+=@{vm=$vm;case=$case;exit=0;source=(& git -C $s rev-parse HEAD).Trim();exe_sha256=(Get-FileHash "$r/q/$vm/bin/simulation_script_lua_value_runtime_test.exe").Hash}
 }
}
$cases | ConvertTo-Json | Set-Content "$r/final-cases/runs.json"
New-Item -ItemType Directory -Force -Path "$r/record-final/lua54" | Out-Null
$lua54='E:/SyncForder/CodeRepos/build/deps/lua54-vcpkg/x64-windows'
cmake -S "$s/cmake/installed-consumers/script-lua-value-costs" -B "$r/record-final/lua54/build" -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DSR5_VALUES=ON -DCMAKE_TOOLCHAIN_FILE=D:/Development/vcpkg/scripts/buildsystems/vcpkg.cmake "-DCMAKE_PREFIX_PATH=E:/SyncForder/CodeRepos/install/s5c/q/l;$dep" "-DLUA_INCLUDE_DIR=$lua54/include" "-DLUA_LIBRARY=$lua54/lib/lua.lib" -DCMAKE_FIND_USE_PACKAGE_REGISTRY=OFF -DCMAKE_FIND_USE_SYSTEM_PACKAGE_REGISTRY=OFF *> "$r/record-final/lua54/configure.log"
if($LASTEXITCODE){throw 'Lua54 diagnostic configure failed'}
cmake --build "$r/record-final/lua54/build" --target all -j 4 -- -k 0 *> "$r/record-final/lua54/all.log"
if($LASTEXITCODE){throw 'Lua54 diagnostic build failed'}
cmake --build "$r/record-final/lua54/build" --target all -j 4 -- -k 0 *> "$r/record-final/lua54/noop.log"
if($LASTEXITCODE){throw 'Lua54 diagnostic second all failed'}
$env:PATH="E:/SyncForder/CodeRepos/install/s5c/q/l/bin;$lua54/bin;D:/Development/vcpkg/installed/x64-windows/bin;$original"
foreach($mode in @('protected-errors','protected-diagnostics','diagnostics')){
 & "$r/record-final/lua54/build/script_lua_value_cost.exe" $mode 10000 *> "$r/record-final/lua54/$mode.log"
 if($LASTEXITCODE){throw "Lua54 $mode failed"}
}
& dumpbin /disasm:nobytes "$r/q/d/bin/lux_engine_simulation_script_lua.dll" *> "$r/diagnostics/C1-backend.asm"
& dumpbin /disasm:nobytes "$r/q/d/bin/lux_engine_function_script_lua.dll" *> "$r/diagnostics/C1-value.asm"
& dumpbin /disasm:nobytes "$r/q/d/bin/script_runtime_benchmark.exe" *> "$r/diagnostics/C1-benchmark.asm"
$env:PATH=$original
& "$r/final-record.ps1"
& "$s/cmake/RunScriptV3Measurements.ps1" -BaselineBin 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/q/d/bin' -FinalBin "$r/q/d/bin" -BaselineToolBin 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/q/t/bin' -FinalToolBin "$r/q/t/bin" -LuaArtifact "$r/q/t/engine/toolchain/lua/lua_runtime_benchmark_fixture.lxsa" -PhysicsLuaArtifact "$r/q/t/engine/toolchain/physics2d/physics2d_lua_fixture.lxsa" -PhysicsFlowArtifact "$r/q/t/engine/toolchain/physics2d/physics2d_flowforge_fixture.lxsa" -OutputRoot "$r/performance-C0-C1" -Only @('cpp-update-10k','lua-update-10k','lua-ability-10k','lua-event-10k','lua-coroutine-10k','flow-update-10k','flow-event-10k','event-fanout-10k') -Pairs 5 -ScalarFrames 3000
& "$s/cmake/RunScriptV3Measurements.ps1" -BaselineBin 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/m4/d/bin' -FinalBin "$r/q/d/bin" -BaselineToolBin 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/m4/t/bin' -FinalToolBin "$r/q/t/bin" -LuaArtifact "$r/q/t/engine/toolchain/lua/lua_runtime_benchmark_fixture.lxsa" -PhysicsLuaArtifact "$r/q/t/engine/toolchain/physics2d/physics2d_lua_fixture.lxsa" -PhysicsFlowArtifact "$r/q/t/engine/toolchain/physics2d/physics2d_flowforge_fixture.lxsa" -OutputRoot "$r/performance-H-C1" -Only @('lua-ability-10k') -Pairs 5 -ScalarFrames 3000
