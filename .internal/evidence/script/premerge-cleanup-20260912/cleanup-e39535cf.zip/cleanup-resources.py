import ctypes as ct,os,json,subprocess
from pathlib import Path
r=Path(__file__).parent;out=r/'cleanup-resources';out.mkdir(exist_ok=False)
k=ct.WinDLL('kernel32');k.GetCurrentProcess.restype=ct.c_void_p;k.SetProcessAffinityMask.argtypes=[ct.c_void_p,ct.c_size_t];assert k.SetProcessAffinityMask(k.GetCurrentProcess(),16)
records=[]
for leg in ['P1','P4','P5']:
 for size in [1000,10000]:
  for side in ['A','B']:
   image=r/'images'/(('E' if side=='A' else 'F')+'-common');name=f'{leg}-{size}-{side}'
   env=dict(os.environ);env['PATH']=';'.join([str(image),'D:/Development/vcpkg/installed/x64-windows/bin',*[p for p in env['PATH'].split(';') if 'CodeRepos' not in p and 'vcpkg' not in p]])
   command=[str(image/'native_lua_complete_tasks.exe'),'--case',leg,'--size',str(size),'--warmups','16','--batches','32','--diagnostics','on','--output',str(out/(name+'.csv'))]
   with (out/(name+'.log')).open('wb') as f:code=subprocess.call(command,stdout=f,stderr=subprocess.STDOUT,env=env)
   text=(out/(name+'.log')).read_text();assert code==0 and 'errors=0 backlog=0' in text
   records.append(dict(name=name,command=command,exit=code,observation=text.splitlines(),timing_acceptance=False));(out/'runs.json').write_text(json.dumps(records,indent=2));print('RESOURCE',name,'PASS',flush=True)
