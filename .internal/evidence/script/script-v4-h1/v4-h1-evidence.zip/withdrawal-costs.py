"""Seven existing whole workloads, exactly three AB/BA/AB pairs. No diagnostic hot counters."""
from pathlib import Path
import csv,ctypes as ct,json,os,re,statistics,subprocess,time
r=Path(__file__).parent;out=r/'h2-withdrawal-costs';out.mkdir(exist_ok=False)
base=r.parent/'script-v4'
identity=json.loads((r/'final-image/identity.json').read_text())
a_source=identity['source'];b_source=identity['source']
k=ct.WinDLL('kernel32');k.GetCurrentProcess.restype=ct.c_void_p
k.SetProcessAffinityMask.argtypes=[ct.c_void_p,ct.c_size_t]
assert k.SetProcessAffinityMask(k.GetCurrentProcess(),16)
cache=(r.parent/'o/w/t/CMakeCache.txt').read_text()
linker=re.search(r'CMAKE_LINKER:FILEPATH=(.*)',cache)[1].strip()
scenes=['flowforge-event']
keys=['active_instances','calls','ability_calls','events','suspensions','resumes','continuations','awaitables',
 'event_waiters','event_dispatch_visits','queue_depth','queue_high_water','checksum','physics_queries','script_calls',
 'next_step_waits','claim_lookups','actual_copy_bytes','completion_capabilities','started','completed','phase']
runs=[]
def quantile(values,q):return values[min(len(values)-1,int(len(values)*q))] if len(values)>1 else None
def metrics(rows,scene,record_time=None):
 groups=[('steady',rows)] if scene!='cpp-sequence' else [
  ('steady',[x for x in rows if not x['scenario'].endswith('-drain')]),
  ('drain',[x for x in rows if x['scenario'].endswith('-drain')])]
 result=[]
 for phase,selected in groups:
  values=sorted(int(x['nanoseconds']) for x in selected) if record_time is None else [record_time]
  if not values:continue
  unit='complete-'+scene+'-cycle';ops=len(values)*10000
  if scene=='record':ops=1000000;unit='complete-ValuePose-ability-call'
  if scene in ['cpp-sequence','physics']:ops=len(values);unit='whole-simulation-frame'
  result.append(dict(phase=phase,total_ns=sum(values),actual_operations=ops,unit=unit,
   ns_per_actual_operation=sum(values)/ops,p50_batch_ns=statistics.median(values) if len(values)>1 else None,
   p95_batch_ns=quantile(values,.95),p99_batch_ns=quantile(values,.99),max_batch_ns=max(values)))
 return result
for scene in scenes:
 for pair in range(3):
  for side in (['A','B'] if pair%2==0 else ['B','A']):
   image=r/'final-flow-image' if side=='A' else r/'h2-withdrawal/image'
   name=f'{scene}-{pair}-{side}';data=out/(name+'.csv');log=out/(name+'.log')
   expected_source=a_source if side=='A' else b_source
   if scene=='record':
    command=[str(image/'simulation_script_lua_value_runtime_test.exe'),'--benchmark','1000000']
   elif scene=='physics':
    command=[str(image/'physics2d_script_benchmark.exe'),'--group','scene-physics-mixed','--mode','performance',
     '--size','10000','--frames','2000','--warmups','300','--workers','0','--trace','off',
     '--lua-artifact',str(image/'physics2d_lua_fixture.lxsa'),
     '--flowforge-artifact',str(image/'physics2d_flowforge_fixture.lxsa'),'--output',str(data)]
   else:
    short=scene in ['cpp-sequence','flowforge-event']
    group={'event':'scene-lua-event','nextstep':'scene-lua-coroutine','scalar':'micro-lua-ability-query',
     'cpp-sequence':'scene-cpp-sequence','flowforge-event':'scene-flowforge-event'}[scene]
    exe='flowforge_script_runtime_benchmark.exe' if scene=='flowforge-event' else 'script_runtime_benchmark.exe'
    command=[str(image/exe),'--group',group,'--mode','performance','--size','10000',
     '--frames','1000' if short else '2000','--warmups','300' if short else '1000',
     '--seed','1592598566','--resume-budget','10000','--output',str(data)]
    if not short:command+=['--vm-accounting','off','--lua-artifact',str(image/'lua_runtime_benchmark_fixture.lxsa')]
   env=dict(os.environ);env['LUX_FLOWFORGE_LINKER']=linker
   env['PATH']=';'.join([str(image),'D:/Development/vcpkg/installed/x64-windows/bin',
    *[p for p in env['PATH'].split(';') if 'CodeRepos' not in p and 'vcpkg' not in p]])
   start=time.monotonic()
   with log.open('wb') as f:code=subprocess.call(command,stdout=f,stderr=subprocess.STDOUT,env=env)
   text=log.read_text(errors='replace');rows=list(csv.DictReader(data.open())) if data.exists() else []
   errors=re.findall(r'invocation_errors=(\d+)',text)
   valid=code==0 and all(int(e)==0 for e in errors)
   record_time=None
   if scene=='record':
    match=re.search(r'VALUE_BENCH count=1000000 ns=(\d+) operations=1000000 errors=0 backlog=0',text)
    valid=valid and match is not None and 'VALUE_CLEANUP invocation_errors=0' in text
    record_time=int(match[1]) if match else 0
   else:
    count=1000 if scene in ['flowforge-event','cpp-sequence'] else 2000
    steady=[x for x in rows if not x['scenario'].endswith('-drain')]
    valid=valid and len(steady)==count and all(x['git_commit']==expected_source and
     x['build_type']=='RelWithDebInfo' for x in rows)
    if scene!='cpp-sequence':valid=valid and len(errors)>=2
    if scene=='event':valid=valid and 'checksum=930010000' in text
    if scene=='flowforge-event':valid=valid and 'checksum=403000000,source=provider-payload' in text
    if scene in ['event','nextstep','scalar','flowforge-event']:
     warm=300 if scene=='flowforge-event' else 1000
     for i,row in enumerate(steady):
      expected=10000*(warm+i+1)
      for key in ['calls']+(['ability_calls'] if scene=='scalar' else ['resumes','suspensions']):
       valid=valid and int(row[key])==expected
   observed_alloc=bool(rows) and (scene=='physics' or rows[0].get('allocation_accounting')=='1')
   run=dict(scene=scene,pair=pair,side=side,source=expected_source,diagnostic_overlay=None if side=='A' else 'H2 ScriptExecution.hpp restored from f7d2815b; not a clean production commit',command=command,exit=code,valid=valid,
    wall_seconds=time.monotonic()-start,measurements=metrics(rows,scene,record_time),
    total_measured_ns=sum(int(x['nanoseconds']) for x in rows) if record_time is None else record_time,
    cumulative_business={key:rows[-1][key] for key in keys if rows and key in rows[-1]},
    errors=0 if errors and valid else None,
    error_scope='outside-ROI cumulative runtime failures and business assertions' if errors else
     'business, backend storage and shutdown assertions; cumulative failure counter unavailable',
    backlog=int(rows[-1]['queue_depth']) if rows and 'queue_depth' in rows[-1] else 0 if scene=='record' and valid else None,
    exe_local_allocations=sum(int(x['allocations']) for x in rows) if observed_alloc else None,
    vm_allocations=None,hotpath_diagnostics=False,affinity_mask=16,
    observations=[x for x in text.splitlines() if x.startswith(('INTEGRITY','ERRORS','BUSINESS_ORACLE','CELL_','NATIVE_'))])
   runs.append(run);(out/'runs.json').write_text(json.dumps(runs,indent=2))
   print(name,code,valid,[(m['phase'],round(m['ns_per_actual_operation'],3)) for m in run['measurements']],flush=True)
   if not valid:raise SystemExit('INVALID_TRIAL_RETAINED '+name)
summary=[]
for scene in scenes:
 sr=[x for x in runs if x['scene']==scene]
 for pair in range(3):
  a,b=[next(x for x in sr if x['pair']==pair and x['side']==side) for side in ['A','B']]
  assert a['cumulative_business']==b['cumulative_business'],('work mismatch',scene,pair)
  if scene!='record':
   raw={side:list(csv.DictReader((out/f'{scene}-{pair}-{side}.csv').open())) for side in ['A','B']}
   assert len(raw['A'])==len(raw['B'])
   for index,(left,right) in enumerate(zip(raw['A'],raw['B'])):
    assert all(left[k]==right[k] for k in keys if k in left and k in right),(scene,pair,index)
 for mi,measure in enumerate(sr[0]['measurements']):
  costs={s:[] for s in ['A','B']};deltas=[];all_deltas=[]
  for pair in range(3):
   selected={s:next(x for x in sr if x['pair']==pair and x['side']==s) for s in costs}
   for s in costs:costs[s].append(selected[s]['measurements'][mi]['ns_per_actual_operation'])
   deltas.append(100*(costs['B'][-1]/costs['A'][-1]-1))
   all_deltas.append(100*(selected['B']['total_measured_ns']/selected['A']['total_measured_ns']-1))
  summary.append(dict(scene=scene,phase=measure['phase'],unit=measure['unit'],paired_ns=costs,
   deltas_percent=deltas,median_percent=statistics.median(deltas),whole_measured_deltas_percent=all_deltas,
   A_ns=statistics.median(costs['A']),B_ns=statistics.median(costs['B'])))
(out/'summary.json').write_text(json.dumps(summary,indent=2))
assert len(runs)==6
print('WITHDRAWAL_COSTS_COMPLETE_6',json.dumps(summary),flush=True)
