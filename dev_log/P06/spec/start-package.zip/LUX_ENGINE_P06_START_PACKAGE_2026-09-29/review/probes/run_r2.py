from pathlib import Path
import subprocess,os,json,sys
r=Path(__file__).resolve().parent
out=r/'r2_runs';out.mkdir(exist_ok=True)
kind,opt=sys.argv[1:]
main='core_regressions.cpp' if kind=='core' else 'completion_regression.cpp'
exe=out/f'{kind}-{opt}'
cmd=['g++','-std=c++23','-'+opt,'-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie','-no-pie','-I'+str(r/'include'),str(r/'vendor_r2/SaveService.cpp'),str(r/'vendor_r2/WriteCoordinator.cpp'),str(r/main),'-o',str(exe)]
p=subprocess.run(cmd,capture_output=True,text=True,timeout=40)
(out/(exe.name+'.build.stdout')).write_text(p.stdout);(out/(exe.name+'.build.stderr')).write_text(p.stderr)
result={'scope':'Production SaveService.cpp and WriteCoordinator.cpp match reviewed Git blobs; shim headers; manually delivered completion. NOT real SaveExecution, ExecutionRuntime, SDK, models, IO or GPU. Leak detector disabled; no leak-freedom claim.','compiler':subprocess.check_output(['g++','--version'],text=True).splitlines()[0],'optimization':opt,'sources':json.loads((r/'verified_sources.json').read_text()),'build_command':cmd,'build_exit_code':p.returncode,'runs':[]}
if p.returncode:
 print(p.stderr);(out/(exe.name+'.json')).write_text(json.dumps(result,indent=2));raise SystemExit(p.returncode)
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1')
modes=['chain-control','chain-ack','revoke','recursive-adoption'] if kind=='core' else ['encoding-success','encoding-error']
for mode in modes:
 p=subprocess.run([str(exe),mode],capture_output=True,text=True,env=env,timeout=5)
 key=exe.name+'-'+mode
 (out/(key+'.stdout.log')).write_text(p.stdout);(out/(key+'.stderr.log')).write_text(p.stderr)
 result['runs'].append({'mode':mode,'command':[str(exe),mode],'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 print(key,p.returncode,p.stdout,p.stderr,flush=True)
(out/(exe.name+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2))
raise SystemExit(0 if all(x['exit_code']==0 for x in result['runs']) else 1)
