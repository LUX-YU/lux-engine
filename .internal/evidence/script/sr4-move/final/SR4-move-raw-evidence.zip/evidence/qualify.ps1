$ErrorActionPreference = 'Stop'
$taskRoot = 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/sr4-move'
$taskSource = "$taskRoot/candidate-source"
& "$taskSource/cmake/RunScriptV3Qualification.ps1" -SourceDir $taskSource -BuildRoot "E:/SyncForder/CodeRepos/build/RelWithDebInfo/m4" `
    -InstallRoot 'E:/SyncForder/CodeRepos/install/sr4-move' -CxxPrefix 'E:/SyncForder/CodeRepos/install/q2/c' `
    -ToolsetPrefix 'E:/SyncForder/CodeRepos/install/q2/toolset' `
    -FoundationPrefix 'E:/SyncForder/CodeRepos/install/RelWithDebInfo' -Profiles @('toolchain', 'developer')
$taskResults = @(Get-Content "E:/SyncForder/CodeRepos/build/RelWithDebInfo/m4/qualification.json" -Raw | ConvertFrom-Json)
$taskSha = (git -C $taskSource rev-parse HEAD).Trim()
$taskResults = @($taskResults | Where-Object source_sha -eq $taskSha)
if ($taskResults.Count -ne 2 -or @($taskResults | Where-Object status -ne 'PASS').Count) { throw 'Qualification failed' }
& "$taskSource/cmake/RunScriptV3Consumers.ps1" -SourceDir $taskSource -OutputRoot "$taskRoot/consumers" `
    -PrefixPath 'E:/SyncForder/CodeRepos/install/sr4-move/t;E:/SyncForder/CodeRepos/install/sr4-move/d;E:/SyncForder/CodeRepos/install/q2/c;E:/SyncForder/CodeRepos/install/q2/toolset;E:/SyncForder/CodeRepos/install/RelWithDebInfo' `
    -DependencyRoot 'D:/Development/vcpkg/installed' `
    -Names @('cpp-generated-script','physics2d-script','system-event-await-runtime','flowforge-compiler',
        'lua-script-packager','scene-script-runtime','script-ability-codegen','system-hook-script-binding',
        'cpp-coroutine-script','script-static-ability-specialization','script-ability-ipo','script-authoring',
        'script-runtime-input','script-description')
