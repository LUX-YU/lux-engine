from pathlib import Path
import json,hashlib,subprocess
r=Path.cwd();p=r/'local-costs.py';p.write_text(p.read_text().replace('21d106014e05cf0a7746d45fd05eac8ae01575f2','7f20191692d3f5e1037a14273a61fc99eef95714'))
p=r/'local-profile.py';p.write_text(p.read_text().replace("('C' if side=='A' else 'D')","('D' if side=='A' else 'E')").replace("'opt-source' if side=='A'","'next-source' if side=='A'"))
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
entries=[]
for name in ['D','D-common','D-flow']:
 root=r/'images'/name;data=json.loads((root/'identity.json').read_text());assert data['production_source']=='7f20191692d3f5e1037a14273a61fc99eef95714'
 for fn,item in data['images'].items():assert sha(root/fn)==item['sha256'],fn
 entries.append({'image':name,'identity':data,'all_files':{str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()}})
def git(path,*args):return subprocess.check_output(['git','-C',str(path),*args],text=True)
(root:=r/'local-baseline.json').write_text(json.dumps({'source':git(r/'local-source','rev-parse','HEAD').strip(),'worktree':git(r/'source','status','--porcelain'),'main':git(Path('E:/SyncForder/CodeRepos/lux-engine'),'status','--porcelain'),'baseline':entries},indent=2))
print('D_BASELINE_VERIFIED',sum(len(e['all_files']) for e in entries))
