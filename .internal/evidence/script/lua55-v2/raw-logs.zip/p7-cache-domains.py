from pathlib import Path
p=Path('engine/domain/simulation/scripting/lua/src/LuaScriptBackend.cpp');s=p.read_text();s=s.replace('''            if (latest == latest_prototypes.end() && latest_prototypes.size() >= instance_capacity) return nullptr;
            Prototype prototype;''','''            Prototype* evicted{};
            if (latest == latest_prototypes.end() && latest_prototypes.size() >= instance_capacity)
            {
                // A new publication domain may replace an idle cache entry. Live instances retain their roots.
                for (const auto& [asset, cached] : latest_prototypes)
                    if (cached->instance_refs == 0U) { evicted = cached; break; }
                if (evicted == nullptr) return nullptr;
            }
            Prototype prototype;''');s=s.replace('''                            latest_prototypes.emplace(context.asset, current);
                        }''','''                            latest_prototypes.emplace(context.asset, current);
                            if (evicted != nullptr)
                            {
                                latest_prototypes.erase(evicted->asset);
                                evicted->superseded = true;
                                collectPrototype(*evicted);
                            }
                        }''');p.write_text(s)
