import csv,json,math,re,statistics
from pathlib import Path
r=Path(__file__).resolve().parent
out=r/'summary';out.mkdir(exist_ok=True)
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def quantiles(values):
 values=sorted(values);n=len(values)
 return {'samples':n,'total_ns':sum(values),'p50_ns':values[math.ceil(n*.50)-1],
         'p95_ns':values[math.ceil(n*.95)-1] if n>=20 else None,
         'p99_ns':values[math.ceil(n*.99)-1] if n>=100 else None,
         'maximum_ns':values[-1], 'method':'per-run nearest rank; p95 unavailable below 20 samples, p99 below 100'}
eight=read(r/'performance/validated-costs.json')
tails=[]
for m in read(r/'performance/runs.json'):
 rows=list(csv.DictReader(Path(m['output']).open()))
 for scenario in sorted({v['scenario'] for v in rows}):
  selected=[v for v in rows if v['scenario']==scenario]
  tails.append({'case':m['case'],'pair':m['pair'],'side':m['variant'],'scenario':scenario,
                **quantiles([int(v['nanoseconds']) for v in selected])})
extras=[]
extra_runs=read(r/'extra-costs/runs.json')
for name in ('sequence','regions'):
 pairs=[]
 for pair in range(5):
  sides=[]
  for side in ('E','F'):
   rows=list(csv.DictReader((r/'extra-costs'/f'{name}-{side}-{pair}.csv').open()))
   metadata=next(v for v in extra_runs if (v['case'],v['pair'],v['side'])==(name,pair,side))
   groups=[]
   for scenario in sorted({v['scenario'] for v in rows}):
    selected=[v for v in rows if v['scenario']==scenario]
    groups.append({'scenario':scenario,**quantiles([int(v['nanoseconds']) for v in selected]),
                   'first':selected[0],'last':selected[-1]})
   sides.append({'side':side,'groups':groups,'memory':{k:metadata[k] for k in
       ('peak_working_set','peak_pagefile_usage','memory_scope')},'rows':rows})
  a,b=sides
  assert len(a['rows'])==len(b['rows'])
  fields=('scenario','size','calls','ability_calls','events','suspensions','resumes','continuations',
          'awaitables','event_waiters','queue_depth','checksum','workers','graph_tasks','graph_edges')
  assert all(all(x.get(k)==y.get(k) for k in fields) for x,y in zip(a['rows'],b['rows']))
  for group_a,group_b in zip(a['groups'],b['groups']):
   group_b['delta_ns']=group_b['total_ns']-group_a['total_ns']
   group_b['percent']=100*(group_b['total_ns']/group_a['total_ns']-1)
  del a['rows'];del b['rows'];pairs.append({'pair':pair,'E':a,'F':b})
 extras.append({'case':name,'pairs':pairs})
def value_fields(path,tag):
 line=next(l for l in path.read_text().splitlines() if l.startswith(tag))
 return {k:int(v) for k,v in re.findall(r'(\w+)=(-?\d+)',line)}
values=[]
for case,tag,count in [('record','VALUE_PUSH',1000000),('typed','VALUE_BENCH',100000)]:
 pairs=[]
 for pair in range(5):
  a=value_fields(r/'record-costs'/f'{case}-E-{pair}.log',tag)
  b=value_fields(r/'record-costs'/f'{case}-F-{pair}.log',tag)
  assert a['count']==b['count']==count
  assert a['errors']==b['errors']==a['backlog']==b['backlog']==0
  if case=='record':assert a['fields']==b['fields']==2
  else:assert a['operations']==b['operations']==count
  pairs.append({'pair':pair,'E':a,'F':b,'delta_ns':b['ns']-a['ns'],'delta_ns_per_operation':(b['ns']-a['ns'])/count,
                'percent':100*(b['ns']/a['ns']-1)})
 values.append({'case':case,'pairs':pairs,'median_percent':statistics.median(p['percent'] for p in pairs),
                'median_delta_ns_per_operation':statistics.median(p['delta_ns_per_operation'] for p in pairs),
                'median_E_ns':statistics.median(p['E']['ns'] for p in pairs),
                'median_F_ns':statistics.median(p['F']['ns'] for p in pairs),
                'per_operation_tail':'unavailable: driver emits one aggregate per independent process, not individual value operation timestamps',
                'E_diagnostics':value_fields(r/'record-costs'/f'{case}-E-diagnostics.log',tag),
                'F_diagnostics':value_fields(r/'record-costs'/f'{case}-F-diagnostics.log',tag)})
scale=read(r/'scale/runs.json');scales=[]
for size in (8,8192):
 pairs=[]
 for pair in range(5):
  a=next(v for v in scale if v['log']==f'baseline-{size}-{pair}.csv.log')
  b=next(v for v in scale if v['log']==f'candidate-{size}-{pair}.csv.log')
  for k in ('creates','destroys','ticks','rebuilds','slot_visits','endpoint_count_visits','mount_bytes','method_bytes','binding_bytes','feedback_bytes','awaitable_bytes'):
   assert a[k]==b[k],k
  pairs.append({'pair':pair,'E':a,'F':b,'percent':100*(b['elapsed_ns']/a['elapsed_ns']-1),
                'delta_ns_per_rebuild':(b['elapsed_ns']-a['elapsed_ns'])/128})
 scales.append({'configs':size,'pairs':pairs,'median_percent':statistics.median(v['percent'] for v in pairs),
                'median_delta_ns_per_rebuild':statistics.median(v['delta_ns_per_rebuild'] for v in pairs)})
def cold_fields(side, suffix):
 lines=(r/'probes'/f'{side}-{suffix}.csv.log').read_text().splitlines()
 header=lines.index('prepare_ns,late_ns,remount_128_ns,creates,destroys,prepares,releases')
 sample={k:int(v) for k,v in zip(lines[header].split(','),lines[header+1].split(','))}
 sample.update({k:int(v) for k,v in zip(lines[header+2].split(','),lines[header+3].split(','))})
 return sample
cold=[]
for pair in range(5):
 a=cold_fields('baseline',pair);b=cold_fields('candidate',pair)
 assert all(a[k]==b[k] for k in ('creates','destroys','prepares','releases'))
 cold.append({'pair':pair,'E':a,'F':b,'percent':{k:100*(b[k]/a[k]-1) for k in ('prepare_ns','late_ns','remount_128_ns')}})
result={'eight':eight,'per_run_tails':tails,'extra':extras,'values':values,'scale':scales,
        'cold':{'pairs':cold,'E_diagnostics':cold_fields('baseline','allocations'),
                'F_diagnostics':cold_fields('candidate','allocations'),
                'tail':'prepare/late one batch sample per process; remount aggregate 128; per-rebuild tails in scale'},
        'memory_notes':'See individual extra process peaks and scale/READY/VM/typed diagnostics. No equivalence between backing bytes and RSS; zero with counters disabled is unavailable.',
        'statistics':'five independent balanced process pairs; no slow pair removed; no arithmetic chaining of historical ratios'}
(out/'costs.json').write_text(json.dumps(result,indent=2))
for c in eight['comparisons']:print(c['case'],round(c['median_percent'],3),c['range_percent'])
for v in values:print(v['case'],round(v['median_percent'],3),v['median_delta_ns_per_operation'])
for v in scales:print('scale',v['configs'],v['median_percent'],v['median_delta_ns_per_rebuild'])
