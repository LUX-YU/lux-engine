from pathlib import Path
r=Path.cwd();t=(r/'next-analysis.py').read_text().replace('next-','local-').replace("baseline='21d106014e05cf0a7746d45fd05eac8ae01575f2'","baseline='7f20191692d3f5e1037a14273a61fc99eef95714'")
t=t.replace("('A','hot-class-layout')","('A','next-class-layout')")
t=t.replace("r/'hot-analysis/frames.json'","r/'next-analysis/frames.json'").replace("if x['side']=='B1'","if x['side']=='B'")
t=t.replace("'EventWaiterRecord','ContinuationRecord','ScriptCompletionIngress','ScriptExecution','ResumeBatch'","'EventWaiterRecord','ContinuationRecord','ScriptCompletionIngress','ScriptExecution','ResumeBatch',\n   'ScriptEventWaitLink','WaitPage','ExecutionInstance','EventRouteHead','ScriptSyncStepSetView'")
t=t.replace("['PROCESS_MEMORY','MEMORY','NATIVE_MEMORY']","['PROCESS_MEMORY','MEMORY','NATIVE_MEMORY','WAIT_MEMORY']")
t=t.replace("'copyPayload','copyScalarEventPayload'","'ScriptCoroutineContext::invokeResolvedSyncStep','ScriptCoroutineContext::resolveSyncStep',\n  'ScriptEventImports::resolve','AwaitableStorage::acquire','AwaitableStorage::releaseResolved',\n  'copyPayload','copyScalarEventPayload'")
(r/'local-analysis.py').write_text(t)
