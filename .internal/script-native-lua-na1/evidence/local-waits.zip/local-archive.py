from pathlib import Path
import hashlib,json,subprocess,zipfile
r=Path(__file__).parent;s=r/'source';e=s/'.internal/script-native-lua-na1/evidence'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
source=git(r/'local-source','rev-parse','HEAD');assert git(r/'local-source','status','--porcelain')==''
initial=json.loads((r/'local-baseline.json').read_text())
for x in initial['protected']:
 assert git(x['repo'],'rev-parse','HEAD')==x['head'] and git(x['repo'],'status','--porcelain')==x['status']
 for f in x['files']:assert sha(Path(x['repo'])/f['path'])==f['sha256']
for x in initial['dependency_files']:assert sha(x['path'])==x['sha256'],x['path']
for x in initial['baseline']:
 for p,h in x['all_files'].items():assert sha(r/'images'/x['image']/p)==h,p
headers=[]
for rel in git(r/'local-source','diff','--name-only','7f201916',source).splitlines():
 if '/include/' not in rel or not rel.endswith('.hpp'):continue
 tail=rel.split('/include/',1)[1]
 for prefix in ['local-tools','local-sdk']:
  p=Path('E:/SyncForder/CodeRepos/install/o/na1')/prefix/'include'/tail
  assert p.exists() and sha(p)==sha(r/'local-source'/rel),(rel,p)
  headers.append({'source':rel,'installed':str(p),'sha256':sha(p)})
(r/'local-protected-final.json').write_text(json.dumps({'source':source,'protected':initial['protected'],'dependency_files_verified':len(initial['dependency_files']),'baseline_images_verified':sum(len(x['all_files']) for x in initial['baseline']),'installed_public_headers':headers},indent=2))
identities=[]
for folder in ['D','D-common','D-flow','E','E-common','E-flow']:
 root=r/'images'/folder;info=json.loads((root/'identity.json').read_text())
 for name,entry in info['images'].items():assert sha(root/name)==entry['sha256']
 for p in sorted(root.iterdir()):
  if p.is_file():identities.append({'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':sha(p)})
(r/'local-final-image-identities.json').write_text(json.dumps(identities,indent=2))
(r/'local-source-identity.json').write_text(json.dumps({'qualification_source':source,'clean':True,'branch':git(s,'branch','--show-current'),'production_baseline':'7f20191692d3f5e1037a14273a61fc99eef95714','code_commits':git(s,'log','--format=%H %s','d63767c2..'+source).splitlines(),'changed':git(s,'diff','--name-only','d63767c2',source).splitlines()},indent=2))
files=set();allowed={'.json','.jsonl','.log','.txt','.csv','.py','.ps1','.asm','.hpp','.cpp','.cmake','.lua','.template'}
for p in r.iterdir():
 if p.is_file() and p.name.startswith('local-') and p.suffix.lower() in allowed:files.add(p)
for root in r.iterdir():
 if not root.is_dir() or not root.name.startswith('local-') or root.name=='local-source':continue
 for p in root.rglob('*'):
  if not p.is_file() or '.git' in p.parts:continue
  parts=p.relative_to(root).parts
  if root.name=='local-profiles':files.add(p);continue
  if ('installed' in root.name or 'relocated' in root.name) and any(x in parts for x in ['sdk','tools','vm','source','build','CMakeFiles']):continue
  if p.suffix.lower() in allowed:files.add(p)
for folder in ['D','D-common','D-flow','E','E-common','E-flow']:files.update((r/'images'/folder).glob('*.json'))
files.add(r/'profile-target.py')
assert all(p.suffix.lower() not in {'.exe','.dll','.pdb','.obj','.lib','.a'} for p in files)
archive=e/'local-waits.zip';assert not archive.exists();manifest=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):
  data=p.read_bytes();path=p.relative_to(r).as_posix();z.writestr(path,data);manifest.append({'path':path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
info={'archive':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'entries':len(manifest),'qualification_source':source,'production_baseline':'7f20191692d3f5e1037a14273a61fc99eef95714','compiled_images_in_archive':False,'manifest':manifest}
(e/'local-waits.json').write_text(json.dumps(info,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(manifest)
 for x in manifest:assert hashlib.sha256(z.read(x['path'])).hexdigest()==x['sha256']
print(json.dumps({k:v for k,v in info.items() if k!='manifest'},indent=2))
