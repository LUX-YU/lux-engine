$ErrorActionPreference='Stop'
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5c'
cmake --build E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/d --target all -j 4 -- -k 0 *> "$r/pre-all.log"
if ($LASTEXITCODE) { throw 'pre all failed' }
$env:PATH="E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/d/bin;D:/Development/vcpkg/installed/x64-windows/bin;$env:PATH"
$records=@()
foreach ($case in @('retire-scalar','retire-zero','stop-scalar','stop-zero','input-recovery')) {
    & E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/d/bin/simulation_script_lua_value_runtime_test.exe --admission-case $case *> "$r/pre-$case.log"
    $records+=@{case=$case;exit=$LASTEXITCODE;source=(& git -C E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source rev-parse HEAD).Trim();exe_sha256=(Get-FileHash E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/d/bin/simulation_script_lua_value_runtime_test.exe).Hash}
}
$records | ConvertTo-Json | Set-Content "$r/pre-cases.json"
$records | Format-Table
