// Same AbilityProvider and read/write operations as flowforge_script_artifact_test.
// The graph is gameplay.ability, produced by that actual test through AOT.cpp.
#include <lux/engine/function/script/abi/lux_script_abi.h>
#include <cstddef>
#include <cstdint>
#include <cstdio>
struct AbilityProvider final { std::int32_t value{}; std::size_t calls{}; };
static std::int32_t readAbility(void* opaque,const void*,std::int32_t value) noexcept {
    auto& self=*static_cast<AbilityProvider*>(opaque);++self.calls;return self.value+value;
}
static void writeAbility(void* opaque,const void*,std::int32_t value) noexcept {
    auto& self=*static_cast<AbilityProvider*>(opaque);++self.calls;self.value=value;
}
extern "C" const lux_script_module_desc* lux_script_get_module();
extern "C" __declspec(noinline) int runActualGraph(AbilityProvider* provider) {
    const lux_script_prepared_ability prepared[]{
        {provider,nullptr,reinterpret_cast<lux_script_ability_direct_entry_fn>(&readAbility)},
        {provider,nullptr,reinterpret_cast<lux_script_ability_direct_entry_fn>(&writeAbility)}
    };
    lux_script_native_instance_context instance{nullptr,prepared,2,0};
    lux_script_call_frame frame{};
    const auto* module=lux_script_get_module();
    if(module->abi_version!=6 || module->function_count!=1 || module->ability_import_count!=2) return 1;
    return module->functions[0].invoke(&instance,&frame);
}
int main() {
    AbilityProvider provider;
    const auto status=runActualGraph(&provider);
    std::printf("STATIC_FLOWFORGE,status=%d,provider_calls=%zu,value=%d,abi=6\n",status,provider.calls,provider.value);
    return status==0 && provider.calls==2 && provider.value==41 ? 0:1;
}
