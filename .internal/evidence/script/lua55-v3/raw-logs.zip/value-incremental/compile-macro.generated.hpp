#pragma once
// Generated typed value operations and immutable CodecPlan specializations.
// Member thunks preserve non-standard-layout and const-member construction; no runtime reflection interpretation.
#include <lux/engine/function/script/lua/LuaValue.hpp>
#include <Values.hpp>
#include "E:/SyncForder/CodeRepos/build/RelWithDebInfo/lua55-v3/installed/script-lua-values/source/Rules.hpp"

namespace lux::script::lua
{


template <> struct LuaGeneratedValue<::Item> : LuaRecordValue<::Item,
    LuaValueField<&::Item::id, "key">,
    LuaValueField<&::Item::weight, "weight">>
{
};
static_assert(LuaValueCodec<::Item>::bounded, "Lua value expanded frame exceeds 64 KiB or depth 32");
}
