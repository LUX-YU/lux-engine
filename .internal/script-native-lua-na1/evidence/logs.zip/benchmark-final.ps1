param([string]$Side='A',[string]$Label='bench-dev')
$ErrorActionPreference='Stop'
$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1'
$s="$r/qualification-source"
$b="$r/benchmark-slots/$Side"
& 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$p=if($Side -eq 'A'){'E:/SyncForder/CodeRepos/install/o/v4/sdk'}else{'E:/SyncForder/CodeRepos/install/o/na1/qualified-sdk'}
$tools=if($Side -eq 'A'){'E:/SyncForder/CodeRepos/install/o/v4/tools'}else{'E:/SyncForder/CodeRepos/install/o/na1/qualified-tools'}
$prefix="$p;$tools;E:/SyncForder/CodeRepos/install/o/v4/lua55;E:/SyncForder/CodeRepos/install/q2/c;E:/SyncForder/CodeRepos/install/q2/toolset"
$clean=@($env:PATH.Split(';')|Where-Object{$_ -notmatch 'CodeRepos[/\\](install|build)' -and $_ -notmatch 'vcpkg[/\\]installed'})
$env:PATH=((@($prefix.Split(';')|ForEach-Object{"$_/bin"})+@('D:/Development/vcpkg/installed/x64-windows/bin')+$clean)-join ';')
function Run([string]$stage,[string[]]$command){
 $log="$r/$Label-$Side-$stage.log"
 if(Test-Path -LiteralPath $log){throw 'Log exists'}
 $command|ConvertTo-Json -Compress|Set-Content $log
 & $command[0] $command[1..($command.Count-1)] *>> $log
 $code=$LASTEXITCODE
 @{source=(git -C $s rev-parse HEAD);side=$Side;prefix=$prefix;command=$command;exit=$code;worktree=(@(git -C $s status --porcelain) -join "`n")}|ConvertTo-Json -Depth 5|Set-Content "$r/$Label-$Side-$stage.json"
 Write-Output "$Label $Side $stage exit=$code"
 if($code){throw "Failed $log"}
}
$candidate=if($Side -eq 'A'){'OFF'}else{'ON'}
Run 'configure' @('cmake','--fresh','-S',"$s/cmake/benchmarks/native-lua-complete",'-B',$b,'-G','Ninja',
 '-DCMAKE_BUILD_TYPE=RelWithDebInfo','-DNA1_ITT_SDK=D:/Softwares/Intel/oneAPI/vtune/2026.3/sdk',"-DNA1_SOURCE_DIR=$s","-DNA1_CANDIDATE=$candidate","-DCMAKE_PREFIX_PATH=$prefix",
 '-DCMAKE_FIND_USE_PACKAGE_REGISTRY=OFF','-DCMAKE_FIND_USE_SYSTEM_PACKAGE_REGISTRY=OFF',
 '-DCMAKE_TOOLCHAIN_FILE=D:/Development/vcpkg/scripts/buildsystems/vcpkg.cmake')
Run 'build' @('cmake','--build',$b,'--target','all','-j','4','--','-k','0')
foreach($case in @('P1','P2','P3','P4','P5')){
 Run $case @("$b/native_lua_complete_tasks.exe",'--case',$case,'--size','64','--warmups','2','--batches','4','--output',"$r/$Label-$Side-$case.csv")
}
