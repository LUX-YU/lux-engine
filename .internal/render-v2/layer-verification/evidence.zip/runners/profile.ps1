$ErrorActionPreference='Stop'
$vtune='C:/Program Files (x86)/Intel/oneAPI/vtune/2026.4/bin64/vtune.exe'
$env:Path="D:/Softwares/VulkanSDK/1.3.280.0/Bin;$env:Path"
$base='E:/RenderV2Rebuild/Layer/evidence/L4/vtune'
New-Item -ItemType Directory -Force $base | Out-Null
foreach($variant in 'baseline','layer') {
 $directory="$base/$variant"
 New-Item -ItemType Directory -Force $directory | Out-Null
 Push-Location $directory
 try {
  & $vtune -collect hotspots -knob sampling-mode=sw -knob enable-characterization-insights=false -start-paused -result-dir "$directory/result" -- "E:/RenderV2Rebuild/Layer/perf/$variant/fixed.exe" alias *> collection.log
  $code=$LASTEXITCODE
  "EXIT=$code" | Add-Content collection.log
  if($code -ne 0){Get-Content collection.log -Tail 25;exit $code}
  & $vtune -report summary -r "$directory/result" -format csv -report-output "$directory/summary.csv" *> summary.log
  & $vtune -report hotspots -r "$directory/result" -group-by function -format csv -report-output "$directory/hotspots.csv" *> hotspots.log
  & $vtune -report hotspots -r "$directory/result" -group-by module -format csv -report-output "$directory/modules.csv" *> modules.log
 } finally {Pop-Location}
 Write-Output "VTune $variant finished"
}

