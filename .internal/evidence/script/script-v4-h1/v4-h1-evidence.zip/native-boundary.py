from pathlib import Path
import json,os,re,subprocess
r=Path(__file__).parent;source=r.parent/'script-cell-a1/source';build=r.parent/'o/w/d';out=r/'native-boundary';out.mkdir(exist_ok=False)
records=[]
def run(name,command,env=None):
    with (out/(name+'.log')).open('wb') as f:code=subprocess.call(command,cwd=out,env=env,stdout=f,stderr=subprocess.STDOUT)
    records.append(dict(name=name,command=command,exit=code));(out/'runs.json').write_text(json.dumps(records,indent=2))
    print(name,code,flush=True)
    if code:raise SystemExit(name+' failed')
run('fixture',['cl','/nologo','/std:c++20','/MD','/EHsc','/O2','/Ob1','/Zi','/LD',
    '/I'+str(source/'modules/function/script/core/include'),str(r/'native-boundary-fixture.cpp'),
    '/link','/OUT:'+str(out/'fixture.dll'),'/PDB:'+str(out/'fixture.pdb')])
name='simulation_script_native_test'
commands=subprocess.check_output(['ninja','-C',str(build),'-t','commands',name],text=True).splitlines()
compile=next(x for x in commands if (' /c ' in x or ' -c ' in x) and name+'.dir' in x and '.cpp' in x)
old_obj=re.search(r'/Fo(\S+)',compile)[1];obj=out/'test.obj'
compile=re.sub(r'/Fo\S+',lambda m:'/Fo'+str(obj),compile)
compile=re.sub(r'/Fd\S+',lambda m:'/Fd'+str(out/'test.pdb'),compile)
compile=re.sub(r' [/-]c .*$',lambda m:' /c '+str(r/'native-boundary-test.cpp'),compile)
link=next(x for x in reversed(commands) if 'vs_link_exe' in x and '/out:bin\\'+name+'.exe' in x).split(' -- ',1)[1].split(' && ',1)[0]
link=link.replace(old_obj,str(obj)).replace('/out:bin\\'+name+'.exe','/out:'+str(out/'test.exe'))
link=link.replace('/pdb:bin\\'+name+'.pdb','/pdb:'+str(out/'test-link.pdb')).replace('/implib:lib\\'+name+'.lib','/implib:'+str(out/'test.lib'))
# Retain the original build working directory for relative import libraries.
for label,cmd in [('compile',compile),('link',link)]:
    with (out/(label+'.log')).open('wb') as f:code=subprocess.call(cmd,cwd=build,stdout=f,stderr=subprocess.STDOUT)
    records.append(dict(name=label,command=cmd,exit=code));(out/'runs.json').write_text(json.dumps(records,indent=2))
    if code:raise SystemExit(label+' failed')
for side in ['A','B']:
    image=r.parent/'script-v4/final-image' if side=='A' else r/'final2-image'
    env=dict(os.environ);env['PATH']=';'.join([str(image),'D:/Development/vcpkg/installed/x64-windows/bin',
        *[p for p in env['PATH'].split(';') if 'CodeRepos' not in p and 'vcpkg' not in p]])
    for mode in range(8):
        env['LUX_H1_BOUNDARY_CASE']=str(mode)
        run(f'{side}-{mode}',[str(out/'test.exe'),str(out/'fixture.dll'),str(mode)],env)
print('NATIVE_BOUNDARY_PASS_16',flush=True)
