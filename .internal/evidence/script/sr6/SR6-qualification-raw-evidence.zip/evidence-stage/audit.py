import hashlib,json,re,subprocess
from pathlib import Path
r=Path(__file__).resolve().parent;s=r/'candidate-source';out=r/'audit';out.mkdir(exist_ok=True)
def git(*a):return subprocess.check_output(['git','-C',str(s),*a],text=True).strip()
assert not git('status','--porcelain')
assert not git('diff','--name-only','f64cadde','HEAD','--','engine','modules')
paths=git('ls-files','engine','modules','cmake').splitlines()
formal=[];obsolete=[];lua_execution=[]
for p in paths:
 path=s/p
 if path.suffix not in ('.hpp','.cpp','.cmake','.template') and path.name!='CMakeLists.txt':continue
 t=path.read_text(encoding='utf-8-sig',errors='replace')
 if '/test/' not in p and '/benchmark/' not in p and p.startswith(('engine/','modules/')):
  if 'LuaRecordMarshaller' in t:obsolete.append(p)
  if p.startswith('engine/domain/simulation/builtin/script/') and any(n in t for n in ('WorldObjectResolver','ScriptSystemDescription','WorldObjectId')):obsolete.append(p)
 if path.name in ('ScriptExecution.hpp','ScriptExecution.cpp') and re.search(r'lua_State|LuaValueCodec|LuaValueSlot|lua_get|lua_raw',t):lua_execution.append(p)
 if path.name in tuple('Script'+n+'.hpp' for n in ('Instances','Bindings','Preparer','Execution','EventWaits','Timers','CompletionIngress')):
  formal.append({'path':p,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                 'private_module_header':'/pinclude/' in p})
assert len(formal)==7 and all(v['private_module_header'] for v in formal)
assert not obsolete and not lua_execution
cases={
 'C01':['hook_regions_test.cpp','hook_execution_test.cpp'],
 'C02':['script_system_continuation_test.cpp','cpp_coroutine_test.cpp'],
 'C03':['script_system_event_wait_test.cpp','script_ingress_frontier_test.cpp','scene_script_runtime_test.cpp'],
 'C04':['script_system_event_wait_test.cpp'],
 'C05':['script_system_event_wait_test.cpp'],
 'C06':['script_system_event_wait_test.cpp'],
 'C07':['script_system_event_wait_test.cpp','script_system_lifecycle_test.cpp'],
 'C08':['script_system_lifecycle_test.cpp','lua_closure_provenance_test.cpp','script_ingress_frontier_test.cpp'],
 'C09':['script_ingress_frontier_test.cpp','script_system_continuation_test.cpp'],
 'C10':['script_system_lifecycle_test.cpp'],
 'C11':['lua_value_runtime_test.cpp','lua_prepared_storage_test.cpp'],
 'C12':['script_system_lifecycle_test.cpp','scene_script_runtime_test.cpp'],
 'C13':['script_system_continuation_test.cpp','script_system_event_wait_test.cpp']}
tests={}
for key,names in cases.items():
 matches=[]
 for name in names:
  found=[p for p in paths if Path(p).name==name]
  for p in found:
   t=(s/p).read_text(encoding='utf-8-sig');matches.append({'path':p,'sha256':hashlib.sha256((s/p).read_bytes()).hexdigest(),
       'functions':re.findall(r'\b(?:void|int)\s+(test[A-Z]\w*)\s*\(',t)})
 assert matches,key
 tests[key]=matches
(out/'formal-paths.json').write_text(json.dumps({'candidate':git('rev-parse','HEAD'),
 'production_equal_to_entry':True,'diff':git('diff','--name-only','f64cadde','HEAD'),
 'owners':formal,'obsolete_formal_entry_matches':obsolete,'lua_values_in_execution':lua_execution,
 'test_sources':tests,'scope':'finite tracked-source audit, not a proof of every possible runtime interleaving'},indent=2))
print('7 private owners, production/source/template identity unchanged, obsolete formal inputs absent')
