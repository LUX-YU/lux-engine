from pathlib import Path
import hashlib, json
root=Path(__file__).parent/'probes'
old=root/'vendor'
new=root/'vendor_r1';new.mkdir(exist_ok=True)
s=(old/'SaveService.cpp').read_text()
s=s.replace('    struct SaveService::Impl final\n    {\n', '''    struct SaveService::Impl final
    {
        // One owner-thread call frame covers role dispatch and destruction of callback-owned inputs.
        // This protects service records only; SessionState remains the sole editing admission gate.
        struct DispatchScope final
        {
            bool& active;
            explicit DispatchScope(bool& value) noexcept : active(value)
            {
                active = true;
            }
            ~DispatchScope()
            {
                active = false;
            }
            DispatchScope(const DispatchScope&) = delete;
            DispatchScope& operator=(const DispatchScope&) = delete;
        };
''')
s=s.replace('        std::size_t snapshot_bytes{};\n','        std::size_t snapshot_bytes{};\n        bool dispatching{};\n')
for name in ['registerSource','requestSave','takeEncoding','completeEncoding','requestCancel','acknowledge']:
 start=s.index('SaveService::'+name+'(')
 pos=s.index('        if (!impl_->onOwner())\n            return failed(EPersistenceError::WRONG_THREAD);',start)
 end=pos+len('        if (!impl_->onOwner())\n            return failed(EPersistenceError::WRONG_THREAD);')
 s=s[:end]+'''\n        if (impl_->dispatching)
            return failed(EPersistenceError::BUSY);
        const Impl::DispatchScope dispatch(impl_->dispatching);'''+s[end:]
s=s.replace('''        auto info = describeSource(*registration->source);
        if (!info)''','''        auto* const source = registration->source;
        auto info = describeSource(*source);
        if (registration->source != source)
            return failed(EPersistenceError::STALE_SOURCE);
        if (!info)''')
s=s.replace('''        auto frozen = captureSource(*registration->source, *info, request, allowance);
        const bool invalid_capture =''','''        auto frozen = captureSource(*source, *info, request, allowance);
        const bool is_revoked = registration->source != source;
        const bool invalid_capture =''')
s=s.replace('''        if (!frozen || invalid_capture)
        {
            auto error = frozen ? PersistenceFailure{EPersistenceError::STALE_SOURCE} : frozen.error();''','''        const bool is_stale_capture = is_revoked || invalid_capture;
        const bool is_rejected_capture = !frozen || is_stale_capture;
        if (is_rejected_capture)
        {
            auto error = is_stale_capture ? PersistenceFailure{EPersistenceError::STALE_SOURCE} : frozen.error();''')
s=s.replace('''    void SaveService::adoptCompletions()
    {
        if (!impl_->onOwner())
            std::terminate();''','''    void SaveService::adoptCompletions()
    {
        if (!impl_->onOwner())
            std::terminate();
        if (impl_->dispatching)
            return;
        const Impl::DispatchScope dispatch(impl_->dispatching);''')
w=(old/'WriteCoordinator.cpp').read_text()
w=w.replace('''                if (target->last_writer != record.origin)
''','''                const bool is_continuation =
                    target->last_writer == record.origin && record.work.target.expected_version == target->version;
                if (!is_continuation)
''')
w=w.replace('''                return receipt && receipt->version == it->work.target.expected_version;''','''                // A successful record proves both the version consumed and the version produced.
                // Its effective publication precondition remains valid evidence after the preceding
                // receipt is acknowledged. Pending/failed/unknown records prove no such edge.
                const bool has_verified_edge =
                    receipt && (receipt->version == it->work.target.expected_version ||
                                earlier.work.target.expected_version == it->work.target.expected_version);
                return has_verified_edge;''')
expected={'SaveService.cpp':'48b7bcf677b857bf1fe2574fad2c3559d40a36d6','WriteCoordinator.cpp':'32df3af3b63d3065fc955c0b00f11317466e35d2'}
manifest=[]
for file,text in [('SaveService.cpp',s),('WriteCoordinator.cpp',w)]:
 b=text.encode(); sha=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\x00'+b).hexdigest()
 print(file,len(b),sha,sha==expected[file]);assert sha==expected[file]
 (new/file).write_bytes(b)
 manifest.append({'file':file,'git_blob_sha1':sha,'sha256':hashlib.sha256(b).hexdigest(),'revision':'5a1ccbb47d2d08ffa8cfda907f74319c4a694068','match':True})
(root/'current_source_identity.json').write_text(json.dumps(manifest,indent=2))
