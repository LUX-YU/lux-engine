from pathlib import Path
p=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source/modules/function/script/lua/include/lux/engine/function/script/lua/LuaValue.hpp')
s=p.read_text()
a=s.index('        // Trivial staging only.');b=s.index('        class LUX_FUNCTION_PUBLIC LuaValueAccess',a)
s=s[:a]+'''        struct LuaFieldLookup final { std::uint64_t hash; std::uint32_t ordinal; };
        constexpr std::uint64_t luaFieldHash(std::string_view value) noexcept
        {
            std::uint64_t hash = 14695981039346656037ULL;
            for (unsigned char c : value) hash = (hash ^ c) * 1099511628211ULL;
            return hash;
        }
        template <std::size_t N>
        consteval auto makeLuaFieldLookup(const std::array<std::string_view, N>& keys) noexcept
        {
            std::array<LuaFieldLookup, N> result{};
            for (std::size_t i{}; i < N; ++i) result[i] = {luaFieldHash(keys[i]), static_cast<std::uint32_t>(i)};
            for (std::size_t i = 1U; i < N; ++i)
                for (std::size_t j = i; j != 0U && result[j].hash < result[j - 1U].hash; --j)
                {
                    const auto previous = result[j - 1U];
                    result[j - 1U] = result[j];
                    result[j] = previous;
                }
            return result;
        }
        struct LuaCodecShape final
        {
            std::span<const std::string_view> keys;
            std::span<const LuaFieldLookup> lookup;
        };
        struct LuaCodecPlan;
        struct LuaCodecField final
        {
            std::string_view name;
            const void* (*member)(const void*) noexcept;
            const LuaCodecPlan& (*plan)() noexcept;
        };
        // Only immutable type structure. No invocation object addresses are stored here.
        struct LuaCodecPlan final
        {
            ELuaPlainKind kind;
            std::uint32_t stack;
            std::span<const LuaCodecField> fields;
            LuaPlainNumber (*read)(const void*) noexcept;
            bool (*validate)(double) noexcept;
            const LuaCodecShape* shape;
        };
'''+s[b:]
s=s.replace('            [[nodiscard]] static LuaValueResult<void> plain(lua_State *, std::span<const LuaPlainNode>, std::size_t) noexcept;', '''            [[nodiscard]] static bool prepare(lua_State*, const LuaCodecPlan&) noexcept;
            [[nodiscard]] static LuaValueResult<void> writePlan(lua_State*, const LuaCodecPlan&, const void*) noexcept;
            [[nodiscard]] static LuaValueResult<void> readPlan(lua_State*, int, const LuaCodecPlan&, std::span<double>) noexcept;''')
s=s.replace('std::span<const std::string_view>) noexcept;','std::span<const std::string_view>, const LuaCodecShape* = nullptr) noexcept;',1)
s=s.replace('        template <class, class> friend struct LuaValueCodec;\n        [[nodiscard]] LuaValueResult<void> plain(std::span<const detail::LuaPlainNode> nodes) noexcept\n        {\n            return detail::LuaValueAccess::plain(state_, nodes, depth_);\n        }','        template <class, class> friend struct LuaValueCodec;')
# Reader index remains private to typed Codec, never made into a public VM escape.
pos=s.index('    class LuaValueReader\n') if '    class LuaValueReader\n' in s else -1
# Find the reader private block by first state_ declaration before writer.
a=s.index('    class LuaValueReader\n') if pos>=0 else s.index('    class LuaValueReader\r') if '    class LuaValueReader\r' in s else s.index('    class LuaValueReader final')
b=s.index('    class LuaValueWriter',a)
r=s[a:b]
r=r.replace('      private:', '      private:\n        template <class, class> friend struct LuaValueCodec;',1)
r=r.replace('shape(std::span<const std::string_view> keys) const noexcept','shape(std::span<const std::string_view> keys, const detail::LuaCodecShape* plan = nullptr) const noexcept')
r=r.replace('LuaValueAccess::shape(state_, index_, keys)','LuaValueAccess::shape(state_, index_, keys, plan)')
s=s[:a]+r+s[b:]
# Plan-driven pure input validates before constructing aggregate/const-member typed values.
s=s.replace('''            if constexpr (can_read && bounded && requires { Rule::template read<Policy>(input); })''','''            if constexpr (can_read && bounded && plainCount() > 1U && plainCount() <= 8192U)
            {
                std::array<double, plainCount()> scratch;
                const auto read = detail::LuaValueAccess::readPlan(input.state_, input.index_, plan(), scratch);
                if (!read) return lux::cxx::unexpected(read.error());
                std::size_t cursor{};
                return consumePlain(scratch, cursor);
            }
            else if constexpr (can_read && bounded && requires { Rule::template read<Policy>(input); })''')
a=s.index('        static void appendPlain(');b=s.index('        static LuaValueResult<void> push(',a)
s=s[:a]+'''        static const detail::LuaCodecPlan& plan() noexcept
        {
            if constexpr (LuaValueScalar<Value>)
            {
                static constexpr detail::LuaCodecPlan result{
                    std::is_same_v<Value, bool> ? detail::ELuaPlainKind::BOOLEAN : detail::ELuaPlainKind::NUMBER,
                    2U, {}, [](const void* pointer) noexcept {
                        return detail::LuaPlainNumber{static_cast<double>(*static_cast<const Value*>(pointer)), true};
                    }, [](double value) noexcept {
                        if (!std::isfinite(value)) return false;
                        if constexpr (std::is_same_v<Value, bool>) return true;
                        else if constexpr (std::is_integral_v<Value>)
                            return std::trunc(value) == value &&
                                value >= static_cast<double>((std::numeric_limits<Value>::lowest)()) &&
                                value <= static_cast<double>((std::numeric_limits<Value>::max)());
                        else return value >= -static_cast<double>((std::numeric_limits<Value>::max)()) &&
                            value <= static_cast<double>((std::numeric_limits<Value>::max)());
                    }, nullptr
                };
                return result;
            }
            else return Rule::template plan<Policy>();
        }
        static Value consumePlain(std::span<const double> values, std::size_t& cursor) noexcept
        {
            if constexpr (LuaValueScalar<Value>) return static_cast<Value>(values[cursor++]);
            else return Rule::template consumePlain<Policy>(values, cursor);
        }
'''+s[b:]
a=s.index('            if constexpr (can_push && bounded && plainCount() > 1U');b=s.index('            else if constexpr (can_push',a)
s=s[:a]+'''            if constexpr (can_push && bounded && plainCount() > 1U && plainCount() <= 8192U)
                return detail::LuaValueAccess::writePlan(output.state_, plan(), std::addressof(value));
'''+s[b:]
s=s.replace('        inline static constexpr std::array<std::string_view, sizeof...(Field)> keys{Field::name...};','''        inline static constexpr std::array<std::string_view, sizeof...(Field)> keys{Field::name...};
        inline static constexpr auto lookup = detail::makeLuaFieldLookup(keys);
        inline static constexpr detail::LuaCodecShape shape_plan{keys, lookup};''')
a=s.index('        template <class Policy> static void appendPlain(');b=s.index('        using Slots',a)
s=s[:a]+'''        template <class Policy> static const detail::LuaCodecPlan& plan() noexcept
        {
            static constexpr std::array<detail::LuaCodecField, sizeof...(Field)> fields{{
                {Field::name, [](const void* parent) noexcept -> const void* {
                    return std::addressof(static_cast<const T*>(parent)->*Field::member);
                }, &LuaValueCodec<typename Field::template Value<T>, Policy>::plan}...
            }};
            static constexpr detail::LuaCodecPlan result{detail::ELuaPlainKind::RECORD,
                static_cast<std::uint32_t>(depthFor<Policy>() * 4U + 8U), fields, nullptr, nullptr, &shape_plan};
            return result;
        }
        template <class Policy>
        static T consumePlain(std::span<const double> values, std::size_t& cursor) noexcept
        {
            ++cursor; // A record has no scalar payload. Never read its uninitialized scratch slot.
            return T{LuaValueCodec<typename Field::template Value<T>, Policy>::consumePlain(values, cursor)...};
        }
'''+s[b:]
s=s.replace('auto shape = input.shape(keys);','auto shape = input.shape(keys, &shape_plan);')
a=s.index('        template <class Policy> static void appendPlain(');b=s.index('        static LuaValueResult<T> read(',a)
s=s[:a]+'''        template <class Policy> static const detail::LuaCodecPlan& plan() noexcept
        {
            static constexpr detail::LuaCodecPlan result{detail::ELuaPlainKind::NUMBER, 2U, {},
                [](const void* pointer) noexcept {
                    const auto current = *static_cast<const T*>(pointer);
                    return detail::LuaPlainNumber{static_cast<double>(static_cast<Underlying>(current)), valid(current)};
                }, [](double number) noexcept {
                    if (!LuaValueCodec<Underlying, Policy>::plan().validate(number)) return false;
                    return valid(static_cast<T>(static_cast<Underlying>(number)));
                }, nullptr};
            return result;
        }
        template <class Policy>
        static T consumePlain(std::span<const double> values, std::size_t& cursor) noexcept
        { return static_cast<T>(static_cast<Underlying>(values[cursor++])); }
'''+s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
