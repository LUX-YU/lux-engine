# ED-1：共享编辑历史与通用 Editor 路由——实际实施任务单

2026-09-08，与主规范v2配套。用户发送并要求执行后生效。**只执行ED-1**。职责和协议已确定，不再以一篇同义设计代替编码，也不自动进入业务全面迁移。

## 1. 本轮完成什么

在engine/editor/editing建立EditHistory、EditOperation、PreparedEdit、EditHistoryTarget和值类型；现有engine/editor/context中建立ActiveEditHistory、Registration及LuxObject EditHistoryController。两种不同测试业务使用同一核心；真实CommandRouter动作与安装消费者形成可验证链路。

core不包含ScenePatchOperation、SceneEditSession、TextReplaceOperation、MaterialGraphOperation；具体类型仅位于测试业务或日后对应业务。所有Editor语义不进入modules。

## 2. 入口核对

记录实际Engine HEAD、branch、status、worktree、依赖/安装来源和编译配置。本包只读HEAD为0ceedbcdbc75f3b2be4b6be8d0b0cbfc6e0b8db7，不是回退指令。后续新增Script/VTune工作保持不动，不重标旧资格。

读AGENTS和下级约束；核对当前editor/CMake、context、InspectorContext、GraphEditingSession/GraphDocument、CommandRouter。新文件若已存在先比对，不重复创建。旧v1路径、命名、场景类型进入core和按值execute所有权均已撤回。

只写必要状态映射和改动计划后直接实施。普通内部细节自行选择；具体前提矛盾按规范登记并完成无依赖工作，不能扩大到新架构。

## 3. 改动白名单

允许新增engine/editor/editing；修改现有editor_context中两类通用接入、相应CMake/meta/测试；editor根依赖顺序；现有测试和安装注册的必要接线；一个cmake/installed-consumers/editor-editing消费者；本轮记录。

禁止修改modules生产代码、Scene/Simulation/Script runtime与其生成模板；禁止完整Scene源模型/所有Inspector写入口/GraphDocument协议迁移；禁止新增材质或脚本编辑产品；禁止在仍用旧栈的真实EditorApplication上全局启用新Undo；禁止新插件注册/消息总线/Variant/codec/database。

旧业务在ED-1未迁移，不等于允许同一业务双记。新机制只在明确fixture/consumer中接入，结束时准确标记真实业务尚未统一。

## 4. 内部实施顺序

1. 建唯一editor_editing共享component、visibility、四个公开头和具体实现；依赖仅标准库与compile_time。
2. 先建立入场拒绝、失败所有权、分支/no-op和prepare失败测试，再实现历史流程。
3. 补StateId/Revision/event_sequence、SaveTicket、预算/裁剪、clear/close；提交后不再发生正常可失败工作。
4. 完成TextBufferFixture和RecordDocumentFixture的真实操作、plan和独立期望；业务代码不进入core编译单元。
5. 实现ActiveEditHistory/Registration生命周期、Controller；实际bindGlobal/state/invoke验证两target和失败信号。
6. 复用现有meta和安装流程，consumer自有两种业务，跨模块销毁正确，不读源码/私有头。
7. 实际跑矩阵、依赖检查、fresh-prefix/relocation/no-op及有限绝对成本，绑定最终代码身份。

## 5. 不能改变的关键接口与行为

execute(EditOperationPtr&)失败保留指针及memento；CHANGE成功移入历史，NO_CHANGE成功安全释放但不改历史。

prepare不改live模型和选择；apply不分配/通知/执行可失败Registry；publish在历史一致后。错误日志不是历史权威。

新操作校验初次base；Undo/Redo按条目方向回放，Revision不回退。失败/no-op不删redo；裁剪仅成功后最旧已应用前缀。

一个pending SaveTicket，确认的是票据state不是完成时current；clear不伪clean；close不因计数耗尽漏资源。

live token busy reset保留；回调内不销毁target；source/target或文档类型不改变核心。单核心实现发行ID，不能多DLL静态计数冲突。

## 6. 验证要求

完成ACCEPTANCE.csv中全部ED-1逻辑用例，不把用例数冒充CTest注册数。所有测试用RelWithDebInfo并真实启用assert，构建/测试/计时不并行。实际启用相应Editor层配置，不能只跑排除了新target的profile。

失败对拍包括model、selection、memento、entries/cursor、saved/current、revision/event和输入指针。不同准备失败独立命中；错误分支目标业务必须为零，随后合法重试成功。死亡测试仅按精确预期原因通过。

实际CommandRouter与LuxObject信号，不用仿制路由。core安装consumer无Scene/UI依赖；route测试可以使用真实context的既有依赖，范围分开。

headless通过不写成真实键盘、窗口焦点、IME、材质/场景统一历史通过。环境受阻记录具体项，禁止stub依赖冒充工程资格。

有限成本按主规范固定工作量；无等价旧core不编造加速率。不重复Script微基准全集，不单独开启每个小残余优化。

## 7. 最终交付与停止

交付实际代码/提交、target/include依赖、D01—D20映射、全部原始日志和身份、consumer/relocation、两业务trace、route关闭与资源回收、成本和限制。

分别报告共享机制、通用路由、安装与失败协议结果。明确：真实Inspector/Graph/Material/FlowForge未在本轮迁移；完整GUI未验证。

保护未知修改；不reset/clean/stash/rebase、升级依赖、合并main、强推、tag、发布或冻结。本包送达并授权后可按原目标分支普通提交/推送。ED-1完成后停止等待独立审阅，不进入ED-2。
