import hashlib,json,os,re,subprocess
from pathlib import Path
base=Path('E:/SyncForder/CodeRepos');build=base/'build/RelWithDebInfo/sr3-e/d';source=base/'lux-engine-sr3-event'
out=base/'build/RelWithDebInfo/sr4/diagnostics/lua-before';out.mkdir(exist_ok=False)
text=(source/'engine/domain/simulation/builtin/script/src/ScriptSystem.cpp').read_text()
hits={}
def replace(old,new,count=1):
    global text
    assert text.count(old)==count,(old,text.count(old));hits[old]=count;text=text.replace(old,new)
text='#include <cstdio>\n'+text
replace('        struct UserInvocationScope final','''        void trace(const char* phase, std::uint32_t a=0, std::uint32_t b=0) const noexcept {
            const auto time=clock->snapshot();
            std::printf("LUA_TRACE,%s,step=%llu,elapsed=%lld,a=%u,b=%u,step_calls=%llu,resumes=%llu,suspended=%llu,continuations=%zu,awaitables=%zu,next=%zu,delay=%zu,queue=%zu,frontier=%zu,head=%zu,tail=%zu\\n",
                phase,time.step_index,time.elapsed.count(),a,b,step_invocations,backend_resume_calls,suspensions_admitted,
                continuations.size(),awaitables.size(),next_step_waits.size(),simulation_delays.size(),resumes.count,
                external_admission_frontier,ingress->completions.dequeue_position,ingress->completions.enqueue_position.load());
            std::fflush(stdout);
        }
        struct UserInvocationScope final''')
replace('            owner->first_awaitable = id;','            owner->first_awaitable = id;\n            trace("awaitable", id.slot, id.generation);')
replace('            record.state = state;','            trace("terminal", record.id.slot, static_cast<std::uint32_t>(state));\n            record.state = state;')
replace('            next_step_last = *inserted;','            next_step_last = *inserted;\n            trace("next-register");')
replace('            if (simulation_delays.size() >= limits.simulation_delay_capacity)','''            std::printf("LUA_DELAY,step=%llu,duration=%.17g,ns=%lld,deadline=%lld,min_step=%llu\\n",
                current.step_index,duration,duration_count,current.elapsed.count()+duration_count,current.step_index+1U);
            std::fflush(stdout);
            if (simulation_delays.size() >= limits.simulation_delay_capacity)''',2)
replace('                const auto completed = lux::script::detail::ScriptAbilityOwnerCompletionAccess::success(','                trace("next-due");\n                const auto completed = lux::script::detail::ScriptAbilityOwnerCompletionAccess::success(')
replace('                auto completed = lux::script::detail::ScriptAbilityOwnerCompletionAccess::success(','                trace("delay-due");\n                auto completed = lux::script::detail::ScriptAbilityOwnerCompletionAccess::success(')
replace('            const auto continuation = *stored;','            trace("destroy", id.slot, id.generation);\n            const auto continuation = *stored;')
replace('                    return;\n                }\n                ScriptBackendContinuation continuation;','                    trace("hook-skip");\n                    return;\n                }\n                ScriptBackendContinuation continuation;')
replace('                    ++step_invocations;','                    trace("invoke");\n                    ++step_invocations;')
replace('                ++backend_resume_calls;','                trace("resume", resume.awaitable.slot, resume.awaitable.generation);\n                ++backend_resume_calls;')
replace('            const auto slot = instance->mount_slot;\n            const auto symbol = instance_owner.methodSymbol(continuation->method_slot);','            trace("resume-result", static_cast<std::uint32_t>(result.state), result.waiting_on.slot);\n            const auto slot = instance->mount_slot;\n            const auto symbol = instance_owner.methodSymbol(continuation->method_slot);')
replace('        state_->last_stable_step = step;','        state_->trace("stable");\n        state_->last_stable_step = step;')
replace('        state_->external_admission_prepared = true;','        state_->external_admission_prepared = true;\n        state_->trace("capture");')
(out/'ScriptSystem.cpp').write_text(text)
(out/'hits.json').write_text(json.dumps(hits,indent=2))
db=json.loads((build/'compile_commands.json').read_text());entry=next(e for e in db if e['file'].endswith('/builtin/script/src/ScriptSystem.cpp'))
old=entry['file'].replace('/','\\');assert entry['command'].count(old)==1
command=entry['command'].replace(old,str(out/'ScriptSystem.cpp'))+f' /Fo"{out}/ScriptSystem.obj" /Fd"{out}/compiler.pdb"'
with (out/'compile.log').open('w') as log:subprocess.run(command,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
raw=subprocess.check_output(['ninja','-C',str(build),'-t','commands','bin/lux_engine_simulation_script.dll'],text=True).splitlines()[-1]
link=raw.split(' -- ',1)[1].split(' && ',1)[0]
old=r'engine\domain\simulation\builtin\script\CMakeFiles\simulation_script.dir\src\ScriptSystem.cpp.obj';assert link.count(old)==1
link=link.replace(old,str(out/'ScriptSystem.obj'))
for option,path in [('out','lux_engine_simulation_script.dll'),('implib','lux_engine_simulation_script.lib'),('pdb','lux_engine_simulation_script.pdb')]:
    original=('lib' if option=='implib' else 'bin')+'\\'+path
    link=link.replace('/'+option+':'+original,'/'+option+':'+str(out/path))
with (out/'link.log').open('w') as log:subprocess.run(link,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
import shutil
exe=out/'scene_script_lua_runtime_test.exe';shutil.copy2(build/'bin'/exe.name,exe)
env=dict(os.environ);env['PATH']=str(base/'install/sr3-e/d/bin')+';D:/Development/vcpkg/installed/x64-windows/bin;'+env['PATH']
records=[]
for label,args in [('workers0',['--workers','0']),('interpreter',['--workers','0','--interpreter-only'])]:
    with (out/f'{label}.log').open('w') as log:
        result=subprocess.run([str(exe),*args],env=env,stdout=log,stderr=subprocess.STDOUT)
    assert result.returncode!=0
    data=(out/f'{label}.log').read_text();assert 'LUA_TRACE,resume' in data and 'activeContinuationCount() == 0U' in data
    records.append({'label':label,'args':args,'exit':result.returncode})
fixture=next(e for e in db if e['file'].endswith('/scene_script_lua_runtime_test.cpp'))
artifact=base/'build/RelWithDebInfo/sr3-e/t/engine/toolchain/lua/lua_portability_fixture.lxsa'
lua=source/'engine/toolchain/lua/test/lua_portability_fixture.lua'
(out/'identity.json').write_text(json.dumps({'E0':'8a6e6ef468f7eb60265678ab25116719b42a01a6',
    'artifact':str(artifact),'artifact_sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),
    'lua_source':str(lua),'lua_sha256':hashlib.sha256(lua.read_bytes()).hexdigest(),
    'fixture_compile':fixture,'probe_compile':command,'probe_link':link,'runs':records,
    'dll_sha256':hashlib.sha256((out/'lux_engine_simulation_script.dll').read_bytes()).hexdigest(),
    'exe_sha256':hashlib.sha256(exe.read_bytes()).hexdigest()},indent=2))
print((out/'workers0.log').read_text())
