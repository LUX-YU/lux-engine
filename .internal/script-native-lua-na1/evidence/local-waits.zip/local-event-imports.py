from pathlib import Path
s=Path(r'E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1/source')
p=s/'engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptInstances.hpp'
t=p.read_text();a=t.index('    struct ScriptEventSourceAccess final');b=t.index('    class ScriptInstances final',a)
t=t[:a]+'''    class ScriptEventImports final
    {
    public:
        // Immutable incarnation borrow, protected by the same owner region as
        // prepared methods. Permission is checked by Execution before resolve.
        [[nodiscard]] const PreparedScriptEventAdmission* resolve(
            ScriptInstanceId instance, ScriptEventAdmissionHandle handle) const noexcept
        {
            const auto local = ScriptRuntimeAccess::matchAdmission(handle, scope_, instance, epoch_, sources_.size());
            return local ? &sources_[*local] : nullptr;
        }
        [[nodiscard]] ecs::Entity target() const noexcept { return target_; }
    private:
        friend class ScriptInstances;
        ScriptEventAdmissionScope scope_;
        std::uint64_t epoch_{};
        std::span<const PreparedScriptEventAdmission> sources_;
        ecs::Entity target_{ecs::NullEntity};
    };

'''+t[b:]
a=t.index('        [[nodiscard]] lux::cxx::expected<ScriptEventSourceAccess');b=t.index('        [[nodiscard]] LifecycleResult beginPlay',a)
t=t[:a]+'''        [[nodiscard]] ScriptEventImports eventImports(std::uint32_t mount_slot) const noexcept;

'''+t[b:]
a=t.index('    inline lux::cxx::expected<ScriptEventSourceAccess');b=t.index('\n\n}',a)
t=t[:a]+'''    inline ScriptEventImports ScriptInstances::eventImports(std::uint32_t mount_slot) const noexcept
    {
        const auto& mount = mounts_[mount_slot];
        ScriptEventImports result;
        result.scope_ = event_scope_;
        result.epoch_ = mount.event_layout_epoch;
        result.sources_ = mount.event_sources;
        if (const auto* entity = std::get_if<EntityScriptScope>(&mount.scope)) result.target_ = entity->self;
        return result;
    }'''+t[b:]
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptExecution.hpp'
t=p.read_text().replace('            ScriptInstances::AuthorityAccess authority;', '            ScriptInstances::AuthorityAccess authority;\n            ScriptEventImports events;')
a=t.index('            const auto source = instance_owner_.eventSource');b=t.index('            auto reservation =',a)
t=t[:a]+'''            if (!ExecutionAccess{owner, instance}.current())
                return lux::cxx::unexpected(EScriptEventWaitError::INVALID_INSTANCE);
            const auto* source = owner->events.resolve(instance, admission);
            if (source == nullptr) return lux::cxx::unexpected(EScriptEventWaitError::UNDECLARED_SOURCE);
            const auto endpoint_slot = source->endpoint_slot;
            const auto target = source->entity_targeted ? owner->events.target() : ecs::NullEntity;
            if (source->entity_targeted && target == ecs::NullEntity)
                return lux::cxx::unexpected(EScriptEventWaitError::SCOPE_MISMATCH);
'''+t[b:]
t=t.replace('source->source->payload', 'source->payload')
t=t.replace('execution_instances_[instance.slot - 1U].authority = instance_owner_.authorityAccess(instance, slot);', 'execution_instances_[instance.slot - 1U].authority = instance_owner_.authorityAccess(instance, slot);\n            execution_instances_[instance.slot - 1U].events = instance_owner_.eventImports(slot);')
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/scripting/core/include/lux/engine/simulation/scripting/ScriptRuntime.hpp'
t=p.read_text().replace('        std::uint32_t endpoint_slot{};\n        PreparedResumeType payload;', '        std::uint32_t endpoint_slot{};\n        bool entity_targeted{};\n        PreparedResumeType payload;')
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/builtin/script/src/ScriptPreparer.cpp'
t=p.read_text().replace('            construction.addEvent({&requirement, {}, *endpoint_slot, payload});', '''            const bool targeted = requirement.route == lux::script::EScriptEventRoute::ENTITY_TARGETED;
            construction.addEvent({&requirement, {}, *endpoint_slot, targeted, payload});''')
p.write_text(t,encoding='utf-8')
for sub in ['cpp_static/test/cpp_static_script_bridge_test.cpp','lua/test/lua_prepared_storage_test.cpp','lua/test/lua_closure_provenance_test.cpp']:
 p=s/'engine/domain/simulation/scripting'/sub
 t=p.read_text().replace('{&event_source, {}, {}, {}}', '{&event_source, {}, {}, false, {}}').replace('{&event, {}, {}, {}}', '{&event, {}, {}, false, {}}').replace('{&sources[index], {}, {}, {}}', '{&sources[index], {}, {}, false, {}}')
 p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/builtin/script/src/ScriptSystem.cpp'
t=p.read_text().replace('limits.awaitable_capacity == 0U ||', 'limits.awaitable_capacity == 0U ||\n                                    limits.awaitable_capacity > std::numeric_limits<std::uint32_t>::max() ||\n                                    limits.event_wait_capacity > std::numeric_limits<std::uint32_t>::max() ||')
p.write_text(t,encoding='utf-8')
