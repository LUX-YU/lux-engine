from pathlib import Path
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/lua55-v2');dev=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source')
s=(dev/'cmake/RunScriptV3Consumers.ps1').read_text()
a='''    if (Test-Path -LiteralPath $root) { throw "Fresh root required: $root" }
    New-Item -ItemType Directory -Path $root | Out-Null
    Copy-Item -LiteralPath "$SourceDir/cmake/installed-consumers/$name" -Destination "$root/source" -Recurse'''
b='''    if (!(Test-Path -LiteralPath "$root/source")) { throw "Missing controlled consumer: $root" }
    foreach ($file in (Get-ChildItem -LiteralPath "$SourceDir/cmake/installed-consumers/$name" -Recurse -File)) {
        $relative = [IO.Path]::GetRelativePath("$SourceDir/cmake/installed-consumers/$name", $file.FullName)
        if ((Get-FileHash -LiteralPath $file.FullName).Hash -ne
            (Get-FileHash -LiteralPath "$root/source/$relative").Hash) { throw "Changed consumer $name/$relative" }
    }'''
assert s.count(a)==1;s=s.replace(a,b)
for name in ['configure.log','build.log','run.log','reload.log','second-build.log','consumers.json']:
 s=s.replace('/'+name,'/closure-'+name)
(r/'consumers-closure.ps1').write_text(s)
s=(r/'installed-final.ps1').read_text().replace('& "$source/cmake/RunScriptV3Consumers.ps1"','& "$r/consumers-closure.ps1"').replace('/consumers.json','/closure-consumers.json')
s=s[:s.index('& "$source/cmake/RunScriptSR5ValueIncremental.ps1"')]+'''Write-Output 'CLOSURE_CURRENT_SDK_15_PASS'
& "$r/relocated.ps1" -Root $r
if($LASTEXITCODE) { throw 'Relocation failed' }
'''
(r/'installed-closure.ps1').write_text(s)
p=r/'final-costs.py';s=p.read_text().replace("r/'final-d-build.json'","r/'closure-d-build.json'");p.write_text(s)
