from pathlib import Path
import json,subprocess,csv
r=Path(__file__).parent;s=r/'source';docs=s/'.internal/script-native-lua-na1'
def load(p):return json.loads((r/p).read_text(encoding='utf-8-sig'))
source=subprocess.check_output(['git','-C',str(r/'local-source'),'rev-parse','HEAD'],text=True).strip()
summary=load('local-costs/summary.json');runs=load('local-costs/runs.json');assert len(runs)==54 and all(x['valid'] for x in runs)
consumers=load('local-installed/consumers.json');assert len(consumers)==16 and all(x['status']=='PASS' for x in consumers)
inc=load('local-value-incremental/probes.json');newinc=load('local-new-incremental/results.json');reloc=load('local-relocated/results.json')
assert len(inc)==13 and len(newinc)==5 and len(reloc)==3 and all(x['status']=='PASS' for x in reloc)
for slot in ['t','d']:assert load(f'local-final-{slot}-tests2.json')['exit']==0
phases=load('local-analysis/phases.json');profiles=load('local-analysis/profiles.json')
limitations=[
 'Lua scalar: all three pairs slower, median +0.703232%; absolute paired deltas 0.597625/1.412565/0.815635 ns per call. No causal ablation; not noise or necessary safety cost by assertion.',
 'One software VTune pair; no PMU cache-miss/branch-misprediction proof. Inclusive parent times are not additive.',
 'Large payload shared backing not selected: actual P4 payload is 4 B; custom copy may reenter, and channel storage does not cover multi-step READY backlog.',
 'Resume FIFO remains, with 8 B wait IDs. No new scheduler, no full source-batch scheduler, no per-task Lua thread pooling.',
 'Native generated coroutine frames increased: P4 224 -> 352 B, Next 288 -> 304 B, sequence 416 -> 432 B, pose 304 -> 320 B. Fixed 512 B frame limit and worst-case backing retained.',
 'Memory snapshots at phase boundaries, not exhaustive transient peaks. Process heap walk is complete at snapshots; not every internal map bucket has a separate requested-byte counter.',
 'Toolchain first post-build pass reran six FlowForge tablegen commands; subsequent explain and no-op checks idle. Developer first post-build pass idle. No production CMake changes in this turn.',
 'Repeated VS environment initialization printed a command-line-length warning in the chained driver; actual configure/compiler/build/test exits and identities validated. No warning was treated as a successful test.',
 'Per-batch errors, per-wait scheduling latency and allocation counts during formal timing are unmeasured null, despite raw disabled VM counters being printed as zero.',
 'Only Windows/MSVC RelWithDebInfo and current Lua55; no old VM, Android, other compiler or hardware qualification. Historical V4/scalar/record debts remain; no arithmetic chaining of historical ratios.'
]
result={
 'qualification_source':source,'baseline_source':'7f20191692d3f5e1037a14273a61fc99eef95714','working_start':'d63767c29315c2d78e5cfc904c0ce4c2a80875ba',
 'branch':'codex/s6-native-task-lua-steps','implementation':'COMPLETE_FOR_SELECTED_LOCAL_WAIT_AND_STEP_CHANGES','contract':'PASS_TESTED_SCOPE',
 'cost':'MEASURED_GAIN_WITH_UNEXPLAINED_SCALAR_RESIDUAL','adoption':'NOT_APPROVED_PENDING_REVIEW',
 'incompatibilities':['No registration-order guarantee among tasks claimed by the same event occurrence; distinct occurrence and nested dispatch behavior preserved.','Public C++ ScriptSyncStepSetView and event admission/projection structures changed; recompile consumers and do not mix old SDK/DLL.','Removed EScriptEventWaitError::SEQUENCE_EXHAUSTED; numeric 9 unused, remaining numeric values preserved. Native C ABI remains 6.'],
 'implementation_components':['Execution-owned fixed wait bank with embedded Event relation; no Event waiter SlotMap','Event-owned bounded dense pointer pages and cancellation swap, no Event instance directory','8-byte ready wait IDs, single existing FIFO/budget/frontier','Prepared Event imports borrowed directly by Execution and CppStatic','Reusable typed synchronous step binding and direct InvocationState authority','Non-reentrant builtin scalar Event copy outside pin/protection success path; custom/failure paths preserved'],
 'qualification':{'toolchain_tests':{'passed':110,'total':110},'developer_tests':{'passed':127,'total':127},'vm_contracts':load('local-vm-tests.json'),'consumers':consumers,'value_incremental':inc,'native_incremental':newinc,'relocated':reloc,'scale':load('local-scale/runs.json')},
 'performance_summary':summary,'performance_runs':runs,'software_profiles':profiles,'exclusive_profile_phases':phases,
 'sizes':load('local-analysis/sizes.json'),'frames':load('local-analysis/frames.json'),'resources':load('local-analysis/resources.json'),
 'host':load('local-host.json'),'fixed':{'lua':'5.5.1 + existing VM patch','gc':'INC upstream default','empty_page_budget_bytes':16777216,'lux_cxx':'3100f54d0743c5ed94a4ccf5943df04e933de255','toolset':'99c3d0480d1db816779b1dfa7f3c06cb7d39a94f','native_abi':6,'build_type':'RelWithDebInfo','affinity_mask':16},
 'limitations':limitations,'evidence':'evidence/local-waits.zip'}
(r/'local-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');(docs/'local-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
names={'P1':'单 Event 完整任务','P2':'NextStep 完整任务','P3':'三等待任务','P4':'同任务 32 次 Event','P5':'ValuePose 跨等待','S1':'Lua scalar','S2':'C++ Sequence','S3':'FlowForge Event','P6':'混合 Physics'}
lines=[]
for row in summary:
 scale=1e6 if row['leg'] in ['S2','P6'] else 1000;unit='ms/原帧' if scale==1e6 else 'μs/调用或任务'
 lines.append(f"| {row['leg']} {names[row['leg']]} | {row['A_ns']/scale:.6f} | {row['B_ns']/scale:.6f} | {row['median_percent']:+.2f}% | {' / '.join(f'{v:+.2f}%' for v in row['deltas_percent'])} | {unit} |")
phase_names={'next_wait_registration':'下一次等待登记','event_delivery':'事件交付','take_previous_result':'取回上次结果及准备恢复','synchronous_lua_step':'同步 Lua 步骤（含外围）','remaining_resume':'其余恢复处理','other':'其他'}
phase_rows=[]
for k,label in phase_names.items():
 a=phases[0]['groups'][k];b=phases[1]['groups'][k];phase_rows.append(f"| {label} | {a['seconds']:.4f} | {b['seconds']:.4f} | {b['percent']:.2f}% |")
report=f'''# 本地等待与同步步骤优化：实际交付

已完成选定结构改动及本轮验证。长任务明显提速，Lua scalar 留有小幅未解释回退；采用仍为 `NOT_APPROVED_PENDING_REVIEW`。
不合并 V4/main，不扩大语言、VM、调度或资产功能。

## 身份与具体变化

参照 A：`7f20191692d3f5e1037a14273a61fc99eef95714`，原 D/D-common/D-flow 镜像。
工作起点 `d63767c2` 只比该参照多报告。候选 B 和独立 clean clone 资格：`{source}`，E/E-common/E-flow 镜像。
后续文档提交不改变资格源码。固定依赖、Lua55/patch/INC/16 MiB、Native ABI6、编译参数不变，原 Lua 业务资产 SHA 完全相同。

[实施合同和各子提交](LOCAL-WAIT-CHANGES.zh-CN.md)保留全部失败尝试说明。实际删掉的工作：

1. EventWaiterRecord 及其 SlotMap、EventWaits 的实例目录和实例链被删除。Event 关系嵌入 Execution 唯一拥有的结果记录。
2. 等待物理记录准备时一次建立，热路径归还逻辑槽并更新代次，不反复构造/析构整个记录。实例等待链直接链接稳定记录。
3. 每事件使用稠密指针页，页内取消用末项补洞；任务结果不搬动。取消和 claim 后的旧快照仍以等待代次拒绝重用槽。
4. 恢复队列仅存 8 B 等待编号，原来是 24 B；从已定位结果读取任务和实例，不再携带重复关联。仍有一个中央 FIFO，保留旧预算/frontier。
5. Event 的固定 import/scope 关联提前准备；CppStatic 不再每次等待回查 backend instance。长任务一次绑定 Lua 同步步骤，循环内不重复解析下标/签名。
6. 调用资格直接读取 Instances 的热 InvocationState。默认 scalar Event copy 的成功路径不再建立写 pin 和嵌套保护；自定义复制、实际错误和队列满的清理保护保留。

同一个 occurrence 唤醒的兄弟任务不再承诺登记顺序；不同 occurrence、claim→callback→complete 和原合法嵌套顺序保持。
每个 ScriptSystem 独占其本地数据，没有新增 Scene 脚本入口。内部本来非原子的路径没有虚构“删原子”收益；真实外部运输仍同步。
保留完整等待代次、逻辑容量/写 pin 延迟归还、当前权限、生命周期和同步失败归属。这里仍有每任务 continuation，未引入 A1 cell 或第二结果池。

## 完整业务成本

九腿各三对 AB/BA/AB，54 个有效独立进程；没有丢弃慢组或无效计时后挑样。i7-13700KF、MSVC 19.44、affinity 16。
工作量沿用原驱动：P1/P2 为 2000 万任务，P3 为 250 万任务/750 万等待，P4 为 64 万任务/2048 万等待，P5 为 100 万任务；
S1 2000 万调用、S2/S3 1000 原帧、P6 2000 原帧。原预热、seed、worker、恢复预算及正常 GC 保持。
下表 A/B 是每次实际操作成本中位数，变化是配对比值中位数，两列中位数不能直接相除替代配对。

| 场景 | A | B | 配对中位变化 | 三对变化 | 单位 |
|---|---:|---:|---:|---|---|
{chr(10).join(lines)}

P4 从 8.528447→5.848663 μs/完整 32 等待任务；按实际等待数摊销约 266.51→182.77 ns/等待，包含该等待相关业务与 Lua 步骤，不能称作纯 resume 开销。
三进程的批次 p99 中位 91.638→64.413 ms（每批 10000 个完整任务）。所有收集到的整进程调用错误和最终 backlog 为零，完整逐实例 oracle/每行计数匹配。

**Lua scalar 未收口**：三对 +0.51%/+1.22%/+0.70%，配对绝对差约 0.60/1.41/0.82 ns/调用。
没有因果消融，不能归为噪声或必要安全成本；不以其他场景收益抵消。历史债务仍保留，不把旧比例连乘成 V4→本候选结果。
逐批错误、独立恢复延迟、正式计时期间分配没有采集，机器可读结果保留 null；原驱动 accounting=0 打印的零不代表测得零分配。

## VTune：省掉的实际成本

独立 software Hotspots 一对，ITT 限定 P4 完整任务波，准备/预热/关闭在 ROI 外；两侧业务、线程和预算相同。
A/B ROI wall 5.755714/3.653007 秒，CPU 5.532247/3.572489 秒。采样不是正式计时，不把两组数字混合。
按真实调用树的祖先路径对 **self 时间互斥分组**，避免把父子包含时间重复相加：

| 工作 | A CPU 秒 | B CPU 秒 | B 占比 |
|---|---:|---:|---:|
{chr(10).join(phase_rows)}

主要改善来自合并登记、移除第二套事件记录及其 unlink、提前绑定步骤和更短的结果交接。
同步 Lua 步骤在候选仍占约 27%，但绝对时间已经下降，不能只看百分比判断“没改善”。
当前较大的 self 样本包括 waitEvent、Lua 的 `luaH_Hgetshortstr`、resumeOne、资格捕获和结果赋值。
Lua 字符串查表包含原脚本 `self` 表的实际访问；未冻结表、改脚本为 local 捕获或隐藏 Lua 功能。
软件采样有内联归属和周期取样偏差，没有 PMU，不声称已证明 cache miss 或分支误预测根因。

已导出匹配 DLL/PDB/EXE、完整调用树、目标对象反汇编和 MSVC class layout。长任务走 `invokeResolvedSyncStep`；
动态下标入口仍有 resolve 调用，只有一次实际调用的任务也保留检查。没有全局 forceinline 或单侧 IPO/LTO。

## 资源与布局的代价

- 结果记录 192→240 B，包含原先独立的 Event 关系；旧 EventWaiterRecord 88 B 被删除，新嵌入 link 32 B **不能再加算一次**。
- ExecutionInstance 64→104 B，换来直接 import/实例访问；原 EventWaits 实例目录删除。SyncStepSetView 56→64 B。
- N 个事件等待预留 N 个 48 B 页，保证每个等待在不同路由时也能接纳；常见 N/4 页使用量不是最坏预留量。
  10000 等待的候选页池 480000 B、claim 编号 80000 B、ready 编号 80000 B；结果 bank 2400000 B。
- 10000 实例 P4：mount 5600000→5520000 B；组合 backend 11121296→11201296 B；native frame backing 两侧均 5760000 B，metadata 均 480352 B。
  旧 StableSlotMap 结果 backing 2334160 B，新固定 bank 2400000 B；所以不能只比较结果 record 或只计算被删除的 Event record。
- 实际生成 frame：Event 224→224 B、NextStep 288→304 B、三等待 416→432 B、长任务 224→352 B、Pose 304→320 B。
  原 512 B 上限和最坏情况保证未缩减；长任务 frame 增大是明确代价，不宣称“绑定引用必然更省空间”。
- P4 10000 实例结束快照：进程 private commit 105521152→105103360 B，heap busy 100508660→100126667 B，working set 108032000→107765760 B。
  1000 实例 private commit 12341248→12320768 B，但 working set 19095552→19103744 B 略增。
  这些是一次独立诊断的阶段快照，不是可推广的 RSS 节省保证。
- Lua 活动页、live bytes、rounding、heap allocation/free 次数两侧相同。正式任务 Lua thread/resume/root 仍为零，关闭后 companion leases 为零。
  closed 快照在 backend/VM 对象最终析构前；VM 保留内存不能误报为新泄漏。

全进程 heap walk 在快照点完成，覆盖未单列的目录/容器分配；每个 map bucket 的 requested bytes 及瞬时活动 frame 峰值没有独立计数，不能称为完整逐对象瞬时内存证明。
大 payload 共享本轮不采用：主路径只有 4 B，逐等待自定义复制可能重入/有副作用，channel 双缓冲又不覆盖跨 step backlog 的寿命。没有制造新大对象负载刷收益。

## 真实验证及边界

- 同一干净提交、独立 local-source：Toolchain all + 110/110；Developer all + 127/127；仅 RelWithDebInfo，`-j 4 -- -k 0`，构建与测试串行。
- Developer 首次复建无工作。Toolchain 首次复建触发六项 FlowForge tablegen，随后 explain 和复建均无工作；首轮日志保留，不写成严格第二轮空闲。
  本轮未修改生产 CMake。重复 VS 初始化出现命令行长度警告，实际配置、编译命令、执行退出码和产物身份均核对，未把初始化警告本身当验证通过。
- 4/4 原 Lua55 VM 合同重跑，实际 VM DLL hash 与固定安装相同；VM 代码未改。
- 16/16 安装消费者、13 类值转换增量、5 类步骤/任务/路由负例、3/3 迁址链通过。原源码/构建/SDK 在迁址执行时不可用，结束恢复。
- 8/8192 配置规模：16 次预热、128 次单实例重建；两种规模候选均触及 128 个配置槽、0 次 endpoint 总表计数，错误/backlog=0，create/destroy/BeginPlay/EndPlay 精确匹配。
  规模只作一对复核加独立诊断，不当作新的多对性能结论。
- 新增真实用例：claimed 期间取消并重用槽、容量 1 连续 64 次等待、稠密页中间删除与补满；原 copy 重入、容量/队列满、错误清理、权限/生命周期、frontier/stale pop、Event 多飞及10k/50k/100k等待测试保留。

公开 C++ 输入结构及 view 构造方式变化，需要整体重编消费者；Native C ABI6 和脚本值/序列化格式保持。
删除无用途的 `SEQUENCE_EXHAUSTED` 枚举项（9 留空），其他错误数值保持。没有 public skip-validation 参数或跨用户代码缓存 ACTIVE。
未验证 Android、其他编译器/CPU；没有恢复 Lua54/JIT。仅本分支交付，等待独立审阅。

[全部机读结果](local-result.json) · [实施记录](LOCAL-WAIT-CHANGES.zh-CN.md) · [原始证据入口](EVIDENCE.zh-CN.md)。
'''
(docs/'LOCAL-WAIT-RESULT.zh-CN.md').write_text(report)
p=docs/'LOCAL-WAIT-CHANGES.zh-CN.md';text=p.read_text();text=text.replace('状态：实施中。下列合同是本轮输入，尚未执行的检查不代表通过。','状态：选定实现及验证完成，等待审阅。最终结果见 [交付报告](LOCAL-WAIT-RESULT.zh-CN.md)；以下按阶段保留原始记录，后文的“尚未”描述当时状态。');text+='\n## 最终资格\n\n固定 `841320a3`：Toolchain 110/110、Developer 127/127、16 consumers、13+5 增量、3 迁址、4 VM 合同通过。\n完整成本、布局代价、scalar 残余及首轮无工作检查限制统一见 [最终报告](LOCAL-WAIT-RESULT.zh-CN.md)。\n';p.write_text(text)
failures={'formal_invalid_timing_runs':[],'intermediate_failures':[
 {'stage':'local-bindings','result':'86/88','cause':'Invalid ACTIVE-publication requirement at construction; corrected without relaxing business assertions'},
 {'stage':'local-bindings-fixed','result':'build style failure','cause':'Two new lines longer than repository limit; fixed'},
 {'stage':'local-bound-step','result':'66/88','cause':'21 Clang generator alias-template CTAD errors and one wrong rejection of a legal epoch-zero producer; fixed with explicit expected error type and correct publication contract'},
 {'stage':'local-final-t-noop','result':'exit 0 but not idle','cause':'Six FlowForge tablegen steps reran; later no-op checks idle'},
 {'stage':'local-phases','result':'analysis parser failure only','cause':'VTune indented quoted CSV needs whitespace-aware parsing while preserving raw indent; corrected and exclusive self-time sum checked against summary CPU; no samples discarded'},
 {'stage':'local-final-setup','result':'driver setup stopped at missing next-profile-target.py','cause':'Reused existing profile-target.py; final source and scripts subsequently checked'},
 ],'limited_checks':[{'stage':'local-wait-bank','matched_tests':2,'superseded_by':'local-wait-bank-regression 88/88'}], 'runtime_failures_in_final_qualification':0}
(r/'local-failed-attempts.json').write_text(json.dumps(failures,indent=2));print('REPORT_AND_RESULT_WRITTEN',source)
