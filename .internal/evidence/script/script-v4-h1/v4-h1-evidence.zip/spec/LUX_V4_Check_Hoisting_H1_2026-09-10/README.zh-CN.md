# V4-H1 实施包

本包为待执行方案，不含候选生产代码或新性能结果。

主规格：`IMPLEMENTATION.zh-CN.md`。给LLM的首条消息：`AGENT_START_PROMPT.zh-CN.md`。
`CHECK_AUDIT.csv`列出本轮检查候选及证明要求；`TEST_MATRIX.csv`是待执行回归映射。
`WORK_ORDER.json`规定顺序和默认范围；`RESULT_TEMPLATE.zh-CN.md`规定真实交付格式。
`SOURCES.json`把既有源码事实、用户报告与外部官方API来源分开。

目标不是清空所有runtime if，而是：

装配建立静态合同 → 实际边界验证当前输入/权限 → 私有热内核不重复已经有效的证明。

V4基线：f7d2815b；V4报告入口：f92853ea8；A1仅保留为失败实验。
完整规格中H1/H2/H3是实际代码任务；H4是必须完成的Lua审查，但不强迫无依据的Lua修改。
不包含Native P/Q目录大重构、GC调参、VMpatch、/Ob2试验或新cell架构。

使用SHA256SUMS.json校验包中文件；它本身不递归纳入自身哈希。
