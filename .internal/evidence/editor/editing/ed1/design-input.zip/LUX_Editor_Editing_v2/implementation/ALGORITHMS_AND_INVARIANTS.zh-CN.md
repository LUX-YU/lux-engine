# 算法与边界精化

本文件解释主规范，没有新架构或额外阶段授权。

## 1. 操作费用与裁剪公式

Entry={独占operation,before,after,cached_label,charged}。charged为operation固定上界加其标题缓存容量等逐entry拥有存储；预留Entry数组另记metadata，不漏也不双计为精确物理内存。

设原n条、cursor=k、新charge=c。先预检c自身不超限，再仅对将保留的[0,k)+new选择最少p，使k-p+1<=max_entries且sum(charges[p:k])+c<=max_retained_bytes。准备阶段不改任何旧条目。

成功后保留[p,k)追加new；[0,p)与[k,n)移到预留回收槽。saved即使引用被裁去状态也继续保存。新基点是剩余首项before；全部旧前缀裁掉时是new.before。不会恢复被裁去的操作。

## 2. 标题与容器移动

必须在Entry最终压紧结束后才取得CommitInfo.label。std::string的SSO可能因Entry移动换地址；不能拿准备阶段的string_view继续publish。

所有待丢operation先move到回收区，再压紧空槽。不能让move-assignment覆盖尚未移出的旧operation并提前执行其析构。回收顺序按原index从高到低，不参与模型恢复。

## 3. 常规错误分类

| 条件 | 返回 |
|---|---|
| limit为0、工厂槽位/元数据计算无法表示 | INVALID_LIMITS |
| factory/prepare实际分配失败 | ALLOCATION_FAILURE |
| 标题空、内嵌NUL、空operation、entry越界 | INVALID_ARGUMENT |
| 标题超过max_label_bytes、单条或最终保留费用不合限 | HISTORY_LIMIT |
| prepare预算reserve不足或求和溢出 | STAGING_LIMIT |
| history身份不匹配 | WRONG_HISTORY |
| 初次operation.baseState不等于current | STALE_BASE |
| 内容范围/关系等领域前置条件不符 | PRECONDITION_FAILED，domain_code说明业务原因 |
| plan为空、存量undo/redo错误返回NO_CHANGE | CONTRACT_VIOLATION |
| state/revision/request或非终态event将溢出 | ID_EXHAUSTED |
| 无undo/redo或无active | NO_UNDO / NO_REDO / NO_ACTIVE_TARGET |

wrongthread/closed/busy优先于普通参数错误；已关闭view例外仍可读最终标量。label过长不静默截断；Error message可以有限截断并标志。

makeEditFailure不分配，message零初始化，最多复制191字节并终止NUL；输入内嵌NUL视为文字结束，存在被丢后缀或超长则message_truncated=true。它是有限诊断字节串，不建立完整本地化/Unicode库。成功路径不应构造不需要的长错误字符串。

HistoryObserver若changed=null则context也必须null；changed非空时允许context=null用于静态接收者。没有observer也必须完成全部内容和历史语义。

## 4. 失败所有权与业务门

核心自己的准备分配捕获到Result；业务prepare须自己遵守noexcept，将正常分配错误转Result。已经违反noexcept的业务不能靠外层catch恢复，不能承诺任意插件异常安全。

输入unique_ptr在整个同步execute期间被独占借用，调用方或回调不得并行修改该变量。错误返回保留其地址和memento；NO_CHANGE成功会在门内销毁。

业务prepare不得间接走另一入口修改同一模型。业务会话须将select/gesture/reload/close和所有写入口纳入同一文档门。core不能拦截绕过会话的裸Registry写入。fixture同样必须测试此点。

## 5. 通知与生命周期

内容execute/undo/redo各business publish一次、HistoryNotice一次；save/clear/close仅metadata notice，不调用业务publish。失败/no-op不发普通变化通知。

显式close时observer必须还存活；析构不通知。发布失败的渲染/编译后续任务不回滚已提交历史。queued listener自己拥有notice值，带版本重取权威模型，不持EntryView。

PreparedEdit旧数据析构、被裁剪条目析构都在RECLAIMING；再次写同history拒绝。其源模型与操作代码必须存活到这些清理返回。不能先销毁business model再让history的operation析构访问它。

## 6. 路由与状态对齐

每个注册target有固定HistoryId，register时检查其可查询、未关闭且身份有效。同一History不能重复注册为不同pane history。HistoryTargetView.history.history与注册身份必须一致，不一致视CONTRACT_VIOLATION且不执行业务。

ActiveEditHistory调用target虚方法期间禁止变更本route；view的借用标题遇target mutation、注销/销毁或route mutation失效。Controller在入口记录handle，failed不能误标成后来另一个active。

目标EMPTY对应NO_UNDO/NO_REDO；BUSY对应BUSY；BLOCKED对应BLOCKED_BY_HOST；CLOSED对应CLOSED。READY只是查询，真正target.undo/redo仍验证。当期间无修改且target返回成功，其结果必须对应原HistoryId，不允许跨目标回放。

应用把当前文本输入消费与文档动作分开。ED-1 headless测试不伪装实际IME/键盘资格；没有新增输入系统授权。

## 7. 现有业务接口不足不是core后门的理由

GraphEditingSession当前的undo/redo和GraphDocument的可失败attach/action不能直接放进PreparedEdit.apply。后续业务要证明staging与commit，或单独提出实际协议冲突。ED-1不修改这套存量，也不删除原原子inverse测试。

不能把dependent子操作全部对旧model prepare再顺序apply；业务组内必须有一致暂存视图。也不能把新history包裹旧history来隐藏迁移未完成。

## 8. 基准无比较来源时的口径

测试两fixture绝对成本即可。模型完整复制仅为小fixture证明，计费与耗时需包含它，不能称core高效或未来Scene同等复杂度。记录所有有效样本；无测试产物或错误工作量不进入性能平均。

## 9. 动作失败与UI未分派不是同一事件

CommandRouter可以在invoke时再次检查enabled并直接拒绝。此时目标业务为零，但Controller没有执行，不能要求它发failed或为了满足测试删除Router校验。另一个独立场景直接进入Controller、在业务prepare中失败，才验证owned failed通知与原handle。

Controller先用activeTarget取得handle值，该查询不调用业务virtual，也不取得可写target。错误线程下Route返回WRONG_THREAD；Controller本身是UI owner-only LuxObject入口，不承诺跨线程发signal。

成功target结果须匹配原HistoryId：CONTENT_APPLIED对应CHANGE；TRANSIENT_CANCELLED对应NO_CHANGE并保持内容state/revision。无历史且无预览返回NO_UNDO/NO_REDO，不返回第三种模糊成功。
