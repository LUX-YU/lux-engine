from pathlib import Path
import csv,ctypes as ct,hashlib,json,os,re,shutil,subprocess,time
r=Path(__file__).parent;out=r/'resource-diagnostic';out.mkdir(exist_ok=False)
image=r/'observation-image';image.mkdir(exist_ok=False);build=r.parent/'o/w/d'
standard=json.loads((r/'final-image/identity.json').read_text());images={}
for name,entry in standard['images'].items():
 p=Path(entry['origin']);target=image/p.name;shutil.copy2(p,target)
 pdb=p.with_suffix('.pdb')
 if pdb.exists():shutil.copy2(pdb,image/pdb.name)
 images[p.name]={'origin':str(p),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
for name in standard['fixtures']:shutil.copy2(r/'final-image'/name,image/name)
(image/'identity.json').write_text(json.dumps(dict(source=standard['source'],hotpath_observation=True,images=images,fixtures=standard['fixtures']),indent=2))
k=ct.WinDLL('kernel32');k.GetCurrentProcess.restype=ct.c_void_p;k.SetProcessAffinityMask.argtypes=[ct.c_void_p,ct.c_size_t]
assert k.SetProcessAffinityMask(k.GetCurrentProcess(),16)
class Memory(ct.Structure):
 _fields_=[('cb',ct.c_ulong),('PageFaultCount',ct.c_ulong),('PeakWorkingSetSize',ct.c_size_t),('WorkingSetSize',ct.c_size_t),('QuotaPeakPagedPoolUsage',ct.c_size_t),('QuotaPagedPoolUsage',ct.c_size_t),('QuotaPeakNonPagedPoolUsage',ct.c_size_t),('QuotaNonPagedPoolUsage',ct.c_size_t),('PagefileUsage',ct.c_size_t),('PeakPagefileUsage',ct.c_size_t)]
psapi=ct.WinDLL('psapi');psapi.GetProcessMemoryInfo.argtypes=[ct.c_void_p,ct.POINTER(Memory),ct.c_ulong]
results=[]
for scene in ['event','cpp-sequence']:
 for side,folder in [('A',r.parent/'script-v4/final-image'),('B',image)]:
  name=scene+'-'+side;log=out/(name+'.log');data=out/(name+'.csv')
  cmd=[str(folder/'script_runtime_benchmark.exe'),'--group','scene-lua-event' if scene=='event' else 'scene-cpp-sequence',
   '--mode','performance','--size','1000','--frames','128','--warmups','16','--seed','1592598566','--resume-budget','1000','--output',str(data)]
  if scene=='event':cmd+=['--vm-accounting','on','--lua-artifact',str(folder/'lua_runtime_benchmark_fixture.lxsa')]
  env=dict(os.environ);env['PATH']=';'.join([str(folder),'D:/Development/vcpkg/installed/x64-windows/bin',
   *[p for p in env['PATH'].split(';') if 'CodeRepos' not in p and 'vcpkg' not in p]])
  peak_ws=peak_private=samples=0
  with log.open('wb') as f:
   process=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
   while process.poll() is None:
    info=Memory();info.cb=ct.sizeof(info)
    if psapi.GetProcessMemoryInfo(int(process._handle),ct.byref(info),info.cb):
     peak_ws=max(peak_ws,info.PeakWorkingSetSize);peak_private=max(peak_private,info.PeakPagefileUsage);samples+=1
    time.sleep(.005)
   code=process.wait()
  text=log.read_text();rows=list(csv.DictReader(data.open()));assert code==0 and samples>0
  assert len([x for x in rows if not x['scenario'].endswith('-drain')])==128
  errors=re.findall(r'invocation_errors=(\d+)',text);assert all(int(e)==0 for e in errors)
  if side=='B' or scene=='event':assert len(errors)==2
  if scene=='event':assert 'cycles=144,completed=144000' in text
  counter_lines=[x for x in text.splitlines() if x.startswith(('CELL_','VM_','INTEGRITY','BUSINESS_ORACLE'))]
  if side=='B':assert 'enabled=1' in text and 'CELL_COUNT' in text
  row=dict(scene=scene,side=side,source=standard['source'] if side=='B' else 'f7d2815bdd2025ee23a7c11449def822413f58e9',
   command=cmd,exit=code,valid=True,timing_qualification=False,peak_working_set=peak_ws,peak_private_commit=peak_private,
   samples=samples,poll_seconds=.005,last_row=rows[-1],errors=0 if errors else None,observations=counter_lines,
   cell_counts_available=side=='B',vm_counters_available=scene=='event',leaf_counters_available=False)
  results.append(row);(out/'results.json').write_text(json.dumps(results,indent=2))
  print('RESOURCE',scene,side,peak_ws,peak_private,flush=True)
for scene in ['event','cpp-sequence']:
 a,b=[next(x for x in results if x['scene']==scene and x['side']==s)['last_row'] for s in ['A','B']]
 for key in ['calls','resumes','suspensions','continuations','awaitables','event_waiters','queue_depth','checksum']:
  assert a.get(key)==b.get(key),(scene,key)
