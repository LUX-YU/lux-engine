$ErrorActionPreference='Stop'
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/s6'
$root="$r/record-costs"
New-Item -ItemType Directory -Path $root -ErrorAction Stop | Out-Null
$prefixes=@{E='E:/SyncForder/CodeRepos/install/s5c/q/d';F='E:/SyncForder/CodeRepos/install/s6/q/d'}
$bins=@{E='E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5c/q/d/bin';F="$r/q/d/bin"}
$clean=@($env:PATH.Split(';') | Where-Object {$_ -notmatch 'CodeRepos[/\\](install|build)' -and $_ -notmatch 'vcpkg[/\\]installed'})
foreach($side in @('E','F')){
 $build="$root/$side"
 New-Item -ItemType Directory -Path $build | Out-Null
 cmake -S "$r/candidate-source/cmake/installed-consumers/script-lua-value-costs" -B $build -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DSR5_VALUES=ON -DCMAKE_TOOLCHAIN_FILE=D:/Development/vcpkg/scripts/buildsystems/vcpkg.cmake "-DCMAKE_PREFIX_PATH=$($prefixes[$side]);E:/SyncForder/CodeRepos/install/q2/c;E:/SyncForder/CodeRepos/install/q2/toolset;E:/SyncForder/CodeRepos/install/RelWithDebInfo" -DCMAKE_FIND_USE_PACKAGE_REGISTRY=OFF -DCMAKE_FIND_USE_SYSTEM_PACKAGE_REGISTRY=OFF *> "$build/configure.log"
 if($LASTEXITCODE){throw 'Record configure failed'}
 cmake --build $build --target all -j 4 -- -k 0 *> "$build/all.log"
 if($LASTEXITCODE){throw 'Record build failed'}
 cmake --build $build --target all -j 4 -- -k 0 *> "$build/noop.log"
 if($LASTEXITCODE -or !(Select-String -LiteralPath "$build/noop.log" -SimpleMatch -Pattern 'no work to do' -Quiet)){throw 'Record no-op failed'}
}
$records=@()
foreach($pair in 0..4){
 $order=if($pair%2){@('F','E')}else{@('E','F')}
 foreach($side in $order){
  $env:PATH=(@("$($prefixes[$side])/bin",'D:/Development/vcpkg/installed/x64-windows/bin')+$clean) -join ';'
  $exe="$root/$side/script_lua_value_cost.exe"
  & $exe timing 1000000 *> "$root/record-$side-$pair.log"
  if($LASTEXITCODE){throw 'Record timing failed'}
  $records+=@{case='record';side=$side;pair=$pair;exe_sha256=(Get-FileHash $exe).Hash;prefix=$prefixes[$side];exit=0}
  $env:PATH=(@($bins[$side],'D:/Development/vcpkg/installed/x64-windows/bin')+$clean) -join ';'
  $exe="$($bins[$side])/simulation_script_lua_value_runtime_test.exe"
  & $exe --benchmark 100000 *> "$root/typed-$side-$pair.log"
  if($LASTEXITCODE){throw 'Typed timing failed'}
  $records+=@{case='typed';side=$side;pair=$pair;exe_sha256=(Get-FileHash $exe).Hash;bin=$bins[$side];exit=0}
 }
}
foreach($side in @('E','F')){
 $env:PATH=(@("$($prefixes[$side])/bin",'D:/Development/vcpkg/installed/x64-windows/bin')+$clean) -join ';'
 & "$root/$side/script_lua_value_cost.exe" diagnostics 10000 *> "$root/record-$side-diagnostics.log"
 if($LASTEXITCODE){throw 'Record diagnostic failed'}
 $env:PATH=(@($bins[$side],'D:/Development/vcpkg/installed/x64-windows/bin')+$clean) -join ';'
 & "$($bins[$side])/simulation_script_lua_value_runtime_test.exe" --benchmark 100000 --allocations *> "$root/typed-$side-diagnostics.log"
 if($LASTEXITCODE){throw 'Typed diagnostic failed'}
}
$records | ConvertTo-Json -Depth 4 | Set-Content "$root/runs.json"
