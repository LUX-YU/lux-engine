$ErrorActionPreference='Stop'
& 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/s6/record-costs.ps1'