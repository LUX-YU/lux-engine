param([string]$StartAt='consumers')
$ErrorActionPreference='Stop'
$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/s6'
$s="$r/candidate-source"
$shell=(Get-Process -Id $PID).Path
$python='C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
$deps='E:/SyncForder/CodeRepos/install/q2/c;E:/SyncForder/CodeRepos/install/q2/toolset;E:/SyncForder/CodeRepos/install/RelWithDebInfo'
$qualification=@(Get-Content "$r/q/qualification.json" -Raw | ConvertFrom-Json)
if($qualification.Count -ne 3 -or @($qualification | Where-Object {$_.status -ne 'PASS'}).Count){throw 'Final qualification not passed'}
$steps=if(Test-Path "$r/post-qualification.json"){@(Get-Content "$r/post-qualification.json" -Raw | ConvertFrom-Json)}else{@()}
$started=$false
function Execute-Step([string]$name,[string]$body){
 if($name -eq $StartAt){$script:started=$true}
 if(!$script:started){return}
 $script="$r/run-$name.ps1"
 [IO.File]::WriteAllText($script,"`$ErrorActionPreference='Stop'`n"+$body)
 Write-Output "[SR6] $name start"
 & $shell -NoProfile -File $script *> "$r/$name-driver.log"
 $exit=$LASTEXITCODE
 $script:steps+=@{step=$name;exit=$exit}
 $script:steps | ConvertTo-Json | Set-Content "$r/post-qualification.json"
 if($exit){throw "$name failed: see $r/$name-driver.log"}
 Write-Output "[SR6] $name complete"
}
Execute-Step 'consumers' @"
& '$s/cmake/RunScriptV3Consumers.ps1' -SourceDir '$s' -OutputRoot '$r/consumers-final' -PrefixPath 'E:/SyncForder/CodeRepos/install/s6/q/d;E:/SyncForder/CodeRepos/install/s6/q/t;$deps' -DependencyRoot D:/Development/vcpkg/installed -Names @('cpp-generated-script','physics2d-script','system-event-await-runtime','flowforge-compiler','lua-script-packager','scene-script-runtime','script-ability-codegen','system-hook-script-binding','cpp-coroutine-script','script-static-ability-specialization','script-ability-ipo','script-authoring','script-runtime-input','script-description','script-lua-values')
`$results=@(Get-Content '$r/consumers-final/consumers.json' -Raw | ConvertFrom-Json)
if(`$results.Count -ne 15 -or @(`$results | Where-Object {`$_.status -ne 'PASS'}).Count){throw 'Incomplete consumers'}
"@
Execute-Step 'incremental' "& '$s/cmake/RunScriptSR5ValueIncremental.ps1' -ConsumerRoot '$r/consumers-final/script-lua-values' -InstalledTemplate 'E:/SyncForder/CodeRepos/install/s6/q/d/share/lux-engine-function/script_lua/cmake_scripts/template/lua_value.template' -EvidenceRoot '$r/incremental-final'"
Execute-Step 'relocation' "& '$r/relocate.ps1'"
Execute-Step 'memory' "& '$r/memory-consumer.ps1'"
$vs=". 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation`n"
Execute-Step 'protocol' ($vs+@"
& '$python' -B '$s/cmake/RunScriptSR6Protocol.py' --source '$s' --prefix E:/SyncForder/CodeRepos/install/s6/q/d --dependencies '$deps' --output '$r/protocol-F'
if(`$LASTEXITCODE){throw 'F protocol failed'}
& '$python' -B '$s/cmake/RunScriptSR6Protocol.py' --source 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5c/candidate-source' --prefix E:/SyncForder/CodeRepos/install/s5c/q/d --dependencies '$deps' --output '$r/protocol-E'
if(`$LASTEXITCODE){throw 'E protocol failed'}
& '$python' -B '$r/regions.py'
if(`$LASTEXITCODE){throw 'Exclusive regions failed'}
"@)
$pair="--baseline-source E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5c/candidate-source --candidate-source '$s' --baseline-prefix E:/SyncForder/CodeRepos/install/s5c/q/d --candidate-prefix E:/SyncForder/CodeRepos/install/s6/q/d --dependencies '$deps'"
Execute-Step 'probes' ($vs+"& '$python' -B '$s/cmake/RunScriptSR2Probes.py' $pair --output '$r/probes'`nif(`$LASTEXITCODE){throw 'Probes failed'}")
Execute-Step 'scale' ($vs+"& '$python' -B '$s/cmake/RunScriptSR3Scale.py' $pair --output '$r/scale'`nif(`$LASTEXITCODE){throw 'Scale failed'}")
Execute-Step 'record-costs' "& '$r/record-costs.ps1'"
Execute-Step 'extra-costs' "& '$python' -B '$r/measure-extra.py'`nif(`$LASTEXITCODE){throw 'Extra costs failed'}"
Execute-Step 'performance' @"
& '$s/cmake/RunScriptV3Measurements.ps1' -BaselineBin E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5c/q/d/bin -FinalBin '$r/q/d/bin' -BaselineToolBin E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5c/q/t/bin -FinalToolBin '$r/q/t/bin' -LuaArtifact '$r/q/t/engine/toolchain/lua/lua_runtime_benchmark_fixture.lxsa' -PhysicsLuaArtifact '$r/q/t/engine/toolchain/physics2d/physics2d_lua_fixture.lxsa' -PhysicsFlowArtifact '$r/q/t/engine/toolchain/physics2d/physics2d_flowforge_fixture.lxsa' -OutputRoot '$r/performance' -Only @('cpp-update-10k','lua-update-10k','lua-ability-10k','lua-event-10k','lua-coroutine-10k','flow-update-10k','flow-event-10k','event-fanout-10k') -Pairs 5 -ScalarFrames 3000
& '$python' -B '$s/cmake/SummarizeScriptSR5Costs.py' --root '$r/performance'
if(`$LASTEXITCODE){throw 'Performance integrity failed'}
"@
