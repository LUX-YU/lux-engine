from pathlib import Path
import re,json
p=Path('local-prequal-cpp.asm')
for block in p.read_text().split('Disassembly of section '):
 m=re.search(r'^0+ <(.*)>:',block,re.M)
 if m and any(x in m[1] for x in ['ScriptCoroutineContext::invokeSyncStep(','ScriptCoroutineContext::resolveSyncStep(','ScriptCoroutineContext::invokeResolvedSyncStep(']) and '<lambda' not in m[1]:
  print(m[1]);print('\n'.join(x for x in block.splitlines() if 'IMAGE_REL_AMD64_REL32' in x))
