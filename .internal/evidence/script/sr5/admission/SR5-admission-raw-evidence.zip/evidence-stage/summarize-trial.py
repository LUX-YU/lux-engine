import json,re,statistics
from pathlib import Path
r=Path('../../s5c').resolve(); root=r/'record-trial';rows={}
for v in ['H','protected','C0','trial']:
 rows[v]=[]
 for i in range(5):
  t=(root/f'{v}-{i}.log').read_text();x={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',t)}
  assert x['count']==1000000 and x['errors']==x['backlog']==0 and x['diagnostics']==0; rows[v].append(x)
 print(v,[round(x['ns']/1e6,3) for x in rows[v]],'median ns/op',statistics.median(x['ns']/1e6 for x in rows[v]))
pairs=[100*(b['ns']/a['ns']-1) for a,b in zip(rows['C0'],rows['trial'])]
s=json.loads((r/'scalar-trial/validated-costs.json').read_text())['comparisons'][0]
print('record percent',pairs,'median',statistics.median(pairs))
keep_scalar=sum(p['percent']<0 for p in s['pairs'])>=4 and s['median_percent']<0
keep_record=sum(x<0 for x in pairs)>=4 and statistics.median(pairs)<0
report={'record_rows':rows,'record_trial_percent':pairs,'scalar_trial_percent':[p['percent'] for p in s['pairs']],'retain_scalar':keep_scalar,'retain_record':keep_record}
(r/'trial-decision.json').write_text(json.dumps(report,indent=2));print('retain scalar',keep_scalar,'retain record',keep_record)
