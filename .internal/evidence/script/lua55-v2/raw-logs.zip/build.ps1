param([Parameter(Mandatory=$true)][string]$Label, [string]$Slot='d',
    [string[]]$Targets=@('all'), [string]$TestPattern='script|lua', [switch]$NoTests)
$ErrorActionPreference='Stop'
$root='E:/SyncForder/CodeRepos/build/RelWithDebInfo/lua55-v2'
$source='E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-region-opt/final-source'
$development='E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source'
$build="E:/SyncForder/CodeRepos/build/RelWithDebInfo/o/w/$Slot"
if ((git -C $source status --porcelain)) { throw 'Qualification clone dirty' }
git -C $source -c gc.auto=0 fetch $development codex/s6-deep-optimization
if ($LASTEXITCODE) { throw 'fetch failed' }
$commit=git -C $development rev-parse HEAD
git -C $source checkout --detach $commit
if ($LASTEXITCODE) { throw 'checkout failed' }
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
function Run([string]$name,[string[]]$command) {
    $path=Join-Path $root "$Label-$name.log"
    if (Test-Path -LiteralPath $path) { throw "Existing log $path" }
    ($command | ConvertTo-Json -Compress) | Set-Content -LiteralPath $path
    $watch=[Diagnostics.Stopwatch]::StartNew()
    & $command[0] $command[1..($command.Length-1)] *>> $path
    $code=$LASTEXITCODE
    [ordered]@{source=$commit;command=$command;exit=$code;seconds=$watch.Elapsed.TotalSeconds} |
        ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $root "$Label-$name.json")
    Write-Output "$Label-$name exit=$code"
    if ($code) { throw "$Label-$name failed: $path" }
}
Run 'configure' @('cmake','-S',$source,'-B',$build,'-ULUX_LUA_VM',
    '-DLuxLua55_DIR=E:/SyncForder/CodeRepos/install/o/v2/lua55/lib/cmake/LuxLua55')
Run 'build' (@('cmake','--build',$build,'--target')+$Targets+@('-j','4','--','-k','0'))
$env:PATH="$build/bin;D:/Development/vcpkg/installed/x64-windows/bin;$env:PATH"
if (!$NoTests) { Run 'tests' @('ctest','--test-dir',$build,'--output-on-failure','-j','1','-R',$TestPattern) }
