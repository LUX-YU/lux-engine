import csv
import hashlib
import io
import json
import math
from pathlib import Path
import statistics
import subprocess

ROOT = Path(__file__).parent
def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def quantile(values, fraction):
    values = sorted(values)
    return values[max(0, math.ceil(len(values) * fraction) - 1)]

def paired(rows):
    deltas = [100 * (c / b - 1) for b, c in rows]
    return {'baseline_median_ns': statistics.median(b for b, c in rows),
            'candidate_median_ns': statistics.median(c for b, c in rows),
            'paired_percent': deltas, 'median_percent': statistics.median(deltas),
            'paired_ns': [c - b for b, c in rows]}

costs = read(ROOT / 'cost-summary.json')['comparisons']
brief = []
distributions = []
for case in costs:
    value = {k: v for k, v in case.items() if k not in {'pairs', 'diagnostics'}}
    value['paired_percent'] = [p['percent'] for p in case['pairs']]
    value['paired_ns'] = [p['delta_ns'] for p in case['pairs']]
    value['work'] = case['pairs'][0]['candidate']['effective_work']
    value['effective_resume_budget'] = case['pairs'][0]['candidate']['effective_resume_budget']
    value['whole_batch_ns_per_actual_operation'] = {
        k: case['median_candidate_ns'] / v for k, v in value['work'].items()
        if isinstance(v, int) and v > 0
    }
    brief.append(value)
    for pair in case['pairs']:
        for variant in ('baseline', 'candidate'):
            run = pair[variant]
            command = run['command']
            path = Path(command[command.index('--output') + 1])
            rows = list(csv.DictReader(path.open(encoding='utf-8-sig')))
            column = next(key for key in ('nanoseconds', 'elapsed_ns', 'frame_ns') if key in rows[0])
            groups = {'frames': rows} if case['case'] != 'event-fanout' else {
                'delivery': rows[:1], 'drains': rows[1:]
            }
            for category, samples in groups.items():
                times = [int(row[column]) for row in samples]
                distributions.append({'comparison': case['comparison'], 'case': case['case'],
                                      'pair': pair['pair'], 'variant': variant, 'category': category,
                                      'samples': len(times), 'total_ns': sum(times),
                                      'p50_ns': quantile(times, .5), 'p95_ns': quantile(times, .95),
                                      'max_ns': max(times), 'source': str(path)})

def probe(variant, index):
    lines = (ROOT / f'validation-final/probes/{variant}-{index}.csv.log').read_text().splitlines()
    position = next(i for i, line in enumerate(lines) if line.startswith('prepare_ns,'))
    return {k: int(v) for k, v in next(csv.DictReader(lines[position:position+2])).items()}

cold = {}
for key in ('prepare_ns', 'late_ns', 'remount_128_ns'):
    cold[key] = paired([(probe('baseline', i)[key], probe('candidate', i)[key]) for i in range(5)])
scale = read(ROOT / 'validation-final/scale/runs.json')
scales = {}
for count in (8, 8192):
    variants = {v: [r for r in scale if r['configs'] == count and not r['diagnostics'] and r['variant'] == v]
                for v in ('baseline', 'candidate')}
    assert len(variants['baseline']) == len(variants['candidate']) == 5
    scales[str(count)] = paired([(b['elapsed_ns'], c['elapsed_ns']) for b, c in zip(*variants.values())])
    for r in [r for r in scale if r['configs'] == count]:
        assert r['slot_visits'] == 128 and r['endpoint_count_visits'] == 0
        assert r['errors'] == r['backlog'] == 0 and r['creates'] == r['destroys'] == count + 144
    scales[str(count)]['rebuilds'] = 128
    scales[str(count)]['slot_visits'] = 128
    scales[str(count)]['endpoint_count_visits'] = 0

result = {'statistical_unit': 'Five independent process pairs; per-frame p50/p95 are descriptive, not independent trials',
          'per_operation_limit': 'Whole measured batch amortization, not isolated invocation/resume cost',
          'qualification_commit': '1750ce854967a382ee89accf3a3534a0628396cc',
          'performance': brief, 'cold': cold, 'scale': scales}
(ROOT / 'one-page.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
(ROOT / 'frame-distributions.json').write_text(json.dumps(distributions, indent=2), encoding='utf-8')
with (ROOT / 'one-page.csv').open('w', newline='', encoding='utf-8') as stream:
    fields = ['comparison', 'case', 'median_baseline_ns', 'median_candidate_ns', 'median_delta_ns', 'median_percent', 'range_percent']
    writer = csv.DictWriter(stream, fieldnames=fields)
    writer.writeheader()
    writer.writerows({k: row[k] for k in fields} for row in brief)

preserved = read(ROOT / 'preserved-work-and-header-sync.json')
checks = []
for entry in preserved['unknown_files']:
    digest = hashlib.sha256(Path(entry['path']).read_bytes()).hexdigest()
    assert digest == entry['sha256'], entry['path']
    checks.append({'path': entry['path'], 'sha256': digest, 'unchanged': True})
sources = []
for folder, expected in (
    ('lux-engine-sr4-candidate', '1750ce854967a382ee89accf3a3534a0628396cc'),
    ('lux-engine-sr3-event', '8a6e6ef468f7eb60265678ab25116719b42a01a6'),
    ('lux-engine-sr3-reference', '8145598c18421d03da1dac21251200af3290e27d'),
    ('lux-cxx-v3r', '3100f54d0743c5ed94a4ccf5943df04e933de255'),
    ('lux-cmake-toolset-s6-relocation', '99c3d0480d1db816779b1dfa7f3c06cb7d39a94f')
):
    path = Path('E:/SyncForder/CodeRepos') / folder
    head = subprocess.check_output(['git', '-C', str(path), 'rev-parse', 'HEAD'], text=True).strip()
    status = subprocess.check_output(['git', '-C', str(path), 'status', '--porcelain'], text=True).strip()
    assert head == expected and not status, (folder, head, status)
    sources.append({'path': str(path), 'commit': head, 'status': status})
(ROOT / 'final-identity-check.json').write_text(json.dumps({'unknown_files': checks, 'sources': sources}, indent=2))
print(json.dumps({'cold': cold, 'scale': scales, 'frame_distributions': len(distributions), 'protected_files': len(checks)}, indent=2))
