from pathlib import Path
import csv,json,re
r=Path(__file__).parent
out=r/'hot-analysis';out.mkdir(exist_ok=True)
frames=[]
for side,folder in [('B0','machine-code2'),('B1','hot-machine-code')]:
 text=(r/folder/'3-Tasks.CompleteTasks.script.generated.cpp.obj.asm').read_text()
 for task in ['event','next','sequence','longTask','pose']:
  matches=[]
  for block in text.split('Disassembly of section '):
   symbol=re.search(r'^0+ <(.*)>:',block,re.M)
   if not symbol or not re.search(r'Tasks::'+task+r'\(',symbol[1]):continue
   if not symbol[1].startswith('public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::'):continue
   lines=block.splitlines()
   for i,line in enumerate(lines):
    if 'IMAGE_REL_AMD64_REL32' not in line or '?allocateFrame@' not in line:continue
    before='\n'.join(lines[max(0,i-9):i])
    n=re.search(r'movl\s+\$0x([0-9a-f]+), %edx',before)
    if n:matches.append((int(n[1],16),symbol[1],block))
  assert len(matches)==1,(side,task,len(matches))
  n,symbol,block=matches[0]
  (out/f'{side}-frame-{task}.asm.txt').write_text(block)
  frames.append(dict(side=side,task=task,frame_bytes=n,alignment=8,pool_limit=512,symbol=symbol))
(out/'frames.json').write_text(json.dumps(frames,indent=2))
sizes=[]
for side,folder in [('B0','current-class-layout2'),('B1','hot-class-layout')]:
 for name in ['CppStaticScriptBridge.cpp.log','LuaScriptBackend.cpp.log','ScriptSystem.cpp.log']:
  text=(r/folder/name).read_text(errors='replace')
  names=['PreparedScriptSyncStep','ScriptSyncStepShape','ScriptSyncStepType','ScriptCoroutine::promise_type',
   'CppStaticScriptBackend::State::Instance','CppStaticScriptBackend::State::DescriptorIndex',
   'LuaScriptBackend::Impl::LuaFunctionBinding','LuaScriptBackend::Impl::LuaFunctionBinding::SyncArgument']
  for line in text.splitlines():
   m=re.match(r'class (.*?)\s+size\((\d+)\):',line)
   if m and any(m[1].endswith('::'+n) for n in names):sizes.append(dict(side=side,type=m[1],size=int(m[2]),file=name))
(out/'sizes.json').write_text(json.dumps(sizes,indent=2))
resources=[]
for run in json.loads((r/'hot-resources/runs.json').read_text()):
 for line in run['observation']:
  kind=line.split(' ')[0];fields=dict(re.findall(r'(\w+)=(\S+)',line))
  if kind not in ['PROCESS_MEMORY','MEMORY','NATIVE_MEMORY']:continue
  resources.append(dict(run=run['name'],kind=kind,**{k:int(v) if v.isdigit() else v for k,v in fields.items()}))
(out/'resources.json').write_text(json.dumps(resources,indent=2))
print('FRAMES',json.dumps(frames,ensure_ascii=False))
print('SIZES',json.dumps([s for s in sizes if s['file']!='ScriptSystem.cpp.log'],ensure_ascii=False))
for leg in ['P1','P4','P5']:
 for size in [1000,10000]:
  values={side:{x['kind']:x for x in resources if x['run']==f'{leg}-{size}-{side}' and x['phase']=='prepared'} for side in ['A','B']}
  print('RESOURCE',leg,size,{k:{s:values[s][kind][k] for s in values} for kind,k in [('PROCESS_MEMORY','private_commit'),('PROCESS_MEMORY','all_heaps_busy_bytes'),('NATIVE_MEMORY','composition'),('MEMORY','live'),('MEMORY','active_pages')]})
