from pathlib import Path
import hashlib,subprocess,json
repo=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source');r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/lua55-v3')
files=subprocess.check_output(['git','diff','--name-only','10a70e80e6e2879ecb09f14ffc083516d0666752','HEAD','--','modules'],cwd=repo,text=True).splitlines()
records=[]
for n in files:
 if '/include/' not in n:continue
 src=repo/n;rel=n.split('/include/',1)[1]
 for base in ['Debug/include','RelWithDebInfo/include','Android/lux-engine/include']:
  p=Path('E:/SyncForder/CodeRepos/install')/base/rel
  correct=hashlib.sha256(p.read_bytes()).digest()==hashlib.sha256(src.read_bytes()).digest() if src.exists() and p.exists() else not(src.exists() or p.exists())
  records.append(dict(source=n,prefix=base,correct=correct,source_exists=src.exists(),installed_exists=p.exists()))
(r/'public-header-sync-audit.json').write_text(json.dumps(records,indent=2));print(json.dumps([a for a in records if not a['correct']],indent=2));print('checked',len(records))
