from pathlib import Path
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source'); p=r/'engine/domain/simulation/scripting/lua/src/LuaScriptBackend.cpp'; t=p.read_text()
t=t.replace('            int reference{LUA_NOREF};','            int roots_ref{LUA_NOREF};\n            std::size_t root_slot{};\n            bool rooted{};',1)
t=t.replace('''            auto* thread = lua_newthread(state);
            const auto reference = luaL_ref(state, LUA_REGISTRYINDEX);
            request->thread = thread;
            request->reference = reference;''','''            lua_rawgeti(state, LUA_REGISTRYINDEX, request->roots_ref);
            auto* thread = lua_newthread(state);
            lua_rawseti(state, -2, static_cast<lua_Integer>(request->root_slot + 1U));
            request->thread = thread;
            request->rooted = true;''')
t=t.replace('            int thread_ref{LUA_NOREF};\n','')
t=t.replace('            vm_configured = true;\n','',1)
a=t.index('            lua_pushcfunction(state, &State::traceback);'); b=t.index('\n        [[nodiscard]] static bool identifier',a)
t=t[:a]+'''            if (!lua_checkstack(state, 3)) return;
            lua_pushcfunction(state, &State::createRoots);
            lua_pushlightuserdata(state, this);
            if (lua_pcall(state, 1, 0, 0) != LUA_OK) { lua_pop(state, 1); return; }
            vm_configured = true;
        }

        static int createRoots(lua_State* vm)
        {
            auto* owner = static_cast<State*>(lua_touserdata(vm, 1));
            lua_createtable(vm, static_cast<int>(owner->continuation_capacity), 0);
            for (std::size_t index{}; index < owner->continuation_capacity; ++index)
            {
                lua_pushboolean(vm, false);
                lua_rawseti(vm, -2, static_cast<lua_Integer>(index + 1U));
            }
            owner->thread_roots_ref = luaL_ref(vm, LUA_REGISTRYINDEX);
            lua_pushcfunction(vm, &State::traceback);
            owner->traceback_ref = luaL_ref(vm, LUA_REGISTRYINDEX);
            return 0;
        }

        void clearThreadRoot(std::size_t slot) noexcept
        {
            lua_rawgeti(state, LUA_REGISTRYINDEX, thread_roots_ref);
            lua_pushboolean(state, false);
            lua_rawseti(state, -2, static_cast<lua_Integer>(slot + 1U));
            lua_pop(state, 1);
        }

        ~State()
        {
            if (!state) return;
            // The root table owns all remaining VM references and is released once.
            if (thread_roots_ref != LUA_NOREF) luaL_unref(state, LUA_REGISTRYINDEX, thread_roots_ref);
            for (const auto& [asset, prototype] : prototypes)
            {
                static_cast<void>(asset);
                if (prototype.table_ref != LUA_NOREF) luaL_unref(state, LUA_REGISTRYINDEX, prototype.table_ref);
                if (prototype.environment_ref != LUA_NOREF) luaL_unref(state, LUA_REGISTRYINDEX, prototype.environment_ref);
            }
            for (const auto& function : function_bindings)
                if (function.function_ref != LUA_NOREF) luaL_unref(state, LUA_REGISTRYINDEX, function.function_ref);
            if (traceback_ref != LUA_NOREF) luaL_unref(state, LUA_REGISTRYINDEX, traceback_ref);
        }
''' + t[b:]
t=t.replace('            ThreadCreateRequest request;','            ThreadCreateRequest request;\n            request.roots_ref = thread_roots_ref;\n            request.root_slot = slot;')
t=t.replace('''            const bool missing_root = request.thread == nullptr || request.reference == LUA_NOREF ||
                request.reference == LUA_REFNIL;''','''            const bool missing_root = request.thread == nullptr || !request.rooted;''')
t=t.replace('''                if (request.reference != LUA_NOREF && request.reference != LUA_REFNIL)
                    luaL_unref(state, LUA_REGISTRYINDEX, request.reference);''','''                if (request.rooted) clearThreadRoot(slot);''')
t=t.replace('                request.reference,\n','')
t=t.replace('''            if (continuation.thread_ref != LUA_NOREF)
                luaL_unref(owner->state, LUA_REGISTRYINDEX, continuation.thread_ref);''','''            owner->clearThreadRoot(slot);''')
t=t.replace('        int traceback_ref{LUA_NOREF};','        int traceback_ref{LUA_NOREF};\n        int thread_roots_ref{LUA_NOREF};')
assert 'thread_ref' not in t and 'request.reference' not in t
p.write_text(t)
# Keep the old registry boundary adversarial arrangement: it must now succeed without touching that slot.
p=r/'engine/domain/simulation/scripting/lua/test/lua_coroutine_integration_test.cpp'; t=p.read_text(); t=t.replace('return testCreationOom(2U, true);','return testFixedRootAtRegistryBoundary();'); a=t.index('    int testCreationOom(')
t=t[:a]+'''    int testFixedRootAtRegistryBoundary()
    {
        const auto boundary = observeRegistryGrowth();
        Harness harness{true, 1U, true, true};
        Provider provider;
        const auto binding = lux::script::bindScriptAbility<Ability>(provider);
        const std::array publications{publishScriptAbility(binding)};
        auto system = harness.create(publications);
        assert(system && system->prepare());
        assert(dispatchRuntimeHook(*system, harness.sync_hook) == 1U);
        auto* vm = g_observed_vm;
        std::vector<int> padding;
        for (std::size_t index{}; index < boundary.padding; ++index)
        {
            lua_pushboolean(vm, true);
            padding.push_back(luaL_ref(vm, LUA_REGISTRYINDEX));
        }
        assert(padding.back() + 1 == boundary.reference);
        assert(dispatchRuntimeHook(*system, harness.async_hook) == 1U);
        assert(provider.pending && provider.reads == 2U && provider.writes == 2U);
        lua_rawgeti(vm, LUA_REGISTRYINDEX, boundary.reference);
        assert(lua_isnil(vm, -1));
        lua_pop(vm, 1);
        assert(system->shutdown());
        for (const auto reference : padding) luaL_unref(vm, LUA_REGISTRYINDEX, reference);
        const auto stats = harness.backend->stats();
        assert(stats.vm_coroutine_creations == 1U && stats.vm_coroutine_releases == 1U);
        std::puts("FIXED_ROOT_PASS,registry_boundary_untouched=1,provider_calls=4,roots=1,releases=1");
        return 0;
    }

''' +t[a:]
# Remove obsolete optional registry-OOM branch, retain allocation failures zero/one and slot reuse.
a=t.index('    int testCreationOom('); b=t.index('    int testCreationReentry(',a); s=t[a:b]; s=s.replace('std::size_t permitted, bool registry_growth = false','std::size_t permitted'); a1=s.index('        // Discover'); b1=s.index('        Harness harness',a1); s=s[:a1]+s[b1:]; a1=s.index('        std::vector<int> padding;'); b1=s.index('        CreationAllocator allocation;',a1); s=s[:a1]+s[b1:]; a1=s.index('        if (registry_growth)'); b1=s.index('        assert(allocation.failures',a1); s=s[:a1]+s[b1:]; s=s.replace('registry_growth=%d,','').replace('permitted, registry_growth ? 1 : 0, allocation.failures,','permitted, allocation.failures,'); t=t[:a]+s+t[b:]; t=t.replace('--creation-registry-oom','--fixed-root-registry'); p.write_text(t)
p=r/'engine/domain/simulation/scripting/lua/CMakeLists.txt'; t=p.read_text().replace('simulation_script_lua_creation_registry_oom','simulation_script_lua_fixed_root_registry_test').replace('--creation-registry-oom','--fixed-root-registry'); p.write_text(t)
