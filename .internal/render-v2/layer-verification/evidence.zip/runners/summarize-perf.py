import csv,json,math
from pathlib import Path

root=Path('E:/RenderV2Rebuild/Layer/evidence/L4/paired')
def rows(p):
    with p.open() as f:return list(csv.DictReader(f))
def quantile(values):
    s=sorted(values)
    return {'n':len(s),**{name:s[math.ceil(len(s)*q)-1] for name,q in [('p50',.5),('p95',.95),('p99',.99),('max',1)]}} if s else None
results=[];pooled={}
for run in json.loads((root/'runs.json').read_text(encoding='utf-8-sig')):
    assert run['exit']==0
    test=run['test'];folder=root/f"{run['round']}-{run['variant']}-{test}"
    metrics={};work={};counts={}
    if test=='command':
        samples=rows(folder/'runtime-open-operation.csv')
        assert len(samples)==1000
        assert all(int(r['engine_new_calls'])==int(r['client_dll_new_calls'])==0 for r in samples)
        for key in ('submit_construct_ns','wait_and_consume_ns','successful_consume_typed_ns','handler_reply_ns'):
            metrics[key]=[int(r[key]) for r in samples]
        metrics['full_roundtrip_ns']=[int(r['submit_construct_ns'])+int(r['wait_and_consume_ns']) for r in samples]
    elif test=='native':
        samples=rows(folder/'native-record-execute.csv');assert len(samples)==1000
        metrics['record_execute_ns']=[float(r['record_execute_us'])*1000 for r in samples]
    else:
        work={k:int(v) for k,v in rows(folder/'fixed-work.csv')[0].items()}
        assert (work['uploads'],work['bytes'],work['chunks'],work['draws'])==(16,268435456,256,4096)
        uploads=rows(folder/f'texture-rendering-{test}.csv');assert len(uploads)==16
        frames=rows(folder/f'texture-cadence-{test}.csv');events=rows(folder/'events.csv')
        counts={str(k):sum(int(e['event'])==k for e in events) for k in (1,2,3,4,5,6,7,10,11)}
        assert counts['4']==4096 and counts['5']==(256 if test=='alias' else 272),counts
        assert counts['10']==counts['11']==16
        metrics={'upload_roundtrip_ns':[int(r['total_ns']) for r in uploads],
            'submit_move_ns':[int(r['submit_move_ns']) for r in uploads],
            'consume_type_access_ns':[int(r['completion_consume_type_access_ns']) for r in uploads]}
        for category,predicate in [('all',lambda r:True),('active',lambda r:int(r['upload_sample'])<16),('tail',lambda r:int(r['upload_sample'])==16)]:
            metrics[f'four_view_{category}_ns']=[int(r['recorded_four_view_interval_ns']) for r in frames if r['phase']=='2' and predicate(r)]
        for sample in range(16):
            samples=[e for e in events if int(e['sample'])==sample]
            def times(kind):return [int(e['ns']) for e in samples if int(e['event'])==kind]
            begin,consumed,ready,published=times(1)[0],times(7)[0],times(10)[0],times(11)[0]
            submissions=times(5)
            for key,value in [('start_to_first_submit_ns',min(submissions)-begin),('first_submit_to_ready_ns',ready-min(submissions)),('last_submit_to_ready_ns',ready-max(submissions)),('ready_to_reply_ns',published-ready),('reply_to_consume_ns',consumed-published)]:
                assert value>=0,(key,value)
                metrics.setdefault(key,[]).append(value)
    for key,values in metrics.items():pooled.setdefault((run['variant'],test,key),[]).extend(values)
    results.append(dict(run=run,work=work,counts=counts,metrics={k:quantile(v) for k,v in metrics.items()}))
summary=[dict(variant=v,test=t,metric=m,**quantile(x)) for (v,t,m),x in pooled.items() if x]
(root/'summary.json').write_text(json.dumps(dict(runs=results,pooled=summary,percentiles='nearest rank ceil(n*p)-1, no trimming'),indent=2)+'\n')
with (root/'summary.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['variant','test','metric','n','p50','p95','p99','max']);w.writeheader();w.writerows(summary)
for r in summary:
    if r['metric'] in ('full_roundtrip_ns','record_execute_ns','upload_roundtrip_ns','four_view_all_ns','four_view_active_ns','ready_to_reply_ns'):
        print(r)

