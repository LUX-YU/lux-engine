from pathlib import Path
b=Path('E:/RenderV2Rebuild/Layer/source/modules/function/render')
p=b/'protocol/include/lux/engine/render/protocol/Protocol.hpp';s=p.read_text();start=s.index('    enum class ECommandOwner');end=s.index('    [[nodiscard]] RenderResult<void> validateCommand',start)
s=s[:start]+'''    // The erased call is produced from one checked C++ signature at cold registration.
    struct CommandHandler final
    {
        const CommandDescriptor* descriptor = nullptr;
        RenderResult<void> (*invoke)(void*, CommandInvocation&) noexcept = nullptr;
        void* user = nullptr;
    };

    template <RenderCommand C, auto Function, class State>
        requires std::same_as<decltype(Function),
            RenderResult<void> (*)(State&, const typename C::Request&, CommandContext<C>&) noexcept>
    [[nodiscard]] CommandHandler bindCommand(State& state) noexcept
    {
        return {&commandDescriptor<C>(), [](void* owner, CommandInvocation& invocation) noexcept {
            CommandContext<C> context(invocation);
            return Function(*static_cast<State*>(owner), context.request(), context);
        }, &state};
    }

'''+s[end:];p.write_text(s)
# Registration policy is outside the neutral protocol. One final binding is adopted at run.
p=b/'resource/include/lux/engine/render/resource/Registration.hpp';s=p.read_text().replace('namespace lux::render\n{','''namespace lux::render
{
    struct CommandRegistration : CommandHandler
    {
        CommandRegistration() noexcept = default;
        CommandRegistration(CommandHandler handler) noexcept : CommandHandler(handler) {}

        // A Native adapter resolves its owner once before publishing capabilities.
        CommandHandler (*bind_native)(void*) noexcept = nullptr;
        bool gpu_completion = false;
    };
''').replace('span<const CommandHandler>','span<const CommandRegistration>');p.write_text(s)
p=b/'features/include/lux/engine/render/features/Registration.hpp';s=p.read_text().replace('#include <memory>','#include <memory>\n#include <lux/engine/render/resource/Registration.hpp>').replace('span<const CommandHandler>','span<const CommandRegistration>');p.write_text(s)
p=b/'runtime/src/RenderServer.cpp';s=p.read_text().replace('CommandHandler binding','CommandRegistration binding').replace('span<const CommandHandler>','span<const CommandRegistration>');s=s.replace('addCommand({&commandDescriptor<C>(),','addCommand(CommandHandler{&commandDescriptor<C>(),');s=s.replace('if (entry.binding.owner == ECommandOwner::DEVICE_SESSION) entry.binding.user = s.device.get();','if (entry.binding.bind_native)\n                static_cast<CommandHandler&>(entry.binding) = entry.binding.bind_native(s.device.get());')
a=s.index('            if (const auto* factory = resources.factory(type.description->type))');z=s.index('            if (auto configured',a)
s=s[:a]+'''            if (auto installed = resources.installFactory(type.factory); !installed)
            { s.shutdown(); return cxx::unexpected(installed.error()); }
'''+s[z:];p.write_text(s)
p=b/'native/vulkan/src/transfer/Transfer.cpp';s=p.read_text();s=s.replace('        resources_->installFactory(textureStorageFactory());','') # inspect exact below
p.write_text(s)
# Native extension registration, no owner policy in Protocol.
p=b/'native/vulkan/include/lux/engine/render/native/vulkan/Registration.hpp'
p.write_text('''#pragma once

#include <lux/engine/render/resource/Registration.hpp>
#include <lux/engine/render/native/vulkan/DeviceSession.hpp>

namespace lux::render::vulkan
{
    template <RenderCommand C, auto Function>
        requires std::same_as<decltype(Function),
            RenderResult<void> (*)(DeviceSession&, const typename C::Request&, CommandContext<C>&) noexcept>
    [[nodiscard]] CommandRegistration nativeCommand() noexcept
    {
        CommandRegistration registration;
        registration.descriptor = &commandDescriptor<C>();
        registration.bind_native = [](void* owner) noexcept {
            return bindCommand<C, Function>(*static_cast<DeviceSession*>(owner));
        };
        // Register the same typed thunk without inventing a device before startup.
        registration.invoke = [](void* owner, CommandInvocation& invocation) noexcept {
            CommandContext<C> context(invocation);
            return Function(*static_cast<DeviceSession*>(owner), context.request(), context);
        };
        registration.gpu_completion = commandDescriptor<C>().completion == ECompletionContract::RESOURCE_GPU_READY;
        return registration;
    }
}
''')
# Context exposes only a borrowed extension access to friend Native adapter, not public GPU policy.
p=b/'protocol/include/lux/engine/render/protocol/Protocol.hpp';s=p.read_text().replace('    struct CommandAsyncOps;','    struct CommandAsyncOps;\n    namespace detail { struct CommandContextAccess; }');s=s.replace('        CommandInvocation* invocation_;','        friend struct detail::CommandContextAccess;\n        CommandInvocation* invocation_;');p.write_text(s)
p=b/'native/vulkan/include/lux/engine/render/native/vulkan/transfer/GpuCompletion.hpp';s=p.read_text();s=s.replace('namespace lux::render::vulkan','''namespace lux::render::detail
{
    // Installed because the Native extension template below has external consumers.
    struct CommandContextAccess final
    {
        template <RenderCommand C>
        static CommandInvocation& invocation(CommandContext<C>& context) noexcept { return *context.invocation_; }
    };
}

namespace lux::render::vulkan''',1);pos=s.index('        ~GpuCompletionReservation()');s=s[:pos]+'''        template <RenderCommand C>
        [[nodiscard]] static RenderResult<GpuCompletionReservation>
        reserve(CommandContext<C>& context, SubmissionQueue& queue, typename C::Response& response) noexcept
        {
            return reserve(detail::CommandContextAccess::invocation(context), queue, &response);
        }

'''+s[pos:];p.write_text(s)
p=b/'native/vulkan/src/texture/Commands.cpp';s=p.read_text().replace('#include <lux/engine/render/resource/Registration.hpp>','#include <lux/engine/render/native/vulkan/Registration.hpp>')
for fn,cmd in [('setTexture','SetTexture'),('setRegion','SetTextureRegion'),('release','ReleaseTexture'),('query','QueryTexture')]:
 s=s.replace('RenderResult<void> '+fn+'(void* native, CommandInvocation& invocation) noexcept', 'RenderResult<void> '+fn+'(vulkan::DeviceSession& device, const '+cmd+'::Request& input,\n            CommandContext<'+cmd+'>& context) noexcept')
 s=s.replace('            CommandContext<'+cmd+'> context(invocation);\n','')
s=s.replace('            const auto& input = context.request();\n','').replace('            auto& device = *static_cast<vulkan::DeviceSession*>(native);\n','').replace('static_cast<vulkan::DeviceSession*>(native)->resources()','device.resources()').replace('reserve(invocation, device.queue(), &response)','reserve(context, device.queue(), response)').replace('storage->query(context.request())','storage->query(input)')
start=s.index('            CommandHandler{');end=s.index('\n        };',start)
s=s[:start]+'''            vulkan::nativeCommand<SetTexture, setTexture>(),
            vulkan::nativeCommand<SetTextureRegion, setRegion>(),
            vulkan::nativeCommand<ReleaseTexture, release>(),
            vulkan::nativeCommand<QueryTexture, query>()'''+s[end:];p.write_text(s)
# Explicit fixture setup, same instance table and factory owner.
p=b/'native/vulkan/test/TextureFixture.hpp';s=p.read_text();anchor='    const TextureStorageConfig config{capacity, bytes};';s=s.replace(anchor,'''    if (!registry.factory(lux::render::TextureStorage::description.type))
        if (auto installed = registry.installFactory(textureStorageFactory()); !installed) return installed;
'''+anchor);p.write_text(s)
