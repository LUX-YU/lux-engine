# 配对复算输入

`analyse_pairs.py`只对已记录的运行做算术复算，不运行基准、不验证DLL身份、不证明行为等价、不决定是否合并。

输入根对象是`{"comparisons": [...]}`。每个comparison必须有唯一`id`和`runs`列表。每条**有效**run需要：

```text
side: "A" 或 "B"
pair: 0、1、2
source: 实际生产资格source的40位小写SHA
valid: true
oracle_pass: true
total_ns: 实际完整区间时间，正数
completed_units: 实际完成单位数，正整数
unit: 明确单位字符串
workload_fingerprint: 该比较共同业务/输入/调度规格hash
business_oracle_digest: 映射到共同业务的结果/trace摘要
```

A/B程序和资产可以不同，`workload_fingerprint`不应是单侧EXE hash；生产产物hash保存在独立manifest。`business_oracle_digest`不能包含允许不同的Lua/native内部调用数、地址或内部token。它应包含共同业务结果和规定时序；不能只选择容易相等的无关字段。

无效运行保留`valid:false`与非空`invalid_reason`，计算时不使用。每组最终恰好3对有效记录，不允许重复一侧再挑快组。同侧不得混用不同candidate源码；三对使用同一workload。每对实际完成量必须相同。

`paired_median_percent`是每对B/A−1的百分比的中位数，不是两侧中位数的比值。脚本不会授予“等价”，也不会根据统一百分比阈值给PROMISING。

执行示例：

```text
python analyse_pairs.py real_normalized_runs.json --output new_arithmetic_result.json
```

输出文件已存在时拒绝覆盖。请从保留的原始CSV/日志生成规范化输入，不得手填想要的计时结果。
