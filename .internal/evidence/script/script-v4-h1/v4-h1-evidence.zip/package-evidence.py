from pathlib import Path
import hashlib,json,zipfile
r=Path(__file__).parent;repo=r.parent/'script-cell-a1/source'
dest=repo/'.internal/evidence/script/script-v4-h1';dest.mkdir(parents=True,exist_ok=True)
archive=dest/'v4-h1-evidence.zip'
assert not archive.exists()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
files=[]
binary={'.exe','.dll','.pdb','.obj','.lib','.exp','.ilk','.pch','.pak','.lxsa'}
directories=['baseline-profile','contract-comparison','contract-comparison2','contract-comparison3','contract-comparison-final',
 'attempt1-native-boundary','attempt2-native-boundary','attempt1-pin-boundary','native-cold','native-boundary','pin-boundary',
 'final-costs','final2-costs','h2-withdrawal','h2-withdrawal-costs','layout','layout-final2',
 'machine-A','machine-A-full','machine-B-full','machine-B2-full','spec','value-incremental','value-incremental-final2']
for p in r.iterdir():
 if p.is_file() and p.suffix in ['.py','.ps1','.cpp','.json','.txt','.log','.csv','.diff'] and 'symbols' not in p.name:
  files.append(p)
for d in directories:
 for p in (r/d).rglob('*'):
  if p.is_file() and (d=='baseline-profile' or p.suffix.lower() not in binary):files.append(p)
# Consumer logs + actual generated textual inputs, never whole build trees or SDK binaries.
for d in ['installed','installed-final2','relocated','relocated-final2']:
 for p in (r/d).rglob('*'):
  if not p.is_file():continue
  rel=p.relative_to(r/d);parts=rel.parts
  if parts[0] in ['sdk','tools','vm']:continue
  if 'build' not in parts:
   if p.suffix.lower() not in binary:files.append(p)
  elif p.name in ['CMakeCache.txt','compile_commands.json'] or ('generated' in parts and p.suffix in ['.hpp','.cpp','.json']):
   files.append(p)
for d in ['final-image','final-flow-image','final2-image','final2-flow-image']:
 files.append(r/d/'identity.json')
files=sorted(set(files))
manifest=[dict(path=p.relative_to(r).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in files]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,p.relative_to(r).as_posix())
 z.writestr('MANIFEST.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 for row in manifest:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256'],row['path']
digest=sha(archive)
(dest/'SHA256.txt').write_text(digest+'  '+archive.name+'\n')
(dest/'MANIFEST.json').write_text(json.dumps(dict(source='7c565a0014d7c82f0d522eb4ca8c8f0f64773893',
 archive=archive.name,sha256=digest,bytes=archive.stat().st_size,entries=len(manifest)+1,hashed_files=len(manifest),
 scope='raw VTune results/exports, code snippets, exact commands, failed attempts, correctness/install logs, all timing; no build/SDK binaries'),indent=2)+'\n')
print('PACKAGE_VERIFIED',archive.stat().st_size,len(manifest),digest,flush=True)
