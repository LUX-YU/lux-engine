$ErrorActionPreference='Stop'
& 'C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -B 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/s6/measure-extra.py'
if($LASTEXITCODE){throw 'Extra costs failed'}