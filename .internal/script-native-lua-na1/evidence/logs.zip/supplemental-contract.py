from pathlib import Path
import json,re,subprocess,os,hashlib
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1'); q=r/'qualification-source'; d=r.parent/'o/w/d'; out=r/'supplemental-contract'; out.mkdir(exist_ok=True)
p=q/'engine/domain/simulation/scripting/native_lua_tasks/test/native_lua_tasks_test.cpp'
s=p.read_text();s=s.replace('"../../../builtin/script/test/', '"'+(q/'engine/domain/simulation/builtin/script/test').as_posix()+'/')
s=s.replace('std::size_t count, leases{};', 'const lux::script::ScriptArtifact *lookup_override{};\n    std::size_t count, leases{};')
s=s.replace('id == asset(1U) ? &self.lua_artifact : &self.native_artifact', 'id == asset(1U) ? (self.lookup_override ? self.lookup_override : &self.lua_artifact) : &self.native_artifact')
extra=r'''
    for (const bool repeated_step : {false, true})
    {
        const std::array routes{NativeLuaTaskRoute{101U, 101U}, NativeLuaTaskRoute{101U, 107U}};
        const std::array steps{lux::rdesc::ScriptFunction{"apply", 102U, {}, {}},
                               lux::rdesc::ScriptFunction{"apply", 102U, {}, {}}};
        const std::array pools{CppStaticScriptPoolDescription{&Na1Task}};
        const std::array plans{NativeLuaTaskPlan{asset(1U), {}, asset(2U), {}, &Na1Task,
            std::span{routes}.first(repeated_step ? 1U : 2U),
            std::span{steps}.first(repeated_step ? 2U : 1U)}};
        auto rejected = NativeLuaTaskBackend::create({.native_pools=pools, .plans=plans,
            .artifacts={nullptr, [](void *, const lux::asset::AssetId &, ResolvedScriptArtifact &) noexcept {
                return false;
            }}, .instance_capacity=1U, .prepared_method_capacity=1U});
        assert(!rejected && rejected.error()==ENativeLuaTaskBackendError::INVALID_PLAN);
        std::printf("CASE supplemental-duplicate kind=%s cold-reject=1\n", repeated_step ? "step" : "route");
    }
    {
        na1::mode=0U;
        Harness h(1U, "local closed=false; do local x <close> = setmetatable({}, {__close=function() "
            "closed=true; lux.TaskProbe.hit(5) end}); lux.TaskProbe.hit(3); assert(not closed); end; "
            "assert(closed); return p");
        h.probe.callback_context=&h;
        h.probe.callback=[](void *pointer, std::int32_t code) noexcept {
            auto &h=*static_cast<Harness *>(pointer);
            if (code==3) assert(dispatchRuntimeHook(*h.system,h.nested_hook)==1U);
        };
        assert(h.system->prepare() && observed_vm);
        const auto base=lua_gettop(observed_vm);
        assert(dispatchRuntimeHook(*h.system,h.hook)==1U);
        h.occurrence();
        assert(na1::completed==1U && na1::results[0]==31 && h.probe.calls==3U);
        assert(lua_gettop(observed_vm)==base && h.system->failures().empty());
        h.closed();
        std::puts("CASE supplemental-nested-tbc outer-live-after-inner=1 close=1 provider=3 stack-restored=1");
    }
    {
        na1::mode=0U;
        Harness h(1U);
        auto replacement=luaArtifact("self.value=self.value+9000; return self.value",false,0U);
        assert(h.system->prepare());
        assert(dispatchRuntimeHook(*h.system,h.hook)==1U);
        h.lookup_override=&replacement;
        h.occurrence();
        assert(na1::completed==1U && na1::results[0]==32);
        h.registry.destroy(h.entities[0]);
        assert(h.system->processLifecycle() && h.leases==0U);
        std::array<ScriptMountStatus,1U> changes;
        assert(h.system->collectMountStatusChanges(changes));
        h.entities[0]=h.registry.create(); h.mounts[0].scope=EntityScriptScope{h.entities[0]};
        assert(h.system->mountResolvedBatch(h.mounts));
        assert(!h.system->processLifecycle());
        assert(na1::constructed==1U && na1::destroyed==1U && h.leases==0U);
        assert(h.probe.begins==1U && h.probe.ends==1U);
        h.closed();
        std::puts("CASE supplemental-content old-task-result=32 new-content-rejected=1 old-lease-balanced=1");
    }
'''
pos=s.rfind('\n}');s=s[:pos]+extra+s[pos:];target=out/'native_lua_tasks_supplemental.cpp';target.write_text(s)
commands=json.loads((d/'compile_commands.json').read_text(encoding='utf-8-sig'));item=next(x for x in commands if x['file'].replace('\\','/').endswith('/test/native_lua_tasks_test.cpp'))
cmd=item['command'];cmd=cmd.replace(item['file'],str(target).replace('\\','/'));cmd=re.sub(r'/Fo\S+', '/Fo'+(out/'supplemental.obj').as_posix(),cmd);cmd=re.sub(r'/Fd\S+', '/Fd'+(out/'supplemental-compile.pdb').as_posix(),cmd);cmd+=' /I"'+str(p.parent)+'"'
def run(name,command,cwd):
 with (out/(name+'.log')).open('wb') as f: code=subprocess.call(command,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 results.append(dict(name=name,command=command,cwd=str(cwd),exit=code));(out/'commands.json').write_text(json.dumps(results,indent=2)); print(name,code,flush=True);assert code==0
results=[];run('compile',cmd,d)
link=subprocess.check_output(['D:/Softwares/ninja-win/ninja.exe','-C',str(d),'-t','commands','simulation_script_native_lua_tasks_test'],text=True).splitlines()[-1]
link=link[link.index('link.exe')-len('D:\\Development\\Mircosoft\\VisualStudio\\VC\\Tools\\MSVC\\14.44.35207\\bin\\Hostx64\\x64\\'):];link=link.split(' && ')[0]
link=re.sub(r'engine\\domain\\simulation\\scripting\\native_lua_tasks\\CMakeFiles\\simulation_script_native_lua_tasks_test.dir\\test\\native_lua_tasks_test.cpp.obj',lambda m:(out/'supplemental.obj').as_posix(),link)
for key,name in [('out','supplemental.exe'),('implib','supplemental.lib'),('pdb','supplemental.pdb')]: link=re.sub('/'+key+r':\S+', '/'+key+':'+(out/name).as_posix(),link)
run('link',link,d)
os.environ['PATH']=str(d/'bin')+';E:/SyncForder/CodeRepos/install/o/v4/lua55/bin;'+os.environ['PATH']
run('run',[str(out/'supplemental.exe')],out)
(out/'identity.json').write_text(json.dumps(dict(production='4a8812e9813fe90b241dba29e3e668e4a4239b26',source_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),base_test_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),kind='supplemental diagnostic; original qualified tests and production unmodified'),indent=2))
