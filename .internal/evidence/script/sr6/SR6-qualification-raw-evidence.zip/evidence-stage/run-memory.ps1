$ErrorActionPreference='Stop'
& 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/s6/memory-consumer.ps1'