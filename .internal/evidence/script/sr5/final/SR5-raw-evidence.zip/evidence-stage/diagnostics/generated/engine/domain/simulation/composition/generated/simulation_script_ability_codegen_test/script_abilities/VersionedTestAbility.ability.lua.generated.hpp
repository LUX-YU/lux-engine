#pragma once
// Generated typed Lua projection. Include the matching .ability.generated.hpp first.
#include <lux/engine/simulation/scripting/lua/LuaScriptAbilityProjection.hpp>

#include <array>
#include <type_traits>
#include <utility>

namespace lux::script::lua
{

    template <>
    struct ScriptAbilityLuaTraits<::versioned_test::Ability> final
    {
        using AbilityTraits = ScriptAbilityTraits<::versioned_test::Ability>;
        using Policy = typename ScriptAbilityLuaPolicy<::versioned_test::Ability>::Type;

        using Values_read = LuaAbilityValueSignature<Policy, int, int>;
        [[nodiscard]] static int read(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, int, int>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, int value) noexcept -> int
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.read(access.context, value);
                }
            );
        }

        inline static constexpr std::array<ScriptAbilityLuaMethodProjection, AbilityTraits::Methods.size()> Methods{
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.versioned.read"},
                &read, Values_read::Parameters, Values_read::Results
            }
        };
    };
} // namespace lux::script::lua
