from pathlib import Path
import hashlib,struct,shutil,json,subprocess
r=Path(__file__).parent
dev=r.parent/'o/w/d'; tool=r.parent/'o/w/t'
sha_source=subprocess.check_output(['git','-C',str(r/'local-source'),'rev-parse','HEAD'],text=True).strip()
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def imports(p):
    b=p.read_bytes();nt=struct.unpack_from('<I',b,60)[0]
    count=struct.unpack_from('<H',b,nt+6)[0];size=struct.unpack_from('<H',b,nt+20)[0];opt=nt+24
    directories=opt+(112 if struct.unpack_from('<H',b,opt)[0]==0x20b else 96)
    sections=[struct.unpack_from('<IIII',b,opt+size+i*40+8) for i in range(count)]
    def offset(rva):
        for vs,va,rs,raw in sections:
            if va<=rva<va+max(vs,rs):return raw+rva-va
        raise ValueError((p,rva))
    result=[]
    for index,stride,field in [(1,20,12),(13,32,4)]:
        address=struct.unpack_from('<I',b,directories+index*8)[0]
        if not address:continue
        at=offset(address)
        while any(b[at:at+stride]):
            name=struct.unpack_from('<I',b,at+field)[0]
            pos=offset(name);result.append(b[pos:b.index(0,pos)].decode('ascii'));at+=stride
    return result

def save(name,executables,roots):
 out=r/'images'/name;out.mkdir(exist_ok=False)
 queue=list(executables);saved={};system=[]
 while queue:
  name=queue.pop()
  if name.lower() in saved:continue
  p=next((root/name for root in roots if (root/name).is_file()),None)
  if p is None:
   assert not name.lower().startswith('lux_'),('Missing Lux dependency',name)
   system.append(name);continue
  shutil.copy2(p,out/name);saved[name.lower()]={'source':str(p),'sha256':sha(p)}
  if p.with_suffix('.pdb').exists():shutil.copy2(p.with_suffix('.pdb'),out/p.with_suffix('.pdb').name)
  queue+=imports(p)
 (out/'identity.json').write_text(json.dumps({'fixture_source':sha_source,'production_source':('f7d2815bdd2025ee23a7c11449def822413f58e9' if out.name.startswith('A') else sha_source),'images':saved,'system_imports':sorted(set(system))},indent=2))
 return out
vcpkg=Path('D:/Development/vcpkg/installed/x64-windows/bin')

save('E',['script_runtime_benchmark.exe','physics2d_script_benchmark.exe','simulation_script_native_lua_tasks_test.exe'],[dev/'bin',vcpkg])
save('E-flow',['flowforge_script_runtime_benchmark.exe'],[tool/'bin',dev/'bin',vcpkg])
sdk=Path('E:/SyncForder/CodeRepos/install/o/na1/local-sdk')
image=save('E-common',['native_lua_complete_tasks.exe'],[r/'benchmark-slots/B',sdk/'bin',Path('E:/SyncForder/CodeRepos/install/o/v4/lua55/bin'),vcpkg])
asset=r/'benchmark-slots/B/business.lxsa'
if not asset.exists():
 files=list((r/'benchmark-slots/B').rglob('business.lxsa'));assert len(files)==1;asset=files[0]
shutil.copy2(asset,image/asset.name)
assert sha(asset)==sha(r/'images/C-common/business.lxsa')
(image/'fixture-asset.json').write_text(json.dumps({'compiled_in_path':str(asset),'sha256':sha(asset),'source':sha_source},indent=2))
for root in ['D-common','D','D-flow','E-common','E','E-flow']:
 image=r/'images'/root;data=json.loads((image/'identity.json').read_text())
 for name,entry in data['images'].items():assert sha(image/name)==entry['sha256'],(root,name)
print('MATCHED_B0_B1_IMAGES_SAVED',sha_source)
