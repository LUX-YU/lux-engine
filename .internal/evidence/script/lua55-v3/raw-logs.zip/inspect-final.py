from pathlib import Path
import subprocess,os,json
r=Path(__file__).parent;out=r/'machine-code';out.mkdir(exist_ok=True)
image=r/'final-image';cdb=Path('C:/Program Files (x86)/Windows Kits/10/Debuggers/x64/cdb.exe')
env=dict(os.environ);env['PATH']=';'.join([str(image),'D:/Development/vcpkg/installed/x64-windows/bin',env['PATH']])
commands={
 'symbols': ['.reload /f lux_engine_function_script_lua.dll','x lux_engine_function_script_lua!*LuaPageAllocator*',
             '.reload /f lux_engine_simulation_script_lua.dll','x lux_engine_simulation_script_lua!*destroyContinuation*',
             '.reload /f lux_lua55.dll','uf lux_lua55!luxlua_vmleafstats','uf lux_lua55!luxlua_vmcallinfostats'],
 'codec-symbols':['.reload /f simulation_script_lua_value_runtime_test.exe',
                  'x simulation_script_lua_value_runtime_test!*ValuePose*writePlain*',
                  'x simulation_script_lua_value_runtime_test!*ValuePose*readPlain*']}
results=[]
for name,lines in commands.items():
 script=out/(name+'.txt');script.write_text('\n'.join(lines+['q'])+'\n')
 exe='simulation_script_lua_value_runtime_test.exe' if name.startswith('codec') else 'script_runtime_benchmark.exe'
 cmd=[str(cdb),'-y',str(image),'-cf',str(script),str(image/exe)]
 with (out/(name+'.log')).open('wb') as log:code=subprocess.call(cmd,stdout=log,stderr=subprocess.STDOUT,env=env)
 results.append(dict(command=cmd,exit=code,source='e06208deb29b9b1de52fe49a129091f693bb7e08',workload_executed=False))
(out/'commands.json').write_text(json.dumps(results,indent=2))
