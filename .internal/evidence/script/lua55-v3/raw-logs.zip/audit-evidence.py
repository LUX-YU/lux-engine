from pathlib import Path
import json,hashlib,subprocess,re
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/lua55-v3');repo=r.parent/'s5/source';old=r.parent/'lua55-v2'
records=[]
for item in json.loads((old/'fixed-dependency-additional-files.json').read_text()):
 p=Path('E:/SyncForder/CodeRepos/install/q2/c')/item['path'];ok=hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'];assert ok
 records.append(dict(path=str(p),sha256=item['sha256'],matches=True))
(r/'fixed-dependency-additional-files.json').write_text(json.dumps(records,indent=2))
for name in ['audit-public.py','work-oracles.py']:
 s=(old/name).read_text().replace('lua55-v2','lua55-v3').replace('a79141cbb64b1d23af5f697bb981f84707225b4a','10a70e80e6e2879ecb09f14ffc083516d0666752')
 (r/name).write_text(s)
# A bounded compile result, not a new timing microbenchmark.
frames={}
for side in ['before','after']:
 text=(r/f'sequence-frame-{side}.log').read_text()
 at=text.index('\n?run@CppSequenceScript@benchmark@simulation@lux@@QEAA?AVScriptCoroutine')
 block=text[at:at+1700]
 size=int(re.search(r'mov\s+edx,([0-9A-F]+)h',block)[1],16)
 frames[side]=dict(requested_frame_bytes=size,configured_maximum=512,disassembly=block)
assert frames['before']['requested_frame_bytes']==528 and frames['after']['requested_frame_bytes']<=512
(r/'sequence-frame-comparison.json').write_text(json.dumps(frames,indent=2));print({k:v['requested_frame_bytes'] for k,v in frames.items()})
