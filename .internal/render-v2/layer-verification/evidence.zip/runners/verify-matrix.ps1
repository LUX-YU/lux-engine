param([string]$Source, [string]$Root, [string]$Evidence)
$ErrorActionPreference='Stop'
foreach ($entry in @(@('r','RelWithDebInfo',''), @('d','Debug',''), @('a','RelWithDebInfo','/fsanitize=address /Zi'))) {
    $build=Join-Path $Root $entry[0]
    foreach($action in @('configure','build','build','test')) {
        & E:/RenderV2Rebuild/Layer/run.ps1 -Source $Source -Build $build -Action $action -Config $entry[1] -ExtraFlags $entry[2] -Evidence (Join-Path $Evidence $entry[0])
        if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
    }
}
