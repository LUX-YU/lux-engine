"""Read-only type layout / real container reservation probe. No runtime production patch."""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
r=Path(__file__).parent;source=r/'source';build=r.parent/'o/w/d';out=r/'layout';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
name='simulation_script_event_wait_test'
commands=subprocess.check_output(['ninja','-C',str(build),'-t','commands',name],text=True).splitlines()
original_compile=next(x for x in commands if ('/c ' in x or '-c ' in x) and name+'.dir' in x and '.cpp' in x)
original_link=next(x for x in reversed(commands) if 'vs_link_exe' in x and '/out:bin\\'+name+'.exe' in x).split(' -- ',1)[1].split(' && ',1)[0]
revisions={'A':'f7d2815bdd2025ee23a7c11449def822413f58e9','B':subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()}
paths=subprocess.check_output(['git','-C',str(source),'ls-files','engine/domain/simulation/builtin/script/pinclude'],text=True).splitlines()
paths += ['engine/domain/simulation/builtin/script/include/lux/engine/simulation/ScriptSystem.hpp',
 'engine/domain/simulation/scripting/core/include/lux/engine/simulation/scripting/ScriptRuntime.hpp',
 'engine/domain/simulation/scripting/core/sinclude/lux/engine/simulation/scripting/ScriptRuntimeAccess.hpp']
for side,revision in revisions.items():
 folder=out/side;folder.mkdir();inc=folder/'include';changes=[]
 for path in paths:
  if side=='A' and path.endswith('ScriptOperationStorage.hpp'):continue
  raw=subprocess.check_output(['git','-C',str(source),'show',revision+':'+path]).decode()
  # Access-label-only overlay, no type/member/algorithm change. Production files untouched.
  text=raw.replace('private:', 'public:')
  text=re.sub(r'(class Script(?:Execution|EventWaits|CompletionIngress|OperationStorage) final\s*\{)',r'\1\n    public:',text)
  target=inc/('lux/'+path.split('/lux/',1)[1]);target.parent.mkdir(parents=True,exist_ok=True);target.write_text(text)
  changes.append({'path':path,'original_sha256':hashlib.sha256(raw.encode()).hexdigest(),'probe_sha256':sha(target)})
 image=(r.parent/'script-v4' if side=='A' else r)/'final-image'
 for p in image.glob('*.dll'):shutil.copy2(p,folder/p.name)
 obj=folder/'layout.obj'
 command=original_compile.replace(' /nologo ',f' /nologo /I{inc} /DCELL_CANDIDATE={int(side=="B")} ',1)
 command=re.sub(r'/Fo\S+',lambda m:'/Fo'+str(obj),command)
 command=re.sub(r'/Fd\S+',lambda m:'/Fd'+str(folder/'layout.pdb'),command)
 command=re.sub(r'(?:E:[^ ]+)?script_system_event_wait_test.cpp',lambda m:str(r/'layout-probe.cpp'),command)
 # Source paths may have drive-case and slashes; replace the complete final /c operand.
 command=re.sub(r' /c .*$',lambda m:' /c '+str(r/'layout-probe.cpp'),command)
 link=re.sub(r'engine\\domain\\simulation\\builtin\\script\\CMakeFiles\\'+name+r'\.dir\\test\\\S+\.obj',lambda m:str(obj),original_link)
 link=link.replace('/out:bin\\'+name+'.exe','/out:'+str(folder/'layout.exe')).replace('/pdb:bin\\'+name+'.pdb','/pdb:'+str(folder/'layout-link.pdb'))
 link=link.replace('/implib:lib\\'+name+'.lib','/implib:'+str(folder/'layout.lib'))
 results=[]
 for stage,cmd in [('compile',['cmd','/d','/s','/c',command]),('link',['cmd','/d','/s','/c',link]),('run',[str(folder/'layout.exe')])]:
  env=dict(os.environ);env['PATH']=str(folder)+';D:/Development/vcpkg/installed/x64-windows/bin;'+env['PATH']
  with (folder/(stage+'.log')).open('wb') as f:code=subprocess.call(cmd,cwd=build,stdout=f,stderr=subprocess.STDOUT,env=env)
  results.append({'stage':stage,'command':cmd,'exit':code})
  (folder/'identity.json').write_text(json.dumps({'revision':revision,'headers':changes,'commands':results},indent=2))
  if code:raise SystemExit(f'{side} {stage} failed')
 print(side,(folder/'run.log').read_text(),flush=True)
