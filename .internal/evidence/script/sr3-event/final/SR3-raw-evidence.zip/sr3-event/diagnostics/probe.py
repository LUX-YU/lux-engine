import argparse, hashlib, json, os, re, shutil, subprocess
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('--build',required=True);p.add_argument('--source',required=True);p.add_argument('--output',required=True);p.add_argument('--executable')
a=p.parse_args();build=Path(a.build);source=Path(a.source);out=Path(a.output);out.mkdir(parents=True,exist_ok=False)
text=(source/'engine/domain/simulation/builtin/script/src/ScriptSystem.cpp').read_text()
hits={}
def replace(old,new,count=1):
 global text
 actual=text.count(old);assert actual==count,(old,actual,count)
 hits[old]=actual;text=text.replace(old,new)
fields=['candidates','hook_candidates','event_candidates','rejects','tickets','skips','waits','claims','copies','copy_rejects','terminals','pushes','pops','stale_pops','destroys','unlinks','active_cancels','errors','resume_completed','resume_suspended','resume_failed']
members=' '.join('std::uint64_t '+f+'{};' for f in fields)
fmt='PATH,%s,occ=%llu,'+','.join(f+'=%llu' for f in fields)+',steps=%llu,sync=%llu,resumes=%llu,queue=%zu,continuations=%zu,awaitables=%zu,waiters=%zu,retained=%zu,capacity=%zu,pins=%zu\n'
args=', '.join('diag.'+f for f in fields)
dump='''
        struct PathCounts { MEMBERS } diag;
        void dumpPath(const char* phase) const noexcept {
            std::printf(FORMAT, phase, event_occurrences, ARGS, step_invocations, sync_invocations,
                backend_resume_calls, resumes.count, continuations.size(), awaitables.size(), event_waiters.size(),
                failures.size(), failures.capacity(), instance_owner.protectedCount());
        }
'''.replace('MEMBERS',members).replace('FORMAT',json.dumps(fmt)).replace('ARGS',args)
replace('        struct UserInvocationScope final',dump+'\n        struct UserInvocationScope final')
text='#include <cstdio>\n'+text
replace('        void invoke(const Handler& handler, lux_script_call_frame& frame, bool hook_invocation) noexcept\n        {','        void invoke(const Handler& handler, lux_script_call_frame& frame, bool hook_invocation) noexcept\n        {\n            ++diag.candidates; if (hook_invocation) ++diag.hook_candidates; else ++diag.event_candidates;')
replace('            if (!access)\n                return;\n            const auto& method = access.method();','            if (!access) { ++diag.rejects; return; }\n            ++diag.tickets;\n            const auto& method = access.method();')
if 'const bool skip_hook' in text:
 replace('                return skip_hook;','                if (skip_hook) ++diag.skips;\n                return skip_hook;')
else:
 replace('                    continuations.find(continuationKey(flight.continuation)) != nullptr)\n                {\n                    return;', '                    continuations.find(continuationKey(flight.continuation)) != nullptr)\n                {\n                    ++diag.skips;\n                    return;')
replace('            event_waiter_high_water = (std::max)(event_waiter_high_water, event_waiters.size());','            ++diag.waits;\n            event_waiter_high_water = (std::max)(event_waiter_high_water, event_waiters.size());')
replace('                waiter->state = EEventWaiterState::CLAIMED;','                ++diag.claims;\n                waiter->state = EEventWaiterState::CLAIMED;')
replace('                copied = !is_invalid_frame && endpoint.payload_projection.copy(','                ++diag.copies;\n                copied = !is_invalid_frame && endpoint.payload_projection.copy(')
replace('            if (!copied || !still_live)\n            {','            if (!copied || !still_live)\n            {\n                ++diag.copy_rejects;')
replace('            record.state = state;','            ++diag.terminals;\n            record.state = state;')
replace('                static_cast<void>(resumes.push({record.instance, record.continuation, record.id}));','                ++diag.pushes;\n                static_cast<void>(resumes.push({record.instance, record.continuation, record.id}));')
replace('            return resumes.pop();','            auto result = resumes.pop();\n            if (result) ++diag.pops;\n            return result;')
begin = text.index('        [[nodiscard]] lux::cxx::expected<void, EScriptSystemError> resumeOne(ResumeRecord resume) noexcept')
end = text.index('            continuation->waiting_on = {};', begin)
prefix = text[begin:end]
assert prefix.count('return {};') == 4
instrumented = prefix.replace('if (stopping)\n                return {};', 'if (stopping) { ++diag.stale_pops; return {}; }')
instrumented = instrumented.replace('if (!outcome)\n                return {};', 'if (!outcome) { ++diag.stale_pops; return {}; }')
instrumented = instrumented.replace('                return {};', '                ++diag.stale_pops; return {};')
assert instrumented.count('++diag.stale_pops') == 4
hits['resumeOne pre-backend skipped-pop branches'] = 4
text = text[:begin] + instrumented + text[end:]
replace('            const auto continuation = *stored;','            ++diag.destroys;\n            const auto continuation = *stored;')
replace('            if (waiter->state == EEventWaiterState::ACTIVE)\n                unlinkEventWaiterRoute(*waiter);','            ++diag.unlinks;\n            if (waiter->state == EEventWaiterState::ACTIVE) { ++diag.active_cancels; unlinkEventWaiterRoute(*waiter); }')
replace('            instance_owner.recordError(slot, error);','            ++diag.errors;\n            instance_owner.recordError(slot, error);')
replace('            const auto slot = instance->mount_slot;\n            const auto symbol = instance_owner.methodSymbol(continuation->method_slot);','            if (result.state == EScriptStepState::COMPLETED && result.valid()) ++diag.resume_completed;\n            else if (result.state == EScriptStepState::SUSPENDED && result.valid()) ++diag.resume_suspended;\n            else ++diag.resume_failed;\n            const auto slot = instance->mount_slot;\n            const auto symbol = instance_owner.methodSymbol(continuation->method_slot);')
replace('        state_->instance_owner.writeStats(result);','        state_->dumpPath("SNAPSHOT");\n        state_->instance_owner.writeStats(result);')
replace('        if (state_ && state_->prepare_state != EPrepareState::SHUT_DOWN && !shutdown())\n            std::terminate();','        if (state_ && state_->prepare_state != EPrepareState::SHUT_DOWN && !shutdown())\n            std::terminate();\n        if (state_) state_->dumpPath("FINAL");')
(out/'ScriptSystem.cpp').write_text(text);(out/'hits.json').write_text(json.dumps(hits,indent=2))
db=json.loads((build/'compile_commands.json').read_text());entry=next(e for e in db if e['file'].endswith('/builtin/script/src/ScriptSystem.cpp'))
original=entry['file'].replace('/','\\');assert entry['command'].count(original)==1
command=entry['command'].replace(original,str(out/'ScriptSystem.cpp'))+f' /Fo"{out}/ScriptSystem.obj" /Fd"{out}/compiler.pdb"'
with (out/'compile.log').open('w') as log:subprocess.run(command,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
raw=subprocess.check_output(['ninja','-C',str(build),'-t','commands','bin/lux_engine_simulation_script.dll'],text=True).splitlines()[-1]
link=raw.split(' -- ',1)[1].split(' && ',1)[0]
old=r'engine\domain\simulation\builtin\script\CMakeFiles\simulation_script.dir\src\ScriptSystem.cpp.obj'
assert link.count(old)==1;link=link.replace(old,str(out/'ScriptSystem.obj'))
for option,old_path,new_path in [('out',r'bin\lux_engine_simulation_script.dll','lux_engine_simulation_script.dll'),('implib',r'lib\lux_engine_simulation_script.lib','diagnostic.lib'),('pdb',r'bin\lux_engine_simulation_script.pdb','diagnostic.pdb')]:
 needle=f'/{option}:{old_path}';assert link.count(needle)==1;link=link.replace(needle,f'/{option}:{out/new_path}')
with (out/'link.log').open('w') as log:subprocess.run(link,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
base=Path('E:/SyncForder/CodeRepos');exe=out/'flowforge_script_runtime_benchmark.exe'
shutil.copy2(Path(a.executable) if a.executable else base/'build/RelWithDebInfo/sr3-c3/t/bin'/exe.name,exe)
env=dict(os.environ);env['PATH']=str(base/'install/sr3-c3/t/bin')+';D:/Development/vcpkg/installed/x64-windows/bin;'+env['PATH']
run=[str(exe),'--group','scene-flowforge-event','--mode','performance','--size','10000','--warmups','60','--frames','300','--seed','1592598566','--resume-budget','2000','--output',str(out/'work.csv')]
with (out/'path.log').open('w') as log:subprocess.run(run,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
rows=[]
for line in (out/'path.log').read_text().splitlines():
 if line.startswith('PATH,'):
  parts=line.split(',');rows.append({'phase':parts[1]}|{k:int(v) for k,v in (part.split('=') for part in parts[2:])})
before=next(r for r in rows if r['occ']==60 and r['phase']=='SNAPSHOT')
after=next(r for r in rows if r['occ']==360 and r['phase']=='SNAPSHOT')
final=next(r for r in rows if r['phase']=='FINAL')
delta={k:after[k]-before[k] for k in before if k!='phase'}
assert delta['candidates']==3000000 and delta['skips']==2400000 and delta['steps']==delta['resumes']==600000
assert delta['hook_candidates']==3000000 and delta['event_candidates']==delta['stale_pops']==0
assert delta['waits']==delta['claims']==delta['copies']==delta['terminals']==delta['pushes']==delta['pops']==delta['destroys']==600000
assert delta['errors']==0 and after['queue']==8000 and final['queue']==final['continuations']==final['awaitables']==final['waiters']==final['pins']==0
identity={'source':str(source),'source_sha':subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip(),'compile':command,'link':link,'command':run,'dll_sha256':hashlib.sha256((out/'lux_engine_simulation_script.dll').read_bytes()).hexdigest(),'exe_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'before':before,'after':after,'delta':delta,'final':final,'limitation':'Instrumented private copy, no public ABI additions. Timing invalid; counters include only changes between actual occurrence snapshots.'}
(out/'results.json').write_text(json.dumps(identity,indent=2));print(json.dumps(identity['delta'],indent=2))
