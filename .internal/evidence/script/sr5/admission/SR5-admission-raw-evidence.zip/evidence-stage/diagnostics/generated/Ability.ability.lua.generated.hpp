#pragma once
// Generated typed Lua projection. Include the matching .ability.generated.hpp first.
#include <lux/engine/simulation/scripting/lua/LuaScriptAbilityProjection.hpp>

#include <array>
#include <type_traits>
#include <utility>

namespace lux::script::lua
{

    template <>
    struct ScriptAbilityLuaTraits<::ValueAbility> final
    {
        using AbilityTraits = ScriptAbilityTraits<::ValueAbility>;
        using Policy = typename ScriptAbilityLuaPolicy<::ValueAbility>::Type;

        using Values_echo = LuaAbilityValueSignature<Policy, Item, const Item &>;
        [[nodiscard]] static int echo(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, Item, const Item &>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, const Item & item) noexcept -> Item
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.echo(access.context, item);
                }
            );
        }

        inline static constexpr std::array<ScriptAbilityLuaMethodProjection, AbilityTraits::Methods.size()> Methods{
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"consumer.values.echo"},
                &echo, Values_echo::Parameters, Values_echo::Results
            }
        };
    };
} // namespace lux::script::lua
