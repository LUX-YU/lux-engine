from pathlib import Path
b=Path('E:/RenderV2Rebuild/Layer/source/modules/function/render')
p=b/'resource/include/lux/engine/render/resource/Registration.hpp';s=p.read_text().replace('(*bind_native)(void*)','(*bind_native)(CommandHandler, void*)');p.write_text(s)
p=b/'native/vulkan/include/lux/engine/render/native/vulkan/Registration.hpp';s=p.read_text().replace('[](void* owner) noexcept {','[](CommandHandler, void* owner) noexcept {');p.write_text(s)
p=b/'runtime/src/RenderServer.cpp';s=p.read_text().replace('entry.binding.bind_native(s.device.get())','entry.binding.bind_native(entry.binding, s.device.get())');p.write_text(s)
p=b/'runtime/test/BufferExtension.hpp';s=p.read_text().replace('#include <lux/engine/render/resource/Registration.hpp>','#include <lux/engine/render/native/vulkan/Registration.hpp>')
for fn,cmd in [('setBuffer','SetBuffer'),('removeBuffer','RemoveBuffer'),('readBuffer','ReadBuffer')]:
 s=s.replace('RenderResult<void> '+fn+'(void* native, CommandInvocation& invocation) noexcept','RenderResult<void> '+fn+'(vk::DeviceSession& session, const '+cmd+'::Request& input,\n        CommandContext<'+cmd+'>& context) noexcept').replace('        CommandContext<'+cmd+'> context(invocation);\n','')
s=s.replace('        const auto& input = context.request();\n','').replace('        auto& session = *static_cast<vk::DeviceSession*>(native);\n','').replace('static_cast<vk::DeviceSession*>(native)->resources()','session.resources()').replace('reserve(invocation, session.queue(), &response)','reserve(context, session.queue(), response)')
a=s.index('            CommandHandler{');z=s.index('\n        };',a);s=s[:a]+'''            vk::nativeCommand<SetBuffer, setBuffer>(),
            vk::nativeCommand<RemoveBuffer, removeBuffer>(),
            vk::nativeCommand<ReadBuffer, readBuffer>()'''+s[z:];p.write_text(s)
# Legacy low-level fault-injection fixtures retain their exact behavior while testing raw boundaries.
# This helper is test-only; new normal-path coverage uses bindCommand/nativeCommand.
(b/'runtime/test/ErasedRegistrationFixture.hpp').write_text('''#pragma once

#include <lux/engine/render/resource/Registration.hpp>

namespace lux::render::test_registration
{
    enum class EOwner { PROVIDED, DEVICE_SESSION };

    inline CommandRegistration erased(
        const CommandDescriptor* descriptor,
        RenderResult<void> (*invoke)(void*, CommandInvocation&) noexcept,
        void* user = nullptr, EOwner owner = EOwner::PROVIDED, bool gpu = false
    ) noexcept
    {
        CommandRegistration result{CommandHandler{descriptor, invoke, user}};
        result.gpu_completion = gpu;
        if (owner == EOwner::DEVICE_SESSION)
            result.bind_native = [](CommandHandler handler, void* device) noexcept {
                handler.user = device;
                return handler;
            };
        return result;
    }
}
''')
for p in (b/'runtime/test').rglob('*'):
 if p.suffix not in ('.cpp','.hpp') or p.name=='ErasedRegistrationFixture.hpp':continue
 s=p.read_text();t=s
 # Balanced braces change construction to a test-only function, preserving lambdas.
 offset=0
 while True:
  a=t.find('CommandHandler{',offset)
  if a<0:break
  start=a+len('CommandHandler');depth=1;i=start+1
  while depth:
   depth+=(t[i]=='{')-(t[i]=='}');i+=1
  t=t[:a]+'test_registration::erased('+t[start+1:i-1]+')'+t[i:];offset=a+len('test_registration::erased(')
 t=t.replace('ECommandOwner::','test_registration::EOwner::').replace('std::array<CommandHandler,','std::array<CommandRegistration,').replace('std::array<lux::render::CommandHandler,','std::array<lux::render::CommandRegistration,')
 if p.name=='Provider.cpp':t=t.replace('host.handlers[0] = {&commands[0], async_tail_test::invoke, &host};','host.handlers[0] = test_registration::erased(&commands[0], async_tail_test::invoke, &host);')
 if t!=s:
  rel='../ErasedRegistrationFixture.hpp' if p.parent.name=='async_tail' else 'ErasedRegistrationFixture.hpp'
  t='#include "'+rel+'"\n'+t;p.write_text(t)
# Test factories retain raw malformed-metadata coverage, but supply exact Config/Ops credentials.
p=b/'resource/test/Registry.cpp';s=p.read_text().replace('            }, {}\n        };','            }, {}, nullptr, nullptr, storageCppType<unsigned>(), storageCppType<TestStorage::Ops>()\n        };');p.write_text(s)
p=b/'resource/test/Storage.cpp';s=p.read_text().replace('        }, {}\n    };','        }, {}, nullptr, nullptr, storageCppType<unsigned>(), storageCppType<Ops>()\n    };');p.write_text(s)
p=b/'native/vulkan/test/BufferStorageFixture.hpp';s=p.read_text().replace('            }, {}, &bindings\n','            }, {}, &bindings, nullptr, storageCppType<Config>(), storageCppType<decltype(size)>()\n');p.write_text(s)
p=b/'native/vulkan/test/MemoryCost.cpp';s=p.read_text().replace('}, [](const void*, const void*) noexcept { return true; }};','}, [](const void*, const void*) noexcept { return true; }, {}, nullptr, nullptr,\n                    storageCppType<unsigned>(), storageCppType<unsigned>()};');p.write_text(s)
# Snapshot runner copies, never modify historical runners.
r=Path('E:/RenderV2Rebuild/Layer/run.ps1');s=Path('E:/RenderV2Rebuild/V11/runners/run.ps1').read_text().replace('C:/Users/chenh/.codex/worktrees/render-v11-s1s2/lux-engine','E:/RenderV2Rebuild/Layer/source').replace('E:/RenderV2Rebuild/V11/build/release','E:/RenderV2Rebuild/Layer/build/release').replace('E:/RenderV2Rebuild/V11/evidence','E:/RenderV2Rebuild/Layer/evidence/build').replace('--output-on-failure -j 1 -R','-V --output-on-failure -j 1 -R');r.write_text(s)
