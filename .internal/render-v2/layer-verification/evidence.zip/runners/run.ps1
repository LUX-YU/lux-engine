param(
    [string]$Source = 'E:/RenderV2Rebuild/Layer/source',
    [string]$Build = 'E:/RenderV2Rebuild/Layer/build/release',
    [string]$Action = 'configure',
    [string]$Config = 'RelWithDebInfo',
    [string]$ExtraFlags = '',
    [string]$Filter = '.',
    [string]$Evidence = 'E:/RenderV2Rebuild/Layer/evidence/build'
)
$ErrorActionPreference = 'Stop'
if (-not $env:VSCMD_VER) { & 'D:/Softwares/MicroSoft/VS/2022/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation }
$env:Path = "D:/DevTools/vcpkg/downloads/tools/cmake-3.31.10-windows/cmake-3.31.10-windows-x86_64/bin;D:/Softwares/ninja;D:/Softwares/VulkanSDK/1.3.280.0/Bin;$env:Path"
$env:VULKAN_SDK = 'D:/Softwares/VulkanSDK/1.3.280.0'
$env:ASAN_OPTIONS = 'alloc_dealloc_mismatch=1'
New-Item -ItemType Directory -Force $Evidence | Out-Null
$log = Join-Path $Evidence "$Action-$Config-$(Get-Date -Format yyyyMMdd-HHmmss-fff).log"
"Source=$Source Build=$Build Action=$Action Config=$Config Flags=$ExtraFlags Filter=$Filter" | Tee-Object $log
switch ($Action) {
    'configure' {
        & cmake -S "$Source/cmake/render-v2-bootstrap" -B $Build -G Ninja `
            "-DCMAKE_BUILD_TYPE=$Config" -DBUILD_TESTING=ON `
            -Dlux-cmake-toolset_DIR=E:/SyncForder/CodeRepos/lux-cmake-toolset `
            -Dlux-cxx_DIR=E:/RenderV2Rebuild/G3/dependencies/share/lux-cxx `
            -Dstdexec_DIR=D:/DevTools/vcpkg/installed/x64-windows/share/stdexec `
            "-DCMAKE_CXX_FLAGS=/EHsc $ExtraFlags" -DCMAKE_CXX_SCAN_FOR_MODULES=OFF `
            -DCMAKE_FIND_USE_PACKAGE_REGISTRY=OFF -DCMAKE_FIND_USE_SYSTEM_PACKAGE_REGISTRY=OFF `
            "-DCMAKE_INSTALL_PREFIX=$Build/sdk" 2>&1 | Tee-Object -Append $log
    }
    'build' { & cmake --build $Build --target all -j 4 -- -k 0 2>&1 | Tee-Object -Append $log }
    'test' { & ctest --test-dir $Build -V --output-on-failure -j 1 -R $Filter 2>&1 | Tee-Object -Append $log }
    'snapshot' { & cmake "-DLUX_SOURCE_DIR=$Source" -P "$Source/cmake/ValidateTrackedSnapshot.cmake" 2>&1 | Tee-Object -Append $log }
    'root-configure' {
        & cmake -S $Source -B $Build -G Ninja "-DCMAKE_BUILD_TYPE=$Config" `
            -DCMAKE_PREFIX_PATH=E:/SyncForder/CodeRepos/install/RelWithDebInfo `
            -DCMAKE_TOOLCHAIN_FILE=D:/DevTools/vcpkg/scripts/buildsystems/vcpkg.cmake `
            -DBUILD_TESTING=ON -DLUX_BUILD_PROFILE=TOOLCHAIN `
            -DLUX_SPIRV_TOOLS_SHARED=D:/Softwares/VulkanSDK/1.3.280.0/Lib/SPIRV-Tools-shared.lib `
            -DLUX_SPIRV_TOOLS_INCLUDE=D:/Softwares/VulkanSDK/1.3.280.0/Include 2>&1 | Tee-Object -Append $log
    }
    default { throw "Unknown action $Action" }
}
$code = $LASTEXITCODE
"EXIT=$code" | Tee-Object -Append $log
if ($Action -eq 'test') {
    $testLog = Join-Path $Build 'Testing/Temporary/LastTest.log'
    if (Test-Path -LiteralPath $testLog) { Copy-Item -LiteralPath $testLog -Destination "$log.ctest.txt" }
    $sampleRoot = "$log.samples"
    foreach ($sample in Get-ChildItem -LiteralPath $Build -Filter '*.csv' -Recurse -File) {
        $relative = [IO.Path]::GetRelativePath($Build, $sample.FullName)
        $target = Join-Path $sampleRoot $relative
        New-Item -ItemType Directory -Force (Split-Path -Parent $target) | Out-Null
        Copy-Item -LiteralPath $sample.FullName -Destination $target
    }
}
exit $code

