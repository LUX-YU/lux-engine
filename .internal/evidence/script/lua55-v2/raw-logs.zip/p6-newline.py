from pathlib import Path
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source')
p=r/'cmake/dependencies/lua55/patches/leaf-yield-r1.patch';p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
p=r/'cmake/dependencies/lua55/apply_leaf.py';t=p.read_text().replace('if out.exists():\n manifest=',"if (out/'.lux-patch.json').exists():\n manifest=")
t=t.replace('shutil.copytree(o,out)','''if out.exists():
 actual={str(f.relative_to(out)):hashlib.sha256(f.read_bytes()).hexdigest() for f in out.rglob('*') if f.is_file()}
 if actual!=identity['files']: raise SystemExit('Incomplete patch tree is not a pristine official copy')
 print('VERIFIED_PRISTINE_RETRY')
else: shutil.copytree(o,out)''');p.write_text(t)
