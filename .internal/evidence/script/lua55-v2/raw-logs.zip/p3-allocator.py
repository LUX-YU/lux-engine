from pathlib import Path
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source')
def put(p,s): (r/p).write_text(s,encoding='utf-8')
def edit(p,a,b):
 t=(r/p).read_text(); assert a in t,p; (r/p).write_text(t.replace(a,b),encoding='utf-8')
base='modules/function/script/lua/'
put(base+'include/lux/engine/function/script/lua/LuaAllocation.hpp','''#pragma once
#include <array>
#include <cstddef>
#include <cstdint>

namespace lux::script::lua
{
    enum class ELuaGcMode : std::uint8_t { INCREMENTAL, GENERATIONAL };
    enum class ELuaGcParameter : std::uint8_t
    {
        MINOR_MULTIPLIER, MAJOR_TO_MINOR, MINOR_TO_MAJOR, PAUSE, STEP_MULTIPLIER, STEP_SIZE
    };
    struct LuaVmConfiguration final
    {
        std::size_t cache_bytes{16U * 1024U * 1024U};
        unsigned seed{1592598566U};
        ELuaGcMode gc_mode{ELuaGcMode::GENERATIONAL};
        // Indexed by ELuaGcParameter; -1 preserves the upstream value.
        std::array<int, 6U> gc_parameters{-1, -1, -1, -1, -1, -1};
        bool track_allocations{};
    };
    struct LuaAllocationStats final
    {
        bool enabled{};
        std::uint64_t allocations{}, reallocations{}, frees{}, failures{};
        std::uint64_t requested_bytes{}, released_bytes{};
        std::uint64_t system_allocations{}, system_frees{}, cache_hits{}, in_place{};
        std::size_t live_bytes{}, peak_live_bytes{}, retained_bytes{}, peak_retained_bytes{};
    };
}
''')
put(base+'pinclude/lux/engine/function/script/lua/LuaAllocationCache.hpp','''#pragma once
#include <lux/engine/function/script/lua/LuaAllocation.hpp>
#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <limits>

namespace lux::script::lua
{
    // Only VM-freed memory enters these lists. No live thread/object is reused.
    class LuaAllocationCache final
    {
        struct alignas(std::max_align_t) Block final
        {
            std::size_t capacity, requested, index;
            Block* next;
        };
        // Observed Lua55 coroutine requests: 64 (CallInfo), 216 (thread), 720 (stack).
        static constexpr std::array<std::size_t, 8U> classes_{32U, 64U, 128U, 224U, 512U, 736U, 1536U, 4096U};
    public:
        explicit LuaAllocationCache(LuaVmConfiguration config) noexcept : budget_(config.cache_bytes)
        {
            stats_.enabled = config.track_allocations;
        }
        ~LuaAllocationCache() { clear(); }
        LuaAllocationCache(const LuaAllocationCache&) = delete;
        LuaAllocationCache& operator=(const LuaAllocationCache&) = delete;
        [[nodiscard]] LuaAllocationStats stats() const noexcept { return stats_; }
        // Diagnostic injection is deliberately below the logical Lua request layer.
        void failSystemAfter(std::size_t requests) noexcept { permitted_system_ = requests; }
        void clear() noexcept
        {
            for (auto& head : free_)
                while (head)
                {
                    auto* block = head;
                    head = head->next;
                    std::free(block);
                    ++stats_.system_frees;
                }
            stats_.retained_bytes = 0U;
        }
        static void* allocate(void* context, void* pointer, std::size_t, std::size_t size) noexcept
        {
            return static_cast<LuaAllocationCache*>(context)->resize(pointer, size);
        }
    private:
        Block* acquire(std::size_t size) noexcept
        {
            std::size_t index{};
            while (index < classes_.size() && size > classes_[index]) ++index;
            const auto capacity = index < classes_.size() ? classes_[index] : size;
            if (index < classes_.size() && free_[index])
            {
                auto* block = free_[index];
                free_[index] = block->next;
                stats_.retained_bytes -= sizeof(Block) + block->capacity;
                ++stats_.cache_hits;
                return block;
            }
            if (capacity > (std::numeric_limits<std::size_t>::max)() - sizeof(Block)) return nullptr;
            if (permitted_system_ == 0U) return nullptr;
            if (permitted_system_ != (std::numeric_limits<std::size_t>::max)()) --permitted_system_;
            auto* block = static_cast<Block*>(std::malloc(sizeof(Block) + capacity));
            if (!block) return nullptr;
            *block = {capacity, size, index, nullptr};
            ++stats_.system_allocations;
            return block;
        }
        void release(Block* block) noexcept
        {
            const auto bytes = sizeof(Block) + block->capacity;
            const bool fits = block->index < classes_.size() && bytes <= budget_ - stats_.retained_bytes;
            if (fits)
            {
                block->next = free_[block->index];
                free_[block->index] = block;
                stats_.retained_bytes += bytes;
                stats_.peak_retained_bytes = (std::max)(stats_.peak_retained_bytes, stats_.retained_bytes);
            }
            else
            {
                std::free(block);
                ++stats_.system_frees;
            }
        }
        void* resize(void* pointer, std::size_t size) noexcept
        {
            auto* old = pointer ? static_cast<Block*>(pointer) - 1 : nullptr;
            const auto old_size = old ? old->requested : 0U;
            if (size == 0U)
            {
                if (old)
                {
                    stats_.live_bytes -= old_size;
                    if (stats_.enabled) { ++stats_.frees; stats_.released_bytes += old_size; }
                    release(old);
                }
                return nullptr;
            }
            Block* block = old;
            if (old && size <= old->capacity) ++stats_.in_place;
            else
            {
                block = acquire(size);
                if (!block) { ++stats_.failures; return nullptr; }
                if (old)
                {
                    std::memcpy(block + 1, old + 1, (std::min)(old_size, size));
                    release(old);
                }
            }
            block->requested = size;
            stats_.live_bytes = stats_.live_bytes - old_size + size;
            stats_.peak_live_bytes = (std::max)(stats_.peak_live_bytes, stats_.live_bytes);
            if (stats_.enabled)
            {
                if (pointer) ++stats_.reallocations; else ++stats_.allocations;
                stats_.requested_bytes += size;
                stats_.released_bytes += old_size;
            }
            return block + 1;
        }
        std::array<Block*, classes_.size()> free_{};
        std::size_t budget_{};
        std::size_t permitted_system_{(std::numeric_limits<std::size_t>::max)()};
        LuaAllocationStats stats_;
    };
}
''')
edit(base+'include/lux/engine/function/script/lua/Lua.hpp','#include <string_view>','#include <string_view>\n#include <lux/engine/function/script/lua/LuaAllocation.hpp>')
edit(base+'include/lux/engine/function/script/lua/Lua.hpp','        ScriptEngine();','        explicit ScriptEngine(LuaVmConfiguration configuration = {});\n        [[nodiscard]] LuaAllocationStats allocationStats() const noexcept;')
edit(base+'include/lux/engine/function/script/lua/LuaBoundary.h','LUX_FUNCTION_PUBLIC int luxLuaBoundaryEntry','/* Protected VM bootstrap; explicit libraries, with no owning C++ locals. */\nLUX_FUNCTION_PUBLIC int luxLuaBootstrap(lua_State* state);\nLUX_FUNCTION_PUBLIC int luxLuaBoundaryEntry')
edit(base+'src/LuaBoundary.c','#include <lauxlib.h>','#include <lauxlib.h>\n#include <lualib.h>\n\nint luxLuaBootstrap(lua_State* state)\n{\n    const int libraries = LUA_GLIBK | LUA_LOADLIBK | LUA_COLIBK | LUA_DBLIBK | LUA_IOLIBK |\n        LUA_MATHLIBK | LUA_OSLIBK | LUA_STRLIBK | LUA_TABLIBK | LUA_UTF8LIBK;\n    luaL_openselectedlibs(state, libraries, 0);\n    return 0;\n}')
edit(base+'pinclude/lux/engine/function/script/lua/LuaImpl.hpp','#include <lua.hpp>','#include <lua.hpp>\n#include <lux/engine/function/script/lua/LuaAllocationCache.hpp>\n#include <lux/engine/function/script/lua/LuaBoundary.h>')
edit(base+'pinclude/lux/engine/function/script/lua/LuaImpl.hpp','''        ScriptEngineImpl()
        {
            L_ = luaL_newstate();
            if (L_)
                luaL_openlibs(L_);
        }''','''        explicit ScriptEngineImpl(LuaVmConfiguration config) : allocator_(config)
        {
            const bool invalid_mode = config.gc_mode != ELuaGcMode::INCREMENTAL &&
                config.gc_mode != ELuaGcMode::GENERATIONAL;
            if (invalid_mode || std::ranges::any_of(config.gc_parameters, [](int value) { return value < -1; }))
                return;
            L_ = lua_newstate(&LuaAllocationCache::allocate, &allocator_, config.seed);
            if (!L_) return;
            lua_pushcfunction(L_, &luxLuaBootstrap);
            if (lua_pcall(L_, 0, 0, 0) != LUA_OK)
            {
                lua_close(L_);
                L_ = nullptr;
                return;
            }
            lua_gc(L_, config.gc_mode == ELuaGcMode::GENERATIONAL ? LUA_GCGEN : LUA_GCINC);
            for (int index{}; index < LUA_GCPN; ++index)
                if (config.gc_parameters[index] != -1) lua_gc(L_, LUA_GCPARAM, index, config.gc_parameters[index]);
        }
        [[nodiscard]] LuaAllocationStats allocationStats() const noexcept { return allocator_.stats(); }''')
edit(base+'pinclude/lux/engine/function/script/lua/LuaImpl.hpp','        lua_State* L_ = nullptr;','        LuaAllocationCache allocator_; // Construct before VM; destroy after lua_close.\n        lua_State* L_ = nullptr;')
edit(base+'src/Lua.cpp','    ScriptEngine::ScriptEngine() : impl_(std::make_unique<ScriptEngineImpl>())','    ScriptEngine::ScriptEngine(LuaVmConfiguration config) : impl_(std::make_unique<ScriptEngineImpl>(config))')
edit(base+'src/Lua.cpp','    ScriptEngine::~ScriptEngine()','    LuaAllocationStats ScriptEngine::allocationStats() const noexcept { return impl_->allocationStats(); }\n\n    ScriptEngine::~ScriptEngine()')
h='engine/domain/simulation/scripting/lua/include/lux/engine/simulation/scripting/lua/LuaScriptBackend.hpp'
t=(r/h).read_text(); t=t.replace('#pragma once','#pragma once\n#include <lux/engine/function/script/lua/LuaAllocation.hpp>'); a=t.index('    struct LuaVmAllocationStats final'); b=t.index('    struct LuaScriptBackendStats final',a); t=t[:a]+t[b:]; t=t.replace('        LuaVmAllocationStats vm_allocations;','        lux::script::lua::LuaAllocationStats vm_allocations;').replace('        bool track_vm_allocations{};','        bool track_vm_allocations{};\n        lux::script::lua::LuaVmConfiguration vm;'); put(h,t)
p='engine/domain/simulation/scripting/lua/src/LuaScriptBackend.cpp'; t=(r/p).read_text(); a=t.index('        struct VmAllocationTracker final'); b=t.index('        static constexpr std::size_t kMaxAbilityArguments',a); t=t[:a]+t[b:]; a=t.index('            if (config.track_vm_allocations'); b=t.index('            if (!lux::script::lua::detail::configureLuaVm(',a); t=t[:a]+t[b:]; t=t.replace(': state(engine.state()),',': engine([&config] { auto vm = config.vm; vm.track_allocations |= config.track_vm_allocations; return vm; }()),\n              state(engine.state()),'); t=t.replace('        // Must outlive ScriptEngine: lua_close may call the original allocator through this diagnostic wrapper.\n        VmAllocationTracker vm_allocations;\n',''); t=t.replace('state_->vm_allocations.stats','state_->engine.allocationStats()'); put(p,t)
