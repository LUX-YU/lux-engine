from pathlib import Path
r=Path(__file__).parent/'source'
def edit(path, pairs):
 p=r/path
 t=p.read_text(encoding='utf-8')
 for old,new in pairs:
  assert t.count(old)==1,(path,old[:100],t.count(old))
  t=t.replace(old,new)
 p.write_text(t,encoding='utf-8',newline='\n')
c='engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/'
edit('engine/domain/simulation/scripting/core/include/lux/engine/simulation/scripting/ScriptEndpointBridge.hpp',[
('''            return {system_, id_, route,
''','''            auto copy = payload_copy_ != nullptr ? &copyPayload<false> : nullptr;
            if constexpr (detail::defaultEventPayloadCopy<Payload>() != nullptr)
            {
                if (payload_copy_ == detail::defaultEventPayloadCopy<Payload>())
                    copy = &copyPayload<true>;
            }
            return {system_, id_, route,
'''),
('{detail::eventPayloadLayout<Payload>(), payload_copy_ != nullptr ? &copyPayload : nullptr}',
 '{detail::eventPayloadLayout<Payload>(), copy}'),
('''        static bool copyPayload(void* context, const lux_script_value_slot& input, std::span<std::byte> output) noexcept
        {
            const auto& endpoint = self(context);
            using Traits = lux::semantic::TypeTraits<Payload>;
            const bool invalid = input.data == nullptr || input.kind != Traits::AbiKind ||
                input.type_id != lux::semantic::typeId(Traits::CanonicalName) || input.size != Traits::Size ||
                output.size() != Traits::Size || endpoint.payload_copy_ == nullptr;
            return !invalid && endpoint.payload_copy_(*static_cast<const Payload*>(input.data), output);
        }''',
'''        template <bool DefaultScalar>
        static bool copyPayload(void* context, const lux_script_value_slot& input, std::span<std::byte> output) noexcept
        {
            using Traits = lux::semantic::TypeTraits<Payload>;
            constexpr auto type = lux::semantic::typeId(Traits::CanonicalName);
            const bool is_invalid_input = input.data == nullptr || input.kind != Traits::AbiKind ||
                input.type_id != type || input.size != Traits::Size || output.size() != Traits::Size;
            if (is_invalid_input)
                return false;
            if constexpr (DefaultScalar)
            {
                std::memcpy(output.data(), input.data, sizeof(Payload));
                return true;
            }
            else
            {
                // The immutable callback was selected when this descriptor was prepared.
                return self(context).payload_copy_(*static_cast<const Payload*>(input.data), output);
            }
        }''')])
edit(c+'ScriptInstances.hpp',[
('''        std::uint32_t endpoint{};
        PreparedResumeType payload;
        ScriptInstanceScope scope;''',
'''        // Owner protection covers the whole registration transaction. Neither
        // reservation nor source commit executes user code or moves these arrays.
        const PreparedScriptEventAdmission* source{};
        const ScriptInstanceScope* scope{};'''),
('return ScriptEventSourceAccess{source.endpoint_slot, source.payload, mount.scope};',
 'return ScriptEventSourceAccess{&source, &mount.scope};')])
edit(c+'ScriptExecution.hpp',[
('''        struct AwaitableRecord final
        {
''','''        struct AwaitableRecord final
        {
            AwaitableRecord(ScriptInstanceId owner, std::optional<PreparedResumeType> type, bool external) noexcept
                : instance(owner), result_type(std::move(type)), external_completion(external) {}
'''),
('''            auto inserted = awaitables_.tryEmplacePrepared(AwaitableRecord{
                {},
                owner.id,
                {},
                EScriptAwaitableState::PENDING,
                std::move(result_type),
                {},
                {},
                false,
                external_completion
            });''',
'''            auto inserted = awaitables_.tryEmplacePrepared(owner.id, std::move(result_type), external_completion);'''),
('const auto endpoint_slot = source->endpoint;', 'const auto endpoint_slot = source->source->endpoint_slot;'),
('std::get_if<EntityScriptScope>(&source->scope)', 'std::get_if<EntityScriptScope>(source->scope)'),
('admitAwaitable(*owner, source->payload, false)', 'admitAwaitable(*owner, source->source->payload, false)'),
('''        struct AwaitableOutcome final
        {
''','''        struct AwaitableOutcome final
        {
            AwaitableOutcome(EScriptAwaitableState result_state, ScriptOwnedResumeValue&& result,
                ScriptStepError result_error) noexcept
                : state(result_state), value(std::move(result)), error(result_error) {}
'''),
('return awaitables_.erase(awaitableKey(id));','return awaitables_.erase(AwaitableKey{id.slot - 1U, id.generation});'),
('const auto key = awaitableKey(record.id);', 'const AwaitableKey key{record.id.slot - 1U, record.id.generation};'),
('''        [[nodiscard]] std::optional<AwaitableOutcome>
        takeAwaitable(ResumeRecord resume, ExecutionAccess access) noexcept''',
'''        [[nodiscard]] bool takeAwaitable(
            ResumeRecord resume, ExecutionAccess access, std::optional<AwaitableOutcome>& outcome
        ) noexcept'''),
('''                return std::nullopt;
            }
            AwaitableOutcome outcome{record->state, std::move(record->value), record->error};
            static_cast<void>(eraseAwaitableRecord(*record, access));
            return outcome;''',
'''                return false;
            }
            outcome.emplace(record->state, std::move(record->value), record->error);
            static_cast<void>(eraseAwaitableRecord(*record, access));
            return true;'''),
('''            auto outcome = takeAwaitable(resume, execution);
            if (!outcome)''',
'''            std::optional<AwaitableOutcome> outcome;
            if (!takeAwaitable(resume, execution, outcome))'''),
('''            releaseSource(*record);
            const auto completed = finishAwaitableOwner(*record, EScriptAwaitableState::READY, nullptr, {});''',
'''            releaseSource(*record);
            const auto completed = finishPreparedEvent(*record);'''),
('''    public:
        void completeClaimedEventWaiter''',
'''        // A prepared Event has already copied into its owned layout and released
        // its source. Copy may reenter: terminal state and queue capacity are dynamic.
        [[nodiscard]] lux::cxx::expected<void, EScriptAwaitableCompletionError>
        finishPreparedEvent(AwaitableRecord& record) noexcept
        {
            if (stopping_)
                return lux::cxx::unexpected(EScriptAwaitableCompletionError::STOPPING);
            if (record.state != EScriptAwaitableState::PENDING || record.release_pending)
                return lux::cxx::unexpected(EScriptAwaitableCompletionError::ALREADY_TERMINAL);
            if (record.continuation.valid() && resumes_.count >= resumes_.records.size())
                return lux::cxx::unexpected(EScriptAwaitableCompletionError::RESUME_QUEUE_FULL);
            record.state = EScriptAwaitableState::READY;
            record.error = {};
            if (record.continuation.valid())
            {
                static_cast<void>(resumes_.push({record.instance, record.continuation, record.id}));
                record.resume_enqueued = true;
            }
            return {};
        }
    public:
        void completeClaimedEventWaiter'''),
('''        [[nodiscard]] bool drainExternalCompletions() noexcept''',
'''        [[nodiscard]] bool hasPendingExternalCompletions() const noexcept { return ingress_.hasPendingInWindow(); }
        [[nodiscard]] bool drainExternalCompletions() noexcept'''),
('''            [[nodiscard]] std::optional<Result> next() noexcept
            {
                if (remaining_ == 0U)
                    return std::nullopt;
                const auto record = owner_.resumes_.pop();
                if (!record)
                    return std::nullopt;
                --remaining_; // Every pop, including a stale one, consumes exactly one
                              // budget unit.
                return owner_.resumeOne(*record);
            }''',
'''            [[nodiscard]] bool next(Result& result) noexcept
            {
                if (remaining_ == 0U)
                    return false;
                const auto record = owner_.resumes_.pop();
                if (!record)
                    return false;
                --remaining_; // Every pop, including a stale one, consumes exactly one budget unit.
                result = owner_.resumeOne(*record);
                return true;
            }''')])
edit(c+'ScriptEventWaits.hpp',[
('''        struct EventWaiterRecord final
        {
''','''        struct EventWaiterRecord final
        {
            EventWaiterRecord(ScriptInstanceId owner, ScriptAwaitableId result, std::uint32_t endpoint,
                ecs::Entity entity, std::uint64_t order) noexcept
                : instance(owner), awaitable(result), bucket_slot(endpoint), target(entity), sequence(order) {}
'''),
('''            const auto inserted = waiters_.tryEmplace(EventWaiterRecord{
                {}, instance, awaitable, endpoint, target, sequence_ + 1U, EEventWaiterState::ACTIVE, {}, {}, {}, {}
            });''',
'''            const auto inserted = waiters_.tryEmplace(instance, awaitable, endpoint, target, sequence_ + 1U);'''),
('''        {
            auto* waiter = waiters_.find(eventWaiterKey(id));
            if (waiter == nullptr)
                return std::nullopt;
            const ScriptSourceCancellation result''',
'''        {
            const auto key = eventWaiterKey(id);
            auto* waiter = waiters_.find(key);
            if (waiter == nullptr)
                return std::nullopt;
            const ScriptSourceCancellation result'''),
('static_cast<void>(waiters_.erase(eventWaiterKey(id)));','static_cast<void>(waiters_.erase(key));')])
edit(c+'ScriptCompletionIngress.hpp',[
('''            remaining_ = transport_->completions.capacity;
            prepared_ = true;''',
'''            remaining_ = transport_->completions.capacity;
            pending_in_window_ = transport_->completions.dequeue_position < frontier_ && remaining_ != 0U;
            prepared_ = true;'''),
('''            if (transport_->completions.dequeue_position >= frontier_ || remaining_ == 0U)
                return nullptr;''',
'''            if (!pending_in_window_)
                return nullptr;'''),
('''            if (result != nullptr)
                --remaining_;
            return result;
        }
        void ack() noexcept { transport_->completions.pop(); }''',
'''            if (result != nullptr && --remaining_ == 0U)
                pending_in_window_ = false;
            // A reserved but unpublished head remains eligible for a later retry.
            return result;
        }
        void ack() noexcept
        {
            transport_->completions.pop();
            if (transport_->completions.dequeue_position >= frontier_)
                pending_in_window_ = false;
        }
        [[nodiscard]] bool hasPendingInWindow() const noexcept { return pending_in_window_; }'''),
('''        bool prepared_{};''','''        bool prepared_{};
        bool pending_in_window_{};''')])
edit('engine/domain/simulation/builtin/script/src/ScriptSystem.cpp',[
('''            while (const auto resumed = batch.next())
            {
                if (!*resumed && !report.first_instance_error)
                    report.first_instance_error = resumed->error();''',
'''            ScriptExecution::Result resumed;
            while (batch.next(resumed))
            {
                if (!resumed && !report.first_instance_error)
                    report.first_instance_error = resumed.error();'''),
('''                if (!execution_owner.drainExternalCompletions())
                    completion_failed = true;''',
'''                if (execution_owner.hasPendingExternalCompletions() && !execution_owner.drainExternalCompletions())
                    completion_failed = true;''')])
