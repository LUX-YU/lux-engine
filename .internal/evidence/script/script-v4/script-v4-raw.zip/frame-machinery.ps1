$ErrorActionPreference='Stop'
$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-v4'
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$cpp='E:/SyncForder/CodeRepos/build/RelWithDebInfo/o/w/d/engine/domain/simulation/builtin/script/CMakeFiles/script_runtime_benchmark.dir/generated/script_runtime_benchmark/cpp_scripts/CppSequence/CppSequenceScript.CppSequence.script.generated.cpp.obj'
$native='E:/SyncForder/CodeRepos/build/RelWithDebInfo/o/w/d/engine/domain/simulation/scripting/native/CMakeFiles/simulation_script_native.dir/src/NativeScriptBackend.cpp.obj'
dumpbin /DISASM $cpp *> "$r/final-cpp-frame-disassembly.log"
if($LASTEXITCODE) { throw 'Cpp disassembly failed' }
dumpbin /DISASM $native *> "$r/final-native-frame-disassembly.log"
if($LASTEXITCODE) { throw 'Native disassembly failed' }
Push-Location $r
try {
 cl /nologo /std:c++latest /EHsc /MD /O2 /Zi /DNDEBUG `
  /I'E:/SyncForder/CodeRepos/install/o/v4/sdk/include' `
  /I'E:/SyncForder/CodeRepos/install/q2/c/include' `
  /I'd:/Development/vcpkg/installed/x64-windows/include' `
  frame-layout.cpp /Fe:frame-layout.exe *> "$r/frame-layout-build.log"
 if($LASTEXITCODE) { throw 'SDK frame layout observer compile failed' }
 & "$r/frame-layout.exe" *> "$r/frame-layout.log"
 if($LASTEXITCODE) { throw 'Frame layout observer failed' }
} finally { Pop-Location }
@{engine='f7d2815bdd2025ee23a7c11449def822413f58e9';
 object_hashes=@(Get-FileHash -LiteralPath $cpp,$native);diagnostic=(Get-FileHash "$r/frame-layout.exe");
 scope='Installed-header layout observer; actual qualified CppSequence/Native object disassembly. No new engine source identity.'
} | ConvertTo-Json -Depth 5 | Set-Content "$r/frame-machinery.json"
