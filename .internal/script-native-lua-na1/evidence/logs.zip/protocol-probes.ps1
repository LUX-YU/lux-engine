$ErrorActionPreference='Stop'
$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1'
& 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$results=@()
foreach($side in @('A','B')){
 $sdk=if($side -eq 'A'){'E:/SyncForder/CodeRepos/install/o/v4/sdk'}else{'E:/SyncForder/CodeRepos/install/o/na1/qualified-sdk'}
 $prefix="$sdk;E:/SyncForder/CodeRepos/install/q2/c;E:/SyncForder/CodeRepos/install/q2/toolset"
 $env:PATH="$sdk/bin;D:/Development/vcpkg/installed/x64-windows/bin;$env:PATH"
 $b="$r/protocol-probes/build-$side"
 & cmake -S "$r/protocol-probes" -B $b -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo "-DCMAKE_PREFIX_PATH=$prefix" -DCMAKE_TOOLCHAIN_FILE=D:/Development/vcpkg/scripts/buildsystems/vcpkg.cmake *> "$r/protocol-probes/$side-configure.log"
 if($LASTEXITCODE){throw 'configure probe'}
 & cmake --build $b --target all -j 4 -- -k 0 *> "$r/protocol-probes/$side-build.log"
 if($LASTEXITCODE){throw 'build probe'}
 & "$b/na1_event_priority_probe.exe" *> "$r/protocol-probes/$side-run.log"
 if($LASTEXITCODE -or !(Select-String "$r/protocol-probes/$side-run.log" -SimpleMatch 'NA1_EVENT_DUAL_FULL' -Quiet)){throw 'run probe'}
 $results+=@{side=$side;status='PASS';exe=(Get-FileHash "$b/na1_event_priority_probe.exe").Hash;source=(Get-FileHash "$r/protocol-probes/priority.cpp").Hash;original_fixture_source='4a8812e9813fe90b241dba29e3e668e4a4239b26'}
 $results|ConvertTo-Json|Set-Content "$r/protocol-probes/results.json"
 Write-Output "DUAL_FULL $side PASS"
}
