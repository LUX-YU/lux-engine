import ctypes, hashlib, json, os, re, subprocess
from pathlib import Path

base = Path('E:/SyncForder/CodeRepos')
root = base / 'build/RelWithDebInfo/sr3-cost-final/diagnostics'
build = base / 'build/RelWithDebInfo/sr3-c3/d'
repo = base / 'lux-engine-sr3-cost-final'
python = 'C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
dump = 'D:/Development/Mircosoft/VisualStudio/VC/Tools/MSVC/14.44.35207/bin/Hostx64/x64/dumpbin.exe'
identity = []
db = json.loads((build / 'compile_commands.json').read_text())
entry = next(e for e in db if e['file'].endswith('/builtin/script/src/ScriptSystem.cpp'))
for label in ('Mount', 'InvocationState', 'Invocation'):
    command = entry['command'] + f' /Fo"{root}/{label}.obj" /Fd"{root}/{label}.pdb" /FAs /Fa"{root}/{label}.asm" /d1reportSingleClassLayout{label}'
    with (root / f'{label}-compiler.log').open('w') as log:
        subprocess.run(command, cwd=entry['directory'], stdout=log, stderr=subprocess.STDOUT, check=True)
    (root / f'{label}-compiler-command.json').write_text(json.dumps(entry | {'diagnostic_command': command}, indent=2))
for label, path, option in [
    ('system', build / 'engine/domain/simulation/builtin/script/CMakeFiles/simulation_script.dir/src/ScriptSystem.cpp.obj', '/DISASM'),
    ('instances', build / 'engine/domain/simulation/builtin/script/CMakeFiles/simulation_script.dir/src/ScriptInstances.cpp.obj', '/DISASM'),
    ('dll', build / 'bin/lux_engine_simulation_script.dll', '/DISASM'),
    ('exports', build / 'bin/lux_engine_simulation_script.dll', '/EXPORTS'),
    ('headers', build / 'bin/lux_engine_simulation_script.dll', '/HEADERS')]:
    with (root / f'b2-{label}.txt').open('w') as log:
        subprocess.run([dump, option, str(path)], stdout=log, check=True)
    identity.append({'label': label, 'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
def names(path):
    return sorted(re.findall(r'^\s+\d+\s+[0-9A-F]+\s+[0-9A-F]+\s+(\S+)', path.read_text(), re.M))
old = base / 'build/RelWithDebInfo/sr3-closeout/diagnostics/b1-final-exports.txt'
assert names(old) == names(root / 'b2-exports.txt')
(root / 'machine-code-identity.json').write_text(json.dumps({'artifacts': identity, 'b1_b2_export_names_equal': True, 'export_count': len(names(old))}, indent=2))
# Sampling is serialized after all builds, tests, and formal timing. It is not a timing result.
ctypes.windll.kernel32.GetCurrentProcess.restype = ctypes.c_void_p
ctypes.windll.kernel32.SetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
assert ctypes.windll.kernel32.SetProcessAffinityMask(ctypes.windll.kernel32.GetCurrentProcess(), 1)
for case, profile, flags, frames in [('cpp', 'd', [], 30000), ('flow', 't', ['--flow'], 30000), ('event', 't', ['--flow', '--event'], 3000)]:
    binary = base / f'build/RelWithDebInfo/sr3-c3/{profile}/bin'
    env = dict(os.environ)
    env['PATH'] = str(base / f'install/sr3-c3/{profile}/bin') + ';D:/Development/vcpkg/installed/x64-windows/bin;' + env['PATH']
    command = [python, '-B', str(repo / 'cmake/SampleScriptHotPath.py'), '--bin', str(binary), '--output', str(root / f'b2-{case}-profile'), '--frames', str(frames)] + flags
    with (root / f'b2-{case}-sampler.log').open('w') as log:
        subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
print('Compiler, linked exports, actual disassembly and three sampled paths complete.')
