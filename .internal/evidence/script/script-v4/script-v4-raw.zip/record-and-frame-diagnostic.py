from pathlib import Path
import ctypes as ct,subprocess,time,json,os,csv
r=Path(__file__).parent;out=r/'other-resources';out.mkdir(exist_ok=False)
code=(r/'memory-diagnostic.py').read_text();exec(code[code.index('class Memory'):code.index('results=[]')])
k=ct.WinDLL('kernel32');k.GetCurrentProcess.restype=ct.c_void_p
k.SetProcessAffinityMask.argtypes=[ct.c_void_p,ct.c_size_t];assert k.SetProcessAffinityMask(k.GetCurrentProcess(),16)
runs=[]
for label,image,exe,args in [
 ('record-v3',r.parent/'lua55-v3/final-image','simulation_script_lua_value_runtime_test.exe',['--benchmark','1000000','--allocations']),
 ('record-v4',r/'final-image','simulation_script_lua_value_runtime_test.exe',['--benchmark','1000000','--allocations']),
 ('cpp-frames-v4',r/'final-image','script_runtime_benchmark.exe',['--group','micro-cpp-coroutine','--mode','diagnostic',
  '--size','10000','--frames','128','--warmups','16','--output',str(out/'cpp-frames.csv')]),
 ('native-frames-v4',r/'final-flow-image','flowforge_script_runtime_benchmark.exe',['--group','scene-flowforge-event-idle',
  '--storage-accounting','on','--mode','diagnostic','--size','10000','--frames','128','--warmups','16',
  '--resume-budget','10000','--output',str(out/'native-frames.csv')])]:
 cmd=[str(image/exe),*args];env=dict(os.environ)
 env['PATH']=';'.join([str(image),'D:/Development/vcpkg/installed/x64-windows/bin',*[p for p in env['PATH'].split(';') if 'CodeRepos' not in p and 'vcpkg' not in p]])
 peak_ws=peak_private=samples=0
 with (out/(label+'.log')).open('wb') as f:
  process=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
  while process.poll() is None:
   m=Memory();m.cb=ct.sizeof(m)
   if psapi.GetProcessMemoryInfo(int(process._handle),ct.byref(m),m.cb):
    peak_ws=max(peak_ws,m.PeakWorkingSetSize);peak_private=max(peak_private,m.PeakPagefileUsage);samples+=1
   time.sleep(.1)
  exit=process.wait()
 text=(out/(label+'.log')).read_text()
 assert exit==0,(label,exit)
 if label.startswith('record'):
  assert 'operations=1000000 errors=0 backlog=0' in text and 'VALUE_CLEANUP invocation_errors=0' in text
 rows=list(csv.DictReader((out/'cpp-frames.csv').open())) if label=='cpp-frames-v4' else []
 if rows:
  assert len(rows)==256 and all(x['allocation_accounting']=='1' and x['allocations']=='0' for x in rows)
  assert all(x['continuations']==('10000' if x['scenario'].endswith('-start') else '0') for x in rows)
 runs.append(dict(label=label,command=cmd,exit=exit,peak_working_set=peak_ws,peak_private_commit=peak_private,
  samples=samples,diagnostic_only=True,observations=text.splitlines(),
  exe_hot_operator_new_calls=0 if rows else None,
  whole_process_heap_calls=None,heap_scope='C++ EXE-local operator new observation; storage acquire/release machine code audited separately' if rows else 'VM allocator explicit counters / Native arena evidence, not an all-DLL malloc trace',
  frame_arena_bytes=int(rows[0]['payload_bytes']) if rows else None))
 (out/'results.json').write_text(json.dumps(runs,indent=2));print(label,exit,peak_ws,flush=True)
