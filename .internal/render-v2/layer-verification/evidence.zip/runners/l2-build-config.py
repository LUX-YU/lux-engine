from pathlib import Path
r=Path('E:/RenderV2Rebuild/Layer/source')
def edit(p,a,b):
 p=r/p;s=p.read_text();assert a in s,(p,a);p.write_text(s.replace(a,b))
p=r/'modules/function/render/features/test/Feature.cpp';s=p.read_text();start=s.index('struct ConfigureFixture');end=s.index('namespace negative',start);s=s[:start]+s[end:];s=s.replace('    if (group == "operations") return operations();\n','');s=s.replace('    std::array<unsigned, 3> order','    const std::array graphs{&fixture::graph<GEOMETRY>(), &fixture::graph<LIGHTING>(), &fixture::graph<TONEMAP>()};\n    std::array<unsigned, 3> order');s=s.replace('{types[i], nullptr, "main"}','{types[i], graphs[i], nullptr, "main"}');s=s.replace('{types[0], nullptr, "main"}','{types[0], graphs[0], nullptr, "main"}').replace('{types[1], nullptr, "main"}','{types[1], graphs[1], nullptr, "main"}').replace('{types[2], nullptr, "main"}','{types[2], graphs[2], nullptr, "main"}').replace('{&fixture::definition<ALTERNATE>(), nullptr, "main"}','{&fixture::definition<ALTERNATE>(), &fixture::graph<ALTERNATE>(), nullptr, "main"}');p.write_text(s)
edit('modules/function/render/features/test/CMakeLists.txt','identity config operations claims','identity config claims')
edit('modules/function/render/features/test/CMakeLists.txt','foreach(header Feature Resources Program Registration)','foreach(header Feature Assembly Resources Registration)')
edit('modules/function/render/data/test/CMakeLists.txt','foreach(header Schema Wire Payload)','foreach(header Schema Wire Payload Shader ShaderInterface)')
edit('modules/function/render/graph/test/CMakeLists.txt','foreach(header Graph Builder Analysis)','foreach(header Graph Builder Analysis Program)')
edit('modules/function/render/resource/test/CMakeLists.txt','foreach(header Storage Factory','foreach(header Binding Storage Factory')
p=r/'modules/function/render/native/vulkan/CMakeLists.txt';s=p.read_text().replace('src/transfer/Transfer.cpp src/transfer/GpuWork.cpp src/transfer/GpuCompletion.cpp\n    src/texture/TextureStorage.cpp src/texture/Commands.cpp','src/transfer/Transfer.cpp src/transfer/GpuWork.cpp');s=s.replace('    lux::engine::render::render_features','    lux::engine::render::render_data lux::engine::render::render_resource lux::engine::render::render_graph');pos=s.index('if(BUILD_TESTING)');s=s[:pos]+'''set(LUX_NATIVE_EXTENSION_SOURCES
    src/transfer/GpuCompletion.cpp src/texture/TextureStorage.cpp src/texture/Commands.cpp
)

add_component(
    STATIC
    COMPONENT_NAME render_native_vulkan_extensions
    NAMESPACE lux::engine::render
    OUTPUT_NAME lux_engine_render_native_vulkan_extensions
    SOURCE_FILES ${LUX_NATIVE_EXTENSION_SOURCES}
)

component_include_directories(render_native_vulkan_extensions
    BUILD_TIME_EXPORT "${CMAKE_CURRENT_SOURCE_DIR}/include"
    PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/pinclude" "${CMAKE_CURRENT_SOURCE_DIR}/sinclude"
    INSTALL_TIME include
)

component_add_internal_dependencies(render_native_vulkan_extensions
    lux::engine::render::render_native_vulkan lux::engine::render::render_features
)

target_compile_features(render_native_vulkan_extensions PUBLIC cxx_std_20)

'''+s[pos:];p.write_text(s)
edit('modules/function/render/CMakeLists.txt','render_client render_runtime','render_native_vulkan_extensions render_client render_runtime')
edit('modules/function/render/runtime/CMakeLists.txt','lux::engine::render::render_native_vulkan lux::engine::render::render_protocol_async','lux::engine::render::render_native_vulkan_extensions lux::engine::render::render_protocol_async')
p=r/'modules/function/render/native/vulkan/test/CMakeLists.txt';s=p.read_text().replace('foreach(source IN LISTS LUX_NATIVE_SOURCES)','foreach(source IN LISTS LUX_NATIVE_SOURCES LUX_NATIVE_EXTENSION_SOURCES)');s=s.replace('target_link_libraries(render_compiler_test PRIVATE render_native_vulkan)','target_link_libraries(render_compiler_test PRIVATE render_native_vulkan render_features)');s=s.replace('target_link_libraries(render_execution_test PRIVATE render_native_vulkan)','target_link_libraries(render_execution_test PRIVATE render_native_vulkan render_features)');s=s.replace('target_link_libraries(render_texture_upload_test PRIVATE render_native_vulkan)','target_link_libraries(render_texture_upload_test PRIVATE render_native_vulkan_extensions)');s=s.replace('target_link_libraries(render_storage_bindings_test PRIVATE render_native_vulkan)','target_link_libraries(render_storage_bindings_test PRIVATE render_native_vulkan_extensions)');s=s.replace('target_link_libraries(render_native_header_${target} PRIVATE render_native_vulkan)','target_link_libraries(render_native_header_${target} PRIVATE render_native_vulkan_extensions)');p.write_text(s)
edit('modules/function/render/native/vulkan/test/installed/CMakeLists.txt','COMPONENTS render_native_vulkan)','COMPONENTS render_native_vulkan render_native_vulkan_extensions)')
edit('modules/function/render/native/vulkan/test/installed/CMakeLists.txt','target_link_libraries(native_consumer PRIVATE lux::engine::render::render_native_vulkan)','target_link_libraries(native_consumer PRIVATE lux::engine::render::render_native_vulkan lux::engine::render::render_features)')
edit('modules/function/render/native/vulkan/test/installed/CMakeLists.txt','target_link_libraries(texture_consumer PRIVATE lux::engine::render::render_native_vulkan','target_link_libraries(texture_consumer PRIVATE lux::engine::render::render_native_vulkan_extensions')
