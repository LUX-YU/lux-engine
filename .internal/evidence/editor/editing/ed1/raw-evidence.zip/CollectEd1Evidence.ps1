param([string]$Repo = 'C:/Users/ChenHui/.codex/worktrees/9905/lux-engine')
$ErrorActionPreference = 'Stop'
$taskRoot = 'E:/lux-ed1-9905'
$final = "$taskRoot/qualification-final"
$out = "$Repo/.internal/evidence/editor/editing/ed1"
$qualified = Get-Content "$final/qualification.json" -Raw | ConvertFrom-Json
$commands = Get-Content "$final/commands.jsonl" | ForEach-Object { $_ | ConvertFrom-Json }
if (@($commands | Where-Object { $_.exit -ne 0 }).Count) { throw 'Failed final command' }
$diagnostic = [IO.File]::ReadAllText("$final/diagnostic-tests.log")
$normal = [IO.File]::ReadAllText("$final/normal-tests.log")
if ($diagnostic -notmatch '100% tests passed, 0 tests failed out of 13') { throw 'Diagnostic matrix mismatch' }
if ($normal -notmatch '100% tests passed, 0 tests failed out of 10') { throw 'Normal matrix mismatch' }
Copy-Item -LiteralPath "$final/qualification.json" -Destination "$out/qualification.json"
$rows = Import-Csv "$out/ACCEPTANCE.csv" | Where-Object phase -eq 'ED-1'
if ($rows.Count -ne 79) { throw 'Original ED-1 matrix must contain 79 cases' }
$mapping = foreach ($row in $rows) {
    $id = $row.id
    $evidence = 'qualified/diagnostic-tests.log'
    $source = switch -Regex ($id) {
        '^C23$' { 'cmake/installed-consumers/editor-editing/main.cpp'; break }
        '^C' { 'engine/editor/editing/test/CoreCases.hpp'; break }
        '^F' { 'engine/editor/editing/test/FailureCases.hpp'; break }
        '^[LS]' { 'engine/editor/editing/test/SaveLimitCases.hpp'; break }
        '^R' { 'engine/editor/context/test/EditHistoryRoutingTest.cpp'; break }
        '^I' { 'cmake/RunEditorEditingQualification.ps1'; break }
    }
    if ($id -eq 'C23') {
        $evidence = 'qualified/core-a-run.log; qualified/core-b-run.log'
        if ([IO.File]::ReadAllText("$final/core-b-run.log") -notmatch 'C23 PASS') { throw 'Missing C23' }
    } elseif ($id -match '^I') {
        $evidence = switch ($id) {
            'I01' { 'qualified/core-a-configure.log; qualified/core-a-build.log; qualified/core-a-run.log' }
            'I02' { 'qualified/core-b-configure.log; qualified/core-b-build.log; qualified/core-b-run.log; qualified/context-signal-run.log' }
            'I03' { 'qualified/second-build.log; qualified/core-a-second-build.log; qualified/core-b-second-build.log; qualified/context-b-second-build.log' }
            'I04' { 'qualified/diagnostic-tests.log; qualified/core-a-core-imports.log; qualified/core-b-*-imports.log; qualified/core-b/editing-import.txt; qualified/core-b/compile_commands.json' }
            'I05' { 'qualified/diagnostic-tests.log; qualified/normal-tests.log; qualified/context-signal-run.log' }
            'I06' { 'qualified/cost-*.log; cost-samples.csv; cost-summary.csv' }
        }
    } elseif ($diagnostic -notmatch "\b$id PASS\b") { throw "Missing logical result: $id" }
    if ($id -eq 'C02') { $evidence += '; qualified/core-b-run.log' }
    if ($id -eq 'L08') { $source += '; engine/editor/editing/test/EditingProtocolTest.cpp' }
    [ordered]@{id=$id;group=$row.group;status='PASS';setup=$row.setup;action=$row.action;expected=$row.expected;
        implementation=$source;evidence=$evidence;qualified_source=$qualified.source_head}
}
$mapping | Export-Csv "$out/acceptance-results.csv" -NoTypeInformation -Encoding utf8
$samples = foreach ($count in @(1000,10000)) {
    foreach ($run in 1..5) {
        foreach ($sample in Import-Csv "$final/cost-$count-$run.log") {
            if ([int64]$sample.applies -ne [int64]$sample.count*3 -or
                [int64]$sample.operations_destroyed -ne [int64]$sample.count -or
                [int64]$sample.plans_destroyed -ne [int64]$sample.count*3 -or
                [int64]$sample.notices -ne [int64]$sample.count*3+2) { throw 'Cost sample work mismatch' }
            $sample | Add-Member -NotePropertyName process -NotePropertyValue "$count-$run"
            $sample
        }
    }
}
if (@($samples).Count -ne 40) { throw 'Expected all 40 workload samples from ten processes' }
$samples | Export-Csv "$out/cost-samples.csv" -NoTypeInformation -Encoding utf8
$summary = foreach ($group in $samples | Group-Object business,count) {
    $record = [ordered]@{business=$group.Group[0].business;count=$group.Group[0].count;processes=$group.Count}
    foreach ($field in @('execute_ns','undo_ns','redo_ns','clear_ns','close_ns')) {
        $numbers = @($group.Group | ForEach-Object { [double]$_.$field } | Sort-Object)
        $mid = [int][Math]::Floor($numbers.Count/2)
        $median = if ($numbers.Count%2) { $numbers[$mid] } else { ($numbers[$mid-1]+$numbers[$mid])/2 }
        $record[$field.Replace('_ns','_median_ms')] = $median/1000000
        $record[$field.Replace('_ns','_min_ms')] = $numbers[0]/1000000
        $record[$field.Replace('_ns','_max_ms')] = $numbers[-1]/1000000
    }
    foreach ($field in @('checksum','metadata_bytes','retained_bytes','staging_bytes')) {
        $values = @($group.Group | ForEach-Object { $_.$field } | Sort-Object -Unique)
        if ($values.Count -ne 1) { throw "Inconsistent cost ledger: $field" }
        $record[$field] = $values[0]
    }
    [pscustomobject]$record
}
$summary | Export-Csv "$out/cost-summary.csv" -NoTypeInformation -Encoding utf8
$identities = foreach ($path in @('sdk-a','sdk-b','core-a','core-b','context-b')) {
    $files = if ($path -like 'sdk-*') {
        Get-ChildItem "$final/$path" -Recurse -File | Where-Object {
            $_.FullName -match 'editor[/\\]editing[/\\]|editor[/\\](ActiveEditHistory|EditHistoryController)|editor[-_]editing|editor[-_]context'
        }
    } else { Get-ChildItem "$final/$path" -File | Where-Object Extension -in '.exe','.dll','.lib' }
    foreach ($file in $files) {
        [ordered]@{path=$file.FullName;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash}
    }
}
$identities | ConvertTo-Json -Depth 4 | Set-Content "$out/sdk-consumer-identities.json" -Encoding utf8
$dependencyFiles = @(
    Get-ChildItem 'E:/SyncForder/CodeRepos/install/q2/c/bin' -File
    Get-ChildItem 'E:/SyncForder/CodeRepos/install/q2/c/lib' -Filter '*.lib'
    Get-ChildItem 'E:/SyncForder/CodeRepos/install/q2/c/include/lux/cxx/compile_time' -Recurse -File
    Get-ChildItem 'E:/SyncForder/CodeRepos/install/q2/toolset' -Recurse -File
    Get-Item 'E:/lux-ed1-9905/q/bin/ui.dll'
    Get-Item 'E:/lux-ed1-9905/q/bin/imgui_core.dll'
)
$dependencyFiles | ForEach-Object {
    [ordered]@{path=$_.FullName;bytes=$_.Length;sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash}
} | ConvertTo-Json -Depth 4 | Set-Content "$out/dependency-identities.json" -Encoding utf8
$stage = "$taskRoot/raw-ed1-final"
New-Item -ItemType Directory -Path "$stage/qualified" -Force | Out-Null
Get-ChildItem $final -File | Copy-Item -Destination "$stage/qualified"
foreach ($variant in @('core-a','core-b','context-b')) {
    New-Item -ItemType Directory -Path "$stage/qualified/$variant" -Force | Out-Null
    foreach ($name in @('CMakeCache.txt','compile_commands.json','build.ninja','editing-import.txt')) {
        Copy-Item -LiteralPath "$final/$variant/$name" -Destination "$stage/qualified/$variant"
    }
}
Copy-Item -LiteralPath 'E:/lux-ed1-9905/q/build.ninja' -Destination "$stage/qualified/engine-build.ninja"
Copy-Item -LiteralPath 'E:/lux-ed1-9905/q/install_manifest.txt' -Destination "$stage/qualified/install_manifest.txt"
Copy-Item -LiteralPath 'E:/lux-ed1-9905/q/Testing/Temporary/LastTest.log' -Destination "$stage/qualified/LastTest.log"
foreach ($trial in @('final','final2','qualified')) {
    New-Item -ItemType Directory -Path "$stage/iterations/$trial" -Force | Out-Null
    Get-ChildItem "$taskRoot/$trial" -File | Copy-Item -Destination "$stage/iterations/$trial"
    foreach ($variant in @('core-a','core-b','context-b')) {
        if (Test-Path -LiteralPath "$taskRoot/$trial/$variant") {
            New-Item -ItemType Directory -Path "$stage/iterations/$trial/$variant" -Force | Out-Null
            foreach ($name in @('CMakeCache.txt','compile_commands.json','build.ninja','editing-import.txt')) {
                if (Test-Path -LiteralPath "$taskRoot/$trial/$variant/$name") {
                    Copy-Item -LiteralPath "$taskRoot/$trial/$variant/$name" -Destination "$stage/iterations/$trial/$variant"
                }
            }
        }
    }
}
New-Item -ItemType Directory -Path "$stage/iterations/initial" -Force | Out-Null
Get-ChildItem $taskRoot -File | Where-Object Extension -in '.log','.json','.txt' |
    Copy-Item -Destination "$stage/iterations/initial"
Copy-Item -LiteralPath "$taskRoot/CollectEd1Evidence.ps1" -Destination "$stage/CollectEd1Evidence.ps1"
Add-Type -AssemblyName System.IO.Compression.FileSystem
[IO.Compression.ZipFile]::CreateFromDirectory($stage,"$out/raw-evidence.zip",[IO.Compression.CompressionLevel]::Optimal,$false)
Get-ChildItem $out -File | Where-Object Name -ne 'SHA256SUMS' | ForEach-Object {
    "$((Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant())  $($_.Name)"
} | Set-Content "$out/SHA256SUMS" -Encoding ascii
$summary | Format-Table business,count,processes,execute_median_ms,undo_median_ms,redo_median_ms
