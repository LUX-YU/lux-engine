#pragma once
// Generated typed Lua projection. Include the matching .ability.generated.hpp first.
#include <lux/engine/simulation/scripting/lua/LuaScriptAbilityProjection.hpp>

#include <array>
#include <type_traits>
#include <utility>

namespace lux::script::lua
{

    template <>
    struct ScriptAbilityLuaTraits<::lux::simulation::script::DelayAbility> final
    {
        using AbilityTraits = ScriptAbilityTraits<::lux::simulation::script::DelayAbility>;

        [[nodiscard]] static int nextStep(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::startLuaAbility<void>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, ScriptAbilityCompletion<void> completion) noexcept
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.nextStep(access.context, std::move(completion));
                }
            );
        }

        [[nodiscard]] static int seconds(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::startLuaAbility<void, double>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, std::remove_cvref_t<double> duration, ScriptAbilityCompletion<void> completion) noexcept
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.seconds(access.context, duration, std::move(completion));
                }
            );
        }

        [[nodiscard]] static int simulationSeconds(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::startLuaAbility<void, double>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, std::remove_cvref_t<double> duration, ScriptAbilityCompletion<void> completion) noexcept
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.simulationSeconds(access.context, duration, std::move(completion));
                }
            );
        }

        [[nodiscard]] static int realSeconds(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::startLuaAbility<void, double>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, std::remove_cvref_t<double> duration, ScriptAbilityCompletion<void> completion) noexcept
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.realSeconds(access.context, duration, std::move(completion));
                }
            );
        }

        inline static constexpr std::array<ScriptAbilityLuaMethodProjection, AbilityTraits::Methods.size()> Methods{
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.simulation.delay.next_step"},
                &nextStep
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.simulation.delay.seconds"},
                &seconds
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.simulation.delay.simulation_seconds"},
                &simulationSeconds
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.simulation.delay.real_seconds"},
                &realSeconds
            }
        };
    };
} // namespace lux::script::lua
