from pathlib import Path
import csv
r=Path.cwd()
for side in ['A','B']:
 rows=list(csv.DictReader((r/'local-profiles'/('P4-'+side)/'top-down.csv').open()))
 blank=[x for x in rows if not x['CPU Time:Self']];print(side,len(blank),[(x['Function Stack'],x['CPU Time:Total']) for x in blank][:8])
p=r/'local-phases.py';t=p.read_text().replace("seconds=float(row['CPU Time:Self']);path", "seconds=float(row['CPU Time:Self']) if row['CPU Time:Self'] else 0.0;path")
p.write_text(t)
