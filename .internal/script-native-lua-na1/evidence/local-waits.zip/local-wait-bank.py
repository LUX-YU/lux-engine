from pathlib import Path
s=Path(r'E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1/source')
p=s/'engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptExecution.hpp'
t=p.read_text().replace('#include <lux/cxx/container/StableSlotMap.hpp>', '#include <lux/cxx/container/SlotMap.hpp>')
t=t.replace('        struct ExecutionInstance final','        struct AwaitableRecord;\n        struct ExecutionInstance final',1)
t=t.replace('            ScriptAwaitableId first_awaitable;', '            AwaitableRecord* first_awaitable{};')
a=t.index('            AwaitableRecord(ScriptInstanceId owner,');b=t.index('            ScriptContinuationId continuation;',a)
t=t[:a]+'''            ExecutionInstance* owner{};
            std::uint32_t next_free{};
'''+t[b:]
t=t.replace('            ScriptAwaitableId instance_previous;\n            ScriptAwaitableId instance_next;', '            AwaitableRecord* instance_previous{};\n            AwaitableRecord* instance_next{};')
a=t.index('        using AwaitableStorage =');b=t.index('        struct UserInvocationScope',a)
t=t[:a]+'''        using AwaitableKey = lux::cxx::SlotKey<AwaitableTag>;
        // A fixed result bank, not an additional pool. Records and their Event
        // links live until shutdown. Logical waits acquire a fresh generation and
        // return capacity before user resume; write pins delay that return exactly
        // as before. No per-wait construction, dense index or block lookup remains.
        class AwaitableStorage final
        {
            static constexpr std::uint32_t NoSlot = (std::numeric_limits<std::uint32_t>::max)();
        public:
            void reserve(std::size_t capacity)
            {
                if (active_ != 0U) std::terminate();
                if (records_.empty())
                {
                    records_.resize(capacity);
                    for (auto& record : records_) record.id.generation = 1U;
                }
                else if (records_.size() != capacity) std::terminate();
                rebuildFreeList();
            }
            [[nodiscard]] AwaitableRecord* acquire(ExecutionInstance& owner,
                std::optional<PreparedResumeType> type, bool external) noexcept
            {
                if (free_head_ == NoSlot) return nullptr;
                const auto slot = free_head_;
                auto& record = records_[slot];
                free_head_ = record.next_free;
                record.id.slot = slot + 1U;
                record.instance = owner.id;
                record.owner = &owner;
                record.state = EScriptAwaitableState::PENDING;
                record.result_type = type;
                record.external_completion = external;
                ++active_;
                return &record;
            }
            [[nodiscard]] AwaitableRecord* find(AwaitableKey key) noexcept
            {
                if (key.index >= records_.size()) return nullptr;
                auto& record = records_[key.index];
                return record.id.slot != 0U && record.id.generation == key.gen ? &record : nullptr;
            }
            void releaseResolved(AwaitableRecord& record) noexcept
            {
                const auto slot = record.id.slot - 1U;
                record.id.slot = 0U;
                record.continuation = {};
                record.value = {};
                record.error = {};
                record.resume_enqueued = false;
                record.release_pending = false;
                --active_;
                // Exhausted generations retire the physical slot; never wrap an
                // old public 32-bit token into a newly live wait.
                if (record.id.generation != NoSlot)
                {
                    ++record.id.generation;
                    record.next_free = free_head_;
                    free_head_ = slot;
                }
            }
            [[nodiscard]] bool empty() const noexcept { return active_ == 0U; }
            [[nodiscard]] std::size_t size() const noexcept { return active_; }
            [[nodiscard]] std::size_t capacity() const noexcept { return records_.size(); }
            [[nodiscard]] std::size_t storageBytes() const noexcept
            {
                return records_.capacity() * sizeof(AwaitableRecord);
            }
            void clear() noexcept
            {
                if (active_ != 0U) std::terminate();
                // Keep the physical bank and generations for a prepare retry.
                rebuildFreeList();
            }
        private:
            void rebuildFreeList() noexcept
            {
                free_head_ = NoSlot;
                for (std::size_t i = records_.size(); i > 0U; --i)
                {
                    auto& record = records_[i - 1U];
                    if (record.id.generation == NoSlot) continue;
                    record.next_free = free_head_;
                    free_head_ = static_cast<std::uint32_t>(i - 1U);
                }
            }
            std::vector<AwaitableRecord> records_;
            std::uint32_t free_head_{NoSlot};
            std::size_t active_{};
        };
'''+t[b:]
a=t.index('            auto inserted = awaitables_.tryEmplacePrepared');b=t.index('            if (!external_completion && record.result_type)',a)
t=t[:a]+'''            auto* inserted = awaitables_.acquire(owner, std::move(result_type), external_completion);
            if (inserted == nullptr)
                return lux::cxx::unexpected(EScriptAwaitableCreateError::ALLOCATION_FAILURE);
            auto& record = *inserted;
            const auto id = record.id;
'''+t[b:]
t=t.replace('static_cast<void>(awaitables_.erase(*inserted));','awaitables_.releaseResolved(record);')
a=t.index('            record.id = id;\n            record.instance_next');b=t.index('            if (external_completion)',a)
t=t[:a]+'''            record.instance_next = owner.first_awaitable;
            if (record.instance_next) record.instance_next->instance_previous = &record;
            owner.first_awaitable = &record;
'''+t[b:]
a=t.index('            auto* owner = access.record;',t.index('        void unlinkAwaitableOwnership'))
b=t.index('        [[nodiscard]] bool eraseAwaitable(',a)
t=t[:a]+'''            auto* owner = access.record;
            if (record.instance_previous) record.instance_previous->instance_next = record.instance_next;
            else if (owner != nullptr && owner->first_awaitable == &record)
                owner->first_awaitable = record.instance_next;
            if (record.instance_next) record.instance_next->instance_previous = record.instance_previous;
            record.instance_previous = nullptr;
            record.instance_next = nullptr;
        }
'''+t[b:]
t=t.replace('return awaitables_.erase(AwaitableKey{id.slot - 1U, id.generation});','awaitables_.releaseResolved(*record);\n            return true;')
t=t.replace('                    const AwaitableKey key{record.id.slot - 1U, record.id.generation};\n','').replace('static_cast<void>(owner.awaitables_.erase(key));','owner.awaitables_.releaseResolved(record);')
t=t.replace('void cancelAwaitables(ScriptInstanceId instance, ScriptAwaitableId first)', 'void cancelAwaitables(ScriptInstanceId instance, AwaitableRecord* first)')
a=t.index('            auto current = first;',t.index('        void cancelAwaitables'))
b=t.index('        void releaseSource',a)
t=t[:a]+'''            auto* current = first;
            while (current)
            {
                auto* next = current->instance_next;
                static_cast<void>(eraseAwaitableRecord(*current, access));
                ++instance_cleanup_awaitable_visits_;
                current = next;
            }
        }
'''+t[b:]
t=t.replace('{executionRecord(record->instance), record->instance}', '{record->owner, record->instance}')
t=t.replace('{executionRecord(instance), instance}));', '{record->owner, instance}));')
t=t.replace('            auto* instance = findExecutionInstance(resume.instance);','            auto* instance = wait->owner;')
a=t.index('            auto* owner = executionRecord(instance);',t.index('        void completeClaimedEventWaiter'))
b=t.index('            ResultWritePin pin',a)
t=t[:a]+'''            auto* record = awaitables_.find(awaitableKey(awaitable));
            const bool is_stale = record == nullptr || record->instance != instance || record->release_pending ||
                record->source != ScriptWaitSource{id, EScriptWaitSource::EVENT};
            if (is_stale) return;
            auto* owner = record->owner;
            const ExecutionAccess execution{owner, instance};
            if (!execution.current())
            {
                static_cast<void>(eraseAwaitableRecord(*record, execution));
                return;
            }
            const auto& endpoint = binding_owner_.eventEndpoint(waiter.endpoint);
'''+t[b:]
p.write_text(t,encoding='utf-8')
