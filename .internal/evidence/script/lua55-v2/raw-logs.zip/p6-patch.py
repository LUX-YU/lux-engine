from pathlib import Path
import difflib
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source')
o=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-lua55-s0-s1-20260909/dependencies/qualified-lua-5.5.1')
changes={}
def change(f,old,new):
 t=changes.get(f,(o/f).read_text()); assert old in t,(f,old[:65]); changes[f]=t.replace(old,new)
change('src/lua.h','LUA_API int  (lua_yieldk)', '''#define LUX_LUA55_LEAF_YIELD_REVISION 1
/* Lux extension: registered leaf C primitives may return a normal yield sentinel.
   All ineligible shapes use this SAME VM's ordinary lua_yieldk. */
LUA_API int (luxlua_yieldleaf) (lua_State *L, lua_KContext ctx, lua_KFunction k);
LUA_API void (luxlua_leafstats) (lua_State *L, unsigned long long *fast, unsigned long long *fallback);

LUA_API int  (lua_yieldk)''')
change('src/lstate.h','#define CIST_FIN\t(CIST_HOOKYIELD << 1)','#define CIST_FIN\t(CIST_HOOKYIELD << 1)\n#define CIST_LUXCALL (CIST_FIN << 1) /* actual precallC C stack, never a resumed K function */')
change('src/lstate.h','  struct lua_longjmp *errorJmp;  /* current error recover point */','''  struct lua_longjmp *errorJmp;  /* current error recover point */
  struct lua_longjmp *lux_resume_boundary;
  unsigned long long lux_leaf_yields, lux_leaf_fallbacks;''')
change('src/lstate.c','  L->errorJmp = NULL;','  L->errorJmp = NULL;\n  L->lux_resume_boundary = NULL;\n  L->lux_leaf_yields = L->lux_leaf_fallbacks = 0;')
change('src/ldo.c','''  n = (*f)(L);  /* do the actual call */
  lua_lock(L);
  api_checknelems(L, n);''','''  ci->callstatus |= CIST_LUXCALL;
  n = (*f)(L);  /* do the actual call */
  lua_lock(L);
  ci->callstatus &= ~CIST_LUXCALL;
  if (n == -1 && L->status == LUA_YIELD) return n; /* retained C CallInfo */
  api_checknelems(L, n);''')
change('src/ldo.c','''  while ((ci = L->ci) != &L->base_ci) {  /* something in the stack */''','''  while (L->status == LUA_OK && (ci = L->ci) != &L->base_ci) {''')
change('src/ldo.c','''static void finishCcall (lua_State *L, CallInfo *ci) {
  int n;''','''static void finishCcall (lua_State *L, CallInfo *ci) {
  int n;
  ci->callstatus &= ~CIST_LUXCALL;''')
change('src/ldo.c','''  CallInfo *ci = L->ci;
  if (L->status == LUA_OK)  /* starting a coroutine? */''','''  CallInfo *ci = L->ci;
  L->lux_resume_boundary = L->errorJmp;
  ci->callstatus &= ~CIST_LUXCALL;
  if (L->status == LUA_OK)  /* starting a coroutine? */''')
change('src/ldo.c','''  status = luaD_rawrunprotected(L, resume, &nargs);
   /* continue running after recoverable errors */''','''  status = luaD_rawrunprotected(L, resume, &nargs);
  L->lux_resume_boundary = NULL; /* also on a standard longjmp/error */
  if (status == LUA_OK && L->status == LUA_YIELD) status = LUA_YIELD;
   /* continue running after recoverable errors */''')
# The top-level ccall already propagates a normal luaV_execute return and balances nCcalls.
change('src/lvm.c','''        if ((newci = luaD_precall(L, ra, nresults)) == NULL)
          updatetrap(ci);  /* C call; nothing else to be done */''','''        if ((newci = luaD_precall(L, ra, nresults)) == NULL) {
            if (L->status == LUA_YIELD) return; /* Lux leaf, C frame remains suspended */
            updatetrap(ci);  /* ordinary C call */
          }''')
change('src/ldo.c','LUA_API int lua_isyieldable (lua_State *L) {','''static int lux_leaf_eligible (lua_State *L) {
  CallInfo *ci = L->ci;
  const l_uint32 top_allowed = CIST_C | CIST_NRESULTS | CIST_LUXCALL;
  if (!yieldable(L) || L->status != LUA_OK || L->hookmask != 0 ||
      L->tbclist.p != L->stack.p || L->lux_resume_boundary == NULL ||
      L->errorJmp != L->lux_resume_boundary || !(ci->callstatus & CIST_LUXCALL) ||
      (ci->callstatus & ~top_allowed) != 0) return 0;
  ci = ci->previous;
  if (ci == &L->base_ci) return 0;
  for (; ci != &L->base_ci; ci = ci->previous) {
    if (!isLua(ci) || (ci->callstatus & ~(CIST_NRESULTS | CIST_FRESH)) != 0 ||
        GET_OPCODE(ci->u.l.savedpc[-1]) != OP_CALL) return 0;
    if ((ci->callstatus & CIST_FRESH) && ci->previous != &L->base_ci) return 0;
  }
  return 1;
}

LUA_API int luxlua_yieldleaf (lua_State *L, lua_KContext ctx, lua_KFunction k) {
  lua_lock(L);
  if (k == NULL || !lux_leaf_eligible(L)) {
    L->lux_leaf_fallbacks++;
    lua_unlock(L);
    return lua_yieldk(L, 0, ctx, k);
  }
  luai_userstateyield(L, 0);
  L->ci->u.c.k = k;
  L->ci->u.c.ctx = ctx;
  L->ci->u2.nyield = 0;
  L->status = LUA_YIELD;
  L->lux_leaf_yields++;
  lua_unlock(L);
  return -1; /* interpreted only by the enclosing precallC/OP_CALL pair */
}

LUA_API void luxlua_leafstats (lua_State *L, unsigned long long *fast, unsigned long long *fallback) {
  *fast = L->lux_leaf_yields;
  *fallback = L->lux_leaf_fallbacks;
}

LUA_API int lua_isyieldable (lua_State *L) {''')
p=r/'cmake/dependencies/lua55/patches/leaf-yield-r1.patch';p.parent.mkdir(exist_ok=True)
patch=''.join(''.join(difflib.unified_diff((o/f).read_text().splitlines(True),t.splitlines(True),fromfile='a/'+f,tofile='b/'+f)) for f,t in sorted(changes.items()))
p.write_text(patch)
print('PATCH',len(changes),len(patch))
