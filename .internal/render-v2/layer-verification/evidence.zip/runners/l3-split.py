from pathlib import Path
import re,textwrap
r=Path('E:/RenderV2Rebuild/Layer/source');base=r/'modules/function/render/runtime'
p=base/'src/RenderServer.cpp';s=p.read_text()
# Mask comments/literals for brace counting without changing offsets.
pattern=r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|\x27(?:\\.|[^\x27\\])*\x27'
def mask(t):return re.sub(pattern,lambda m:''.join('\n' if c=='\n' else ' ' for c in m[0]),t)
def endbrace(t,a):
 m=mask(t);depth=0
 for i in range(a,len(t)):
  if m[i]=='{':depth+=1
  elif m[i]=='}':
   depth-=1
   if depth==0:return i+1
 raise RuntimeError('brace')
impl_start=s.index('    struct RenderServer::Impl final');openpos=s.index('{',impl_start);impl_end=endbrace(s,openpos)+1
impl=s[impl_start:impl_end];nested_a=impl.index('        struct CompileState final');nested_b=endbrace(impl,impl.index('{',nested_a))+1
compile_state=impl[nested_a:nested_b];impl=impl[:nested_a]+'        struct CompileState;'+impl[nested_b:]
groups={
'Bootstrap':['Impl','diagnostic'],
'Registration':['addCommand','validateHandlers'],
'Scene':['withdraw','attach','resize','createScene','removeScene','createView','removeView','createTarget','resizeTarget','detach'],
'Effect':['compileEffect','createEffect','removeEffect'],
'Completion':['settle','cancelReadbacks','readback','armReadback','finishReadback','finishGpu','reserveCompletion','completeCpu','deferCommand','drainCompletions'],
'Loop':['tick','queryRenderStats','stopCommand','dispatch','shutdown']}
output={k:[] for k in groups}
# Extract member definitions. Templates remain in the sole private Impl definition.
for group,names in groups.items():
 for name in names:
  match=re.search(r'^        [^\n;{]*\b'+name+r'\(',impl,re.M)
  assert match,(group,name)
  a=match.start();par=impl.index('(',match.start());m=mask(impl);depth=0
  for j in range(par,len(impl)):
   if m[j]=='(':depth+=1
   elif m[j]==')':
    depth-=1
    if depth==0:break
  if name=='Impl':body=impl.index('\n        {',j)+9
  else:body=impl.index('{',j)
  end=endbrace(impl,body);header=impl[a:body].rstrip();bodytext=impl[body:end]
  decl=header
  if name=='Impl':decl=header[:header.index('\n            :')]
  impl=impl[:a]+decl+';'+impl[end:]
  defhead=textwrap.dedent(header).replace('static ','',1) if header.lstrip().startswith('static ') else textwrap.dedent(header)
  defhead=re.sub(r'\b'+name+r'\(',('RenderServer::Impl::Impl(' if name=='Impl' else 'RenderServer::Impl::'+name+'('),defhead,count=1)
  # Defaults belong only to declarations.
  defhead=defhead.replace(' = nullptr','').replace(' = {}','').replace(' = false','').replace(' = 128','')
  definition=defhead+'\n'+textwrap.dedent('        '+bodytext)
  output[group].append(textwrap.indent(definition,'    '))
# Private object model: one definition, no anonymous namespace types duplicated between TUs.
models=s[s.index('    namespace\n'):impl_start].replace('    namespace\n','    namespace runtime_detail\n',1)
headers='''#pragma once

#include <lux/engine/render/runtime/RenderServer.hpp>
#include <lux/engine/render/runtime/RenderClient.hpp>
#include <lux/engine/render/runtime/Commands.hpp>
#include <lux/engine/render/native/vulkan/ExecutionContext.hpp>
#include <lux/engine/platform/ipc/IpcCore.hpp>
#include "TypedProtocol.hpp"
#include "Deferred.hpp"
#include <lux/cxx/core/CheckedArithmetic.hpp>
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <thread>

namespace lux::render
{
    namespace ipc = platform::ipc;
    using namespace runtime_detail;

'''
(base/'pinclude/ServerImpl.hpp').write_text(headers+models+impl+'\n}\n')
# Existing out-of-class blocks retain exact code; only their implementation file changes.
rest=s[impl_end:];rest=rest[:rest.rfind('}')]
tables_end=rest.index('    RenderServer::RenderServer')
output['Completion'].append(rest[:tables_end].strip('\n'));rest=rest[tables_end:]
# Namespace-level function definitions have a four-space signature.
while rest.strip():
 rest=rest.lstrip('\n');a=0
 brace=mask(rest).find('{');end=endbrace(rest,brace)
 block=rest[:end];rest=rest[end:]
 if '::registerFeature' in block.split('{',1)[0] or '::registerStorage' in block.split('{',1)[0]:group='Registration'
 elif '::run(' in block.split('{',1)[0] or '::stop(' in block.split('{',1)[0] or '::stats(' in block.split('{',1)[0]:group='Loop'
 else:group='Bootstrap'
 output[group].append(block)
cs=textwrap.dedent(compile_state).replace('struct CompileState final','struct RenderServer::Impl::CompileState final',1)
output['Effect'].insert(0,textwrap.indent(cs,'    '))
for group,blocks in output.items():
 extra=''
 if group=='Bootstrap':extra='#include <lux/engine/platform/Random.hpp>\n'
 target='RenderServer.cpp' if group=='Bootstrap' else 'Server'+group+'.cpp'
 content='#include "ServerImpl.hpp"\n'+extra+'\nnamespace lux::render\n{\n'+ '\n\n'.join(blocks)+'\n}\n'
 (base/'src'/target).write_text(content)
# Use exactly the same source set for production and all compile-time fault seams.
paths=['src/RenderServer.cpp']+['src/Server'+g+'.cpp' for g in groups if g!='Bootstrap']+['src/Request.cpp']
p=base/'CMakeLists.txt';s=p.read_text();old='SOURCE_FILES src/RenderServer.cpp src/Request.cpp';s=s.replace(old,'SOURCE_FILES ${LUX_RUNTIME_SOURCES}');pos=s.index('add_component(\n    STATIC\n    COMPONENT_NAME render_runtime');s=s[:pos]+'set(LUX_RUNTIME_SOURCES\n    '+'\n    '.join('${CMAKE_CURRENT_SOURCE_DIR}/'+v for v in paths)+'\n)\n\n'+s[pos:];s=s.replace('lux::cxx::concurrent bcrypt','lux::cxx::concurrent lux::engine::platform::platform_process');s=s.replace('"find_package(lux-cxx CONFIG REQUIRED COMPONENTS concurrent)"','"find_package(lux-cxx CONFIG REQUIRED COMPONENTS concurrent)"\n    [=[find_package(lux-engine-platform CONFIG REQUIRED COMPONENTS platform_process\n        HINTS "${CMAKE_CURRENT_LIST_DIR}/../../lux-engine-platform")]=]');p.write_text(s)
p=base/'test/CMakeLists.txt';s=p.read_text().replace('../src/RenderServer.cpp ../src/Request.cpp','${LUX_RUNTIME_SOURCES}').replace(' bcrypt',' lux::engine::platform::platform_process');p.write_text(s)
