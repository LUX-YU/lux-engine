"""One retained Lua55 baseline and final candidate, three alternating independent runs per workload."""
import csv,ctypes as ct,hashlib,json,os,re,shutil,statistics,struct,subprocess,time
from pathlib import Path
r=Path(__file__).parent
dev=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/o/w/d')
tool=dev.parent/'t'
baseline=r.parent/'lua55-v2/final-image'
final=r/'final-image';final.mkdir(exist_ok=False)
out=r/'final-costs';out.mkdir(exist_ok=False)
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def imports(p):
    b=p.read_bytes();nt=struct.unpack_from('<I',b,60)[0]
    count=struct.unpack_from('<H',b,nt+6)[0];size=struct.unpack_from('<H',b,nt+20)[0];opt=nt+24
    directories=opt+(112 if struct.unpack_from('<H',b,opt)[0]==0x20b else 96)
    sections=[struct.unpack_from('<IIII',b,opt+size+i*40+8) for i in range(count)]
    def offset(rva):
        for vs,va,rs,raw in sections:
            if va<=rva<va+max(vs,rs):return raw+rva-va
        raise ValueError((p,rva))
    result=[]
    for index,stride,field in [(1,20,12),(13,32,4)]:
        address=struct.unpack_from('<I',b,directories+index*8)[0]
        if not address:continue
        at=offset(address)
        while any(b[at:at+stride]):
            name=struct.unpack_from('<I',b,at+field)[0]
            pos=offset(name);result.append(b[pos:b.index(0,pos)].decode('ascii'));at+=stride
    return result
queue=['script_runtime_benchmark.exe','physics2d_script_benchmark.exe','simulation_script_lua_value_runtime_test.exe']
saved={};external=set()
while queue:
    name=queue.pop()
    if name.lower() in saved:continue
    candidates=[dev/'bin'/name,Path('D:/Development/vcpkg/installed/x64-windows/bin')/name]
    p=next((p for p in candidates if p.exists()),None)
    if not p:external.add(name);continue
    shutil.copy2(p,final/name);saved[name.lower()]=dict(path=str(p),sha256=sha(p))
    for pdb in [p.with_suffix('.pdb')]:
        if pdb.exists():shutil.copy2(pdb,final/pdb.name)
    queue+=imports(p)
assert sha(final/'lux_lua55.dll')==sha(Path('E:/SyncForder/CodeRepos/install/o/v3/lua55/bin/lux_lua55.dll')), 'stale app-local VM'
fixtures={}
for name,source in [('lua_runtime_benchmark_fixture.lxsa',tool/'engine/toolchain/lua'),
    ('physics2d_lua_fixture.lxsa',tool/'engine/toolchain/physics2d'),
    ('physics2d_flowforge_fixture.lxsa',tool/'engine/toolchain/physics2d')]:
    p=source/name;shutil.copy2(p,final/name);fixtures[name]=sha(p)
identity=dict(source=json.loads((r/'qualified-d-build.json').read_text(encoding='utf-8-sig'))['source'],
    images=saved,fixtures=fixtures,system_imports=sorted(external),
    vm=json.loads(Path('E:/SyncForder/CodeRepos/install/o/v3/lua55/share/LuxLua55/identity.json').read_text()))
(final/'identity.json').write_text(json.dumps(identity,indent=2))
b0=json.loads((baseline/'identity.json').read_text())
assert b0['source']=='a6f16d6de6a67f6a4422553d31b42c1ac2b3e4c0'
for name in saved:
    p=baseline/name
    if p.exists():
        expected=next((v['sha256'] for k,v in b0['images'].items() if k.lower()==name),None)
        if expected: assert sha(p)==expected,('modified baseline image',name)
assert fixtures['lua_runtime_benchmark_fixture.lxsa']==sha(baseline/'lua_runtime_benchmark_fixture.lxsa')
assert fixtures['physics2d_lua_fixture.lxsa']==sha(baseline/'physics2d_lua_fixture.lxsa')
(out/'identities.json').write_text(json.dumps(dict(baseline=b0,candidate=identity),indent=2))
kernel=ct.WinDLL('kernel32');kernel.GetCurrentProcess.restype=ct.c_void_p
kernel.SetProcessAffinityMask.argtypes=[ct.c_void_p,ct.c_size_t]
assert kernel.SetProcessAffinityMask(kernel.GetCurrentProcess(),16)
runs=[]
keys=['active_instances','calls','ability_calls','events','suspensions','resumes','continuations','awaitables',
      'event_waiters','queue_depth','checksum','physics_queries','script_calls','next_step_waits']
for scene in ['event','nextstep','scalar','record','physics']:
    for pair in range(3):
        for side in (['baseline','candidate'] if pair%2==0 else ['candidate','baseline']):
            image=baseline if side=='baseline' else final
            name=f'{scene}-{pair}-{side}';data=out/(name+'.csv');log=out/(name+'.log')
            if scene=='record':
                command=[str(image/'simulation_script_lua_value_runtime_test.exe'),'--benchmark','1000000']
                operations=1000000;unit='complete-nested-record-ability-call'
            elif scene=='physics':
                command=[str(image/'physics2d_script_benchmark.exe'),'--group','scene-physics-mixed',
                    '--mode','performance','--size','10000','--frames','2000','--warmups','300','--workers','0',
                    '--trace','off','--lua-artifact',str(image/'physics2d_lua_fixture.lxsa'),
                    '--flowforge-artifact',str(image/'physics2d_flowforge_fixture.lxsa'),'--output',str(data)]
                operations=2000;unit='mixed-physics-frame'
            else:
                group={'event':'scene-lua-event','nextstep':'scene-lua-coroutine',
                    'scalar':'micro-lua-ability-query'}[scene]
                command=[str(image/'script_runtime_benchmark.exe'),'--group',group,'--mode','performance',
                    '--size','10000','--frames','2000','--warmups','1000','--seed','1592598566',
                    '--resume-budget','10000','--vm-accounting','off','--lua-artifact',
                    str(image/'lua_runtime_benchmark_fixture.lxsa'),'--output',str(data)]
                operations=20000000;unit='complete-'+scene+'-operation'
            env=dict(os.environ)
            env['PATH']=';'.join([str(image),'D:/Development/vcpkg/installed/x64-windows/bin',
                *[p for p in env['PATH'].split(';') if 'CodeRepos' not in p and 'vcpkg' not in p]])
            started=time.monotonic()
            with log.open('wb') as f:code=subprocess.call(command,stdout=f,stderr=subprocess.STDOUT,env=env)
            text=log.read_text();rows=list(csv.DictReader(data.open())) if data.exists() else []
            times=sorted(int(row['nanoseconds']) for row in rows)
            counters={key:int(rows[-1][key]) for key in keys if rows and key in rows[-1]}
            valid=code==0 and len(rows)==2000
            errors=None;error_scope='';backlog=None
            if scene=='record':
                m=re.search(r'VALUE_BENCH count=1000000 ns=(\d+) operations=1000000 errors=0 backlog=0',text)
                valid=code==0 and m is not None and 'VALUE_CLEANUP invocation_errors=0' in text
                times=[int(m[1])] if m else []
                counters={'provider_calls_in_roi':1000000} if m else {}
                errors=0 if valid else None;backlog=0 if valid else None
                error_scope='runtime cumulative failure counter and provider/result/cleanup assertions'
            elif scene=='event':
                valid=valid and 'checksum=930010000' in text and text.count('invocation_errors=0')==2
                errors=0 if valid else None;backlog=counters.get('queue_depth')
                error_scope='runtime cumulative failure counter; independent per-instance readback and shutdown'
            else:
                valid=valid and text.count('invocation_errors=0')==2
                errors=0 if valid else None;backlog=counters.get('queue_depth')
                error_scope='runtime cumulative failure counter and shutdown; scalar/NextStep no per-instance readback'
            if rows:
                expected=b0['source'] if side=='baseline' else identity['source']
                valid=valid and all(row['git_commit']==expected and row['build_type']=='RelWithDebInfo' for row in rows)
            run=dict(scene=scene,pair=pair,side=side,command=command,exit=code,valid=valid,
                wall_seconds=time.monotonic()-started,total_ns=sum(times),actual_operations=operations,
                unit=unit,ns_per_actual_operation=sum(times)/operations,
                p50_batch_ns=statistics.median(times) if len(times)>1 else None,
                p95_batch_ns=times[1900] if len(times)==2000 else None,
                p99_batch_ns=times[1980] if len(times)==2000 else None,
                business=counters,errors=errors,error_scope=error_scope,backlog=backlog,
                allocations_scope='EXE-local counts in CSV; VM timing accounting disabled',affinity=16)
            runs.append(run);(out/'runs.json').write_text(json.dumps(runs,indent=2))
            print(name,code,valid,round(run['ns_per_actual_operation'],3),flush=True)
            if not valid:raise SystemExit('Invalid run '+name)
summary=[]
for scene in ['event','nextstep','scalar','record','physics']:
    deltas=[]
    for pair in range(3):
        values={run['side']:run for run in runs if run['scene']==scene and run['pair']==pair}
        assert values['baseline']['business']==values['candidate']['business'],('work mismatch',scene,pair)
        deltas.append(100*(values['candidate']['total_ns']/values['baseline']['total_ns']-1))
    summary.append(dict(scene=scene,deltas_percent=deltas,median_percent=statistics.median(deltas),
        faster_pairs=sum(d<0 for d in deltas),baseline_ns=statistics.median(run['ns_per_actual_operation']
        for run in runs if run['scene']==scene and run['side']=='baseline'),
        candidate_ns=statistics.median(run['ns_per_actual_operation'] for run in runs
        if run['scene']==scene and run['side']=='candidate')))
(out/'summary.json').write_text(json.dumps(summary,indent=2))
print('COSTS_COMPLETE',json.dumps(summary),flush=True)
