"""Single permitted H2 withdrawal diagnostic. Does not replace qualification outputs."""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
r=Path(__file__).parent; source=r.parent/'script-cell-a1/source'; build=r.parent/'o/w/t'
out=r/'h2-withdrawal';out.mkdir(exist_ok=False); image=out/'image'
shutil.copytree(r/'final-flow-image',image)
header='engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptExecution.hpp'
hp=out/'include/lux/engine/simulation/script/ScriptExecution.hpp';hp.parent.mkdir(parents=True)
old=subprocess.check_output(['git','-C',str(source),'show','f7d2815b:'+header]);hp.write_bytes(old)
(out/'withdrawal.diff').write_bytes(subprocess.check_output(['git','-C',str(source),'diff','65585540','f7d2815b','--',header]))
commands=subprocess.check_output(['ninja','-C',str(build),'-t','commands','bin/lux_engine_simulation_script.dll'],text=True).splitlines()
compile=next(x for x in commands if 'ScriptSystem.cpp' in x and (' /c ' in x or ' -c ' in x))
old_obj=re.search(r'/Fo(\S+)',compile)[1];obj=out/'ScriptSystem.obj'
compile=compile.replace(' /nologo ',f' /nologo /I{out / "include"} ',1)
compile=re.sub(r'/Fo\S+',lambda m:'/Fo'+str(obj),compile)
compile=re.sub(r'/Fd\S+',lambda m:'/Fd'+str(out/'compile.pdb'),compile)
link=next(x for x in reversed(commands) if 'vs_link_dll' in x and '/out:bin\\lux_engine_simulation_script.dll' in x).split(' -- ',1)[1].split(' && ',1)[0]
link=link.replace(old_obj,str(obj))
for option,oldpath,newpath in [('out','bin\\lux_engine_simulation_script.dll',image/'lux_engine_simulation_script.dll'),
 ('implib','lib\\lux_engine_simulation_script.lib',out/'script.lib'),
 ('pdb','bin\\lux_engine_simulation_script.pdb',image/'lux_engine_simulation_script.pdb')]:
 link=link.replace('/'+option+':'+oldpath,'/'+option+':'+str(newpath))
records=[]
for label,cmd in [('compile',compile),('link',link)]:
 with (out/(label+'.log')).open('wb') as f: code=subprocess.call(cmd,cwd=build,stdout=f,stderr=subprocess.STDOUT)
 records.append(dict(stage=label,command=cmd,exit=code));(out/'build.json').write_text(json.dumps(records,indent=2))
 if code: raise SystemExit(label+' failed')
manifest=dict(diagnostic_only=True,source='655855401e09aac2d4e8becd16afca62086291ee',
 overlay_from='f7d2815bdd2025ee23a7c11449def822413f58e9',overlay=header,overlay_sha256=hashlib.sha256(old).hexdigest(),
 images={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in image.iterdir() if p.suffix in ['.dll','.exe','.pdb']})
(out/'identity.json').write_text(json.dumps(manifest,indent=2))
print('H2_WITHDRAWAL_DIAGNOSTIC_BUILT',flush=True)
