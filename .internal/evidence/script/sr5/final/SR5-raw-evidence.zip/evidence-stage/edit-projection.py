from pathlib import Path
root = Path(__file__).parent / 'source'
p = root / 'engine/domain/simulation/scripting/lua/include/lux/engine/simulation/scripting/lua/LuaScriptAbilityProjection.hpp'
s = p.read_text()
start = s.index('    template <class... Arguments, std::size_t... Index>')
s = s[:start] + r'''
    template <class Policy, class... Arguments, std::size_t... Index>
    [[nodiscard]] bool readLuaAbilityArguments(lua_State* state,
        lux::script::lua::LuaValueSlots<std::remove_cvref_t<Arguments>...>& values,
        std::index_sequence<Index...>) noexcept
    {
        bool success = true;
        (([&]() noexcept {
            if (!success) return;
            using T = std::remove_cvref_t<Arguments>;
            lux::script::lua::LuaValueReader input{state, static_cast<int>(Index + 1)};
            auto value = lux::script::lua::LuaValueCodec<T, Policy>::read(input);
            if (value) values.template put<Index>(std::move(*value));
            else success = false;
        }()), ...);
        return success;
    }

    template <class Policy, class Result, class... Arguments, class Invoke>
    [[nodiscard]] int invokeLuaValueAbility(lua_State* state, Invoke invoke) noexcept
    {
        using namespace lux::script::lua;
        LuaPreparedAbilityAccess access;
        if (!LuaAbilityProjectionAccess::current(state, access))
            return LuaAbilityProjectionAccess::fail(state, -1, "invalid prepared Script Ability");
        if (access.argument_count != static_cast<int>(sizeof...(Arguments)))
            return LuaAbilityProjectionAccess::fail(state, -3, "Script Ability argument count mismatch");
        constexpr bool can_reenter = !((LuaValueScalar<std::remove_cvref_t<Arguments>> &&
            !requires { LuaValueOverride<std::remove_cvref_t<Arguments>, Policy>::name; }) && ...);
        if constexpr (can_reenter)
            access.validity = access.behavior ? access.behavior->captureInvocation() : ScriptInvocationValidity{};
        // This inner frame is gone before error formatting and the wrapper's success/error/yield protocol.
        const auto status = [&]() noexcept -> int {
            LuaValueSlots<std::remove_cvref_t<Arguments>...> values;
            if (!readLuaAbilityArguments<Policy, Arguments...>(state, values, std::index_sequence_for<Arguments...>{}))
                return -3;
            if constexpr (can_reenter)
                if (!LuaAbilityProjectionAccess::revalidate(state, access)) return -1;
            if constexpr (std::is_void_v<Result>)
            {
                values.apply([&](auto&... arguments) noexcept { invoke(access, arguments...); });
                return 0;
            }
            else
            {
                using Value = std::remove_cvref_t<Result>;
                static_assert(std::is_trivially_copyable_v<Value>);
                const Value result = values.apply([&](auto&... arguments) noexcept -> Result { return invoke(access, arguments...); });
                LuaValueWriter output{state};
                if (!LuaValueCodec<Value, Policy>::push(output, result)) return -5;
                return 1;
            }
        }();
        if (status < 0)
            return LuaAbilityProjectionAccess::fail(state, status, "Script Ability value conversion or authority failure");
        return LuaAbilityProjectionAccess::succeed(state, status);
    }

    template <class Result, class... Arguments, class Invoke>
    [[nodiscard]] int invokeLuaAbility(lua_State* state, Invoke invoke) noexcept
    { return invokeLuaValueAbility<lux::script::lua::LuaValuePolicy, Result, Arguments...>(state, invoke); }

    template <class Result, class... Arguments, class Start>
    [[nodiscard]] int startLuaAbility(lua_State* state, Start start) noexcept
    {
        using namespace lux::script::lua;
        LuaPreparedAbilityAccess access;
        if (!LuaAbilityProjectionAccess::current(state, access) || access.step == nullptr)
            return LuaAbilityProjectionAccess::fail(state, -1, "async Script Ability requires coroutine execution");
        if (access.argument_count != static_cast<int>(sizeof...(Arguments)))
            return LuaAbilityProjectionAccess::fail(state, -3, "Script Ability argument count mismatch");
        // New record/enum async protocols are not part of SR-5's first batch.
        if constexpr (!(LuaValueScalar<std::remove_cvref_t<Arguments>> && ...))
            return LuaAbilityProjectionAccess::fail(state, -5, "unsupported async Ability value");
        else
        {
            ScriptStepResult result;
            const auto converted = [&]() noexcept {
                LuaValueSlots<std::remove_cvref_t<Arguments>...> values;
                if (!readLuaAbilityArguments<LuaValuePolicy, Arguments...>(state, values, std::index_sequence_for<Arguments...>{}))
                    return false;
                result = invokeScriptAbilityAsync<Result>(*access.step,
                    [&](lux::script::ScriptAbilityCompletion<Result> completion) noexcept {
                        return values.apply([&](auto&... arguments) noexcept {
                            return start(access, arguments..., std::move(completion));
                        });
                    });
                return true;
            }();
            if (!converted) return LuaAbilityProjectionAccess::fail(state, -3, "Script Ability argument type mismatch");
            return LuaAbilityProjectionAccess::suspend(state, result, access.local_slot);
        }
    }
}
'''
p.write_text(s)
p = root / 'engine/domain/simulation/scripting/lua/src/LuaScriptBackend.cpp'
s = p.read_text().replace('*instance = Instance{\n                std::addressof(self),', '*instance = Instance{\n                context.behavior, std::addressof(self),')
p.write_text(s)
