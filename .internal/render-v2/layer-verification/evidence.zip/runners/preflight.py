from pathlib import Path
import subprocess, json, hashlib, re, shutil
root=Path('E:/RenderV2Rebuild/Layer')
source=root/'source'; out=root/'evidence/L0';out.mkdir(parents=True,exist_ok=True)
base='7ca2828d60df50e54ed299efeb1cbab20cf369ad'
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
assert git(source,'rev-parse','HEAD')==base
assert git(source,'rev-parse','origin/codex/render-v2-rebuild')==base
user=Path('E:/SyncForder/CodeRepos/lux-engine')
old=json.loads(Path('E:/RenderV2Rebuild/V11/evidence/preflight.json').read_text(encoding='utf-8-sig'))
assert git(user,'status','--porcelain')==old['user_status']
for name,digest in old['user_sha256'].items():
 assert hashlib.sha256((user/name).read_bytes()).hexdigest()==digest
for name,value in old['dependencies'].items():
 assert git(user.parent/name,'rev-parse','HEAD')==value['sha']
 assert git(user.parent/name,'status','--porcelain')==value['status']
manifest=json.loads((source/'docs/render-v2/LEGACY_SOURCE_MANIFEST.json').read_text())
def tree(rev):return {x.split('\t')[1]:x.split('\t')[0].split()[2] for x in git(source,'ls-tree','-rz',rev).split('\0') if x}
current=tree(base);frozen=tree(manifest['source_sha'])
for f in manifest['files']:
 assert f['blob']==current[f['destination']]==frozen[f['source']]
 assert git(source,'hash-object',f['destination'])==f['blob']
assert len(manifest['files'])==719
doc=Path('E:/Resources/3DModels/LuxEngine_RenderV2_Layering_Audit_and_Refactoring_Contract_v1_2026-10-16.zh-CN.md')
shutil.copy2(doc,out/doc.name)
worktrees=git(source,'worktree','list','--porcelain')
states={}
for line in worktrees.splitlines():
 if line.startswith('worktree '):
  p=Path(line[9:]);states[str(p)]={'head':git(p,'rev-parse','HEAD'),'status':git(p,'status','--porcelain')}
snapshot=dict(baseline=base,doc_sha256=hashlib.sha256(doc.read_bytes()).hexdigest(),legacy_count=719,
 user_head=git(user,'rev-parse','HEAD'),user_status=old['user_status'],user_sha256=old['user_sha256'],
 dependencies=old['dependencies'],worktrees=states,submodules=git(source,'submodule','status','--recursive'))
(out/'snapshot.json').write_text(json.dumps(snapshot,indent=2)+'\n')
inventory=json.loads(Path('E:/RenderV2Rebuild/V11R/evidence/test-inventory.json').read_text())
assert len(inventory['names'])==98
(out/'test-names.json').write_text(json.dumps(inventory['names'],indent=2)+'\n')
tokens=['OwnedWireBytes','WireView','BorrowedWireView','WireLimits','DataSchema<','encodeWire','decodeWire',
 'SelectedFeature','FeatureDefinition','ECommandOwner','CommandHandler','StorageFactory','nativeStorageBinding',
 'compileGraph','configureType','textureStorageFactory','programArguments','BCryptGenRandom']
files=[p for p in (source/'modules/function/render').rglob('*') if p.suffix in ('.hpp','.cpp','.cmake','.txt')]
uses=[];includes=[];cmake=[]
for p in files:
 text=p.read_text(encoding='utf-8-sig');relative=p.relative_to(source).as_posix()
 for n,line in enumerate(text.splitlines(),1):
  matches=[t for t in tokens if t in line]
  if matches:uses.append(dict(file=relative,line=n,symbols=matches,text=line.strip()))
  m=re.match(r'\s*#include\s*[<"]([^>"]+)',line)
  if m:includes.append(dict(file=relative,include=m[1]))
 if p.name=='CMakeLists.txt' or p.suffix=='.cmake':cmake.append(dict(file=relative,text=text))
(out/'consumers.json').write_text(json.dumps(uses,indent=2)+'\n')
(out/'include-edges.json').write_text(json.dumps(includes,indent=2)+'\n')
(out/'cmake-inputs.json').write_text(json.dumps(cmake,indent=2)+'\n')
print(json.dumps(dict(baseline=base,legacy=719,tests=98,consumer_lines=len(uses),include_edges=len(includes),document_sha256=snapshot['doc_sha256']),indent=2))
