from pathlib import Path
r=Path.cwd();p=r/'local-phases.py';t=p.read_text()
t=t.replace("tree=list(csv.DictReader((p/'top-down.csv').open()));stack=[];groups={};details={}","raw_lines=(p/'top-down.csv').read_text().splitlines();header=next(csv.reader([raw_lines[0]],skipinitialspace=True));tree=[]\n for line in raw_lines[1:]:\n  if not line.strip():continue\n  values=next(csv.reader([line],skipinitialspace=True));assert len(values)==len(header),line\n  row=dict(zip(header,values));row['depth']=len(line)-len(line.lstrip());tree.append(row)\n stack=[];groups={};details={}")
t=t.replace("depth=len(label)-len(label.lstrip())","depth=row['depth']")
t=t.replace("seconds=float(row['CPU Time:Self']) if row['CPU Time:Self'] else 0.0", "seconds=float(row['CPU Time:Self'])")
p.write_text(t)
