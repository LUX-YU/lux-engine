from pathlib import Path
import csv,json,re,statistics,subprocess
r=Path(__file__).parent;repo=r.parent/'script-cell-a1/source';out=repo/'.internal/script-v4-h1'
def read(p):return json.loads((r/p).read_text(encoding='utf-8-sig'))
audit=read('final-audit.json');source=audit['source'];runs=read('final2-costs/runs.json');summary=read('final2-costs/summary.json')
assert len(runs)==42 and all(x['valid'] for x in runs)
consumers=read('installed-final2/consumers.json');incremental=read('value-incremental-final2/probes.json');relocated=read('relocated-final2/results.json')
assert len(consumers)==15 and all(x['status']=='PASS' for x in consumers)
assert len(incremental)==13 and len(relocated)==2 and all(x['status']=='PASS' for x in relocated)
tests={}
for slot in ['d','t']:
 record=read(f'final2-{slot}-tests.json');assert record['exit']==0
 text=(r/f'final2-{slot}-tests.log').read_text(encoding='utf-8-sig')
 count=int(re.search(r'out of (\d+)',text)[1]);tests[slot]=dict(count=count,exit=0,source=source,log=f'final2-{slot}-tests.log')
layout=(r/'layout-final2/B/run.log').read_text();other=(r/'layout-final2/A/run.log').read_text()
assert [x for x in layout.splitlines() if x.startswith(('SIZE ','BACKING ','OLD_WAIT ','LAYOUT_'))]==[x for x in other.splitlines() if x.startswith(('SIZE ','BACKING ','OLD_WAIT ','LAYOUT_'))]
sizes={m[1]:int(m[2]) for m in re.finditer(r'^SIZE (.*?)=(\d+)',layout,re.M)}
backing=[dict(name=m[1],object=int(m[2]),dynamic=int(m[3]),total_requested=int(m[4]),allocations=int(m[5]))
 for m in re.finditer(r'^BACKING (\S+) object=(\d+) dynamic=(\d+) total_requested=(\d+) allocations=(\d+)',layout,re.M)]
owned=sum(x['dynamic'] for x in backing)+sum(sizes[x] for x in ['ScriptExecution','ScriptEventWaits','ScriptTimers','ScriptCompletionIngress'])
matrix=list(csv.DictReader((out/'TEST_MATRIX.csv').open(encoding='utf-8-sig')))
incomplete=[x['test_id'] for x in matrix if x['status'].startswith('PARTIAL')]
cost='NO_CLEAR_GAIN'
record=dict(schema_version=1,task='V4-H1 prepared checks',implementation='PARTIAL',contract='INCOMPLETE' if incomplete else 'PASS',cost=cost,
 source=source,baseline_source='f7d2815bdd2025ee23a7c11449def822413f58e9',withdrawn_candidate='655855401e09aac2d4e8becd16afca62086291ee',
 branch='codex/s6-v4-prepared-checks',report_commit_is_qualification_source=False,
 stages=dict(H0='COMPLETE_WITH_ROI_LIMIT',H1='RETAINED',H2='IMPLEMENTED_AND_WITHDRAWN_COST',H3='RETAINED',
 Native_arithmetic='NOT_SELECTED_METADATA_TRADEOFF',H4='ALREADY_BOUNDARY_ONLY',H5='COMPLETE'),
 configuration=dict(build='RelWithDebInfo',lua='5.5.1 + lux-lua55-v3-r2',gc='INC upstream defaults',idle_page_budget=16777216,
 native_abi=6,lux_cxx='3100f54d0743c5ed94a4ccf5943df04e933de255',toolset='99c3d0480d1db816779b1dfa7f3c06cb7d39a94f',
 compiler='MSVC19.44.35228 /O2 /Ob1 /MD /Zi /DNDEBUG; test assertions /UNDEBUG',affinity_mask=16),
 tests=tests,vm_contracts=dict(count=4,exit=0,log='final-vm-tests.log',unchanged_vm=True),
 installed_consumers=consumers,incremental=incremental,relocated=relocated,
 costs=summary,runs=runs,prewithdrawal_costs=read('final-costs/summary.json'),withdrawal_diagnostic=read('h2-withdrawal-costs/summary.json'),
 trial_counts=dict(prewithdrawal_valid=42,related_withdrawal_valid=6,final_valid=42,invalid_timing=0),
 resources=dict(sizes=sizes,backing=backing,selected_owner_bytes=owned,logical_N=10000,physical_A_slots=10240,
 scope='selected four owners and N methods/one Event endpoint, not whole engine/RSS; requested allocation bytes include probe header/alignment',
 additional_proof_storage_bytes=0,vm_allocations=None,rss=None,heap_calls=None,executable_allocations='see each raw run; DLL/VM allocations not inferred'),
 artifact_identity=audit,profile=dict(count=5,mode='software10ms',roi='whole target process including setup/warmup/cleanup; no ITT ROI',
 pmu=None,candidate_profile=None,exports='baseline-profile/*/{summary,hotspots,top-down}.csv',machine_code='machine-A-full;machine-B-full(withdrawn);machine-B2-full(final)'),
 limitations=['H2 not adopted after measured regression; not a fully delivered H1/H2/H3 performance optimization',
 'Three pairs do not establish performance equivalence; final micro residuals remain unexplained',
 'Software sampling is coarse and has no PMU; ValuePose sample short',
 'No new old-VM/Android qualification; retained V4 scalar and Native metadata debts',
 'MSVC deep public expected wrapper limitation not fixed',
 'Timing disables VM/allocator/leaf statistics: null is unobserved; C++ Sequence cumulative runtime failure counter unavailable'],
 incomplete_matrix=incomplete,
 failures=['attempt1 final all: new test signature exceeded120columns; fixed65585540',
 'five unsupported VTune bottom-up report requests; valid exports separately retained',
 'contract driver command parsing then quoting failures, corrected raw compiler commands',
 'first final2 driver path-replacement typo before any build, corrected',
 'Native boundary diagnostic compile used nonexistent default constructor; corrected unique_ptr reset',
 'Native boundary diagnostic initial max_ability_imports=0 rejected by unchanged configuration gate; corrected config',
 'Pin diagnostic moved source lost its quoted sibling include; added original test include directory',
 'Outer PowerShell emitted nonfatal input-line-too-long warning; source not isolated; individual target exits/oracles and identities validated',
 'H2 valid-but-slower production experiment withdrawn; never classify as invalid timing'])
(out/'result.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
lines=['# V4-H1 实施结果\n',f'实际交付保留 H1 Native prepared step 去重和 H3 checked release 收敛。H2 已编码、验证并撤回，原因是实测 FlowForge Event 回退。',
 f"`implementation=PARTIAL`；`contract={record['contract']}`；`cost={cost}`。不宣称全路径提速或性能等价。",
 '## 身份\n',f'固定 V4 `{record["baseline_source"]}`；撤回前候选 `{record["withdrawn_candidate"]}`；**最终资格与计时源码 `{source}`**。后续文档/证据提交不是新测量身份。',
 '分支 `codex/s6-v4-prepared-checks`；V4 分支 f92853ea、A1 分支1039f2bc 保留；main 的7个未知文件及原始镜像哈希不变。独立 clean clone 构建，独立 `install/o/v4-h1/{sdk,tools}`。',
 'Lua5.5.1 + lux-lua55-v3-r2、INC、16MiB、Native ABI6、lux-cxx3100f54d、toolset99c3d048、MSVC19.44.35228 /O2 /Ob1 /MD 与 V4 相同。三份 cooked fixture 字节相同。详见 result.json 和归档 final-audit.json。',
 '## 实际变化与未采用项\n',
 '| 项目 | 实施/结论 |\n|---|---|',
 '| H0 | 五份 V4 软件热点、调用栈和 A/B PDB 指令片段；只有全目标进程范围，没有精确循环ROI/PMU。 |',
 '| H1 / 9ecc5432 | checked入口定位step一次；create内核不重复非零size/对齐/上界；slot、frame、lease、packet、outcome及销毁顺序保留。 |',
 '| H2 / f7f7b1c1 → 7c565a00撤回 | Event prepared/raw gateway共用动态内核曾完整落地；custom ABI残余检查保留。最终 ScriptExecution.hpp 恢复V4，新负例继续保留。 |',
 '| H3 / c85c40f1 | Ticket与Allocation各自验证后进入private releaseResolved；不合成Allocation再验证自身。完整代次/owner/data-size错误仍拒绝。 |',
 '| Native固定除法 | NOT_SELECTED_METADATA_TRADEOFF：实际div仍在；缓存商使Class32B→40B，目录按prepared容量增长，未采用。 |',
 '| H4 | ALREADY_BOUNDARY_ONLY：Lua current一次prepared解析，revalidate无目录重复；默认scalar can_reenter优化是V4既有成果。Lua生产源码未改。 |',
 '检查逐谓词的证明、失效点、原拒绝入口、源行及机器码见 [CHECK_AUDIT.csv](CHECK_AUDIT.csv)。实际断言和覆盖范围见 [TEST_MATRIX.csv](TEST_MATRIX.csv)。',
 '## H2 的负结果\n',
 '65585540 对 V4 的 FlowForge Event 三对 +2.765% / +0.532% / +5.951%。唯一一次有限撤销诊断只换回 V4 ScriptExecution.hpp，保留其余候选DLL：三对 -4.386% / -4.023% / -4.163%，业务完全相同。因而撤回H2，不尝试 forceinline 或第二轮消融调参。',
 '机器码支持具体代价：H2 把完整 reserve 内核变为额外调用目标；waitEvent体积1080B→1228B。只能把整项改动视为已定位成本，不能将13ns全部精确分摊给某个分支。撤回前42个有效进程、6个撤销对照均保留。撤回改变了最终源码，故另行绑定最终构建/安装及下列42进程；不复用旧数据重标身份。',
 '## 最终七腿同量对照\n',
 'A为固定V4，B为最终7c565a00；各3对AB/BA/AB。变化为 `(B/A-1)`，负值更快；“配对中位”不是两侧中位数相除。',
 '| 场景 / 单位 | 三对 A → B | 每对变化 | 配对中位 |\n|---|---|---|---:|']
for x in summary:
 scale=1e6 if x['unit']=='whole-simulation-frame' else 1
 unit='ms/完整帧' if scale!=1 else 'ns/完整调用或等待周期'
 pairs='；'.join(f'{a/scale:.3f}→{b/scale:.3f}' for a,b in zip(x['paired_ns']['A'],x['paired_ns']['B']))
 lines += [f"| {x['scene']} / {unit} | {pairs} | {' / '.join(f'{v:+.2f}%' for v in x['deltas_percent'])} | {x['median_percent']:+.2f}% |"]
lines += ['正式负载不变：Lua三腿10000实例×2000帧，预热1000；FlowForge Event10000×1000帧，预热300；ValuePose100万双向调用，预热1000；C++ Sequence原1000完整帧，未额外drain；Physics原2000完整帧、预热300、workers0。每条CSV业务列逐行A/B相等，所有进程exit0。',
 '批量总ns、p50/p95/p99/max帧、累计calls/resumes/suspensions、错误与backlog见result.json.runs及原CSV。它们是帧分布，不是逐resume延迟测量。ValuePose只有批量计时，没有伪造逐调用p99。C++ Sequence未暴露累计失败计数，保留null；其它腿的错误观测位于计时区间外。VM统计关闭为null，不是0。',
 '## 资源和机器码\n',
 f'最终A/B sizeof与选定owner backing逐项相同：PreparedInvocation32、C72、A192、Ready24、EventWaiter88、TimerWait104、BoundedClassStorage208、Ticket24、Native Class32。逻辑N=10000，物理A=10240；选定四owner与N方法/单endpoint的动态存储加对象共 **{owned:,}B**。该口径含诊断分配header/alignment，不是引擎总内存、RSS或Lua VM统计。详见layout-final2原始输出。',
 '未新增成员、证书、cell、结果池或身份目录。Native create机器码228→187B，分支指令10→4；invoke1035→993B。C++ Ticket186→165B，Allocation410→198B，新增共享内核195B；Native/Lua相同模板的内联结果不同。分支数含跳转，不能据此推断预测失败率。Lua current548B/revalidate215B保持。每个DLL/PDB/RVA见machine索引，实际文件大小见final-audit.json。',
 '## 验证与原始记录\n',
 f"最终Developer **{tests['d']['count']}/{tests['d']['count']}**，Toolchain **{tests['t']['count']}/{tests['t']['count']}**；两轮target all -j4 -- -k0与no-work检查通过。固定VM4/4；当前SDK15/15、增量13类、迁址2/2真实运行。迁址时原源码/构建/SDK/VM路径隐藏，随后全部恢复。",
 '新增并重放：释放prepared入口拒绝；Event source/A双满；4种custom payload原阶段拒绝；Ticket两种统计模式坏释放；Native冷描述8种×A/B；Native实际packet六种错误和ABI/outcome八场景×A/B。native-boundary探针中provider/backend resume计数、frame和lease释放均实测。',
 '基线与65585540的8条新轨迹相同；最终CTest保留全部新增断言。另以最终DLL重放容量1的pin内取消/嵌套登记：activeA已0仍因物理槽被pin占据而拒绝新等待；两侧关闭后均清零。机器码、布局和SDK均绑定最终7c565a00。完整路径和错误范围在矩阵中展开，不用测试名相似替代断言。',
 '原始日志只归档一份：[证据入口](../evidence/script/script-v4-h1/INDEX.md)。本机原始目录 `E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-v4-h1`；原VTune result可直接打开。诊断源/命令/哈希随归档交付。',
 '## 失败、限制与停止点\n',
 '保留首次style失败、报表参数失败、诊断编译/配置修正日志。Native诊断的无默认构造编译失败和max_ability_imports=0冷拒绝属于驱动问题，没有调整生产拒绝行为。外层PowerShell还输出一次input-line-too-long警告，具体初始化命令未隔离；各构建/运行目标退出码和业务oracle独立通过，警告原文保留。H2是有效负结果，未按“异常慢样本”删除。',
 '未解决V4 scalar成本和Native metadata债务；未改VM/GC/allocator/ISA/IPO/原资产。没有PMU、逐恢复延迟或新增RSS观测；没有重测Lua54/JIT或Android。既有MSVC深层public expected包装器限制仍在。',
 '建议只审阅最终保留的H1/H3及测试；H2本轮收口为未采用，整体实施标PARTIAL。成本结论只对实际分布成立，不授予性能等价，也不把未解释差额归为必要安全成本。停止于本分支，未合并V4/main、未发tag，等待独立审阅。']
(out/'RESULT.zh-CN.md').write_text(re.sub(r'(?<=\|)\n\n(?=\|)', '\n', '\n\n'.join(lines))+'\n',encoding='utf-8')
print('FINAL_REPORT_WRITTEN',source,owned,cost,record['contract'])
