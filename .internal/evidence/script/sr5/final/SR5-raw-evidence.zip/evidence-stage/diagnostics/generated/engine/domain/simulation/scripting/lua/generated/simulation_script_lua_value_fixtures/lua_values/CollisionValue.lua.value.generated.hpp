#pragma once
// Generated typed value operations. No offsets or runtime reflection interpretation.
#include <lux/engine/function/script/lua/LuaValue.hpp>
#include <CollisionValue.hpp>
#include "E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/candidate-source/engine/domain/simulation/scripting/lua/test/LuaValueTestRules.hpp"

namespace lux::script::lua
{


template <> struct LuaGeneratedValue<::CollisionEvent> : LuaRecordValue<::CollisionEvent,
    LuaValueField<&::CollisionEvent::body, "body">,
    LuaValueField<&::CollisionEvent::impulse, "impulse">>
{
};
static_assert(LuaValueCodec<::CollisionEvent>::bounded, "Lua value expanded frame exceeds 64 KiB or depth 32");
}
