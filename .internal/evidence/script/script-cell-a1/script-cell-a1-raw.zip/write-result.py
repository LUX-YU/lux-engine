from pathlib import Path
import csv,hashlib,json,re,statistics,subprocess
r=Path(__file__).parent;source=r/'source';dest=source/'.internal/script-cell-a1'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
summary=read(r/'final-costs/summary.json');runs=read(r/'final-costs/runs.json');resources=read(r/'resource-diagnostic/results.json')
layouts={}
for side in ['A','B']:
 text=(r/'layout'/side/'run.log').read_text();sizes={k:int(v) for k,v in re.findall(r'^SIZE (.*?)=(\d+)$',text,re.M)}
 backing=[]
 for name,obj,dynamic,total,allocs in re.findall(r'^BACKING (\S+) object=(\d+) dynamic=(\d+) total_requested=(\d+) allocations=(\d+)',text,re.M):
  backing.append(dict(name=name,object_bytes=int(obj),live_requested_bytes=int(dynamic),cumulative_requested_bytes=int(total),allocation_calls=int(allocs)))
 owner=sum(sizes['Script'+x] for x in ['Execution','EventWaits','Timers','CompletionIngress'])
 layouts[side]=dict(sizes=sizes,backing=backing,profile={'C':10000,'A':10000,'ready':10000,'event_waits':10000,
  'timer_waits':10000,'instances':10000,'methods':10000,'event_endpoints':1,'external_queue':10000},
  four_owners_bytes=owner,dynamic_bytes=sum(x['live_requested_bytes'] for x in backing),
  four_owners_with_owned_backing=owner+sum(x['live_requested_bytes'] for x in backing),
  spill_bytes_in_probe=0,peak_active_cell_bytes=None,distinct_cell_addresses_touched=None,
  scope='Execution, EventWaits, Timers, CompletionIngress only; includes all bank/directories/sources/ready/transport arrays. Excludes unchanged Instances/Bindings/Preparer/backend/VM and system heap overhead.')
counts={}
for resource in resources:
 side=resource['side'];scene=resource['scene'];values={}
 for line in resource['observations']:
  match=re.match(r'CELL_COUNT,[^,]+,steady,(\w+)=(\d+)$',line)
  if match:values[match[1]]=int(match[2])
 counts[scene+'-'+side]=values if side=='B' else None
names={'event':'Lua Event','nextstep':'Lua NextStep','flowforge-event':'FlowForge Event','cpp-sequence':'C++ Sequence','scalar':'Lua scalar','record':'ValuePose record','physics':'Physics mixed'}
rows=[]
for entry in summary:
 scene=entry['scene'];selected=[x for x in runs if x['scene']==scene]
 times={s:[next(x for x in selected if x['side']==s and x['pair']==p)['total_measured_ns']/1e9 for p in range(3)] for s in ['A','B']}
 entry['whole_batch_seconds']=times
 entry['A_median_batch_p95_ns']=statistics.median(x['measurements'][0]['p95_batch_ns'] for x in selected if x['side']=='A') if scene!='record' else None
 entry['B_median_batch_p95_ns']=statistics.median(x['measurements'][0]['p95_batch_ns'] for x in selected if x['side']=='B') if scene!='record' else None
 rows.append('| '+names[scene]+' | '+('ms/整帧' if scene in ['physics','cpp-sequence'] else 'ns/完整周期或调用')+' | '+
  f"{entry['A_ns']/(1e6 if scene in ['physics','cpp-sequence'] else 1):.3f} → {entry['B_ns']/(1e6 if scene in ['physics','cpp-sequence'] else 1):.3f}"+' | '+
  '/'.join(f'{x:+.2f}%' for x in entry['deltas_percent'])+' | '+f"{entry['median_percent']:+.2f}%"+' |')

# Explicit assertion mapping, not name-based coverage inference.
E='engine/domain/simulation/builtin/script/test/script_system_event_wait_test.cpp'
C='engine/domain/simulation/builtin/script/test/script_system_continuation_test.cpp'
L='engine/domain/simulation/builtin/script/test/script_system_lifecycle_test.cpp'
S='engine/domain/simulation/builtin/script/test/script_operation_storage_test.cpp'
F='engine/domain/simulation/builtin/script/test/script_ingress_frontier_test.cpp'
matrix=[
('T01',C,'testNoWaitResumableCall','8次step/provider；C/A=0、destroy=0；scope构造无cell acquire分支','contract-comparison','PASS','零cell分配依据实现与storage空初态断言，非单独bulk峰值计数'),
('T02',E,'testEventCompletesInsideInitialBackend / testCellRearmAtCapacityOne','value=103/32次值oracle；真实Lua观察144000晋升、额外execution=0','contract-comparison;resource-diagnostic','PASS','独立旧完整local池已删除，0为结构事实；不是未采集字段填零'),
('T03',E,'testBroadcastSemantics / testTargetedAndRetirement / testRegistrationCutoff','错误实体不访问waiter；目标/广播值与cutoff/退休后计数','final-d-LastTest.log','PASS',''),
('T04',E,'testCellContinuationAdmissionAfterSideEffects(true)','backend_starts=2，destroy=2，C全局晚拒绝，resume=0','contract-comparison','PASS',''),
('T05',E,'testCellContinuationAdmissionAfterSideEffects(false)','同实例C限制晚拒绝，另一实例配额不借用，资源零','contract-comparison','PASS',''),
('T06',E,'testCapacityFailure / testAwaitableCapacityFailure + supplemental both_full','Event和A同时满时WAITER_CAPACITY_EXCEEDED优先；单A满报AWAITABLE；最终资源零','additional-contracts;final-d-LastTest.log','PASS','同时满使用仓外增强fixture；序号极限不是本项逐ordinal注入'),
('T07',C,'testLocalTimerCapacityAndReuse','A满+-1 duration先报A；Timer满报CAPACITY；四形状32次取消再登记','contract-comparison','PASS',''),
('T08',E,'testEventCompletesInsideInitialBackend','初始用户代码中完成；inline_resume=0，queued=1，最终值103','contract-comparison','PASS',''),
('T09',E,'testResumeQueueFailure','Event拷贝完成但queue满，RESUME_QUEUE_FULL，实例fault，无resume','final-d-LastTest.log','PASS',''),
('T10',C,'testTimerDeadlineOrderAndBackpressure','原deadline/真实step；满queue保留来源，后续retry恰好两次resume','contract-comparison','PASS',''),
('T11',E+';'+S,'testCellRearmAtCapacityOne / testPromotionRearmAndStale','同cell32次重装填；旧wait epoch返回null；每次业务值准确','contract-comparison;final-d-LastTest.log','PASS','迟到内部ticket在storage层验证，真实runtime重装填业务另测'),
('T12',C,'testCellMixedTimerTransitions(false)','local→external→local；start=1,resume=3,boxed完成=1,destroy=1','contract-comparison','PASS',''),
('T13',C,'testCellMixedTimerTransitions(true)','external-first→local；C/A=1仍可take后重登记，业务/清理相同','contract-comparison','PASS',''),
('T14',E,'testUnboundLocalWithForeignExecution / testCompletedCallPreservesWait','COMPLETED留下终态wait，后来attach值97；未选中local仍保存值41/73','contract-comparison','PASS',''),
('T15',E,'testOldContextInsideNestedSameInstanceCall / testUnboundLocalWithForeignExecution','同实例两个准确context，source FIFO；承载cell与消费者分离，resume=3','contract-comparison','PASS',''),
('T16',E,'testSecondConsumerRejected','两次start，原attach错误，resume=0,destroy=2','contract-comparison','PASS',''),
('T17',E,'testCopyRetirementPin','4B copy回调退休；保护期间不析构，返回后重验，不继续resume','final-d-LastTest.log','PASS',''),
('T18',E,'testPinnedCancellationStillOccupiesCapacity','active=0、release_pending=1时A1仍拒绝；最后pin退出归零','contract-comparison','PASS',''),
('T19',E,'testCopyOtherRecordRemoval / testCopyNestedAdmission / testCopyShutdownAndFailure','copy重入删其它项/增长/嵌套/关闭/失败；原业务值、pin与最终清理断言','final-d-LastTest.log','PASS',''),
('T20',E+';'+C,'testCellRearmAtCapacityOne / testCellMixedTimerTransitions','A=1，take后用户代码立即新wait，旧packet值不被inline覆盖','contract-comparison','PASS',''),
('T21',E+';'+F,'testStaleLocalReadyConsumesBudget / ingress ring main','budget1先pop stale，第一步resume0、下一步resume1、value47','contract-comparison;final-d-LastTest.log','PASS',''),
('T22',S+';'+F+';'+L,'testPromotionRearmAndStale / testHeaderOwnerAndExhaustion / incarnation tests','旧A/C/owner/epoch拒绝；公开slot新generation不被旧completion命中','final-d-LastTest.log','PASS','内部目标生命周期与公开通知分别测'),
('T23',C+';'+L,'testSharedHookMethod / testProtectedReentry','destroy内合法重入；C/hook原时点释放；另一实例可调用；准确析构数','final-d-LastTest.log','PASS',''),
('T24',S+';'+E,'testPromotionRearmAndStale / testUnboundLocalWithForeignExecution / pin test','去C仍由A保活；承载execution先结束不毁wait；pin最后退出才还槽','contract-comparison;final-d-LastTest.log','PASS',''),
('T25',L+';'+C+';'+E,'testProtectedReentry / testTimerSourceCancellation / testShutdownWithPendingWaiter','Event、Timer、外部取消及七点生命周期清理原断言；结束零资源','final-d-LastTest.log','PASS_SPLIT','不同来源组合分散在既有fixtures；没有另造一个穷举全部来源排列的关闭场景'),
('T26',S+';'+C,'testExtraAndForeignConsumer / testExternalFirstAndQuota / testLocalTimerCapacityAndReuse','C+A bank边界，local/extra/external共享A，不能借空inline绕过A容量','final-d-LastTest.log;contract-comparison','PASS',''),
('T27',S,'testPublicGenerationAndPayloadFailure','64B/64对齐boxed spill、真实分配、take后旧值保留、erase归零','final-d-LastTest.log','PASS_STORAGE','大值/超对齐在实际共享storage层验证；未另增三后端各自64B Event资产'),
('T28',S+';'+E+';'+C+';'+L,'payload allocation failure / capacity / copy failure / lifecycle failure fixtures','命中aligned nothrow分配失败1次；A/cell均回滚，之后64B成功；backend/prepare/BeginPlay失败清理','final-d-LastTest.log','PASS','未穷举每个heap malloc序号；bank冷期OOM沿原prepare containment'),
('T29',C,'createInstance local catalog provenance + supplemental SameNameDelay','错context/dispatch不能resolve local；同名发布双方AMBIGUOUS_PROVIDER，provider/backend=0；普通自定义异步仍真completion','additional-contracts;contract-comparison','BASELINE_CONTRACT_ADAPTED','当前runtime不支持覆盖已发布builtin Delay，不添加该产品能力以满足假设'),
('T30','engine/domain/simulation/scripting/*/test;engine/toolchain/flowforge/test','existing real backend/FlowForge integration + seven workloads + SDK','真实Lua55、CppStatic、Native/FlowForge provider/Event/Timer/resume及独立业务oracle','final-d-LastTest.log;final-t-LastTest.log;installed;final-costs','PASS','非只测fake backend'),
('T31','engine/domain/simulation/scripting/lua/test/lua_vm_coroutine_contract_test.cpp','Lua VM identity/close/continuation contracts','保持coroutine.running、旧thread/table、关闭/OOM契约；VM4/4；144000 fresh threads/resumes/released','final-vm-tests.log;final-d-LastTest.log;resource-diagnostic','PASS','没有thread/table池；Lua55 leaf诊断关闭字段为null'),
('T32',F+';'+C,'frontier test / testAsyncAbilityInvocation / stale local budget','保留publication未完成空洞，不跨frontier，重复/背压/每pop处理，唯一ready ring','final-d-LastTest.log;contract-comparison','PASS','无新stable point；未做所有生产线程交错的模型检查'),
('T33',S,'testPromotionRearmAndStale / testHeaderOwnerAndExhaustion','C++ body切换后旧票据失败，header先验owner/epoch；storage删除copy/move','final-d-LastTest.log','PASS','System稳定State转移合同由既有move fixture覆盖'),
('T34',S,'testPublicGenerationAndPayloadFailure / testHeaderOwnerAndExhaustion','public test上限4退休不wrap；private epoch手动置UINT64_MAX后拒绝/跳过耗尽cell','final-d-LastTest.log','PASS','未执行2^32/2^64次真实循环；测试小上限只在测试实例类型'),
('T35','cmake/install-consumers','15 consumers / 13 incremental / 2 relocated chains','公开头匹配qualified clone；真实生成provider闭环；两条链旧source/build/SDK不可用仍成功','installed/consumers.json;value-incremental/probes.json;relocated/results.json;final-audit.json','PASS','Windows x64 RelWithDebInfo，未验证其它平台'),
('T36','engine/domain/simulation/builtin/script/benchmark/script_runtime_benchmark.cpp','existing seven whole workloads, observer-only counters','42正式进程有效；逐帧业务同量；负成本全部保留；A缺字段和关闭观察为null','final-costs;resource-diagnostic;candidate-profile','PASS','三对有限样本，不声称显著性或性能等价')]
with (dest/'TEST_MATRIX.csv').open('w',encoding='utf-8-sig',newline='') as f:
 writer=csv.writer(f);writer.writerow(['id','source','entry','actual_assertion','raw_evidence','status','scope_limit']);writer.writerows(matrix)
qual={slot:read(r/f'final-{slot}-tests.json') for slot in ['d','t']}
invalid=[
 {'path':'a1-core-build.log','reason':'初版style门禁与三处standalone callback签名未迁移；已修'},
 {'path':'a3-mixed-build.log','reason':'测试startTyped需要double lvalue，初版传rvalue；已修'},
 {'path':'a4-contracts-tests.log','reason':'测试在自身Event buffer派发中再次record；改用独立真实endpoint，不改生产顺序'},
 {'path':'attempt1-final-d-build.log','reason':'新测试PreparedResumeType构造参数数量不符；caf34修正'},
 {'path':'contract-attempt1','reason':'驱动混合Developer与Toolchain同名DLL身份，校验拒绝，未用于测试'},
 {'path':'contract-attempt2','reason':'驱动未匹配实际vs_link_exe命令，未运行对照'},
 {'path':'observer-attempt1-observer-configure.log','reason':'驱动未指定-S，CMake源目录身份不符而拒绝，未配置或构建main；补准确-S后成功'},
 {'path':'additional-attempt1','reason':'驱动只匹配/c，实际为-c，跑到未增强fixture；A1_EXTRA命中数门禁拒绝该证据，修后重编两侧'},
 {'path':'audit-attempt1.log','reason':'development工作树ScriptRuntime.hpp换行与clean clone不同；两SDK与资格clone原始hash相同，文本与development一致'}]
result=dict(schema_version=1,implementation_status='IMPLEMENTATION_COMPLETE',contract_status='CONTRACT_PASS',cost_status='REGRESSION',
 recommendation='Do not adopt this candidate as a v4 replacement; retain experiment for architecture review.',
 branch='codex/s6-execution-cell-a1',branch_start='f92853ea8361a7dc90ce0da072497d3722c29f88',
 baseline_source='f7d2815bdd2025ee23a7c11449def822413f58e9',qualified_source='caf34bd307912450d894da922b59af4238154508',
 source_identity_rule='Report/evidence commits are not new measured source identities.',
 identities={name:read(r/name/'identity.json') for name in ['final-image','final-flow-image','observation-image']},
 fixed_dependencies=dict(lux_cxx='3100f54d0743c5ed94a4ccf5943df04e933de255',toolset='99c3d0480d1db816779b1dfa7f3c06cb7d39a94f',
  lua='5.5.1 + lux-lua55-v3-r2',lua_sha256='34f11df8679a46b2d956462a99a9a3ba49ee29e88b85bb27b1c2b3c5a78bb29e',native_abi=6,
  gc='INC upstream defaults',empty_page_budget_bytes=16777216,verified_installed_files=204),
 contracts=dict(matrix='TEST_MATRIX.csv',ab_trace=read(r/'contract-comparison/result.json'),additional=read(r/'additional-contracts/result.json')),
 performance=dict(valid_processes=42,invalid_timed_processes=0,order='AB/BA/AB',summary=summary,runs=runs,
  scheduler_resume_latency_ns=None,latency_scope='Per-batch p50/p95/p99/max are measured; scheduler delivery timing is verified by step assertions, no separate wall-clock resume-latency histogram.',
  raw_csv_scope='Original CSV fields are preserved, including zero-initialized observation columns. A zero in claim_lookups/actual_copy_bytes is not reinterpreted as a measured zero when that group does not populate it; business equality also requires independent provider/value oracles.',
  unsupported_claims=['performance equivalence','PMU/cache miss attribution','pure backend resume cost']),
 resources=dict(layout=layouts,observations=resources,cell_counts=counts,independent_local_full_record_body_creations=0,
  independent_local_full_record_evidence='Removed complete local Awaitable pool; all local bodies are optional members of the same execution union arm; not a counter fabricated for A.',
  unchanged_backend_backing_reference='../script-v4/RESULT.zh-CN.md',
  unmeasured={'bulk_cell_high_water':None,'distinct_physical_cells_touched':None,'whole_process_all_allocator_peak':None,'leaf_calls':None}),
 profile=read(r/'candidate-profile/identity.json'),qualification=dict(Developer={'passed':127,'total':127,**qual['d']},
  Toolchain={'passed':111,'total':111,**qual['t']},VM={'passed':4,'total':4},consumers=read(r/'installed/consumers.json'),
  incremental=read(r/'value-incremental/probes.json'),relocated=read(r/'relocated/results.json'),audit=read(r/'final-audit.json')),
 invalid_attempts=invalid,limitations=[
  'Negative CPU result, larger reserved storage; no product adoption approval requested or inferred.',
  'T25 split lifecycle/source fixtures; T27 storage-layer large result; T29 baseline duplicate-publication policy preserved. See matrix scope limits.',
  'No Windows ARM64/Linux/Android/other compiler/production assets qualification; Lua54/LuaJIT not built or measured.',
  '32/64-bit exhaustion tested with reduced test limit/manual terminal header, not billions of operations.',
  'Whole-process sample only B; no PMU. More memory accesses are a source/layout-supported hypothesis, not a measured cache-miss explanation.',
  'A C++ Sequence cumulative error counter unavailable; asserts still passed. Disabled diagnostics are not zero.',
  'Retained bank/directories, VM slack and backend frame reserved values are different quantities; no claim that all process memory was exhaustively attributed.',
  'v4 scalar and Native metadata debts unchanged and still registered in v4 report.'])
(dest/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
costrows='\n'.join(rows)
totalrows=[]
for row in summary:
 totalrows.append('| '+names[row['scene']]+' | '+' / '.join(f'{t:.6f}' for t in row['whole_batch_seconds']['A'])+' | '+' / '.join(f'{t:.6f}' for t in row['whole_batch_seconds']['B'])+' |')
memoryrows=[]
for scene in ['event','cpp-sequence']:
 pair=[next(x for x in resources if x['scene']==scene and x['side']==s) for s in ['A','B']]
 memoryrows.append('| '+names[scene]+' | '+' → '.join(f"{x['peak_working_set']/1048576:.3f}" for x in pair)+' | '+' → '.join(f"{x['peak_private_commit']/1048576:.3f}" for x in pair)+' |')
text=f'''# V5 / A1 ExecutionCell 实施结果

**IMPLEMENTATION_COMPLETE / CONTRACT_PASS / REGRESSION。** A0–A6 已实际完成；本候选不值得作为当前 v4 的替代，保留在实验分支供架构审阅。结构确实改变、已测语义保持，但主目标没有取得整体收益，预留内存明显增加。这是否定本候选，不是否定所有可能的 cell 设计。

## 1. 身份与冻结边界

- 实验分支 `codex/s6-execution-cell-a1`，从 `f92853ea8361a7dc90ce0da072497d3722c29f88` 创建；不合并原分支/main。
- 固定 A：`f7d2815bdd2025ee23a7c11449def822413f58e9` 的 v4 匹配镜像。起始44项与最终镜像 hash 复核，旧产物未修改。
- B 的实际完整资格/计时源码：`caf34bd307912450d894da922b59af4238154508`，独立 clean clone，唯一最终标准产物。本文和归档提交不是新测量身份。
- Windows x64、MSVC19.44.35228.0、RelWithDebInfo `/O2 /Ob1 /MD`，单 owner，affinity mask16。Lua5.5.1 + lux-lua55-v3-r2、INC原值、16MiB完整空页预算；Native ABI6。
- lux-cxx `3100f54d0743c5ed94a4ccf5943df04e933de255`、toolset `99c3d0480d1db816779b1dfa7f3c06cb7d39a94f`：204个实际安装文件再核验。VM DLL hash `34f11df8679a46b2d956462a99a9a3ba49ee29e88b85bb27b1c2b3c5a78bb29e` 两侧一致。
- VM patch、allocator、GC、codec、NativeFrameStorage、BoundedClassStorage、编译器/ISA/IPO及三份cooked基准资产均未改变。

完整字段、命令、产物 hash、配对分布见 [result.json](result.json)，源码/合同见 [NOTES](NOTES.zh-CN.md)，逐项证据见 [TEST_MATRIX.csv](TEST_MATRIX.csv)。唯一新原始包见 [证据索引](../evidence/script/script-cell-a1/INDEX.zh-CN.md)。原 main 的7项修改全部与既有登记同 hash，原开发工作树未操作。

## 2. 实际删掉与保留的工作

普通本地 Event/Timer 不再构造独立完整 AwaitableRecord；首次挂起在 provisional cell 中晋升 execution role，连续本地等待重新填同一 local slot。原独立 C/A 完整存储被一个稳定 C+A bank 和两个薄身份目录替换；只有一个 ready FIFO，没有双引擎选择器。

但没有消除所有管理操作：每次 A 仍需逻辑接纳与generation，C仍在backend返回后接纳；owner链、来源取消关系、selected wait关联、pin、权限及代次检查保留。来源直达 cell 后，公开句柄、外部完成和清理仍可能查目录。`attached_execution` 不等于 hosting cell，保留未绑定/额外/foreign token 的合法语义。

普通链为：`waitEvent → scopeFor → A目录 → provisional local cell → 来源登记 → backend返回 → C目录/原位晋升 → attachWaiter → claim/callback/copy → ready → take到栈上/归还A → backend.resume → unlink/hook解锁/C归还 → backend.destroy`。每次用户代码返回均按原权限重验，Timer queue-full 重试与 Event queue-full fault 不合并。

跨后端唯一必要C++接口变化是 EventWaitFactory 取得准确 `ScriptStepContext` 借用；CppStatic/Lua直接构造fixture已迁移，Native/FlowForge仍透传同一step。公开C++头与DLL必须配套重编译；Native ABI6、token字节与资产格式不变。统计口径变化（A目录 vs 全部bank）明确列在NOTES。

## 3. 独立结构观察

诊断使用同一源码的 HOTPATH_OBSERVATION=ON 构建；正式42次全部OFF。下表是1000实例、16预热+128帧的实测累计值，含预热；A没有新计数，保持null。常规Event的每次完整周期包含开始、等待、完成、恢复、销毁。

| 计数 | Lua Event B | C++ Sequence B |
|---|---:|---:|
| start / resume / complete | 144000 / 144000 / 144000 | 36000 / 108000 / 36000 |
| cell acquire / release | 144000 / 144000 | 36000 / 36000 |
| 原位晋升 / 额外execution创建 | 144000 / 0 | 36000 / 0 |
| local waits / 后续rearm | 144000 / 0 | 108000 / 72000 |
| boxed（external/无scope/布局/已占local） | 0 / 0 / 0 / 0 | 0 / 0 / 0 / 0 |
| A接纳 / 实际归还 | 144000 / 144000 | 108000 / 108000 |
| C接纳 / 实际归还 | 144000 / 144000 | 36000 / 36000 |
| 来源直达 / 来源目录解析 | 144000 / 0 | 108000 / 0 |

local独立完整结果池为零是源码布局事实；新统计并未给A编造零。Sequence是原NextStep/Event/simulation delay混合业务；local↔external过渡、extra/未绑定/foreign-target由独立真实runtime负例验证，不把普通诊断的boxed=0推广到所有调用。

Lua两侧都新建/恢复/解除root 144000个thread；384B档和736B档各144000次周期请求仍在。两侧总VM alloc=297477、realloc=88，fresh thread/stack没有少做。关闭ScriptSystem仅解除脚本资源，Lua VM仍可保留等待GC的对象，最终VM销毁合同由VM/后端测试验证。

## 4. 语义与真实消费者

同一新runtime测试分别用A历史头+固定DLL、B候选DLL执行，31条精确业务轨迹相同。覆盖C晚接纳的副作用/析构、A1 pin物理占槽、初始eager完成、重复消费者、旧context嵌套、stale pop预算、32次A1重装填、foreign target、COMPLETED留下wait，以及两方向local/external过渡。

补充同时耗尽Event/A，双方都优先返回WAITER_CAPACITY_EXCEEDED；同名Delay publication双方均AMBIGUOUS_PROVIDER、provider/backend=0。不能把当前不支持的builtin覆盖当成可执行旧合同。原catalog错context/dispatch测试和通用自定义异步provider测试保留。

七点重入、同步退休错误、Bindings回滚、实例复用、copy增长/退休、Event/Timer queue-full差异、真实step/frontier/预算、Scene及三后端旧断言继续通过。64B/64对齐payload在真实storage层验证分配失败1次、恢复成功、take值与回收；未额外为三后端各建64B Event资产。T25来源/清理排列按既有多个fixture分开覆盖，未声称穷举全部组合。public测试代次上限4、private手动终值覆盖拒绝wrap，不是运行数十亿轮。

## 5. 资源总账

实际MSVC布局：A完整C=72B、A结果=192B；B execution=88B、wait共用状态144B、local176B、boxed232B；union/header组合后的cell **320B**。boxed已包含在bank最大宽度内，不能再加一遍，也不能省略这份reserved。大payload spill另计。来源Event 88→112B、Timer104→128B、临时claimed snapshot28→56B；ready24→64B。

以C=A=ready=Event=Timer=external queue=10000、10000实例/方法、1个Event endpoint测量实际reserve，单位B。`dynamic`是向下层operator new提出的真实在用请求，包括STL对齐及array cookie，不是OS/RSS；容器owner对象单列避免重复计算。

| 所有动态backing | A | B |
|---|---:|---:|
| C完整池 | 840117 | 包含在bank/目录行 |
| A完整稳定池（10240物理槽） | 2335695 | 包含在bank/目录行 |
| cell bank + C/A薄目录 | 0 | 7120086 |
| ready ring | 240039 | 640039 |
| execution实例/方法索引 | 800078 | 800078 |
| Event来源、路由、claim、实例索引 | 1771361 | 2011361 |
| Timer来源、external capability槽、heap、实例索引 | 2400312 | 2640312 |
| shared transport、completion ring、tickets | 1045856 | 1040096 |
| 四owner对象（含嵌入容器，不重复计transport） | 1096 | 1224 |
| **上述合计** | **9434554** | **14253196** |

增 **4818642B（约4.60MiB，+51.07%）**，这是四组件及其全部owned backing，不是整个引擎内存增幅。B逻辑bank=6400000B、C目录320000B、A目录400000B；实际allocation多出的字节记录在上表。free/owner/epoch均在cell/目录内，没有另藏一份旧pool。A ticket按10240物理A准备，B按10000，transport少5760B，未改变公开逻辑配额。

初始prepare触及全部cell header，不能把未使用角色称为未预留。结束快照active cell=0；bulk cell峰值与不同地址touch数没有独立采集，result.json为null。单cell稳定复用和pin物理保活由断言验证，不能据结束为0推断峰值为0。

Instances/Bindings/Preparer、C++ frame arena/root、Native N×R与metadata、Lua VM仍按v4容量独立保留，并没有由cell取代。[v4资源账](../script-v4/RESULT.zh-CN.md)中的C++ 10000容量arena5440000B+metadata240280B、原FlowForge Event payload160000B及metadata1200272B继续适用（源码/配置未改）；这些不是本轮新测得的不同后端统一成本。LuaVM由本轮资源诊断另计，不能将跨时间峰值相加。

| 1000实例独立资源观察 | 峰值working set MiB A→B | 峰值private commit MiB A→B |
|---|---:|---:|
{chr(10).join(memoryrows)}

每进程仅6–7次5ms查询，记录Windows返回的进程累计峰值；有限小场景不能代表10000实例峰值。Lua末快照两侧active/idle页与待GC对象不同，A/B下层heap请求91/88、页供给88/85；总thread/stack请求相同。GC受地址与回收进度影响，不能把这点当成cell节省VM内存的证据；heap请求不是OS syscall，16MiB仍只约束完整空页。完整class/slack/retained记录保留。

## 6. 完整业务成本

每腿三对独立进程AB/BA/AB，所有42次有效，不筛除慢组、不另追3%门槛。以下A/B列分别是各侧成本中位，变化是各对B/A−1后取中位，不能直接将前列相除代替。Event/NextStep/scalar ROI20M调用；FlowForge Event ROI10M；record ROI1M；Sequence1000整帧（2.5M start、7.5M resume）；Physics2000整帧。原warmup/seed/budget/worker保持，Sequence恰逢完整序列边界，无额外drain帧。

| 腿 | 单位 | A → B | 三对变化 | 配对中位 |
|---|---|---:|---|---:|
{costrows}

| 腿 | A三次完整ROI总秒数 | B三次完整ROI总秒数 |
|---|---|---|
{chr(10).join(totalrows)}

完整总量、每帧CSV、p50/p95/p99/max及错误范围在result.json/原始包。各组最终ready backlog为0；Sequence/Physics帧内存在原有in-flight等待，并非全部调用同步完成。可观测累计errors=0；A的Sequence只有旧业务/资源/shutdown断言，没有累计failure输出，因此该字段为null。正式VM/EXE-local可选分配计数关闭时为未采集；Physics原EXE-local计数为0不代表全部DLL零分配。没有独立wall-clock恢复延迟直方图；恢复时机由真实step协议测试证明。

**没有主目标收益。** Event方向混合，NextStep、FlowForge、Sequence与Physics三对都更慢。scalar两慢一快、record小幅混合，不声称等价。v4 scalar/Native metadata旧债务继续登记，本轮增量单独归为当前候选成本，不用旧债务豁免。

## 7. 采样、机器码与资格

对B只补一次软件Hotspots，完整子进程CPU19.638259s、elapsed21.856173s，包含setup/warmup/oracle/shutdown；业务30M Event与checksum930010000通过。自耗：Awaitables::admit0.580928s（2.96%）、Continuations::tryEmplace0.314880s（1.60%）、waitEvent0.265301s、attachWaiter0.186419s、resumeOne0.140878s；luaV_execute0.707738s、traversestrongtable0.616084s、luaH_Hgetshortstr0.532432s。新接纳/晋升仍是可见成本，并非把所有损耗都放到resume。

实际DLL反汇编保留；admit入口VA0x18008c970仍建立0x78字节局部栈区、检查/计算薄目录容量，随后处理稳定header/角色与失败分支。减少旧目录解析没有让整个入口成为一次直接store。更宽cell/来源/ready、额外定位和管理是由源码/布局支持的候选解释；**单侧软件样本不能证明全部新增回退的微架构归因**。没有PMU/cache-miss结论，不据此追加无界inline搜索或VM改动。

最终独立clean clone：Developer **127/127**、Toolchain **111/111**，两个all `-j4 -- -k0`成功、第二轮无工作；冻结VM合同 **4/4**；真实安装消费者 **15/15**；增量 **13项**（含预期生成拒绝，按expected_success验收）；两条迁址链 **2/2**。迁址时原source、两个build、原SDK/tools/VM前缀均暂时不可用，恢复后身份再核验。public头与qualification clone原始hash相同；无private cell/owner头泄露。所有后端、真实provider字段值、错误恢复/生命周期和关闭清理旧断言保留。

初期失败和驱动无效记录原样保留，见result.json.invalid_attempts：回调签名/测试构造/错误重入endpoint已修正；观察驱动遗漏-S被CMake拒绝；补充trace驱动未匹配-c被命中门禁拒绝；header审计曾误将开发工作树换行差异当身份差异，最终按clean clone原始hash核验。正式42次没有无效重测或挑选快组。观察构建已恢复OFF，未覆盖正式安装。

## 8. 结论与停点

本轮验证了“本地等待由执行cell承载”可以实现，并保持已测的复杂等待、失败及重入合同；没有证据表明此实现优于v4。它减少了普通路径的独立完整记录，但更多预留、宽目标和管理操作没有换来CPU改善，建议**不采用当前候选**。

该结论不表示所有cell布局已经穷尽，也不把旧架构视为性能极限。只在实验分支提交/推送，等待A1架构审阅；不继续VM/source-link合并、allocator/codec/frame或其它阶段。未验证Windows ARM64/Linux/Android、其它编译器或真实游戏资产；不恢复Lua54/JIT，不发布tag，不合并main。
'''
(dest/'RESULT.zh-CN.md').write_text(text,encoding='utf-8')
print('REPORT_WRITTEN',len(matrix),'contracts',len(runs),'runs',len(read(r/'value-incremental/probes.json')),'incremental')
