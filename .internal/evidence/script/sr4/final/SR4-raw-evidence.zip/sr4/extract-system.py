from pathlib import Path
import re
base=Path('E:/SyncForder/CodeRepos');repo=base/'lux-engine-deep-optimization'
s=(base/'build/RelWithDebInfo/sr4/E0-ScriptSystem.cpp').read_text()
def method(name):
    m=re.search(r'^        (?! ).*\b'+name+r'\(',s,re.M);assert m,name
    a=m.start();previous=s.rfind('\n',0,a-1)+1
    if s[previous:a].lstrip().startswith('[[nodiscard]]'):a=previous
    start=s.index('{',m.end());depth=1;i=start+1
    while depth:depth+=(s[i]=='{')-(s[i]=='}');i+=1
    return s[a:i]+'\n'
def change(text,old,new,count=1):
    assert text.count(old)==count,(old,text.count(old));return text.replace(old,new)
queue=s[s.index('        struct SparseMountQueue final'):s.index('        const SimulationDescription* simulation')]
affinity=s[s.index('        [[nodiscard]] bool enterExecutionOwner()'):s.index('        [[nodiscard]] ExecutionInstance* executionRecord')]
fields='''        using Handler = detail::ScriptMethodReference;
        using RetirementRecord = detail::ScriptInstances::Retirement;
        const SimulationDescription* simulation{};
        ecs::Registry* registry{};
        const SimulationClock* clock{};
        ScriptRuntimeLimits limits;
        detail::ScriptPreparer preparer;
        detail::ScriptInstances instance_owner;
        detail::ScriptBindings binding_owner;
        detail::ScriptEventWaits event_owner;
        detail::ScriptTimers timer_owner;
        detail::ScriptCompletionIngress ingress;
        detail::ScriptExecution execution_owner{instance_owner, binding_owner, event_owner, timer_owner, ingress};
        std::vector<ScriptSystemFailure> failures;
        std::vector<std::uint32_t> retirement_queue;
        SparseMountQueue dirty_current;
        SparseMountQueue dirty_processing;
        std::vector<std::uint32_t> lifecycle_candidates;
        std::vector<std::uint32_t> lifecycle_initialized;
        std::vector<RetirementRecord> lifecycle_retirements;
        std::uint64_t last_stable_step{};
        std::uint64_t event_occurrences{};
        std::size_t endpoint_dispatch_depth{};
        entt::connection constructed;
        entt::connection updated;
        entt::connection destroyed;
        bool stopping{};
        EPrepareState prepare_state{EPrepareState::CREATED};
#if defined(LUX_SCRIPT_OWNER_AFFINITY_PROBE)
        std::thread::id execution_owner_thread;
        std::size_t execution_depth{};
#endif
'''
affinity=re.sub(r'\bexecution_owner\b','execution_owner_thread',affinity)
body=''.join(method(n) for n in ['buildLayout','acceptMounts','recordFailure','queueRetirement','faultInvocation'])
body=body.replace('invalidateAdmission(instance_owner.fault(slot))','execution_owner.invalidateAdmission(instance_owner.fault(slot))')
body+='''        struct FailurePort final { State* owner{}; } failure_port{this};
        static void faultErased(void* context, std::uint32_t slot, lux::script::ScriptSymbolId symbol,
            EScriptSystemError error, std::int32_t status) noexcept
        {
            static_cast<FailurePort*>(context)->owner->faultInvocation(slot, symbol, error, status);
        }
        struct BindingPort final { State* owner{}; } binding_port{this};
'''+method('invokeHookLane')
body=body.replace('owner.invoke(handler, frame, true)','owner.execution_owner.invoke(handler, frame, true)')
body+='''        static void dispatchEvent(void* context, std::uint32_t bucket, ecs::Entity entity,
            lux_script_call_frame& frame) noexcept
        {
            auto& owner = *static_cast<BindingPort*>(context)->owner;
            ExecutionOwnerScope execution{owner};
            if (!execution)
                return;
            ++owner.event_occurrences;
            ++owner.endpoint_dispatch_depth;
            {
                const auto& endpoint = owner.binding_owner.eventEndpoint(bucket);
                const auto target = endpoint.route == EEventRoute::SIMULATION_BROADCAST ? ecs::NullEntity : entity;
                auto claimed = owner.event_owner.claim(bucket, target);
                owner.binding_owner.visitEvent(bucket, entity,
                    [&](const Handler& handler) noexcept { owner.execution_owner.invoke(handler, frame, false); });
                for (std::size_t index{}; index < claimed.size(); ++index)
                    if (const auto waiter = claimed.at(index))
                        owner.execution_owner.completeClaimedEventWaiter(*waiter, frame);
            }
            --owner.endpoint_dispatch_depth;
        }
'''
body+=''.join(method(n) for n in ['ownsAttachment','beginPlayMount','beginRetirement','finishRetirement',
    'releaseMount','initializeMount','publishMount','activateMount','queueDirty','handleAttachmentSignal',
    'onAttachmentConstructed','onAttachmentUpdated','onAttachmentDestroyed','connectEndpoints','disconnectEndpoints',
    'releaseSignals','rollbackPrepare'])
body=body.replace('invalidateInstance(slot);','execution_owner.invalidateInstance(instance_owner.view(slot).retiring_instance);')
body=body.replace('invalidateAdmission(mount.retiring_instance);','execution_owner.invalidateAdmission(mount.retiring_instance);')
body=change(body,'                execution_instances[mount.instance.slot - 1U] = {mount.instance, slot};','''            {
                execution_owner.beginInstance(mount.instance, slot);
                event_owner.beginInstance(mount.instance);
                timer_owner.beginInstance(mount.instance);
            }''')
body+='''        [[nodiscard]] lux::cxx::expected<void, EScriptSystemError> drainResumes() noexcept
        {
            std::optional<EScriptSystemError> first_error;
            auto batch = execution_owner.resumeBatch();
            while (const auto resumed = batch.next())
            {
                if (!*resumed && !first_error)
                    first_error = resumed->error();
                // Do not recapture: completion admission after EVERY pop uses the same bounded frontier.
                if (!execution_owner.drainExternalCompletions() && !first_error)
                    first_error = EScriptSystemError::INVOCATION_FAILURE;
            }
            return first_error ? lux::cxx::expected<void, EScriptSystemError>{lux::cxx::unexpected(*first_error)} :
                lux::cxx::expected<void, EScriptSystemError>{};
        }
'''
tail=s[s.index('    lux::cxx::expected<ScriptRuntimeCapacityPlan'):]
tail=change(tail,'''            state->delay_provider.owner = state.get();
            state->next_step_waits.reserve(limits.next_step_wait_capacity);
            state->simulation_delays.reserve(limits.simulation_delay_capacity);
''','')
tail=tail.replace('bindScriptAbility<DelayAbility>(state->delay_provider)','bindScriptAbility<DelayAbility>(state->timer_owner)')
tail=change(tail,'            state->real_delay = real_delay;','''            state->execution_owner.prepare(limits, state->instance_owner.identityCapacity(), capacity.method_capacity,
                {&state->failure_port, &State::faultErased});
            state->event_owner.prepare(limits.event_wait_capacity, state->instance_owner.identityCapacity());
            state->timer_owner.prepare(clock, limits, real_delay, state->execution_owner,
                state->instance_owner.identityCapacity());
            state->ingress.prepare(limits.external_completion_capacity, state->execution_owner.physicalAwaitableCapacity());''')
a=tail.index('            state->execution_instances.resize');b=tail.index('            const auto layout = state->buildLayout();',a)
tail=tail[:a]+tail[b:]
tail=change(tail,'        state_->prepare_state = EPrepareState::PREPARED;','        state_->prepare_state = EPrepareState::PREPARED;\n        state_->execution_owner.enablePrepared();')
tail=tail.replace('state_->result_write_pins','state_->execution_owner.resultPins()')
tail=tail.replace('state_->active_claimed_waiters','state_->event_owner.claimedCount()')
tail=change(tail,'''        if (!state_->external_admission_prepared)
            beginStableAdmission();
        state_->external_admission_prepared = false;''','        state_->ingress.beginDrain();')
tail=tail.replace('state_->promoteNextStepWaits()','state_->timer_owner.promoteNextStep()')
tail=tail.replace('state_->promoteSimulationDelays()','state_->timer_owner.promoteSimulationDelay()')
tail=tail.replace('state_->drainExternalCompletions()','state_->execution_owner.drainExternalCompletions()')
a=tail.index('        state_->external_admission_frontier =');b=tail.index('    }',a)
tail=tail[:a]+'        state_->ingress.capture();\n'+tail[b:]
tail=change(tail,'        state_->ingress->completions.stop();','''        state_->execution_owner.stop();
        state_->timer_owner.stop();
        state_->ingress.stop();''')
a=tail.index('        state_->next_step_waits.clear();');b=tail.index('        const auto disconnected',a)
tail=tail[:a]+tail[b:]
a=tail.index('        state_->continuations.clear();');b=tail.index('        state_->instance_owner.finishShutdown();',a)
tail=tail[:a]+'''        state_->execution_owner.shutdown();
        state_->event_owner.shutdown();
        state_->timer_owner.shutdown();
        state_->preparer.releaseCatalog();
'''+tail[b:]
tail=tail.replace('state_->continuations.size()','state_->execution_owner.activeContinuations()')
tail=change(tail,'''        if (!state_ || !state_->ingress)
            return 0U;
        return state_->awaitables.size() - state_->pending_awaitable_releases;''','        return state_ ? state_->execution_owner.activeAwaitables() : 0U;')
a=tail.index('        result.sync_invocations =');b=tail.index('        return result;',a)
tail=tail[:a]+'''        result.event_occurrences = state_->event_occurrences;
        state_->execution_owner.writeStats(result);
        state_->event_owner.writeStats(result);
        state_->timer_owner.writeStats(result);
        state_->ingress.writeStats(result);
'''+tail[b:]
tail=change(tail,'''        if (invalid_limits || artifacts.resolve == nullptr)''','''        const auto timer_slot_limit = std::numeric_limits<std::uint32_t>::max();
        const bool invalid_timer_capacity = limits.simulation_delay_capacity >= timer_slot_limit ||
            limits.next_step_wait_capacity >= timer_slot_limit - limits.simulation_delay_capacity;
        if (invalid_limits || invalid_timer_capacity || artifacts.resolve == nullptr)''')
top='''#include <lux/engine/simulation/ScriptSystem.hpp>
#include <lux/engine/simulation/script/ScriptExecution.hpp>
#include <lux/engine/simulation/script/ScriptPreparer.hpp>
#include <lux/engine/simulation/abilities/DelayAbility.hpp>
#include "DelayAbility.ability.generated.hpp"
#include <entt/signal/sigh.hpp>
#include <algorithm>
#include <limits>
#include <optional>
#include <utility>
#include <vector>
#if defined(LUX_SCRIPT_OWNER_AFFINITY_PROBE)
#include <thread>
#endif

namespace lux::simulation::script
{
    namespace
    {
        enum class EPrepareState : std::uint8_t
        {
            CREATED, PREPARING, ROLLBACK_PENDING, PREPARED, SHUT_DOWN,
        };
    }

    struct ScriptSystem::State final
    {
'''
(repo/'engine/domain/simulation/builtin/script/src/ScriptSystem.cpp').write_text(top+queue+fields+affinity+body+'    };\n\n'+tail)
