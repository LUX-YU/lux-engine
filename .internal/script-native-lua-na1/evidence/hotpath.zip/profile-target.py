import json,subprocess,sys
from pathlib import Path
r=Path(sys.argv[1]);cmd=json.loads((r/'target-command.json').read_text())
with (r/'target.log').open('wb') as f:code=subprocess.call(cmd,stdout=f,stderr=subprocess.STDOUT)
(r/'target-exit.json').write_text(json.dumps({'exit':code}))
raise SystemExit(code)
