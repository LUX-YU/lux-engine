from pathlib import Path
import hashlib,struct,shutil,json,subprocess,os
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-v4');image=r/'v3-flow-image';image.mkdir(exist_ok=False)
s=(r/'save-w1.py').read_text();exec(s[s.index('def sha('):s.index('queue=')])
original=r.parent/'o/w/t/bin/flowforge_script_runtime_benchmark.exe'
assert b'e06208deb29b9b1de52fe49a129091f693bb7e08' in original.read_bytes(), 'FlowForge benchmark embedded source differs'
queue=[original.name];saved={};external=[]
roots=[r.parent/'lua55-v3/final-image',Path('E:/SyncForder/CodeRepos/install/o/v3/tools/bin'),Path('E:/SyncForder/CodeRepos/install/o/v3/sdk/bin'),Path('D:/Development/vcpkg/installed/x64-windows/bin')]
while queue:
 name=queue.pop()
 if name.lower() in saved:continue
 p=original if name==original.name else next((root/name for root in roots if (root/name).exists()),None)
 if not p:external.append(name);continue
 shutil.copy2(p,image/name);saved[name.lower()]={'origin':str(p),'sha256':sha(p)}
 if p.with_suffix('.pdb').exists():shutil.copy2(p.with_suffix('.pdb'),image/p.with_suffix('.pdb').name)
 queue+=imports(p)
(image/'identity.json').write_text(json.dumps(dict(source='e06208deb29b9b1de52fe49a129091f693bb7e08',basis='Preserved all-build benchmark embeds the qualification source; DLLs come only from untouched v3 image/SDK and fixed vcpkg, not current build DLLs',images=saved,system_imports=external),indent=2))
print('preserved v3 FlowForge',len(saved),'images')
