import json,re,statistics
from pathlib import Path
r=Path('../../s5c').resolve(); root=r/'record-final'
def read(p):
 t=p.read_text();return {k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',t)}
rows={v:[read(root/f'{v}-{i}.log') for i in range(5)] for v in ['H','protected','C0','C1']}
for v,data in rows.items():
 for x in data:assert x['count']==1000000 and x['errors']==x['backlog']==0 and x['diagnostics']==0
 print(v,'median total ms',statistics.median(x['ns'] for x in data)/1e6,'median ns/op',statistics.median(x['ns']/x['count'] for x in data))
comparisons={}
for a,b in [('C0','C1'),('H','C1'),('H','protected'),('protected','C1')]:
 ps=[{'pair':i,'delta_ns_per_op':(y['ns']-x['ns'])/x['count'],'percent':100*(y['ns']/x['ns']-1)} for i,(x,y) in enumerate(zip(rows[a],rows[b]))]
 comparisons[a+'->'+b]={'pairs':ps,'median_delta_ns_per_op':statistics.median(x['delta_ns_per_op'] for x in ps),'median_percent':statistics.median(x['percent'] for x in ps)}
 print(a,b,comparisons[a+'->'+b])
for v,n in [('H',0),('protected',10000),('C0',30000),('C1',30000)]:
 x=read(root/f'{v}-diagnostics.log');assert x['count']==10000 and x['c_calls']==n and x['diagnostics']==1
for mode,n in [('protected-diagnostics',10000),('diagnostics',30000)]:
 x=read(root/'lua54'/f'{mode}.log');assert x['count']==10000 and x['c_calls']==n
for p in [root/'protected-errors.log',root/'lua54/protected-errors.log']:
 t=p.read_text();assert all(k in t for k in ['point=1 top=0 live=1','point=2 top=0 live=1','live=0 PASS'])
typed=[read(root/f'typed-{i}.log') for i in range(5)]
for x in typed:assert x['count']==x['operations']==100000 and x['errors']==x['backlog']==0 and x['vm_accounting']==0
print('typed median ns/op',statistics.median(x['ns']/x['count'] for x in typed))
report={'rows':rows,'comparisons':comparisons,'typed_rows':typed,'typed_diagnostics':read(root/'typed-allocations.log'),'diagnostics':{v:read(root/f'{v}-diagnostics.log') for v in rows},'timing_vm':'LuaJIT only; Lua54 diagnostic runs test error/cleanup, not timing equivalence','allocation_scope':'Lua allocator only; counters disabled in timing are unavailable, not zero allocations'}
(root/'validated-costs.json').write_text(json.dumps(report,indent=2))
