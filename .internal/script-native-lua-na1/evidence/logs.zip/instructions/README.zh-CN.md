# V4-NA1 指令包

这是一份交给LLM实施方的**未执行实验规格**。目标不是优化Lua协程外壳，而是由原生C++任务持有跨等待状态，只在需要业务计算时同步调用Lua。

推荐阅读顺序：`AGENT_START_PROMPT.zh-CN.md` → `SPEC.zh-CN.md` → `WORK_PLAN.json` → `TEST_MATRIX.csv`/`PERFORMANCE_PLAN.json` → `SOURCES.md`。

## 文件

- `SPEC.zh-CN.md`：规范主文档，含明确组合方案、权限/生命周期、数据/错误桥、工作负载、观察与资格。
- `AGENT_START_PROMPT.zh-CN.md`：直接给实施agent的入口。
- `WORK_PLAN.json`：N0–N7依赖、冻结项和停止边界。
- `TEST_MATRIX.csv`：54条必须映射的合同要求，全部初始NOT_RUN。
- `PERFORMANCE_PLAN.json`：9条正式A/B比较，3对各6进程，共54个有效正式进程；不是54项合同测试。
- `RESULT_TEMPLATE.json`、`RESULT_TEMPLATE.zh-CN.md`：空的结果模板，不含新测量数据。
- `start_branch.py`：可选安全启动工具；默认只读检查，`--create`才在新目录clone并建立本地实验分支。**不推送、不构建，不触碰原工作区内容。**
- `analyse_pairs.py`：对实施方规范化后的真实运行记录复算；不执行引擎、不推断性能因果。
- `ANALYSIS_INPUT_FORMAT.md`：复算输入合同。
- `SOURCES.md`：固定源代码与官方机制来源，新API建议与已有事实明确分开。
- `PACKAGE_MANIFEST.json`、`PACKAGE_CHECKS.json`：本指令包文件hash与生成时结构检查；不是引擎资格。

## 启动工具示例

需要Python 3.10+和Git。以下是供实施机器执行的命令，不表示本包作者已经执行：

```text
python start_branch.py --repo "E:/your/lux-engine" --destination "E:/your/isolated/native-lua-na1"
python start_branch.py --repo "E:/your/lux-engine" --destination "E:/your/isolated/native-lua-na1" --create
```

工具发现目标目录/分支已存在、仓库origin不匹配、固定生产输入差异等会拒绝自动继续。失败留下新目录和日志供检查，不自动删除它们。不要通过修改脚本去绕过真实权限或基线限制。

主实验完整范围是C++原生任务+同步Lua步骤；新FlowForge→Lua桥没有被默认塞进本轮。原FlowForge回归与混合Physics仍为强制工作。
