from pathlib import Path
import re
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source')
p=r/'modules/function/script/core/include/lux/engine/function/script/abi/lux_script_abi.h'; t=p.read_text().replace('#define LUX_SCRIPT_ABI_VERSION 5u','#define LUX_SCRIPT_ABI_VERSION 6u').replace('Explicit native instance context; separate from generic per-call user_context.','Explicit native instance context, bound once and passed as the entry argument.'); t=re.sub(r'    void\*\s+user_context;[^\n]*\n','',t); t=t.replace('    const lux_script_native_instance_context* native_instance;\n',''); t=t.replace('typedef int (*lux_script_invoke_fn)(lux_script_call_frame* frame);','typedef int (*lux_script_invoke_fn)(void* context, lux_script_call_frame* frame);'); t=t.replace('typedef int (*lux_script_step_start_fn)(\n','typedef int (*lux_script_step_start_fn)(\n    const lux_script_native_instance_context* instance,\n'); t=t.replace('typedef struct lux_script_step_desc {','''typedef enum lux_script_frame_initialization {
    LUX_SCRIPT_FRAME_ZEROED_BY_HOST = 0,
    LUX_SCRIPT_FRAME_INITIALIZED_BY_ENTRY = 1
} lux_script_frame_initialization;

typedef struct lux_script_step_desc {'''); t=t.replace('    lux_script_step_destroy_fn destroy;\n','    lux_script_step_destroy_fn destroy;\n    uint32_t initialization; /**< lux_script_frame_initialization; unknown values rejected. */\n    uint32_t reserved;\n');p.write_text(t)
# Narrowly transform sync entry declarations, bound sync call sites and explicit frame aggregate initializers.
files=[p for root in ('engine','modules/function/script','cmake/installed-consumers') for p in (r/root).rglob('*') if p.suffix in ('.cpp','.hpp','.template','.in')]
for p in files:
 t=p.read_text(encoding='utf-8-sig'); old=t
 t=re.sub(r'\((lux_script_call_frame\s*\*\s*(?:\w+)?)\)',r'(void* invocation_context, \1)',t)
 # frame context expressions belong to sync entries only; native production wrapper handled separately below.
 if p.name!='NativeScriptBackend.cpp':
  t=re.sub(r'\b(?:frame|call)->user_context\b','invocation_context',t)
 # All dot-form one-argument .invoke(&frame) in these directories are bound script sync entries.
 t=re.sub(r'([\w.\[\]>-]+)\.invoke\((&\w+|std::addressof\(\w+\))\)',lambda m:f'{m[1]}.invoke({m[1]}.context, {m[2]})',t)
 # Remove obsolete assignments only; contexts are passed at each actual entry, including repeated calls.
 if p.name!='NativeScriptBackend.cpp': t=re.sub(r'^\s*\w+\.user_context\s*=\s*[^;\n]+;\n','\n',t,flags=re.M)
 matches=list(re.finditer(r'\blux_script_call_frame\s+\w+\s*\{',t))
 for m in reversed(matches):
  a=m.end(); depth=0; parts=[]; start=a; i=a
  while i<len(t):
   c=t[i]
   if c=='}' and depth==0: parts.append(t[start:i]); break
   if c in '({[': depth+=1
   if c in ')}]': depth-=1
   if c==',' and depth==0: parts.append(t[start:i]); start=i+1
   i+=1
  if len(parts)>7:
   t=t[:a]+','.join(parts[:7])+t[i:]
 if t!=old:p.write_text(t,encoding='utf-8')
# Native entries interpret context consistently as the stable native-instance descriptor, never raw state.
for f in ('modules/function/script/native/test/native_fixture.cpp','modules/function/script/native/test/native_collision_fixture.cpp','modules/function/script/native/test/native_step_fixture.cpp','engine/domain/simulation/scripting/native/test/population_fixture.cpp'):
 p=r/f;t=p.read_text(); t=re.sub(r'int (\w+)\(void\* invocation_context, (lux_script_call_frame[^)]*)\)( noexcept)?\n    \{',lambda m:m[0]+'\n        const auto* native = static_cast<const lux_script_native_instance_context*>(invocation_context);\n        void* state = native ? native->state : nullptr;',t)
 # refer to state only in bodies, retain initial context cast
 t=t.replace('invocation_context == nullptr','state == nullptr').replace('!invocation_context','!state');t=re.sub(r'\*?>?\(invocation_context\)',lambda m:m[0],t) if False else t
 for ty in ('std::int32_t','float','std::uint32_t','const std::uint32_t','const float'):
  t=t.replace(f'static_cast<{ty}*>(invocation_context)',f'static_cast<{ty}*>(state)')
 # Native step function explicit instance, all context use moves off call frame.
 t=t.replace('        lux_script_call_frame* call,','        const lux_script_native_instance_context* instance,\n        lux_script_call_frame* call,').replace('int start(lux_script_call_frame* call,','int start(const lux_script_native_instance_context* instance, lux_script_call_frame* call,')
 t=t.replace('call->native_instance','instance');p.write_text(t)
# Production native sync wrapper disappears.
p=r/'engine/domain/simulation/scripting/native/src/NativeScriptBackend.cpp';t=p.read_text(); a=t.index('        static int invokePrepared(');b=t.index('        static int startEventWait(',a); t=t[:a]+t[b:];t=t.replace('lux::script::BoundScriptCall{&invokePrepared, std::addressof(prepared)}','lux::script::BoundScriptCall{function->invoke, std::addressof(instance->native_context)}');a=t.index('            const auto* previous_native = frame.native_instance;');b=t.index('            StepAdapter adapter',a);t=t[:a]+t[b:];t=t.replace('            frame.user_context = previous_user;\n            frame.native_instance = previous_native;\n','');t=t.replace('prepared.function->step->start(\n','prepared.function->step->start(\n                std::addressof(prepared.instance->native_context),\n');t=t.replace('            std::memset(frame->data, 0, step.frame_size);','            if (step.initialization == LUX_SCRIPT_FRAME_ZEROED_BY_HOST)\n                std::memset(frame->data, 0, step.frame_size);');p.write_text(t)
# Production lifecycle/execution no longer mutate context in frame.
for f in ('engine/domain/simulation/builtin/script/src/ScriptInstances.cpp','engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptExecution.hpp'):
 p=r/f;t=p.read_text();t=re.sub(r'^\s*frame\.user_context = call\.context;\n','\n',t,flags=re.M);p.write_text(t)
# loader rejects invalid init strategy before invoking any module function.
p=r/'modules/function/script/native/src/NativeModule.cpp';t=p.read_text().replace('step.frame_layout_hash == 0U;','step.frame_layout_hash == 0U ||\n                        step.initialization > LUX_SCRIPT_FRAME_INITIALIZED_BY_ENTRY || step.reserved != 0U;');p.write_text(t)
