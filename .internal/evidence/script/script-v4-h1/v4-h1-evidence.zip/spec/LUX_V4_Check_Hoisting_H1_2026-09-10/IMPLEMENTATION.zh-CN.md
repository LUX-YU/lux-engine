# V4-H1：装配期证明、调用边界验证与热路径去重

日期：2026-09-10  
对象：LUX-YU/lux-engine，LLM 实施方  
交付类型：**待执行的实施规格，不是实施结果**  
主线：回到 V4；不采用 A1；先取得最终 V4 的热点，然后修改有充分依据的检查与访问链。

## 0. 本轮决定

**不是“把所有检查搬到装配期”，而是“不让已经证明且仍然有效的事实在内部热路径反复被证明”。**

将检查放到它第一次能够正确完成、且其结论可以安全沿用的位置：

- 不可变结构：编译/生成、模块加载、装配及发布阶段。
- 实际调用输入和来源：每次进入相应边界时。
- 已定位对象：同一个不发生失效的短区间内复用，不再 ID→目录→对象往返。
- 运行中可变的权限、代次、容量和状态：在真实操作/提交时检查；跨用户代码后按原合同重验。

本轮允许重写私有入口和准备结果，但不创建统一 ExecutionCell、第二 scheduler、额外结果池或通用“证明运行时”。
**证明应主要体现在构造路径、可见性、已有准备记录及局部控制流中，不是为每次调用再分配一张证书。**

## 1. 身份、分支与恢复

| 项目 | 固定参照 |
|---|---|
| V4 开发/报告分支 | `codex/s6-deep-optimization` |
| 已读取的分支 HEAD | `f92853ea8361a7dc90ce0da072497d3722c29f88` |
| V4 实际资格源码 | `f7d2815bdd2025ee23a7c11449def822413f58e9` |
| 建议本轮隔离分支 | `codex/s6-v4-prepared-checks` |
| 不采用但保留的实验分支 | `codex/s6-execution-cell-a1` |
| A1 报告 HEAD | `1039f2bcca44cff7bdfdb09f5c090db3647ae32a` |
| A1 实际资格源码 | `caf34bd307912450d894da922b59af4238154508` |

本次读取时，V4 远端分支没有被 A1 覆盖。[S01]

实施方先读取仓库 AGENTS.md 及改动子目录约定，核对本机实际状态。保留未知修改、旧镜像及实验记录。
使用新的 worktree/隔离克隆或现有已确认安全的 V4 工作树；不执行 `reset --hard`、`clean -fd`、删除 A1 或 force-push。
若上述分支已前进，记录差异，不把未知新改动混入本轮；仍从固定 V4 源码建立可解释的候选。

V4 的源码、公共头、生成器、SDK、DLL/PDB、EXE、资产必须配套。A1 改过公共 C++ EventWaitFactory 的 callback 签名；
Native C ABI 同为 6 并不使两组公共 C++ 产物可混用。[S11]

将基线镜像设为只读的比较对象，不覆盖。可以从 V4 HEAD 开发，但必须核对其生产输入与 f7d2815b 的关系。
报告/归档提交不得重标为测量身份。正式候选以最终 clean commit 和真实产物清单为准。

## 2. 已确认事实与尚未确认的问题

### 2.1 已确认的 V4 事实

1. Native `prepareMethod()` 已校验方法参数/返回合同并准备 frame layout；`createNativeContinuation()` 又检查
   step 存在性、frame_size 和 frame_align。这是本轮需要拆分“结构不变量”和“存活性”的具体入口。[S02]
2. `ScriptPreparer::prepareMount()` 已检查 Event schema、payload 布局与最大结果字节数；
   `waitEvent()` 在取得有效来源之后又进入通用 `reserveAwaitable()`。[S03][S04]
3. `PreparedInvocation::current()` 已只读取既有 authority 的 ACTIVE 和完整实例身份。
   同步 C++ 路径不是每次从头验证全部装配合同；不要再为它添加证明对象或另一个目录。[S05]
4. Lua typed Ability 已有 `if constexpr (can_reenter)`：默认 scalar 输入不重复做转换后资格检查，
   可能重入的输入转换才做。这项优化已存在，不算本轮新成果。[S06]
5. Lua `current()`/`revalidate()` 仍检查当前 thread、execution、closure layout 与原调用资格；
   Native/Lua 恢复入口仍验证实际 packet。这些检查不全是静态 schema 检查。[S07][S02]
6. Native frame 热路径重复计算 `domain.stride / class.stride`；C++ Ticket 释放重新构造完整 Allocation 后
   进入另一个 checked release。这是两个可具体检查机器码的去重候选。[S08][S09]
7. V4 W0 的内层 callback 栈额度修正已经落地。不能为了减检查撤销它。[S10]

### 2.2 当前不能声称的事情

没有本轮最终 V4 ROI profile，不能说“所有热路径时间主要来自检查”，也不能预先给出减少检查后的加速比例。
A1 的单侧 profile、早期 VM 的 longjmp 比例、W2 之前的采样不能替代最终 V4 的当前分布。
一个分支在已有 benchmark 中从未触发，不构成它能够被删除的证明。

## 3. 检查分类：逐谓词分类，不按整个函数分类

| 类别 | 定义 | 处理 |
|---|---|---|
| P：装配不变量 | 只依赖已封闭的 descriptor、固定配置或不可变布局 | 迁入/复用装配证明；私有 kernel 不重复验证 |
| B：实际输入边界 | 本次参数、实际 ABI packet、closure 来源/ordinal 等 | 在实际边界检查；同一验证区间下游复用结论 |
| L：生命周期/权限 | ACTIVE、实例代次、发布域、撤权、旧 token、当前执行 | 保留动态检查；缩短机制；跨失效边界重验 |
| R：资源/状态机 | 当前 A/C/queue 容量、pending/ready、pin、OOM、step budget | 在原操作/提交时点保留，不提前接纳或提前拒绝 |
| D：局部重复 | 已经验证并定位，且中间没有可能失效的操作 | 传递局部借用或直接复用引用，删除重复解析 |
| U：未证明 | 不能说明来源、写入者或有效期 | 本轮保留，登记缺失依据；不得猜成 P |

同一 `if` 可以含 P+B+L：必须拆出具体谓词，不能把整个条件归为“装配检查”后删除。

### 3.1 必须使用的判定问题

对每个拟删除/移动的谓词，回答：

- 它依赖哪些字段？谁能写这些字段？
- 结论何时建立？位于哪个真实 factory/prepare/commit？
- 它对哪个对象、发布代次、方法布局有效？
- 在哪次调用、释放、复用、重入或外部输入之后失效？
- 不检查时，旧实现能拒绝的哪类输入仍由哪一个入口拒绝？
- 错误码、错误优先级、已发生的业务副作用和资源归还时点是否不变？
- 该谓词是否已经被编译器消除？若已消除，不能把源码变短算成 CPU 优化。

写入 `CHECK_AUDIT.csv`。只覆盖本轮指定的实际调用链，不做全仓每个 if 的庞大普查。

### 3.2 不能装配化的典型条件

装配知道 `Delay.seconds` 需要 double，并不知道本次 double 是否 NaN、Inf 或非法 duration。
装配知道 record 有哪些字段，并不知道本次 Lua table 是否缺字段、多字段或值类型错误。
装配知道 A 容量是 N，并不知道下一次登记时已占用多少，以及被 pin 延迟回收的槽是否可用。
装配知道一个 prepared method 成立，并不知道它执行前是否已退休，或者转换期间是否已撤权。
装配知道结果预期类型，并不知道一个外部 producer 本次传来的 type、size、data 是否匹配。
装配知道 codec 需要多少额外 Lua 栈位，并不授予以后每个 C callback 的当前 CallInfo 相同额度。

最后一项必须区分“所需数量是静态的”与“当前栈是否满足、是否需要扩容是动态的”。Lua 官方 API 对新的 C 调用栈
和 lua_checkstack 的说明见 [S12]；本轮不再次修改 Lua 栈保障模型。

## 4. 目标调用结构与约束

```text
装配/重新装配：
    校验静态 descriptor 与布局
    → 形成已有 owner 管理的 prepared 数据
    → 保留必要的资源/模块 lease
    → 最后发布

每次外部/可变输入进入：
    检查当前输入、当前来源和必要的当前权限
    → 得到局部已定位借用
    → 私有 resolved/prepared kernel
        不重复静态合同、目录解析和已经完成的局部判断
    → 运行资源接纳/状态转换

跨用户代码：
    结束可能失效的借用
    → 用户转换 / provider / backend / destructor / 可重入分配
    → 按原合同重验原身份与当前权限
    → 必要时重新定位
```

### 4.1 有效期不只等于“这次调用没有返回”

`noexcept` 不等于不能重入。调用用户 allocator、record converter、payload copy、provider、backend start/resume/destroy，
以及能够运行 Lua finalizer 的操作，均不能无证据地视为安全区间。

稳定地址也不等于对象角色还存活。Protection/pin 可以延迟物理释放，但不保证 ACTIVE、等待状态或发布身份仍有效。
移动型 SlotMap 的对象指针不得跨可能 erase/移动它的操作；稳定 A 记录也必须遵守最后 pin 和逻辑释放合同。

### 4.2 禁止的“优化方式”

不得通过全局关闭 runtime validation、Release-only `assert`、`__assume`、unchecked 公共入口或修改测试期待删除保护。
Debug assert 可以记录私有不变量，但不是建立不变量的机制；所有可到达的坏输入必须由既有错误边界正确处理。

不得新增公共 `trusted=true` / `skip_validation` 参数。未经过受控构造的普通 public struct 不构成可信资格。
同一个 kernel 可以被 checked gateway 与 prepared 内部调用共用；禁止复制两套 scheduler 或完整业务实现。

不得让生成代码“来自我们生成器”自动成为可信凭据。公开 Native ABI6 仍可被其他消费者调用，ordinal、buffer、packet
仍需在它们实际进入的边界验证。没有已验证 provenance 的路径继续使用 checked gateway。

不得为每个 C/A/Ready/来源记录增加一组新的 proof ID、epoch、shared_ptr 或 side map。
本轮保持 Ready、Event waiter、Timer wait、C/A 主体布局不膨胀；证明尽量复用已有 prepared 字段及栈上短借用。

## 5. 连续实施顺序

| 阶段 | 交付 | 是否要求生产编码 |
|---|---|---|
| H0 | 恢复匹配 V4、检查分类、当前 ROI 热点和反汇编入口 | 诊断驱动；生产逻辑不改 |
| H1 | Native prepared step 的静态/动态验证分离 | 是 |
| H2 | 本地 Event 结果接纳的装配证明复用 | 是 |
| H3 | C++ 释放去重；Native 固定算术有限候选 | C++ 是；固定算术按成本选择 |
| H4 | Lua 边界与转换的检查归属审查，并只改剩余可证明重复 | 审查必须；没有真实重复可不改生产 |
| H5 | 最终有限 A/B、回归、SDK 和 unified 交付 | 是，执行验证 |

H0–H5 是连续实施的子提交，不是逐阶段等人工批准。完成 H0 后实际编码，不能只交一张检查表。
H1/H2/H3 的目标不能用“适用项已完成”掩盖；存在合同阻碍时逐项说明并标 PARTIAL，继续其他独立主线。
已经完成的去重若没有机器码或整体成本收益，保留负结论，必要时撤销候选，不强行凑优化数量。

## 6. H0：当前 V4 定位，限定工作量

### 6.1 取样范围

先取得五条场景各一份有效软件 Hotspots：Lua Event、FlowForge Event、Lua scalar Ability、原 ValuePose record、C++ Sequence。
全程正常执行原装配、预热、业务 oracle 与清理；将 ROI 限定在原正式业务循环。只在单独 profile driver 中
使用已有 ITT 支持或窄 pause/resume 接入；正式无采样 A/B 不加入逐操作埋点。[S13]

若某场景太短不足以形成可解释分布，只能在明确标注的采样运行中增加完整批次数；不能改变正式比较的工作量。
不在每条 continuation 上创建 ITT task；可使用每批次 3 段的窄诊断记录启动/登记、来源完成、恢复/清理。

采样应保留真实 target exit、原业务 oracle、已加载模块与匹配 PDB。导出 self/inclusive/module/caller；
不得把 inclusive 与其子树 self 相加，不得把采样进程时间写成优化后的正常耗时。
ITT/collector 的具体参数按本机版本帮助确认，不复制未经支持的 CLI 选项。ITT 不可用时保留完整进程采样的范围限制，
不通过任意截时间冒充精确 ROI；这一环境限制不阻塞有源码证明的 H1–H3。

### 6.2 硬件事件和机器码

PMU 可用时只为排名靠前且需要解释的热点补一次硬件采样；不可用记录限制，不更改系统安全策略/驱动权限。
无 PMU 不给 cache-miss 或 branch-miss 的精确归因。分支多不等于预测失败多。

反汇编至少包括：Native invoke/create/resume/destroy、frame acquire/release、C++ Ticket release、Event reserve、
Lua current/revalidate 和 scalar worker。记录符号/RVA、DLL/PDB 身份与观察到的分支/调用，不要求给每个 if 单独定时。

H0 输出 `PROFILE_BASELINE.zh-CN.md` 和填写后的检查审计。profile 只决定可选候选的优先级，不是证明静态性的依据。

## 7. H1：Native prepared step——装配证明一次，运行保留必要门禁

主要文件：

- `engine/domain/simulation/scripting/native/src/NativeScriptBackend.cpp`
- 对应 Native 私有头与测试；需要时检查 NativeModule 的加载校验实现，但不更改 ABI6。

### 7.1 当前问题

`prepareMethod()` 完成签名与 frame layout 准备后，`invokePreparedStep()` 再检查 prepared 链，
`createNativeContinuation()` 又检查 function/step、frame size、power-of-two alignment；resume/destroy 又穿过同一 descriptor 链。[S02]

这些条件里有不同性质：step descriptor 的静态形状可由装配保证；prepared 槽是否仍活跃、调用来源是否有效则不是。

### 7.2 修改方法

1. 核对 loader→prepareMethod→发布的现有校验，确认 start/resume/destroy 指针、非零 frame_size、对齐及最大配置已被证明。
   所有进入 prepared 内核的路径必须经过同一完整准备过程。原本在冷期拒绝的输入保持同阶段和原错误策略。
   若某输入在 V4 合法装配但运行时按特定错误返回，不得无授权把它改成冷拒绝；该谓词保留 checked 路径或登记阻碍。
2. 在 `invokePreparedStep()` 的现有 checked 入口解析有效 PreparedCall，保留已有失效/空发布判断。
   一次取得只读 step 引用和 layout；传给私有 `createNativeContinuationResolved(call, step)`。
   该函数不再从 call.function 回溯，也不重复静态 frame 形状验证。
3. 创建内核仍在原时点检查 free_continuations、frame_storage 当前容量、generation 与 acquire 成败，失败原样回滚。
   不在方法之外提前接纳核心 C，不绕过 backend 自己的原 frame 配额。
4. start/resume/destroy 只在其所需边界解析 descriptor 一次。优先用现有 ModuleEntry/PreparedCall 和局部引用，
   不为每条 NativeContinuation 复制一份新 descriptor 或增加 lifetime token。
5. 跨 step.start/resume/destroy 不缓存可能被重入失效的角色状态。模块 lease 保证 immutable descriptor 的物理寿命，
   不自动保证 prepared 槽/实例资格仍有效。保持 V4 的失败清理和析构回调顺序。
6. Native `startEventWait(ordinal, waiting_on)` 是 ABI 边界：本次 ordinal 范围、输出指针和实际 step context 不应被
   当成 assembly 常量删掉。一次成功解析后，其私有下游可使用 `PreparedEvent` 引用；不得再沿 module 查 import。
7. `stepResult(outcome)` 的 state/status/token 来自本次运行，不能只因方法签名已知而省掉合法状态验证。
   `resumeNativeContinuation` 的实际结果 mismatch 继续验证；本轮不新建跨公共 backend ABI 的“trusted packet”通路。

### 7.3 预期结构与验收

```text
checked prepared entry
    → 本次有效 call + 已装配的 step
    → 当前容量接纳
    → start / resume / destroy
```

正常准备好的 frame 不再重复验证 descriptor 大小/对齐；坏公开/失效入口仍受控拒绝。
用实际 Native/FlowForge Event 和混合 Sequence 进入新内核，不以手写假函数代替生成消费者。
记录源码去重是否体现在机器码。如果原编译器已消掉重复分支，只登记维护改善，不写 CPU 加速。

## 8. H2：Event 接纳——复用现有装配证明，不削弱实际来源验证

主要文件：`ScriptPreparer.cpp`、`ScriptInstances.hpp`、`ScriptExecution.hpp`，必要时相应私有头。

### 8.1 采用两个内部入口、一个动态接纳内核

保留通用结果入口的原行为：

```text
raw/public/custom 结果描述
    → 检查本次 result_type 与 external transport 支持
    → reserveAwaitableValidated(...)
```

新增/拆分只供本地 Event 已解析路径使用的内部入口：

```text
waitEvent
    → 原 stopping/instance 检查
    → eventSource：本次 handle 的 scope/instance/layout epoch/ordinal 验证
    → 原 targeted entity 检查
    → 原 Event source preflight
    → 已装配 payload → reserveAwaitableValidated(...)
    → 原 source commit
```

`reserveAwaitableValidated` 是同一 owner 的私有实现，不是新增 public unchecked API。
它不接受外部能随手构造的“可信 bool”。可以用窄私有借用类型限定入口，也可以用受控私有调用图；
不要求持久保存一份证明对象，不扩大 Event waiter/Ready/ARecord。

### 8.2 证明建立处

`prepareMount()` 已比较 Event descriptor/endpoint schema、payload 布局并检查 max_resume_payload_bytes。[S03]
核对 `PreparedResumeType::valid()` 涉及的每个字段在 artifact、endpoint 或 construction 中是否确实检查。
缺少证明的谓词不能直接删除。完善已有冷装配验证时保留原拒绝语义；无法做到则仅复用已证实部分。

`eventSource()` 返回与本次 handle 匹配的当前来源，此前的装配证明仅对它的 layout 有效。
保留 runtime scope、instance、layout epoch、ordinal 与 targeted entity 检查。[S05]
它们防止将另一个曾经装配成功的来源用于本次实例，而不是重新验证 schema。

### 8.3 动态内核的责任

必须保留 stopping、当前 A 占用、物理槽取得、结果存储增长/OOM、owner 链、external publication 和回滚。
只有存在连续无失效区间证据时，允许合并重复的 stopping/current 等读取；不改变其拒绝先后。

Event 仍然是来源 preflight 在 A 接纳之前；Timer 仍然是 A 接纳在 duration/deadline/来源容量之前。
同一时刻两个资源都满时，原错误优先级不变。不能把“数量上限已装配”解释成“运行不用检查空闲量”。

### 8.4 已定位记录复用

在本轮真实热点涉及的私有链上，将“已获得 record 后传 ID，再 find 一次”改成短引用调用。
参考现有 `eraseAwaitableRecord(record, access)`，优先扩大对已有 resolved helper 的使用，不新增新身份系统。

`tryEmplacePrepared` 插入后再 find 的容器接口缺口可以登记；本轮固定 lux-cxx 依赖。
若现有容器没有支持，不通过侵入 private 或复制一份容器实现解决，不把临时 find 包装成所谓零查找。
仅删除可在引擎自身调用图内消除的往返。

### 8.5 结果交付与恢复

本轮不删除 actual packet/type/bytes 校验，不改变 pin 与取值/释放的次序，不让 A 结果槽占用跨 backend.resume。
Event copy 前后的权限检查保留；queue-full 的 Event fault 与 Timer retry 保持不同。
无新 permanent ticket；ReadyRecord 保持 V4 表示，避免 A1 的扩张。

## 9. H3：C++ 释放解析收敛与 Native 冷期算术

### 9.1 C++ releaseResolved：必须实施的窄改动

文件：`engine/domain/simulation/scripting/core/include/lux/engine/simulation/scripting/detail/BoundedClassStorage.hpp`。

当前 Ticket 入口已取得 page/slot/class，仍构造 Allocation 后调用第二个 checked release。[S09]
改为：

```text
release(Ticket)
    检查 owner → page/slot 边界 → slot active + 完整 generation
    → releaseResolved(已定位 page, slot, class, 释放需要的索引)

release(Allocation)
    检查非空 → page/slot 边界 → active/generation/size/expected data
    → 同一个 releaseResolved(...)
```

Ticket 入口不再合成一个 data/size 然后检查这个刚合成的值。
Allocation 入口对调用者提供的 data/size 必须继续验证。
私有 releaseResolved 只做确定的状态写入、计数与空闲链维护，不重新查目录。
没有用户代码的这个区间才允许复用引用；不得把其裸引用用于下一次任意 release。

保留完整 generation、owner、double free、错票据拒绝与容量计数。
不改变24B frame header、compiler frame 上限、arena 预算或物理槽布局。

### 9.2 Native slots_per_region：有条件采用

文件：`NativeFrameStorage.hpp`。
layout 准备后 `d.stride / c.stride` 不变；检查实际 DLL 是否仍在 acquire/release 中执行除法。
若存在且当前路径值得处理，将它移到 prepare，并以不破坏资源预算的方式提供给热路径。[S08]

不能盲目给所有 Class 加一个字段：当前 Class 数量由 prepared_call_capacity 驱动，字段增长会放大已有 metadata 债务。
在不扩大当前目录总 backing、不新增热期间接层的前提下可以实施；否则此候选记为
`NOT_SELECTED_METADATA_TRADEOFF`，保留原实现。

本轮不顺手重写 layout catalog 的 P→Q 容量规划；其未来模块/布局接纳合同需另行处理。
不得为了省除法降低合法 alignment/size 范围、N 个全大 frame 保证或原共享容量域。

## 10. H4：Lua——边界集中，但不把动态脚本当成静态调用者

主要文件：LuaScriptBackend.cpp、LuaScriptAbilityProjection.hpp；必要时阅读 LuaValue.cpp，默认不改 codec 表示。

### 10.1 已经存在的优化先登记

`invokeLuaValueAbility` 根据参数 codec 的编译期事实选择 can_reenter；普通 scalar 不走转换后的二次 revalidate。[S06]
保留它，不再加“所有 scalar 无需检查”的新运行模式。
这里免除的是一处有条件的资格重验，不是参数个数、数值类型、range 或当前 invocation 的验证。

### 10.2 可以做的实际修改

对 `LuaAbilityProjectionAccess::current()` 与 Event projection 的成功解析结果：

- 把准备时已经验证的 method/dispatch/result layout 用已有不可变 prepared 数据表达。
- 边界完成当前 owner/thread/layout/ordinal 检查后，内层复用已定位 prepared 引用。
- 删除无用户代码区间内确实重复的 context/descriptor 解析，但保留边界本身。
- `PreparedAbility.context/dispatch` 等非空约束，只有在查明所有构造、standalone、退休和发布路径之后，
  才允许从私有下游删除；不因类型名字带 Prepared 就假定成立。
- 不新增每个 invocation 持久证书，不把 scratch access 塞进 coroutine frame；测量现有 access 的真实使用和机器码。

若当前 projection 已经做到一次解析、没有可删除的重复，就报告 `ALREADY_BOUNDARY_ONLY`。
H4 的审查必须完成，但不强迫实现方为“必须改 Lua”制造无收益的额外抽象。

### 10.3 必须保留的边界

Lua 实际参数类型、数量、数值范围、enum 合法性和 raw record shape 都是动态输入。
从 raw table 到有类型 C++ 值只需按当前转换合同检查，但不能把“schema 已知”当成“本次 table 正确”。
当前声明字段时序、未知/缺失字段错误、独立结果 table 身份均不变。

closure 的当前来源属于本次调用条件。不得因 closure 在装配时创建，就删除与当前 prototype/layout 的对应验证。
还应核对当前库开放方式和 debug 行为：Lua debug.setupvalue 能修改函数 upvalue。[S12]
不改变标准库开放范围，不冻结用户表，不改正常 Lua 动态能力。只覆盖基线已承诺的合法/受控拒绝行为，
不将本轮扩成“防止任意 native 指针伪造”的新 sandbox 项目。

原 `revalidate()` 复用 ORIGINAL invocation validity；不能在回调之后重新 capture 一个新的已授权身份来放行旧调用。
恢复结果转换后的 active/instance/call/thread/wait/generation 检查保留原有效性含义。[S07]
结果 copy、allocator、converter 或 provider 一旦可能改变权限，之前的 TRUE 不能缓存沿用。

W0 callback 内的 checkstack、pcall/OOM 边界以及失败时拥有型对象清理保留；不把 Lua 内部API检查宏当作性能开关。

## 11. 不混入本轮的工作

固定 Lua55 VM patch、GC 参数、16MiB 空页预算、LuaPageAllocator、table/record 表示、Native ABI6、C/A存储模型。
固定编译器、/Ob、ISA/IPO和运行线程/恢复预算。/Ob2 或 compiler/LTO 实验本轮不采用，防止与检查迁移混合归因。

不做 cell、透明 coroutine/table 池、thread+stack 合并、table IC、生成式轻结果池、额外全局epoch或宽 Ready ticket。
不重新实现已完成的 local Timer、384B档、inline CI、cold codec plan、C++24B header 或 buffer capacity 复用。
Native P/Q 元数据债务、V4 scalar 回退和其他成本继续登记，不能用本轮目标较窄而宣称这些问题已关闭。

## 12. 最小充分回归：围绕被删除的谓词写反例

详细用例表在 `TEST_MATRIX.csv`。优先复用现有测试，针对改动补窄断言；不要复制全套A1实现。
所有断言在所用配置中必须实际生效。

关键验收：

1. 不匹配的冷 descriptor/schema/layout 仍不发布；失败回滚无半成品入口。
2. 旧/跨实例/跨布局来源仍被拒绝；合法相同布局实例仍工作。
3. 延迟停止与即时撤权保留原差异；转换期间撤权阻止原调用继续使用资格。
4. 实际 Lua 错数量/类型/范围/shape 仍不调用 provider；provider 已执行后的结果失败不撤销业务副作用。
5. A/C/来源/queue 容量以及“双满”错误优先级不变；晚 C 接纳、pin物理占槽、stale pop预算不变。
6. Event copy 重入、Timer retry、foreign/unbound等待的已有通用路径保持。
7. C++ 错 owner/旧 generation/篡改 data-size/重复释放仍拒绝；正常 acquire-release重新可用。
8. Native 深/混合frame、destroy重入、start失败清理、有效模块 lease 与完整关闭保持。
9. Lua callback 深度1/16/32、扩容失败和恢复继续覆盖；最大深度 public expected 包装器的既有 MSVC 限制不伪称消失。
10. 没有把有效运行业务减少、输入验证关闭、脚本改成固定局部绑定来换取时间。

只对准备记录原本确实不可能的内部状态使用 debug invariant；不通过 delete 测试来删除可观察的拒绝合同。

## 13. 最终成本比较与采用规则

### 13.1 正式七腿，不为每个 if 建微测试

使用现有 V4 驱动及实际 oracle，七腿各三对独立进程，AB/BA/AB，共42个正式进程：

| 场景 | 保持的工作量/单位 |
|---|---|
| Lua Event | 原10000实例、1000预热、2000计时批次；完整周期 |
| Lua NextStep | 同上；完整周期 |
| Lua scalar Ability | 同上；原一次provider/实例的完整调用 |
| ValuePose record | 原1000预热、1000000完整嵌套双向调用 |
| FlowForge Event | 原10000实例、300预热、1000计时批次；完整周期 |
| C++ Sequence | 复用原sequence驱动；1000完整帧，完整序列边界；不额外drain |
| Physics mixed | 原混合业务300预热、2000计时帧 |

C++ Sequence 具体 group/数量参数、所有资产与 seed/budget 从 V4 原驱动读取，不凭本表推导新的 workload。
正式 A/B 不开诊断计数，不使用采样耗时，不筛除慢组，不把历史不同轮次中位数拼成新对照。

初期调试只做受影响用例和有限 smoke；最终只统一做这一轮七腿。失败和无效运行保留，不能反复追一个3%数字。
需要定位明确回退时，最多对直接相关子提交做一次有限撤销对照，之后保留结论，不扩大成全组合消融。

### 13.2 成本和检查结论分别报告

- 源码：哪些 P 被前移，哪些 D 被复用，哪些本来已经是边界最少检查。
- 机器码：目标分支/调用/除法/重查是否实际消失；源码删了但机器码不变必须如实写。
- 运行：完整业务、错误和backlog；有效CPU/墙钟/批次分布，各自测量范围。
- 资源：prepared/continuation/result/source/ready 的 sizeof、capacity、owned backing、代码体积。
- 配置：VM/GC/预算/编译器一致，保留在途任务与容量，不伪称“线程创建为零”。

不预设所有安全检查都昂贵，也不把“检查条数下降百分比”当作速度提升。
稳定且很小的安全性/维护改进可以保留为代码质量结果；性能不明确时不要宣传性能资格。
若候选引入明确总体回退，分项撤销该候选，不能因为已写完而合并。

### 13.3 资格和SDK

最终 clean 源码一次 Developer/Toolchain完整构建、二轮无工作、相关全部CTest；固定VM4项合同继续运行。
公开头/安装库/生成器改动影响的SDK消费者必须重新编译和实际运行；可复用既有15消费者、13增量、两条迁址的脚本。
本轮若改变这些输入，就执行相应原资格集合；若未改变，可明确引用不受影响的范围，不能填成新跑过。
记录实际数量与限制，不把“必须恰好还是126/110”作为目标，也不恢复旧Lua版本测试。

## 14. 最终交付

在隔离分支提交/推送（依仓库授权规则），不合并 V4/main、不发布tag、不覆盖基线SDK。
最终至少包括：

- `RESULT.zh-CN.md`：源身份、修改/未采用项、成本与限制、建议。
- `CHECK_AUDIT.csv`：每个删除/前移/合并谓词的证明和旧坏输入的拒绝归属。
- `PROFILE_BASELINE.zh-CN.md`：最终V4本轮ROI热点、对应的实际函数/指令，不能使用A1样本替代。
- `TEST_MATRIX.csv`：用例到真实测试/日志/状态的对应，不预填PASS。
- `result.json`：实际源码/产物身份、原始计时、配对、resource、unobserved=null、失败尝试。
- 足够重放的原始日志、VTune导出及本机原result位置、机器码关键片段。不要制作多份相同原始包。

状态至少分开：

```text
implementation: COMPLETE / PARTIAL
contract: PASS / BLOCKED / INCOMPLETE
cost: IMPROVEMENT / MIXED / NO_CLEAR_GAIN / REGRESSION
```

“主目标改动未做”不能与“经证据选择不做可选项”混为一谈。
没有反例证明/没有工具可观测的项目明确留空，不编造可用的时间、cache miss或零检查数。

## 15. 对用户问题的实施性结论

**装配应当证明“这个能力和布局是什么”；运行边界仍要判定“这次是谁、带来了什么值、现在是否允许做”。**
本轮要减少的是同一事实在同一有效期内被重复验证的次数，不是减少系统对实际变化的感知。
原始低开销 C++ 路径已经在采用这种分工；Native frame 和已准备的 Event 接纳还有可以具体前移/去重的地方。
只有在实际边界、寿命和资源合同闭合后，热内核才可以不再自我怀疑。

---

## 来源索引

下列是代码/记录来源；章节里的修改方法是本方案提出的设计，尚未实施验证。
仓库链接与读取范围见 `SOURCES.json`。来源不足之处已列 U/保留边界，不由一般知识替代。

- S01：GitHub 分支元数据；V4 HEAD f92853ea8。
- S02：V4 NativeScriptBackend.cpp，prepareMethod/bindEvents/invokePreparedStep/create/resume/destroy。
- S03：V4 ScriptPreparer.cpp，prepareMount/eventMatches。
- S04：V4 ScriptExecution.hpp，reserveAwaitable/waitEvent/attach/take/pin。
- S05：V4 ScriptInstances.hpp，PreparedInvocation/current/AuthorityAccess/eventSource。
- S06：V4 LuaScriptAbilityProjection.hpp，invokeLuaValueAbility/can_reenter。
- S07：V4 LuaScriptBackend.cpp，current/revalidate/恢复转换及执行资格。
- S08：V4 NativeFrameStorage.hpp，prepare/acquire/release。
- S09：V4 BoundedClassStorage.hpp，Ticket/Allocation两个释放入口。
- S10：V4 LuaValue.cpp 与V4实施记录，callback内checkstack已修正。
- S11：用户提供 A1 NOTES/RESULT，V4匹配基线、失败候选、旧合同和ABI不兼容记录。
- S12：Lua5.5官方手册 §4.1.1、lua_checkstack、debug.setupvalue（官方API事实，不是V4新增功能）。
- S13：Intel ittapi官方ittnotify.h（仅采集控制API；具体VTune CLI仍按实施机器帮助）。
- S14：V4 AGENTS.md（实际实施时继续读取全文及子目录规则）。
