from pathlib import Path
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1');s=r/'source'
def edit(rel,fn):
 p=s/rel; t=p.read_text(); p.write_text(fn(t))
def once(t,a,b):
 assert t.count(a)==1,(a[:70],t.count(a));return t.replace(a,b)
base='engine/domain/simulation/scripting/'
def lua(t):
 t=once(t,'            result = {\n                std::addressof(call),\n                lux::script::BoundScriptCall{&Impl::invokePreparedSync, std::addressof(call)},', '''            const bool protected_arguments = stack_values + 8U > LUA_MINSTACK ||
                std::any_of(function_binding->argument_operations.begin(), function_binding->argument_operations.end(),
                    [](const auto* operation) noexcept { return operation != nullptr; });
            result = {
                std::addressof(call),
                lux::script::BoundScriptCall{
                    protected_arguments ? &invokeConvertedSync : &invokePreparedSync, std::addressof(call)},''')
 marker='        static int invokePreparedSync(void* invocation_context, lux_script_call_frame* frame) noexcept\n'
 block='''        struct ConvertedSyncRequest final
        {
            PreparedCall& call;
            Instance& instance;
            const LuaFunctionBinding& function;
            lux_script_call_frame& frame;
            const ScriptBehavior* behavior;
            ScriptInvocationValidity qualification;
            bool bound_authority;
            std::int32_t status{kInvalidCall};
        };

        static int executeConvertedSync(lua_State* vm)
        {
            auto& request = *static_cast<ConvertedSyncRequest*>(lua_touserdata(vm, 1));
            auto& frame = request.frame;
            const auto slots = (std::max)(frame.arg_count, frame.return_count);
            const bool invalid_slots = slots > static_cast<std::uint32_t>((std::numeric_limits<int>::max)()) - 8U;
            if (invalid_slots || !lua_checkstack(vm, static_cast<int>(slots + 8U)))
                return 0;
            lua_rawgeti(vm, LUA_REGISTRYINDEX, request.function.function_ref);
            const bool entity_scope = request.instance.entity_scope;
            if (entity_scope) lua_rawgeti(vm, LUA_REGISTRYINDEX, request.instance.table_ref);
            for (std::uint32_t i{}; i < frame.arg_count; ++i)
            {
                const auto* operation = i < request.function.argument_operations.size()
                    ? request.function.argument_operations[i] : nullptr;
                if (!pushArgument(vm, frame.args[i], operation))
                {
                    request.status = kMarshalFailure;
                    return 0;
                }
            }
            const bool same_binding = request.call.active && request.instance.active &&
                request.call.instance == &request.instance && request.call.function == &request.function &&
                request.instance.behavior == request.behavior &&
                (request.behavior != nullptr && request.behavior->hasInvocationAuthority()) == request.bound_authority;
            if (!same_binding || (request.bound_authority && !request.qualification.valid())) return 0;
            lua_call(vm, static_cast<int>(frame.arg_count) + entity_scope, static_cast<int>(frame.return_count));
            for (std::uint32_t i{}; i < frame.return_count; ++i)
            {
                if (!readReturn(vm, 2 + static_cast<int>(i), frame.returns[i]))
                {
                    request.status = -5;
                    return 0;
                }
            }
            // Converter-created to-be-closed values and errors stay inside this C boundary.
            lua_settop(vm, 1);
            request.status = 0;
            return 0;
        }

        static int invokeConvertedSync(void* opaque, lux_script_call_frame* frame) noexcept
        {
            if (!opaque || !frame) return kInvalidCall;
            auto& call = *static_cast<PreparedCall*>(opaque);
            const bool invalid_call = !call.active || !call.instance || !call.function;
            if (invalid_call) return kInvalidCall;
            auto& self = *call.instance->owner;
            const auto* behavior = call.instance->behavior;
            const bool bound_authority = behavior != nullptr && behavior->hasInvocationAuthority();
            const auto qualification = bound_authority ? behavior->captureInvocation() : ScriptInvocationValidity{};
            if (bound_authority && !qualification.valid()) return kInvalidCall;
            ExecutionScope execution{self, {self.main_thread, call.instance, nullptr, nullptr, nullptr}};
            if (!execution) return kExecutionDepthCapacity;
            auto* vm = self.main_thread;
            if (!lua_checkstack(vm, 3)) return kLuaFailure;
            const auto base = lua_gettop(vm);
            ConvertedSyncRequest request{call, *call.instance, *call.function, *frame, behavior,
                qualification, bound_authority};
            lua_pushcfunction(vm, &traceback);
            lua_pushcfunction(vm, &executeConvertedSync);
            lua_pushlightuserdata(vm, &request);
            const auto result = lua_pcall(vm, 1, 0, base + 1);
            lua_settop(vm, base);
            return result == LUA_OK ? request.status : kLuaFailure;
        }

'''
 return once(t,marker,block+marker)
edit(base+'lua/src/LuaScriptBackend.cpp',lua)
def timer(t):
 marker='namespace lux::simulation::script::detail\n{'
 helper='''namespace lux::simulation::script::detail
{
    namespace
    {
        // A double representation of INT64_MAX rounds up on MSVC. Use the exact
        // exclusive power-of-two limit and check the rounded value before casting.
        template<class Duration>
        [[nodiscard]] std::optional<Duration> checkedDuration(double seconds) noexcept
        {
            using Rep = typename Duration::rep;
            static_assert(std::is_integral_v<Rep> && std::is_signed_v<Rep>);
            const auto count = std::ceil(static_cast<long double>(seconds) * 1'000'000'000.0L);
            const auto exclusive_limit = std::ldexp(1.0L, std::numeric_limits<Rep>::digits);
            if (count >= exclusive_limit) return std::nullopt;
            return Duration{static_cast<Rep>(count)};
        }
    }
'''
 t=once(t,marker,helper)
 t=once(t,"        const long double requested = static_cast<long double>(duration) * 1'000'000'000.0L;\n        const auto maximum = static_cast<long double>(std::numeric_limits<SimulationDuration::rep>::max());\n        if (requested > maximum) return error(EScriptDelayStatus::DURATION_OVERFLOW);\n        const auto count = duration == 0.0 ? SimulationDuration::rep{} :\n            static_cast<SimulationDuration::rep>(std::ceil(requested));",'''        const auto converted = checkedDuration<SimulationDuration>(duration);
        if (!converted) return error(EScriptDelayStatus::DURATION_OVERFLOW);
        const auto count = converted->count();''')
 t=once(t,"        const long double requested = static_cast<long double>(duration) * 1'000'000'000.0L;\n        const auto maximum = static_cast<long double>(std::numeric_limits<std::chrono::nanoseconds::rep>::max());\n        if (requested > maximum)\n            return error(EScriptDelayStatus::DURATION_OVERFLOW);\n        return real_delay_.invoke(std::chrono::nanoseconds{static_cast<std::chrono::nanoseconds::rep>(\n            std::ceil(requested))}, std::move(completion));",'''        const auto converted = checkedDuration<std::chrono::nanoseconds>(duration);
        if (!converted) return error(EScriptDelayStatus::DURATION_OVERFLOW);
        return real_delay_.invoke(*converted, std::move(completion));''')
 return t
edit('engine/domain/simulation/builtin/script/src/ScriptTimers.cpp',timer)
edit(base+'core/include/lux/engine/simulation/scripting/ScriptRuntime.hpp',lambda t:once(t,'                if (size_ != 0U)\n                    std::memcpy(inline_.data(), data(), (std::min)(size_, size));','                if (spill_ != nullptr && size_ != 0U && size != 0U)\n                    std::memcpy(inline_.data(), spill_, (std::min)(size_, size));'))
print('fixed F01-F03 source')
