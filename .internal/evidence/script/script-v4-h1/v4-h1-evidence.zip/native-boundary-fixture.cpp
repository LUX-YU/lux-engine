#include <lux/engine/function/script/abi/lux_script_abi.h>
#include <cstdint>
#include <cstdlib>

namespace
{
    unsigned starts{}, resumes{}, destroys{};
    constexpr std::uint64_t id(const char* s)
    {
        std::uint64_t n{14695981039346656037ULL};
        while (*s) { n ^= static_cast<unsigned char>(*s++); n *= 1099511628211ULL; }
        return n;
    }
    int sync(void*, lux_script_call_frame*) { return 0; }
    int start(const lux_script_native_instance_context*, lux_script_call_frame*, const lux_script_step_host* host,
        void*, lux_script_step_outcome* outcome)
    {
        ++starts;
        const int mode = std::atoi(std::getenv("LUX_H1_BOUNDARY_CASE"));
        lux_script_async_token token{};
        if (mode == 1) return host->start_event_wait(host->context, 1U, &token);
        if (mode == 2) return host->start_event_wait(host->context, 0U, nullptr);
        if (mode == 3) return 73;
        if (mode == 4) { outcome->state = 255U; return 0; }
        if (mode == 5 || mode == 6)
        {
            outcome->state = LUX_SCRIPT_STEP_FAILED; outcome->status = mode == 5 ? 0 : -71; return 0;
        }
        if (mode != 7)
        {
            const int status = host->start_event_wait(host->context, 0U, &token);
            if (status) return status;
        }
        outcome->state = LUX_SCRIPT_STEP_SUSPENDED; outcome->waiting_on = token; return 0;
    }
    int resume(const lux_script_step_host*, void*, const lux_script_step_resume_packet* packet,
        lux_script_step_outcome* outcome)
    {
        ++resumes;
        if (packet->state != LUX_SCRIPT_RESUME_READY || !packet->has_value) return 74;
        if (*static_cast<const std::uint32_t*>(packet->value.data) != 29U) return 75;
        outcome->state = LUX_SCRIPT_STEP_COMPLETED; return 0;
    }
    void destroy(void*) { ++destroys; }
    constexpr lux_script_step_desc step{16U, 8U, 0x1234U, &start, &resume, &destroy};
    constexpr lux_script_function_desc function{"Step", 1U, nullptr, 0U, nullptr, 0U, &sync, &step};
    constexpr lux_script_event_wait_import_desc event{11U, 12U, 13U, 1U, 0U, {},
        {"lux.u32", id("lux.u32"), 4U, 4U, LUX_SCRIPT_VK_UINT32, LUX_SCRIPT_PASS_VALUE, {}}};
    constexpr lux_script_module_desc module{"h1_boundary", LUX_SCRIPT_ABI_VERSION, 0U, 0x2345U,
        8U, 8U, &function, 1U, 0U, nullptr, 0U, 0U, &event, 1U, 0U};
}
extern "C" LUX_SCRIPT_EXPORT const lux_script_module_desc* lux_script_get_module() { return &module; }
extern "C" LUX_SCRIPT_EXPORT unsigned lux_h1_count(unsigned which)
{ return which == 0 ? starts : which == 1 ? resumes : destroys; }
