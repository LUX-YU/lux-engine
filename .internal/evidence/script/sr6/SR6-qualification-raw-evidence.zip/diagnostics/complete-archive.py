"""Complete the new, unpublished SR6 archive with generated snapshots excluded by the shared collector filter."""
import hashlib,json,zipfile
from pathlib import Path
r=Path(__file__).resolve().parent
output=r.parent/'s5/source/.internal/evidence/script/sr6'
archive=output/'SR6-qualification-raw-evidence.zip'
index=json.loads((output/'raw-files.json').read_text())
known={v['path'] for v in index}
additions={}
for folder in ('incremental-final','probes','scale','record-costs'):
 base=r/folder
 for p in base.rglob('*'):
  if p.is_file() and p.suffix in ('.cpp','.hpp'):
   relative=p.relative_to(base)
   if 'CMakeFiles' not in relative.parts:
    additions['diagnostics/snapshots/'+folder+'/'+relative.as_posix()]=p
additions['diagnostics/complete-archive.py']=Path(__file__)
with zipfile.ZipFile(archive,'a',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,path in sorted(additions.items()):
  assert name not in known,name
  value=path.read_bytes();z.writestr(name,value)
  index.append({'path':name,'source':str(path),'size':len(value),'sha256':hashlib.sha256(value).hexdigest()})
index.sort(key=lambda v:v['path'])
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(index)
 for entry in index:
  value=z.read(entry['path']);assert len(value)==entry['size']
  assert hashlib.sha256(value).hexdigest()==entry['sha256']
 assert not any(Path(n).suffix.lower() in ('.exe','.dll','.obj','.lib','.pdb') for n in z.namelist())
(output/'raw-files.json').write_text(json.dumps(index,indent=2))
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
(output/'SHA256SUMS').write_text(digest+'  '+archive.name+'\n')
result={'files':len(index),'added_source_and_generated_snapshots':len(additions),'bytes':archive.stat().st_size,'sha256':digest}
(r/'package-final.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
