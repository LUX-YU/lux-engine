// Reduced C++20 control-flow probe, NOT the engine or its CTest suite.
// Mirrors the early-return/lambda-capture shape in PreparedMaterialReload::prepare
// and EditGate::withRead at commit 7ead91c5f111c5edfd7d9f156e23e3f00af4a8eb.
// CodeLease tracks lifetime; no DLL is loaded or unloaded by this program.
#include <iostream>
#include <memory>
#include <string>
#include <utility>
#include <vector>

struct Gate {
    enum class State { Available, Reading, Closing } state{State::Available};
    template<class F> bool withRead(F&& fn) {
        if (state != State::Available) return false;
        state = State::Reading;
        struct Scope { Gate& g; ~Scope() { g.state = State::Available; } } scope{*this};
        return std::forward<F>(fn)();
    }
    bool edit() const { return state == State::Available; }
};
struct Session { Gate gate; bool bound{}; int author_value{}; };
struct Observation { int destructions{}; bool nested_edit{}; bool expired_in_destructor{}; };
struct Node {
    Session& session;
    Observation& out;
    std::weak_ptr<const void> code;
    ~Node() {
        ++out.destructions;
        out.expired_in_destructor = out.expired_in_destructor || code.expired();
        if (session.gate.edit()) {
            out.nested_edit = true;
            ++session.author_value;
        }
    }
};
struct Source { std::vector<std::unique_ptr<Node>> nodes; };
struct Lease { std::shared_ptr<const void> code; };

bool original_shape(Session& session, Source source, Lease code) {
    (void)source;
    (void)code;
    return session.gate.withRead([&]() {
        if (!session.bound) return false;
        // Actual successful create path omitted: this probe tests rejection only.
        return true;
    });
}

bool ownership_scope_example(Session& session, Source source, Lease code) {
    // Demonstration only. No changes have been made to the GitHub repository.
    struct Input { Lease code; Source source; } input{std::move(code), std::move(source)};
    return session.gate.withRead([&]() {
        auto scoped_input = std::move(input);
        if (!session.bound) return false;
        return true;
    });
}
using Function = bool(*)(Session&, Source, Lease);
void run(const char* version, const char* scenario, Function fn, bool busy, bool keep_external) {
    Session session;
    session.gate.state = busy ? Gate::State::Closing : Gate::State::Available;
    Observation out;
    auto external = std::make_shared<int>(1);
    Lease lease{external};
    Source input;
    input.nodes.emplace_back(new Node{session, out, external});
    if (!keep_external) external.reset();
    const bool accepted = fn(session, std::move(input), std::move(lease));
    std::cout << "{\"version\":\"" << version << "\",\"scenario\":\"" << scenario
              << "\",\"accepted\":" << accepted << ",\"destructions\":" << out.destructions
              << ",\"nested_edit\":" << out.nested_edit << ",\"author_value\":" << session.author_value
              << ",\"expired_in_destructor\":" << out.expired_in_destructor << "}\n";
}
int main() {
    run("original_shape", "unbound_external_kept", original_shape, false, true);
    run("original_shape", "unbound_last_lease", original_shape, false, false);
    run("original_shape", "busy_last_lease", original_shape, true, false);
    run("illustrative_ownership_scope", "unbound_external_kept", ownership_scope_example, false, true);
    run("illustrative_ownership_scope", "unbound_last_lease", ownership_scope_example, false, false);
    run("illustrative_ownership_scope", "busy_last_lease", ownership_scope_example, true, false);
}
