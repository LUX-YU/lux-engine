from pathlib import Path
import subprocess
r=Path.cwd();s=r/'source'
p=s/'engine/domain/simulation/scripting/native_lua_tasks/benchmark/main.cpp'
t=p.read_text();needle='        const auto b = backend->stats();\n'
assert t.count(needle)==1
t=t.replace(needle,'        std::printf("WAIT_MEMORY phase=%s event_pages=%zu event_claims=%zu ready=%zu\\n",\n                    phase, core.event_page_storage_bytes, core.event_claim_storage_bytes,\n                    core.resume_storage_bytes);\n'+needle)
p.write_text(t)
for name in ['final-qualify.ps1','installed.ps1','benchmark.ps1','save-images.py','costs.py','resources.py','profile.py','profile-target.py','machine.py','class-layout.py','class-layout.ps1','new-incremental.py','new-incremental.ps1','relocated.ps1']:
 p=r/('next-'+name);t=p.read_text(encoding='utf-8-sig').replace('next-','local-')
 if name in ['costs.py','resources.py','save-images.py']:
  for old,new in [('C-common','D-common'),('C-flow','D-flow'),("'C'","'D'"),('D-common','E-common'),('D-flow','E-flow'),("'D'","'E'")]:
   pass
  # simultaneous image name mapping, do not cascade
  import re
  t=re.sub(r"(['\"])([CD])(-common|-flow)?\1",lambda m:m[1]+{'C':'D','D':'E'}[m[2]]+(m[3] or '')+m[1],t)
 if name=='costs.py':
  t=t.replace('21d89a83a8dc66c636550df2e0899030583791c6','7f20191692d3f5e1037a14273a61fc99eef95714')
 if name=='machine.py':t=t.replace("['D']","['E']")
 (r/('local-'+name)).write_text(t)
