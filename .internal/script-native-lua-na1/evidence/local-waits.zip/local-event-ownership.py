from pathlib import Path
s=Path(r'E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1/source')
p=s/'engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptEventWaits.hpp'
t=p.read_text().replace('#include <entt/container/dense_map.hpp>','#include <entt/container/dense_map.hpp>\n#include <array>')
t=t.replace('        const ScriptWaitIdentity* wait_{};', '        ScriptAwaitableId awaitable_;').replace('        ScriptEventWaitLink* instance_previous_{};\n        ScriptEventWaitLink* instance_next_{};\n','')
a=t.index('        struct InstanceIndex final');b=t.index('        [[nodiscard]] EventRouteHead* findRoute',a)
t=t[:a]+'''        using EventRouteIndex = entt::dense_map<EventRouteKey, EventRouteHead, EventRouteKeyHash>;

'''+t[b:]
t=t.replace('claimed_.push_back(link.wait_->id);', 'claimed_.push_back(link.awaitable_);')
t=t.replace(': owner_(std::exchange(other.owner_, nullptr)), instance_(other.instance_),\n                  endpoint_(other.endpoint_), target_(other.target_) {}', ': owner_(std::exchange(other.owner_, nullptr)), endpoint_(other.endpoint_), target_(other.target_) {}')
t=t.replace('Admission(ScriptEventWaits& owner, InstanceIndex& instance, std::uint32_t endpoint,', 'Admission(ScriptEventWaits& owner, std::uint32_t endpoint,').replace(': owner_(&owner), instance_(&instance), endpoint_(endpoint), target_(target) {}', ': owner_(&owner), endpoint_(endpoint), target_(target) {}').replace('            InstanceIndex* instance_{};\n','')
a=t.index('        void prepare(');b=t.index('        [[nodiscard]] lux::cxx::expected<Admission',a)
t=t[:a]+'''        void prepare(std::size_t capacity, std::size_t endpoint_count);
'''+t[b:]
t=t.replace('ScriptInstanceId instance, std::uint32_t endpoint, ecs::Entity target) noexcept\n        {\n            auto* owner = instanceRecord(instance);\n            if (!owner) return lux::cxx::unexpected(EScriptEventWaitError::INVALID_INSTANCE);', 'std::uint32_t endpoint, ecs::Entity target) noexcept\n        {')
t=t.replace('            if (sequence_ == std::numeric_limits<std::uint64_t>::max())\n                return lux::cxx::unexpected(EScriptEventWaitError::SEQUENCE_EXHAUSTED);\n','').replace('return Admission{*this, *owner, endpoint, target};','return Admission{*this, endpoint, target};')
t=t.replace('            auto& owner = *admission.instance_;\n','').replace('            ++sequence_;\n            link.wait_ = &wait;', '            link.awaitable_ = wait.id;')
a=t.index('            link.instance_next_ = owner.first;');b=t.index('            high_water_',a);t=t[:a]+t[b:]
a=t.index('        [[nodiscard]] std::optional<ScriptSourceCancellation> cancel(Link& link)');b=t.index('        [[nodiscard]] std::size_t claimedCount()',a)
t=t[:a]+'''        void cancel(Link& link) noexcept
        {
            if (link.state_ == Link::EState::DETACHED) return;
            if (link.state_ == Link::EState::ACTIVE) unlinkRoute(link);
            else --active_claimed_;
            link.state_ = Link::EState::DETACHED;
            --active_;
        }
        void cancelForRetirement(Link& link) noexcept
        {
            ++cleanup_visits_;
            cancel(link);
        }
'''+t[b:]
t=t.replace('        std::vector<InstanceIndex> instances_;\n','').replace('        std::uint64_t sequence_{};\n','')
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/builtin/script/src/ScriptEventWaits.cpp'
t=p.read_text().replace('std::size_t capacity, std::size_t instance_capacity, std::size_t endpoint_count','std::size_t capacity, std::size_t endpoint_count').replace('        instances_.resize(instance_capacity);\n','').replace('        instances_.clear();\n','')
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptExecution.hpp'
t=p.read_text().replace('event_owner_.reserve(instance, endpoint_slot, target)', 'event_owner_.reserve(endpoint_slot, target)')
t=t.replace('            while (const auto cancelled = event_owner_.cancelNext(instance))\n                detachSource(*cancelled);', '''            // Event relations live in these stable result records. Preserve Event
            // cancellation before Timer cleanup, without a second instance index
            // or a duplicate ownership chain on every successful wait.
            for (auto* wait = first_awaitable; wait; wait = wait->instance_next)
            {
                if (wait->source.kind == EScriptWaitSource::EVENT)
                {
                    event_owner_.cancelForRetirement(wait->event_link);
                    wait->source = {};
                }
            }''')
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/builtin/script/src/ScriptSystem.cpp'
t=p.read_text().replace('                event_owner.beginInstance(mount.instance);\n','').replace('limits.event_wait_capacity, state->instance_owner.identityCapacity(), events.size()', 'limits.event_wait_capacity, events.size()')
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/scripting/core/include/lux/engine/simulation/scripting/ScriptRuntime.hpp'
t=p.read_text().replace('        SEQUENCE_EXHAUSTED,\n        ALLOCATION_FAILURE,','        // Value 9 was the removed per-wait registration sequence limit.\n        ALLOCATION_FAILURE = 10,')
p.write_text(t,encoding='utf-8')
