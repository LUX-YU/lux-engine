$ErrorActionPreference='Stop'
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5c'
$s='E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source'
git -C $s diff --binary | Set-Content "$r/trial.patch"
cmake --build E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/d --target all -j 4 -- -k 0 *> "$r/trial-all.log"
if ($LASTEXITCODE) { throw 'trial all failed' }
ctest --test-dir E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/d -R 'lua_value|simulation_script_lua_test|collision_event' --output-on-failure *> "$r/trial-narrow.log"
if ($LASTEXITCODE) { throw 'trial narrow failed' }
& "$s/cmake/RunScriptV3Measurements.ps1" -BaselineBin "$r/q/d/bin" -FinalBin 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/d/bin' -BaselineToolBin "$r/q/t/bin" -FinalToolBin "$r/q/t/bin" -LuaArtifact "$r/q/t/engine/toolchain/lua/lua_runtime_benchmark_fixture.lxsa" -PhysicsLuaArtifact "$r/q/t/engine/toolchain/physics2d/physics2d_lua_fixture.lxsa" -PhysicsFlowArtifact "$r/q/t/engine/toolchain/physics2d/physics2d_flowforge_fixture.lxsa" -OutputRoot "$r/scalar-trial" -Only @('lua-ability-10k') -Pairs 5 -ScalarFrames 3000
$dep='E:/SyncForder/CodeRepos/install/q2/c;E:/SyncForder/CodeRepos/install/q2/toolset;E:/SyncForder/CodeRepos/install/RelWithDebInfo'
foreach($side in @('H','C0')) {
 $p=if($side -eq 'H') {'E:/SyncForder/CodeRepos/install/sr4-move/d'} else {'E:/SyncForder/CodeRepos/install/s5/q/d'}
 $mode=if($side -eq 'H') {'OFF'}else{'ON'}
 New-Item -ItemType Directory -Force -Path "$r/record-trial/$side" | Out-Null
 cmake -S "$s/cmake/installed-consumers/script-lua-value-costs" -B "$r/record-trial/$side/build" -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo -DCMAKE_EXPORT_COMPILE_COMMANDS=ON "-DSR5_VALUES=$mode" -DCMAKE_TOOLCHAIN_FILE=D:/Development/vcpkg/scripts/buildsystems/vcpkg.cmake "-DCMAKE_PREFIX_PATH=$p;$dep" -DCMAKE_FIND_USE_PACKAGE_REGISTRY=OFF -DCMAKE_FIND_USE_SYSTEM_PACKAGE_REGISTRY=OFF *> "$r/record-trial/$side/configure.log"
 if($LASTEXITCODE){throw 'record configure failed'}
 cmake --build "$r/record-trial/$side/build" --target all -j 4 -- -k 0 *> "$r/record-trial/$side/all.log"
 if($LASTEXITCODE){throw 'record all failed'}
 cmake --build "$r/record-trial/$side/build" --target all -j 4 -- -k 0 *> "$r/record-trial/$side/noop.log"
 if($LASTEXITCODE){throw 'record second all failed'}
}
$oldPath=$env:PATH
$variants=@{
 H=@{exe="$r/record-trial/H/build/script_lua_value_cost.exe";bin='E:/SyncForder/CodeRepos/install/sr4-move/d/bin';mode='timing'}
 protected=@{exe="$r/record-trial/C0/build/script_lua_value_cost.exe";bin='E:/SyncForder/CodeRepos/install/s5/q/d/bin';mode='protected'}
 C0=@{exe="$r/record-trial/C0/build/script_lua_value_cost.exe";bin='E:/SyncForder/CodeRepos/install/s5/q/d/bin';mode='timing'}
 trial=@{exe="$r/record-trial/C0/build/script_lua_value_cost.exe";bin='E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/d/bin';mode='timing'}
}
$records=@()
foreach($i in 0..4){
 $order=if($i % 2){@('trial','C0','protected','H')}else{@('H','protected','C0','trial')}
 foreach($side in $order){
  $v=$variants[$side];$env:PATH="$($v.bin);D:/Development/vcpkg/installed/x64-windows/bin;$oldPath"
  & $v.exe $v.mode 1000000 *> "$r/record-trial/$side-$i.log"
  if($LASTEXITCODE){throw "record $side failed"}
  $records+=@{variant=$side;pair=$i;exe_sha256=(Get-FileHash $v.exe).Hash;bin=$v.bin;mode=$v.mode;exit=0}
 }
}
foreach($side in @('H','protected','C0','trial')){
 $v=$variants[$side];$env:PATH="$($v.bin);D:/Development/vcpkg/installed/x64-windows/bin;$oldPath"
 $mode=if($side -eq 'protected'){'protected-diagnostics'}else{'diagnostics'}
 & $v.exe $mode 10000 *> "$r/record-trial/$side-diagnostics.log"
 if($LASTEXITCODE){throw "diagnostic $side failed"}
}
$v=$variants['trial'];$env:PATH="$($v.bin);D:/Development/vcpkg/installed/x64-windows/bin;$oldPath"
& $v.exe protected-errors *> "$r/record-trial/protected-errors.log"
if($LASTEXITCODE){throw 'protected errors failed'}
$records | ConvertTo-Json -Depth 5 | Set-Content "$r/record-trial/runs.json"
