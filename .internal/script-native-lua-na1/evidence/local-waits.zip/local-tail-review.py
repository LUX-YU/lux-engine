from pathlib import Path
import json,statistics
r=Path.cwd();runs=json.loads((r/'local-costs/runs.json').read_text())
for leg in ['P1','P4','S1','S3','P6']:
 for side in ['A','B']:
  rows=[x for x in runs if x['leg']==leg and x['side']==side];print(leg,side,{k:statistics.median(x[k] for x in rows) for k in ['p50_batch_ns','p95_batch_ns','p99_batch_ns']}, 'error', [x['errors'] for x in rows])
print('incremental',len(json.loads((r/'local-value-incremental/probes.json').read_text(encoding='utf-8-sig'))))
