from pathlib import Path
import csv,json
r=Path(__file__).parent;output=[]
for side in ['A','B']:
 p=r/'local-profiles'/('P4-'+side)
 raw=list(csv.reader((p/'summary.csv').open()));cpu=float(next(x[2] for x in raw if len(x)>2 and x[1]=='CPU Time'))
 raw_lines=(p/'top-down.csv').read_text().splitlines();header=next(csv.reader([raw_lines[0]],skipinitialspace=True));tree=[]
 for line in raw_lines[1:]:
  if not line.strip():continue
  values=next(csv.reader([line],skipinitialspace=True));assert len(values)==len(header),line
  row=dict(zip(header,values));row['depth']=len(line)-len(line.lstrip());tree.append(row)
 stack=[];groups={};details={}
 for row in tree:
  label=row['Function Stack'];depth=row['depth'];stack=stack[:depth];stack.append(row['Function (Full)'])
  seconds=float(row['CPU Time:Self']);path=' / '.join(stack)
  if 'ScriptCoroutineContext::wait' in path or 'ScriptExecution::waitEvent' in path:group='next_wait_registration'
  elif any(x in path for x in ['ScriptExecution::takeAwaitable','promise_type::prepareResume']):group='take_previous_result'
  elif any(x in path for x in ['ScriptCoroutineContext::invokeSyncStep','ScriptCoroutineContext::invokeResolvedSyncStep']):group='synchronous_lua_step'
  elif 'dispatchEvent' in path or 'ScriptEventWaits::claim' in path:group='event_delivery'
  elif 'ScriptExecution::resumeOne' in path:group='remaining_resume'
  else:group='other'
  groups[group]=groups.get(group,0)+seconds
  if seconds:details.setdefault(group,[]).append({'symbol':row['Function (Full)'],'self_seconds':seconds,'path':path})
 total=sum(groups.values());assert abs(total-cpu)<.002,(total,cpu)
 output.append({'side':side,'cpu_seconds':cpu,'partition_basis':'Exclusive sampled self time assigned by actual ancestor paths, not sum of inclusive parents','groups':{k:{'seconds':v,'percent':v/cpu*100,'ns_per_wait':v*1e9/20480000,'top_self':sorted(details.get(k,[]),key=lambda x:-x['self_seconds'])[:8]} for k,v in groups.items()}})
(r/'local-analysis/phases.json').write_text(json.dumps(output,indent=2));print([(x['side'],{k:round(v['percent'],2) for k,v in x['groups'].items()}) for x in output])
