from pathlib import Path
import json,subprocess,hashlib
r=Path.cwd();old=json.loads((r/'next-baseline.json').read_text())
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
for x in old['dependency_files']:assert sha(x['path'])==x['sha256'],x['path']
for x in old['protected']:
 assert git(x['repo'],'rev-parse','HEAD')==x['head']
 assert git(x['repo'],'status','--porcelain')==x['status']
 for p in x['files']:assert sha(Path(x['repo'])/p['path'])==p['sha256'],p
base=r/'local-baseline.json';data=json.loads(base.read_text());data.update(protected=old['protected'],dependency_files=old['dependency_files']);base.write_text(json.dumps(data,indent=2))
print('PROTECTED_AND_INSTALLED_DEPENDENCIES_MATCH',len(old['dependency_files']))
