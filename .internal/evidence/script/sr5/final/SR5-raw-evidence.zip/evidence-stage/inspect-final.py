import hashlib,json,subprocess
from pathlib import Path
r=Path('..').resolve()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((r/'b8-qualification/binaries.json').read_text())
changes=[]
for x in old:
 p=r/'q'/x['profile']/'bin'/x['file']
 if p.exists() and digest(p)!=x['sha256']:changes.append({'profile':x['profile'],'file':x['file'],'before':x['sha256'],'after':digest(p)})
(r/'diagnostics/final-binary-changes.json').write_text(json.dumps(changes,indent=2))
print(json.dumps([x for x in changes if x['profile']=='d'],indent=2))
start=json.loads((r/'start-identity.json').read_text());repo=Path('E:/SyncForder/CodeRepos/lux-engine')
checks={x['path']:digest(repo/x['path'])==x['sha256'] for x in start['main_files']}
for name,v in start['dependencies'].items():
 p=repo.parent/name
 checks[name]=subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip()==v['head'] and subprocess.check_output(['git','-C',str(p),'status','--porcelain'],text=True).strip()==v['status']
checks['main_head']=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()==start['main_head']
assert all(checks.values()),checks
(r/'protected-state-final.json').write_text(json.dumps(checks,indent=2)); print('protected state preserved')
