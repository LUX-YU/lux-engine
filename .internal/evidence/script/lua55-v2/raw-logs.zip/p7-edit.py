from pathlib import Path
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source')
p=r/'engine/domain/simulation/scripting/lua/src/LuaScriptBackend.cpp'
s=p.read_text()
def replace(a,b):
    global s
    assert s.count(a)==1, (a[:100],s.count(a))
    s=s.replace(a,b)
replace('struct Prototype final\n        {','struct Prototype final\n        {\n            lux::script::ScriptArtifactContentId content;')
replace('struct FunctionKey final\n        {\n            lux::asset::AssetId asset;', 'struct FunctionKey final\n        {\n            lux::script::ScriptArtifactContentId content;')
replace('const auto asset_hash = std::hash<lux::asset::AssetId>{}(key.asset);','const auto asset_hash = lux::script::ScriptArtifactContentId::Hash{}(key.content);')
replace('std::unordered_map<lux::asset::AssetId, Prototype> prototypes;', '''using PrototypeMap = std::unordered_map<
            lux::script::ScriptArtifactContentId, Prototype, lux::script::ScriptArtifactContentId::Hash
        >;
        PrototypeMap prototypes;''')
replace('const FunctionKey key{instance->asset, function.symbol_id};','const FunctionKey key{instance->prototype->content, function.symbol_id};')
a=s.index('        [[nodiscard]] bool appendArtifactAbilities(')
b=s.index('        // All four upvalues',a)
s=s[:a]+'''        // Only C++ allocation here. The subsequent protected Lua render reads this frozen layout.
        [[nodiscard]] bool prepareArtifactLayout(
            Prototype& prototype, const lux::script::ScriptArtifact& artifact
        ) noexcept
        {
            try
            {
                for (const auto& requirement : artifact.description().api_requirements)
                {
                    std::size_t ordinal{};
                    while (ordinal < ability_methods.size())
                    {
                        const auto* ability = ability_methods[ordinal].ability;
                        if (ability->id.hash() == requirement.contract.hash() &&
                            ability->id.name() == requirement.contract.name() &&
                            ability->schema_hash == requirement.expected_schema_hash) break;
                        ++ordinal;
                    }
                    if (ordinal == ability_methods.size()) return false;
                    const auto* ability = ability_methods[ordinal].ability;
                    while (ordinal < ability_methods.size() && ability_methods[ordinal].ability == ability)
                        prototype.ability_ordinals.push_back(static_cast<std::uint32_t>(ordinal++));
                }
                for (const auto& requirement : artifact.description().event_requirements)
                {
                    const auto found = std::ranges::find(event_sources, requirement);
                    if (found == event_sources.end()) return false;
                    prototype.event_ordinals.push_back(static_cast<std::uint32_t>(found - event_sources.begin()));
                }
                prototype.ability_class = prepared_abilities.select(prototype.ability_ordinals.size());
                prototype.event_class = prepared_events.select(prototype.event_ordinals.size());
                return true;
            }
            catch (const std::bad_alloc&)
            {
                return false;
            }
        }

        void appendArtifactAbilities(const Prototype& prototype, int lux_index) noexcept
        {
            std::size_t local_slot{};
            while (local_slot < prototype.ability_ordinals.size())
            {
                const auto* ability = ability_methods[prototype.ability_ordinals[local_slot]].ability;
                lua_createtable(state, 0, static_cast<int>(ability->methods.size()));
                const auto ability_index = lua_gettop(state);
                while (local_slot < prototype.ability_ordinals.size())
                {
                    const auto& entry = ability_methods[prototype.ability_ordinals[local_slot]];
                    if (entry.ability != ability) break;
                    lua_pushlstring(state, entry.method->name.data(), entry.method->name.size());
                    lua_pushlightuserdata(state, this);
                    lua_pushinteger(state, static_cast<lua_Integer>(local_slot));
                    lua_pushlightuserdata(state, this);
                    lua_rawget(state, lux_index);
                    pushPrimitive(entry.entry);
                    lua_rawset(state, ability_index);
                    ++local_slot;
                }
                lua_pushlstring(state, ability->name.data(), ability->name.size());
                lua_pushvalue(state, ability_index);
                lua_rawset(state, lux_index);
                lua_pop(state, 1);
            }
        }

'''+s[b:]
# Keep the established grouping/order; remove all C++ container writes from the Lua callback.
replace('[[nodiscard]] bool appendArtifactEvents(', 'void appendArtifactEvents(')
replace('''            if (artifact.description().event_requirements.empty())
                return true;''','''            if (artifact.description().event_requirements.empty()) return;''')
replace('''            int system_index{};
            for (const auto& requirement : artifact.description().event_requirements)
            {
                const auto found = std::ranges::find(event_sources, requirement);
                if (found == event_sources.end())
                    return false;''','''            int system_index{};
            std::size_t local_slot{};
            for (const auto& requirement : artifact.description().event_requirements)
            {''')
replace('''                const auto local_slot = prototype.event_ordinals.size();
                if (local_slot > (std::numeric_limits<lua_Integer>::max)())
                    return false;
''','')
replace('''                lua_settable(state, system_index);
                prototype.event_ordinals.push_back(static_cast<std::uint32_t>(found - event_sources.begin()));''','''                lua_settable(state, system_index);
                ++local_slot;''')
replace('''            prototype.event_class = prepared_events.select(prototype.event_ordinals.size());
            return true;
        }

        [[nodiscard]] bool pushArtifactEnvironment(''','''        }

        void pushArtifactEnvironment(''')
replace('''            if (!appendArtifactAbilities(prototype, artifact, lux_index) ||
                !appendArtifactEvents(prototype, artifact, lux_index))
            {
                lua_settop(state, environment_index - 1);
                return false;
            }
            lua_setfield(state, environment_index, "lux");
            return true;''','''            appendArtifactAbilities(prototype, lux_index);
            appendArtifactEvents(prototype, artifact, lux_index);
            lua_setfield(state, environment_index, "lux");''')
a=s.index('        [[nodiscard]] Prototype* prototypeFor(')
b=s.index('        [[nodiscard]] bool supportedType(',a)
s=s[:a]+'''        // No owning C++ objects may be constructed in callbacks passed here.
        [[nodiscard]] int runCold(lua_CFunction entry, void* request) noexcept
        {
            if (!lua_checkstack(state, 3)) return LUA_ERRMEM;
            const auto base = lua_gettop(state);
            lua_pushcfunction(state, entry);
            lua_pushlightuserdata(state, request);
            const auto status = lua_pcall(state, 1, 0, 0);
            lua_settop(state, base);
            return status;
        }

        struct PrototypeRequest final
        {
            State* owner;
            Prototype* prototype;
            const lux::script::ScriptArtifact* artifact;
            const lux::rdesc::LuaSourceScript* body;
            bool complete{};
        };

        static int loadPrototype(lua_State* vm)
        {
            auto& request = *static_cast<PrototypeRequest*>(lua_touserdata(vm, 1));
            auto& prototype = *request.prototype;
            const auto& artifact = *request.artifact;
            request.owner->pushArtifactEnvironment(prototype, artifact);
            const auto environment_index = lua_gettop(vm);
            if (luaL_loadbufferx(vm, reinterpret_cast<const char*>(artifact.payload().data()),
                    artifact.payload().size(), artifact.description().module_name.c_str(), "t") != LUA_OK)
                return lua_error(vm);
            if (!lux::script::lua::detail::setLuaChunkEnvironment(vm, -1, environment_index)) return 0;
            lua_call(vm, 0, 1);
            if (!lua_istable(vm, -1))
            {
                lua_pop(vm, 1);
                lua_getfield(vm, environment_index, request.body->entry.c_str());
            }
            if (!lua_istable(vm, -1)) return 0;
            prototype.table_ref = luaL_ref(vm, LUA_REGISTRYINDEX);
            lua_pushvalue(vm, environment_index);
            prototype.environment_ref = luaL_ref(vm, LUA_REGISTRYINDEX);
            request.complete = true;
            return 0;
        }

        void releasePrototype(const Prototype& prototype) noexcept
        {
            if (prototype.table_ref != LUA_NOREF) luaL_unref(state, LUA_REGISTRYINDEX, prototype.table_ref);
            if (prototype.environment_ref != LUA_NOREF)
                luaL_unref(state, LUA_REGISTRYINDEX, prototype.environment_ref);
        }

        [[nodiscard]] Prototype* prototypeFor(const lux::script::ScriptArtifact& artifact) noexcept
        {
            const auto content = artifact.contentIdentity();
            const auto found = prototypes.find(content);
            if (found != prototypes.end()) return std::addressof(found->second);
            if (content.isNull() || artifact.payload().empty()) return nullptr;
            const auto* body = std::get_if<lux::rdesc::LuaSourceScript>(std::addressof(artifact.description().body));
            if (!body) return nullptr;
            Prototype prototype;
            prototype.content = content;
            if (!prepareArtifactLayout(prototype, artifact)) return nullptr;
            PrototypeRequest request{this, &prototype, &artifact, body};
            if (runCold(&loadPrototype, &request) != LUA_OK || !request.complete)
            {
                releasePrototype(prototype);
                return nullptr;
            }
            try
            {
                const auto inserted = prototypes.emplace(content, std::move(prototype));
                if (inserted.second) return std::addressof(inserted.first->second);
            }
            catch (const std::bad_alloc&)
            {
            }
            releasePrototype(prototype);
            return nullptr;
        }

'''+s[b:]
replace('self.prototypeFor(context, artifact)', 'self.prototypeFor(artifact)')
# Self table creation: same Lua operations/order inside one C callback; publish only after protected success.
a=s.index('            lua_createtable(self.state, 0, instance->entity_scope ? 4 : 0);')
b=s.index('            result.value = instance;',a)
body=s[a:b].replace('self.state','vm').replace('prototype->table_ref','instance->prototype->table_ref').replace('context.behavior','instance->behavior').replace('std::addressof(self)','instance->owner')
s=s[:a]+'''            if (self.runCold(&createSelf, instance) != LUA_OK)
            {
                // Nothing was published to user code; the failed Lua stack owns any partial userdata.
                self.prepared_events.release(instance->prepared_events);
                self.prepared_abilities.release(instance->prepared_abilities);
                *instance = {};
                self.free_instances.push_back(instance_slot);
                return EScriptBackendResult::ALLOCATION_FAILURE;
            }
'''+s[b:]
insert='''        static int createSelf(lua_State* vm)
        {
            auto* instance = static_cast<Instance*>(lua_touserdata(vm, 1));
'''+body+'''            return 0;
        }

        struct FunctionRequest final
        {
            int table_ref;
            const char* name;
            int function_ref{LUA_NOREF};
        };

        static int rootFunction(lua_State* vm)
        {
            auto& request = *static_cast<FunctionRequest*>(lua_touserdata(vm, 1));
            lua_rawgeti(vm, LUA_REGISTRYINDEX, request.table_ref);
            lua_getfield(vm, -1, request.name);
            if (lua_isfunction(vm, -1)) request.function_ref = luaL_ref(vm, LUA_REGISTRYINDEX);
            return 0;
        }

'''
idx=s.index('        static EScriptBackendResult createInstance(')
s=s[:idx]+insert+s[idx:]
a=s.index('                const auto prototype = self.prototypes.find(instance->asset);')
b=s.index('                try\n',a)
s=s[:a]+'''                FunctionRequest request{instance->prototype->table_ref, function.name.c_str()};
                const auto status = self.runCold(&rootFunction, &request);
                if (status != LUA_OK || request.function_ref == LUA_NOREF)
                    return status == LUA_ERRMEM ? EScriptBackendResult::ALLOCATION_FAILURE :
                        EScriptBackendResult::CONSTRUCTION_FAILURE;
                const auto function_ref = request.function_ref;
'''+s[b:]
p.write_text(s)
