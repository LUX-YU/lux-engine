from pathlib import Path
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source')
p=r/'modules/function/script/lua/src/LuaBoundary.c';t=p.read_text().replace('        return lua_yieldk(state, 0, (lua_KContext)base, finishWait);','''#if defined(LUX_LUA55_LEAF_YIELD_REVISION)
        return luxlua_yieldleaf(state, (lua_KContext)base, finishWait);
#else
        return lua_yieldk(state, 0, (lua_KContext)base, finishWait);
#endif''');p.write_text(t)
p=r/'modules/function/script/lua/pinclude/lux/engine/function/script/lua/LuaAllocationCache.hpp';t=p.read_text().replace('224U, 512U','256U, 512U').replace('216 (thread)','216/240 (official/patched thread)');p.write_text(t)
p=r/'engine/domain/simulation/scripting/lua/include/lux/engine/simulation/scripting/lua/LuaScriptBackend.hpp';t=p.read_text().replace('        std::size_t cached_prototypes{};','''        std::size_t cached_prototypes{};
        // Counters include released threads only; no per-snapshot scan of live continuations.
        bool leaf_yield_available{};
        std::uint64_t leaf_return_yields{}, standard_leaf_yields{};''');p.write_text(t)
p=r/'engine/domain/simulation/scripting/lua/src/LuaScriptBackend.cpp';t=p.read_text();t=t.replace('            ++owner->vm_coroutine_releases;','''            ++owner->vm_coroutine_releases;
#if defined(LUX_LUA55_LEAF_YIELD_REVISION)
            unsigned long long fast{}, fallback{};
            luxlua_leafstats(continuation.thread, &fast, &fallback);
            owner->leaf_return_yields += fast;
            owner->standard_leaf_yields += fallback;
#endif''',1); t=t.replace('        bool vm_configured{};','''        bool vm_configured{};
#if defined(LUX_LUA55_LEAF_YIELD_REVISION)
        static constexpr bool leaf_yield_available = true;
#else
        static constexpr bool leaf_yield_available = false;
#endif
        std::uint64_t leaf_return_yields{}, standard_leaf_yields{};'''); t=t.replace('            state_->prototypes.size()','            state_->prototypes.size(),\n            State::leaf_yield_available, state_->leaf_return_yields, state_->standard_leaf_yields');p.write_text(t)
# Observe a real generated Event->resume->result->provider path, counters outside timing.
p=r/'engine/domain/simulation/scripting/lua/test/lua_value_runtime_test.cpp';t=p.read_text();a=t.index('int resumeAuthorityCase') if 'int resumeAuthorityCase' in t else t.index('resumeAuthorityCase('); pos=t.index('return 0;',a);t=t[:pos]+'''const auto leaf_stats = backend->stats();
    std::printf("ENGINE_LEAF,available=%d,fast=%llu,standard=%llu\\n", leaf_stats.leaf_yield_available,
        leaf_stats.leaf_return_yields, leaf_stats.standard_leaf_yields);
    if (leaf_stats.leaf_yield_available) assert(leaf_stats.leaf_return_yields == 1U);
    '''+t[pos:];p.write_text(t)
# Additional VM protocol coverage: alternating threads, preserved identity, nonyieldable error, recovery, fresh state.
p=r/'cmake/dependencies/lua55/leaf_contract.c';t=p.read_text();t=t.replace('static void run(','''static int nonyieldable(lua_State* L) { lua_getglobal(L,"wait");lua_call(L,0,0);return 0; }
static void run(''');t=t.replace('    lua_close(L);puts(','''    lua_pushcfunction(L,nonyieldable);lua_setglobal(L,"nonyieldable");
    CHECK(luaL_dostring(L,"local ok,e=pcall(nonyieldable);assert(not ok and e:find('yield')); local saved={} local function f() local me=coroutine.running();saved[#saved+1]=me;for i=1,3 do local x=wait();assert(x==42 and coroutine.running()==me) end return 42 end local a,b=coroutine.create(f),coroutine.create(f);assert(a~=b);for i=0,3 do local ok,x=coroutine.resume(a,42);assert(ok);ok,x=coroutine.resume(b,42);assert(ok) end assert(saved[1]==a and saved[2]==b and coroutine.status(a)=='dead' and coroutine.status(b)=='dead');local c=coroutine.create(f);assert(c~=a and c~=b);local ok=coroutine.resume(c);assert(ok);assert(coroutine.close(c));local q=coroutine.create(function() local x=wait();local ok=pcall(function() error('caught after') end);assert(not ok);return 42 end);assert(coroutine.resume(q));local ok,x=coroutine.resume(q,42);assert(ok and x==42)")==LUA_OK);
    puts("LEAF_EXTRA,alternating_threads=2,waits_each=3,identity_preserved=1,nonyieldable_rejected=1,error_recovery=1");
    lua_close(L);puts(''');p.write_text(t)
