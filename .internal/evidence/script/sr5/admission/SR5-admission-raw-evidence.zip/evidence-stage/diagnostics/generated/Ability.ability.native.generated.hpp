#pragma once
// Generated typed Native projection. Include the matching .ability.generated.hpp first.
#include <lux/engine/simulation/scripting/native/NativeScriptAbilityProjection.hpp>

#include <array>
#include <type_traits>
#include <utility>

namespace lux::script::native
{

    template <>
    struct ScriptAbilityNativeTraits<::ValueAbility> final
    {
        using AbilityTraits = ScriptAbilityTraits<::ValueAbility>;

        [[nodiscard]] static Item echo(
            void* provider,
            const void* dispatch_value,
            std::remove_cvref_t<const Item &> item
        ) noexcept
        {
            const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(dispatch_value);
            return dispatch.echo(provider, item);
        }

        inline static const std::array<ScriptAbilityNativeMethodProjection, AbilityTraits::Methods.size()> Methods{
            ScriptAbilityNativeMethodProjection{
                ScriptApiMethodIdView{"consumer.values.echo"},
                reinterpret_cast<lux_script_ability_direct_entry_fn>(&echo)
            }
        };
    };
} // namespace lux::script::native
