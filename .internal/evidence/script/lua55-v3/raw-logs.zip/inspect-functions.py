from pathlib import Path
import re,subprocess,json,os
r=Path(__file__).parent;out=r/'machine-code';image=r/'final-image'
cdb='C:/Program Files (x86)/Windows Kits/10/Debuggers/x64/cdb.exe'
records=[]
def address(raw):return int(raw.replace('`',''),16)
for module,log,patterns,exe in [
 ('lux_engine_function_script_lua','symbols.log',['LuaPageAllocator::allocate<0> (','LuaPageAllocator::allocate<1> (','LuaPageAllocator::acquire<0> (','LuaPageAllocator::release<0> ('], 'script_runtime_benchmark.exe'),
 ('simulation_script_lua_value_runtime_test','codec-symbols.log',['LuaValuePolicy>::writePlain (','LuaValuePolicy>::readPlain ('],'simulation_script_lua_value_runtime_test.exe'),
 ('lux_engine_simulation_script_lua','lux_engine_function_script_lua-uf.log',['State::destroyLuaContinuation (','State::destroyLuaContinuationErased ('],'script_runtime_benchmark.exe')]:
 text=(out/log).read_text();suffix='.exe' if module.startswith('simulation_') else '.dll'
 base=re.search(r'ModLoad: ([0-9a-f`]+) [0-9a-f`]+ +.*'+re.escape(module+suffix),text,re.I)
 assert base,(module,'missing module load')
 lines=['.reload /f '+module+suffix]
 for pattern in patterns:
  line=next(line for line in text.splitlines() if pattern in line and re.match(r'^[0-9a-f`]+ ',line))
  rva=address(line.split()[0])-address(base[1]);assert 0<rva<0x1000000
  records.append(dict(module=module,symbol=line.split(' ',1)[1],rva=hex(rva)))
  lines.append('uf '+module+'+'+hex(rva))
 if 'function' in module:
  lines+=['dt '+module+'!lux::script::lua::LuaPageAllocator',
    'x lux_engine_simulation_script_lua!*destroyLuaContinuation*']
 script=out/(module+'-uf.txt');script.write_text('\n'.join(lines+['q'])+'\n')
 env=dict(os.environ);env['PATH']=str(image)+';D:/Development/vcpkg/installed/x64-windows/bin;'+env['PATH']
 cmd=[cdb,'-y',str(image),'-cf',str(script),str(image/exe)]
 with (out/(module+'-uf.log')).open('wb') as f:code=subprocess.call(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 assert code==0
(out/'rvas.json').write_text(json.dumps(records,indent=2))
