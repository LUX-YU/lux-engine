import hashlib, json, subprocess, datetime
from pathlib import Path

base = Path('E:/SyncForder/CodeRepos')
out = base / 'build/RelWithDebInfo/sr3-event'
def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(base/repo), *args], text=True).strip()
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
repos = ['lux-engine', 'lux-engine-deep-optimization', 'lux-engine-sr3-reference',
         'lux-engine-sr3-cost-final', 'lux-engine-sr3-event', 'lux-cxx-v3r', 'lux-cmake-toolset-s6-relocation']
sources = [{'path': str(base/r), 'sha': git(r,'rev-parse','HEAD'), 'status': git(r,'status','--porcelain'),
            'remote': git(r,'remote','get-url','origin')} for r in repos]
assert sources[-2]['sha'] == '3100f54d0743c5ed94a4ccf5943df04e933de255'
assert not sources[-2]['status'] and not sources[-1]['status']
protected = {}
for repo in repos[:2]:
    paths = git(repo, 'diff', '--name-only').splitlines()
    paths += git(repo, 'ls-files', '--others', '--exclude-standard').splitlines()
    protected[repo] = {p: sha(base/repo/p) for p in paths if (base/repo/p).is_file()}
headers = json.loads((base/'build/RelWithDebInfo/sr3-closeout/cxx-header-check.json').read_text())['headers']
for h in headers:
    a = (base/'lux-cxx-v3r'/h['source']).read_bytes().replace(b'\r\n',b'\n')
    b = (base/'install/q2/c/include'/h['installed']).read_bytes().replace(b'\r\n',b'\n')
    h.update(source_sha256=hashlib.sha256(a).hexdigest(), installed_sha256=hashlib.sha256(b).hexdigest(), match=a==b)
assert len(headers)==114 and all(h['match'] for h in headers)
runtime = ['engine/domain/simulation/builtin/script/src', 'engine/domain/simulation/builtin/script/pinclude']
delta = git('lux-engine-sr3-event','diff','--name-only','99c1d095','--',*runtime)
assert not delta
record = {'time_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'sources': sources,
          'protected_files': protected, 'installed_cxx_headers': headers, 'normalization':'CRLF to LF only',
          'runtime_delta_from_99c1d095': delta,
          'power': subprocess.check_output(['powercfg','/getactivescheme'],text=True).strip(),
          'control_limit':'Affinity mask 1 in formal driver; clock frequency and background load not controlled.'}
(out/'identity-check.json').write_text(json.dumps(record, indent=2),encoding='utf-8')
print('Clean references, unchanged production runtime, 114 installed cxx headers and protected files recorded.')
