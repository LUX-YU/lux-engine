$ErrorActionPreference = 'Stop'
$root = 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/lua55-v2'
$source = 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-region-opt/final-source'
$development = 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source'
$depbuild = 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-lua55-s0-s1-20260909/dependencies/build-lua55'
$build = 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/o/w/d'
if ((git -C $source status --porcelain)) { throw 'Qualification clone is dirty' }
git -C $source fetch $development codex/s6-deep-optimization
if ($LASTEXITCODE) { throw 'fetch failed' }
$commit = git -C $development rev-parse HEAD
git -C $source checkout --detach $commit
if ($LASTEXITCODE) { throw 'checkout failed' }
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
function Run([string]$name,[string[]]$command) {
    $path = Join-Path $root "$name.log"
    if (Test-Path -LiteralPath $path) { throw "Existing log $path" }
    ($command | ConvertTo-Json -Compress) | Set-Content -LiteralPath $path
    $watch = [Diagnostics.Stopwatch]::StartNew()
    & $command[0] $command[1..($command.Length-1)] *>> $path
    $code=$LASTEXITCODE
    [ordered]@{source=$commit;command=$command;exit=$code;seconds=$watch.Elapsed.TotalSeconds} |
        ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $root "$name.json")
    Write-Output "$name exit=$code"
    if ($code) { throw "$name failed: $path" }
}
Run 'p6-real-dep-configure' @('cmake','-S',"$source/cmake/dependencies/lua55",'-B',$depbuild,
    '-DLUX_LUA55_LEAF_YIELD=ON',
    '-DPython3_EXECUTABLE=C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
Run 'p6-real-dep-build' @('cmake','--build',$depbuild,'--target','all','-j','4','--','-k','0')
Run 'p6-real-dep-tests' @('ctest','--test-dir',$depbuild,'--output-on-failure','-V','-j','1')


Run 'p6-real-dep-install' @('cmake','--install',$depbuild)

