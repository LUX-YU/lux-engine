$ErrorActionPreference = 'Stop'
$root = 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5'
$source = "$root/source"
$dep = 'E:/SyncForder/CodeRepos/install/q2/c;E:/SyncForder/CodeRepos/install/q2/toolset;E:/SyncForder/CodeRepos/install/RelWithDebInfo'
& "$root/value-costs-valid.ps1"
& "$source/cmake/RunScriptV3Measurements.ps1" -BaselineBin 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/m4/d/bin' -FinalBin "$root/q/d/bin" -BaselineToolBin 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/m4/t/bin' -FinalToolBin "$root/q/t/bin" -LuaArtifact "$root/q/t/engine/toolchain/lua/lua_runtime_benchmark_fixture.lxsa" -PhysicsLuaArtifact "$root/q/t/engine/toolchain/physics2d/physics2d_lua_fixture.lxsa" -PhysicsFlowArtifact "$root/q/t/engine/toolchain/physics2d/physics2d_flowforge_fixture.lxsa" -OutputRoot "$root/performance-final" -Only @('cpp-update-10k','lua-ability-10k','lua-update-10k','lua-coroutine-10k','flow-update-10k','flow-event-10k','event-fanout-10k','lua-event-10k') -Pairs 5
