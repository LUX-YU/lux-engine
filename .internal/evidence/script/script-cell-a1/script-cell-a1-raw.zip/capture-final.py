from pathlib import Path
import hashlib,json,shutil,struct
r=Path(__file__).parent
dev=r.parent/'o/w/d';tool=r.parent/'o/w/t';v4=r.parent/'script-v4'
source=json.loads((r/'final-d-build.json').read_text(encoding='utf-8-sig'))['source']
assert source==json.loads((r/'final-t-build.json').read_text(encoding='utf-8-sig'))['source']
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def imports(p):
 b=p.read_bytes();nt=struct.unpack_from('<I',b,60)[0]
 count=struct.unpack_from('<H',b,nt+6)[0];size=struct.unpack_from('<H',b,nt+20)[0];opt=nt+24
 directories=opt+(112 if struct.unpack_from('<H',b,opt)[0]==0x20b else 96)
 sections=[struct.unpack_from('<IIII',b,opt+size+i*40+8) for i in range(count)]
 def offset(rva):
  for vs,va,rs,raw in sections:
   if va<=rva<va+max(vs,rs):return raw+rva-va
  raise ValueError((p,rva))
 result=[]
 for index,stride,field in [(1,20,12),(13,32,4)]:
  address=struct.unpack_from('<I',b,directories+index*8)[0]
  if not address:continue
  at=offset(address)
  while any(b[at:at+stride]):
   name=struct.unpack_from('<I',b,at+field)[0];pos=offset(name)
   result.append(b[pos:b.index(0,pos)].decode('ascii'));at+=stride
 return result
for label,queue,roots in [
 ('final-image',['script_runtime_benchmark.exe','physics2d_script_benchmark.exe',
   'simulation_script_lua_value_runtime_test.exe'],[dev/'bin']),
 ('final-flow-image',['flowforge_script_runtime_benchmark.exe'],[tool/'bin',dev/'bin'])]:
 image=r/label;image.mkdir(exist_ok=False);saved={};external=[]
 roots=roots+[Path('D:/Development/vcpkg/installed/x64-windows/bin')]
 while queue:
  name=queue.pop()
  if name.lower() in saved:continue
  p=next((path/name for path in roots if (path/name).exists()),None)
  if p is None:external.append(name);continue
  shutil.copy2(p,image/name);saved[name.lower()]={'origin':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
  pdb=p.with_suffix('.pdb')
  if pdb.exists():shutil.copy2(pdb,image/pdb.name)
  queue+=imports(p)
 fixtures={}
 if label=='final-image':
  assert sha(image/'lux_lua55.dll')==sha(v4/'final-image/lux_lua55.dll')
  for name,folder in [('lua_runtime_benchmark_fixture.lxsa','lua'),
      ('physics2d_lua_fixture.lxsa','physics2d'),('physics2d_flowforge_fixture.lxsa','physics2d')]:
   p=tool/'engine/toolchain'/folder/name
   assert sha(p)==sha(v4/'final-image'/name),('changed workload',p)
   shutil.copy2(p,image/name);fixtures[name]=sha(p)
 (image/'identity.json').write_text(json.dumps(dict(source=source,images=saved,fixtures=fixtures,
    system_imports=external,baseline_source='f7d2815bdd2025ee23a7c11449def822413f58e9'),indent=2))
 print('CAPTURED',label,len(saved),source,flush=True)
