import hashlib,json,os,subprocess,shutil
from pathlib import Path
base=Path('E:/SyncForder/CodeRepos');root=base/'build/RelWithDebInfo/sr4';out=root/'diagnostics/timer-source-proof'
out.mkdir(parents=True,exist_ok=False)
exe=out/'simulation_script_continuation_test.exe'
shutil.copy2(root/'candidate/d/bin'/exe.name,exe)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
records=[]
for variant,prefix in [('e0',base/'install/sr3-e/d'),('e1',base/'install/sr4-candidate/d')]:
 env=dict(os.environ);clean=[v for v in env['PATH'].split(';') if 'CodeRepos' not in v and 'vcpkg' not in v]
 env['PATH']=';'.join([str(prefix/'bin'),'D:/Development/vcpkg/installed/x64-windows/bin',str(base/'install/q2/c/bin'),str(base/'install/RelWithDebInfo/bin')]+clean)
 with (out/(variant+'.log')).open('w') as log:r=subprocess.run([str(exe)],env=env,stdout=log,stderr=subprocess.STDOUT)
 text=(out/(variant+'.log')).read_text();valid=(r.returncode==0) if variant=='e1' else (r.returncode!=0 and 'waits() == 1U && system.activeAwaitableCount() == 1U' in text)
 records.append(dict(variant=variant,prefix=str(prefix),exit=r.returncode,expected_result=valid,dll_sha256=digest(prefix/'bin/lux_engine_simulation_script.dll')))
 assert valid,records[-1]
(out/'identity.json').write_text(json.dumps(dict(executable=str(exe),sha256=digest(exe),test_source_sha256=digest(base/'lux-engine-sr4-candidate/engine/domain/simulation/builtin/script/test/script_system_continuation_test.cpp'),runs=records),indent=2))
layouts=root/'diagnostics/layout';layouts.mkdir(exist_ok=False)
commands=[]
for variant,build,filename,types in [
 ('e0',base/'build/RelWithDebInfo/sr3-e/d','ScriptSystem.cpp',['AwaitableRecord','ExecutionInstance','NextStepWait','SimulationDelayWait']),
 ('e1',root/'candidate/d','ScriptExecution.cpp',['AwaitableRecord','ExecutionInstance']),
 ('e1-timers',root/'candidate/d','ScriptTimers.cpp',['Wait','InstanceIndex'])]:
 db=json.loads((build/'compile_commands.json').read_text());entry=next(e for e in db if e['file'].endswith('/builtin/script/src/'+filename))
 command=entry['command']+f' /Fo"{layouts}/{variant}.obj" /Fd"{layouts}/{variant}.pdb" '+ ' '.join('/d1reportSingleClassLayout'+t for t in types)
 with (layouts/(variant+'.log')).open('w') as log:r=subprocess.run(command,cwd=build,stdout=log,stderr=subprocess.STDOUT)
 commands.append(dict(variant=variant,command=command,exit=r.returncode))
 assert r.returncode==0
 assert 'class ' in (layouts/(variant+'.log')).read_text()
(layouts/'commands.json').write_text(json.dumps(commands,indent=2))
print(json.dumps(records))