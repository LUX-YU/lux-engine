from pathlib import Path
import ctypes as ct,subprocess,time,json,os,csv
r=Path(__file__).parent;out=r/'memory-diagnostic';out.mkdir(exist_ok=False)
base=r.parent/'lua55-v3/final-image'
k=ct.WinDLL('kernel32');k.GetCurrentProcess.restype=ct.c_void_p;k.SetProcessAffinityMask.argtypes=[ct.c_void_p,ct.c_size_t];assert k.SetProcessAffinityMask(k.GetCurrentProcess(),16)
class Memory(ct.Structure):
 _fields_=[('cb',ct.c_ulong),('PageFaultCount',ct.c_ulong),('PeakWorkingSetSize',ct.c_size_t),('WorkingSetSize',ct.c_size_t),('QuotaPeakPagedPoolUsage',ct.c_size_t),('QuotaPagedPoolUsage',ct.c_size_t),('QuotaPeakNonPagedPoolUsage',ct.c_size_t),('QuotaNonPagedPoolUsage',ct.c_size_t),('PagefileUsage',ct.c_size_t),('PeakPagefileUsage',ct.c_size_t)]
psapi=ct.WinDLL('psapi');psapi.GetProcessMemoryInfo.argtypes=[ct.c_void_p,ct.POINTER(Memory),ct.c_ulong]
results=[]
for side,image in [('baseline',base),('candidate',r/'final-image')]:
 log=out/(side+'.log');data=out/(side+'.csv')
 cmd=[str(image/'script_runtime_benchmark.exe'),'--group','scene-lua-event','--mode','performance','--size','10000','--frames','2000','--warmups','1000','--seed','1592598566','--resume-budget','10000','--vm-accounting','on','--lua-artifact',str(image/'lua_runtime_benchmark_fixture.lxsa'),'--output',str(data)]
 env=dict(os.environ);env['PATH']=';'.join([str(image),'D:/Development/vcpkg/installed/x64-windows/bin',*[p for p in env['PATH'].split(';') if 'CodeRepos' not in p and 'vcpkg' not in p]])
 peak_ws=peak_private=0;observations=0
 with log.open('wb') as f:
  process=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
  while process.poll() is None:
   info=Memory();info.cb=ct.sizeof(info)
   if psapi.GetProcessMemoryInfo(int(process._handle),ct.byref(info),info.cb):
    peak_ws=max(peak_ws,info.PeakWorkingSetSize);peak_private=max(peak_private,info.PeakPagefileUsage);observations+=1
   time.sleep(.2)
  code=process.wait()
 assert observations>0 and peak_ws>0, 'process memory observation unavailable'
 text=log.read_text();assert code==0 and 'checksum=930010000' in text and text.count('invocation_errors=0')==2
 rows=list(csv.DictReader(data.open()));assert len(rows)==2000
 results.append(dict(side=side,command=cmd,exit=code,valid=True,peak_working_set=peak_ws,peak_private_commit=peak_private,samples=observations,last_row=rows[-1],diagnostic_lines=[line for line in text.splitlines() if line.startswith(('VM_','INTEGRITY'))]))
 (out/'results.json').write_text(json.dumps(results,indent=2));print('MEMORY',side,peak_ws,peak_private,flush=True)
