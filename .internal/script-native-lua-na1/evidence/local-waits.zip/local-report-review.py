from pathlib import Path
r=Path.cwd();p=r/'source/.internal/script-native-lua-na1/LOCAL-WAIT-RESULT.zh-CN.md';t=p.read_text();needle='软件采样有内联归属和周期取样偏差，没有 PMU，不声称已证明 cache miss 或分支误预测根因。';assert needle in t;t=t.replace(needle,needle+'\n各项结构改动同时进入最终对照，不能精确分摊每个改动贡献的百分比；Lua 库和脚本未改，Lua 内部样本变化也不能称作本轮 VM 优化收益。');p.write_text(t)
