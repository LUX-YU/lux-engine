from pathlib import Path
import hashlib,json,subprocess,sys,urllib.request,zipfile,io
r=Path(__file__).parent;source=r/'source';branch='codex/s6-execution-cell-a1';commit=sys.argv[1]
head=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
remote=subprocess.check_output(['git','-C',str(source),'ls-remote','origin','refs/heads/'+branch],text=True).split()[0]
assert remote==head
base=source/'.internal/evidence/script/script-cell-a1';expected=json.loads((base/'archive.json').read_text())
url=f'https://raw.githubusercontent.com/LUX-YU/lux-engine/{commit}/.internal/evidence/script/script-cell-a1/script-cell-a1-raw.zip'
with urllib.request.urlopen(url,timeout=120) as response:data=response.read()
assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256']
with zipfile.ZipFile(io.BytesIO(data)) as z:
 assert z.testzip() is None
 manifest=json.loads(z.read('manifest.json'))
 for entry in manifest['files']:assert hashlib.sha256(z.read(entry['path'])).hexdigest()==entry['sha256']
result=dict(branch=branch,remote_head=remote,archive_commit=commit,url=url,sha256=expected['sha256'],bytes=len(data),hashed_files=len(manifest['files']),verified=True)
(r/'remote-verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
