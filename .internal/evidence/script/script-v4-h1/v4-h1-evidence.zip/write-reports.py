"""Compile actual qualification records. Never converts a planned test into PASS."""
from pathlib import Path
import csv,json,re,statistics,subprocess
r=Path(__file__).parent;repo=r.parent/'script-cell-a1/source';out=repo/'.internal/script-v4-h1';out.mkdir(exist_ok=True)
spec=r/'spec/LUX_V4_Check_Hoisting_H1_2026-09-10'
A='f7d2815bdd2025ee23a7c11449def822413f58e9'
B=json.loads((r/'final2-d-build.json').read_text(encoding='utf-8-sig'))['source']
C='655855401e09aac2d4e8becd16afca62086291ee'
def read(p):return json.loads((r/p).read_text(encoding='utf-8-sig'))
def line(path,needle,rev=B):
 text=subprocess.check_output(['git','-C',str(repo),'show',rev+':'+path],text=True)
 for n,s in enumerate(text.splitlines(),1):
  if needle in s:return f'{rev[:8]}:{path}:{n}'
 raise ValueError((path,needle,rev))
native='engine/domain/simulation/scripting/native/src/NativeScriptBackend.cpp'
frame='engine/domain/simulation/scripting/native/pinclude/lux/engine/simulation/scripting/native/NativeFrameStorage.hpp'
storage='engine/domain/simulation/scripting/core/include/lux/engine/simulation/scripting/detail/BoundedClassStorage.hpp'
execution='engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptExecution.hpp'
instances='engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptInstances.hpp'
preparer='engine/domain/simulation/builtin/script/src/ScriptPreparer.cpp'
loader='modules/function/script/native/src/NativeModule.cpp'
lua='engine/domain/simulation/scripting/lua/src/LuaScriptBackend.cpp'
projection='modules/function/script/lua/include/lux/engine/function/script/lua/LuaScriptAbilityProjection.hpp'
if not (repo/projection).exists():
 projection=next(str(x.relative_to(repo)).replace('\\','/') for x in repo.rglob('LuaScriptAbilityProjection.hpp'))
value='modules/function/script/lua/src/LuaValue.cpp'
proofs={
 'H1-N01':(native,'createNativeContinuationResolved',loader,'frame_size', 'REUSED_COLD','loadNativeModule INVALID_MODULE；prepareMethod 固定 max envelope；运行 frame/acquire 失败原样回滚','native-cold/runs.json; native-boundary/runs.json'),
 'H1-N02':(native,'createNativeContinuationResolved',native,'frame_storage.prepare', 'REUSED_COLD','loader 拒绝零/非2幂；prepareMethod 拒绝配置 alignment 上界','native-cold/runs.json; final2-d-LastTest.log'),
 'H1-N03':(native,'resumeNativeContinuation(',native,'invokePreparedStep(', 'RESOLVED_LOCAL','checked PreparedCall 链仍逐调用检查；局部 immutable step 不代表 ACTIVE','contract-comparison-final/result.json; native-boundary/runs.json'),
 'H1-N04':(native,'static int startEventWait(',native,'ordinal >= adapter.events.size()', 'KEPT_BOUNDARY','原 startEventWait -1；未取消上下文/ordinal/output 检查','native-boundary/runs.json'),
 'H1-N05':(native,'resumeNativeContinuation(',native,'stepResult(', 'KEPT_DYNAMIC','原 packet mismatch -1；非法 outcome -1；真实 failed status 保留','native-boundary/runs.json'),
 'H1-N06':(native,'free_continuations.empty()',native,'frame_storage.acquire', 'KEPT_DYNAMIC','原 create 失败；slot 恢复；frame generation/lease 由 storage 管理','final2-d-LastTest.log; native-boundary/runs.json'),
 'H2-E01':(execution,'reserveAwaitable(',preparer,'payload', 'WITHDRAWN_COST','65585540 仅复用已证实字段，STRUCT_REF identity/modulo 仍热检；7c565a0 恢复完整旧 gateway','contract-comparison-final/result.json; h2-withdrawal-costs/summary.json'),
 'H2-E02':(instances,'eventSource(',instances,'eventSource(', 'KEPT_BOUNDARY','scope/instance/layout_epoch/local_slot/target entity 仍由本次来源解析拒绝','final2-d-LastTest.log:testPreparedAdmissionProvenance'),
 'H2-E03':(execution,'const auto registered = event_owner_.registerWait',execution,'eraseAwaitableRecord(', 'WITHDRAWN_COST','短借用回滚候选随 H2 整体撤回；原 discardAwaitable 查找保留','h2-withdrawal/withdrawal.diff; contract-comparison-final/result.json'),
 'H2-E04':(execution,'ResultWritePin',execution,'ResultWritePin', 'KEPT_DYNAMIC','copy 前后权限、pin、terminal 不改；迟到/重复完成仍受拒绝','final2-d-LastTest.log:testCopyRetirementPin/testCopyNestedAdmission'),
 'H2-E05':(execution,'beginSuspension(',execution,'takeAwaitable(', 'KEPT_DYNAMIC','C 晚接纳、取值还 A、源取消、stale pop/full queue 按 V4 时点','final2-d-LastTest.log; final2-t-LastTest.log'),
 'H3-C01':(storage,'bool release(Ticket',storage,'releaseResolved(', 'RESOLVED_LOCAL','Ticket owner/边界/active/完整 generation 检查后私有写内核；不再构造再验证 Allocation','contract-comparison-final/result.json'),
 'H3-C02':(storage,'bool release(const Allocation',storage,'expected', 'KEPT_BOUNDARY','外部 data/size/nonempty/page/slot/active/generation 仍拒绝；错误释放不改变统计','contract-comparison-final/result.json'),
 'H3-N01':(frame,'slots_per_region',frame,'slots_per_region', 'NOT_SELECTED_METADATA_TRADEOFF','保留 div；Class 增字段使32B→40B，违背本轮 backing 条件','machine-A-full/index.json; layout-final2/B/run.log'),
 'H4-L01':(lua,'LuaAbilityProjectionAccess::current',lua,'LuaAbilityProjectionAccess::current', 'KEPT_BOUNDARY','当前 execution/thread/behavior/layout/closure ordinal；无效绑定不按 standalone 放行','final2-d-LastTest.log'),
 'H4-L02':(lua,'LuaAbilityProjectionAccess::revalidate',lua,'LuaAbilityProjectionAccess::current', 'ALREADY_BOUNDARY_ONLY','current 一次 prepared_abilities.at；revalidate 无重复目录解析，比较原 access','machine-A-full/index.json; machine-B2-full/index.json'),
 'H4-L03':(projection,'if constexpr (can_reenter)',projection,'if constexpr (can_reenter)', 'ALREADY_IMPLEMENTED','原默认 scalar 免转换后重验；初始权限和实际参数仍验证，不计本轮收益','final2-d-LastTest.log'),
 'H4-L04':(projection,'invokeLuaValueAbility',value,'', 'KEPT_BOUNDARY','arity/type/range/enum/strict raw shape 仍按实际输入；结果失败不回滚 provider','final2-d-LastTest.log'),
 'H4-L05':(lua,'LuaAbilityProjectionAccess::revalidate',lua,'LuaAbilityProjectionAccess::revalidate', 'KEPT_DYNAMIC','原 capture 比较；转换重入后不重新 capture 获取权限','final2-d-LastTest.log:resume-retire/resume-stop/retire/fault/recovery'),
 'H4-L06':(value,'lua_checkstack',value,'lua_checkstack', 'KEPT_DYNAMIC','W0 callback checkstack/pcall/OOM 及外层 owning cleanup 保留','final2-d-LastTest.log:CODEC_INNER_STACK_OOM'),
 'H4-C01':(instances,'bool current()',instances,'bool current()', 'ALREADY_MINIMAL_AUTHORITY_PATH','既有只读 authority + 完整身份，不添加证书和目录','final2-d-LastTest.log:script_bindings')}
rows=list(csv.DictReader((spec/'CHECK_AUDIT.csv').open(encoding='utf-8-sig')))
for x in rows:
 path,needle,pfile,pneedle,status,rejection,evidence=proofs[x['check_id']]
 # Exact snippets vary in return-type wrapping; fail loudly rather than invent a location.
 if x['check_id']=='H3-C02':needle='release(Allocation allocation)'
 if x['check_id']=='H3-N01':needle=pneedle='d.stride / c.stride'
 if x['check_id']=='H4-C01':needle=pneedle='authority_->state == EScriptMountState::ACTIVE'
 x['actual_before_file_lines']=line(path, 'createNativeContinuation(' if x['check_id'] in ['H1-N01','H1-N02'] else needle,A)
 x['actual_after_file_lines']=line(path,needle)
 x['actual_proof_file_lines']=line(pfile,pneedle)
 x['old_rejection_owner']=rejection;x['assembly_evidence']='machine-A-full/index.json; machine-B2-full/index.json'
 if x['stage']=='H2':x['assembly_evidence']+='; withdrawn65585540=machine-B-full/index.json'
 x['runtime_evidence']=evidence;x['status']=status
with (out/'CHECK_AUDIT.csv').open('w',newline='',encoding='utf-8-sig') as f:
 writer=csv.DictWriter(f,fieldnames=rows[0].keys());writer.writeheader();writer.writerows(rows)

# Matrix records assertions actually present; a suite name is not proof of an untested negative.
tests=[
 ('native-cold 8 shapes; Event testArtifactSchemaDriftFailsBeforeInstanceCreation/testPreparedPayloadResidualValidation','16 cold A/B exits0; bad size/alignment/callback/init loader rejection; Event prepare succeeds for custom malformed ABI then wait rejects, zero backend resume','PASS'),
 ('native_backend_test released entry; lifecycle incarnation; lua value authority cases','released invoke FAILED/-1 frames0; re-materialized state0; old Event admission UNDECLARED_SOURCE','PASS'),
 ('native_frame_storage_test; native_population_test','tiny/large/mixed/superalignment; all N large + N+1 fail; domains separated; destructor counts/final active0','PASS'),
 ('native_population_test failure probe; native-boundary modes3–7','start status73; failed0→-1; invalid state/token→-1; destroy exactly1, frame0, lease1','PASS'),
 ('native_population_test destroy probe; lifecycle protected reentry','destroy callback frame remains active until return; nested allocation limited; later reuse succeeds; seven-point core reentry','PASS'),
 ('native-boundary modes1/2; generated FlowForge Event; Native released entry','Event ordinal1 on one import and null output return-1; waits0, destroy1. Null opaque pointer is not a supported C++ entry, not forged. Empty prepared entry rejected','PASS'),
 ('native-boundary mode0','6 READY negatives: type/kind/size/alignment/bytes/null-value all -1; actual resume0/frame retained; corrected packet value29 resumes1/destroy1','PASS'),
 ('native-boundary modes4–7','invalid state255/empty token/failed0→-1; failed -71 preserved; no continuation published, cleanup1','PASS'),
 ('testPreparedAdmissionProvenance; testTargetedAndRetirement','foreign runtime and old incarnation UNDECLARED_SOURCE; valid payload9 delivered; destroyed targeted instance no resume','PASS'),
 ('testSourcePreflightBeforeAwaitableCapacity; testCapacityAndCancellation; testLocalTimerCapacityAndReuse','Event both-full WAITER_CAPACITY_EXCEEDED; late C refusal still records three backend starts；local/external Timer A-full + duration=-1 都返回 AWAITABLE_CAPACITY_EXCEEDED，四配置各32轮清零','PASS'),
 ('testCopyRetirementPin; pin-boundary A/B real runtime probe','capacity1；copy内取消后activeA0/pin1；来源容量2未满但嵌套登记被AWAITABLE_CAPACITY_EXCEEDED拒绝；copy后pin0/A0/resume0，关闭成功','PASS'),
 ('copy retirement/other removal/nested admission; generated Lua converter reentry','payload81 then three82; moved-other record copy8bytes/one valid resume; revoked provider counts0','PASS'),
 ('testSyncAndContinuation; testLocalTimerCapacityAndReuse; testCapacityAndCancellation','ready before/after attachment, repeated local wait, stale external completion INVALID_ID, release/cancellation and final0','PASS'),
 ('testResumeQueueFailure/testResumeBudget; testTimerDeadlineOrderAndBackpressure; script_ingress_frontier_test','Event full error; Timer pending retry survives; per-pop frontier and budget tests; single-flight isolation/shared-hook ratios','PASS'),
 ('class_storage_test new checked-release boundaries, observe false/true','wrong owner/null/page/slot/high generation/data/size/double free rejected; no counter/usage changes; valid release/reuse succeeds','PASS'),
 ('class_storage_test; frame_storage_failure_test; cpp coroutine runtime','Ticket24, unchanged class/backing; allocation failure cleanup; both observe paths final live0','PASS'),
 ('Native arithmetic candidate not selected','actual div retained; Class32; no cached field or changed legal alignment/population budget','NOT_SELECTED_METADATA_TRADEOFF'),
 ('lua_closure_provenance_test; lua_value_runtime authority + standalone','跨 Alpha/Beta closure 拒绝且 provider0；同 prototype 复用合法；重建/换 content 旧 closure 拒绝；32次重载 stale_provider0，prepared_slots最终0；standalone scalar2/zero2/lifecycle2','PASS'),
 ('H4 reviewed, no Lua predicate removed','No new closure/ordinal elimination requiring mutation replay; debug availability and table mutability untouched','NOT_APPLICABLE_NO_LUA_CHANGE'),
 ('lua_value_test numeric contract; generated value runtime negative/recovery','i32/u32 boundaries, finite inputs, enums; invalid record provider0; recovery and lifecycle counts exact','PASS'),
 ('lua_value_runtime_test; lua_value_test; script-lua-values installed','generated nested ValuePose field outputs; unknown/missing/type rejects; custom field mutation order and const/factory cleanup','PASS'),
 ('lua_value_runtime output failure; script-lua-values installed','output provider poses1 despite conversion error; new results remain independent; reverse resource cleanup','PASS'),
 ('lifecycle execution-region tests; value runtime retire/fault/stop/recovery and resume variants','native retire/fault scalar/zero0; deferred stop same-batch legal; original resume conversion retirement rechecked','PASS'),
 ('lua_value_test testInnerStackFailure; fixed VM contracts','actual depth1/16/32 callback paths, forced stack growth failure, owning object intact then depth32 recovery; MSVC public deep wrapper limitation retained','PASS'),
 ('15 installed consumers; 13 incremental probes;2 relocated chains','all all/build/run/noop; real generated Ability provider→independent results→shutdown while qualified source/build/SDK hidden','PASS'),
 ('final2-costs; layout-final2; final-audit','7 legs3pairs whole work oracle, raw batch tails/errors/backlog; selected C/A/Ready/source/backing identical','PASS')]
matrix=list(csv.DictReader((spec/'TEST_MATRIX.csv').open(encoding='utf-8-sig')))
for x,(test,observed,status) in zip(matrix,tests):
 x.update(actual_test=test,command_log='final2-d-LastTest.log; final2-t-LastTest.log; native-boundary/runs.json; installed-final2/consumers.json; relocated-final2/results.json; final2-costs/runs.json',observed_result=observed,status=status)
with (out/'TEST_MATRIX.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=matrix[0].keys());w.writeheader();w.writerows(matrix)

profile=['# V4-H1 当前 V4 软件采样\n',f'实际 A 源码 `{A}`。五份本轮采样均从保留 V4 镜像启动，target exit=0 且业务 oracle 通过。',
 '采样使用 VTune 2026.3 User-mode sampling，10ms，采集调用栈。固定 EXE 没有可用 ITT ROI 接口，范围为完整目标进程（包括准备、预热与清理），**不是精确业务循环 ROI**。没有 PMU 数据，不推断 cache miss/branch miss。',
 'CPU self 是函数自身采样，top-down 是 inclusive 调用树；两者不相加。不得把带采样耗时作为普通性能数据。']
for scene in ['event','flowforge-event','scalar','record','cpp-sequence']:
 home=r/'baseline-profile'/scene
 sums=list(csv.reader((home/'summary.csv').open(encoding='utf-8-sig')))
 cpu=float(next(x[2] for x in sums if len(x)>2 and x[1]=='CPU Time'))
 hot=list(csv.DictReader((home/'hotspots.csv').open(encoding='utf-8-sig')))
 profile += [f'\n## {scene}\n',f'目标 CPU 合计 {cpu:.6f}s。原始记录：归档 `baseline-profile/{scene}/`；本机 `{home}`。',
 '| 函数 | self秒 | 占CPU |\n|---|---:|---:|']
 for h in hot[:8]:profile += [f"| {h['Function']} | {float(h['CPU Time']):.6f} | {100*float(h['CPU Time'])/cpu:.2f}% |"]
profile += ['\n## 解释与限制\n',
 'Lua Event 仍包含 Lua table 读取、GC/页释放、字节码执行、实例 Event 来源解析和 resumeOne；不能说检查占据大多数时间。FlowForge 可观察到 prepared invoke、来源登记、frame 分配、类型验证；H1 仅删除其中冷期可证明的重复形状判断。',
 'ValuePose 只有约1.1秒 CPU，软件样本粗；不为微小百分比作精确归因。FlowForge 目标退出后编译器 vctip 子进程延长 collector 生命周期，收到完整 target oracle 后停止采集；collector elapsed 不作为业务耗时。',
 '五次 bottom-up 报表命令不受本版本支持，失败输出保留；有效导出为 hotspots、top-down 和 summary。没有重新采候选热点，候选使用独立无采样对照与匹配 PDB 机器码。',
 'PDB 的 S_GPROC/S_LPROC RVA+code size 界定函数。objdump 文本附近的导出别名不是函数归属依据。机器码索引包含实际 DLL/PDB hash、RVA、代码字节、分支/调用/除法数量。']
(out/'PROFILE_BASELINE.zh-CN.md').write_text(re.sub(r'(?<=\|)\n\n(?=\|)', '\n', '\n\n'.join(profile))+'\n',encoding='utf-8')
print('AUDIT_MATRIX_PROFILE_WRITTEN',B)
