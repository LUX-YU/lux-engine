#pragma once
// Generated typed Lua projection. Include the matching .ability.generated.hpp first.
#include <lux/engine/simulation/scripting/lua/LuaScriptAbilityProjection.hpp>

#include <array>
#include <type_traits>
#include <utility>

namespace lux::script::lua
{

    template <>
    struct ScriptAbilityLuaTraits<::lux::simulation::script::benchmark::ValueAbility> final
    {
        using AbilityTraits = ScriptAbilityTraits<::lux::simulation::script::benchmark::ValueAbility>;
        using Policy = typename ScriptAbilityLuaPolicy<::lux::simulation::script::benchmark::ValueAbility>::Type;

        using Values_read = LuaAbilityValueSignature<Policy, int, int>;
        [[nodiscard]] static int read(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, int, int>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, int input) noexcept -> int
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.read(access.context, input);
                }
            );
        }

        using Values_write = LuaAbilityValueSignature<Policy, void, int>;
        [[nodiscard]] static int write(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, void, int>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, int value) noexcept -> void
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    dispatch.write(access.context, value);
                }
            );
        }

        inline static constexpr std::array<ScriptAbilityLuaMethodProjection, AbilityTraits::Methods.size()> Methods{
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.benchmark.value.read"},
                &read, Values_read::Parameters, Values_read::Results
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.benchmark.value.write"},
                &write, Values_write::Parameters, Values_write::Results
            }
        };
    };
} // namespace lux::script::lua
