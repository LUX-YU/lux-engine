$ErrorActionPreference='Stop'
$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5c'
$original=$env:PATH
$variants=@{
 H=@{exe="$r/record-trial/H/build/script_lua_value_cost.exe";bin='E:/SyncForder/CodeRepos/install/sr4-move/d/bin';mode='timing'}
 protected=@{exe="$r/record-trial/C0/build/script_lua_value_cost.exe";bin='E:/SyncForder/CodeRepos/install/s5c/q/d/bin';mode='protected'}
 C0=@{exe="$r/record-trial/C0/build/script_lua_value_cost.exe";bin='E:/SyncForder/CodeRepos/install/s5/q/d/bin';mode='timing'}
 C1=@{exe="$r/record-trial/C0/build/script_lua_value_cost.exe";bin='E:/SyncForder/CodeRepos/install/s5c/q/d/bin';mode='timing'}
}
$records=@()
foreach($i in 0..4){
 $order=if($i % 2){@('C1','C0','protected','H')}else{@('H','protected','C0','C1')}
 foreach($side in $order){
  $v=$variants[$side];$env:PATH="$($v.bin);D:/Development/vcpkg/installed/x64-windows/bin;$original"
  & $v.exe $v.mode 1000000 *> "$r/record-final/$side-$i.log"
  if($LASTEXITCODE){throw "record final $side failed"}
  $records+=@{variant=$side;pair=$i;exe_sha256=(Get-FileHash $v.exe).Hash;bin=$v.bin;mode=$v.mode;exit=0}
 }
}
foreach($side in @('H','protected','C0','C1')){
 $v=$variants[$side];$env:PATH="$($v.bin);D:/Development/vcpkg/installed/x64-windows/bin;$original"
 $mode=if($side -eq 'protected'){'protected-diagnostics'}else{'diagnostics'}
 & $v.exe $mode 10000 *> "$r/record-final/$side-diagnostics.log"
 if($LASTEXITCODE){throw "final diagnostic $side failed"}
}
$v=$variants.C1;$env:PATH="$($v.bin);D:/Development/vcpkg/installed/x64-windows/bin;$original"
& $v.exe protected-errors *> "$r/record-final/protected-errors.log"
if($LASTEXITCODE){throw 'final protected errors failed'}
$records | ConvertTo-Json -Depth 5 | Set-Content "$r/record-final/runs.json"
$env:PATH="$r/q/d/bin;D:/Development/vcpkg/installed/x64-windows/bin;$original"
foreach($i in 0..4){
 & "$r/q/d/bin/simulation_script_lua_value_runtime_test.exe" --benchmark 100000 *> "$r/record-final/typed-$i.log"
 if($LASTEXITCODE){throw 'typed benchmark failed'}
}
& "$r/q/d/bin/simulation_script_lua_value_runtime_test.exe" --benchmark 100000 --allocations *> "$r/record-final/typed-allocations.log"
if($LASTEXITCODE){throw 'typed allocations failed'}
$env:PATH=$original
