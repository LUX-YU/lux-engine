import subprocess
import sys
from pathlib import Path

r = Path(__file__).resolve().parent
s = r.parent / 's5/source'
stage = r / 'evidence-stage'
(stage / 'diagnostics/task.txt').write_bytes((r / 'task.md').read_bytes())
(stage / 'H-initial-bootstrap-warning.log').write_text(
    'Transcription of tool output from final-validation.ps1, after C0-C1 and before the first H-C1 run.\n'
    'The input line is too long.\nThe syntax of the command is incorrect.\n'
    'The measurement process returned zero; this attempt is excluded due to bootstrap uncertainty.\n'
    'Fresh-process replacement: H-clean-driver.log and performance-H-C1-clean.\n')
roots = ['evidence-stage', 'q', 'correctness-qualification', 'consumers-final', 'incremental-final',
         'final-cases', 'scalar-trial', 'record-trial', 'record-final', 'performance-C0-C1',
         'performance-H-C1', 'performance-H-C1-clean']
sources = [r / 'candidate-source', r.parent / 's5/candidate-source',
           r.parent / 'sr4-move/candidate-source',
           Path('E:/SyncForder/CodeRepos/lux-cxx-v3r'),
           Path('E:/SyncForder/CodeRepos/lux-cmake-toolset-s6-relocation')]
prefixes = [Path('E:/SyncForder/CodeRepos/install') / v for v in
            ['s5c/q/t', 's5c/q/d', 's5c/q/l', 'q2/c', 'q2/toolset']]
args = [sys.executable, '-B', str(s / 'cmake/CollectScriptSR3Evidence.py')]
for root in roots:
    args += ['--root', str(r / root)]
for source in sources:
    args += ['--source', str(source)]
for prefix in prefixes:
    args += ['--prefix', str(prefix)]
args += ['--consumers', str(r / 'consumers-final'), '--output',
         str(s / '.internal/evidence/script/sr5/admission'),
         '--archive-name', 'SR5-admission-raw-evidence.zip']
(stage / 'archive.py').write_bytes(Path(__file__).read_bytes())
subprocess.run(args, check=True)
