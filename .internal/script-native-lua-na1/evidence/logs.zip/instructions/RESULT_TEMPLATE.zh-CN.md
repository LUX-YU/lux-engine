# V4-NA1 实施结果（未填写模板）

> 此文件当前未执行、未测量。删除本提示只能基于真实交付记录。

## 结论

实施：NOT_STARTED；合同：NOT_TESTED；成本：NOT_MEASURED；采用：NOT_APPROVED_PENDING_REVIEW。

范围：C++原生编排 + Lua同步步骤。新FlowForge→Lua桥未包含；原FlowForge回归：[实际状态]。

## 身份

填写V4生产源、共同测试源、最终B clean源、报告提交、每个镜像/SDK/VM/资产/工具/实际环境。不要把文档提交冒充测量源。

## 实际调用链

列出一个core实例及Lua/CPP子对象、create/prepare/start/wait/complete/call-step/fail/destroy。注明实际新接口、未采用项、与规格的偏离和理由。

## 业务合同与有意语义变化

填写共同业务oracle、时序、来源/恢复/权限；明确不再支持的单体Lua暂停上下文行为。不得只写“所有语义等价”。

## 结构与资源

分别填写任务thread/root/yield计数、nativeframe/lease/step绑定、Lua余留池、core/source及总账。必须区分零/未观察，活跃/预留/进程峰值。

## 性能

| 比较 | 单位 | A中位 | B中位 | 三对变化 | 配对变化中位 | 业务有效 |
|---|---|---:|---:|---|---:|---|
| P1 | 完整Event任务 | — | — | — | — | 未测 |
| P2 | 完整NextStep任务 | — | — | — | — | 未测 |
| P3 | 完整三wait任务 | — | — | — | — | 未测 |
| P4 | 完整32wait任务 | — | — | — | — | 未测 |
| P5 | 完整record任务 | — | — | — | — | 未测 |
| S1 | 原scalar调用 | — | — | — | — | 未测 |
| S2 | 原CPP Sequence帧 | — | — | — | — | 未测 |
| S3 | 原FlowForge Event | — | — | — | — | 未测 |
| P6 | 混合Physics整帧 | — | — | — | — | 未测 |

完整ROI秒数/批次分布/有效慢组与无效理由另表。不要把P3/P4归一化混成一次lua_resume。

## 观察

P1/P3两侧准确ROI profile、机器码、pcall层数、frame大小及未知归因。无PMU就不写确定cache/branch原因。

## 资格与安装

54条要求的实际映射；Developer/Toolchain/VM；旧15+新consumer；旧13+新增量；旧2+新迁址。不要按计划数量填实际PASS数。

## 已知限制、负结果与是否值得继续

回答SPEC第14.4节八个问题。性能与内存交换分别评价；不能用无Lua task thread自动证明整体更快。

## 保护及证据

原工作区/分支未修改的证据；只推新分支；固定归档hash和远端回取状态。未做到的校验写未做到。
