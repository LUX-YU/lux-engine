from pathlib import Path
import ast, difflib, hashlib, json, re, subprocess, textwrap

root = Path('E:/RenderV2Rebuild/Layer/perf')
root.mkdir(exist_ok=True)
prior = Path('E:/RenderV2Rebuild/V11R/runners/prepare-experiment.py').read_text()
tree = ast.parse(prior)
values = {}
for node in tree.body:
    if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name) and node.targets[0].id in ('common','server_prefix'):
        values[node.targets[0].id] = ast.literal_eval(node.value)
fixture_patch = (prior[prior.index(" out=root/variant;"):prior.index(" p=source/'modules/function/render/runtime/src/RenderServer.cpp'")])
variants = {
 'baseline': (Path('E:/RenderV2Rebuild/V11R/verification/2824180646c1c01eaa97ed86151abbc4852a4de1/source'), Path('E:/RenderV2Rebuild/V11R/verify-build/release')),
 'layer': (Path('E:/RenderV2Rebuild/Layer/v/src'), Path('E:/RenderV2Rebuild/Layer/v/r')),
}
manifest = []
for variant, (source, build) in variants.items():
    assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain']).strip()
    out = root / variant
    exec('if True:\n' + fixture_patch, dict(root=root, variant=variant, source=source, common=values['common'], difflib=difflib))
    names = ['RenderServer.cpp'] if variant == 'baseline' else ['ServerLoop.cpp', 'ServerCompletion.cpp']
    for name in names:
        path = source / 'modules/function/render/runtime/src' / name
        original = path.read_text()
        s = values['server_prefix'] + original
        if 'auto result = group.context->execute();' in s:
            s = s.replace('auto result = group.context->execute();', 'if (!experimentDrawPermit()) continue;\n                auto result = group.context->execute();', 1)
            s, count = re.subn(r'(RenderResult<void> (?:RenderServer::Impl::)?tick\(\) noexcept\s*\{)', r'''\1
            if (const auto capture = experimentCaptureRequested()) {
                const auto stats = device->uploadStats();
                experimentSnapshot(capture, stats.copied_bytes, stats.chunks, stats.prepare_ns, stats.owner_ns,
                    stats.gpu_ns, stats.gpu_samples, device->queue().nativeQueue().family,
                    device->queue(vulkan::EQueueRole::TRANSFER).nativeQueue().family,
                    &device->queue() == &device->queue(vulkan::EQueueRole::TRANSFER));
            }''', s)
            assert count == 1
        if 'auto ready = completed;' in s:
            s = s.replace('auto ready = completed;', 'experimentTrace(10, 0);\n        auto ready = completed;', 1)
            anchor = 'reply = slot.request->publishPrepared(gpu.reply, gpu.reply_charge);'
            assert s.count(anchor) == 1
            s = s.replace(anchor, anchor+'\n            experimentTrace(11, bool(reply) ? 0 : 1);', 1)
        (out / name).write_text(s)
        (out / (name+'.patch')).write_text(''.join(difflib.unified_diff(original.splitlines(True), s.splitlines(True), fromfile=str(path), tofile=str(out/name))))
    commands = subprocess.check_output(['D:/Softwares/ninja/ninja.exe','-C',str(build),'-t','commands','render_texture_rendering_test'],text=True).splitlines()
    compiles = []
    objects = []
    filenames = ['TextureRendering.cpp'] + names
    for filename in filenames:
        subfolder = 'test' if filename == 'TextureRendering.cpp' else 'src'
        needle = str(source/f'modules/function/render/runtime/{subfolder}/{filename}').replace('\\','/').lower()
        cmd = next(c for c in commands if needle in c.replace('\\','/').lower() and 'render_texture_rendering_test.dir' in c and ' -c ' in c)
        objects.append(re.search(r'/Fo([^ ]+)',cmd).group(1))
        cmd = re.sub(r'/Fo[^ ]+',f'/Fo{out.as_posix()}/{filename}.obj',cmd)
        cmd = re.sub(r'/Fd[^ ]+',f'/Fd{out.as_posix()}/compile.pdb',cmd)
        cmd = re.sub(r' -c .*$',f' /I"{source.as_posix()}/modules/function/render/runtime/test" /I"{source.as_posix()}/modules/function/render/runtime/pinclude" /c {out.as_posix()}/{filename}',cmd)
        cmd = cmd.replace(' /nologo ', ' /nologo /I"C:/Program Files (x86)/Intel/oneAPI/vtune/2026.4/include" ')
        compiles.append(cmd)
    link = commands[-1]
    link = link[link.index(' -- ')+4:]
    link = link.rsplit(' && cd .',1)[0].rstrip('"')
    for obj, filename in zip(objects,filenames):
        link = link.replace(obj,f'{out.as_posix()}/{filename}.obj')
    for flag, name in [('out','fixed.exe'),('implib','fixed.lib'),('pdb','fixed.pdb')]:
        link = re.sub('/'+flag+r':[^ ]+', '/'+flag+':'+(out/name).as_posix(),link)
    link += ' "C:/Program Files (x86)/Intel/oneAPI/vtune/2026.4/lib64/libittnotify.lib"'
    (out/'build.cmd').write_text('@echo off\ncd /d "'+str(build)+'"\n'+'\nif errorlevel 1 exit /b %errorlevel%\n'.join(compiles+[link])+'\nexit /b %errorlevel%\n')
    manifest.append(dict(variant=variant,source=str(source),build=str(build),sha=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip(),patches=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in out.glob('*.patch')]))
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))

