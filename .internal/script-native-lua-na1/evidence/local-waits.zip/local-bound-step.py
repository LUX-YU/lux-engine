from pathlib import Path
s=Path(r'E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1/source')
p=s/'engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptEventWaits.hpp'
t=p.read_text().replace(': owner_(std::exchange(other.owner_, nullptr)), begin_(other.begin_), end_(other.end_), endpoint_(other.endpoint_) {}', ': owner_(std::exchange(other.owner_, nullptr)), begin_(other.begin_),\n                  end_(other.end_), endpoint_(other.endpoint_) {}')
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/scripting/cpp_static/src/CppStaticScriptBridge.cpp'
t=p.read_text().replace('view->behavior == nullptr || !view->behavior->hasInvocationAuthority() || !view->current || view->publication == 0U;', 'view->behavior == nullptr || !view->behavior->hasInvocationAuthority() ||\n                !view->current || view->publication == 0U;')
# A checked binder and one shared execution kernel; the dynamic entry remains useful
# for callers that choose an ordinal at run time, never as a legacy mode.
a=t.index('    const auto error = [ordinal]',t.index('ScriptCoroutineContext::invokeSyncStep'))
b=t.index('\nnamespace\n{',a)
t=t[:a]+'''    const auto entry = resolveSyncStep(ordinal, shape);
    if (!entry) return lux::cxx::unexpected(entry.error());
    return invokeResolvedSyncStep(**entry, ordinal, arguments, output);
}

lux::cxx::expected<const PreparedScriptSyncStep*, ScriptSyncStepError>
ScriptCoroutineContext::resolveSyncStep(std::uint32_t ordinal, const ScriptSyncStepShape& shape) noexcept
{
    const auto error = [ordinal](EScriptSyncStepError category, std::int32_t status) {
        return lux::cxx::unexpected(ScriptSyncStepError{ordinal, category, status});
    };
    const auto* view = sync_steps_;
    const bool invalid_context = active_step_ == nullptr || view == nullptr;
    if (invalid_context) return error(EScriptSyncStepError::INVALID_CONTEXT, -32001);
    if (ordinal >= view->steps.size()) return error(EScriptSyncStepError::INVALID_STEP, -32002);
    const auto& entry = view->steps[ordinal];
    if (entry.shape != &shape) return error(EScriptSyncStepError::SIGNATURE_MISMATCH, -32003);
    return &entry;
}

lux::cxx::expected<void, ScriptSyncStepError>
ScriptCoroutineContext::invokeResolvedSyncStep(const PreparedScriptSyncStep& entry, std::uint32_t ordinal,
                                              const void* const* arguments, void* output) noexcept
{
    const auto error = [ordinal](EScriptSyncStepError category, std::int32_t status) {
        return lux::cxx::unexpected(ScriptSyncStepError{ordinal, category, status});
    };
    if (active_step_ == nullptr) return error(EScriptSyncStepError::INVALID_CONTEXT, -32001);
    // No user code between capture and this check. Later checks always validate
    // the original capture, including Lua stack growth and converter reentry.
    const auto qualification = sync_steps_->behavior->captureInvocation();
    if (!detail::ScriptRuntimeAccess::hasCapturedInvocation(qualification))
        return error(EScriptSyncStepError::INVOCATION_REVOKED, -32004);
    const auto status = entry.invoke(entry.context, arguments, output, qualification);
    if (status != 0) return error(EScriptSyncStepError::BACKEND_FAILURE, status);
    if (!qualification.valid()) return error(EScriptSyncStepError::INVOCATION_REVOKED, -32004);
    return {};
}
''' +t[b:]
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/scripting/cpp_static/include/lux/engine/simulation/scripting/cpp_static/ScriptSyncStepCall.hpp'
t=p.read_text()
a=t.index('            const std::array<const void*',t.index('[[nodiscard]] static Result invoke'))
b=t.index('\n    };',a)
x=t[a:b].replace('context.invokeSyncStep(ordinal, Shape, arguments.data(), nullptr)', 'call(arguments.data(), nullptr)').replace('context.invokeSyncStep(ordinal, Shape, arguments.data(), &value)', 'call(arguments.data(), &value)')
t=t[:a]+'''            return apply([&](const void* const* arguments, void* result) noexcept {
                return context.invokeSyncStep(ordinal, Shape, arguments, result);
            }, values...);
        }

        template <class Call>
        [[nodiscard]] static Result apply(Call&& call, const std::remove_cvref_t<Args>&... values) noexcept
        {
'''+x+t[b:]
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/scripting/cpp_static/include/lux/engine/simulation/scripting/cpp_static/ScriptCoroutine.hpp'
t=p.read_text().replace('    class ScriptCoroutine;\n','''    class ScriptCoroutineContext;

    // An immutable binding borrowed by one live task. Like its context, this must
    // not escape the owning coroutine's lifetime. It conveys no call permission.
    template <class Signature>
    class ScriptCoroutineSyncStep final
    {
    public:
        template <class... Args> [[nodiscard]] auto operator()(Args&&... args) const noexcept;
    private:
        friend class ScriptCoroutineContext;
        ScriptCoroutineSyncStep(ScriptCoroutineContext& context, const PreparedScriptSyncStep& entry,
            std::uint32_t ordinal) noexcept : context_(&context), entry_(&entry), ordinal_(ordinal) {}
        ScriptCoroutineContext* context_{};
        const PreparedScriptSyncStep* entry_{};
        std::uint32_t ordinal_{};
    };

    class ScriptCoroutine;
''',1)
pos=t.index('        [[nodiscard]] ScriptCoroutineFailure fail(')
t=t[:pos]+'''        template <class Signature>
        [[nodiscard]] lux::cxx::expected<ScriptCoroutineSyncStep<Signature>, ScriptSyncStepError>
        bindStep(std::uint32_t ordinal) noexcept
        {
            const auto entry = resolveSyncStep(ordinal, detail::ScriptSyncStepCall<Signature>::Shape);
            if (!entry) return lux::cxx::unexpected(entry.error());
            return ScriptCoroutineSyncStep<Signature>{*this, **entry, ordinal};
        }

'''+t[pos:]
pos=t.index('      template <class Signature> friend struct detail::ScriptSyncStepCall;')
t=t[:pos]+'''      [[nodiscard]] lux::cxx::expected<const PreparedScriptSyncStep*, ScriptSyncStepError>
      resolveSyncStep(std::uint32_t ordinal, const ScriptSyncStepShape& shape) noexcept;
      [[nodiscard]] lux::cxx::expected<void, ScriptSyncStepError>
      invokeResolvedSyncStep(const PreparedScriptSyncStep& entry, std::uint32_t ordinal,
          const void* const* arguments, void* output) noexcept;
      template <class Signature> friend class ScriptCoroutineSyncStep;
'''+t[pos:]
pos=t.index('    struct ScriptCoroutinePromiseAccess final') if '    struct ScriptCoroutinePromiseAccess final' in t else t.index('    struct ScriptCoroutinePromiseAccess\n')
t=t[:pos]+'''    template <class Signature>
    template <class... Args>
    auto ScriptCoroutineSyncStep<Signature>::operator()(Args&&... args) const noexcept
    {
        return detail::ScriptSyncStepCall<Signature>::apply(
            [this](const void* const* arguments, void* result) noexcept {
                return context_->invokeResolvedSyncStep(*entry_, ordinal_, arguments, result);
            }, std::forward<Args>(args)...
        );
    }

'''+t[pos:]
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/scripting/native_lua_tasks/benchmark/Tasks.hpp'
t=p.read_text().replace('    ScriptCoroutine longTask(ScriptCoroutineContext &c) noexcept\n    {', '''    ScriptCoroutine longTask(ScriptCoroutineContext &c) noexcept
    {
        auto bound = c.bindStep<void(std::int32_t)>(0U);
        if (!bound) co_await c.fail(bound.error());''')
a=t.index('    ScriptCoroutine longTask(');b=t.index('    LUX_METHOD',a)
x=t[a:b].replace('step<void(std::int32_t)>(c, 0U, payload)', '(*bound)(payload)');t=t[:a]+x+t[b:]
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/scripting/native_lua_tasks/test/NativeTask.hpp'
t=p.read_text().replace('        const auto count = mode == 3U ? 32U : 1U;', '''        auto bound = context.bindStep<std::int32_t(std::int32_t)>(0U);
        if (!bound) co_await context.fail(bound.error());
        const auto count = mode == 3U ? 32U : 1U;''',1)
t=t.replace('const auto value = context.callStep<std::int32_t(std::int32_t)>(0U, payload);','const auto value = (*bound)(payload);',1)
p.write_text(t,encoding='utf-8')
