from pathlib import Path
import re
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source')
p=r/'engine/toolchain/flowforge/test/script_artifact_compiler_test.cpp';t=p.read_text()
for f,c in [('event_wait_frame','event_wait_instance'),('async_frame','async_instance'),('control_frame','control_instance'),('result_frame','result_instance'),('function_frame','function_instance'),('borrow_frame','borrow_instance')]:
 t=re.sub(r'(\.start\(\s*)(&'+f+r'\b)',lambda m:m[1]+'&'+c+', '+m[2],t)
p.write_text(t)
p=r/'engine/domain/simulation/scripting/lua/test/lua_backend_test.cpp';t=p.read_text().replace('            0U,\n            nullptr,\n            nullptr};','            0U,\n            nullptr};');p.write_text(t)
# Layout declarations and expanded invocation lines use one semantic split.
for p in (r/'engine').rglob('*'):
 if p.suffix not in ('.cpp','.hpp'): continue
 t=p.read_text(encoding='utf-8-sig'); lines=t.splitlines(); change=False
 for i,line in enumerate(lines):
  if len(line)<=120:continue
  indent=line[:len(line)-len(line.lstrip())]
  if '.invoke(' in line or '.start(' in line:
   pos=line.find('(',line.find('.invoke' if '.invoke(' in line else '.start'))+1
   lines[i]=line[:pos]+'\n'+indent+'    '+line[pos:];change=True
  elif '->invoke(' in line:
   pos=line.index('->invoke(')+9; lines[i]=line[:pos]+'\n'+indent+'    '+line[pos:];change=True
  elif 'StepAdapter adapter{' in line:
   lines[i]=line.replace('StepAdapter adapter{','StepAdapter adapter{\n'+indent+'    '); change=True
  elif 'int start(' in line:
   lines[i]=line.replace('int start(','int start(\n'+indent+'    ').replace('lux_script_call_frame* call,','lux_script_call_frame* call,\n'+indent+'   ');change=True
  elif 'llvm::StructType::create(ctx' in line:
   lines[i]=line.replace('llvm::StructType::create(ctx,','llvm::StructType::create(\n'+indent+'    ctx,');change=True
 if change:p.write_text('\n'.join(lines)+'\n')
