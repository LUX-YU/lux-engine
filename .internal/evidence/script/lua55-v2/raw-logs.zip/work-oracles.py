from pathlib import Path
import csv,json
r=Path(__file__).parent;root=r/'final-costs';runs=json.loads((root/'runs.json').read_text());records=[]
for run in runs:
 scene=run['scene'];p=root/f"{scene}-{run['pair']}-{run['side']}.csv"
 if scene=='record':continue
 rows=list(csv.DictReader(p.open()));fields=list(run['business']);expected=run['actual_operations']
 if scene in ['event','nextstep','scalar']:
  for field in ['calls']+(['resumes','suspensions'] if scene!='scalar' else ['ability_calls']):
   assert all(int(row[field])==10000*(1000+i+1) for i,row in enumerate(rows)),(p,field)
  actual=int(rows[-1]['calls'])-(int(rows[0]['calls'])-10000)
 else:actual=len(rows)
 assert actual==expected,(p,actual,expected)
 observed_exe=scene=='physics' or rows[0].get('allocation_accounting')=='1'
 records.append(dict(scene=scene,pair=run['pair'],side=run['side'],actual_operations=actual,
  batches=len(rows),per_batch_counters_verified=True,exe_allocations_observed=observed_exe,
  exe_allocations=sum(int(x['allocations']) for x in rows) if observed_exe else None,
  vm_allocations_observed=False,vm_allocations=None))
 if run['side']=='candidate':
  other=list(csv.DictReader((root/f"{scene}-{run['pair']}-baseline.csv").open()))
  assert len(other)==len(rows)
  for i,(a,b) in enumerate(zip(rows,other)):
   assert all(a[k]==b[k] for k in fields),(scene,run['pair'],i,[(k,a[k],b[k]) for k in fields if a[k]!=b[k]])
(root/'work-oracles.json').write_text(json.dumps(records,indent=2));print('ALL_PER_BATCH_WORK_ORACLES_PASS',len(records))
