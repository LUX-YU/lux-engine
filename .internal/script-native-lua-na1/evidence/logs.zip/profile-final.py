import csv,ctypes as ct,json,os,re,subprocess,time
from pathlib import Path
r=Path(__file__).parent;out=r/'profiles';out.mkdir(exist_ok=False)
k=ct.WinDLL('kernel32');k.GetCurrentProcess.restype=ct.c_void_p;k.SetProcessAffinityMask.argtypes=[ct.c_void_p,ct.c_size_t];assert k.SetProcessAffinityMask(k.GetCurrentProcess(),16)
vtune='D:/Softwares/Intel/oneAPI/vtune/2026.3/bin64/vtune.exe'
records=[]
for leg in ['P1','P3']:
 for side in ['A','B']:
  directory=out/f'{leg}-{side}';directory.mkdir();image=r/'images'/(side+'-common');data=directory/'business.csv'
  env=dict(os.environ);env['PATH']=';'.join([str(image),'D:/Development/vcpkg/installed/x64-windows/bin',*[p for p in env['PATH'].split(';') if 'CodeRepos' not in p and 'vcpkg' not in p]])
  app=[str(image/'native_lua_complete_tasks.exe'),'--case',leg,'--size','10000','--warmups','1000' if leg=='P1' else '75','--batches','2000' if leg=='P1' else '250','--roi','on','--output',str(data)]
  command=[vtune,'-collect','hotspots','-knob','sampling-mode=sw','-knob','enable-stack-collection=true','-knob','enable-characterization-insights=false','-start-paused','-return-app-exitcode','-result-dir',str(directory/'result'),'-search-dir',str(image),'-source-search-dir',str(r/'qualification-source'),'--',*app]
  started=time.monotonic()
  with (directory/'collect.log').open('wb') as f:code=subprocess.call(command,stdout=f,stderr=subprocess.STDOUT,env=env)
  text=(directory/'collect.log').read_text(errors='replace');rows=list(csv.DictReader(data.open())) if data.exists() else []
  valid=code==0 and len(rows)==(2000 if leg=='P1' else 250) and 'ROI_BEGIN' in text and 'ROI_END' in text and 'errors=0 backlog=0' in text
  record=dict(leg=leg,side=side,command=command,exit=code,valid=valid,seconds=time.monotonic()-started,scope='ITT exact complete-wave ROI; preparation, warmup, oracle and shutdown excluded',PMU=False)
  records.append(record);(out/'runs.json').write_text(json.dumps(records,indent=2));print('PROFILE',leg,side,code,valid,flush=True)
  if not valid:continue
  for report in ['summary','hotspots','top-down']:
   args=[vtune,'-report',report,'-r',str(directory/'result'),'-format','csv','-csv-delimiter','comma','-limit','10000','-report-output',str(directory/(report+'.csv'))]
   if report!='summary':args+=['-filter','process=native_lua_complete_tasks.exe']
   with (directory/(report+'.log')).open('wb') as f:export=subprocess.call(args,stdout=f,stderr=subprocess.STDOUT,env=env)
   record[report+'_exit']=export;(out/'runs.json').write_text(json.dumps(records,indent=2))
