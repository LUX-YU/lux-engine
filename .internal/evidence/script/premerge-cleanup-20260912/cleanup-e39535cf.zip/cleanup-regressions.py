from pathlib import Path
s=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1/source')
def once(t,a,b):
 assert t.count(a)==1,(a[:70],t.count(a));return t.replace(a,b)
p=s/'engine/domain/simulation/scripting/lua/test/lua_value_runtime_test.cpp';t=p.read_text();t='#include <lua.hpp>\n'+t
old='static int resumeAuthorityCase(bool stop)\n{'
new='''enum class EConversionAuthorityCase
{
    RESUME_RETIRE, RESUME_STOP, SYNC_VALID, SYNC_RETIRE, SYNC_STOP, SYNC_ERROR
};
static bool conversion_synchronous{};
static bool conversion_retains_instance{};
static bool conversion_raises_error{};
static std::size_t conversion_body_calls{};

static int conversionAuthorityCase(EConversionAuthorityCase selected)
{
    const bool stop = selected == EConversionAuthorityCase::RESUME_STOP ||
        selected == EConversionAuthorityCase::SYNC_STOP;
    const bool synchronous = selected != EConversionAuthorityCase::RESUME_RETIRE &&
        selected != EConversionAuthorityCase::RESUME_STOP;
    const bool retains_instance = selected == EConversionAuthorityCase::SYNC_VALID;
    const bool raises_error = selected == EConversionAuthorityCase::SYNC_ERROR;'''
t=once(t,old,new)
start=t.index('static int conversionAuthorityCase');end=t.index('\nint main(int argc',start);body=t[start:end]
body=once(body,'        if (resume_stop) assert(resume_system->requestStop());\n        else resume_registry->destroy(resume_entity);','''        if (conversion_raises_error)
        {
            luaL_error(state, "injected input converter failure");
            return false;
        }
        if (resume_stop) assert(resume_system->requestStop());
        else if (!conversion_retains_instance) resume_registry->destroy(resume_entity);''')
body=once(body,'        return original.push(state, value);','''        const bool pushed = original.push(state, value);
        if (pushed && conversion_synchronous)
        {
            lua_pushcfunction(state, +[](lua_State*) -> int { ++conversion_body_calls; return 0; });
            lua_setfield(state, -2, "audit");
        }
        return pushed;''')
body=once(body,'    constexpr std::string_view code =','    constexpr std::string_view resume_code =')
needle='    const auto bytes = std::as_bytes(std::span{code.data(), code.size()});'
body=once(body,needle,'''    constexpr std::string_view sync_code =
        "return {tick=function(self,p) p.audit();"
        "assert(p.key==31 and p.velocity.x==2 and p.velocity.y==3 and p.mode==3);"
        "assert(lux.Values.zeroArgumentProbe()==42) end}";
    if (synchronous)
    {
        description.body = lux::rdesc::LuaSourceScript{"Resume"};
        description.exports.front().args = {
            lux::rdesc::makeScriptValueType<ValuePose>(lux::semantic::EValuePass::CONST_REF)};
    }
    const auto code = synchronous ? sync_code : resume_code;
'''+needle)
body=once(body,'{{kTick, HookScriptTarget{kOwner, kHook}}}}};','''{{kTick, synchronous ? ScriptBindingTarget{EventScriptTarget{kOwner, event_id}}
                            : ScriptBindingTarget{HookScriptTarget{kOwner, kHook}}}}}};''')
# Alias type name is checked below against the public binding definition.
body=once(body,'    assert(dispatchRuntimeHook(*system, hook) == 1U);\n    assert(system->activeContinuationCount() == 1U && system->stats().active_event_waiters == 1U);','''    if (!synchronous)
    {
        assert(dispatchRuntimeHook(*system, hook) == 1U);
        assert(system->activeContinuationCount() == 1U && system->stats().active_event_waiters == 1U);
    }''')
body=once(body,'    assert(deliverRuntimeEvent(*system, event) == 1U);\n','')
body=once(body,'    resume_conversions = 0U;','''    resume_conversions = 0U;
    conversion_synchronous = synchronous;
    conversion_retains_instance = retains_instance;
    conversion_raises_error = raises_error;
    conversion_body_calls = 0U;
    assert(deliverRuntimeEvent(*system, event) == 1U);''')
body=once(body,'    assert(stable);\n    assert(resume_conversions == 1U && provider.zero_calls == static_cast<std::size_t>(stop));','''    assert(synchronous && stop ? !stable : static_cast<bool>(stable));
    const auto expected_calls = static_cast<std::size_t>(stop || retains_instance);
    std::printf("CONVERSION_AUTHORITY mode=%u conversions=%zu body=%zu provider=%zu expected=%zu\\n",
        static_cast<unsigned>(selected), resume_conversions, conversion_body_calls, provider.zero_calls, expected_calls);
    assert(resume_conversions == 1U && provider.zero_calls == expected_calls);
    if (synchronous) assert(conversion_body_calls == expected_calls);''')
body=once(body,'    assert(released.vm_coroutine_creations == 1U && released.vm_coroutine_releases == 1U);','''    const auto expected_threads = static_cast<std::size_t>(!synchronous);
    assert(released.vm_coroutine_creations == expected_threads && released.vm_coroutine_releases == expected_threads);''')
body=once(body,'    std::printf("RESUME_AUTHORITY stop=%u converted=1 provider=%zu roots=1 released=1 backlog=0 PASS\\n",\n        stop, provider.zero_calls);','''    std::printf("CONVERSION_CLEANUP synchronous=%u provider=%zu roots=%zu released=%zu backlog=0 PASS\\n",
        synchronous, provider.zero_calls, expected_threads, expected_threads);''')
body=once(body,'    if (leaf_stats.leaf_statistics_enabled) assert(leaf_stats.leaf_return_yields == 1U);','    if (leaf_stats.leaf_statistics_enabled) assert(leaf_stats.leaf_return_yields == expected_threads);')
t=t[:start]+body+t[end:]
t=once(t,'return resumeAuthorityCase(false);','return conversionAuthorityCase(EConversionAuthorityCase::RESUME_RETIRE);')
t=once(t,'return resumeAuthorityCase(true);','return conversionAuthorityCase(EConversionAuthorityCase::RESUME_STOP);')
needle='    static_assert(!std::is_default_constructible_v<ValueToken>);'
t=once(t,needle,'''    if (argc == 2 && std::string_view{argv[1]} == "--sync-valid")
        return conversionAuthorityCase(EConversionAuthorityCase::SYNC_VALID);
    if (argc == 2 && std::string_view{argv[1]} == "--sync-retire")
        return conversionAuthorityCase(EConversionAuthorityCase::SYNC_RETIRE);
    if (argc == 2 && std::string_view{argv[1]} == "--sync-stop")
        return conversionAuthorityCase(EConversionAuthorityCase::SYNC_STOP);
    if (argc == 2 && std::string_view{argv[1]} == "--sync-error")
        return conversionAuthorityCase(EConversionAuthorityCase::SYNC_ERROR);
'''+needle)
p.write_text(t)
p=s/'engine/domain/simulation/scripting/lua/CMakeLists.txt';t=p.read_text();t=once(t,'target_link_libraries(simulation_script_lua_value_runtime_test PRIVATE simulation_script_lua_value_fixtures)','target_link_libraries(simulation_script_lua_value_runtime_test PRIVATE simulation_script_lua_value_fixtures LuxLua55::Runtime)')
t+='''\nforeach(_sync_case valid retire stop error)
    add_test(NAME simulation_script_lua_sync_${_sync_case}_test
        COMMAND simulation_script_lua_value_runtime_test --sync-${_sync_case})
endforeach()
''';p.write_text(t)
# Real runtime boundary regression; both common completion and owner-local admission.
p=s/'engine/domain/simulation/builtin/script/test/script_system_continuation_test.cpp';t=p.read_text()
new='''    void testTimerDurationBoundaries()
    {
        const double exclusive_seconds = std::ldexp(1.0, 63) / 1'000'000'000.0;
        const std::array durations{std::nextafter(exclusive_seconds, 0.0), exclusive_seconds,
            std::nextafter(exclusive_seconds, std::numeric_limits<double>::infinity())};
        for (const bool local : {false, true})
        {
            for (std::size_t i{}; i < durations.size(); ++i)
            {
                Harness harness{false};
                configureTimerHarness(harness);
                auto& backend = harness.backend_state;
                backend.local_timer = local;
                backend.simulation_timer = true;
                backend.timer_seconds = durations[i];
                auto system = harness.create(limits(), {});
                assert(system && system->prepare());
                assert(dispatchRuntimeHook(*system, harness.hook) == 1U);
                const auto stats = system->stats();
                const bool accepted = i == 0U;
                std::printf("TIMER_BOUNDARY local=%u index=%zu waits=%zu errors=%llu expected_accept=%u\\n",
                    local, i, stats.simulation_delay_waits, stats.invocation_failures, accepted);
                assert(stats.simulation_delay_waits == static_cast<std::size_t>(accepted));
                assert(system->activeAwaitableCount() == static_cast<std::size_t>(accepted));
                assert(system->activeContinuationCount() == static_cast<std::size_t>(accepted));
                assert(stats.invocation_failures == static_cast<std::size_t>(!accepted));
                if (!accepted)
                    assert(system->failures().front().status == static_cast<int>(EScriptDelayStatus::DURATION_OVERFLOW));
                assert(system->shutdown());
                assert(backend.creates == 1U && backend.destroys == 1U && backend.continuation_destroys == 1U);
                assert(system->activeAwaitableCount() == 0U && system->activeContinuationCount() == 0U);
            }
        }
    }

'''
t=once(t,'    void testLocalTimerCapacityAndReuse()\n',new+'    void testLocalTimerCapacityAndReuse()\n');t=once(t,'int main()\n{','int main()\n{\n    testTimerDurationBoundaries();');p.write_text(t)
# Byte preservation across every storage relationship, including repeated inline resize.
p=s/'engine/domain/simulation/scripting/core/test/class_storage_test.cpp';t=p.read_text();t='#include <lux/engine/simulation/scripting/ScriptRuntime.hpp>\n'+t
idx=t.index('int main()');t=t[:idx]+'''static void testOwnedBytes()
{
    using lux::simulation::script::ScriptOwnedBytes;
    ScriptOwnedBytes bytes;
    assert(bytes.resize(8U));
    for (std::size_t i{}; i < 8U; ++i) bytes.data()[i] = static_cast<std::byte>(i + 1U);
    auto* inline_address = bytes.data();
    assert(bytes.resize(16U) && bytes.data() == inline_address);
    for (std::size_t i{}; i < 8U; ++i) assert(bytes.data()[i] == static_cast<std::byte>(i + 1U));
    assert(bytes.resize(64U, 32U) && bytes.data() != inline_address);
    for (std::size_t i{}; i < 8U; ++i) assert(bytes.data()[i] == static_cast<std::byte>(i + 1U));
    assert(bytes.resize(4U) && bytes.data() == inline_address);
    for (std::size_t i{}; i < 4U; ++i) assert(bytes.data()[i] == static_cast<std::byte>(i + 1U));
    assert(!bytes.resize(4U, 3U) && bytes.size() == 4U);
    ScriptOwnedBytes moved{std::move(bytes)};
    assert(bytes.empty() && moved.size() == 4U);
    for (std::size_t i{}; i < 4U; ++i) assert(moved.data()[i] == static_cast<std::byte>(i + 1U));
    auto& self = moved;
    moved = std::move(self);
    assert(moved.size() == 4U && moved.resize(0U) && moved.empty());
    assert(moved.resize(64U, 32U));
    moved.data()[0] = std::byte{17};
    auto* spill = moved.data();
    bytes = std::move(moved);
    assert(moved.empty() && bytes.data() == spill && bytes.data()[0] == std::byte{17});
    assert(bytes.resize(0U) && bytes.empty());
    std::puts("OWNED_BYTES inline-grow spill inline-shrink invalid-align move self-move empty PASS");
}

'''+t[idx:];t=once(t,'int main()\n{','int main()\n{\n    testOwnedBytes();');p.write_text(t)
print('added formal regressions')
