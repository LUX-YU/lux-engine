from pathlib import Path
import hashlib, json, shutil, subprocess

source=Path('E:/RenderV2Rebuild/Layer/v/src')
evidence=Path('E:/RenderV2Rebuild/Layer/evidence/L4/sdk-sync')
assert not evidence.exists(), 'Do not overwrite the original backup'
assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()=='b427f9d5ac99bcec42a154e6a865585c058a3365'
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain']).strip()
files=subprocess.check_output(['git','-C',str(source),'ls-files','modules/function/render','modules/platform/process/include'],text=True).splitlines()
headers={p.split('/include/',1)[1]: source/p for p in files if '/include/' in p and p.endswith('.hpp')}
removed=['lux/engine/render/data/Wire.hpp','lux/engine/render/features/Program.hpp','lux/engine/render/features/Texture.hpp']
prefixes=[Path('E:/SyncForder/CodeRepos/install')/p for p in ('Debug/include','RelWithDebInfo/include','Android/lux-engine/include')]
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
records=[]
for index,prefix in enumerate(prefixes):
    for relative in sorted(set(headers)|set(removed)):
        target=(prefix/relative).resolve()
        assert target.is_relative_to(prefix.resolve())
        before=digest(target)
        backup=evidence/'backup'/str(index)/relative
        if target.exists():
            backup.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(target,backup)
        if relative in headers:
            target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(headers[relative],target)
            assert digest(target)==digest(headers[relative])
        elif target.exists():
            target.unlink()
        records.append(dict(target=str(target),backup=str(backup) if before else None,before_sha256=before,after_sha256=digest(target),source=str(headers.get(relative,''))))
evidence.mkdir(parents=True,exist_ok=True)
(evidence/'manifest.json').write_text(json.dumps(dict(implementation='b427f9d5ac99bcec42a154e6a865585c058a3365',headers=len(headers),removed=removed,files=records),indent=2)+'\n')
print(f'{len(headers)} public headers synchronized to 3 prefixes; {len(removed)} obsolete paths removed; backups retained')
