import json,statistics
from pathlib import Path
r=Path('..').resolve();a=json.loads((r/'performance/validated-costs.json').read_text())['comparisons'];b=json.loads((r/'performance-final/validated-costs.json').read_text())['comparisons']
lines=['| 场景 | 初轮 4fe 配对中位差距 | 最终配对中位差距及范围 | 最终 B0/B2 全批中位 ms | 每批实际操作数 | B0/B2 ns/操作 |','|---|---:|---:|---:|---:|---:|']
for old,new in zip(a,b):
 assert old['case']==new['case']
 key='completions' if 'fanout' in new['case'] else 'actual_new_calls'
 pa=new['pairs'];n=pa[0]['baseline']['counts'][key]
 av=statistics.median(p['baseline']['ns_per_operation'][key] for p in pa);bv=statistics.median(p['candidate']['ns_per_operation'][key] for p in pa)
 lo,hi=new['range_percent']
 lines.append(f"| {new['case']} | {old['median_percent']:+.2f}% | {new['median_percent']:+.2f}% [{lo:+.2f}, {hi:+.2f}] | {new['median_baseline_ns']/1e6:.3f} / {new['median_candidate_ns']/1e6:.3f} | {n:,} | {av:.3f} / {bv:.3f} |")
 print(new['case'],n,round(av,3),round(bv,3),'median paired delta',round(statistics.median((p['candidate']['total_ns']-p['baseline']['total_ns'])/n for p in pa),3))
lines += ['', 'B0 为上述 cd7160ff 实际参照，B2 为 6086e4a4；两者 CSV 身份和工作量经汇总脚本校验。',
'初轮与最终是分别相对参照的两轮配对，不是把两轮中位数之差冒充同一组直接 B1→B2 实验。',
'Lua Ability 最终五组均为正差距，仍有新增且未充分解释的成本，**性能未收口，待用户审阅接受或另行授权处理**。',
'初轮 Lua Event +6.48% 在最终组中位数未重现，但最终有 +44.68% 的配对离群；不能据此宣称消除回退或性能等价。',
'其他小差距和宽分布按原样登记，五个进程对不足以证明等价，也不按每项残余开启新调优项目。',
'旧驱动完整保留同量工作：每批 Hook candidates 为 frames×10,000；Flow Event/Lua coroutine 每帧实际新调用和恢复为预算2,000，backlog8,000；',
'Lua Event 每帧实际新调用与恢复10,000、backlog0；fan-out 为一次 occurrence 完成10,000个等待者并按原预算排空。']
p=r/'source/.internal/script-system-sr5-closeout-2026-09-07.zh-CN.md';t=p.read_text();assert '<!-- FINAL_PERFORMANCE_TABLE -->' in t;t=t.replace('<!-- FINAL_PERFORMANCE_TABLE -->','\n'.join(lines));p.write_text(t)
(r/'diagnostics/final-performance-table.md').write_text('\n'.join(lines))
