from pathlib import Path
r=Path.cwd()
for name in ['machine.py','class-layout.py','class-layout.ps1','new-incremental.py','new-incremental.ps1','relocated.ps1']:
 t=(r/('next-'+name)).read_text(encoding='utf-8-sig').replace('next-','local-')
 if name=='machine.py':t=t.replace("['D']","['E']")
 (r/('local-'+name)).write_text(t)
