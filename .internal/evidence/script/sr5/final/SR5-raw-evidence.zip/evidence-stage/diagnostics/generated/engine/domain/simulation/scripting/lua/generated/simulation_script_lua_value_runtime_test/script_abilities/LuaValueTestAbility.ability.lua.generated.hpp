#pragma once
// Generated typed Lua projection. Include the matching .ability.generated.hpp first.
#include <lux/engine/simulation/scripting/lua/LuaScriptAbilityProjection.hpp>

#include <array>
#include <type_traits>
#include <utility>

namespace lux::script::lua
{

    template <>
    struct ScriptAbilityLuaTraits<::lux::simulation::script::test::LuaValueTestAbility> final
    {
        using AbilityTraits = ScriptAbilityTraits<::lux::simulation::script::test::LuaValueTestAbility>;
        using Policy = typename ScriptAbilityLuaPolicy<::lux::simulation::script::test::LuaValueTestAbility>::Type;

        using Values_echo = LuaAbilityValueSignature<Policy, lux::simulation::script::test::ValuePose, const lux::simulation::script::test::ValuePose &>;
        [[nodiscard]] static int echo(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, lux::simulation::script::test::ValuePose, const lux::simulation::script::test::ValuePose &>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, const lux::simulation::script::test::ValuePose & value) noexcept -> lux::simulation::script::test::ValuePose
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.echo(access.context, value);
                }
            );
        }

        using Values_angle = LuaAbilityValueSignature<Policy, lux::simulation::script::test::ValueAngle, lux::simulation::script::test::ValueAngle>;
        [[nodiscard]] static int angle(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, lux::simulation::script::test::ValueAngle, lux::simulation::script::test::ValueAngle>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, lux::simulation::script::test::ValueAngle value) noexcept -> lux::simulation::script::test::ValueAngle
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.angle(access.context, value);
                }
            );
        }

        using Values_inspect = LuaAbilityValueSignature<Policy, int, const lux::simulation::script::test::ValueConstRecord &>;
        [[nodiscard]] static int inspect(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, int, const lux::simulation::script::test::ValueConstRecord &>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, const lux::simulation::script::test::ValueConstRecord & value) noexcept -> int
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.inspect(access.context, value);
                }
            );
        }

        using Values_token = LuaAbilityValueSignature<Policy, int, const lux::simulation::script::test::ValueToken &, int>;
        [[nodiscard]] static int token(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, int, const lux::simulation::script::test::ValueToken &, int>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, const lux::simulation::script::test::ValueToken & value, int next) noexcept -> int
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.token(access.context, value, next);
                }
            );
        }

        inline static constexpr std::array<ScriptAbilityLuaMethodProjection, AbilityTraits::Methods.size()> Methods{
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.lua_values.echo"},
                &echo, Values_echo::Parameters, Values_echo::Results
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.lua_values.angle"},
                &angle, Values_angle::Parameters, Values_angle::Results
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.lua_values.inspect"},
                &inspect, Values_inspect::Parameters, Values_inspect::Results
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.lua_values.token"},
                &token, Values_token::Parameters, Values_token::Results
            }
        };
    };
} // namespace lux::script::lua
