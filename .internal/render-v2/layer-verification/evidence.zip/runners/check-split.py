from pathlib import Path
import re,subprocess,json,hashlib
root=Path('E:/RenderV2Rebuild/Layer/source');base=root/'modules/function/render/runtime'
old=subprocess.check_output(['git','-C',str(root),'show','HEAD:modules/function/render/runtime/src/RenderServer.cpp'],text=True)
for a,b in {'WireView':'RetainableEncodedDataView','OwnedWireBytes':'lux::cxx::SharedBytes<>','max_wire_bytes':'max_encoded_bytes','kInvalidWire':'kInvalidEncoding'}.items():old=re.sub(r'\b'+a+r'\b',lambda _:b,old)
mask_pattern=r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|\x27(?:\\.|[^\x27\\])*\x27'
def mask(t):return re.sub(mask_pattern,lambda m:' '*len(m[0]),t)
def body(t,start):
 m=mask(t);p=m.index('(',start);depth=0
 for i in range(p,len(m)):
  if m[i]=='(':depth+=1
  if m[i]==')':
   depth-=1
   if depth==0:break
 a=m.index('{',i);depth=0
 for b in range(a,len(m)):
  if m[b]=='{':depth+=1
  if m[b]=='}':
   depth-=1
   if depth==0:return t[a:b+1]
def tokens(t):
 t=re.sub(r'//[^\n]*|/\*[\s\S]*?\*/','',t)
 return re.findall(r'"(?:\\.|[^"\\])*"|\w+|[^\s]',t)
results=[]
for p in sorted((base/'src').glob('Server*.cpp')):
 new=p.read_text()
 for match in re.finditer(r'RenderServer::Impl::(\w+)\(',new):
  name=match[1]
  # Methods that were already out-of-class are checked by the same signature.
  before=re.search(r'RenderServer::Impl::'+name+r'\(',old)
  if before is None:before=re.search(r'^        (?=\S)[^\n;{]*\b'+name+r'\(',old,re.M)
  assert before,name
  a,b=tokens(body(old,before.start())),tokens(body(new,match.start()))
  assert a==b,(name,p)
  results.append({'function':name,'file':str(p.relative_to(root)),'body_token_sha256':hashlib.sha256(' '.join(b).encode()).hexdigest()})
# Member ownership and destruction order do not change when moving the type definition.
a=old[old.index('        RenderServerConfig config;'):old.index('        Impl(RenderServerConfig')]
h=(base/'pinclude/ServerImpl.hpp').read_text();b=h[h.index('        RenderServerConfig config;'):h.index('        Impl(')]
assert tokens(a)==tokens(b),'Impl members'
out=Path('E:/RenderV2Rebuild/Layer/evidence/L3');out.mkdir(exist_ok=True)
(out/'split-proof.json').write_text(json.dumps({'matched_bodies':len(results),'impl_members_same_order':True,'functions':results},indent=2)+'\n')
print(len(results),'bodies unchanged; Impl members/order unchanged')
