from pathlib import Path
root=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source')
p=root/'modules/function/script/lua/include/lux/engine/function/script/lua/LuaValue.hpp'
s=p.read_text()
s=s.replace('static bool field(lua_State *, int, std::string_view) noexcept;', 'static bool field(lua_State*, int, std::string_view, const LuaCodecShape* = nullptr, std::size_t = 0U) noexcept;')
s=s.replace('static bool setField(lua_State *, int, std::string_view) noexcept;', 'static bool setField(lua_State*, int, std::string_view, const LuaCodecShape* = nullptr, std::size_t = 0U) noexcept;')
s=s.replace('LuaValueResult<T> field(std::string_view) const noexcept;', 'LuaValueResult<T> field(std::string_view, const detail::LuaCodecShape* = nullptr, std::size_t = 0U) const noexcept;')
s=s.replace('LuaValueResult<void> field(std::string_view, const T &) noexcept;', 'LuaValueResult<void> field(std::string_view, const T&, const detail::LuaCodecShape* = nullptr, std::size_t = 0U) noexcept;')
s=s.replace('LuaValueReader::field(std::string_view name) const noexcept', 'LuaValueReader::field(std::string_view name, const detail::LuaCodecShape* plan, std::size_t ordinal) const noexcept')
s=s.replace('LuaValueAccess::field(state_, index_, name)', 'LuaValueAccess::field(state_, index_, name, plan, ordinal)')
s=s.replace('LuaValueWriter::field(std::string_view name, const T &value) noexcept', 'LuaValueWriter::field(std::string_view name, const T& value, const detail::LuaCodecShape* plan, std::size_t ordinal) noexcept')
s=s.replace('LuaValueAccess::setField(state_, table_, name)', 'LuaValueAccess::setField(state_, table_, name, plan, ordinal)')
s=s.replace('input.template field<typename F::template Value<T>, Policy>(F::name);','input.template field<typename F::template Value<T>, Policy>(F::name, &shape_plan, I);')
s=s.replace('                LuaValueResult<void> result;\n                (([&]() noexcept {','                LuaValueResult<void> result;\n                std::size_t ordinal{};\n                (([&]() noexcept {')
s=s.replace('value.*Field::member);','value.*Field::member, &shape_plan, ordinal++);')
s=s.replace('                std::array<double, plainCount()> scratch;', '                if (input.depth_ + depth > 32U)\n                    return lux::cxx::unexpected(LuaValueFailure{ELuaValueError::CAPACITY});\n                std::array<double, plainCount()> scratch;')
s=s.replace('''            if constexpr (can_push && bounded && plainCount() > 1U && plainCount() <= 8192U)
                return detail::LuaValueAccess::writePlan(output.state_, plan(), std::addressof(value));''','''            if constexpr (can_push && bounded && plainCount() > 1U && plainCount() <= 8192U)
            {
                if (output.depth_ + depth > 32U)
                    return lux::cxx::unexpected(LuaValueFailure{ELuaValueError::CAPACITY});
                return detail::LuaValueAccess::writePlan(output.state_, plan(), std::addressof(value));
            }''')
p.write_text(s,encoding='utf-8',newline='\n')
p=root/'modules/function/script/lua/src/LuaValue.cpp';s=p.read_text()
a=s.index('            int readField(')
s=s[:a]+'''            void pushShapeKeys(lua_State* state, const LuaCodecShape& shape);
            void pushOperationKey(lua_State* state, Operation& operation)
            {
                if (operation.shape == nullptr) lua_pushlstring(state, operation.key.data(), operation.key.size());
                else
                {
                    pushShapeKeys(state, *operation.shape);
                    lua_rawgeti(state, -1, static_cast<lua_Integer>(operation.count) + 1);
                    lua_remove(state, -2);
                }
            }
'''+s[a:]
a=s.index('            int readField(');b=s.index('            void pushShapeKeys(lua_State* state, const LuaCodecShape& shape)\n',a)
s=s[:a]+s[a:b].replace('lua_pushlstring(state, operation.key.data(), operation.key.size());','pushOperationKey(state, operation);')+s[b:]
for name in ['field','setField']:
 s=s.replace('bool LuaValueAccess::'+name+'(lua_State *state, int index, std::string_view key) noexcept','bool LuaValueAccess::'+name+'(lua_State* state, int index, std::string_view key,\n            const LuaCodecShape* plan, std::size_t ordinal) noexcept')
 a=s.index('        bool LuaValueAccess::'+name+'(');b=s.index('\n        }',a)
 chunk=s[a:b].replace('            operation.key = key;','            operation.key = key;\n            operation.shape = plan;\n            operation.count = static_cast<int>(ordinal);')
 s=s[:a]+chunk+s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
