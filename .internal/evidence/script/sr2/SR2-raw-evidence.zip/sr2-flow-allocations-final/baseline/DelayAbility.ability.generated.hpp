#pragma once
// Generated canonical Script Ability descriptor, provider binder and C++ projection.
#include <lux/engine/function/script/ScriptAbility.hpp>
#include <lux/engine/function/script/ScriptAbilityAsync.hpp>
#include <lux/engine/function/script/ScriptAbilityCompletionAdapter.hpp>
#include <array>
#include <concepts>
#include <memory>
#include <utility>
#include <lux/engine/simulation/abilities/DelayAbility.hpp>

namespace lux::script
{

    template <>
    struct ScriptAbilityTraits<::lux::simulation::script::DelayAbility> final
    {
        using Ability = ::lux::simulation::script::DelayAbility;
        inline static constexpr ScriptApiContractIdView Contract{"lux.simulation.delay"};
        inline static constexpr auto Receiver = EScriptAbilityReceiverKind::PROVIDER_INSTANCE;

        struct Dispatch final
        {
            ScriptAbilityStartResult (*nextStep)(void*, ScriptAbilityCompletion<void>) noexcept{};
            ScriptAbilityStartResult (*seconds)(void*, double, ScriptAbilityCompletion<void>) noexcept{};
            ScriptAbilityStartResult (*simulationSeconds)(void*, double, ScriptAbilityCompletion<void>) noexcept{};
            ScriptAbilityStartResult (*realSeconds)(void*, double, ScriptAbilityCompletion<void>) noexcept{};
        };

        static_assert(noexcept(std::declval<Ability&>().nextStep()));

        static_assert(noexcept(std::declval<Ability&>().seconds(std::declval<double>())));

        static_assert(noexcept(std::declval<Ability&>().simulationSeconds(std::declval<double>())));

        static_assert(noexcept(std::declval<Ability&>().realSeconds(std::declval<double>())));



        inline static constexpr std::array<ScriptAbilityParameterDescription, 0> nextStepParameters{
        };
        inline static constexpr std::array<ScriptAbilityValueDescription, 0> nextStepResults{
        };
        inline static constexpr std::array<ScriptAbilityParameterDescription, 1> secondsParameters{
            ScriptAbilityParameterDescription{"duration", makeScriptAbilityValue<double>(EScriptAbilityValueLifetime::OWNED_VALUE)}
        };
        inline static constexpr std::array<ScriptAbilityValueDescription, 0> secondsResults{
        };
        inline static constexpr std::array<ScriptAbilityParameterDescription, 1> simulationSecondsParameters{
            ScriptAbilityParameterDescription{"duration", makeScriptAbilityValue<double>(EScriptAbilityValueLifetime::OWNED_VALUE)}
        };
        inline static constexpr std::array<ScriptAbilityValueDescription, 0> simulationSecondsResults{
        };
        inline static constexpr std::array<ScriptAbilityParameterDescription, 1> realSecondsParameters{
            ScriptAbilityParameterDescription{"duration", makeScriptAbilityValue<double>(EScriptAbilityValueLifetime::OWNED_VALUE)}
        };
        inline static constexpr std::array<ScriptAbilityValueDescription, 0> realSecondsResults{
        };

        inline static constexpr std::array<ScriptAbilityMethodDescription, 4> Methods{
            ScriptAbilityMethodDescription{
                ScriptApiMethodIdView{"lux.simulation.delay.next_step"},
                "nextStep",
                "NextStep",
                EScriptApiMethodKind::ASYNC_OPERATION,
                nextStepParameters,
                nextStepResults
            },
            ScriptAbilityMethodDescription{
                ScriptApiMethodIdView{"lux.simulation.delay.seconds"},
                "seconds",
                "Seconds",
                EScriptApiMethodKind::ASYNC_OPERATION,
                secondsParameters,
                secondsResults
            },
            ScriptAbilityMethodDescription{
                ScriptApiMethodIdView{"lux.simulation.delay.simulation_seconds"},
                "simulationSeconds",
                "SimulationSeconds",
                EScriptApiMethodKind::ASYNC_OPERATION,
                simulationSecondsParameters,
                simulationSecondsResults
            },
            ScriptAbilityMethodDescription{
                ScriptApiMethodIdView{"lux.simulation.delay.real_seconds"},
                "realSeconds",
                "RealSeconds",
                EScriptApiMethodKind::ASYNC_OPERATION,
                realSecondsParameters,
                realSecondsResults
            }
        };
        static_assert(scriptAbilityMethodIdsUnique(Methods), "Script Ability MethodId values must be unique");
        inline static constexpr ScriptAbilityDescription Description{
            Contract,
            "Delay",
            "Delay",
            1U,
            scriptAbilitySchemaHash(Contract, Receiver, Methods,
                1U),
            Receiver,
            Methods
        };
        static_assert(scriptAbilityCodeNameValid(Description.name), "Script Ability code name must be an identifier");

        static ScriptAbilityStartResult nextStepErased(
            void* context,
            const void* dispatch_value,
            std::span<const ScriptAbilityInputSlot> arguments,
            ScriptAbilityErasedCompletion completion
        ) noexcept
        {
            if (dispatch_value == nullptr || arguments.size() != 0U)
                return lux::cxx::unexpected<ScriptAbilityOperationError>(ScriptAbilityOperationError{static_cast<std::int32_t>(EScriptAbilityErasedCallStatus::INVALID_ARGUMENTS)});
            const auto& dispatch = *static_cast<const Dispatch*>(dispatch_value);
            auto typed_completion = adaptScriptAbilityCompletion<void>(std::move(completion));
            if (!typed_completion)
                return lux::cxx::unexpected<ScriptAbilityOperationError>(typed_completion.error());
            return dispatch.nextStep(context, std::move(*typed_completion));
        }
        static ScriptAbilityStartResult secondsErased(
            void* context,
            const void* dispatch_value,
            std::span<const ScriptAbilityInputSlot> arguments,
            ScriptAbilityErasedCompletion completion
        ) noexcept
        {
            if (dispatch_value == nullptr || arguments.size() != 1U)
                return lux::cxx::unexpected<ScriptAbilityOperationError>(ScriptAbilityOperationError{static_cast<std::int32_t>(EScriptAbilityErasedCallStatus::INVALID_ARGUMENTS)});
            if (!scriptAbilityInputMatches<double>(arguments[0]))
                return lux::cxx::unexpected<ScriptAbilityOperationError>(ScriptAbilityOperationError{static_cast<std::int32_t>(EScriptAbilityErasedCallStatus::INVALID_ARGUMENTS)});
            const auto& dispatch = *static_cast<const Dispatch*>(dispatch_value);
            auto typed_completion = adaptScriptAbilityCompletion<void>(std::move(completion));
            if (!typed_completion)
                return lux::cxx::unexpected<ScriptAbilityOperationError>(typed_completion.error());
            return dispatch.seconds(context, *static_cast<const std::remove_cvref_t<double>*>(arguments[0].data), std::move(*typed_completion));
        }
        static ScriptAbilityStartResult simulationSecondsErased(
            void* context,
            const void* dispatch_value,
            std::span<const ScriptAbilityInputSlot> arguments,
            ScriptAbilityErasedCompletion completion
        ) noexcept
        {
            if (dispatch_value == nullptr || arguments.size() != 1U)
                return lux::cxx::unexpected<ScriptAbilityOperationError>(ScriptAbilityOperationError{static_cast<std::int32_t>(EScriptAbilityErasedCallStatus::INVALID_ARGUMENTS)});
            if (!scriptAbilityInputMatches<double>(arguments[0]))
                return lux::cxx::unexpected<ScriptAbilityOperationError>(ScriptAbilityOperationError{static_cast<std::int32_t>(EScriptAbilityErasedCallStatus::INVALID_ARGUMENTS)});
            const auto& dispatch = *static_cast<const Dispatch*>(dispatch_value);
            auto typed_completion = adaptScriptAbilityCompletion<void>(std::move(completion));
            if (!typed_completion)
                return lux::cxx::unexpected<ScriptAbilityOperationError>(typed_completion.error());
            return dispatch.simulationSeconds(context, *static_cast<const std::remove_cvref_t<double>*>(arguments[0].data), std::move(*typed_completion));
        }
        static ScriptAbilityStartResult realSecondsErased(
            void* context,
            const void* dispatch_value,
            std::span<const ScriptAbilityInputSlot> arguments,
            ScriptAbilityErasedCompletion completion
        ) noexcept
        {
            if (dispatch_value == nullptr || arguments.size() != 1U)
                return lux::cxx::unexpected<ScriptAbilityOperationError>(ScriptAbilityOperationError{static_cast<std::int32_t>(EScriptAbilityErasedCallStatus::INVALID_ARGUMENTS)});
            if (!scriptAbilityInputMatches<double>(arguments[0]))
                return lux::cxx::unexpected<ScriptAbilityOperationError>(ScriptAbilityOperationError{static_cast<std::int32_t>(EScriptAbilityErasedCallStatus::INVALID_ARGUMENTS)});
            const auto& dispatch = *static_cast<const Dispatch*>(dispatch_value);
            auto typed_completion = adaptScriptAbilityCompletion<void>(std::move(completion));
            if (!typed_completion)
                return lux::cxx::unexpected<ScriptAbilityOperationError>(typed_completion.error());
            return dispatch.realSeconds(context, *static_cast<const std::remove_cvref_t<double>*>(arguments[0].data), std::move(*typed_completion));
        }
        inline static constexpr std::array<ScriptAbilityErasedMethodBinding, Methods.size()> ErasedMethods{
            ScriptAbilityErasedMethodBinding{
                ScriptApiMethodIdView{"lux.simulation.delay.next_step"},
                EScriptApiMethodKind::ASYNC_OPERATION,
                nextStepParameters,
                nextStepResults,
                nullptr,
                &nextStepErased
            },
            ScriptAbilityErasedMethodBinding{
                ScriptApiMethodIdView{"lux.simulation.delay.seconds"},
                EScriptApiMethodKind::ASYNC_OPERATION,
                secondsParameters,
                secondsResults,
                nullptr,
                &secondsErased
            },
            ScriptAbilityErasedMethodBinding{
                ScriptApiMethodIdView{"lux.simulation.delay.simulation_seconds"},
                EScriptApiMethodKind::ASYNC_OPERATION,
                simulationSecondsParameters,
                simulationSecondsResults,
                nullptr,
                &simulationSecondsErased
            },
            ScriptAbilityErasedMethodBinding{
                ScriptApiMethodIdView{"lux.simulation.delay.real_seconds"},
                EScriptApiMethodKind::ASYNC_OPERATION,
                realSecondsParameters,
                realSecondsResults,
                nullptr,
                &realSecondsErased
            }
        };

        template <class Provider>
        inline static constexpr bool ProviderConforms = requires(
            Provider& provider, double arg_seconds_0, double arg_simulationSeconds_0, double arg_realSeconds_0
        ) {
            { provider.nextStep(ScriptAbilityCompletion<void>{}) } noexcept -> std::same_as<ScriptAbilityStartResult>;
            { provider.seconds(arg_seconds_0, ScriptAbilityCompletion<void>{}) } noexcept -> std::same_as<ScriptAbilityStartResult>;
            { provider.simulationSeconds(arg_simulationSeconds_0, ScriptAbilityCompletion<void>{}) } noexcept -> std::same_as<ScriptAbilityStartResult>;
            { provider.realSeconds(arg_realSeconds_0, ScriptAbilityCompletion<void>{}) } noexcept -> std::same_as<ScriptAbilityStartResult>;
        };

        template <class Provider>
        static ScriptAbilityStartResult nextStepThunk(void* context, ScriptAbilityCompletion<void> completion) noexcept
        {
            auto& provider = *static_cast<Provider*>(context);
            return provider.nextStep(std::move(completion));
        }
        template <class Provider>
        static ScriptAbilityStartResult secondsThunk(void* context, double arg_0, ScriptAbilityCompletion<void> completion) noexcept
        {
            auto& provider = *static_cast<Provider*>(context);
            return provider.seconds(arg_0, std::move(completion));
        }
        template <class Provider>
        static ScriptAbilityStartResult simulationSecondsThunk(void* context, double arg_0, ScriptAbilityCompletion<void> completion) noexcept
        {
            auto& provider = *static_cast<Provider*>(context);
            return provider.simulationSeconds(arg_0, std::move(completion));
        }
        template <class Provider>
        static ScriptAbilityStartResult realSecondsThunk(void* context, double arg_0, ScriptAbilityCompletion<void> completion) noexcept
        {
            auto& provider = *static_cast<Provider*>(context);
            return provider.realSeconds(arg_0, std::move(completion));
        }

        template <class Provider>
        inline static constexpr Dispatch ProviderDispatch{
            &nextStepThunk<Provider>,
            &secondsThunk<Provider>,
            &simulationSecondsThunk<Provider>,
            &realSecondsThunk<Provider>
        };

        template <class Provider>
            requires ProviderConforms<Provider>
        [[nodiscard]] static ScriptAbilityBinding bind(Provider& provider) noexcept
        {
            return {&Description, std::addressof(provider), &ProviderDispatch<Provider>, ErasedMethods};
        }
    };

    template <>
    class ScriptAbilityStarter<::lux::simulation::script::DelayAbility> final
    {
    public:
        [[nodiscard]] static lux::cxx::expected<ScriptAbilityStarter, EScriptAbilityBindingError>
        create(ScriptAbilityBinding binding) noexcept
        {
            if (!binding.valid())
                return lux::cxx::unexpected<EScriptAbilityBindingError>(
                    EScriptAbilityBindingError::INVALID_BINDING
                );
            if (binding.description->id != ScriptAbilityTraits<::lux::simulation::script::DelayAbility>::Description.id ||
                binding.description->schema_hash != ScriptAbilityTraits<::lux::simulation::script::DelayAbility>::Description.schema_hash)
                return lux::cxx::unexpected<EScriptAbilityBindingError>(
                    EScriptAbilityBindingError::CONTRACT_MISMATCH
                );
            return ScriptAbilityStarter(binding.context,
                static_cast<const typename ScriptAbilityTraits<::lux::simulation::script::DelayAbility>::Dispatch*>(binding.dispatch));
        }
        ScriptAbilityStartResult nextStep(ScriptAbilityCompletion<void> completion) const noexcept
        {
            return dispatch_->nextStep(context_, std::move(completion));
        }
        ScriptAbilityStartResult seconds(double duration, ScriptAbilityCompletion<void> completion) const noexcept
        {
            return dispatch_->seconds(context_, duration, std::move(completion));
        }
        ScriptAbilityStartResult simulationSeconds(double duration, ScriptAbilityCompletion<void> completion) const noexcept
        {
            return dispatch_->simulationSeconds(context_, duration, std::move(completion));
        }
        ScriptAbilityStartResult realSeconds(double duration, ScriptAbilityCompletion<void> completion) const noexcept
        {
            return dispatch_->realSeconds(context_, duration, std::move(completion));
        }

    private:
        ScriptAbilityStarter(void* context, const typename ScriptAbilityTraits<::lux::simulation::script::DelayAbility>::Dispatch* dispatch) noexcept
            : context_(context), dispatch_(dispatch) {}
        void* context_{};
        const typename ScriptAbilityTraits<::lux::simulation::script::DelayAbility>::Dispatch* dispatch_{};
    };

    template <>
    class ScriptAbilityCpp<::lux::simulation::script::DelayAbility> final
    {
    public:
        [[nodiscard]] static lux::cxx::expected<ScriptAbilityCpp, EScriptAbilityBindingError>
        create(ScriptAbilityBinding binding) noexcept
        {
            if (!binding.valid())
                return lux::cxx::unexpected<EScriptAbilityBindingError>(
                    EScriptAbilityBindingError::INVALID_BINDING
                );
            if (binding.description->id != ScriptAbilityTraits<::lux::simulation::script::DelayAbility>::Description.id ||
                binding.description->schema_hash != ScriptAbilityTraits<::lux::simulation::script::DelayAbility>::Description.schema_hash)
                return lux::cxx::unexpected<EScriptAbilityBindingError>(
                    EScriptAbilityBindingError::CONTRACT_MISMATCH
                );
            return ScriptAbilityCpp(binding.context,
                static_cast<const typename ScriptAbilityTraits<::lux::simulation::script::DelayAbility>::Dispatch*>(binding.dispatch));
        }

    private:
        ScriptAbilityCpp(void* context, const typename ScriptAbilityTraits<::lux::simulation::script::DelayAbility>::Dispatch* dispatch) noexcept
            : context_(context), dispatch_(dispatch) {}
        void* context_{};
        const typename ScriptAbilityTraits<::lux::simulation::script::DelayAbility>::Dispatch* dispatch_{};
    };

    template <class Context>
    class ScriptAbilityCoroutine<::lux::simulation::script::DelayAbility, Context> final
    {
    public:
        ScriptAbilityCoroutine(Context& context, std::uint32_t ability_slot) noexcept
            : context_(std::addressof(context)), ability_slot_(ability_slot)
        {
        }
        [[nodiscard]] auto nextStep() const noexcept
        {
            return context_->template awaitAbility<void>(
                ability_slot_,
                [](
                    void* provider,
                    const void* dispatch_value,
                    ScriptAbilityCompletion<void> completion
                ) noexcept
                {
                    const auto& dispatch = *static_cast<const typename ScriptAbilityTraits<::lux::simulation::script::DelayAbility>::Dispatch*>(dispatch_value);
                    return dispatch.nextStep(provider, std::move(completion));
                }
            );
        }
        [[nodiscard]] auto seconds(double duration) const noexcept
        {
            return context_->template awaitAbility<void>(
                ability_slot_,
                [duration_owned = std::remove_cvref_t<double>(duration)](
                    void* provider,
                    const void* dispatch_value,
                    ScriptAbilityCompletion<void> completion
                ) noexcept
                {
                    const auto& dispatch = *static_cast<const typename ScriptAbilityTraits<::lux::simulation::script::DelayAbility>::Dispatch*>(dispatch_value);
                    return dispatch.seconds(provider, duration_owned, std::move(completion));
                }
            );
        }
        [[nodiscard]] auto simulationSeconds(double duration) const noexcept
        {
            return context_->template awaitAbility<void>(
                ability_slot_,
                [duration_owned = std::remove_cvref_t<double>(duration)](
                    void* provider,
                    const void* dispatch_value,
                    ScriptAbilityCompletion<void> completion
                ) noexcept
                {
                    const auto& dispatch = *static_cast<const typename ScriptAbilityTraits<::lux::simulation::script::DelayAbility>::Dispatch*>(dispatch_value);
                    return dispatch.simulationSeconds(provider, duration_owned, std::move(completion));
                }
            );
        }
        [[nodiscard]] auto realSeconds(double duration) const noexcept
        {
            return context_->template awaitAbility<void>(
                ability_slot_,
                [duration_owned = std::remove_cvref_t<double>(duration)](
                    void* provider,
                    const void* dispatch_value,
                    ScriptAbilityCompletion<void> completion
                ) noexcept
                {
                    const auto& dispatch = *static_cast<const typename ScriptAbilityTraits<::lux::simulation::script::DelayAbility>::Dispatch*>(dispatch_value);
                    return dispatch.realSeconds(provider, duration_owned, std::move(completion));
                }
            );
        }

    private:
        Context* context_{};
        std::uint32_t ability_slot_{};
    };

    template <class Provider>
        requires ScriptAbilityTraits<::lux::simulation::script::DelayAbility>::template ProviderConforms<Provider>
    class ScriptAbilityStatic<::lux::simulation::script::DelayAbility, Provider> final
    {
    public:
        [[nodiscard]] static lux::cxx::expected<ScriptAbilityStatic, EScriptAbilityBindingError> create(
            Provider& provider,
            ScriptAbilityBinding binding
        ) noexcept
        {
            const bool is_mismatch = !binding.valid() || binding.context != std::addressof(provider) ||
                binding.description->id != ScriptAbilityTraits<::lux::simulation::script::DelayAbility>::Description.id ||
                binding.description->schema_hash != ScriptAbilityTraits<::lux::simulation::script::DelayAbility>::Description.schema_hash;
            return is_mismatch
                ? lux::cxx::unexpected<EScriptAbilityBindingError>(EScriptAbilityBindingError::CONTRACT_MISMATCH)
                : lux::cxx::expected<ScriptAbilityStatic, EScriptAbilityBindingError>{ScriptAbilityStatic(provider)};
        }
        ScriptAbilityStartResult nextStep(ScriptAbilityCompletion<void> completion) const noexcept
        {
            return provider_->nextStep(std::move(completion));
        }
        ScriptAbilityStartResult seconds(double duration, ScriptAbilityCompletion<void> completion) const noexcept
        {
            return provider_->seconds(duration, std::move(completion));
        }
        ScriptAbilityStartResult simulationSeconds(double duration, ScriptAbilityCompletion<void> completion) const noexcept
        {
            return provider_->simulationSeconds(duration, std::move(completion));
        }
        ScriptAbilityStartResult realSeconds(double duration, ScriptAbilityCompletion<void> completion) const noexcept
        {
            return provider_->realSeconds(duration, std::move(completion));
        }

    private:
        explicit ScriptAbilityStatic(Provider& provider) noexcept : provider_(std::addressof(provider)) {}
        Provider* provider_{};
    };

} // namespace lux::script
