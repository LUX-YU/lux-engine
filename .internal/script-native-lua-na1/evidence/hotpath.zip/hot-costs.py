"""Nine locked end-to-end legs, exactly three AB/BA/AB pairs. No outlier rejection."""
import csv,ctypes as ct,json,os,re,statistics,subprocess,time
from pathlib import Path
r=Path(__file__).parent; out=r/'hot-costs';out.mkdir(exist_ok=False)
source=subprocess.check_output(['git','-C',str(r/'opt-source'),'rev-parse','HEAD'],text=True).strip()
k=ct.WinDLL('kernel32');k.GetCurrentProcess.restype=ct.c_void_p;k.SetProcessAffinityMask.argtypes=[ct.c_void_p,ct.c_size_t]
assert k.SetProcessAffinityMask(k.GetCurrentProcess(),16)
linker=re.search(r'CMAKE_LINKER:FILEPATH=(.*)',(r.parent/'o/w/t/CMakeCache.txt').read_text())[1].strip()
fixed={'P1':(10000,1000,2000,1),'P2':(10000,1000,2000,1),'P3':(10000,75,250,3),'P4':(10000,16,64,32),'P5':(1000,100,1000,1),'S1':(10000,1000,2000,0),'S2':(10000,300,1000,0),'S3':(10000,300,1000,1),'P6':(10000,300,2000,0)}
work_keys=['active_instances','calls','ability_calls','events','suspensions','resumes','continuations','awaitables','event_waiters','event_dispatch_visits','queue_depth','queue_high_water','checksum','claim_lookups','actual_copy_bytes','completion_capabilities','physics_queries','script_calls','next_step_waits','phase']
runs=[]
for leg,(size,warm,batches,waits) in fixed.items():
 for pair in range(3):
  for side in (['A','B'] if pair%2==0 else ['B','A']):
   name=f'{leg}-{pair}-{side}';data=out/(name+'.csv');log=out/(name+'.log')
   image_side='B' if side=='A' else 'C'
   image=r/'images'/(image_side+'-common' if leg in ['P1','P2','P3','P4','P5'] else image_side+'-flow' if leg=='S3' else image_side)
   if leg in ['P1','P2','P3','P4','P5']:
    command=[str(image/'native_lua_complete_tasks.exe'),'--case',leg,'--size',str(size),'--warmups',str(warm),'--batches',str(batches),'--output',str(data)]
   elif leg=='P6':
    command=[str(image/'physics2d_script_benchmark.exe'),'--group','scene-physics-mixed','--mode','performance','--size',str(size),'--frames',str(batches),'--warmups',str(warm),'--workers','0','--trace','off','--lua-artifact',str(r/'images/shared-assets/physics2d_lua_fixture.lxsa'),'--flowforge-artifact',str(r/'images/shared-assets/physics2d_flowforge_fixture.lxsa'),'--output',str(data)]
   else:
    group={'S1':'micro-lua-ability-query','S2':'scene-cpp-sequence','S3':'scene-flowforge-event'}[leg]
    command=[str(image/('flowforge_script_runtime_benchmark.exe' if leg=='S3' else 'script_runtime_benchmark.exe')),'--group',group,'--mode','performance','--size',str(size),'--frames',str(batches),'--warmups',str(warm),'--seed','1592598566','--resume-budget','10000','--output',str(data)]
    if leg=='S1':command+=['--vm-accounting','off','--lua-artifact',str(r/'images/shared-assets/lua_runtime_benchmark_fixture.lxsa')]
   env=dict(os.environ);env['LUX_FLOWFORGE_LINKER']=linker
   env['PATH']=';'.join([str(image),'D:/Development/vcpkg/installed/x64-windows/bin',*[p for p in env['PATH'].split(';') if 'CodeRepos' not in p and 'vcpkg' not in p]])
   start=time.monotonic()
   with log.open('wb') as f:code=subprocess.call(command,stdout=f,stderr=subprocess.STDOUT,env=env)
   text=log.read_text(errors='replace'); rows=list(csv.DictReader(data.open())) if data.exists() else []
   values=[int(x['nanoseconds']) for x in rows];times=sorted(values)
   business={};errors=None;backlog=None;prepare=None;total=sum(values);valid=code==0 and len(rows)>=batches
   if leg in ['P1','P2','P3','P4','P5']:
    m=re.search(r'^BUSINESS (.*)$',text,re.M);obs=dict(re.findall(r'(\w+)=(\S+)',m[1])) if m else {}
    expected={'case':leg,'side':'B','instances':str(size),'warmups':str(warm),'batches':str(batches),'tasks':str(size*batches),'waits':str(size*batches*waits),'resumes':str(size*batches*waits),'errors':'0','backlog':'0','leases':'0','diagnostics':'0'}
    valid=valid and len(rows)==batches and all(obs.get(k)==v for k,v in expected.items())
    if obs:
     business={k:int(obs[k]) for k in ['instances','tasks','waits','resumes','provider','per_instance','errors','backlog','leases']}
     total=int(obs['elapsed_ns']);prepare=int(obs['prepare_ns']);errors=int(obs['errors']);backlog=int(obs['backlog'])
     valid=valid and int(obs['threads'])==0 and int(obs['lua_resumes'])==0
    operations=size*batches;unit='complete-task';observation=obs
   else:
    expected_source='4a8812e9813fe90b241dba29e3e668e4a4239b26' if side=='A' else source
    valid=valid and all(x['git_commit']==expected_source and x['build_type']=='RelWithDebInfo' for x in rows)
    errs=re.findall(r'invocation_errors=(\d+)',text);valid=valid and all(int(e)==0 for e in errs)
    errors=0 if errs else None;backlog=int(rows[-1]['queue_depth']) if rows else None
    business={k:rows[-1][k] for k in work_keys if rows and k in rows[-1]}
    operations=len(rows) if leg in ['S2','P6'] else len(rows)*size
    unit='original-simulation-frame' if leg in ['S2','P6'] else 'complete-call-or-task'
    observation=[x for x in text.splitlines() if x.startswith(('INTEGRITY','ERRORS','NATIVE_STORAGE','BUSINESS_ORACLE'))]
   run=dict(leg=leg,pair=pair,side=side,command=command,exit=code,valid=valid,production_source='4a8812e9813fe90b241dba29e3e668e4a4239b26' if side=='A' else source,fixture_source=('4a8812e9813fe90b241dba29e3e668e4a4239b26' if side=='A' else source) if leg.startswith('P') and leg!='P6' else None,wall_seconds=time.monotonic()-start,total_ns=total,sum_batches_ns=sum(values),actual_operations=operations,unit=unit,ns_per_actual_operation=total/operations,prepare_ns=prepare,p50_batch_ns=statistics.median(times) if times else None,p95_batch_ns=times[min(len(times)-1,int(.95*len(times)))] if times else None,p99_batch_ns=times[min(len(times)-1,int(.99*len(times)))] if times else None,business=business,observation=observation,errors=errors,backlog=backlog,per_batch_errors=None,resume_latency_ns=None,allocations=None,allocator_statistics=False,affinity=16)
   runs.append(run);(out/'runs.json').write_text(json.dumps(runs,indent=2))
   print(name,code,valid,round(run['ns_per_actual_operation'],3),flush=True)
   if not valid:raise SystemExit('INVALID_TRIAL retained '+name)
summary=[]
for leg in fixed:
 deltas=[];paired=[]
 for pair in range(3):
  values={v['side']:v for v in runs if v['leg']==leg and v['pair']==pair}
  assert values['A']['business']==values['B']['business'],('business mismatch',leg,pair,values['A']['business'],values['B']['business'])
  if leg in ['S1','S2','S3','P6']:
   raw={s:list(csv.DictReader((out/f'{leg}-{pair}-{s}.csv').open())) for s in ['A','B']}
   assert len(raw['A'])==len(raw['B'])
   for a,b in zip(raw['A'],raw['B']):
    assert all(a[k]==b[k] for k in work_keys if k in a and k in b),('per-row mismatch',leg,pair,a,b)
  d=100*(values['B']['total_ns']/values['A']['total_ns']-1);deltas.append(d)
  paired.append({s:values[s]['total_ns'] for s in ['A','B']})
 summary.append(dict(leg=leg,paired_totals_ns=paired,deltas_percent=deltas,median_percent=statistics.median(deltas),A_ns=statistics.median(v['ns_per_actual_operation'] for v in runs if v['leg']==leg and v['side']=='A'),B_ns=statistics.median(v['ns_per_actual_operation'] for v in runs if v['leg']==leg and v['side']=='B'),unit=values['A']['unit']))
(out/'summary.json').write_text(json.dumps(summary,indent=2))
print('ALL_54_COMPLETE',json.dumps(summary),flush=True)
