import hashlib
import json
import shutil
import statistics
import subprocess
from pathlib import Path

r = Path(__file__).resolve().parent
s = r.parent / 's5/source'
main = Path('E:/SyncForder/CodeRepos/lux-engine')
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def git(p, *args):
    return subprocess.check_output(['git', '-C', str(p), *args], text=True).strip()

start = json.loads((r / 'start-identity.json').read_text())
assert git(main, 'rev-parse', 'HEAD') == start['main_head']
assert git(main, 'status', '--porcelain') == start['main_status']
for entry in start['main_files']:
    assert digest(main / entry['path']) == entry['sha256'], entry['path']
for name, identity in start['dependencies'].items():
    assert git(main.parent / name, 'rev-parse', 'HEAD') == identity['head']
    assert git(main.parent / name, 'status', '--porcelain') == identity['status']
for entry in start['C0']:
    assert digest(Path(entry['path'])) == entry['sha256'], entry['path']
c1 = 'f64caddebcc353c07ac03637135f99586986eb6e'
assert git(r / 'candidate-source', 'rev-parse', 'HEAD') == c1
assert not git(r / 'candidate-source', 'status', '--porcelain')
changed = git(s, 'diff', '--name-only', 'ebf081158', c1).splitlines()
assert not any(p.startswith('modules/') and '/include/' in p for p in changed)
assert not any('template' in p or 'engine_lua_values.cmake' in p for p in changed)
identities = {'source': c1, 'candidate_clean': True, 'main_and_unknown_files_unchanged': True,
              'dependencies_unchanged': True, 'frozen_C0_files_verified': len(start['C0']),
              'changed_files': changed, 'modules_public_headers_or_templates_changed': False, 'binaries': []}
for vm in ('t', 'd', 'l'):
    for p in sorted((r / 'q' / vm / 'bin').glob('*')):
        if p.suffix.lower() in ('.exe', '.dll'):
            identities['binaries'].append({'vm': vm, 'path': str(p), 'sha256': digest(p)})
(r / 'final-identity.json').write_text(json.dumps(identities, indent=2))

stage = r / 'evidence-stage'
stage.mkdir(exist_ok=True)
for p in r.iterdir():
    if p.is_file() and p.suffix in ('.py', '.ps1', '.log', '.json', '.patch'):
        shutil.copy2(p, stage / p.name)
diag = stage / 'diagnostics'
diag.mkdir(exist_ok=True)
for p in (r / 'diagnostics').glob('*.asm'):
    shutil.copy2(p, diag / p.name)
for name in ('ProtectedRecord.hpp', 'main.cpp', 'CMakeLists.txt'):
    shutil.copy2(s / 'cmake/installed-consumers/script-lua-value-costs' / name, diag / name)
generated = diag / 'generated'
generated.mkdir(exist_ok=True)
for p in (r / 'consumers-final/script-lua-values').rglob('*.hpp'):
    if 'generated' in str(p).lower() or 'lua_value' in p.name.lower():
        shutil.copy2(p, generated / p.name)

windows = {}
for file, symbols in {
    'C0-value.asm': ('?table@LuaValueAccess', '?setField@LuaValueAccess'),
    'C1-value.asm': ('?table@LuaValueAccess', '?setField@LuaValueAccess'),
    'fix-development-backend.asm': ('?current@LuaAbilityProjectionAccess',),
    'C1-backend.asm': ('?current@LuaAbilityProjectionAccess',),
}.items():
    lines = (r / 'diagnostics' / file).read_text().splitlines()
    for symbol in symbols:
        matches = [i for i, line in enumerate(lines) if line.startswith(symbol) and line.endswith(':')]
        assert len(matches) == 1, (file, symbol, matches)
        begin = matches[0]
        end = next((i for i in range(begin + 1, len(lines)) if lines[i] and not lines[i].startswith(' ')), len(lines))
        body = '\n'.join(lines[begin:end])
        if 'value.asm' in file:
            assert ('call        memset' in body) == file.startswith('C0')
        else:
            assert '?valid@ScriptInvocationValidity' in body
        windows[file + ':' + symbol] = {'first_line': begin + 1, 'text': body}
(diag / 'verified-windows.json').write_text(json.dumps(windows, indent=2))

invalid = {'performance-H-C1': {
    'excluded_from_final_summary': True,
    'reason': 'Repeated VS DevShell initialization in the parent session reported input line too long / syntax error. Measurement driver processes returned zero; retained but environmental bootstrap is uncertain.',
    'replacement': 'performance-H-C1-clean: fresh PowerShell process, no bootstrap warning; all five pairs retained',
    'slow_pairs_removed': False},
    'production_experiments': 'Exactly two predefined experiments, both retained after 5/5 improvement; no failed production experiment or forceinline search omitted.'}
(stage / 'invalid-trials.json').write_text(json.dumps(invalid, indent=2))

report = s / '.internal/script-system-sr5-admission-correction-2026-09-07.zh-CN.md'
text = report.read_text(encoding='utf-8')
comparisons = json.loads((r / 'performance-C0-C1/validated-costs.json').read_text())['comparisons']
cost = ['### 最终 clean C1 配对', '',
        '下表总时间是各侧五进程中位（ms）；单位成本均摊完整批次，不能称为单独 provider/resume 函数耗时。',
        '配对变化是五个独立差值的中位，不能用两侧中位之差替代；完整逐帧业务核验及所有分布保存在 validated-costs.json。', '',
        '| C0→C1 场景 | 计时有效量 | C0/C1 总 ms | C0/C1 ns/单位 | 配对中位变化 | backlog |',
        '|---|---:|---:|---:|---:|---:|']
for c in comparisons:
    p = c['pairs'][0]
    n = p['candidate']['counts']
    unit = 'provider_calls' if c['case'] == 'lua-ability-10k' else 'actual_new_calls'
    if unit not in n:
        unit = 'completions'
    a, b = c['median_baseline_ns'], c['median_candidate_ns']
    cost.append(f"| {c['case']} | {n[unit]:,} {unit} | {a/1e6:.4f} / {b/1e6:.4f} | {a/n[unit]:.4f} / {b/n[unit]:.4f} | {c['median_percent']:+.3f}% | {p['candidate']['last'].get('queue_depth', '见原始记录')} |")
cost += ['', '五对完整分布，按预先排定的 pair 0—4；Δ 为整批 C1−C0 毫秒：', '',
         '| 场景 | Δ ms | Δ % |', '|---|---|---|']
for c in comparisons:
    cost.append('| ' + c['case'] + ' | ' + ', '.join(f"{p['delta_ns']/1e6:+.4f}" for p in c['pairs']) +
                ' | ' + ', '.join(f"{p['percent']:+.3f}" for p in c['pairs']) + ' |')
h = json.loads((r / 'performance-H-C1-clean/validated-costs.json').read_text())['comparisons'][0]
cost += ['',
    'C0→C1 scalar 的配对增量中位 +6.9321 ns/provider（+207.9628 ms/30M）；它包含补上的完整初始资格，',
    '而 C0 对默认 scalar 跳过该检查。仅修正→窄改实验的改善不抵消最终 C0→C1 +9.151%，不改写安全参照。',
    'Lua coroutine +8.099%（配对中位 +788.3976 ms/10M、+78.8398 ns/实际新调用）也单独登记。',
    '该路径的 async scalar 现在经过初始 core 准入；源调用边界解释了新增工作，但本轮没有独立分离其全部时间，',
    '故不将整批差值全部归给资格或 resume，也不认定为已证明必要成本。其8,000 backlog与C0相同、由原预算保留。',
    '其余方向混合且部分 Event 配对波动明显；保留全部分布，不声称小幅中位差代表稳定优化。', '',
    f"H→C1 scalar同量30M：{h['median_baseline_ns']/1e6:.4f}/{h['median_candidate_ns']/1e6:.4f} ms，",
    f"{h['median_baseline_ns']/30e6:.4f}/{h['median_candidate_ns']/30e6:.4f} ns/provider；配对中位 {h['median_percent']:+.3f}%，",
    '五对百分比 ' + ', '.join(f"{p['percent']:+.3f}%" for p in h['pairs']) + '；',
    '五对Δms ' + ', '.join(f"{p['delta_ns']/1e6:+.4f}" for p in h['pairs']) + '。',
    '配对增量中位 +16.7296 ns/provider，backlog=0。首次H复跑的开发环境初始化出现命令行过长警告，',
    '所有记录保留于 performance-H-C1，但不进入最终统计；新进程 performance-H-C1-clean 无警告且五对全部纳入。', '',
    '旧benchmark缺失的 errors/failures仍为null。FlowForge的计时区间外 INTEGRITY retained=0 与关闭清零另存，',
    '它们不是所有错误的计数替身；真实资格负例的provider=0、结果错误provider=1由独立 correctness 运行证明。', '',
    '### 两字段输出与新值绝对成本', '',
    '| 路径 | 1M次总时间中位 ms | ns/输出 | 独立10k诊断 protected C调用 |',
    '|---|---:|---:|---:|',
    '| H旧无保护手写 | 99.6799 | 99.6799 | 0 |',
    '| 同安全目标手写诊断 | 122.5410 | 122.5410 | 10,000 |',
    '| C0正式生成 | 254.8304 | 254.8304 | 30,000 |',
    '| C1正式生成 | 240.0040 | 240.0040 | 30,000 |', '',
    'C0→C1五对Δns/输出：[-11.7151,-13.7756,-16.5632,-14.0426,-10.8872]，中位−13.7756；',
    '百分比[-4.6540,-5.4741,-6.4997,-5.4190,-4.1781]，中位−5.4190%。',
    'H→C1配对增量中位+140.3241 ns；H→protected中位+22.8525 ns；protected→C1中位+116.4941 ns。',
    '所有H/protected/C0/C1逐对总时间、差值和百分比分布见 record-final/validated-costs.json。',
    '不把+140.3241 ns全部叫作生成开销；受保护诊断证明特定两个scalar输出可用更粗保护，但不证明通用生成协议等价。',
    'C1仍比该诊断贵约116.5 ns/输出（配对中位），这是可量化残余，不是性能等价或全部必要安全成本。', '',
    '全部输出计时errors=0、backlog=0、fields=2、完成量1M。LuaJIT计时与分配/调用hook诊断分离；',
    '独立10k输出C0/C1均20,081次Lua分配、1,122,592 bytes，保护次数均30k；EXE-local分配不是全DLL堆统计。',
    'Lua54只做对应保护/错误/清理诊断，未宣称与手写pushinteger的数值子类或性能等价。',
    'typed Pose五次100k绝对测量中位129.5654 ms、1295.654 ns/provider，errors/backlog=0；',
    '另一次启用VM计数的100k诊断为800,000次Lua分配；该诊断耗时不混入普通计时。', '',
    '最终反汇编确认C1 table不再调用256字节memset，栈预留由170h降为78h；current直接写访问字段，',
    '仍保留capture调用、40字节ticket拷贝与valid调用。verified-windows.json给出精确符号和行号，不能把未删除的操作记作收益。',
]
text = text.replace('<!-- FINAL_COSTS -->', '\n'.join(cost))
text = text.replace('<!-- FINAL_EVIDENCE -->',
    '新证据位于 [evidence/script/sr5/admission/README.md](evidence/script/sr5/admission/README.md)：'+
    '独立修前/修后、clean正确性提交及C1资格、原始配对、无效环境试验、诊断源码/反汇编、产物/安装身份与哈希。\n'+
    '本轮未改L0公共头或生成模板；无须新增三个旧install前缀的头同步，新的Engine窄公开入口由三份C1安装及真实消费者校验。\n'+
    '结束时逐项复核main七项未知文件哈希、main HEAD、两个依赖仓状态及全部冻结C0 EXE/DLL，均与开工相同。')
text = text.replace('是否建议进入 SR-6 的依据以真实正确性门槛和本轮有限成本结果给出，仍由统一审阅决定；本轮不自行进入。',
    '建议：正确性与本轮有限调查可以提交验收；不建议在尚未明确接受scalar、coroutine新增成本及record残余前无条件进入SR-6。'+
    '若统一审阅接受上述已量化成本与未完全分离的coroutine归因，可另行批准SR-6；本轮不继续优化或自动启动下一阶段。')
report.write_text(text, encoding='utf-8')
summary = '''# SR-5 权限补正：审阅摘要

本轮完成实际补正与一次有限成本检查，停在SR-5。生产身份 **f64cadde**；旧C0为6086e4a4。

- 每个普通/async Ability入口都检查初始core资格。can_reenter只决定转换后原资格重验。
- 已绑定但失效的authority必须拒绝；真正standalone仍受原backend frame/layout检查。
- 正式生成/runtime的retire/stop × scalar/zero四个独立修前进程均实际调用provider一次，修后两VM均为零。
- ACTIVE、同VM嵌套、Begin/End、普通输入错误后的合法重试，以及原七点清理/身份/pin/frontier/预算保持通过。
- 两个窄改有独立证据：直接写准入访问结果；输出操作不再初始化未使用的256字节错误路径。保护与对象清理未删减。

仅RelWithDebInfo，clean C1：Toolchain 108/108、Developer 123/123、Lua54受影响110/110，15安装消费者、13增量检查通过。
两种VM各五项独立资格命令通过；实际安装与生成输入有身份清单。六项Scene Lua保留既有已修正协议断言，本轮未重做。

| 最终成本 | 五对配对中位变化 | 绝对影响 |
|---|---:|---:|
| C0→C1 scalar Ability | +9.151% | +6.9321 ns/provider；30M调用+207.9628 ms |
| H→C1 scalar Ability | +25.648% | +16.7296 ns/provider |
| C0→C1两字段输出 | −5.419% | −13.7756 ns/输出；C1中位240.004 ns |
| protected手写诊断→C1输出 | +95.665% | +116.4941 ns/输出，保护次数1对3 |
| C0→C1 Lua coroutine | +8.099% | 整批均摊+78.8398 ns/实际新调用；backlog同为8,000 |

绝对成本均摊完整工作，不是单函数计时。完整八场景、所有配对和分配诊断见主报告；旧缺失errors保留null。
输出错误/backlog均为零。首次H运行的VS环境警告记录保留并排除，新进程五对全部纳入；没有按速度删除样本。
coroutine新增准入工作已定位到调用边界，但全部时间尚未独立分离；不把残余称为性能等价或全部必要安全成本。

建议接受正确性补正与有限调查结果；**进入SR-6仍需审阅方明确接受新增成本与残余**。本轮不再扩优化项目，不合并main。
主工作区七项未知修改、HEAD和固定依赖均保持；原证据包不改写。

[完整资格、测试、成本及限制](script-system-sr5-admission-correction-2026-09-07.zh-CN.md) ·
[新原始证据与下载](evidence/script/sr5/admission/README.md)
'''
(s / '.internal/script-system-sr5-admission-summary-2026-09-07.zh-CN.md').write_text(summary, encoding='utf-8')
print('Identity preservation, assembly windows, complete cost report and summary verified')
