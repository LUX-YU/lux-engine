from pathlib import Path
r=Path('E:/RenderV2Rebuild/Layer/source')
p=r/'modules/platform/process/include/lux/engine/platform/Random.hpp';p.write_text('''#pragma once

#include <cstddef>
#include <span>

namespace lux::engine::platform
{
    // OS entropy for cold process/session identities. No deterministic fallback on failure.
    [[nodiscard]] bool fillRandomBytes(std::span<std::byte> destination) noexcept;
}
''')
p=r/'modules/platform/process/src/Random.cpp';p.write_text('''#include <lux/engine/platform/Random.hpp>
#include <limits>

#if defined(_WIN32)
#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <bcrypt.h>
#else
#include <cerrno>
#include <fcntl.h>
#include <unistd.h>
#endif

namespace lux::engine::platform
{
    bool fillRandomBytes(std::span<std::byte> destination) noexcept
    {
#if defined(_WIN32)
        if (destination.size() > std::numeric_limits<ULONG>::max()) return false;
        return BCryptGenRandom(nullptr, reinterpret_cast<PUCHAR>(destination.data()),
            static_cast<ULONG>(destination.size()), BCRYPT_USE_SYSTEM_PREFERRED_RNG) == 0;
#else
        const int descriptor = open("/dev/urandom", O_RDONLY | O_CLOEXEC);
        if (descriptor < 0) return false;
        std::size_t offset = 0;
        while (offset < destination.size())
        {
            const auto count = read(descriptor, destination.data() + offset, destination.size() - offset);
            if (count < 0 && errno == EINTR) continue;
            if (count <= 0) { close(descriptor); return false; }
            offset += static_cast<std::size_t>(count);
        }
        close(descriptor);
        return true;
#endif
    }
}
''')
p=r/'modules/platform/process/CMakeLists.txt';s=p.read_text().replace('SOURCE_FILES src/Process.cpp','SOURCE_FILES src/Process.cpp src/Random.cpp').replace('PRIVATE shell32 ole32','PRIVATE shell32 ole32 bcrypt');p.write_text(s)
p=r/'cmake/render-v2-bootstrap/CMakeLists.txt';s=p.read_text().replace('include("${CMAKE_CURRENT_LIST_DIR}/../InstallComponents.cmake")','include("${CMAKE_CURRENT_LIST_DIR}/../InstallComponents.cmake")\ninclude("${CMAKE_CURRENT_LIST_DIR}/../TargetClassification.cmake")\nfind_package(lux-cxx CONFIG REQUIRED COMPONENTS compile_time)').replace('set(platform_components platform_ipc gapi)','set(platform_components platform_ipc gapi platform_process)\n\nadd_subdirectory("${CMAKE_CURRENT_LIST_DIR}/../../modules/platform/process" platform-process)');p.write_text(s)
p=r/'modules/function/render/runtime/src/RenderServer.cpp';s=p.read_text().replace('if (BCryptGenRandom(nullptr, reinterpret_cast<PUCHAR>(identity.data()), sizeof(identity),\n            BCRYPT_USE_SYSTEM_PREFERRED_RNG) != 0)','if (!lux::engine::platform::fillRandomBytes(std::as_writable_bytes(std::span(identity))))');assert 'BCrypt' not in s;s=s.replace('#include "ServerImpl.hpp"','#include "ServerImpl.hpp"');p.write_text(s)
p=r/'modules/function/render/core/test/Installed.cmake';s=p.read_text().replace('file(RENAME "${prefix}" "${relocated}")','''file(RENAME "${prefix}" "${relocated}")

foreach(obsolete features/Texture.hpp features/Program.hpp data/Wire.hpp)
    if(EXISTS "${relocated}/include/lux/engine/render/${obsolete}")
        message(FATAL_ERROR "Obsolete public header installed: ${obsolete}")
    endif()
endforeach()''').replace('-C "${CONFIG}" --output-on-failure)','-C "${CONFIG}" -V --output-on-failure)');p.write_text(s)
p=r/'.internal/render-v2/check_layer.py';s=p.read_text().replace('changed = set(','''platform_files = {
    "modules/platform/process/CMakeLists.txt",
    "modules/platform/process/include/lux/engine/platform/Random.hpp",
    "modules/platform/process/src/Random.cpp",
}
def permitted(name):
    return name.startswith(allowed) or name in platform_files

changed = set(''').replace('all(name.startswith(allowed) for name in changed), sorted(name for name in changed if not name.startswith(allowed))','all(permitted(name) for name in changed), sorted(name for name in changed if not permitted(name))');p.write_text(s)
