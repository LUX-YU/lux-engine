#pragma once
// Generated typed Lua projection. Include the matching .ability.generated.hpp first.
#include <lux/engine/simulation/scripting/lua/LuaScriptAbilityProjection.hpp>

#include <array>
#include <type_traits>
#include <utility>

namespace lux::script::lua
{

    template <>
    struct ScriptAbilityLuaTraits<::lux::simulation::test::CppCoroutineAbility> final
    {
        using AbilityTraits = ScriptAbilityTraits<::lux::simulation::test::CppCoroutineAbility>;
        using Policy = typename ScriptAbilityLuaPolicy<::lux::simulation::test::CppCoroutineAbility>::Type;

        using Values_read = LuaAbilityValueSignature<Policy, int, int>;
        [[nodiscard]] static int read(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, int, int>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, int value) noexcept -> int
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.read(access.context, value);
                }
            );
        }

        using Values_write = LuaAbilityValueSignature<Policy, void, int>;
        [[nodiscard]] static int write(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, void, int>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, int value) noexcept -> void
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    dispatch.write(access.context, value);
                }
            );
        }

        using Values_borrowed = LuaAbilityValueSignature<Policy, const int &>;
        [[nodiscard]] static int borrowed(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, const int &>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access) noexcept -> const int &
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.borrowed(access.context);
                }
            );
        }

        using Values_run = LuaAbilityValueSignature<Policy, int, int>;
        [[nodiscard]] static int run(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::startLuaValueAbility<Policy, int, int>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, int value, ScriptAbilityCompletion<int> completion) noexcept
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.run(access.context, value, std::move(completion));
                }
            );
        }

        inline static constexpr std::array<ScriptAbilityLuaMethodProjection, AbilityTraits::Methods.size()> Methods{
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.cpp_coroutine.read"},
                &read, Values_read::Parameters, Values_read::Results
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.cpp_coroutine.write"},
                &write, Values_write::Parameters, Values_write::Results
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.cpp_coroutine.borrowed"},
                &borrowed, Values_borrowed::Parameters, Values_borrowed::Results
            },
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.cpp_coroutine.run"},
                &run, Values_run::Parameters, Values_run::Results
            }
        };
    };
} // namespace lux::script::lua
