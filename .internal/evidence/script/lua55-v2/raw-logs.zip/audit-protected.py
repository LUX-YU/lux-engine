from pathlib import Path
import json,hashlib,subprocess
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/lua55-v2');main=Path('E:/SyncForder/CodeRepos/lux-engine');start=json.loads((r/'start.json').read_text(encoding='utf-8-sig'));results=[]
for item in start['protected']:
 p=main/item['path'];digest=hashlib.sha256(p.read_bytes()).hexdigest().upper();results.append(dict(path=item['path'],sha256=digest,unchanged=digest==item['sha256']))
result=dict(main_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=main,text=True).strip(),status=subprocess.check_output(['git','status','--porcelain'],cwd=main,text=True),protected=results)
assert result['main_head']==start['main_head'] and all(x['unchanged'] for x in results)
(r/'protected-workspace-final.json').write_text(json.dumps(result,indent=2));print('PROTECTED_MAIN_UNCHANGED',len(results))
