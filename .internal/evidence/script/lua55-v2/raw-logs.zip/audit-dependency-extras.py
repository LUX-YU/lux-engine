from pathlib import Path
import json,hashlib
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/lua55-v2');repo=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source');identity=json.loads((repo/'.internal/evidence/script/sr6/identity.json').read_text());p=Path('E:/SyncForder/CodeRepos/install/q2/c');prev=next(x for x in identity['prefixes'] if x['prefix'].replace('\\','/').endswith('/q2/c'));known={x['path'].replace('\\','/') for x in prev['files']};extras=[]
for f in p.rglob('*'):
 if f.is_file() and str(f.relative_to(p)).replace('\\','/') not in known:
  extras.append(dict(path=str(f.relative_to(p)),sha256=hashlib.sha256(f.read_bytes()).hexdigest(),text=f.read_text(errors='replace') if f.stat().st_size<5000 else None))
(r/'fixed-dependency-additional-files.json').write_text(json.dumps(extras,indent=2));print(json.dumps(extras,indent=2))
