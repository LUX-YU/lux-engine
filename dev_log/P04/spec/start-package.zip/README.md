# P04 启动包

先读 [START_P04.md](START_P04.md)，再读 [原 P04 实施文档](reference/lux_editor_execution_pack_v4_2026-09-28/phases/P04_flowforge_authoring.md)。

本包包括当前启动补充与原 V4 完整只读参考（36 文件），以保留阶段文档的相对链接和追踪附件。**只授权 P04，不因参考中包含其它阶段就继续执行。**

原参考包的旧路径/manifest/收据示例不能覆盖当前仓库施工账本：以 START_P04、已验收提交和当前 `.internal/editor-redesign/` 为准。历史和会话已收拢到 `editor/editing/`，验收快照在 `dev_log/`。

这不是引擎源码或补丁包。未包含独立构建结果；64/64 等成绩在 START_P04 中明确标为实施方归档证据。PACKAGING_SHA256.json 仅校验本次交付文件及原参考逐字节完整性，不是引擎测试报告。
