$ErrorActionPreference='Stop'
$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1'
$source='E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1/qualification-source'
$sdk='E:/SyncForder/CodeRepos/install/o/na1/qualified-sdk'
$tools='E:/SyncForder/CodeRepos/install/o/na1/qualified-tools'
$prefixes="$sdk;$tools;E:/SyncForder/CodeRepos/install/o/v4/lua55;E:/SyncForder/CodeRepos/install/q2/toolset;E:/SyncForder/CodeRepos/install/q2/c"
$ignore='E:/SyncForder/CodeRepos/install/RelWithDebInfo;E:/SyncForder/CodeRepos/install/o/q/d;E:/SyncForder/CodeRepos/install/o/q/t;E:/SyncForder/CodeRepos/install/o/q/s1-lua55;E:/SyncForder/CodeRepos/install/o/q/s1-t'
$names=@('cpp-generated-script','physics2d-script','system-event-await-runtime','flowforge-compiler',
    'lua-script-packager','scene-script-runtime','script-ability-codegen','system-hook-script-binding',
    'cpp-coroutine-script','script-static-ability-specialization','script-ability-ipo','script-authoring',
    'script-runtime-input','script-description','script-lua-values','native-task-lua-steps')
& "$source/cmake/RunScriptV3Consumers.ps1" -SourceDir $source -OutputRoot "$r/installed" `
    -PrefixPath $prefixes -DependencyRoot 'D:/Development/vcpkg/installed' -IgnorePrefixes $ignore -Names $names
if($LASTEXITCODE) { throw 'Consumer driver failed' }
$results=Get-Content -Raw -LiteralPath "$r/installed/consumers.json" | ConvertFrom-Json
if($results.Count -ne $names.Count -or @($results | Where-Object status -ne 'PASS').Count) {
    throw 'Not every current SDK consumer passed'
}
& "$source/cmake/RunScriptSR5ValueIncremental.ps1" -ConsumerRoot "$r/installed/script-lua-values" `
    -InstalledTemplate "$sdk/share/lux-engine-function/script_lua/cmake_scripts/template/lua_value.template" `
    -EvidenceRoot "$r/value-incremental"
if($LASTEXITCODE) { throw 'Value incremental qualification failed' }
Write-Output 'CURRENT_SDK_AND_VALUE_INCREMENTAL_PASS'
