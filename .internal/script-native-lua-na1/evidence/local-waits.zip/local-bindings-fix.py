from pathlib import Path
s=Path(r'E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1/source')
p=s/'engine/domain/simulation/scripting/cpp_static/src/CppStaticScriptBridge.cpp'
t=p.read_text().replace('!view->behavior->hasInvocationAuthority() || !view->current ||\n                !view->current(view->owner, context.instance, view->publication);','!view->behavior->hasInvocationAuthority() || !view->current || view->publication == 0U;')
t=t.replace('    [[nodiscard]] CoroutineContinuation *acquireCoroutine(Instance &instance) noexcept\n    {','''    [[nodiscard]] CoroutineContinuation *acquireCoroutine(Instance &instance) noexcept
    {
        // Publication is not live while the two child objects are being built.
        // Validate once when a task starts; its immutable view and child instance
        // cannot be released before this task is destroyed.
        if (const auto* view = instance.sync_steps)
            if (!view->current(view->owner, view->instance, view->publication)) return nullptr;''')
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptEventWaits.hpp'
t=p.read_text().replace('        ScriptInstanceId instance;\n        ScriptAwaitableId awaitable;\n        std::uint32_t endpoint{};','        ScriptAwaitableId awaitable;\n        std::uint32_t endpoint{};')
t=t.replace('claimed_.push_back({current->wait_->instance, current->wait_->id, endpoint});', 'claimed_.push_back(current->wait_->id);')
t=t.replace('end_(other.end_) {}', 'end_(other.end_), endpoint_(other.endpoint_) {}')
t=t.replace('return owner_->claimed_[begin_ + offset];','return {owner_->claimed_[begin_ + offset], endpoint_};')
t=t.replace('ClaimBatch(ScriptEventWaits& owner, std::size_t begin, std::size_t end) noexcept\n                : owner_(&owner), begin_(begin), end_(end) {}','ClaimBatch(ScriptEventWaits& owner, std::size_t begin, std::size_t end, std::uint32_t endpoint) noexcept\n                : owner_(&owner), begin_(begin), end_(end), endpoint_(endpoint) {}')
t=t.replace('            std::size_t end_{};\n', '            std::size_t end_{};\n            std::uint32_t endpoint_{};\n')
t=t.replace('return ClaimBatch{*this, begin, claimed_.size()};','return ClaimBatch{*this, begin, claimed_.size(), endpoint};')
t=t.replace('std::vector<ScriptClaimedEventWait> claimed_;', 'std::vector<ScriptAwaitableId> claimed_;')
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptExecution.hpp'
t=p.read_text().replace('            const auto instance = waiter.instance;\n','')
a=t.index('            const bool is_stale = record == nullptr',t.index('        void completeClaimedEventWaiter'))
b=t.index('            auto* owner = record->owner;',a)
t=t[:a]+'''            const bool is_stale = record == nullptr || record->release_pending ||
                record->source != ScriptWaitSource{id, EScriptWaitSource::EVENT};
            if (is_stale) return;
            const auto instance = record->instance;
'''+t[b:]
p.write_text(t,encoding='utf-8')
