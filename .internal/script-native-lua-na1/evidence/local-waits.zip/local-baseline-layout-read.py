from pathlib import Path
import re
r=Path.cwd()
text=(r/'next-class-layout/ScriptSystem.cpp.log').read_text(errors='replace')
for line in text.splitlines():
 if line.startswith('class ') and 'size(' in line and any(line.split('size(')[0].rstrip().endswith('::'+n) for n in ['AwaitableRecord','ExecutionInstance','EventWaiterRecord','ContinuationRecord','ResumeRecord','EventRouteHead','InstanceRecord']):print(line)
