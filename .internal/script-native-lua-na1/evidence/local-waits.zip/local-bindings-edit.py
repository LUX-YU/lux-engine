from pathlib import Path
s=Path(r'E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1/source')
p=s/'engine/domain/simulation/scripting/cpp_static/include/lux/engine/simulation/scripting/cpp_static/ScriptCoroutine.hpp'
t=p.read_text()
t=t.replace('    namespace detail\n    {\n        [[nodiscard]] LUX_ENGINE_SIMULATION_SCRIPT_CPP_STATIC_PUBLIC','''    namespace detail
    {
        struct CppStaticPreparedEvents final
        {
            const CppStaticContract* layout{};
            std::span<const ScriptEventAdmissionHandle> entries;
        };
        [[nodiscard]] LUX_ENGINE_SIMULATION_SCRIPT_CPP_STATIC_PUBLIC''',1)
t=t.replace('      using ResolveEventFn = bool (*)(void*, std::uint32_t, const CppStaticContract*, std::uint32_t,\n                                      ScriptEventAdmissionHandle&) noexcept;\n','')
t=t.replace('ResolveEventFn resolve_event,','const detail::CppStaticPreparedEvents* events,').replace('ScriptCoroutineContext::const detail::CppStaticPreparedEvents* events,','const detail::CppStaticPreparedEvents* events,')
t=t.replace(': sync_steps_(sync_steps), sync_publication_(sync_steps ? sync_steps->publication : 0U),', ': sync_steps_(sync_steps),')
t=t.replace('resolve_event_(resolve_event)', 'events_(events)').replace('        std::uint64_t sync_publication_{};\n','').replace('        ResolveEventFn resolve_event_{};', '        const detail::CppStaticPreparedEvents* events_{};')
t=t.replace('alignment_limit, resolve_event, sync_steps}', 'alignment_limit, events, sync_steps}')
a=t.index('            ScriptEventAdmissionHandle admission;',t.index('    auto ScriptCoroutineContext::wait('))
b=t.index('            return waiting ?',a)
t=t[:a]+'''            const auto* events = context.events_;
            const bool wrong_source = events == nullptr || events->layout != layout || slot >= events->entries.size();
            if (wrong_source) return ScriptStepResult::failed(-1);
            const auto waiting = step.event_waits.wait(events->entries[slot]);
'''+t[b:]
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/scripting/cpp_static/src/CppStaticScriptBridge.cpp'
t=p.read_text().replace('#include <lux/engine/simulation/scripting/ScriptLifecycle.hpp>','#include <lux/engine/simulation/scripting/ScriptLifecycle.hpp>\n#include <lux/engine/simulation/scripting/ScriptRuntimeAccess.hpp>')
a=t.index('    const auto identity = active_step_->instance;');b=t.index('    if (ordinal >=',a);t=t[:a]+t[b:]
a=t.index('    auto* behavior = view->behavior;');b=t.index('    const auto status = entry.invoke',a)
t=t[:a]+'''    // The immutable publication is borrowed for the entire child-task lifetime.
    // Capture checks current core authority once; no user code precedes invocation.
    const auto qualification = view->behavior->captureInvocation();
    if (!detail::ScriptRuntimeAccess::hasCapturedInvocation(qualification))
        return error(EScriptSyncStepError::INVOCATION_REVOKED, -32004);
'''+t[b:]
t=t.replace('if (!view->current(view->owner, identity, sync_publication_) || !qualification.valid())','if (!qualification.valid())')
t=t.replace('        std::span<const ScriptEventAdmissionHandle> prepared_events;', '        detail::CppStaticPreparedEvents prepared_events;')
a=t.index('    [[nodiscard]] static bool resolveEvent(');b=t.index('    void destroyCoroutine',a);t=t[:a]+t[b:]
t=t.replace('descriptor.frame_limit, descriptor.frame_alignment, &State::resolveEvent, instance.sync_steps);','descriptor.frame_limit, descriptor.frame_alignment, &instance.prepared_events, instance.sync_steps);')
t=t.replace('instance->prepared_events = events;', 'instance->prepared_events = {&descriptor, events};').replace('!instance->prepared_events.empty()', '!instance->prepared_events.entries.empty()')
# Validate a foreign sync publication before taking resources; this replaces per-call publication checks.
a=t.index('    static EScriptBackendResult createInstance(');pos=t.index('        auto &self =',a)
t=t[:pos]+'''        if (const auto* view = context.sync_steps)
        {
            const bool invalid_view = view->instance != context.instance || view->behavior != context.behavior ||
                view->behavior == nullptr || !view->behavior->hasInvocationAuthority() || !view->current ||
                !view->current(view->owner, context.instance, view->publication);
            if (invalid_view) return EScriptBackendResult::HOST_CONTEXT_MISMATCH;
            for (const auto& step : view->steps)
            {
                const bool invalid_step = step.shape == nullptr || step.signature == nullptr || step.invoke == nullptr;
                if (invalid_step) return EScriptBackendResult::UNSUPPORTED_SIGNATURE;
            }
        }
'''+t[pos:]
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/scripting/core/sinclude/lux/engine/simulation/scripting/ScriptRuntimeAccess.hpp'
t=p.read_text().replace('    public:\n', '''    public:
        // Only in the no-user-code interval immediately after capture. This is
        // not a later validity test and cannot renew a captured invocation.
        [[nodiscard]] static bool hasCapturedInvocation(const ScriptInvocationValidity& value) noexcept
        {
            return value.check_ != nullptr;
        }
''',1);p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptInstances.hpp'
t=p.read_text().replace('            ScriptInstances* owner{};\n            bool lifecycle_call{};\n','').replace('            std::uint64_t retirement_epoch{};\n','')
t=t.replace('            EScriptMountState state{EScriptMountState::INACTIVE};\n        };\n        struct Mount', '''            EScriptMountState state{EScriptMountState::INACTIVE};
            bool lifecycle_call{};
            std::uint64_t retirement_epoch{};
            const bool* accepting_invocations{};
        };
        struct Mount''')
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/builtin/script/src/ScriptInstances.cpp'
t=p.read_text().replace('            for (std::size_t slot{}; slot < mounts_.size(); ++slot)\n                mounts_[slot].invocation = &invocation_states_[slot];', '''            for (std::size_t slot{}; slot < mounts_.size(); ++slot)
            {
                mounts_[slot].invocation = &invocation_states_[slot];
                invocation_states_[slot].accepting_invocations = &accepting_invocations_;
            }''')
t=t.replace('        mount.owner = this;\n','').replace('bindInvocation(mount.behavior, &mount,','bindInvocation(mount.behavior, mount.invocation,')
a=t.index('        ScriptRuntimeAccess::bindInvocation');b=t.index('        return std::optional{Construction',a)
x=t[a:b].replace('static_cast<const Mount*>','static_cast<const InvocationState*>').replace('current.invocation->','current.').replace('value.invocation->','value.').replace('current.owner->accepting_invocations_', '*current.accepting_invocations').replace('value.owner->accepting_invocations_', '*value.accepting_invocations')
t=t[:a]+x+t[b:]
t=t.replace('mount.retirement_epoch','mount.invocation->retirement_epoch').replace('mount.lifecycle_call','mount.invocation->lifecycle_call')
p.write_text(t,encoding='utf-8')
