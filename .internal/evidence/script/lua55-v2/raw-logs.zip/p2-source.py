from pathlib import Path
p=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source/modules/function/script/lua/src/LuaValue.cpp')
s=p.read_text()
s=s.replace('            char operation_key;\n','')
s=s.replace('                std::span<const LuaPlainNode> nodes;\n                std::size_t current{};', '''                const LuaCodecPlan* plan{};
                const LuaCodecShape* shape{};
                const void* object{};
                std::span<double> scratch;
                std::array<std::string_view, 33U> path{};
                std::size_t path_size{};
                std::size_t cursor{};''')
s=s.replace('''            // These C trampolines have no owning C++ locals and deliberately are not noexcept:
            // the selected VM may use either longjmp or C++ unwinding to reach its own pcall.''','''            // Lua55 C errors may jump only over trivial, non-owning callback frames.''')
a=s.index('            int initializeTrampoline(');b=s.index('            bool run(',a)
s=s[:a]+s[b:]
a=s.index('                lua_pushlightuserdata(state, &operation_key);');b=s.index('                lua_pushlightuserdata(state, &operation);',a)
s=s[:a]+'                lua_pushcfunction(state, trampoline);\n'+s[b:]
a=s.index('            // These recursive frames');b=s.index('        } // namespace',a)
s=s[:a]+'''            void pushShapeKeys(lua_State* state, const LuaCodecShape& shape)
            {
                lua_rawgetp(state, LUA_REGISTRYINDEX, &shape);
                if (!lua_isnil(state, -1)) return;
                lua_pop(state, 1);
                lua_createtable(state, static_cast<int>(shape.keys.size()), 0);
                for (std::size_t i{}; i < shape.keys.size(); ++i)
                {
                    const auto key = shape.keys[i];
                    lua_pushlstring(state, key.data(), key.size());
                    lua_rawseti(state, -2, static_cast<lua_Integer>(i + 1U));
                }
                lua_pushvalue(state, -1);
                lua_rawsetp(state, LUA_REGISTRYINDEX, &shape);
            }
            std::size_t fieldOrdinal(const LuaCodecShape* shape, std::span<const std::string_view> keys,
                const char* key, std::size_t length) noexcept
            {
                if (keys.size() <= 8U || shape == nullptr)
                {
                    for (std::size_t i{}; i < keys.size(); ++i)
                        if (keys[i].size() == length && std::memcmp(keys[i].data(), key, length) == 0) return i;
                }
                else
                {
                    const auto hash = luaFieldHash({key, length});
                    std::size_t first{}, last = shape->lookup.size();
                    while (first < last)
                    {
                        const auto middle = first + (last - first) / 2U;
                        if (shape->lookup[middle].hash < hash) first = middle + 1U;
                        else last = middle;
                    }
                    for (; first < shape->lookup.size() && shape->lookup[first].hash == hash; ++first)
                    {
                        const auto ordinal = shape->lookup[first].ordinal;
                        if (keys[ordinal].size() == length && std::memcmp(keys[ordinal].data(), key, length) == 0)
                            return ordinal;
                    }
                }
                return keys.size();
            }
            bool matchShape(lua_State* state, int table, std::span<const std::string_view> keys,
                const LuaCodecShape* shape, LuaValueFailure& failure)
            {
                if (lua_type(state, table) != LUA_TTABLE) { failure.code = ELuaValueError::TYPE; return false; }
                std::size_t count{};
                std::uint64_t seen{};
                lua_pushnil(state);
                while (lua_next(state, table))
                {
                    if (++count > keys.size() || lua_type(state, -2) != LUA_TSTRING)
                    { failure.code = ELuaValueError::UNKNOWN_FIELD; return false; }
                    std::size_t length{};
                    const char* key = lua_tolstring(state, -2, &length);
                    const auto ordinal = fieldOrdinal(shape, keys, key, length);
                    if (ordinal == keys.size()) { failure.code = ELuaValueError::UNKNOWN_FIELD; return false; }
                    seen |= std::uint64_t{1U} << ordinal;
                    lua_pop(state, 1);
                }
                for (std::size_t i{}; i < keys.size(); ++i)
                    if ((seen & (std::uint64_t{1U} << i)) == 0U)
                    {
                        failure.code = ELuaValueError::MISSING_FIELD;
                        failure.prepend(keys[i]);
                        return false;
                    }
                return true;
            }
            int checkShape(lua_State* state, Operation& operation)
            {
                if (operation.shape != nullptr) { pushShapeKeys(state, *operation.shape); lua_pop(state, 1); }
                operation.success = matchShape(state, 2, operation.keys, operation.shape, *operation.failure);
                return 0;
            }
            void preparePlan(lua_State* state, const LuaCodecPlan& plan)
            {
                if (plan.shape == nullptr) return;
                pushShapeKeys(state, *plan.shape);
                lua_pop(state, 1);
                for (const auto& field : plan.fields) preparePlan(state, field.plan());
            }
            int prepareOperation(lua_State* state, Operation& operation)
            {
                if (operation.plan != nullptr) preparePlan(state, *operation.plan);
                else { pushShapeKeys(state, *operation.shape); lua_pop(state, 1); }
                return 0;
            }
            bool pushPlain(lua_State* state, Operation& operation, const LuaCodecPlan& plan,
                const void* object, std::size_t depth)
            {
                if (plan.kind != ELuaPlainKind::RECORD)
                {
                    const auto number = plan.read(object);
                    if (!number.valid || !plan.validate(number.value))
                    { operation.failure->code = ELuaValueError::RANGE; return false; }
                    if (plan.kind == ELuaPlainKind::BOOLEAN) lua_pushboolean(state, number.value != 0.0);
                    else lua_pushnumber(state, number.value);
                    return true;
                }
                pushShapeKeys(state, *plan.shape);
                const int keys = lua_gettop(state);
                lua_createtable(state, 0, static_cast<int>(plan.fields.size()));
                const int table = lua_gettop(state);
                for (std::size_t i{}; i < plan.fields.size(); ++i)
                {
                    const auto& field = plan.fields[i];
                    operation.path[depth] = field.name;
                    operation.path_size = depth + 1U;
                    // Resolve the member now, after preceding allocations and callbacks.
                    if (!pushPlain(state, operation, field.plan(), field.member(object), depth + 1U)) return false;
                    operation.path_size = depth + 1U;
                    lua_rawgeti(state, keys, static_cast<lua_Integer>(i + 1U));
                    lua_insert(state, -2);
                    lua_rawset(state, table);
                }
                lua_remove(state, keys);
                return true;
            }
            bool readPlain(lua_State* state, Operation& operation, const LuaCodecPlan& plan,
                int value, std::size_t depth)
            {
                const auto slot = operation.cursor++;
                if (slot >= operation.scratch.size()) { operation.failure->code = ELuaValueError::CAPACITY; return false; }
                if (plan.kind != ELuaPlainKind::RECORD)
                {
                    const bool boolean = plan.kind == ELuaPlainKind::BOOLEAN;
                    if (lua_type(state, value) != (boolean ? LUA_TBOOLEAN : LUA_TNUMBER))
                    { operation.failure->code = ELuaValueError::TYPE; return false; }
                    const double number = boolean ? static_cast<double>(lua_toboolean(state, value)) : lua_tonumber(state, value);
                    if (!plan.validate(number)) { operation.failure->code = ELuaValueError::RANGE; return false; }
                    operation.scratch[slot] = number;
                    return true;
                }
                if (!matchShape(state, value, plan.shape->keys, plan.shape, *operation.failure)) return false;
                pushShapeKeys(state, *plan.shape);
                const int keys = lua_gettop(state);
                for (std::size_t i{}; i < plan.fields.size(); ++i)
                {
                    const auto& field = plan.fields[i];
                    operation.path[depth] = field.name;
                    operation.path_size = depth + 1U;
                    lua_rawgeti(state, keys, static_cast<lua_Integer>(i + 1U));
                    lua_rawget(state, value);
                    if (!readPlain(state, operation, field.plan(), lua_gettop(state), depth + 1U)) return false;
                    lua_pop(state, 1);
                }
                lua_pop(state, 1);
                return true;
            }
            int writePlain(lua_State* state, Operation& operation)
            {
                operation.success = pushPlain(state, operation, *operation.plan, operation.object, 0U);
                return operation.success ? 1 : 0;
            }
            int readPlainOperation(lua_State* state, Operation& operation)
            {
                operation.success = readPlain(state, operation, *operation.plan, 2, 0U);
                return 0;
            }
            LuaValueResult<void> planResult(lua_State* state, Operation& operation, int input, int results) noexcept
            {
                LuaValueFailure failure{ELuaValueError::VM_FAILURE};
                operation.failure = &failure;
                if (operation.plan->stack <= 136U && lua_checkstack(state, static_cast<int>(operation.plan->stack)) &&
                    run(state, operation, input, 0, results)) return {};
                for (auto i = operation.path_size; i > 0U; --i) failure.prepend(operation.path[i - 1U]);
                return lux::cxx::unexpected(failure);
            }
'''+s[b:]
a=s.index('        bool LuaValueAccess::initialize(');b=s.index('        int LuaValueAccess::top(',a)
s=s[:a]+'''        bool LuaValueAccess::initialize(lua_State* state) noexcept
        {
            return state != nullptr && lua_checkstack(state, 136) != 0;
        }
        bool LuaValueAccess::prepare(lua_State* state, const LuaCodecPlan& plan) noexcept
        {
            Operation operation{prepareOperation};
            operation.plan = &plan;
            return lua_checkstack(state, static_cast<int>(plan.stack)) && run(state, operation, 0, 0, 0);
        }
        bool LuaValueAccess::prepareShape(lua_State* state, const LuaCodecShape& shape) noexcept
        {
            Operation operation{prepareOperation};
            operation.shape = &shape;
            return run(state, operation, 0, 0, 0);
        }
'''+s[b:]
a=s.index('        LuaValueResult<void> LuaValueAccess::plain(');b=s.index('        int LuaValueAccess::failure(',a)
s=s[:a]+'''        LuaValueResult<void> LuaValueAccess::writePlan(lua_State* state, const LuaCodecPlan& plan,
            const void* object) noexcept
        {
            Operation operation{writePlain};
            operation.plan = &plan;
            operation.object = object;
            return planResult(state, operation, 0, 1);
        }
        LuaValueResult<void> LuaValueAccess::readPlan(lua_State* state, int index, const LuaCodecPlan& plan,
            std::span<double> scratch) noexcept
        {
            Operation operation{readPlainOperation};
            operation.plan = &plan;
            operation.scratch = scratch;
            return planResult(state, operation, index, 0);
        }
'''+s[b:]
s=s.replace('std::span<const std::string_view> keys) noexcept','std::span<const std::string_view> keys, const LuaCodecShape* plan) noexcept')
s=s.replace('            operation.keys = keys;\n','            operation.keys = keys;\n            operation.shape = plan;\n')
p.write_text(s,encoding='utf-8',newline='\n')
