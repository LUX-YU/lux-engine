from pathlib import Path
r=Path(__file__).parent
for name in ['benchmark.ps1','installed.ps1','new-incremental.ps1','new-incremental.py','relocated.ps1',
             'costs.py','profile.py','resources.py','machine.py','class-layout.py','class-layout.ps1']:
 p=r/('hot-'+name)
 t=p.read_text(encoding='utf-8-sig').replace('hot-','next-').replace('opt-source','next-source')
 t=t.replace('optimized-sdk','next-sdk').replace('optimized-tools','next-tools')
 t=t.replace("'4a8812e9813fe90b241dba29e3e668e4a4239b26'", "'21d106014e05cf0a7746d45fd05eac8ae01575f2'")
 t=t.replace("'B' if side=='A' else 'C'", "'C' if side=='A' else 'D'")
 t=t.replace("'qualification-source' if side=='A' else 'next-source'", "'opt-source' if side=='A' else 'next-source'")
 if name=='new-incremental.py':
  t=t.replace("['signature','contract','mapping','delete-step']", "['signature','contract','mapping','delete-step','shape']")
 (r/('next-'+name)).write_text(t,encoding='utf-8')
t=(r/'hot-save-images.py').read_text().replace('opt-source','next-source').replace('optimized-sdk','next-sdk')
t=t.replace("save('C'", "save('D'").replace("save('C-flow'", "save('D-flow'").replace("save('C-common'", "save('D-common'")
t=t.replace("['B-common','B','B-flow','C-common','C','C-flow']", "['C-common','C','C-flow','D-common','D','D-flow']")
t=t.replace("images/B-common/business.lxsa", "images/C-common/business.lxsa")
(r/'next-save-images.py').write_text(t,encoding='utf-8')
