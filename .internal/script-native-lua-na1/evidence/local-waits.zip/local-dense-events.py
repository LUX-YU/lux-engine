from pathlib import Path
s=Path(r'E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1/source')
p=s/'engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptEventWaits.hpp'
t=p.read_text().replace('        ScriptEventWaitLink* route_previous_{};\n        ScriptEventWaitLink* route_next_{};', '        std::uint32_t page_{};\n        std::uint8_t position_{};')
t=t.replace('        using Link = ScriptEventWaitLink;', '''        using Link = ScriptEventWaitLink;
        static constexpr std::uint32_t NoPage = (std::numeric_limits<std::uint32_t>::max)();
        static constexpr std::size_t PageSize = 4U;
        struct WaitPage final
        {
            std::array<Link*, PageSize> entries;
            std::uint32_t previous{NoPage};
            std::uint32_t next{NoPage};
            std::uint32_t count{};
        };''')
t=t.replace('            Link* first{};\n            Link* last{};', '            std::uint32_t first{NoPage};\n            std::uint32_t last{NoPage};')
a=t.index('        void unlinkRoute(Link& link)');b=t.index('        void claimRoute(',a)
t=t[:a]+'''        [[nodiscard]] std::uint32_t appendPage(EventRouteHead& route) noexcept
        {
            // At most one nonempty page per ACTIVE wait. The source preflight
            // guarantees a free page without imposing a per-event capacity.
            if (free_page_ == NoPage) std::terminate();
            const auto index = free_page_;
            auto& page = pages_[index];
            free_page_ = page.next;
            page.previous = route.last;
            page.next = NoPage;
            page.count = 0U;
            if (route.last != NoPage) pages_[route.last].next = index;
            else route.first = index;
            route.last = index;
            return index;
        }
        void releasePage(std::uint32_t index) noexcept
        {
            auto& page = pages_[index];
            page.count = 0U;
            page.next = free_page_;
            free_page_ = index;
        }
        void unlinkRoute(Link& link) noexcept
        {
            auto& page = pages_[link.page_];
            const auto last = --page.count;
            if (link.position_ != last)
            {
                auto* moved = page.entries[last];
                page.entries[link.position_] = moved;
                moved->position_ = link.position_;
            }
            if (page.count != 0U) return;
            auto* route = findRoute(link.endpoint_, link.target_);
            if (route == nullptr) std::terminate();
            if (page.previous != NoPage) pages_[page.previous].next = page.next;
            else route->first = page.next;
            if (page.next != NoPage) pages_[page.next].previous = page.previous;
            else route->last = page.previous;
            releasePage(link.page_);
            if (route->first == NoPage) removeEmptyRoute(link.endpoint_, link.target_);
        }
'''+t[b:]
a=t.index('            auto* current = route->first;',t.index('        void claimRoute'));b=t.index('            removeEmptyRoute(endpoint, target);',a)
t=t[:a]+'''            auto current = route->first;
            // Each page contains a dense range. Task order inside one occurrence
            // is unspecified; cancellation swaps the last page entry into its gap.
            // Claim is still complete before any user callback can register again.
            while (current != NoPage)
            {
                auto& page = pages_[current];
                const auto next = page.next;
                for (std::uint32_t i{}; i < page.count; ++i)
                {
                    auto& link = *page.entries[i];
                    ++dispatch_visits_;
                    link.state_ = Link::EState::CLAIMED;
                    ++active_claimed_;
                    if (claimed_.size() == claimed_.capacity()) std::terminate();
                    claimed_.push_back(link.wait_->id);
                }
                releasePage(current);
                current = next;
            }
'''+t[b:]
a=t.index('            link.route_previous_ = route.last;');b=t.index('            link.instance_next_ = owner.first;',a)
t=t[:a]+'''            const auto page_index = route.last == NoPage || pages_[route.last].count == PageSize ?
                appendPage(route) : route.last;
            auto& page = pages_[page_index];
            link.page_ = page_index;
            link.position_ = static_cast<std::uint8_t>(page.count);
            page.entries[page.count++] = &link;
'''+t[b:]
t=t.replace('        EventRouteIndex routes_;', '        std::vector<WaitPage> pages_;\n        std::uint32_t free_page_{NoPage};\n        EventRouteIndex routes_;')
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/builtin/script/src/ScriptEventWaits.cpp'
t=p.read_text().replace('        capacity_ = capacity;','''        capacity_ = capacity;
        pages_.resize(capacity);
        free_page_ = NoPage;
        for (std::size_t i = capacity; i > 0U; --i)
            releasePage(static_cast<std::uint32_t>(i - 1U));''')
t=t.replace('        result.event_waiter_record_bytes = sizeof(ScriptEventWaitLink);', '''        result.event_waiter_record_bytes = sizeof(ScriptEventWaitLink);
        result.event_page_storage_bytes = pages_.capacity() * sizeof(WaitPage);
        result.event_claim_storage_bytes = claimed_.capacity() * sizeof(ScriptAwaitableId);''')
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/builtin/script/include/lux/engine/simulation/ScriptSystem.hpp'
t=p.read_text().replace('        std::size_t awaitable_storage_bytes{};', '''        std::size_t awaitable_storage_bytes{};
        // Event links are included in awaitable_storage_bytes, not counted twice.
        std::size_t event_page_storage_bytes{};
        std::size_t event_claim_storage_bytes{};
        std::size_t resume_storage_bytes{};''')
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/builtin/script/src/ScriptExecution.cpp'
t=p.read_text().replace('        result.resume_queue_depth = resumes_.count;', '        result.resume_storage_bytes = resumes_.records.capacity() * sizeof(ScriptAwaitableId);\n        result.resume_queue_depth = resumes_.count;')
p.write_text(t,encoding='utf-8')
