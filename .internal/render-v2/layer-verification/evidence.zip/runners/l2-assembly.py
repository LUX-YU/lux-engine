from pathlib import Path
b=Path('E:/RenderV2Rebuild/Layer/source/modules/function/render')
p=b/'features/include/lux/engine/render/features/Feature.hpp';old=p.read_text();a=old.index('    // Arguments:');errors=old[a:old.rfind('}')]
p.write_text('''#pragma once

#include <lux/engine/render/data/Schema.hpp>

namespace lux::render
{
    struct FeatureTypeTag;
    using FeatureTypeIdView = cxx::SchemaIdView<FeatureTypeTag>;

    // Immutable author metadata; no execution, command registration or selection policy.
    struct FeatureDescriptor final
    {
        FeatureTypeIdView type;
        cxx::SchemaVersion version;
        const DataSchemaDescriptor* config_schema = nullptr;
    };
}
''')
(b/'features/include/lux/engine/render/features/Assembly.hpp').write_text('''#pragma once

#include <lux/engine/render/features/Feature.hpp>
#include <lux/engine/render/features/Resources.hpp>
#include <lux/engine/render/graph/Builder.hpp>
#include <lux/engine/render/graph/Analysis.hpp>
#include <lux/engine/render/data/Wire.hpp>

namespace lux::render
{
    // Synchronous cold contributions. Callbacks may append, never finish/move/retain the Builder.
    struct FeatureGraphOps final
    {
        RenderResult<void> (*describe)(const WireView*, std::string_view, std::vector<ResourceClaim>&) noexcept;
        RenderResult<void> (*build)(const WireView*, std::string_view,
            std::span<const ResolvedResource>, RenderGraphBuilder&) noexcept = nullptr;
    };

    struct FeatureInstanceView final
    {
        const FeatureDescriptor* descriptor = nullptr;
        const FeatureGraphOps* graph = nullptr;
        const WireView* config = nullptr;
        std::string_view instance_key;
    };

    struct FeatureContribution final
    {
        std::size_t input_index;
        std::size_t first_pass;
        std::size_t pass_count;
    };

    struct FeatureAssembly final
    {
        RenderGraphDefinition definition;
        GraphAnalysis analysis;
        std::vector<GraphStorageBinding> external_bindings;
        std::vector<FeatureContribution> contributions;
    };

    [[nodiscard]] std::string
    featureKey(FeatureTypeIdView type, std::string_view instance, std::string_view local) noexcept;

    [[nodiscard]] RenderResult<FeatureAssembly>
    assembleFeatures(std::span<const FeatureInstanceView> instances, WireLimits config_limits) noexcept;

'''+errors+'}\n')
p=b/'features/src/Assemble.cpp';s=p.read_text().replace('/features/Feature.hpp','/features/Assembly.hpp').replace('SelectedFeature','FeatureInstanceView').replace('selection_index','input_index').replace('validateSelections','validateInstances');s=s.replace('.definition->','.descriptor->').replace('!s.definition','!s.descriptor || !s.graph').replace('*s.definition','*s.descriptor').replace('!d.describe','!s.graph->describe').replace('previous.definition != s.definition','previous.descriptor != s.descriptor || previous.graph != s.graph')
s=s.replace('s.descriptor->describe','s.graph->describe').replace('s.descriptor->build','s.graph->build')
s=s.replace('            std::vector<const CommandDescriptor*> commands;\n','')
a=s.index('                for (const auto& command : s.descriptor->commands)');z=s.index('\n            }\n            return {};',a);s=s[:a]+s[z:]
p.write_text(s)
p=b/'features/include/lux/engine/render/features/Registration.hpp';s=p.read_text().replace('/features/Feature.hpp','/features/Assembly.hpp').replace('        const FeatureDefinition* definition;','        const FeatureDescriptor* descriptor;\n        const FeatureGraphOps* graph;');p.write_text(s)
# Current consumers that need assembly must state it, while Feature.hpp remains descriptor-only.
for p in b.rglob('*'):
 if p.suffix not in ('.hpp','.cpp'):continue
 if p.name in ('Feature.hpp','Assembly.hpp','Registration.hpp','Assemble.cpp') and '/include/' in p.as_posix():continue
 s=p.read_text();t=s.replace('lux/engine/render/features/Feature.hpp','lux/engine/render/features/Assembly.hpp').replace('SelectedFeature','FeatureInstanceView').replace('selection_index','input_index')
 if s!=t:p.write_text(t)
