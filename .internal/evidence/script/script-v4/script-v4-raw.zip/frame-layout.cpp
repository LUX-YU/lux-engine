#include <lux/engine/simulation/scripting/cpp_static/ScriptCoroutine.hpp>
#include <lux/engine/simulation/scripting/detail/BoundedClassStorage.hpp>
#include <array>
#include <cstdio>

int main()
{
    using namespace lux::simulation::script;
    using Storage = detail::BoundedClassStorage;
    constexpr auto alignment = alignof(std::max_align_t);
    constexpr auto overhead = CppStaticCoroutineAccess::frameOverhead(alignment);
    constexpr auto stride = (512U + overhead + alignment - 1U) & ~(alignment - 1U);
    const std::array plans{detail::StorageClassPlan{512U + overhead, alignment, stride * 10000U, 1U}};
    auto storage = Storage::create(plans, 10000U * 1024U + 65536U, 20000U);
    if (!storage) return 1;
    const auto stats = storage->stats();
    std::printf("CPP_FRAME_LAYOUT,alignment=%zu,ticket=%zu,allocation=%zu,overhead=%zu,max_body=512,stride=%zu,"
        "arena=%zu,metadata=%zu,reserved_slots=%zu,observation=%d\n", alignment, sizeof(Storage::Ticket),
        sizeof(Storage::Allocation), overhead, stride, stats.arena_bytes, stats.metadata_bytes,
        stats.reserved_slots, stats.observation_collected);
    return stats.observation_collected || stats.reserved_slots != 10000U;
}
