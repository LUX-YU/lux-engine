#pragma once
// Generated typed Native projection. Include the matching .ability.generated.hpp first.
#include <lux/engine/simulation/scripting/native/NativeScriptAbilityProjection.hpp>

#include <array>
#include <type_traits>
#include <utility>

namespace lux::script::native
{

    template <>
    struct ScriptAbilityNativeTraits<::lux::simulation::script::DelayAbility> final
    {
        using AbilityTraits = ScriptAbilityTraits<::lux::simulation::script::DelayAbility>;

        [[nodiscard]] static int nextStep(
            void* invocation,
            void* provider,
            const void* dispatch_value,
            lux_script_async_token* waiting_on
        ) noexcept
        {
            const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(dispatch_value);
            return lux::simulation::script::detail::startNativeAbility<void>(
                invocation,
                waiting_on,
                [provider, &dispatch](
                    ScriptAbilityCompletion<void> completion
                ) noexcept
                {
                    return dispatch.nextStep(provider, std::move(completion));
                }
            );
        }

        [[nodiscard]] static int seconds(
            void* invocation,
            void* provider,
            const void* dispatch_value,
            std::remove_cvref_t<double> duration,
            lux_script_async_token* waiting_on
        ) noexcept
        {
            const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(dispatch_value);
            return lux::simulation::script::detail::startNativeAbility<void>(
                invocation,
                waiting_on,
                [provider, &dispatch, duration](
                    ScriptAbilityCompletion<void> completion
                ) noexcept
                {
                    return dispatch.seconds(provider, duration, std::move(completion));
                }
            );
        }

        [[nodiscard]] static int simulationSeconds(
            void* invocation,
            void* provider,
            const void* dispatch_value,
            std::remove_cvref_t<double> duration,
            lux_script_async_token* waiting_on
        ) noexcept
        {
            const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(dispatch_value);
            return lux::simulation::script::detail::startNativeAbility<void>(
                invocation,
                waiting_on,
                [provider, &dispatch, duration](
                    ScriptAbilityCompletion<void> completion
                ) noexcept
                {
                    return dispatch.simulationSeconds(provider, duration, std::move(completion));
                }
            );
        }

        [[nodiscard]] static int realSeconds(
            void* invocation,
            void* provider,
            const void* dispatch_value,
            std::remove_cvref_t<double> duration,
            lux_script_async_token* waiting_on
        ) noexcept
        {
            const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(dispatch_value);
            return lux::simulation::script::detail::startNativeAbility<void>(
                invocation,
                waiting_on,
                [provider, &dispatch, duration](
                    ScriptAbilityCompletion<void> completion
                ) noexcept
                {
                    return dispatch.realSeconds(provider, duration, std::move(completion));
                }
            );
        }

        inline static const std::array<ScriptAbilityNativeMethodProjection, AbilityTraits::Methods.size()> Methods{
            ScriptAbilityNativeMethodProjection{
                ScriptApiMethodIdView{"lux.simulation.delay.next_step"},
                reinterpret_cast<lux_script_ability_direct_entry_fn>(&nextStep)
            },
            ScriptAbilityNativeMethodProjection{
                ScriptApiMethodIdView{"lux.simulation.delay.seconds"},
                reinterpret_cast<lux_script_ability_direct_entry_fn>(&seconds)
            },
            ScriptAbilityNativeMethodProjection{
                ScriptApiMethodIdView{"lux.simulation.delay.simulation_seconds"},
                reinterpret_cast<lux_script_ability_direct_entry_fn>(&simulationSeconds)
            },
            ScriptAbilityNativeMethodProjection{
                ScriptApiMethodIdView{"lux.simulation.delay.real_seconds"},
                reinterpret_cast<lux_script_ability_direct_entry_fn>(&realSeconds)
            }
        };
    };
} // namespace lux::script::native
