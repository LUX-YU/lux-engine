from pathlib import Path
import re
base=Path('E:/SyncForder/CodeRepos');repo=base/'lux-engine-deep-optimization'
s=(base/'build/RelWithDebInfo/sr4/E0-ScriptSystem.cpp').read_text()
def method(name):
    m=re.search(r'^        (?:\[\[nodiscard\]\] )?(?:static )?[^\n]*\b'+name+r'\(',s,re.M)
    assert m,name
    a=m.start();start=s.index('{',m.end());depth=1;i=start+1
    while depth:
        depth+=(s[i]=='{')-(s[i]=='}');i+=1
    return s[a:i]+'\n'
records=s[s.index('        enum class EEventWaiterState'):s.index('        using ContinuationStorage')]
methods=method('unlinkEventWaiterRoute')+method('unlinkEventWaiterOwnership')+method('claimEventWaiters')
methods=methods.replace('findExecutionInstance(waiter.instance)','instanceRecord(waiter.instance)')
renames={'EventWaiterId':'ScriptSourceId','event_waiters':'waiters_','event_wait_routes':'routes_',
    'claimed_event_waiters':'claimed_','active_claimed_waiters':'active_claimed_',
    'event_route_claim_lookups':'claim_lookups_','event_waiter_dispatch_visits':'dispatch_visits_'}
for a,b in renames.items():
    records=re.sub(r'\b'+a+r'\b',b,records);methods=re.sub(r'\b'+a+r'\b',b,methods)
text='''#pragma once

#include <lux/engine/simulation/ScriptSystem.hpp>
#include <lux/engine/simulation/script/ScriptWaitSource.hpp>
#include <lux/cxx/container/SlotMap.hpp>
#include <entt/container/dense_map.hpp>
#include <limits>
#include <utility>

namespace lux::simulation::script::detail
{
    struct ScriptClaimedEventWait final
    {
        ScriptSourceId id;
        ScriptInstanceId instance;
        ScriptAwaitableId awaitable;
        std::uint32_t endpoint{};
    };

    class ScriptEventWaits final
    {
'''+records+'''
        struct EventWaiterTag;
        using EventWaiterStorage = lux::cxx::SlotMap<EventWaiterRecord, EventWaiterTag>;
        using EventWaiterKey = EventWaiterStorage::key_type;
        using EventRouteIndex = entt::dense_map<EventRouteKey, EventRouteHead, EventRouteKeyHash>;
        struct InstanceIndex final
        {
            ScriptInstanceId id;
            ScriptSourceId first_event_waiter;
        };
        [[nodiscard]] static constexpr ScriptSourceId eventWaiterId(EventWaiterKey key) noexcept
        {
            return {key.index + 1U, key.gen};
        }
        [[nodiscard]] static constexpr EventWaiterKey eventWaiterKey(ScriptSourceId id) noexcept
        {
            return id.valid() ? EventWaiterKey{id.slot - 1U, id.generation} : EventWaiterKey::invalid();
        }
        [[nodiscard]] InstanceIndex* instanceRecord(ScriptInstanceId instance) noexcept
        {
            if (!instance.valid() || instance.slot > instances_.size())
                return nullptr;
            auto& result = instances_[instance.slot - 1U];
            return result.id == instance ? &result : nullptr;
        }
'''+methods+'''
    public:
        class ClaimBatch final
        {
        public:
            ClaimBatch(const ClaimBatch&) = delete;
            ClaimBatch& operator=(const ClaimBatch&) = delete;
            ClaimBatch(ClaimBatch&& other) noexcept
                : owner_(std::exchange(other.owner_, nullptr)), begin_(other.begin_), end_(other.end_) {}
            ~ClaimBatch() noexcept
            {
                if (owner_ != nullptr)
                    owner_->finishClaim(begin_, end_);
            }
            [[nodiscard]] std::size_t size() const noexcept { return end_ - begin_; }
            [[nodiscard]] std::optional<ScriptClaimedEventWait> at(std::size_t offset) const noexcept
            {
                if (owner_ == nullptr || offset >= size())
                    return std::nullopt;
                return owner_->claimedValue(owner_->claimed_[begin_ + offset]);
            }
        private:
            friend class ScriptEventWaits;
            ClaimBatch(ScriptEventWaits& owner, std::size_t begin, std::size_t end) noexcept
                : owner_(&owner), begin_(begin), end_(end) {}
            ScriptEventWaits* owner_{};
            std::size_t begin_{};
            std::size_t end_{};
        };

        void prepare(std::size_t capacity, std::size_t instance_capacity)
        {
            capacity_ = capacity;
            waiters_.reserve(capacity);
            // Every route has an ACTIVE waiter. Registration's physical reservation bound therefore
            // bounds both dense_map arrays and buckets after reserve; trivial key/value insertion cannot allocate.
            routes_.reserve(capacity);
            claimed_.reserve(capacity);
            instances_.resize(instance_capacity);
        }
        void beginInstance(ScriptInstanceId instance) noexcept
        {
            auto& index = instances_[instance.slot - 1U];
            if (index.first_event_waiter.valid())
                std::terminate();
            index = {instance, {}};
        }
        [[nodiscard]] lux::cxx::expected<void, EScriptEventWaitError> preflight() const noexcept
        {
            const auto reserved = waiters_.size() - active_claimed_ + claimed_.size();
            if (reserved >= capacity_)
                return lux::cxx::unexpected(EScriptEventWaitError::WAITER_CAPACITY_EXCEEDED);
            if (sequence_ == std::numeric_limits<std::uint64_t>::max())
                return lux::cxx::unexpected(EScriptEventWaitError::SEQUENCE_EXHAUSTED);
            return {};
        }
        [[nodiscard]] lux::cxx::expected<ScriptSourceId, EScriptEventWaitError> registerWait(
            ScriptInstanceId instance, ScriptAwaitableId awaitable, std::uint32_t endpoint, ecs::Entity target) noexcept
        {
            auto* owner = instanceRecord(instance);
            if (owner == nullptr)
                return lux::cxx::unexpected(EScriptEventWaitError::INVALID_INSTANCE);
            const auto checked = preflight();
            if (!checked)
                return lux::cxx::unexpected(checked.error());
            const EventRouteKey key{endpoint, target};
            const auto [unused, inserted_route] = routes_.try_emplace(key, EventRouteHead{});
            const auto inserted = waiters_.tryEmplace(EventWaiterRecord{
                {}, instance, awaitable, endpoint, target, ++sequence_, EEventWaiterState::ACTIVE, {}, {}, {}, {}
            });
            if (!inserted)
            {
                if (inserted_route)
                    routes_.erase(key);
                return lux::cxx::unexpected(EScriptEventWaitError::ALLOCATION_FAILURE);
            }
            const auto id = eventWaiterId(*inserted);
            auto& waiter = waiters_[*inserted];
            waiter.id = id;
            auto route = routes_.find(key);
            waiter.route_previous = route->second.last;
            if (waiter.route_previous.valid())
                waiters_[eventWaiterKey(waiter.route_previous)].route_next = id;
            else
                route->second.first = id;
            route->second.last = id;
            waiter.instance_next = owner->first_event_waiter;
            if (waiter.instance_next.valid())
                waiters_[eventWaiterKey(waiter.instance_next)].instance_previous = id;
            owner->first_event_waiter = id;
            high_water_ = (std::max)(high_water_, waiters_.size());
            return id;
        }

        [[nodiscard]] ClaimBatch claim(std::uint32_t endpoint, ecs::Entity target) noexcept
        {
            const auto begin = claimed_.size();
            claimEventWaiters(endpoint, target, sequence_);
            return ClaimBatch{*this, begin, claimed_.size()};
        }

        [[nodiscard]] std::optional<ScriptSourceCancellation> cancel(ScriptSourceId id) noexcept
        {
            auto* waiter = waiters_.find(eventWaiterKey(id));
            if (waiter == nullptr)
                return std::nullopt;
            const ScriptSourceCancellation result{waiter->instance, waiter->awaitable, {id, EScriptWaitSource::EVENT}};
            if (waiter->state == EEventWaiterState::ACTIVE)
                unlinkEventWaiterRoute(*waiter);
            else
                --active_claimed_;
            unlinkEventWaiterOwnership(*waiter);
            static_cast<void>(waiters_.erase(eventWaiterKey(id)));
            return result;
        }
        [[nodiscard]] std::optional<ScriptSourceCancellation> cancelNext(ScriptInstanceId instance) noexcept
        {
            auto* owner = instanceRecord(instance);
            if (owner == nullptr || !owner->first_event_waiter.valid())
                return std::nullopt;
            const auto result = cancel(owner->first_event_waiter);
            if (!result)
                std::terminate();
            ++cleanup_visits_;
            return result;
        }
        [[nodiscard]] std::size_t claimedCount() const noexcept { return active_claimed_; }
        void shutdown() noexcept
        {
            if (!waiters_.empty() || !claimed_.empty())
                std::terminate();
            routes_.clear();
            instances_.clear();
        }
        void writeStats(ScriptRuntimeStats& result) const noexcept
        {
            result.active_event_waiters = waiters_.size();
            result.event_waiter_high_water = high_water_;
            result.event_waiter_dispatch_visits = dispatch_visits_;
            result.instance_cleanup_event_waiter_visits = cleanup_visits_;
            result.event_route_claim_lookups = claim_lookups_;
            result.event_waiter_record_bytes = sizeof(EventWaiterRecord);
        }
    private:
        [[nodiscard]] std::optional<ScriptClaimedEventWait> claimedValue(ScriptSourceId id) const noexcept
        {
            const auto* waiter = waiters_.find(eventWaiterKey(id));
            if (waiter == nullptr || waiter->state != EEventWaiterState::CLAIMED)
                return std::nullopt;
            return ScriptClaimedEventWait{id, waiter->instance, waiter->awaitable, waiter->bucket_slot};
        }
        void finishClaim(std::size_t begin, std::size_t end) noexcept
        {
            if (claimed_.size() != end)
                std::terminate();
            claimed_.resize(begin);
        }
        EventWaiterStorage waiters_;
        EventRouteIndex routes_;
        std::vector<ScriptSourceId> claimed_;
        std::vector<InstanceIndex> instances_;
        std::size_t capacity_{};
        std::uint64_t sequence_{};
        std::size_t active_claimed_{};
        std::size_t high_water_{};
        std::size_t dispatch_visits_{};
        std::size_t cleanup_visits_{};
        std::uint64_t claim_lookups_{};
    };
}
'''
(repo/'engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptEventWaits.hpp').write_text(text)
