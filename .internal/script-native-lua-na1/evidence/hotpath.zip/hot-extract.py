from pathlib import Path
import json,re
r=Path(__file__).parent;out=r/'hot-analysis';out.mkdir(exist_ok=True)
summary=[]
for side,folder in [('B0','machine-code2'),('B1','hot-machine-code')]:
 for filename in ['0-CppStaticScriptBridge.cpp.obj.asm','1-LuaScriptBackend.cpp.obj.asm','3-Tasks.CompleteTasks.script.generated.cpp.obj.asm']:
  text=(r/folder/filename).read_text();counts={}
  for block in text.split('Disassembly of section '):
   m=re.search(r'^0+ <(.*)>:',block,re.M)
   if not m:continue
   symbol=m[1];label=None
   if 'Tasks::longTask$_ResumeCoro' in symbol:label='long-resume'
   elif 'ScriptCoroutineContext::invokeSyncStep(' in symbol:label='cpp-invoke'
   elif 'State::resolveEvent(' in symbol:label='cpp-event'
   elif 'ScriptCoroutine::promise_type::prepareResume(' in symbol:label='prepare-resume'
   elif 'detail::syncStepSlot<int>' in symbol:label='typed-slot'
   elif 'ScriptCoroutineAwaiter<int,' in symbol and '::await_suspend' in symbol:label='awaiter-int'
   elif symbol.startswith('?await_suspend@?$ScriptCoroutineAwaiter@H'):label='awaiter-int'
   elif symbol.startswith('?await_resume@?$ScriptCoroutineAwaiter@H'):label='awaiter-result-int'
   elif 'LuaScriptBackend::Impl::invokeSyncStep<' in symbol and '<1,0,1,int>' in symbol.replace(' ','') and 'lambda' not in symbol:label='lua-scalar-int-void'
   if not label:continue
   n=counts.get(label,0);counts[label]=n+1
   path=out/f'{side}-{label}-{n}.asm.txt';path.write_text(block)
   relocations=re.findall(r'IMAGE_REL_AMD64_REL32\s+(.*)',block)
   summary.append(dict(side=side,label=label,file=path.name,symbol=symbol,divq=len(re.findall(r'\tdivq\s',block)),fnv_prime=bool(re.search('100000001b3',block,re.I)),lua_apis=[s for s in relocations if '__imp_lua' in s],relocations=relocations))
(out/'machine-summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps([{k:v for k,v in x.items() if k not in ['symbol','relocations']} for x in summary],indent=2))
