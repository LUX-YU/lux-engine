import argparse,hashlib,io,json,subprocess,zipfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--commit',required=True);args=p.parse_args()
r=Path(__file__).resolve().parent
bare=r/'remote-verify.git'
log=r/'remote-verify.log'
def run(*cmd):
 result=subprocess.run(cmd,capture_output=True)
 with log.open('ab') as f:f.write((' '.join(cmd)+'\n').encode());f.write(result.stderr)
 if result.returncode:raise RuntimeError(f'Command exit {result.returncode}: {cmd}')
 return result.stdout
if not bare.exists():run('git','init','--bare',str(bare))
run('git','-C',str(bare),'fetch','--depth=1','git@github.com:LUX-YU/lux-engine.git',
    'refs/heads/codex/s6-deep-optimization')
actual=run('git','-C',str(bare),'rev-parse','FETCH_HEAD').decode().strip()
assert actual==args.commit,(actual,args.commit)
base='.internal/evidence/script/sr6/'
def show(name):return run('git','-C',str(bare),'show',actual+':'+base+name)
data=show('SR6-qualification-raw-evidence.zip')
expected=show('SHA256SUMS').decode().split()[0]
digest=hashlib.sha256(data).hexdigest();assert digest==expected
index=json.loads(show('raw-files.json'))
with zipfile.ZipFile(io.BytesIO(data)) as z:
 assert len(z.namelist())==len(index)
 assert not any(Path(n).suffix.lower() in ('.dll','.exe','.obj','.lib','.pdb') for n in z.namelist())
 for item in index:
  value=z.read(item['path'])
  assert len(value)==item['size']
  assert hashlib.sha256(value).hexdigest()==item['sha256'],item['path']
result={'remote':'git@github.com:LUX-YU/lux-engine.git','branch':'codex/s6-deep-optimization',
        'download_commit':actual,'bytes':len(data),'entries':len(index),'sha256':digest,
        'all_entry_hashes_match':True,'compiled_binaries_in_archive':False,
        'method':'fresh bare fetch from GitHub; git show of immutable commit; every archive entry checked'}
(r/'remote-verification.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
