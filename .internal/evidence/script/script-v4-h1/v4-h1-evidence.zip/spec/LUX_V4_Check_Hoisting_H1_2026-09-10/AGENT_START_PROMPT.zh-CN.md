# 交给实施 LLM：执行 V4-H1

你需要实际实施代码、执行诊断和测试，不是再次输出优化建议。

先阅读同包 `IMPLEMENTATION.zh-CN.md`，再读取当前仓库 AGENTS.md 和被修改目录的规范。
本包是待实施规格；CHECK_AUDIT/TEST_MATRIX 的条目不是已经通过的验证。

## 身份

从 V4 开始，不从 A1 开始：

- 参考分支：`codex/s6-deep-optimization`，已读取 HEAD `f92853ea8361a7dc90ce0da072497d3722c29f88`。
- 固定比较源码：`f7d2815bdd2025ee23a7c11449def822413f58e9` 及其匹配 V4 镜像。
- 隔离候选分支：`codex/s6-v4-prepared-checks`。
- A1 `codex/s6-execution-cell-a1` 保留，不合并、不删除。

先核对实际 HEAD 与工作区，保护未知改动。不要 reset --hard、clean -fd 或 force-push。
不要混用 A1 公共头、SDK/DLL、EXE 与 V4。Native ABI 同为6不代表 C++ 接口兼容。

## 本轮核心原则

“装配期已证明的结构事实”不应在私有热内核重复验证。
“本次实际输入、当前调用来源、当前权限/代次、容量、状态、OOM”仍要在正确时点验证。
一次动态验证的结论只在其未失效的短区间内复用；不要缓存 ACTIVE 跨用户代码。

不要引入通用证书系统、第二scheduler、cell bank、新的结果池或宽Ready票据。
不允许 public trusted/skip_validation 参数，不用assert/assume替代实际边界处理。

## 连续实际执行

H0：冻结匹配 V4。对 Lua Event、FlowForge Event、scalar、ValuePose、C++ Sequence各取一次有效软件热点，
尽量限定实际业务ROI。输出目标callstack/机器码与检查分类。PMU不可用记录限制，不因驱动/权限反复停工。

H1：实际拆分 Native prepared-step 的结构不变量与运行资格。
prepare/loader 已证明的 step形状不再在 createNativeContinuation 内重复验证；
checked入口解析一次，私有 resolved kernel使用局部step引用。
保留当前slot/容量/lease/epoch、公开ordinal/buffer、实际packet和step状态检查及原清理顺序。

H2：实际拆分 Event 已准备结果与通用结果描述的入口，共用一个动态接纳内核。
eventSource 本次 scope/instance/layout/ordinal检查不删除；复用 prepareMount 已证明的payload结构。
保留Event source preflight→A→source commit、Timer A→duration/source、OOM/pin/queue/frontier及原错误优先级。
无用户代码且引用有效的短区间复用已有record，不反复传ID查回。

H3：实际将 BoundedClassStorage 的Ticket/Allocation两个checked release收敛到一个releaseResolved。
保留错owner、旧generation、double free和外部data/size验证，不合成Allocation后再验证自己。
Native固定slots算术可独立尝试，但不以扩大过量Class目录或收紧合法配置为代价；不满足就不采用。

H4：审查Lua projection。现有can_reenter已让默认scalar免去一处二次资格检查，不要重复实现。
只删边界之后真实重复的prepared解析；无重复就ALREADY_BOUNDARY_ONLY。
保留参数个数/类型/range/shape、closure来源、跨转换重验及W0内层checkstack。

H5：统一最终资格与七腿三对A/B；原脚本、业务、预算、资产、VM、GC、allocator、编译器参数不变。
不要为每个if做微测试，不跑旧VM，不为凑收益无限追加样本。

H0–H5连续推进，无需每个子提交再请求批准。H1/H2/H3未做不能写“适用工作全部完成”。
真实合同无法闭合的局部改动保留反例/状态，撤销该候选并继续独立工作；最终如实报告PARTIAL或NO_CLEAR_GAIN。

## 完成后的交付

CHECK_AUDIT.csv逐条填写：具体谓词、类别、装配/边界证明、失效点、旧坏输入的拒绝去向、机器码、测试证据。
提供最终源码与DLL/PDB/EXE身份，原始profile与导出、七腿原始计时/实际业务、sizeof及owned backing。
按实际影响重编译运行SDK消费者、增量与迁址集合；未运行的不能写PASS。
最终状态分 implementation/contract/cost。不合并V4/main，不发布tag，不覆盖原镜像。
