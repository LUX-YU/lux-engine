import hashlib, json, re, subprocess
from pathlib import Path
base = Path('E:/SyncForder/CodeRepos')
root = base/'build/RelWithDebInfo/sr3-event/diagnostics'
dump = 'D:/Development/Mircosoft/VisualStudio/VC/Tools/MSVC/14.44.35207/bin/Hostx64/x64/dumpbin.exe'
records=[]
for label, build_name in [('b2','sr3-c3'),('b3','sr3-e')]:
    build=base/f'build/RelWithDebInfo/{build_name}/d'
    for kind, path, option in [
        ('system',build/'engine/domain/simulation/builtin/script/CMakeFiles/simulation_script.dir/src/ScriptSystem.cpp.obj','/DISASM'),
        ('exports',build/'bin/lux_engine_simulation_script.dll','/EXPORTS')]:
        target=root/f'{label}-{kind}.txt'
        with target.open('w') as stream:
            subprocess.run([dump,option,str(path)],stdout=stream,check=True)
        records.append({'label':label,'kind':kind,'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    lines=(root/f'{label}-system.txt').read_text().splitlines()
    snippets=[]
    for symbol in ('?invoke@State','?resumeOne@State'):
        start=next(i for i,line in enumerate(lines) if line.startswith(symbol))
        end=next(i for i in range(start+1,len(lines)) if lines[i].endswith(':') and not lines[i].startswith(' '))
        snippets.extend(lines[start:end])
    (root/f'{label}-invoke-resume.txt').write_text('\n'.join(snippets)+'\n')
def names(label):
    return sorted(re.findall(r'^\s+\d+\s+[0-9A-F]+\s+[0-9A-F]+\s+(\S+)',(root/f'{label}-exports.txt').read_text(),re.M))
assert names('b2')==names('b3') and len(names('b2'))==26
(root/'machine-identity.json').write_text(json.dumps({'artifacts':records,'exports':names('b3'),
    'export_names_equal':True,'limitation':'Export names are only one ABI check. Production source is unchanged; no complete binary ABI proof is claimed.'},indent=2))
print('Actual optimized objects and linked export identities collected.')
