from pathlib import Path
import re
base=Path('E:/SyncForder/CodeRepos');repo=base/'lux-engine-deep-optimization'
s=(base/'build/RelWithDebInfo/sr4/E0-ScriptSystem.cpp').read_text()
def method(name):
    m=re.search(r'^        (?! ).*\b'+name+r'\(',s,re.M);assert m,name
    a=m.start();previous=s.rfind('\n',0,a-1)+1
    if s[previous:a].lstrip().startswith('[[nodiscard]]'):
        a=previous
    start=s.index('{',m.end());depth=1;i=start+1
    while depth:
        depth+=(s[i]=='{')-(s[i]=='}');i+=1
    return s[a:i]+'\n'
def struct(name,next_name):
    return s[s.index('        struct '+name):s.index('        '+next_name)]
def change(text,old,new,count=1):
    assert text.count(old)==count,(old,text.count(old));return text.replace(old,new)
records=struct('ExecutionInstance','using ExternalCompletionRecord')
records=records.replace('            EventWaiterId first_event_waiter;\n','')
records+=struct('AwaitableRecord','enum class EEventWaiterState').replace('EventWaiterId event_waiter;','ScriptWaitSource source;')
aliases='''        struct ContinuationTag;
        struct AwaitableTag;
        using Handler = ScriptMethodReference;
        using PreparedMethod = ScriptPreparedMethod;
        using ContinuationStorage = lux::cxx::SlotMap<ContinuationRecord, ContinuationTag>;
        using ContinuationKey = ContinuationStorage::key_type;
        using AwaitableStorage = lux::cxx::StableSlotMap<AwaitableRecord, AwaitableTag>;
        using AwaitableKey = AwaitableStorage::key_type;
'''
methods=''.join(method(n) for n in ['continuationId','continuationKey','awaitableId','awaitableKey'])
# Both overloads of findExecutionInstance must remain inside the owner.
methods+=s[s.index('        [[nodiscard]] ExecutionInstance* executionRecord'):s.index('        [[nodiscard]] bool validInstance')]
methods+=method('createAwaitableRecord')
methods+='''        [[nodiscard]] lux::cxx::expected<ScriptAwaitableRegistration, EScriptAwaitableCreateError>
        createAwaitable(ScriptInstanceId instance, std::optional<PreparedResumeType> type) noexcept
        {
            const auto created = createAwaitableRecord(instance, std::move(type));
            if (!created)
                return lux::cxx::unexpected(created.error());
            return ingress.registration(instance, *created, this, &ScriptExecution::completeAbilityOwnerErased,
                &ScriptExecution::failAbilityOwnerErased);
        }
'''
methods+=method('createAwaitableErased')+method('validAwaitableOutcome')+method('completeAwaitableOwner')
finish=method('finishAwaitableOwner')
finish=change(finish,'            record.error = error;','            record.error = error;\n            releaseSource(record);')
methods+=finish+method('completeAbilityOwnerErased')+method('failAbilityOwnerErased')
drain=method('drainExternalCompletions')
a=drain.index('            while (');b=drain.index('                auto* record =',a)
drain=drain[:a]+'''            while (const auto* external = ingress.peek())
            {
'''+drain[b:]
drain=drain.replace('ingress->completions.pop()','ingress.ack()')
methods+=method('eventWaitError')
wait=method('waitEvent')
wait=wait.replace('prepare_state != EPrepareState::PREPARED','!prepared')
wait=wait.replace('!registry->valid(entity->self)','!instance_owner.validEntity(entity->self)')
a=wait.index('            const auto reserved_waiters');b=wait.index('            auto awaitable =',a)
wait=wait[:a]+'''            const auto reservation = event_owner.preflight();
            if (!reservation)
                return lux::cxx::unexpected(reservation.error());

'''+wait[b:]
a=wait.index('            const EventRouteKey');b=wait.index('            return *awaitable;',a)
wait=wait[:a]+'''            const auto registered = event_owner.registerWait(instance, *awaitable, endpoint_slot, target);
            if (!registered)
            {
                discardAwaitable(instance, *awaitable);
                return lux::cxx::unexpected(registered.error());
            }
            auto* record = awaitables.find(awaitableKey(*awaitable));
            if (record == nullptr || record->instance != instance)
                std::terminate();
            record->source = {*registered, EScriptWaitSource::EVENT};
'''+wait[b:]
methods+=wait+method('waitEventErased')+method('attachWaiter')
methods+=struct('AwaitableOutcome','void unlinkAwaitableOwnership')+method('unlinkAwaitableOwnership')
erase=method('eraseAwaitable')
erase=change(erase,'            unlinkAwaitableOwnership(*record);','            releaseSource(*record);\n            unlinkAwaitableOwnership(*record);')
methods+=erase+struct('ResultWritePin','[[nodiscard]] std::optional<AwaitableOutcome> takeAwaitable')
methods+=method('takeAwaitable')+method('cancelAwaitables')
methods+='''        void releaseSource(AwaitableRecord& record) noexcept
        {
            const auto source = std::exchange(record.source, {});
            if (source.kind == EScriptWaitSource::EVENT)
                static_cast<void>(event_owner.cancel(source.id));
            else if (source.kind == EScriptWaitSource::TIMER)
                static_cast<void>(timer_owner.cancel(source.id));
        }
        void eraseEventWaiter(ScriptSourceId id) noexcept
        {
            if (const auto removed = event_owner.cancel(id))
                detachSource(*removed);
        }
        void discardAwaitable(ScriptInstanceId instance, ScriptAwaitableId id) noexcept
        {
            const auto* record = awaitables.find(awaitableKey(id));
            if (record != nullptr && record->instance == instance)
                static_cast<void>(eraseAwaitable(id));
        }
'''
methods+=method('discardAwaitableErased')+method('clearActiveHook')+method('destroyContinuation')+method('destroyContinuations')
invalidate=method('invalidateAdmission')
invalidate=change(invalidate,'            const auto first_event_waiter = record->first_event_waiter;\n','')
invalidate=change(invalidate,'            cancelEventWaiters(instance, first_event_waiter);','''            while (const auto cancelled = event_owner.cancelNext(instance))
                detachSource(*cancelled);
            while (const auto cancelled = timer_owner.cancelNext(instance))
                detachSource(*cancelled);''')
retire=method('invalidateInstance').replace('std::uint32_t slot','ScriptInstanceId retired')
retire=change(retire,'            const auto retired = instance_owner.view(slot).retiring_instance;\n','')
methods+='''        void faultInvocation(std::uint32_t slot, lux::script::ScriptSymbolId symbol,
            EScriptSystemError error, std::int32_t status = 0) noexcept
        {
            failures_.fault(failures_.context, slot, symbol, error, status);
        }
'''+method('beginSuspension')+method('failEventWaiter')+method('resumeOne')
invoke=method('invoke')
complete=method('completeClaimedEventWaiter')
start=complete.index('        void completeClaimedEventWaiter');end=complete.index('            const bool is_live',start)
complete='''        void completeClaimedEventWaiter(const ScriptClaimedEventWait& waiter, lux_script_call_frame& frame) noexcept
        {
            const auto id = waiter.id;
            const auto instance = waiter.instance;
            const auto awaitable = waiter.awaitable;
'''+complete[end:]
complete=complete.replace('binding_owner.eventEndpoint(waiter->bucket_slot)','binding_owner.eventEndpoint(waiter.endpoint)')
public='''    public:
        using Result = lux::cxx::expected<void, EScriptSystemError>;
        ScriptExecution(ScriptInstances& instances, ScriptBindings& bindings, ScriptEventWaits& events,
            ScriptTimers& timers, ScriptCompletionIngress& ingress) noexcept
            : instance_owner(instances), binding_owner(bindings), event_owner(events), timer_owner(timers), ingress(ingress) {}
        ScriptExecution(const ScriptExecution&) = delete;
        ScriptExecution& operator=(const ScriptExecution&) = delete;

        void prepare(ScriptRuntimeLimits configured, std::size_t instance_capacity,
            std::size_t method_capacity, ScriptExecutionFailureSink failures)
        {
            limits = configured;
            failures_ = failures;
            execution_instances.resize(instance_capacity);
            active_hooks.resize(method_capacity);
            continuations.reserve(limits.continuation_capacity);
            awaitables.reserve(limits.awaitable_capacity);
            resumes.prepare(limits.resume_queue_capacity);
        }
        void beginInstance(ScriptInstanceId instance, std::uint32_t slot) noexcept
        {
            execution_instances[instance.slot - 1U] = {instance, slot};
        }
        void enablePrepared() noexcept { prepared = true; }
        void stop() noexcept { stopping = true; }
        [[nodiscard]] std::size_t resultPins() const noexcept { return result_write_pins; }
        [[nodiscard]] std::size_t activeContinuations() const noexcept { return continuations.size(); }
        [[nodiscard]] std::size_t activeAwaitables() const noexcept
        {
            return awaitables.size() - pending_awaitable_releases;
        }
        [[nodiscard]] std::size_t physicalAwaitableCapacity() const noexcept { return awaitables.capacity(); }

        [[nodiscard]] std::optional<ScriptTimerAssociation> timerAssociation(
            const lux::script::ScriptAbilityCompletion<void>& completion) const noexcept
        {
            std::uint64_t a{}, b{};
            if (!lux::script::detail::ScriptAbilityOwnerCompletionAccess::matchOwner(completion, this, a, b))
                return std::nullopt;
            const auto instance = ScriptCompletionIngress::unpackInstance(a);
            const auto id = ScriptCompletionIngress::unpackAwaitable(b);
            const auto* record = awaitables.find(awaitableKey(id));
            const bool matches = !stopping && instance_owner.active(instance) && record != nullptr &&
                record->instance == instance && record->state == EScriptAwaitableState::PENDING &&
                !record->release_pending && record->source.kind == EScriptWaitSource::NONE;
            return matches ? std::optional{ScriptTimerAssociation{instance, id}} : std::nullopt;
        }
        [[nodiscard]] bool attachTimer(ScriptTimerAssociation association, ScriptSourceId id) noexcept
        {
            auto* record = awaitables.find(awaitableKey(association.awaitable));
            const bool matches = !stopping && record != nullptr && record->instance == association.instance &&
                record->state == EScriptAwaitableState::PENDING && !record->release_pending &&
                record->source.kind == EScriptWaitSource::NONE && instance_owner.active(association.instance);
            if (matches)
                record->source = {id, EScriptWaitSource::TIMER};
            return matches;
        }
        void detachSource(ScriptSourceCancellation cancelled) noexcept
        {
            auto* record = awaitables.find(awaitableKey(cancelled.awaitable));
            if (record != nullptr && record->instance == cancelled.instance && record->source == cancelled.source)
                record->source = {};
        }
'''+invalidate+retire+invoke+complete+drain+'''
        class ResumeBatch final
        {
        public:
            [[nodiscard]] std::optional<Result> next() noexcept
            {
                if (remaining_ == 0U)
                    return std::nullopt;
                const auto record = owner_.resumes.pop();
                if (!record)
                    return std::nullopt;
                --remaining_; // Every pop, including a stale one, consumes exactly one budget unit.
                return owner_.resumeOne(*record);
            }
        private:
            friend class ScriptExecution;
            ResumeBatch(ScriptExecution& owner, std::size_t budget) noexcept : owner_(owner), remaining_(budget) {}
            ScriptExecution& owner_;
            std::size_t remaining_{};
        };
        [[nodiscard]] ResumeBatch resumeBatch() noexcept { return ResumeBatch{*this, limits.resumes_per_stable_point}; }

        void shutdown() noexcept
        {
            if (!continuations.empty() || !awaitables.empty() || result_write_pins != 0U)
                std::terminate();
            execution_instances.clear();
            active_hooks.clear();
            continuations.clear();
            awaitables.clear();
            resumes.clear();
        }
        void writeStats(ScriptRuntimeStats& result) const noexcept
        {
            result.sync_invocations = sync_invocations;
            result.step_invocations = step_invocations;
            result.backend_resume_calls = backend_resume_calls;
            result.suspensions_admitted = suspensions_admitted;
            result.active_continuations = continuations.size();
            result.active_awaitables = activeAwaitables();
            result.instance_cleanup_awaitable_visits = instance_cleanup_awaitable_visits;
            result.instance_cleanup_continuation_visits = instance_cleanup_continuation_visits;
            result.event_payload_copy_bytes = event_payload_copy_bytes;
            result.result_write_pins = result_write_pins;
            result.deferred_awaitable_releases = pending_awaitable_releases;
            result.awaitable_record_bytes = sizeof(AwaitableRecord);
            result.awaitable_reserved_slots = awaitables.capacity();
            result.awaitable_storage_bytes = awaitables.storageBytes();
            result.resume_queue_depth = resumes.count;
            result.resume_queue_high_water = resumes.high_water;
        }
'''
fields='''    private:
        ScriptInstances& instance_owner;
        ScriptBindings& binding_owner;
        ScriptEventWaits& event_owner;
        ScriptTimers& timer_owner;
        ScriptCompletionIngress& ingress;
        ScriptRuntimeLimits limits;
        ScriptExecutionFailureSink failures_;
        std::vector<ExecutionInstance> execution_instances;
        struct HookFlight final
        {
            ScriptInstanceId instance;
            ScriptContinuationId continuation;
        };
        std::vector<HookFlight> active_hooks;
        ContinuationStorage continuations;
        AwaitableStorage awaitables;
        ResumeRing resumes;
        std::size_t instance_cleanup_awaitable_visits{};
        std::size_t instance_cleanup_continuation_visits{};
        std::size_t pending_awaitable_releases{};
        std::size_t result_write_pins{};
        std::uint64_t event_payload_copy_bytes{};
        std::uint64_t sync_invocations{};
        std::uint64_t step_invocations{};
        std::uint64_t backend_resume_calls{};
        std::uint64_t suspensions_admitted{};
        bool stopping{};
        bool prepared{};
'''
scope='''        struct UserInvocationScope final
        {
            explicit UserInvocationScope(ScriptExecution& owner) noexcept : protection(owner.instance_owner) {}
            ScriptInstances::Protection protection;
        };
'''
text=records+aliases+scope+methods+public+fields
text=text.replace('static_cast<ExecutionPort*>(context)->owner->','static_cast<ScriptExecution*>(context)->')
text=text.replace('*static_cast<ExecutionPort*>(context)->owner','*static_cast<ScriptExecution*>(context)')
text=text.replace('&execution_port','this').replace('&State::','&ScriptExecution::').replace('State&','ScriptExecution&')
text=text.replace('AwaitableIngress::','ScriptCompletionIngress::')
text=text.replace('ingress->completions.open','ingress.open').replace('ingress->completions.close','ingress.close')
names=['instance_owner','binding_owner','event_owner','timer_owner','ingress','limits','execution_instances','active_hooks',
       'continuations','awaitables','resumes','instance_cleanup_awaitable_visits','instance_cleanup_continuation_visits',
       'pending_awaitable_releases','result_write_pins','event_payload_copy_bytes','sync_invocations','step_invocations',
       'backend_resume_calls','suspensions_admitted','stopping','prepared']
for name in names:
    # Public ScriptRuntimeStats fields retain their wire/API spelling; only this owner's members change.
    text=re.sub(r'(?<!result\.)\b'+name+r'\b',name+'_',text)
header='''#pragma once

#include <lux/engine/simulation/script/ScriptInstances.hpp>
#include <lux/engine/simulation/script/ScriptEventWaits.hpp>
#include <lux/engine/simulation/script/ScriptTimers.hpp>
#include <lux/engine/simulation/script/ScriptCompletionIngress.hpp>
#include <lux/engine/function/script/ScriptAbilityAsync.hpp>
#include <lux/cxx/container/StableSlotMap.hpp>

namespace lux::simulation::script::detail
{
    struct ScriptExecutionFailureSink final
    {
        void* context{};
        void (*fault)(void*, std::uint32_t, lux::script::ScriptSymbolId, EScriptSystemError, std::int32_t) noexcept{};
    };

    class ScriptExecution final
    {
'''
(repo/'engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptExecution.hpp').write_text(header+text+'    };\n}\n')
