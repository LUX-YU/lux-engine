#pragma once
// Production: engine/editor/editing/include/lux/engine/editor/editing/EditHistory.hpp.
#include "EditOperation.contract.hpp"
#include <memory>
namespace lux::editor::editing
{
    class EditHistory final
    {
    public:
        using CreateResult = EditResult<std::unique_ptr<EditHistory>>;
        [[nodiscard]] static CreateResult create(HistoryCreateInfo info) noexcept;
        ~EditHistory() noexcept;
        EditHistory(const EditHistory&) = delete;
        EditHistory& operator=(const EditHistory&) = delete;
        EditHistory(EditHistory&&) = delete;
        EditHistory& operator=(EditHistory&&) = delete;
        [[nodiscard]] HistoryId id() const noexcept;
        [[nodiscard]] EditResult<HistoryView> view() const noexcept;
        [[nodiscard]] EditResult<HistoryEntryView> entry(std::size_t index) const noexcept;
        // Failure: caller retains unchanged operation.
        // CHANGE success: ownership moves into history, input becomes null.
        // NO_CHANGE success: input is destroyed under the gate, without new history, then null.
        [[nodiscard]] EditResult<ApplyResult> execute(EditOperationPtr& operation) noexcept;
        [[nodiscard]] EditResult<ApplyResult> undo() noexcept;
        [[nodiscard]] EditResult<ApplyResult> redo() noexcept;
        // Metadata only; no file I/O or asynchronous task is started here.
        [[nodiscard]] EditResult<SaveTicket> beginSave() noexcept;
        [[nodiscard]] EditResult<void> finishSave(SaveTicket ticket, ESaveOutcome outcome) noexcept;
        [[nodiscard]] EditResult<void> clear() noexcept;
        [[nodiscard]] EditResult<void> close() noexcept;
    private:
        struct Impl;
        explicit EditHistory(std::unique_ptr<Impl> impl) noexcept;
        std::unique_ptr<Impl> impl_;
    };
}
