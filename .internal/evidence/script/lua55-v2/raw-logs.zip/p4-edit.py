from pathlib import Path
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source')
p=r/'engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptInstances.hpp'; t=p.read_text(); marker='        class Protection final'; t=t.replace(marker,'''        // Stable, read-only authority. The owner alone writes InvocationState; every query re-reads it.
        class AuthorityAccess final
        {
        public:
            AuthorityAccess() = default;
            [[nodiscard]] bool valid() const noexcept;
            [[nodiscard]] bool current() const noexcept;
        private:
            friend class ScriptInstances;
            AuthorityAccess(const InvocationState* state, ScriptInstanceId identity) noexcept
                : state_(state), identity_(identity) {}
            const InvocationState* state_{};
            ScriptInstanceId identity_;
        };
        [[nodiscard]] AuthorityAccess authorityAccess(ScriptInstanceId identity, std::uint32_t slot) const noexcept;

'''+marker,1); marker='    inline bool ScriptInstances::valid(ScriptInstanceId instance) const noexcept'; t=t.replace(marker,'''    inline bool ScriptInstances::AuthorityAccess::valid() const noexcept
    {
        return state_ != nullptr && state_->instance == identity_;
    }
    inline bool ScriptInstances::AuthorityAccess::current() const noexcept
    {
        return valid() && state_->state == EScriptMountState::ACTIVE;
    }
    inline ScriptInstances::AuthorityAccess
    ScriptInstances::authorityAccess(ScriptInstanceId identity, std::uint32_t slot) const noexcept
    {
        if (slot >= invocation_states_.size() || !identity.valid()) return {};
        const auto& state = invocation_states_[slot];
        return state.instance == identity ? AuthorityAccess{&state, identity} : AuthorityAccess{};
    }
'''+marker); p.write_text(t)
p=r/'engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptExecution.hpp'; t=p.read_text(); t=t.replace('            bool admission_revoked{};','            bool admission_revoked{};\n            ScriptInstances::AuthorityAccess authority;',1); t=t.replace('record->id == identity && !record->admission_revoked;','record->id == identity && !record->admission_revoked && record->authority.current();');t=t.replace('''            return instance_owner_.valid(id) ? executionRecord(id) : nullptr;''','''            auto* record = executionRecord(id);
            return record != nullptr && record->authority.valid() ? record : nullptr;''');t=t.replace('''            if (!instance_owner_.valid(id) || id.slot > execution_instances_.size())''','''            if (!id.valid() || id.slot > execution_instances_.size())''');t=t.replace('''            return record.id == id ? &record : nullptr;
        }

        [[nodiscard]] lux::cxx::expected<AwaitableRecord*''','''            return record.id == id && record.authority.valid() ? &record : nullptr;
        }

        [[nodiscard]] lux::cxx::expected<AwaitableRecord*'''); t=t.replace('''            execution_instances_[instance.slot - 1U] = {instance, slot};''','''            execution_instances_[instance.slot - 1U] = {instance, slot};
            execution_instances_[instance.slot - 1U].authority = instance_owner_.authorityAccess(instance, slot);''')
# owner borrow valid throughout result unlink: no callback, array never moves
s='''            auto current = first;
            while (current.valid())'''; pos=t.index('        void cancelAwaitables('); a=t[:pos]; b=t[pos:]; b=b.replace(s,'''            const ExecutionAccess access{executionRecord(instance), instance};
            auto current = first;
            while (current.valid())''',1).replace('eraseAwaitableRecord(*record, {executionRecord(instance), instance})','eraseAwaitableRecord(*record, access)',1); t=a+b
# Already located discarded record, no second lookup.
t=t.replace('''            const auto* record = awaitables_.find(awaitableKey(id));
            if (record != nullptr && record->instance == instance)
                static_cast<void>(eraseAwaitable(id));''','''            auto* record = awaitables_.find(awaitableKey(id));
            if (record != nullptr && record->instance == instance)
                static_cast<void>(eraseAwaitableRecord(*record, {executionRecord(instance), instance}));''')
t=t.replace('''            if (owner != nullptr && instance_owner_.active(instance))''','''            if (owner != nullptr && owner->authority.current())''')
t=t.replace('''            auto access = instance_owner_.resumeAccess(resume.instance, instance->mount_slot);
            if (!access)''','''            if (!execution.current())'''); t=t.replace('''            if (!execution.current() || !access.current())''','''            if (!execution.current())''')
t=t.replace('''            const bool matches = !stopping_ && instance_owner_.active(instance) && record != nullptr &&''','''            const auto* owner = findExecutionInstance(instance);
            const bool matches = !stopping_ && owner != nullptr && owner->authority.current() && record != nullptr &&''')
a=t.index('        void completeClaimedEventWaiter('); b=t.index('\n        ',t.index('            switch (completed.error())',a)+1) if False else 0
# scoped changes inside method only, retain existing source API for external cancellation
start=t[:a]; tail=t[a:]; end=tail.index('        class ResumeBatch') if '        class ResumeBatch' in tail else len(tail)
method=tail[:end]; rest=tail[end:]
method=method.replace('''            const bool is_live = instance_owner_.active(instance);''','''            auto* owner = executionRecord(instance);
            const ExecutionAccess execution{owner, instance};
            const bool is_live = execution.current();''',1)
method=method.replace('''                eraseEventWaiter(id);
                return;
            }
            ResultWritePin''','''                static_cast<void>(event_owner_.cancel(id));
                return;
            }
            ResultWritePin''',1)
method=method.replace('''            const bool still_live = !stopping_ && !record->release_pending && instance_owner_.active(instance);''','''            const bool still_live = !stopping_ && !record->release_pending && execution.current();''',1)
method=method.replace('''                eraseEventWaiter(id);
                discardAwaitable(instance, awaitable);
                if (still_live) failEventWaiter(instance, EScriptSystemError::INVOCATION_FAILURE);''','''                static_cast<void>(eraseAwaitableRecord(*record, execution));
                if (still_live) faultInvocation(owner->mount_slot, lux::script::InvalidScriptSymbolId,
                    EScriptSystemError::INVOCATION_FAILURE);''',1)
method=method.replace('''            eraseEventWaiter(id);
            const auto completed''','''            releaseSource(*record);
            const auto completed''',1)
method=method.replace('''            discardAwaitable(instance, awaitable);
            switch (completed.error())''','''            static_cast<void>(eraseAwaitableRecord(*record, execution));
            switch (completed.error())''',1)
t=start+method+rest; p.write_text(t)
p=r/'engine/domain/simulation/scripting/core/include/lux/engine/simulation/scripting/ScriptRuntime.hpp'; t=p.read_text().replace('ScriptOwnedBytes() noexcept = default;','ScriptOwnedBytes() noexcept {} // Payload bytes become readable only after a successful producer writes them.').replace('std::array<std::byte, InlineCapacity> inline_{};','std::array<std::byte, InlineCapacity> inline_;'); p.write_text(t)
