#pragma once
// Generated typed value operations. No offsets or runtime reflection interpretation.
#include <lux/engine/function/script/lua/LuaValue.hpp>
#include <CollisionValue.hpp>

namespace lux::script::lua
{


template <> struct LuaGeneratedValue<::CollisionEvent> : LuaRecordValue<::CollisionEvent,
    LuaValueField<&::CollisionEvent::body, "body">,
    LuaValueField<&::CollisionEvent::impulse, "impulse">>
{
};
static_assert(LuaValueCodec<::CollisionEvent>::bounded, "Lua value expanded frame exceeds 64 KiB or depth 32");
}
