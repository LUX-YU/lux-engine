#pragma once
// Production: engine/editor/editing/include/lux/engine/editor/editing/EditOperation.hpp.
#include "EditTypes.contract.hpp"
#include <memory>
namespace lux::editor::editing
{
    class PreparedEdit
    {
    public:
        virtual ~PreparedEdit() noexcept = default;
        PreparedEdit(const PreparedEdit&) = delete;
        PreparedEdit& operator=(const PreparedEdit&) = delete;
        PreparedEdit(PreparedEdit&&) = delete;
        PreparedEdit& operator=(PreparedEdit&&) = delete;
        [[nodiscard]] virtual EEditEffect effect() const noexcept = 0;
    protected:
        PreparedEdit() noexcept = default;
    private:
        friend class EditHistory;
        // No new allocations, validation, callbacks, I/O, or fallible live-model mutation.
        virtual void apply() noexcept = 0;
        // Business model AND history are committed before this call.
        virtual void publish(const CommitInfo&) noexcept = 0;
    };
    using PreparedEditPtr = std::unique_ptr<PreparedEdit>;
    class EditOperation
    {
    public:
        virtual ~EditOperation() noexcept = default;
        EditOperation(const EditOperation&) = delete;
        EditOperation& operator=(const EditOperation&) = delete;
        EditOperation(EditOperation&&) = delete;
        EditOperation& operator=(EditOperation&&) = delete;
        [[nodiscard]] virtual HistoryId historyId() const noexcept = 0;
        [[nodiscard]] virtual StateId baseState() const noexcept = 0;
        [[nodiscard]] virtual std::string_view label() const noexcept = 0;
        [[nodiscard]] virtual std::size_t retainedBytesUpperBound() const noexcept = 0;
        [[nodiscard]] virtual EditResult<PreparedEditPtr>
        prepare(const ApplyContext& context, EditPreparationBudget& budget) const noexcept = 0;
    protected:
        EditOperation() noexcept = default;
    };
    using EditOperationPtr = std::unique_ptr<EditOperation>;
}
