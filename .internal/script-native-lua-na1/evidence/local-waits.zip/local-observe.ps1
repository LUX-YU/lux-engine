$ErrorActionPreference='Stop'
$python='C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
& $python -B "$PSScriptRoot/local-resources.py"
if($LASTEXITCODE){throw 'Resources failed'}
& $python -B "$PSScriptRoot/local-profile.py"
if($LASTEXITCODE){throw 'Profile driver failed'}
& $python -B "$PSScriptRoot/local-analysis.py"
if($LASTEXITCODE){throw 'Analysis failed'}
& $python -B "$PSScriptRoot/local-phases.py"
if($LASTEXITCODE){throw 'Phase analysis failed'}
