import hashlib,json,shutil,subprocess
from pathlib import Path
r=Path(__file__).parent;out=r/'machine-code';out.mkdir(exist_ok=False)
llvm=Path('D:/Development/Mircosoft/VisualStudio/VC/Tools/Llvm/x64/bin')
records=[]
for side in ['A','B']:
 common=r/'images'/(side+'-common');reference=r/'images'/side
 for dll in common.glob('*.dll'):
  pdb=reference/(dll.stem+'.pdb')
  if pdb.exists():
   assert hashlib.sha256(dll.read_bytes()).digest()==hashlib.sha256((reference/dll.name).read_bytes()).digest()
   shutil.copy2(pdb,common/pdb.name)
 for name,match in [('lux_engine_simulation_script','ScriptExecution|ScriptEventWaits|ScriptTimers|ScriptInstances|ScriptBindings|ScriptCompletionIngress|ExternalCompletion'),('lux_engine_simulation_script_cpp_static','CppStaticScriptBackend|ScriptCoroutineContext|ScriptSyncStep'),('lux_engine_simulation_script_lua','LuaScriptBackend'),('native_lua_complete_tasks','lux::simulation::na1::cost::Tasks')]:
  p=common/(name+'.pdb');command=[str(llvm/'llvm-pdbutil.exe'),'pretty','--classes','--class-definitions=layout','--class-recurse-depth=2','--include-types='+match,str(p)]
  with (out/(side+'-'+name+'-layout.txt')).open('wb') as f:code=subprocess.call(command,stdout=f,stderr=subprocess.STDOUT)
  records.append(dict(kind='layout',side=side,command=command,exit=code,pdb_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
dev=r.parent/'o/w/d';objects=[]
for file in ['CppStaticScriptBridge.cpp.obj','LuaScriptBackend.cpp.obj','NativeLuaTaskBackend.cpp.obj']:
 found=list(dev.rglob(file));assert len(found)==1;objects+=found
objects+=list((r/'benchmark-slots/B').rglob('Tasks.CompleteTasks.script.generated.cpp.obj'))
for i,p in enumerate(objects):
 command=[str(llvm/'llvm-objdump.exe'),'-dr','--demangle',str(p)]
 with (out/(str(i)+'-'+p.name+'.asm')).open('wb') as f:code=subprocess.call(command,stdout=f,stderr=subprocess.STDOUT)
 records.append(dict(kind='disassembly',command=command,exit=code,object_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(out/'commands.json').write_text(json.dumps(records,indent=2))
print('MACHINE_CODE_CAPTURED',len(records),flush=True)
