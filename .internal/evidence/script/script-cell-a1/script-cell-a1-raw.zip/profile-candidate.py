"""One bounded whole-process software sample; never a formal performance pair."""
from pathlib import Path
import csv,ctypes as ct,json,os,subprocess,sys,time
r=Path(__file__).parent;out=r/'candidate-profile';out.mkdir(exist_ok=False);image=r/'final-image'
vtune='D:/Softwares/Intel/oneAPI/vtune/2026.3/bin64/vtune.exe'
env=dict(os.environ);env['PATH']=';'.join([str(image),'D:/Development/vcpkg/installed/x64-windows/bin',
 *[p for p in env['PATH'].split(';') if 'CodeRepos' not in p and 'vcpkg' not in p]])
k=ct.WinDLL('kernel32');k.GetCurrentProcess.restype=ct.c_void_p;k.SetProcessAffinityMask.argtypes=[ct.c_void_p,ct.c_size_t]
assert k.SetProcessAffinityMask(k.GetCurrentProcess(),16)
app=[str(image/'script_runtime_benchmark.exe'),'--group','scene-lua-event','--mode','performance',
 '--size','10000','--warmups','1000','--frames','2000','--resume-budget','10000','--seed','1592598566',
 '--vm-accounting','off','--lua-artifact',str(image/'lua_runtime_benchmark_fixture.lxsa'),'--output',str(out/'business.csv')]
(out/'target-command.json').write_text(json.dumps(app,indent=2))
records=[]
def run(name,command):
 start=time.monotonic()
 with (out/(name+'.log')).open('wb') as f:code=subprocess.call(command,stdout=f,stderr=subprocess.STDOUT,env=env)
 records.append(dict(name=name,command=command,exit=code,seconds=time.monotonic()-start))
 (out/'runs.json').write_text(json.dumps(records,indent=2));print(name,code,flush=True);return code
if not Path(vtune).exists():
 (out/'limitation.txt').write_text('VTune executable unavailable. No PMU claim.');sys.exit(0)
command=[vtune,'-collect','hotspots','-knob','sampling-mode=sw','-knob','enable-stack-collection=true',
 '-knob','enable-characterization-insights=false','-return-app-exitcode','-result-dir',str(out/'result'),
 '-search-dir',str(image),'-source-search-dir',str(r.parent/'script-region-opt/final-source'),
 '--',sys.executable,'-B',str(r/'profile-target.py'),str(out)]
code=run('collect',command)
text=(out/'target.log').read_text() if (out/'target.log').exists() else ''
rows=list(csv.DictReader((out/'business.csv').open())) if (out/'business.csv').exists() else []
valid=code==0 and len(rows)==2000 and 'completed=30000000,per_instance=93001,checksum=930010000' in text and text.count('invocation_errors=0')==2
(out/'identity.json').write_text(json.dumps(dict(valid=valid,source=json.loads((image/'identity.json').read_text())['source'],
 image=str(image/'identity.json'),PMU=False,scope='whole child process including setup/warmup/oracle/cleanup; launcher filtered',timing_qualification=False),indent=2))
if valid:
 for name in ['summary','hotspots','top-down']:
  run(name,[vtune,'-report',name,'-r',str(out/'result'),'-format','csv','-csv-delimiter','comma','-limit','10000',
    '-filter','process=script_runtime_benchmark.exe','-report-output',str(out/(name+'.csv'))])
