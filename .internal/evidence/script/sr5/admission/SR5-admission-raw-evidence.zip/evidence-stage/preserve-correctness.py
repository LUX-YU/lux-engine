import hashlib,json,shutil,subprocess
from pathlib import Path
r=Path(__file__).resolve().parent;dst=r/'correctness-qualification';dst.mkdir(exist_ok=False)
for p in (r/'q').rglob('*'):
 if p.is_file() and (p.name in {'qualification.json','configure.log','all.log','ctest.log','install.log','second-build.log','tracked.log','cross-profile-fixtures.log','LastTest.log','CMakeCache.txt','compile_commands.json','build.ninja'}):
  q=dst/p.relative_to(r/'q');q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
rows=[]
for profile in ('t','d','l'):
 for p in (r/'q'/profile/'bin').glob('*'):
  if p.suffix in ('.exe','.dll'):rows.append({'profile':profile,'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(dst/'binaries.json').write_text(json.dumps(rows,indent=2))
(dst/'source.json').write_text(json.dumps({'head':subprocess.check_output(['git','-C',str(r/'candidate-source'),'rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','-C',str(r/'candidate-source'),'status','--porcelain'],text=True).strip()},indent=2))
print('correctness qualification preserved')
