from pathlib import Path
import json
r=Path.cwd()
for x in json.loads((r/'local-analysis/profiles.json').read_text()):
 print(x['side']);print([(p['target'],round(p['inclusive_seconds'],4),round(p['main_path_self_seconds'],4)) for p in x['selected_inclusive_not_additive']]);print([(p['Function'],p['CPU Time']) for p in x['top_self'][:12]])
for x in json.loads((r/'local-analysis/phases.json').read_text()):print(x['side'],{k:round(v['seconds'],4) for k,v in x['groups'].items()})
