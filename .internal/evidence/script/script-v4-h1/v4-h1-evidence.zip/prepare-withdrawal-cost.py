from pathlib import Path
r=Path(__file__).parent
s=(r/'final-costs.py').read_text()
s=s.replace("out=r/'final-costs'", "out=r/'h2-withdrawal-costs'")
s=s.replace("a_source='f7d2815bdd2025ee23a7c11449def822413f58e9'", "a_source=identity['source']")
s=s.replace("scenes=['event','nextstep','flowforge-event','cpp-sequence','scalar','record','physics']", "scenes=['flowforge-event']")
s=s.replace("home=base if side=='A' else r\n   image=home/('final-flow-image' if scene=='flowforge-event' else 'final-image')", "image=r/'final-flow-image' if side=='A' else r/'h2-withdrawal/image'")
s=s.replace("source=expected_source,command=command", "source=expected_source,diagnostic_overlay=None if side=='A' else 'H2 ScriptExecution.hpp restored from f7d2815b; not a clean production commit',command=command")
s=s.replace('assert len(runs)==42','assert len(runs)==6').replace('FINAL_COSTS_COMPLETE_42','WITHDRAWAL_COSTS_COMPLETE_6')
(r/'withdrawal-costs.py').write_text(s)
