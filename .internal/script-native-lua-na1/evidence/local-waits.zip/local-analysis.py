from pathlib import Path
import csv,json,re,subprocess
r=Path(__file__).parent
out=r/'local-analysis';out.mkdir(exist_ok=True)
source=subprocess.check_output(['git','-C',str(r/'local-source'),'rev-parse','HEAD'],text=True).strip()
baseline='7f20191692d3f5e1037a14273a61fc99eef95714'
assert not subprocess.check_output(['git','-C',str(r/'local-source'),'status','--porcelain'],text=True).strip()
profiles=[]
for side in ['A','B']:
 p=r/'local-profiles'/f'P4-{side}'
 raw=list(csv.reader((p/'summary.csv').open()))
 cpu=float(next(x[2] for x in raw if len(x)>2 and x[1]=='CPU Time'))
 tree=list(csv.DictReader((p/'top-down.csv').open(),skipinitialspace=True))
 targets=['Tasks::step','ScriptExecution::resumeOne','ScriptInstances::eventSource','ScriptExecution::waitEvent',
  'ScriptExecution::admitAwaitable','ScriptEventWaits::registerWait','ScriptExecution::takeAwaitable',
  'ScriptExecution::releaseSource','ScriptExecution::finishPreparedEvent','ScriptExecution::finishAwaitableOwner',
  'ScriptExecution::completeClaimedEventWaiter','ScriptExecution::drainExternalCompletions',
  'ScriptCoroutineContext::invokeResolvedSyncStep','ScriptCoroutineContext::resolveSyncStep',
  'ScriptEventImports::resolve','AwaitableStorage::acquire','AwaitableStorage::releaseResolved',
  'copyPayload','copyScalarEventPayload','hashString','ScriptCoroutine::promise_type::prepareResume','lua_pcallk']
 selected=[]
 for target in targets:
  found=[x for x in tree if target in x['Function Stack'] and 'lambda' not in x['Function Stack']]
  if found:
   x=max(found,key=lambda x:float(x['CPU Time:Total']))
   selected.append(dict(target=target,inclusive_percent=float(x['CPU Time:Total']),
    inclusive_seconds=cpu*float(x['CPU Time:Total'])/100,main_path_self_seconds=float(x['CPU Time:Self']),
    symbol=x['Function (Full)'],address=x['Start Address']))
 hot=list(csv.DictReader((p/'hotspots.csv').open()))
 fields=dict(re.findall(r'(\w+)=(\S+)',next(x for x in (p/'target.log').read_text().splitlines() if x.startswith('BUSINESS '))))
 assert all(fields[k]==v for k,v in {'case':'P4','instances':'10000','warmups':'16','batches':'64','tasks':'640000',
  'waits':'20480000','resumes':'20480000','errors':'0','backlog':'0','leases':'0','threads':'0','lua_resumes':'0'}.items())
 profiles.append(dict(side=side,source=baseline if side=='A' else source,cpu_seconds=cpu,
  roi_elapsed_ns=int(fields['elapsed_ns']),business=fields,selected_inclusive_not_additive=selected,top_self=hot[:30],pmu=False))
(out/'profiles.json').write_text(json.dumps(profiles,indent=2))
sizes=[]
for side,folder in [('A','next-class-layout'),('B','local-class-layout')]:
 text=(r/folder/'ScriptSystem.cpp.log').read_text(errors='replace')
 for line in text.splitlines():
  m=re.match(r'class (.*?)\s+size\((\d+)\):',line)
  if not m:continue
  name=m[1]
  selected=any(name.endswith('::'+n) for n in ['ScriptEventSourceAccess','AwaitableRecord','AwaitableOutcome',
   'EventWaiterRecord','ContinuationRecord','ScriptCompletionIngress','ScriptExecution','ResumeBatch',
   'ScriptEventWaitLink','WaitPage','ExecutionInstance','EventRouteHead','ScriptSyncStepSetView'])
  selected=selected or name.startswith('tl::expected<') and 'ScriptEventSourceAccess' in name
  if selected:sizes.append(dict(side=side,type=name,size=int(m[2])))
(out/'sizes.json').write_text(json.dumps(sizes,indent=2))
frames=[dict(x,side='A') for x in json.loads((r/'next-analysis/frames.json').read_text()) if x['side']=='B']
p=next((r/'local-machine-code').glob('*Tasks.CompleteTasks.script.generated.cpp.obj.asm'))
text=p.read_text()
for task in ['event','next','sequence','longTask','pose']:
 found=[]
 for block in text.split('Disassembly of section '):
  m=re.search(r'^0+ <(.*)>:',block,re.M)
  if not m or not m[1].startswith('public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::'+task+'('):continue
  lines=block.splitlines()
  for i,line in enumerate(lines):
   if 'IMAGE_REL_AMD64_REL32' not in line or '?allocateFrame@' not in line:continue
   n=re.search(r'movl\s+\$0x([0-9a-f]+), %edx','\n'.join(lines[max(0,i-9):i]))
   if n:found.append((int(n[1],16),m[1],block))
 assert len(found)==1,(task,len(found))
 size,symbol,block=found[0];(out/f'frame-{task}.asm.txt').write_text(block)
 frames.append(dict(side='B',task=task,frame_bytes=size,alignment=8,pool_limit=512,symbol=symbol))
(out/'frames.json').write_text(json.dumps(frames,indent=2))
resources=[]
for run in json.loads((r/'local-resources/runs.json').read_text()):
 for line in run['observation']:
  kind=line.split(' ')[0]
  if kind not in ['PROCESS_MEMORY','MEMORY','NATIVE_MEMORY','WAIT_MEMORY']:continue
  fields=dict(re.findall(r'(\w+)=(\S+)',line))
  resources.append(dict(run=run['name'],kind=kind,**{k:int(v) if v.isdigit() else v for k,v in fields.items()}))
(out/'resources.json').write_text(json.dumps(resources,indent=2))
blocks=[]
for p in (r/'local-machine-code').glob('*.asm'):
 for block in p.read_text().split('Disassembly of section '):
  m=re.search(r'^0+ <(.*)>:',block,re.M)
  if not m:continue
  symbol=m[1]
  if not any(x in symbol for x in ['ScriptExecution::resumeOne(', 'ScriptExecution::takeAwaitable(',
   'ScriptExecution::admitAwaitable(', 'ScriptExecution::finishPreparedEvent(', 'ScriptInstances::eventSource(',
   'ScriptEventWaits::registerWait(', '::copyPayload<']):continue
  label=f'machine-{len(blocks)}.asm.txt';(out/label).write_text(block)
  blocks.append(dict(file=label,object=p.name,symbol=symbol,fnv_prime='100000001b3' in block.lower(),
   relocations=re.findall(r'IMAGE_REL_AMD64_REL32\s+(.*)',block)))
(out/'machine.json').write_text(json.dumps(blocks,indent=2))
print('PROFILES',[(x['side'],x['cpu_seconds'],x['roi_elapsed_ns']) for x in profiles])
print('SIZES',json.dumps(sizes))
print('FRAMES',[(x['side'],x['task'],x['frame_bytes']) for x in frames])
print('MACHINE',[(x['symbol'],x['fnv_prime']) for x in blocks if 'copyPayload' in x['symbol']])


