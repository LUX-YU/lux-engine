$ErrorActionPreference='Stop'
$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/lua55-v3'
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$sha=(git -C 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-region-opt/final-source' rev-parse HEAD).Trim()
foreach($pair in @(@('t','physics2d_flowforge_integration_test'),@('d','scene_script_lua_runtime_test'))) {
 $slot=$pair[0];$target=$pair[1];$b="E:/SyncForder/CodeRepos/build/RelWithDebInfo/o/w/$slot"
 & cmake --build $b --target $target -j 4 -- -k 0 *> "$r/generated-$slot-build.log"
 $code=$LASTEXITCODE
 @{source=$sha;target=$target;exit=$code}|ConvertTo-Json|Set-Content "$r/generated-$slot-build.json"
 if($code) { throw "build $target failed" }
 $env:PATH="$b/bin;D:/Development/vcpkg/installed/x64-windows/bin;"+$env:PATH
 & ctest --test-dir $b --output-on-failure -V -j 1 -R $target *> "$r/generated-$slot-tests.log"
 $code=$LASTEXITCODE
 @{source=$sha;target=$target;exit=$code}|ConvertTo-Json|Set-Content "$r/generated-$slot-tests.json"
 if($code) { throw "test $target failed" }
 Write-Output "GENERATED_$slot PASS"
}
