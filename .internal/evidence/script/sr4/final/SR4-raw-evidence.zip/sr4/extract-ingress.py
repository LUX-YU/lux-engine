from pathlib import Path
base=Path('E:/SyncForder/CodeRepos');repo=base/'lux-engine-deep-optimization'
s=(base/'build/RelWithDebInfo/sr4/E0-ScriptSystem.cpp').read_text()
body=s[s.index('        struct AwaitableIngress final'):s.index('        struct SparseMountQueue final')]
body=body.replace('AwaitableIngress','Transport')
p=repo/'engine/domain/simulation/builtin/script/pinclude/lux/engine/simulation/script/ScriptCompletionIngress.hpp'
p.write_text('''#pragma once

#include <lux/engine/simulation/ScriptSystem.hpp>
#include <lux/engine/simulation/script/ExternalCompletionRing.hpp>

namespace lux::simulation::script::detail
{
    class ScriptCompletionIngress final
    {
'''+body+'''    public:
        // Fallible preparation only; transport outlives this owner through completion leases.
        void prepare(std::size_t capacity, std::size_t physical_awaitables)
        {
            transport_ = std::make_shared<Transport>();
            transport_->completions.prepare(capacity, physical_awaitables);
        }

        void open(ScriptAwaitableId id, const std::optional<PreparedResumeType>& type) noexcept
        {
            transport_->completions.open(id, type);
        }
        void close(ScriptAwaitableId id) noexcept { transport_->completions.close(id); }
        void stop() noexcept { transport_->completions.stop(); }

        [[nodiscard]] ScriptAwaitableRegistration registration(ScriptInstanceId instance, ScriptAwaitableId id,
            void* owner, ScriptAwaitableCompletion::AbilitySuccessFn success,
            ScriptAwaitableCompletion::AbilityFailureFn fail) noexcept
        {
            ++capability_constructions_;
            return {id, ScriptAwaitableCompletion{std::static_pointer_cast<void>(transport_), transport_.get(),
                &Transport::completeErased, &Transport::activeErased, instance, id,
                &Transport::completeAbilityErased, &Transport::failAbilityErased, &Transport::activeAbilityErased,
                owner, success, fail}};
        }

        void capture() noexcept
        {
            frontier_ = transport_->completions.enqueue_position.load(std::memory_order_acquire);
            remaining_ = transport_->completions.capacity;
            prepared_ = true;
        }
        void beginDrain() noexcept
        {
            if (!prepared_)
                capture();
            prepared_ = false;
        }

        // Owner-only const borrow ends at ack(). An unpublished reserved head is never skipped.
        // The attempt consumes the captured window's allowance even if owner admission is backpressured.
        [[nodiscard]] const ExternalCompletionRecord* peek() noexcept
        {
            if (transport_->completions.dequeue_position >= frontier_ || remaining_ == 0U)
                return nullptr;
            const auto* result = transport_->completions.front();
            if (result != nullptr)
                --remaining_;
            return result;
        }
        void ack() noexcept { transport_->completions.pop(); }

        [[nodiscard]] static ScriptInstanceId unpackInstance(std::uint64_t value) noexcept
        {
            return Transport::unpackInstance(value);
        }
        [[nodiscard]] static ScriptAwaitableId unpackAwaitable(std::uint64_t value) noexcept
        {
            return Transport::unpackAwaitable(value);
        }
        [[nodiscard]] static lux::script::EScriptAbilityCompletionError abilityError(
            EScriptAwaitableCompletionError error) noexcept
        {
            return Transport::abilityError(error);
        }

        void writeStats(ScriptRuntimeStats& result) const noexcept
        {
            result.completion_capability_constructions = capability_constructions_;
            if (!transport_)
                return;
            const auto& ring = transport_->completions;
            result.external_ticket_storage_bytes = ring.ticket_capacity * sizeof(ExternalCompletionRing::Ticket);
            result.external_completion_queue_depth = ring.count.load(std::memory_order_relaxed);
            result.external_completion_queue_high_water = ring.high_water.load(std::memory_order_relaxed);
            result.external_completion_capacity_failures = ring.capacity_failures.load(std::memory_order_relaxed);
        }

    private:
        std::shared_ptr<Transport> transport_;
        std::size_t frontier_{};
        std::size_t remaining_{};
        bool prepared_{};
        std::uint64_t capability_constructions_{};
    };
}
''')
