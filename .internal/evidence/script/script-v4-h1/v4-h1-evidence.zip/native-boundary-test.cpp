#include <lux/engine/simulation/scripting/native/NativeScriptBackend.hpp>
#include <lux/engine/simulation/scripting/native/NativeScriptAbilityProjection.hpp>
#include <lux/engine/simulation/scripting/ScriptLifecycle.hpp>

#include <array>
#include <cassert>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <filesystem>
#include <memory>
#include <optional>
#include <vector>

namespace
{
    struct Provider final
    {
        struct Lease final
        {
            Provider* owner{};
            std::shared_ptr<lux::script::NativeModule> module;
        };

        std::array<std::shared_ptr<lux::script::NativeModule>, 2U> modules;
        std::size_t resolves{};
        std::size_t releases{};

        static void release(void* opaque) noexcept
        {
            auto* lease = static_cast<Lease*>(opaque);
            ++lease->owner->releases;
            delete lease;
        }

        static bool resolve(
            void* opaque,
            const lux::asset::AssetId& asset,
            const lux::script::ScriptArtifact&,
            lux::simulation::script::ResolvedNativeModule& result
        ) noexcept
        {
            auto& self = *static_cast<Provider*>(opaque);
            ++self.resolves;
            const auto bytes = asset.bytes();
            const auto index = std::to_integer<std::uint8_t>(bytes[0]) == 2U
                ? 1U
                : 0U;
            auto* lease = new (std::nothrow) Lease{
                &self,
                self.modules[index]};
            if (!lease)
                return false;
            result = {lease->module.get(), lease, &release};
            return true;
        }
    };

    struct AsyncProvider final
    {
        lux::script::ScriptAbilityCompletion<void> completion;

        static lux::script::ScriptAbilityStartResult start(
            AsyncProvider& provider,
            lux::script::ScriptAbilityCompletion<void> completion
        ) noexcept
        {
            provider.completion = std::move(completion);
            return {};
        }
    };

    int startAsync(
        void* invocation,
        void* provider,
        const void*,
        lux_script_async_token* waiting_on
    ) noexcept
    {
        return lux::simulation::script::detail::startNativeAbility<void>(
            invocation,
            waiting_on,
            [provider](lux::script::ScriptAbilityCompletion<void> completion) noexcept {
                return AsyncProvider::start(*static_cast<AsyncProvider*>(provider), std::move(completion));
            }
        );
    }

    inline constexpr std::array AsyncMethods{
        lux::script::ScriptAbilityMethodDescription{
            lux::script::ScriptApiMethodIdView{"lux.test.native_async.wait"},
            "wait",
            "wait",
            lux::script::EScriptApiMethodKind::ASYNC_OPERATION,
            {},
            {}
        }
    };
    inline constexpr lux::script::ScriptAbilityDescription AsyncDescription{
        lux::script::ScriptApiContractIdView{"lux.test.native_async"},
        "NativeAsync",
        "Native Async",
        1U,
        0xA55A55A5ULL,
        lux::script::EScriptAbilityReceiverKind::PROVIDER_INSTANCE,
        AsyncMethods
    };
    inline const std::array AsyncNativeMethods{
        lux::script::native::ScriptAbilityNativeMethodProjection{
            lux::script::ScriptApiMethodIdView{"lux.test.native_async.wait"},
            reinterpret_cast<lux_script_ability_direct_entry_fn>(&startAsync)
        }
    };
    inline const lux::script::native::ScriptAbilityNativeContribution AsyncContribution{
        std::addressof(AsyncDescription),
        AsyncNativeMethods
    };

    struct AwaitableHarness final
    {
        lux::simulation::script::ScriptInstanceId instance{1U, 1U};
        lux::simulation::script::ScriptAwaitableId awaiting{1U, 1U};
        std::shared_ptr<void> lease{std::make_shared<int>(0)};
        bool completed{};

        static lux::cxx::expected<lux::simulation::script::ScriptAwaitableRegistration,
                                  lux::simulation::script::EScriptAwaitableCreateError>
        create(
            void* opaque,
            lux::simulation::script::ScriptInstanceId instance,
            std::optional<lux::simulation::script::PreparedResumeType> result
        ) noexcept
        {
            auto& self = *static_cast<AwaitableHarness*>(opaque);
            if (instance != self.instance || result)
            {
                return lux::cxx::unexpected(
                    lux::simulation::script::EScriptAwaitableCreateError::INVALID_RESULT_TYPE
                );
            }
            return lux::simulation::script::ScriptAwaitableRegistration{
                self.awaiting,
                lux::simulation::script::ScriptAwaitableCompletion{
                    self.lease,
                    std::addressof(self),
                    &complete,
                    &active,
                    self.instance,
                    self.awaiting,
                    &abilitySuccess,
                    &abilityFailure,
                    &abilityActive
                }
            };
        }

        static void discard(
            void*,
            lux::simulation::script::ScriptInstanceId,
            lux::simulation::script::ScriptAwaitableId
        ) noexcept
        {
        }

        static lux::cxx::expected<void, lux::simulation::script::EScriptAwaitableCompletionError> complete(
            void* opaque,
            lux::simulation::script::ScriptInstanceId,
            lux::simulation::script::ScriptAwaitableId,
            lux::simulation::script::EScriptAwaitableState state,
            lux::simulation::script::ScriptOwnedResumeValue,
            lux::simulation::script::ScriptStepError
        ) noexcept
        {
            auto& self = *static_cast<AwaitableHarness*>(opaque);
            if (self.completed)
            {
                return lux::cxx::unexpected(
                    lux::simulation::script::EScriptAwaitableCompletionError::ALREADY_TERMINAL
                );
            }
            self.completed = state == lux::simulation::script::EScriptAwaitableState::READY;
            return {};
        }

        static bool active(
            void* opaque,
            lux::simulation::script::ScriptInstanceId,
            lux::simulation::script::ScriptAwaitableId
        ) noexcept
        {
            return !static_cast<AwaitableHarness*>(opaque)->completed;
        }

        static lux::cxx::expected<void, lux::script::EScriptAbilityCompletionError> abilitySuccess(
            void* opaque,
            std::uint64_t,
            std::uint64_t,
            lux::semantic::TypeId type,
            const void* data,
            std::uint32_t size
        ) noexcept
        {
            auto& self = *static_cast<AwaitableHarness*>(opaque);
            if (self.completed)
                return lux::cxx::unexpected(lux::script::EScriptAbilityCompletionError::ALREADY_COMPLETED);
            if (type != lux::semantic::InvalidTypeId || data != nullptr || size != 0U)
                return lux::cxx::unexpected(lux::script::EScriptAbilityCompletionError::INVALID_VALUE);
            self.completed = true;
            return {};
        }

        static lux::cxx::expected<void, lux::script::EScriptAbilityCompletionError> abilityFailure(
            void*,
            std::uint64_t,
            std::uint64_t,
            lux::script::ScriptAbilityOperationError
        ) noexcept
        {
            return {};
        }

        static bool abilityActive(void* opaque, std::uint64_t, std::uint64_t) noexcept
        {
            return !static_cast<AwaitableHarness*>(opaque)->completed;
        }
    };
}

// Appended to the existing Native backend fixture's helpers, against actual A/B DLLs.
#include <Windows.h>
#include <cstring>
#include <cstdlib>

int main(int argc, char** argv)
{
    using namespace lux::simulation::script;
    assert(argc == 3);
    const int mode = std::atoi(argv[2]);
    auto loaded = lux::script::loadNativeModule(std::filesystem::path{argv[1]});
    assert(loaded);
    auto module = std::make_shared<lux::script::NativeModule>(std::move(*loaded));
    const auto library = LoadLibraryA(argv[1]);
    const auto count = reinterpret_cast<unsigned (*)(unsigned)>(GetProcAddress(library, "lux_h1_count"));
    assert(count);
    Provider provider{{module, module}};
    auto owned = std::make_unique<NativeScriptBackend>(NativeModuleResolver{&provider, &Provider::resolve},
        NativeScriptBackendConfig{
        .module_capacity = 1U, .instance_capacity = 1U, .prepared_call_capacity = 1U, .continuation_capacity = 1U,
        .max_ability_imports_per_module = 1U,
        .max_continuation_frame_bytes = 256U, .continuation_frame_storage_bytes = 5120U,
        .storage_populations = std::array{NativeScriptStoragePopulation{module.get(), 1U, 1U}},
        .state_storage_bytes = 65536U, .observe_storage = true});
    auto& backend = *owned;
    assert(backend);
    lux::script::ScriptEventSourceDescription event{"H1", "Payload", 11U, 12U,
        lux::script::EScriptEventRoute::SIMULATION_BROADCAST,
        {"lux.u32", lux::semantic::typeId("lux.u32"), LUX_SCRIPT_VK_UINT32, 4U, 4U}, 13U, 1U, 14U, 15U, 1U};
    const PreparedScriptEventAdmission admission{&event};
    lux::rdesc::Script description;
    description.module_name = "h1_boundary";
    description.body = lux::rdesc::NativeModuleScript{LUX_SCRIPT_ABI_VERSION, module->stateLayoutHash(),
        module->stateSize(), module->stateAlignment(), {}};
    const lux::rdesc::ScriptFunction function{"Step", 1U, {}, {}};
    description.exports = {function}; description.event_requirements = {event};
    auto artifact = lux::script::ScriptArtifact::create(std::move(description), {});
    assert(artifact);
    std::array<std::uint8_t, 16> bytes{}; bytes[0] = 1U;
    auto descriptor = backend.descriptor(); ScriptBackendInstance instance;
    assert(descriptor.createInstance(descriptor.context, ScriptInstanceCreateContext{
        lux::asset::AssetId{bytes}, SimulationScriptScope{}, nullptr, {1U, 1U}, {}, std::span{&admission, 1U}},
        *artifact, instance) == EScriptBackendResult::SUCCESS);
    ScriptBackendPreparedMethod method;
    assert(descriptor.prepareMethod(descriptor.context, instance, function, method) == EScriptBackendResult::SUCCESS);
    unsigned waits{};
    ScriptStepContext context{{1U, 1U}, &waits, nullptr, nullptr,
        [](void* opaque, ScriptInstanceId, ScriptEventAdmissionHandle) noexcept
            -> lux::cxx::expected<ScriptAwaitableId, EScriptEventWaitError> {
            ++*static_cast<unsigned*>(opaque); return ScriptAwaitableId{1U, 1U}; }};
    lux_script_call_frame frame{}; ScriptBackendContinuation continuation;
    const auto started = method.resumable.invoke(method.resumable.context, frame, context, continuation);
    if (mode == 0)
    {
        assert(started.state == EScriptStepState::SUSPENDED && continuation && waits == 1U);
        ScriptOwnedResumeValue value;
        value.type = {lux::semantic::typeId("lux.u32"), LUX_SCRIPT_VK_UINT32, 4U, 4U};
        assert(value.bytes.resize(4U)); const std::uint32_t expected = 29U;
        std::memcpy(value.bytes.data(), &expected, sizeof(expected));
        const auto valid_type = value.type;
        for (unsigned which{}; which < 6U; ++which)
        {
            value.type = valid_type; assert(value.bytes.resize(4U));
            std::memcpy(value.bytes.data(), &expected, sizeof(expected));
            if (which == 0) value.type.type_id = lux::semantic::typeId("lux.i32");
            if (which == 1) value.type.abi_kind = LUX_SCRIPT_VK_INT32;
            if (which == 2) value.type.size = 8U;
            if (which == 3) value.type.alignment = 8U;
            if (which == 4) assert(value.bytes.resize(3U));
            const ScriptResumePacket packet{{1U, 1U}, EScriptAwaitableState::READY,
                which == 5 ? nullptr : &value, {}};
            const auto rejected = continuation.resume(continuation.state, context, packet);
            assert(rejected.state == EScriptStepState::FAILED && rejected.error.status == -1);
            assert(count(1) == 0U && count(2) == 0U && backend.stats().active_frames == 1U);
            std::printf("NATIVE_PACKET_REJECT,case=%u,resumes=0,frame_retained=1\n", which);
        }
        value.type = valid_type; assert(value.bytes.resize(4U));
        std::memcpy(value.bytes.data(), &expected, sizeof(expected));
        const ScriptResumePacket packet{{1U, 1U}, EScriptAwaitableState::READY, &value, {}};
        assert(continuation.resume(continuation.state, context, packet).state == EScriptStepState::COMPLETED);
        assert(count(1) == 1U); continuation.destroy(continuation.state);
    }
    else
    {
        const int error = mode == 3 ? 73 : mode == 6 ? -71 : -1;
        assert(started.state == EScriptStepState::FAILED && started.error.status == error);
        assert(!continuation && waits == 0U && count(1) == 0U);
    }
    assert(count(0) == 1U && count(2) == 1U && backend.stats().active_frames == 0U);
    descriptor.releaseMethod(descriptor.context, instance, method);
    descriptor.destroyInstance(descriptor.context, instance);
    assert(backend.stats().active_states == 0U && count(2) == 1U);
    owned.reset();
    assert(provider.resolves == 1U && provider.releases == 1U);
    std::printf("NATIVE_BOUNDARY,case=%d,start=1,resume=%u,destroy=1,waits=%u,lease_release=1\n",
        mode, count(1), waits);
    FreeLibrary(library);
}
