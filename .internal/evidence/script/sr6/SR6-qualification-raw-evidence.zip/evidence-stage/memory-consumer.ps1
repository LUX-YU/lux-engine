$ErrorActionPreference='Stop'
$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/s6'
$source="$r/memory-source-2"
New-Item -ItemType Directory -Path "$source/cmake/installed-consumers" -Force | Out-Null
Copy-Item -LiteralPath "$r/candidate-source/cmake/installed-consumers/script-lua-values" -Destination "$source/cmake/installed-consumers/script-lua-values" -Recurse
$path="$source/cmake/installed-consumers/script-lua-values/main.cpp"
$text=[IO.File]::ReadAllText($path)
$old='    runInstalledRuntime();'
if(([regex]::Matches($text,[regex]::Escape($old))).Count -ne 1){throw 'Memory insertion must match once'}
$extra=@'
    std::printf("VALUE_MEMORY item=%zu slots=%zu failure=%zu input_frame=%zu result_frame=%zu\n",
        sizeof(Item), sizeof(LuaValueSlots<Item>), sizeof(LuaValueFailure),
        contribution.methods[0].parameters[0].frame_bytes, contribution.methods[0].results[0].frame_bytes);
    runInstalledRuntime();
'@
[IO.File]::WriteAllText($path,$text.Replace($old,$extra))
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$root="$r/memory-consumer-2"
New-Item -ItemType Directory -Path $root | Out-Null
$prefix="$r/relocation/sdk/d;$r/relocation/sdk/t;E:/SyncForder/CodeRepos/install/q2/c;E:/SyncForder/CodeRepos/install/q2/toolset"
$env:PATH=(@($prefix.Split(';') | ForEach-Object {"$_/bin"})+@('D:/Development/vcpkg/installed/x64-windows/bin')+@($env:PATH.Split(';') | Where-Object {$_ -notmatch 'CodeRepos[/\\](install|build)' -and $_ -notmatch 'vcpkg[/\\]installed'})) -join ';'
cmake -S "$source/cmake/installed-consumers/script-lua-values" -B "$root/build" -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DCMAKE_TOOLCHAIN_FILE=D:/Development/vcpkg/scripts/buildsystems/vcpkg.cmake "-DCMAKE_PREFIX_PATH=$prefix" -DCMAKE_FIND_USE_PACKAGE_REGISTRY=OFF -DCMAKE_FIND_USE_SYSTEM_PACKAGE_REGISTRY=OFF *> "$root/configure.log"
if($LASTEXITCODE){throw 'Memory configure failed'}
cmake --build "$root/build" --target all -j 4 -- -k 0 *> "$root/all.log"
if($LASTEXITCODE){throw 'Memory build failed'}
& "$root/build/lux_script_lua_values_consumer.exe" *> "$root/run.log"
if($LASTEXITCODE){throw 'Memory execution failed'}
if(!(Select-String -LiteralPath "$root/run.log" -SimpleMatch -Pattern 'VALUE_MEMORY item=' -Quiet)){throw 'Missing memory row'}
cmake --build "$root/build" --target all -j 4 -- -k 0 *> "$root/noop.log"
if($LASTEXITCODE -or !(Select-String -LiteralPath "$root/noop.log" -SimpleMatch -Pattern 'no work to do' -Quiet)){throw 'Memory no-op failed'}
@{source_commit=(& git -C "$r/candidate-source" rev-parse HEAD).Trim();main_sha256=(Get-FileHash $path).Hash;exe_sha256=(Get-FileHash "$root/build/lux_script_lua_values_consumer.exe").Hash;diagnostic_only=$true;insertion_hits=1} | ConvertTo-Json | Set-Content "$root/identity.json"
