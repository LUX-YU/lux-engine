from pathlib import Path
import json,re
r=Path.cwd();rows=json.loads((r/'local-analysis/resources.json').read_text())
for size in [1000,10000]:
 for side in ['A','B']:
  rs=[x for x in rows if x['run']==f'P4-{size}-{side}' and x['phase']=='end'];print(size,side,rs)
print('scale candidate diagnostics')
print([x for x in json.loads((r/'local-scale/runs.json').read_text()) if x['variant']=='candidate' and x['diagnostics']==1])
