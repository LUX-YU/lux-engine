import hashlib,json,shutil,subprocess
from pathlib import Path
r=Path(__file__).resolve().parent;s=r.parent/'s5/source';candidate=r/'candidate-source'
main=Path('E:/SyncForder/CodeRepos/lux-engine')
def git(p,*a):return subprocess.check_output(['git','-C',str(p),*a],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
start=json.loads((r/'start-identity.json').read_text())
assert git(main,'rev-parse','HEAD')==start['main_head']
assert git(main,'status','--porcelain')==start['main_status']
for v in start['main_files']:assert sha(main/v['path'])==v['sha256'],v
for name,v in start['dependencies'].items():
 assert git(main.parent/name,'rev-parse','HEAD')==v['head']
 assert git(main.parent/name,'status','--porcelain')==v['status']
for v in start['entry_binaries']:assert sha(Path(v['path']))==v['sha256'],v['path']
assert not git(candidate,'status','--porcelain')
assert not git(candidate,'diff','--name-only','f64cadde','HEAD','--','engine','modules')
record={'candidate':git(candidate,'rev-parse','HEAD'),'candidate_clean':True,'main_unknown_files_unchanged':True,
        'dependency_worktrees_unchanged':True,'entry_binaries_unchanged':len(start['entry_binaries']),
        'production_and_templates_equal_E':True,'binaries':[],'VM_files':[]}
for vm in ('t','d','l'):
 for p in sorted((r/'q'/vm/'bin').glob('*')):
  if p.suffix.lower() in ('.dll','.exe'):record['binaries'].append({'vm':vm,'path':str(p),'sha256':sha(p)})
for base in (Path('D:/Development/vcpkg/installed/x64-windows'),
             Path('E:/SyncForder/CodeRepos/build/deps/lua54-vcpkg/x64-windows')):
 for pattern in ('bin/lua*.dll','include/lua.h','include/luajit.h','lib/lua*.lib'):
  for p in base.glob(pattern):record['VM_files'].append({'path':str(p),'sha256':sha(p)})
(r/'final-identity.json').write_text(json.dumps(record,indent=2))
stage=r/'evidence-stage';stage.mkdir(exist_ok=False)
for p in r.iterdir():
 if p.is_file() and p.suffix in ('.json','.py','.ps1','.log'):
  shutil.copy2(p,stage/p.name)
diag=stage/'diagnostics';diag.mkdir()
(diag/'task.txt').write_bytes((r/'task.md').read_bytes())
for folder in ('consumer-development','consumer-development-2','memory-source','memory-source-2',
               'protocol-development','protocol-E','protocol-F','regions'):
 base=r/folder
 for p in base.rglob('*'):
  if p.is_file() and p.suffix in ('.cpp','.hpp') and 'build' not in p.relative_to(base).parts:
   dest=diag/folder/p.relative_to(base);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
for folder in ('consumers-final/script-lua-values','relocation','memory-consumer-2'):
 base=r/folder
 for p in base.rglob('*.generated.hpp'):
  dest=diag/'generated'/folder/p.relative_to(base);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
invalid=[{'stage':'consumer-development','reason':'Consumer omitted the required unique stable Hook. Public bindHookCallbacks rejected INVALID_EXECUTION_POINT; fixture declaration corrected. Not a runtime regression.',
          'replacement':'consumer-development-2 and final/relocated SDK execution'},
         {'stage':'memory-consumer','reason':'Diagnostic built and executed successfully, but the PowerShell Select-String arguments were reversed. Driver failed while reading its log; records retained.',
          'replacement':'memory-consumer-2; explicit -LiteralPath/-Pattern and successful no-op'}]
(stage/'invalid-trials.json').write_text(json.dumps(invalid,indent=2))
print('Final protected-state audit and new evidence staging complete')
