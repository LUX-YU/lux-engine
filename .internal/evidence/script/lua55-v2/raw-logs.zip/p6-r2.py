from pathlib import Path
import difflib
root=Path('cmake/dependencies/lua55')
official=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-lua55-s0-s1-20260909/dependencies/qualified-lua-5.5.1/src')
r1=official.parent.parent/'build-lua55/lux-leaf-r1/src'
parts=[]
for name in ['ldo.c','lstate.c','lstate.h','lvm.c']:
 before=(official/name).read_text();after=(r1/name).read_text()
 if name=='lvm.c':
  at='void luaV_execute (lua_State *L, CallInfo *ci) {'
  helper='''typedef enum { LUX_LUA_FRAME, LUX_C_COMPLETE, LUX_LEAF_YIELD } LuxPrecallKind;
typedef struct { LuxPrecallKind kind; CallInfo *frame; } LuxPrecallResult;

/* OP_CALL alone may consume a normally returned engine leaf wait. */
static LuxPrecallResult lux_precall (lua_State *L, StkId function, int nresults) {
  LuxPrecallResult result;
  result.frame = luaD_precall(L, function, nresults);
  result.kind = result.frame != NULL ? LUX_LUA_FRAME :
                L->status == LUA_YIELD ? LUX_LEAF_YIELD : LUX_C_COMPLETE;
  return result;
}

'''
  assert after.count(at)==1;after=after.replace(at,helper+at)
  after=after.replace('''        CallInfo *newci;
        int b = GETARG_B(i);''','''        LuxPrecallResult call;
        int b = GETARG_B(i);''')
  a='''        if ((newci = luaD_precall(L, ra, nresults)) == NULL) {
            if (L->status == LUA_YIELD) return; /* Lux leaf, C frame remains suspended */
            updatetrap(ci);  /* ordinary C call */
          }
        else {  /* Lua call: run function in this same C frame */
          ci = newci;'''
  b='''        call = lux_precall(L, ra, nresults);
        if (call.kind == LUX_LEAF_YIELD) return; /* retain the suspended C frame */
        if (call.kind == LUX_C_COMPLETE)
          updatetrap(ci);
        else {  /* Lua call: run function in this same C frame */
          ci = call.frame;'''
  assert after.count(a)==1;after=after.replace(a,b)
 parts.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/src/'+name,tofile='b/src/'+name))
(root/'patches/leaf-yield-r2.patch').write_bytes(''.join(parts).encode())
(root/'lux_lua55_extensions.h').write_text('''#ifndef LUX_LUA55_EXTENSIONS_H
#define LUX_LUA55_EXTENSIONS_H

#include <lua.h>

#if defined(LUX_LUA55_LEAF_YIELD_REVISION)
#ifdef __cplusplus
extern "C" {
#endif
/* Only engine leaf primitives return this private sentinel; other shapes use standard Lua55 yield. */
LUA_API int luxlua_yieldleaf(lua_State* state, lua_KContext context, lua_KFunction continuation);
LUA_API void luxlua_leafstats(lua_State* state, unsigned long long* fast, unsigned long long* fallback);
#ifdef __cplusplus
}
#endif
#endif

#endif
''')
p=root/'CMakeLists.txt';s=p.read_text().replace('leaf-yield-r1.patch','leaf-yield-r2.patch').replace('lux-leaf-r1','lux-leaf-r2')
s=s.replace('''        --patch "${CMAKE_CURRENT_SOURCE_DIR}/patches/leaf-yield-r2.patch"
''','''        --patch "${CMAKE_CURRENT_SOURCE_DIR}/patches/leaf-yield-r2.patch" --revision lux-leaf-r2
''')
s=s.replace('''add_library(LuxLua55::Runtime ALIAS lux_lua55_runtime)''','''add_library(LuxLua55::Runtime ALIAS lux_lua55_runtime)
if(LUX_LUA55_LEAF_YIELD)
    target_compile_definitions(lux_lua55_runtime PUBLIC LUX_LUA55_LEAF_YIELD_REVISION=2)
endif()''')
s=s.replace('''    "$<BUILD_INTERFACE:${LUX_LUA55_SOURCE_DIR}/src>" "$<INSTALL_INTERFACE:include/lua55>")''','''    "$<BUILD_INTERFACE:${LUX_LUA55_SOURCE_DIR}/src>"
    "$<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}>" "$<INSTALL_INTERFACE:include/lua55>")''')
s=s.replace('''foreach(header lua.h''','''install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/lux_lua55_extensions.h" DESTINATION include/lua55)
foreach(header lua.h''');p.write_text(s)
p=root/'apply_leaf.py';s=p.read_text().replace("p.add_argument('--patch',type=Path,required=True)","p.add_argument('--patch',type=Path,required=True)\np.add_argument('--revision',required=True)").replace("key=dict(revision='lux-leaf-r1',","key=dict(revision=a.revision,");p.write_text(s)
for name in ['cmake/dependencies/lua55/leaf_contract.c','modules/function/script/lua/src/LuaBoundary.c','engine/domain/simulation/scripting/lua/src/LuaScriptBackend.cpp']:
 p=Path(name);s=p.read_text();s='#include <lux_lua55_extensions.h>\n'+s;p.write_text(s)
p=Path('.gitattributes');s=p.read_text();s+='\ncmake/dependencies/lua55/patches/leaf-yield-r2.patch -text\n';p.write_text(s)
