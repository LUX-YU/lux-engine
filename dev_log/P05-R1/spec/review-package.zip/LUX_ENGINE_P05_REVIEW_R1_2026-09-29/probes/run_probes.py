#!/usr/bin/env python3
"""Run isolated ORIGINAL-source diagnostics; a completed run does not mean the engine is safe.

No network, no changes to an engine checkout. Compile only the two Git-blob-verified .cpp files
with the explicitly documented test header shim, on GCC with C++23 for std::expected.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
EXPECTED = {
    "SaveService.cpp": "78784eb7047bf7c1b939a83c5c771e2033196bac",
    "WriteCoordinator.cpp": "3f8fa33d91f671a2de1c8f494148d36501ea1fb9",
}
CASES = ["chain-control", "chain-ack", "revoke", "recursive-adoption"]

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--compiler", default="g++")
    parser.add_argument("--output", type=Path, default=HERE / "runs")
    args = parser.parse_args()
    compiler = shutil.which(args.compiler)
    if not compiler:
        parser.error(f"C++ compiler not found: {args.compiler}")
    proof = []
    for name, wanted in EXPECTED.items():
        path = HERE / "vendor" / name
        content = path.read_bytes()
        actual = hashlib.sha1(b"blob " + str(len(content)).encode() + b"\0" + content).hexdigest()
        if actual != wanted:
            raise RuntimeError(f"Original production source changed: {name}: {actual}")
        proof.append({"file": str(path.relative_to(HERE)), "git_blob_sha1": actual,
                      "sha256": hashlib.sha256(content).hexdigest(), "matches_connector_blob": True})
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    version = subprocess.check_output([compiler, "--version"], text=True).splitlines()[0]
    rows = []
    with tempfile.TemporaryDirectory(prefix="lux-p05-isolated-") as temporary:
        for level in ("-O0", "-O2"):
            executable = Path(temporary) / f"probe-{level[1:]}"
            command = [compiler, "-std=c++23", level, "-g", "-fsanitize=address,undefined",
                       "-fno-omit-frame-pointer", "-I" + str(HERE / "include"),
                       *[str(HERE / "vendor" / name) for name in EXPECTED],
                       str(HERE / "core_regressions.cpp"), "-o", str(executable)]
            built = subprocess.run(command, capture_output=True, timeout=90)
            (output / f"build-{level[1:]}.stdout.log").write_bytes(built.stdout)
            (output / f"build-{level[1:]}.stderr.log").write_bytes(built.stderr)
            if built.returncode:
                raise RuntimeError(f"Harness build failed; not a reproduced engine defect: {command}")
            for case in CASES:
                label = f"{level[1:]}-{case}"
                env = {**os.environ, "ASAN_OPTIONS": "detect_leaks=0:halt_on_error=1",
                       "UBSAN_OPTIONS": "print_stacktrace=1"}
                run = subprocess.run([str(executable), case], capture_output=True, env=env, timeout=10)
                (output / (label + ".stdout.log")).write_bytes(run.stdout)
                (output / (label + ".stderr.log")).write_bytes(run.stderr)
                stdout, stderr = run.stdout.decode(errors="replace"), run.stderr.decode(errors="replace")
                if case == "chain-control":
                    reproduced = run.returncode == 0 and "fourth_published=1 final=V4 conflicts=0" in stdout
                elif case == "chain-ack":
                    reproduced = run.returncode == 10 and "fourth_published=0 final=V3 conflicts=1" in stdout
                elif case == "revoke":
                    reproduced = run.returncode != 0 and "null pointer" in stderr and "SaveService.cpp" in stderr
                else:
                    reproduced = run.returncode != 0 and "heap-use-after-free" in stderr and "acknowledged_inside_accept=1" in stdout
                rows.append({"case": case, "optimization": level, "returncode": run.returncode,
                             "expected_observation_seen": reproduced,
                             "target_contract_met": case == "chain-control" and reproduced,
                             "stdout": stdout, "stderr_file": label + ".stderr.log",
                             "build_command": command})
                print(f"{label}: exit={run.returncode}, expected_observation_seen={reproduced}")
    report = {"scope": "Byte-identical SaveService.cpp and WriteCoordinator.cpp compiled with a header shim. "
              "std::expected, simple identity/CodeLease stand-ins, controlled in-memory role/storage; "
              "NOT a Lux SDK/full-engine build, actual-model test, real file IO, GPU or DLL-unload qualification.",
              "source_commit": "5866f990f8a5c4d68e19e0e395c9487c6c0f2779",
              "compiler": version, "production_source_identity": proof, "cases": rows,
              "all_expected_observations_seen": all(x["expected_observation_seen"] for x in rows)}
    (output / "results.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return 0 if report["all_expected_observations_seen"] else 1

if __name__ == "__main__":
    raise SystemExit(main())
