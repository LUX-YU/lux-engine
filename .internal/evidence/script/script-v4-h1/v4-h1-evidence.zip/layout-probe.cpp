#include <lux/engine/simulation/script/ScriptExecution.hpp>
#include <lux/engine/simulation/scripting/native/NativeFrameStorage.hpp>
#include <cstdio>
#include <cstdlib>
#include <new>
#include <cstdint>

// Diagnostic EXE only. Exact requested bytes, not allocator usable size or RSS.
static bool tracking;
static std::size_t live, requested, allocations;
struct Header { void* base; std::size_t bytes; bool tracked; };
void* allocate(std::size_t n, std::size_t alignment)
{
    alignment = (std::max)(alignment, alignof(Header));
    void* raw = std::malloc(n + alignment + sizeof(Header));
    if (!raw) throw std::bad_alloc();
    const auto address = (reinterpret_cast<std::uintptr_t>(raw) + sizeof(Header) + alignment - 1) & ~(alignment - 1);
    auto* header = reinterpret_cast<Header*>(address) - 1;
    *header = {raw, n, tracking};
    if (tracking) { live += n; requested += n; ++allocations; }
    return reinterpret_cast<void*>(address);
}
void release(void* p) noexcept
{
    if (!p) return;
    auto* h = static_cast<Header*>(p) - 1;
    if (h->tracked) live -= h->bytes;
    std::free(h->base);
}
void* operator new(std::size_t n) { return allocate(n, alignof(std::max_align_t)); }
void* operator new[](std::size_t n) { return allocate(n, alignof(std::max_align_t)); }
void* operator new(std::size_t n, std::align_val_t a) { return allocate(n, static_cast<std::size_t>(a)); }
void* operator new[](std::size_t n, std::align_val_t a) { return allocate(n, static_cast<std::size_t>(a)); }
void operator delete(void* p) noexcept { release(p); }
void operator delete[](void* p) noexcept { release(p); }
void operator delete(void* p, std::size_t) noexcept { release(p); }
void operator delete[](void* p, std::size_t) noexcept { release(p); }
void operator delete(void* p, std::align_val_t) noexcept { release(p); }
void operator delete[](void* p, std::align_val_t) noexcept { release(p); }
void operator delete(void* p, std::size_t, std::align_val_t) noexcept { release(p); }
void operator delete[](void* p, std::size_t, std::align_val_t) noexcept { release(p); }

using namespace lux::simulation::script::detail;
#define SIZE(T) std::printf("SIZE %s=%zu\n", #T, sizeof(T))
void begin() { if (live) std::abort(); requested = allocations = 0; tracking = true; }
void snapshot(const char* label, std::size_t object)
{
    std::printf("BACKING %s object=%zu dynamic=%zu total_requested=%zu allocations=%zu\n",
        label, object, live, requested, allocations);
}
int main()
{
    constexpr std::size_t N = 10000;
    SIZE(lux::simulation::script::PreparedScriptEventAdmission); SIZE(ScriptEventSourceAccess);
    SIZE(ScriptPreparedMethod); SIZE(PreparedInvocation); SIZE(NativeFrameStorage::Class);
    SIZE(BoundedClassStorage); SIZE(BoundedClassStorage::Ticket); SIZE(BoundedClassStorage::Class);
    SIZE(ScriptExecution); SIZE(ScriptExecution::ContinuationRecord); SIZE(ScriptExecution::AwaitableRecord);
    SIZE(ScriptExecution::ResumeRecord); SIZE(ScriptExecution::ExecutionInstance); SIZE(ScriptExecution::HookFlight);
    SIZE(ScriptEventWaits); SIZE(ScriptEventWaits::EventWaiterRecord); SIZE(ScriptClaimedEventWait);
    SIZE(ScriptTimers); SIZE(ScriptTimers::Wait); SIZE(ScriptTimerAssociation);
    SIZE(ScriptCompletionIngress); SIZE(ScriptCompletionIngress::Transport);
    SIZE(ExternalCompletionRing::Ticket); SIZE(ExternalCompletionRing::Cell);
#if CELL_CANDIDATE
    SIZE(ScriptOperationCell); SIZE(ScriptExecutionState); SIZE(ScriptWaitState);
    SIZE(ScriptLocalWait); SIZE(ScriptBoxedWait); SIZE(ScriptOperationStorage);
    begin(); {
        ScriptOperationStorage storage;
        storage.prepare(N, N);
        ScriptOperationStorage::Continuations c(storage); c.reserve(N);
        ScriptOperationStorage::Awaitables a(storage); a.reserve(N);
        std::printf("CELL bank=%zu continuation_directory=%zu wait_directory=%zu capacity=%zu\n",
            storage.bankBytes(), storage.continuationDirectoryBytes(), a.storageBytes(), storage.capacity());
        snapshot("bank_and_directories", sizeof(storage) + sizeof(c) + sizeof(a));
    }
#else
    begin(); {
        ScriptExecution::ContinuationStorage c; c.reserve(N);
        snapshot("continuations", sizeof(c));
    }
    begin(); {
        ScriptExecution::AwaitableStorage a; a.reserve(N);
        std::printf("OLD_WAIT physical_capacity=%zu storage_bytes_including_object=%zu\n", a.capacity(), a.storageBytes());
        snapshot("awaitables", sizeof(a));
    }
#endif
    begin(); {
        ScriptExecution::ResumeRing ring; ring.prepare(N);
        snapshot("ready", sizeof(ring));
    }
    begin(); {
        std::vector<ScriptExecution::ExecutionInstance> instances(N);
        std::vector<ScriptExecution::HookFlight> hooks(N);
        snapshot("execution_indices_N_methods", sizeof(instances) + sizeof(hooks));
    }
    begin(); {
        ScriptEventWaits event;
        event.waiters_.reserve(N); event.routes_.reserve(N); event.broadcast_routes_.resize(1);
        event.claimed_.reserve(N); event.instances_.resize(N);
        snapshot("event_source_N_1_endpoint", sizeof(event));
    }
    begin(); {
        ScriptTimers timer;
        timer.waits_.reserve(N); timer.external_.reserve(N); timer.heap_.reserve(N); timer.instances_.resize(N);
        snapshot("timer_source_N", sizeof(timer));
    }
    begin(); {
        auto transport = std::make_shared<ScriptCompletionIngress::Transport>();
        transport->completions.prepare(N,
#if CELL_CANDIDATE
            N
#else
            ((N + 255) / 256) * 256
#endif
        );
        snapshot("transport_shared_and_arrays", sizeof(transport));
    }
    tracking = false;
    if (live) return 1;
    std::puts("LAYOUT_RELEASE_COMPLETE");
}
