from pathlib import Path
p=Path('engine/domain/simulation/scripting/lua/test/lua_value_runtime_test.cpp')
for i,l in enumerate(p.read_text().splitlines(),1):
 if len(l)>120:print(i,len(l),l)
