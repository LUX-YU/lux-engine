import json,subprocess,re
from pathlib import Path
base=Path('E:/SyncForder/CodeRepos');root=base/'build/RelWithDebInfo/sr4'
out=root/'diagnostics/layout-final';out.mkdir(exist_ok=False)
records=[]
for variant,build,filename,owner,names in [
 ('e0',base/'build/RelWithDebInfo/sr3-e/d','ScriptSystem.cpp','lux::simulation::script::ScriptSystem::State',['AwaitableRecord','ExecutionInstance','NextStepWait','SimulationDelayWait']),
 ('e1',root/'candidate/d','ScriptExecution.cpp','lux::simulation::script::detail::ScriptExecution',['AwaitableRecord','ExecutionInstance']),
 ('e1-timers',root/'candidate/d','ScriptTimers.cpp','lux::simulation::script::detail::ScriptTimers',['Wait','InstanceIndex']),
 ('e1-events',root/'candidate/d','ScriptEventWaits.cpp','lux::simulation::script::detail::ScriptEventWaits',['InstanceIndex'])]:
 db=json.loads((build/'compile_commands.json').read_text());entry=next(e for e in db if e['file'].endswith('/builtin/script/src/'+filename))
 for name in names:
  label=variant+'-'+name
  command=entry['command']+f' /Fo"{out}/{label}.obj" /Fd"{out}/{label}.pdb" /d1reportSingleClassLayout{name}'
  with (out/(label+'.log')).open('w') as log:r=subprocess.run(command,cwd=build,stdout=log,stderr=subprocess.STDOUT)
  data=(out/(label+'.log')).read_text()
  sizes=re.findall(r'^class '+re.escape(owner+'::'+name)+r'\s+size\((\d+)\):',data,re.M)
  record=dict(variant=variant,type=owner+'::'+name,command=command,exit=r.returncode,sizes=sizes)
  records.append(record);(out/'layouts.json').write_text(json.dumps(records,indent=2))
  assert r.returncode==0 and len(sizes)==1,record
print(json.dumps(records))
