from pathlib import Path
p=Path('E:/RenderV2Rebuild/Layer/source/modules/function/render/resource/test/Registry.cpp');s=p.read_text();pos=s.index('    StorageFactory factory()');s=s[:pos]+'''    struct WrongOpsStorage final
    {
        using Config = unsigned;
        static inline constexpr auto description = TestStorage::description;
        struct Ops final { double (*read)(const void*) noexcept; void (*write)(void*, double) noexcept; };
        struct Access final
        {
            Access(void*, const Ops&, bool) noexcept { std::abort(); }
        };
    };
    static_assert(sizeof(WrongOpsStorage::Ops) == sizeof(TestStorage::Ops));

'''+s[pos:];s=s.replace('        require(global && repeated && counts.created == 1);','        require(global && repeated && counts.created == 1);\n        require(!registry.tryGet<WrongOpsStorage>(root, "shared"));');p.write_text(s)
