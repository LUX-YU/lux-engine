"""One retained Lua55 baseline and final candidate, three alternating independent runs per workload."""
import csv,ctypes as ct,hashlib,json,os,re,shutil,statistics,struct,subprocess,time
from pathlib import Path
r=Path(__file__).parent
dev=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/o/w/d')
tool=dev.parent/'t'
baseline=r.parent/'lua55-v3/final-image'
final=r/'w1-image';final.mkdir(exist_ok=False)
out=r/'w1-image-record';out.mkdir(exist_ok=False)
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def imports(p):
    b=p.read_bytes();nt=struct.unpack_from('<I',b,60)[0]
    count=struct.unpack_from('<H',b,nt+6)[0];size=struct.unpack_from('<H',b,nt+20)[0];opt=nt+24
    directories=opt+(112 if struct.unpack_from('<H',b,opt)[0]==0x20b else 96)
    sections=[struct.unpack_from('<IIII',b,opt+size+i*40+8) for i in range(count)]
    def offset(rva):
        for vs,va,rs,raw in sections:
            if va<=rva<va+max(vs,rs):return raw+rva-va
        raise ValueError((p,rva))
    result=[]
    for index,stride,field in [(1,20,12),(13,32,4)]:
        address=struct.unpack_from('<I',b,directories+index*8)[0]
        if not address:continue
        at=offset(address)
        while any(b[at:at+stride]):
            name=struct.unpack_from('<I',b,at+field)[0]
            pos=offset(name);result.append(b[pos:b.index(0,pos)].decode('ascii'));at+=stride
    return result
queue=['script_runtime_benchmark.exe','script_lua_page_allocator_test.exe','simulation_script_lua_value_boundary_test.exe']
saved={};external=set()
while queue:
    name=queue.pop()
    if name.lower() in saved:continue
    candidates=[dev/'bin'/name,Path('D:/Development/vcpkg/installed/x64-windows/bin')/name]
    p=next((p for p in candidates if p.exists()),None)
    if not p:external.add(name);continue
    shutil.copy2(p,final/name);saved[name.lower()]=dict(path=str(p),sha256=sha(p))
    for pdb in [p.with_suffix('.pdb')]:
        if pdb.exists():shutil.copy2(pdb,final/pdb.name)
    queue+=imports(p)
assert sha(final/'lux_lua55.dll')==sha(Path('E:/SyncForder/CodeRepos/install/o/v4/lua55/bin/lux_lua55.dll')), 'stale app-local VM'
fixtures={}
for name,source in [('lua_runtime_benchmark_fixture.lxsa',tool/'engine/toolchain/lua'),
    ('physics2d_lua_fixture.lxsa',tool/'engine/toolchain/physics2d'),
    ('physics2d_flowforge_fixture.lxsa',tool/'engine/toolchain/physics2d')]:
    p=source/name;shutil.copy2(p,final/name);fixtures[name]=sha(p)
identity=dict(source=json.loads((r/'w1-current-build.json').read_text(encoding='utf-8-sig'))['source'],
    images=saved,fixtures=fixtures,system_imports=sorted(external),
    vm=json.loads(Path('E:/SyncForder/CodeRepos/install/o/v4/lua55/share/LuxLua55/identity.json').read_text()))
(final/'identity.json').write_text(json.dumps(identity,indent=2))
