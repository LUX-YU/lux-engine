import hashlib, json, re, subprocess
from pathlib import Path

base = Path('E:/SyncForder/CodeRepos')
root = base/'build/RelWithDebInfo/sr3-event/diagnostics'
result = {'qualification': {}, 'assertion_flags': [], 'reference_failures': {}}
expected_names = sorted(['scene_script_lua_runtime_test','scene_script_lua_runtime_workers_0',
    'scene_script_lua_runtime_workers_2','scene_script_lua_runtime_workers_4',
    'scene_script_lua_runtime_interpreter_test','scene_script_lua_runtime_interpreter_workers_4'])
for profile, total, failed in [('t',107,0),('d',119,6)]:
    build = base/f'build/RelWithDebInfo/sr3-e/{profile}'
    summary = (build/'ctest.log').read_text()
    assert f'{failed} tests failed out of {total}' in summary
    assert 'ninja: no work to do' in (build/'second-build.log').read_text()
    trace = (build/'Testing/Temporary/LastTest.log').read_text()
    points = re.findall(r'^REENTRY_OK,(.*)$',trace,re.M)
    assert len(points)==8 and [int(p.split(',')[0]) for p in points]==[1,2,3,4,5,6,7,3]
    markers = ['INVOCATION_AUTHORITY_OK,','BINDINGS_OK,',
        'SINGLE_FLIGHT_OK,skipped=16,methods=2,instances=2,resume_budget=1,reused_generation=1']
    assert all(trace.count(marker)==1 for marker in markers)
    result['qualification'][profile] = {'total':total,'failed':failed,'reentry':points,'markers':markers}
    for item in json.loads((build/'compile_commands.json').read_text()):
        if item['file'].endswith(('/script_system_lifecycle_test.cpp','/script_bindings_test.cpp',
                                 '/script_system_continuation_test.cpp','/script_system_event_wait_test.cpp')):
            assert '/UNDEBUG' in item['command']
            result['assertion_flags'].append(item)
    if profile=='d':
        names = sorted(re.findall(r'\d+:([^\n]+)', (build/'Testing/Temporary/LastTestsFailed.log').read_text()))
        assert names==expected_names
        asserts = [line for line in trace.splitlines() if 'activeContinuationCount() == 0U' in line]
        assert len(asserts)==6
        result['qualification'][profile].update(historical_names=names, assertions=asserts)
for label in ('sr3-reference','sr3-c3'):
    directory=base/f'build/RelWithDebInfo/sr3-event/reference-refresh/{label}'
    trace=(directory/'historical-lua.log').read_text()
    assert '6 tests failed out of 6' in trace
    asserts=[line for line in trace.splitlines() if 'activeContinuationCount() == 0U' in line]
    assert len(asserts)==6
    names=sorted(re.findall(r'\d+:([^\n]+)', (base/f'build/RelWithDebInfo/{label}/d/Testing/Temporary/LastTestsFailed.log').read_text()))
    assert names==expected_names
    result['reference_failures'][label]={'names':names,'assertions':asserts,'exit':(directory/'exit.log').read_text()}
repo=base/'lux-engine-deep-optimization'
paths=['.internal/evidence/script/'+p for p in ('sr2','sr3-gate','sr3','sr3-cost')]
def tree(ref):
    return subprocess.check_output(['git','-C',str(repo),'ls-tree','-r',ref,'--',*paths],text=True)
assert tree('96305a93')==tree('HEAD')
result['old_evidence']={'all_blob_ids_preserved':True,'entries':len(tree('HEAD').splitlines())}
(root/'verification.json').write_text(json.dumps(result,indent=2))
print('Final tests, markers, assertion flags, historical failures and preserved evidence verified.')
