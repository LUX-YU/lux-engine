#include <lux/engine/function/script/abi/lux_script_abi.h>
#include <array>
#include <cstdlib>

namespace
{
    int invoke(void*, lux_script_call_frame*) { return 0; }
    int start(const lux_script_native_instance_context*, lux_script_call_frame*, const lux_script_step_host*,
        void*, lux_script_step_outcome*) { return 0; }
    int resume(const lux_script_step_host*, void*, const lux_script_step_resume_packet*, lux_script_step_outcome*)
    { return 0; }
    void destroy(void*) {}
    constexpr auto steps = [] {
        std::array<lux_script_step_desc, 8> result{};
        for (auto& step : result) step = {16U, 8U, 0x1234U, &start, &resume, &destroy};
        result[1].frame_size = 0U;
        result[2].frame_align = 0U;
        result[3].frame_align = 3U;
        result[4].start = nullptr;
        result[5].resume = nullptr;
        result[6].destroy = nullptr;
        result[7].initialization = 2U;
        return result;
    }();
    constexpr auto functions = [] {
        std::array<lux_script_function_desc, 8> result{};
        for (unsigned i{}; i < result.size(); ++i)
            result[i] = {"Step", 1U, nullptr, 0U, nullptr, 0U, &invoke, &steps[i]};
        return result;
    }();
    constexpr auto modules = [] {
        std::array<lux_script_module_desc, 8> result{};
        for (unsigned i{}; i < result.size(); ++i)
            result[i] = {"h1_cold_fixture", LUX_SCRIPT_ABI_VERSION, 0U, 0x2345U, 8U, 8U, &functions[i], 1U};
        return result;
    }();
}
extern "C" LUX_SCRIPT_EXPORT const lux_script_module_desc* lux_script_get_module()
{
    const auto* mode = std::getenv("LUX_H1_COLD_CASE");
    const auto index = mode ? std::atoi(mode) : 0;
    return index >= 0 && index < 8 ? &modules[index] : nullptr;
}
