
E:\SyncForder\CodeRepos\build\RelWithDebInfo\script-native-lua-na1\benchmark-slots\B\CMakeFiles\native_lua_complete_tasks.dir\generated\native_lua_complete_tasks\cpp_scripts\CompleteTasks\Tasks.CompleteTasks.script.generated.cpp.obj:	file format coff-x86-64

Disassembly of section .text$mn:

0000000000000000 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::event(class lux::simulation::script::ScriptCoroutineContext &)>::start(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *)>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 6c 24 10               	movq	%rbp, 0x10(%rsp)
       a: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
       f: 57                           	pushq	%rdi
      10: 48 83 ec 20                  	subq	$0x20, %rsp
      14: 49 8b e8                     	movq	%r8, %rbp
      17: 48 8b f2                     	movq	%rdx, %rsi
      1a: 48 8b d9                     	movq	%rcx, %rbx
      1d: 48 85 d2                     	testq	%rdx, %rdx
      20: 0f 84 ab 00 00 00            	je	0xd1 <$$__resumable_init_label$110+0x5c>
      26: 41 83 79 18 00               	cmpl	$0x0, 0x18(%r9)
      2b: 0f 85 a0 00 00 00            	jne	0xd1 <$$__resumable_init_label$110+0x5c>
      31: 41 8b 41 08                  	movl	0x8(%r9), %eax
      35: 85 c0                        	testl	%eax, %eax
      37: 74 12                        	je	0x4b <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::event(class lux::simulation::script::ScriptCoroutineContext &)>::start(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *)+0x4b>
      39: 49 83 39 00                  	cmpq	$0x0, (%r9)
      3d: 0f 84 8e 00 00 00            	je	0xd1 <$$__resumable_init_label$110+0x5c>
      43: 85 c0                        	testl	%eax, %eax
      45: 0f 85 86 00 00 00            	jne	0xd1 <$$__resumable_init_label$110+0x5c>
      4b: ba e0 00 00 00               	movl	$0xe0, %edx
      50: 41 b8 08 00 00 00            	movl	$0x8, %r8d
      56: 48 8b cd                     	movq	%rbp, %rcx
      59: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x5f <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::event(class lux::simulation::script::ScriptCoroutineContext &)>::start(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *)+0x5f>
		000000000000005b:  IMAGE_REL_AMD64_REL32	__imp_?allocateFrame@ScriptCoroutineContext@script@simulation@lux@@AEAAPEAX_K0@Z
      5f: 48 8b f8                     	movq	%rax, %rdi
      62: 48 8b cb                     	movq	%rbx, %rcx
      65: 48 85 c0                     	testq	%rax, %rax
      68: 75 0b                        	jne	0x75 <$$__resumable_init_label$110>
      6a: 48 89 03                     	movq	%rax, (%rbx)
      6d: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x73 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::event(class lux::simulation::script::ScriptCoroutineContext &)>::start(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *)+0x73>
		000000000000006f:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
      73: eb 5a                        	jmp	0xcf <$$__resumable_init_label$110+0x5a>

0000000000000075 <$$__resumable_init_label$110>:
      75: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x7c <$$__resumable_init_label$110+0x7>
		0000000000000078:  IMAGE_REL_AMD64_REL32	?event$_DestroyCoro$2@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      7c: 48 89 47 08                  	movq	%rax, 0x8(%rdi)
      80: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x87 <$$__resumable_init_label$110+0x12>
		0000000000000083:  IMAGE_REL_AMD64_REL32	?event$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      87: 48 89 07                     	movq	%rax, (%rdi)
      8a: 48 89 77 40                  	movq	%rsi, 0x40(%rdi)
      8e: 48 89 6f 48                  	movq	%rbp, 0x48(%rdi)
      92: c7 47 50 02 00 01 00         	movl	$0x10002, 0x50(%rdi)    # imm = 0x10002
      99: 33 c0                        	xorl	%eax, %eax
      9b: 66 89 47 11                  	movw	%ax, 0x11(%rdi)
      9f: 88 47 13                     	movb	%al, 0x13(%rdi)
      a2: 88 47 10                     	movb	%al, 0x10(%rdi)
      a5: 48 89 47 14                  	movq	%rax, 0x14(%rdi)
      a9: 89 47 1c                     	movl	%eax, 0x1c(%rdi)
      ac: 48 89 47 20                  	movq	%rax, 0x20(%rdi)
      b0: 48 89 47 28                  	movq	%rax, 0x28(%rdi)
      b4: 48 89 47 30                  	movq	%rax, 0x30(%rdi)
      b8: 48 8b d7                     	movq	%rdi, %rdx
      bb: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xc1 <$$__resumable_init_label$110+0x4c>
		00000000000000bd:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@AEAA@U?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
      c1: 33 c0                        	xorl	%eax, %eax
      c3: 88 47 38                     	movb	%al, 0x38(%rdi)
      c6: 48 8b cf                     	movq	%rdi, %rcx
      c9: e8 00 00 00 00               	callq	0xce <$$__resumable_init_label$110+0x59>
		00000000000000ca:  IMAGE_REL_AMD64_REL32	?event$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      ce: 90                           	nop
      cf: eb 0b                        	jmp	0xdc <$$__resumable_init_label$110+0x67>
      d1: 33 c0                        	xorl	%eax, %eax
      d3: 48 89 01                     	movq	%rax, (%rcx)
      d6: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xdc <$$__resumable_init_label$110+0x67>
		00000000000000d8:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
      dc: 48 8b c3                     	movq	%rbx, %rax
      df: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
      e4: 48 8b 6c 24 38               	movq	0x38(%rsp), %rbp
      e9: 48 8b 74 24 40               	movq	0x40(%rsp), %rsi
      ee: 48 83 c4 20                  	addq	$0x20, %rsp
      f2: 5f                           	popq	%rdi
      f3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::next(class lux::simulation::script::ScriptCoroutineContext &)>::start(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *)>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 6c 24 10               	movq	%rbp, 0x10(%rsp)
       a: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
       f: 57                           	pushq	%rdi
      10: 48 83 ec 20                  	subq	$0x20, %rsp
      14: 49 8b e8                     	movq	%r8, %rbp
      17: 48 8b f2                     	movq	%rdx, %rsi
      1a: 48 8b d9                     	movq	%rcx, %rbx
      1d: 48 85 d2                     	testq	%rdx, %rdx
      20: 0f 84 ab 00 00 00            	je	0xd1 <$$__resumable_init_label$113+0x5c>
      26: 41 83 79 18 00               	cmpl	$0x0, 0x18(%r9)
      2b: 0f 85 a0 00 00 00            	jne	0xd1 <$$__resumable_init_label$113+0x5c>
      31: 41 8b 41 08                  	movl	0x8(%r9), %eax
      35: 85 c0                        	testl	%eax, %eax
      37: 74 12                        	je	0x4b <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::next(class lux::simulation::script::ScriptCoroutineContext &)>::start(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *)+0x4b>
      39: 49 83 39 00                  	cmpq	$0x0, (%r9)
      3d: 0f 84 8e 00 00 00            	je	0xd1 <$$__resumable_init_label$113+0x5c>
      43: 85 c0                        	testl	%eax, %eax
      45: 0f 85 86 00 00 00            	jne	0xd1 <$$__resumable_init_label$113+0x5c>
      4b: ba 20 01 00 00               	movl	$0x120, %edx            # imm = 0x120
      50: 41 b8 08 00 00 00            	movl	$0x8, %r8d
      56: 48 8b cd                     	movq	%rbp, %rcx
      59: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x5f <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::next(class lux::simulation::script::ScriptCoroutineContext &)>::start(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *)+0x5f>
		000000000000005b:  IMAGE_REL_AMD64_REL32	__imp_?allocateFrame@ScriptCoroutineContext@script@simulation@lux@@AEAAPEAX_K0@Z
      5f: 48 8b f8                     	movq	%rax, %rdi
      62: 48 8b cb                     	movq	%rbx, %rcx
      65: 48 85 c0                     	testq	%rax, %rax
      68: 75 0b                        	jne	0x75 <$$__resumable_init_label$113>
      6a: 48 89 03                     	movq	%rax, (%rbx)
      6d: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x73 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::next(class lux::simulation::script::ScriptCoroutineContext &)>::start(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *)+0x73>
		000000000000006f:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
      73: eb 5a                        	jmp	0xcf <$$__resumable_init_label$113+0x5a>

0000000000000075 <$$__resumable_init_label$113>:
      75: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x7c <$$__resumable_init_label$113+0x7>
		0000000000000078:  IMAGE_REL_AMD64_REL32	?next$_DestroyCoro$2@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      7c: 48 89 47 08                  	movq	%rax, 0x8(%rdi)
      80: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x87 <$$__resumable_init_label$113+0x12>
		0000000000000083:  IMAGE_REL_AMD64_REL32	?next$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      87: 48 89 07                     	movq	%rax, (%rdi)
      8a: 48 89 77 40                  	movq	%rsi, 0x40(%rdi)
      8e: 48 89 6f 48                  	movq	%rbp, 0x48(%rdi)
      92: c7 47 50 02 00 01 00         	movl	$0x10002, 0x50(%rdi)    # imm = 0x10002
      99: 33 c0                        	xorl	%eax, %eax
      9b: 66 89 47 11                  	movw	%ax, 0x11(%rdi)
      9f: 88 47 13                     	movb	%al, 0x13(%rdi)
      a2: 88 47 10                     	movb	%al, 0x10(%rdi)
      a5: 48 89 47 14                  	movq	%rax, 0x14(%rdi)
      a9: 89 47 1c                     	movl	%eax, 0x1c(%rdi)
      ac: 48 89 47 20                  	movq	%rax, 0x20(%rdi)
      b0: 48 89 47 28                  	movq	%rax, 0x28(%rdi)
      b4: 48 89 47 30                  	movq	%rax, 0x30(%rdi)
      b8: 48 8b d7                     	movq	%rdi, %rdx
      bb: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xc1 <$$__resumable_init_label$113+0x4c>
		00000000000000bd:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@AEAA@U?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
      c1: 33 c0                        	xorl	%eax, %eax
      c3: 88 47 38                     	movb	%al, 0x38(%rdi)
      c6: 48 8b cf                     	movq	%rdi, %rcx
      c9: e8 00 00 00 00               	callq	0xce <$$__resumable_init_label$113+0x59>
		00000000000000ca:  IMAGE_REL_AMD64_REL32	?next$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      ce: 90                           	nop
      cf: eb 0b                        	jmp	0xdc <$$__resumable_init_label$113+0x67>
      d1: 33 c0                        	xorl	%eax, %eax
      d3: 48 89 01                     	movq	%rax, (%rcx)
      d6: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xdc <$$__resumable_init_label$113+0x67>
		00000000000000d8:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
      dc: 48 8b c3                     	movq	%rbx, %rax
      df: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
      e4: 48 8b 6c 24 38               	movq	0x38(%rsp), %rbp
      e9: 48 8b 74 24 40               	movq	0x40(%rsp), %rsi
      ee: 48 83 c4 20                  	addq	$0x20, %rsp
      f2: 5f                           	popq	%rdi
      f3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::sequence(class lux::simulation::script::ScriptCoroutineContext &)>::start(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *)>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 6c 24 10               	movq	%rbp, 0x10(%rsp)
       a: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
       f: 57                           	pushq	%rdi
      10: 48 83 ec 20                  	subq	$0x20, %rsp
      14: 49 8b e8                     	movq	%r8, %rbp
      17: 48 8b f2                     	movq	%rdx, %rsi
      1a: 48 8b d9                     	movq	%rcx, %rbx
      1d: 48 85 d2                     	testq	%rdx, %rdx
      20: 0f 84 ab 00 00 00            	je	0xd1 <$$__resumable_init_label$117+0x5c>
      26: 41 83 79 18 00               	cmpl	$0x0, 0x18(%r9)
      2b: 0f 85 a0 00 00 00            	jne	0xd1 <$$__resumable_init_label$117+0x5c>
      31: 41 8b 41 08                  	movl	0x8(%r9), %eax
      35: 85 c0                        	testl	%eax, %eax
      37: 74 12                        	je	0x4b <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::sequence(class lux::simulation::script::ScriptCoroutineContext &)>::start(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *)+0x4b>
      39: 49 83 39 00                  	cmpq	$0x0, (%r9)
      3d: 0f 84 8e 00 00 00            	je	0xd1 <$$__resumable_init_label$117+0x5c>
      43: 85 c0                        	testl	%eax, %eax
      45: 0f 85 86 00 00 00            	jne	0xd1 <$$__resumable_init_label$117+0x5c>
      4b: ba a0 01 00 00               	movl	$0x1a0, %edx            # imm = 0x1A0
      50: 41 b8 08 00 00 00            	movl	$0x8, %r8d
      56: 48 8b cd                     	movq	%rbp, %rcx
      59: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x5f <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::sequence(class lux::simulation::script::ScriptCoroutineContext &)>::start(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *)+0x5f>
		000000000000005b:  IMAGE_REL_AMD64_REL32	__imp_?allocateFrame@ScriptCoroutineContext@script@simulation@lux@@AEAAPEAX_K0@Z
      5f: 48 8b f8                     	movq	%rax, %rdi
      62: 48 8b cb                     	movq	%rbx, %rcx
      65: 48 85 c0                     	testq	%rax, %rax
      68: 75 0b                        	jne	0x75 <$$__resumable_init_label$117>
      6a: 48 89 03                     	movq	%rax, (%rbx)
      6d: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x73 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::sequence(class lux::simulation::script::ScriptCoroutineContext &)>::start(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *)+0x73>
		000000000000006f:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
      73: eb 5a                        	jmp	0xcf <$$__resumable_init_label$117+0x5a>

0000000000000075 <$$__resumable_init_label$117>:
      75: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x7c <$$__resumable_init_label$117+0x7>
		0000000000000078:  IMAGE_REL_AMD64_REL32	?sequence$_DestroyCoro$2@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      7c: 48 89 47 08                  	movq	%rax, 0x8(%rdi)
      80: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x87 <$$__resumable_init_label$117+0x12>
		0000000000000083:  IMAGE_REL_AMD64_REL32	?sequence$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      87: 48 89 07                     	movq	%rax, (%rdi)
      8a: 48 89 77 40                  	movq	%rsi, 0x40(%rdi)
      8e: 48 89 6f 48                  	movq	%rbp, 0x48(%rdi)
      92: c7 47 50 02 00 01 00         	movl	$0x10002, 0x50(%rdi)    # imm = 0x10002
      99: 33 c0                        	xorl	%eax, %eax
      9b: 66 89 47 11                  	movw	%ax, 0x11(%rdi)
      9f: 88 47 13                     	movb	%al, 0x13(%rdi)
      a2: 88 47 10                     	movb	%al, 0x10(%rdi)
      a5: 48 89 47 14                  	movq	%rax, 0x14(%rdi)
      a9: 89 47 1c                     	movl	%eax, 0x1c(%rdi)
      ac: 48 89 47 20                  	movq	%rax, 0x20(%rdi)
      b0: 48 89 47 28                  	movq	%rax, 0x28(%rdi)
      b4: 48 89 47 30                  	movq	%rax, 0x30(%rdi)
      b8: 48 8b d7                     	movq	%rdi, %rdx
      bb: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xc1 <$$__resumable_init_label$117+0x4c>
		00000000000000bd:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@AEAA@U?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
      c1: 33 c0                        	xorl	%eax, %eax
      c3: 88 47 38                     	movb	%al, 0x38(%rdi)
      c6: 48 8b cf                     	movq	%rdi, %rcx
      c9: e8 00 00 00 00               	callq	0xce <$$__resumable_init_label$117+0x59>
		00000000000000ca:  IMAGE_REL_AMD64_REL32	?sequence$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      ce: 90                           	nop
      cf: eb 0b                        	jmp	0xdc <$$__resumable_init_label$117+0x67>
      d1: 33 c0                        	xorl	%eax, %eax
      d3: 48 89 01                     	movq	%rax, (%rcx)
      d6: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xdc <$$__resumable_init_label$117+0x67>
		00000000000000d8:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
      dc: 48 8b c3                     	movq	%rbx, %rax
      df: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
      e4: 48 8b 6c 24 38               	movq	0x38(%rsp), %rbp
      e9: 48 8b 74 24 40               	movq	0x40(%rsp), %rsi
      ee: 48 83 c4 20                  	addq	$0x20, %rsp
      f2: 5f                           	popq	%rdi
      f3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::longTask(class lux::simulation::script::ScriptCoroutineContext &)>::start(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *)>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 6c 24 10               	movq	%rbp, 0x10(%rsp)
       a: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
       f: 57                           	pushq	%rdi
      10: 48 83 ec 20                  	subq	$0x20, %rsp
      14: 49 8b e8                     	movq	%r8, %rbp
      17: 48 8b f2                     	movq	%rdx, %rsi
      1a: 48 8b d9                     	movq	%rcx, %rbx
      1d: 48 85 d2                     	testq	%rdx, %rdx
      20: 0f 84 ab 00 00 00            	je	0xd1 <$$__resumable_init_label$113+0x5c>
      26: 41 83 79 18 00               	cmpl	$0x0, 0x18(%r9)
      2b: 0f 85 a0 00 00 00            	jne	0xd1 <$$__resumable_init_label$113+0x5c>
      31: 41 8b 41 08                  	movl	0x8(%r9), %eax
      35: 85 c0                        	testl	%eax, %eax
      37: 74 12                        	je	0x4b <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::longTask(class lux::simulation::script::ScriptCoroutineContext &)>::start(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *)+0x4b>
      39: 49 83 39 00                  	cmpq	$0x0, (%r9)
      3d: 0f 84 8e 00 00 00            	je	0xd1 <$$__resumable_init_label$113+0x5c>
      43: 85 c0                        	testl	%eax, %eax
      45: 0f 85 86 00 00 00            	jne	0xd1 <$$__resumable_init_label$113+0x5c>
      4b: ba e0 00 00 00               	movl	$0xe0, %edx
      50: 41 b8 08 00 00 00            	movl	$0x8, %r8d
      56: 48 8b cd                     	movq	%rbp, %rcx
      59: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x5f <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::longTask(class lux::simulation::script::ScriptCoroutineContext &)>::start(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *)+0x5f>
		000000000000005b:  IMAGE_REL_AMD64_REL32	__imp_?allocateFrame@ScriptCoroutineContext@script@simulation@lux@@AEAAPEAX_K0@Z
      5f: 48 8b f8                     	movq	%rax, %rdi
      62: 48 8b cb                     	movq	%rbx, %rcx
      65: 48 85 c0                     	testq	%rax, %rax
      68: 75 0b                        	jne	0x75 <$$__resumable_init_label$113>
      6a: 48 89 03                     	movq	%rax, (%rbx)
      6d: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x73 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::longTask(class lux::simulation::script::ScriptCoroutineContext &)>::start(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *)+0x73>
		000000000000006f:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
      73: eb 5a                        	jmp	0xcf <$$__resumable_init_label$113+0x5a>

0000000000000075 <$$__resumable_init_label$113>:
      75: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x7c <$$__resumable_init_label$113+0x7>
		0000000000000078:  IMAGE_REL_AMD64_REL32	?longTask$_DestroyCoro$2@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      7c: 48 89 47 08                  	movq	%rax, 0x8(%rdi)
      80: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x87 <$$__resumable_init_label$113+0x12>
		0000000000000083:  IMAGE_REL_AMD64_REL32	?longTask$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      87: 48 89 07                     	movq	%rax, (%rdi)
      8a: 48 89 77 40                  	movq	%rsi, 0x40(%rdi)
      8e: 48 89 6f 48                  	movq	%rbp, 0x48(%rdi)
      92: c7 47 50 02 00 01 00         	movl	$0x10002, 0x50(%rdi)    # imm = 0x10002
      99: 33 c0                        	xorl	%eax, %eax
      9b: 66 89 47 11                  	movw	%ax, 0x11(%rdi)
      9f: 88 47 13                     	movb	%al, 0x13(%rdi)
      a2: 88 47 10                     	movb	%al, 0x10(%rdi)
      a5: 48 89 47 14                  	movq	%rax, 0x14(%rdi)
      a9: 89 47 1c                     	movl	%eax, 0x1c(%rdi)
      ac: 48 89 47 20                  	movq	%rax, 0x20(%rdi)
      b0: 48 89 47 28                  	movq	%rax, 0x28(%rdi)
      b4: 48 89 47 30                  	movq	%rax, 0x30(%rdi)
      b8: 48 8b d7                     	movq	%rdi, %rdx
      bb: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xc1 <$$__resumable_init_label$113+0x4c>
		00000000000000bd:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@AEAA@U?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
      c1: 33 c0                        	xorl	%eax, %eax
      c3: 88 47 38                     	movb	%al, 0x38(%rdi)
      c6: 48 8b cf                     	movq	%rdi, %rcx
      c9: e8 00 00 00 00               	callq	0xce <$$__resumable_init_label$113+0x59>
		00000000000000ca:  IMAGE_REL_AMD64_REL32	?longTask$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      ce: 90                           	nop
      cf: eb 0b                        	jmp	0xdc <$$__resumable_init_label$113+0x67>
      d1: 33 c0                        	xorl	%eax, %eax
      d3: 48 89 01                     	movq	%rax, (%rcx)
      d6: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xdc <$$__resumable_init_label$113+0x67>
		00000000000000d8:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
      dc: 48 8b c3                     	movq	%rbx, %rax
      df: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
      e4: 48 8b 6c 24 38               	movq	0x38(%rsp), %rbp
      e9: 48 8b 74 24 40               	movq	0x40(%rsp), %rsi
      ee: 48 83 c4 20                  	addq	$0x20, %rsp
      f2: 5f                           	popq	%rdi
      f3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::pose(class lux::simulation::script::ScriptCoroutineContext &, struct lux::simulation::script::test::ValuePose const &)>::start(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *)>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 6c 24 10               	movq	%rbp, 0x10(%rsp)
       a: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
       f: 48 89 7c 24 20               	movq	%rdi, 0x20(%rsp)
      14: 41 56                        	pushq	%r14
      16: 48 83 ec 20                  	subq	$0x20, %rsp
      1a: 4d 8b f0                     	movq	%r8, %r14
      1d: 48 8b ea                     	movq	%rdx, %rbp
      20: 48 8b d9                     	movq	%rcx, %rbx
      23: 48 85 d2                     	testq	%rdx, %rdx
      26: 0f 84 ed 00 00 00            	je	0x119 <$$__resumable_init_label$120+0x60>
      2c: 41 83 79 18 00               	cmpl	$0x0, 0x18(%r9)
      31: 0f 85 e2 00 00 00            	jne	0x119 <$$__resumable_init_label$120+0x60>
      37: 48 8b 74 24 50               	movq	0x50(%rsp), %rsi
      3c: 48 85 f6                     	testq	%rsi, %rsi
      3f: 0f 84 d4 00 00 00            	je	0x119 <$$__resumable_init_label$120+0x60>
      45: 41 8b 49 08                  	movl	0x8(%r9), %ecx
      49: 85 c9                        	testl	%ecx, %ecx
      4b: 74 0a                        	je	0x57 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::pose(class lux::simulation::script::ScriptCoroutineContext &, struct lux::simulation::script::test::ValuePose const &)>::start(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *)+0x57>
      4d: 49 83 39 00                  	cmpq	$0x0, (%r9)
      51: 75 04                        	jne	0x57 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::pose(class lux::simulation::script::ScriptCoroutineContext &, struct lux::simulation::script::test::ValuePose const &)>::start(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *)+0x57>
      53: b0 01                        	movb	$0x1, %al
      55: eb 02                        	jmp	0x59 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::pose(class lux::simulation::script::ScriptCoroutineContext &, struct lux::simulation::script::test::ValuePose const &)>::start(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *)+0x59>
      57: 32 c0                        	xorb	%al, %al
      59: 83 f9 01                     	cmpl	$0x1, %ecx
      5c: 0f 85 b7 00 00 00            	jne	0x119 <$$__resumable_init_label$120+0x60>
      62: 84 c0                        	testb	%al, %al
      64: 0f 85 af 00 00 00            	jne	0x119 <$$__resumable_init_label$120+0x60>
      6a: 49 8b 39                     	movq	(%r9), %rdi
      6d: 48 8b cf                     	movq	%rdi, %rcx
      70: e8 00 00 00 00               	callq	0x75 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::pose(class lux::simulation::script::ScriptCoroutineContext &, struct lux::simulation::script::test::ValuePose const &)>::start(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *)+0x75>
		0000000000000071:  IMAGE_REL_AMD64_REL32	??$cppStaticSlotMatches@AEBUValuePose@test@script@simulation@lux@@@detail@script@simulation@lux@@YA_NAEBUlux_script_value_slot@@@Z
      75: 84 c0                        	testb	%al, %al
      77: 0f 84 9c 00 00 00            	je	0x119 <$$__resumable_init_label$120+0x60>
      7d: 48 8b 47 10                  	movq	0x10(%rdi), %rax
      81: 0f 10 00                     	movups	(%rax), %xmm0
      84: 0f 11 06                     	movups	%xmm0, (%rsi)
      87: 0f 10 48 10                  	movups	0x10(%rax), %xmm1
      8b: 0f 11 4e 10                  	movups	%xmm1, 0x10(%rsi)
      8f: ba 30 01 00 00               	movl	$0x130, %edx            # imm = 0x130
      94: 41 b8 08 00 00 00            	movl	$0x8, %r8d
      9a: 49 8b ce                     	movq	%r14, %rcx
      9d: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xa3 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::pose(class lux::simulation::script::ScriptCoroutineContext &, struct lux::simulation::script::test::ValuePose const &)>::start(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *)+0xa3>
		000000000000009f:  IMAGE_REL_AMD64_REL32	__imp_?allocateFrame@ScriptCoroutineContext@script@simulation@lux@@AEAAPEAX_K0@Z
      a3: 48 8b f8                     	movq	%rax, %rdi
      a6: 48 8b cb                     	movq	%rbx, %rcx
      a9: 48 85 c0                     	testq	%rax, %rax
      ac: 75 0b                        	jne	0xb9 <$$__resumable_init_label$120>
      ae: 48 89 03                     	movq	%rax, (%rbx)
      b1: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xb7 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::pose(class lux::simulation::script::ScriptCoroutineContext &, struct lux::simulation::script::test::ValuePose const &)>::start(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *)+0xb7>
		00000000000000b3:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
      b7: eb 5e                        	jmp	0x117 <$$__resumable_init_label$120+0x5e>

00000000000000b9 <$$__resumable_init_label$120>:
      b9: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0xc0 <$$__resumable_init_label$120+0x7>
		00000000000000bc:  IMAGE_REL_AMD64_REL32	?pose$_DestroyCoro$2@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@AEBUValuePose@test@745@@Z
      c0: 48 89 47 08                  	movq	%rax, 0x8(%rdi)
      c4: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0xcb <$$__resumable_init_label$120+0x12>
		00000000000000c7:  IMAGE_REL_AMD64_REL32	?pose$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@AEBUValuePose@test@745@@Z
      cb: 48 89 07                     	movq	%rax, (%rdi)
      ce: 48 89 6f 40                  	movq	%rbp, 0x40(%rdi)
      d2: 4c 89 77 48                  	movq	%r14, 0x48(%rdi)
      d6: 48 89 77 50                  	movq	%rsi, 0x50(%rdi)
      da: c7 47 58 02 00 01 00         	movl	$0x10002, 0x58(%rdi)    # imm = 0x10002
      e1: 33 c0                        	xorl	%eax, %eax
      e3: 66 89 47 11                  	movw	%ax, 0x11(%rdi)
      e7: 88 47 13                     	movb	%al, 0x13(%rdi)
      ea: 88 47 10                     	movb	%al, 0x10(%rdi)
      ed: 48 89 47 14                  	movq	%rax, 0x14(%rdi)
      f1: 89 47 1c                     	movl	%eax, 0x1c(%rdi)
      f4: 48 89 47 20                  	movq	%rax, 0x20(%rdi)
      f8: 48 89 47 28                  	movq	%rax, 0x28(%rdi)
      fc: 48 89 47 30                  	movq	%rax, 0x30(%rdi)
     100: 48 8b d7                     	movq	%rdi, %rdx
     103: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x109 <$$__resumable_init_label$120+0x50>
		0000000000000105:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@AEAA@U?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
     109: 33 c0                        	xorl	%eax, %eax
     10b: 88 47 38                     	movb	%al, 0x38(%rdi)
     10e: 48 8b cf                     	movq	%rdi, %rcx
     111: e8 00 00 00 00               	callq	0x116 <$$__resumable_init_label$120+0x5d>
		0000000000000112:  IMAGE_REL_AMD64_REL32	?pose$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@AEBUValuePose@test@745@@Z
     116: 90                           	nop
     117: eb 0e                        	jmp	0x127 <$$__resumable_init_label$120+0x6e>
     119: 33 c0                        	xorl	%eax, %eax
     11b: 48 89 03                     	movq	%rax, (%rbx)
     11e: 48 8b cb                     	movq	%rbx, %rcx
     121: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x127 <$$__resumable_init_label$120+0x6e>
		0000000000000123:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
     127: 48 8b c3                     	movq	%rbx, %rax
     12a: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
     12f: 48 8b 6c 24 38               	movq	0x38(%rsp), %rbp
     134: 48 8b 74 24 40               	movq	0x40(%rsp), %rsi
     139: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
     13e: 48 83 c4 20                  	addq	$0x20, %rsp
     142: 41 5e                        	popq	%r14
     144: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <bool __cdecl lux::simulation::script::generated::CompleteTasksOperations::resolveAbility(unsigned __int64, unsigned int &)>:
       0: 48 b8 ca af c4 5b ce f5 42 81	movabsq	$-0x7ebd0a31a43b5036, %rax # imm = 0x8142F5CE5BC4AFCA
       a: 48 3b c8                     	cmpq	%rax, %rcx
       d: 74 03                        	je	0x12 <bool __cdecl lux::simulation::script::generated::CompleteTasksOperations::resolveAbility(unsigned __int64, unsigned int &)+0x12>
       f: 32 c0                        	xorb	%al, %al
      11: c3                           	retq
      12: c7 02 00 00 00 00            	movl	$0x0, (%rdx)
      18: b0 01                        	movb	$0x1, %al
      1a: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static __cdecl `struct lux::simulation::script::CppStaticObjectOperations __cdecl lux::simulation::script::detail::cppStaticObject<struct lux::simulation::na1::cost::Tasks, 0>(void)'::`2'::<lambda_1>::<lambda_invoker_cdecl>(void *)>:
       0: 48 8b d1                     	movq	%rcx, %rdx
       3: 48 8d 4c 24 10               	leaq	0x10(%rsp), %rcx
       8: e9 00 00 00 00               	jmp	0xd <public: static __cdecl `struct lux::simulation::script::CppStaticObjectOperations __cdecl lux::simulation::script::detail::cppStaticObject<struct lux::simulation::na1::cost::Tasks, 0>(void)'::`2'::<lambda_1>::<lambda_invoker_cdecl>(void *)+0xd>
		0000000000000009:  IMAGE_REL_AMD64_REL32	??R<lambda_1>@?1???$cppStaticObject@UTasks@cost@na1@simulation@lux@@$M$$T0A@@detail@script@simulation@lux@@YA?AUCppStaticObjectOperations@234@XZ@QEBA@PEAX@Z

Disassembly of section .text$mn:

0000000000000000 <public: static __cdecl `struct lux::simulation::script::CppStaticObjectOperations __cdecl lux::simulation::script::detail::cppStaticObject<struct lux::simulation::na1::cost::Tasks, 0>(void)'::`2'::<lambda_2>::<lambda_invoker_cdecl>(void *)>:
       0: c2 00 00                     	retq	$0x0

Disassembly of section .text$mn:

0000000000000000 <class `public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::nextStep(void) const'::`2'::<lambda_1> && __cdecl <move><class `public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::nextStep(void) const'::`2'::<lambda_1> &>(class `public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::nextStep(void) const'::`2'::<lambda_1> &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <class `public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::simulationSeconds(double) const'::`2'::<lambda_1> && __cdecl <move><class `public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::simulationSeconds(double) const'::`2'::<lambda_1> &>(class `public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::simulationSeconds(double) const'::`2'::<lambda_1> &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <class std::tuple<> && __cdecl <move><class std::tuple<> &>(class std::tuple<> &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <class std::tuple<double> && __cdecl <move><class std::tuple<double> &>(class std::tuple<double> &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl std::tuple<double>::tuple<double><double, 0>(double &&)>:
       0: 48 8b 02                     	movq	(%rdx), %rax
       3: 48 89 01                     	movq	%rax, (%rcx)
       6: 48 8b c1                     	movq	%rcx, %rax
       9: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl std::_Tuple_val<double>::_Tuple_val<double><double>(double &&)>:
       0: 48 8b 02                     	movq	(%rdx), %rax
       3: 48 89 01                     	movq	%rax, (%rcx)
       6: 48 8b c1                     	movq	%rcx, %rax
       9: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl std::tuple<>::tuple<><struct std::_Exact_args_t, 0>(struct std::_Exact_args_t)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl std::tuple<double>::tuple<double><struct std::_Exact_args_t, double, 0>(struct std::_Exact_args_t, double &&)>:
       0: 49 8b 00                     	movq	(%r8), %rax
       3: 48 89 01                     	movq	%rax, (%rcx)
       6: 48 8b c1                     	movq	%rcx, %rax
       9: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl std::span<struct lux_script_value_slot const, -1>::span<struct lux_script_value_slot const, -1><struct lux_script_value_slot, 1>(class std::array<struct lux_script_value_slot, 1> const &)>:
       0: 48 89 11                     	movq	%rdx, (%rcx)
       3: 48 8b c1                     	movq	%rcx, %rax
       6: 48 c7 41 08 01 00 00 00      	movq	$0x1, 0x8(%rcx)
       e: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl std::span<struct lux_script_value_slot const, -1>::span<struct lux_script_value_slot const, -1><struct lux_script_value_slot, 0>(class std::array<struct lux_script_value_slot, 0> const &)>:
       0: 33 c0                        	xorl	%eax, %eax
       2: 48 89 01                     	movq	%rax, (%rcx)
       5: 48 89 41 08                  	movq	%rax, 0x8(%rcx)
       9: 48 8b c1                     	movq	%rcx, %rax
       c: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::expected<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>::expected<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError><enum lux::simulation::script::EScriptAwaitableCreateError, 0, 0>(class tl::unexpected<enum lux::simulation::script::EScriptAwaitableCreateError> &&)>:
       0: 0f b6 02                     	movzbl	(%rdx), %eax
       3: 88 01                        	movb	%al, (%rcx)
       5: 48 8b c1                     	movq	%rcx, %rax
       8: c6 41 70 00                  	movb	$0x0, 0x70(%rcx)
       c: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::detail::expected_copy_assign_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>::expected_copy_assign_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1><enum lux::simulation::script::EScriptAwaitableCreateError, 0>(struct tl::unexpect_t, enum lux::simulation::script::EScriptAwaitableCreateError &&)>:
       0: 41 0f b6 00                  	movzbl	(%r8), %eax
       4: 88 01                        	movb	%al, (%rcx)
       6: 48 8b c1                     	movq	%rcx, %rax
       9: c6 41 70 00                  	movb	$0x0, 0x70(%rcx)
       d: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::detail::expected_copy_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>::expected_copy_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1><enum lux::simulation::script::EScriptAwaitableCreateError, 0>(struct tl::unexpect_t, enum lux::simulation::script::EScriptAwaitableCreateError &&)>:
       0: 41 0f b6 00                  	movzbl	(%r8), %eax
       4: 88 01                        	movb	%al, (%rcx)
       6: 48 8b c1                     	movq	%rcx, %rax
       9: c6 41 70 00                  	movb	$0x0, 0x70(%rcx)
       d: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::detail::expected_move_assign_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0>::expected_move_assign_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0><enum lux::simulation::script::EScriptAwaitableCreateError, 0>(struct tl::unexpect_t, enum lux::simulation::script::EScriptAwaitableCreateError &&)>:
       0: 41 0f b6 00                  	movzbl	(%r8), %eax
       4: 88 01                        	movb	%al, (%rcx)
       6: 48 8b c1                     	movq	%rcx, %rax
       9: c6 41 70 00                  	movb	$0x0, 0x70(%rcx)
       d: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::detail::expected_move_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0>::expected_move_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0><enum lux::simulation::script::EScriptAwaitableCreateError, 0>(struct tl::unexpect_t, enum lux::simulation::script::EScriptAwaitableCreateError &&)>:
       0: 41 0f b6 00                  	movzbl	(%r8), %eax
       4: 88 01                        	movb	%al, (%rcx)
       6: 48 8b c1                     	movq	%rcx, %rax
       9: c6 41 70 00                  	movb	$0x0, 0x70(%rcx)
       d: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::detail::expected_operations_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>::expected_operations_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError><enum lux::simulation::script::EScriptAwaitableCreateError, 0>(struct tl::unexpect_t, enum lux::simulation::script::EScriptAwaitableCreateError &&)>:
       0: 41 0f b6 00                  	movzbl	(%r8), %eax
       4: 88 01                        	movb	%al, (%rcx)
       6: 48 8b c1                     	movq	%rcx, %rax
       9: c6 41 70 00                  	movb	$0x0, 0x70(%rcx)
       d: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::detail::expected_storage_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>::expected_storage_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1><enum lux::simulation::script::EScriptAwaitableCreateError, 0>(struct tl::unexpect_t, enum lux::simulation::script::EScriptAwaitableCreateError &&)>:
       0: 41 0f b6 00                  	movzbl	(%r8), %eax
       4: 88 01                        	movb	%al, (%rcx)
       6: 48 8b c1                     	movq	%rcx, %rax
       9: c6 41 70 00                  	movb	$0x0, 0x70(%rcx)
       d: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::expected<struct lux::simulation::script::ScriptAwaitableId, enum lux::simulation::script::EScriptEventWaitError>::expected<struct lux::simulation::script::ScriptAwaitableId, enum lux::simulation::script::EScriptEventWaitError><enum lux::simulation::script::EScriptEventWaitError, 0, 0>(class tl::unexpected<enum lux::simulation::script::EScriptEventWaitError> &&)>:
       0: 0f b6 02                     	movzbl	(%rdx), %eax
       3: 88 01                        	movb	%al, (%rcx)
       5: 48 8b c1                     	movq	%rcx, %rax
       8: c6 41 08 00                  	movb	$0x0, 0x8(%rcx)
       c: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::detail::expected_copy_assign_base<struct lux::simulation::script::ScriptAwaitableId, enum lux::simulation::script::EScriptEventWaitError, 1, 1>::expected_copy_assign_base<struct lux::simulation::script::ScriptAwaitableId, enum lux::simulation::script::EScriptEventWaitError, 1, 1><enum lux::simulation::script::EScriptEventWaitError, 0>(struct tl::unexpect_t, enum lux::simulation::script::EScriptEventWaitError &&)>:
       0: 41 0f b6 00                  	movzbl	(%r8), %eax
       4: 88 01                        	movb	%al, (%rcx)
       6: 48 8b c1                     	movq	%rcx, %rax
       9: c6 41 08 00                  	movb	$0x0, 0x8(%rcx)
       d: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::detail::expected_copy_base<struct lux::simulation::script::ScriptAwaitableId, enum lux::simulation::script::EScriptEventWaitError, 1, 1>::expected_copy_base<struct lux::simulation::script::ScriptAwaitableId, enum lux::simulation::script::EScriptEventWaitError, 1, 1><enum lux::simulation::script::EScriptEventWaitError, 0>(struct tl::unexpect_t, enum lux::simulation::script::EScriptEventWaitError &&)>:
       0: 41 0f b6 00                  	movzbl	(%r8), %eax
       4: 88 01                        	movb	%al, (%rcx)
       6: 48 8b c1                     	movq	%rcx, %rax
       9: c6 41 08 00                  	movb	$0x0, 0x8(%rcx)
       d: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::detail::expected_move_assign_base<struct lux::simulation::script::ScriptAwaitableId, enum lux::simulation::script::EScriptEventWaitError, 1>::expected_move_assign_base<struct lux::simulation::script::ScriptAwaitableId, enum lux::simulation::script::EScriptEventWaitError, 1><enum lux::simulation::script::EScriptEventWaitError, 0>(struct tl::unexpect_t, enum lux::simulation::script::EScriptEventWaitError &&)>:
       0: 41 0f b6 00                  	movzbl	(%r8), %eax
       4: 88 01                        	movb	%al, (%rcx)
       6: 48 8b c1                     	movq	%rcx, %rax
       9: c6 41 08 00                  	movb	$0x0, 0x8(%rcx)
       d: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::detail::expected_move_base<struct lux::simulation::script::ScriptAwaitableId, enum lux::simulation::script::EScriptEventWaitError, 1>::expected_move_base<struct lux::simulation::script::ScriptAwaitableId, enum lux::simulation::script::EScriptEventWaitError, 1><enum lux::simulation::script::EScriptEventWaitError, 0>(struct tl::unexpect_t, enum lux::simulation::script::EScriptEventWaitError &&)>:
       0: 41 0f b6 00                  	movzbl	(%r8), %eax
       4: 88 01                        	movb	%al, (%rcx)
       6: 48 8b c1                     	movq	%rcx, %rax
       9: c6 41 08 00                  	movb	$0x0, 0x8(%rcx)
       d: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::detail::expected_operations_base<struct lux::simulation::script::ScriptAwaitableId, enum lux::simulation::script::EScriptEventWaitError>::expected_operations_base<struct lux::simulation::script::ScriptAwaitableId, enum lux::simulation::script::EScriptEventWaitError><enum lux::simulation::script::EScriptEventWaitError, 0>(struct tl::unexpect_t, enum lux::simulation::script::EScriptEventWaitError &&)>:
       0: 41 0f b6 00                  	movzbl	(%r8), %eax
       4: 88 01                        	movb	%al, (%rcx)
       6: 48 8b c1                     	movq	%rcx, %rax
       9: c6 41 08 00                  	movb	$0x0, 0x8(%rcx)
       d: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::detail::expected_storage_base<struct lux::simulation::script::ScriptAwaitableId, enum lux::simulation::script::EScriptEventWaitError, 1, 1>::expected_storage_base<struct lux::simulation::script::ScriptAwaitableId, enum lux::simulation::script::EScriptEventWaitError, 1, 1><enum lux::simulation::script::EScriptEventWaitError, 0>(struct tl::unexpect_t, enum lux::simulation::script::EScriptEventWaitError &&)>:
       0: 41 0f b6 00                  	movzbl	(%r8), %eax
       4: 88 01                        	movb	%al, (%rcx)
       6: 48 8b c1                     	movq	%rcx, %rax
       9: c6 41 08 00                  	movb	$0x0, 0x8(%rcx)
       d: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static void * __cdecl lux::simulation::script::ScriptCoroutine::promise_type::operator new<struct lux::simulation::na1::cost::Tasks>(unsigned __int64, struct lux::simulation::na1::cost::Tasks &, class lux::simulation::script::ScriptCoroutineContext &)>:
       0: 49 8b c0                     	movq	%r8, %rax
       3: 48 8b d1                     	movq	%rcx, %rdx
       6: 48 8b c8                     	movq	%rax, %rcx
       9: 41 b8 08 00 00 00            	movl	$0x8, %r8d
       f: 48 ff 25 00 00 00 00         	jmpq	*(%rip)                 # 0x16 <public: static void * __cdecl lux::simulation::script::ScriptCoroutine::promise_type::operator new<struct lux::simulation::na1::cost::Tasks>(unsigned __int64, struct lux::simulation::na1::cost::Tasks &, class lux::simulation::script::ScriptCoroutineContext &)+0x16>
		0000000000000012:  IMAGE_REL_AMD64_REL32	__imp_?allocateFrame@ScriptCoroutineContext@script@simulation@lux@@AEAAPEAX_K0@Z

Disassembly of section .text$mn:

0000000000000000 <public: static void * __cdecl lux::simulation::script::ScriptCoroutine::promise_type::operator new<struct lux::simulation::na1::cost::Tasks, struct lux::simulation::script::test::ValuePose const &>(unsigned __int64, struct lux::simulation::na1::cost::Tasks &, class lux::simulation::script::ScriptCoroutineContext &, struct lux::simulation::script::test::ValuePose const &)>:
       0: 49 8b c0                     	movq	%r8, %rax
       3: 48 8b d1                     	movq	%rcx, %rdx
       6: 48 8b c8                     	movq	%rax, %rcx
       9: 41 b8 08 00 00 00            	movl	$0x8, %r8d
       f: 48 ff 25 00 00 00 00         	jmpq	*(%rip)                 # 0x16 <public: static void * __cdecl lux::simulation::script::ScriptCoroutine::promise_type::operator new<struct lux::simulation::na1::cost::Tasks, struct lux::simulation::script::test::ValuePose const &>(unsigned __int64, struct lux::simulation::na1::cost::Tasks &, class lux::simulation::script::ScriptCoroutineContext &, struct lux::simulation::script::test::ValuePose const &)+0x16>
		0000000000000012:  IMAGE_REL_AMD64_REL32	__imp_?allocateFrame@ScriptCoroutineContext@script@simulation@lux@@AEAAPEAX_K0@Z

Disassembly of section .text$mn:

0000000000000000 <public: struct lux::simulation::script::ScriptAwaitableId const & __cdecl tl::expected<struct lux::simulation::script::ScriptAwaitableId, enum lux::simulation::script::EScriptEventWaitError>::operator*<struct lux::simulation::script::ScriptAwaitableId, 0>(void) const &>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$?R$$V@<lambda_1>@?1???R0?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@$$V@std@@V0?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@XZ@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z@QEBA?A_PXZ>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 60                  	subq	$0x60, %rsp
       6: 48 8b 41 10                  	movq	0x10(%rcx), %rax
       a: 4c 8d 4c 24 20               	leaq	0x20(%rsp), %r9
       f: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
      14: 4c 8d 44 24 40               	leaq	0x40(%rsp), %r8
      19: 48 8b 41 18                  	movq	0x18(%rcx), %rax
      1d: 48 8b da                     	movq	%rdx, %rbx
      20: 48 8b 11                     	movq	(%rcx), %rdx
      23: 48 89 44 24 28               	movq	%rax, 0x28(%rsp)
      28: 48 8b 41 08                  	movq	0x8(%rcx), %rax
      2c: 48 8d 4c 24 30               	leaq	0x30(%rsp), %rcx
      31: 0f 10 00                     	movups	(%rax), %xmm0
      34: f2 0f 10 48 10               	movsd	0x10(%rax), %xmm1
      39: 0f 29 44 24 40               	movaps	%xmm0, 0x40(%rsp)
      3e: f2 0f 11 4c 24 50            	movsd	%xmm1, 0x50(%rsp)
      44: e8 00 00 00 00               	callq	0x49 <??$?R$$V@<lambda_1>@?1???R0?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@$$V@std@@V0?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@XZ@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z@QEBA?A_PXZ+0x49>
		0000000000000045:  IMAGE_REL_AMD64_REL32	??$invokePreparedScriptAbilityAsync@XV<lambda_1>@?1???$?R$$V@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PXZ@$$V@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@VPreparedLocalAsyncStart@012@$$QEAV<lambda_1>@?1???$?R$$V@6?1???R6?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@$$V@std@@V6?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@XZ@@Z@QEAA@AEAV7012@0@Z@QEBA?A_PXZ@@Z
      49: 0f 10 00                     	movups	(%rax), %xmm0
      4c: 48 8b c3                     	movq	%rbx, %rax
      4f: 0f 11 03                     	movups	%xmm0, (%rbx)
      52: 48 83 c4 60                  	addq	$0x60, %rsp
      56: 5b                           	popq	%rbx
      57: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$?RN@<lambda_1>@?1???R0?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@N@std@@V0?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@N@Z@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z@QEBA?A_PAEAN@Z>:
       0: 4c 8b dc                     	movq	%rsp, %r11
       3: 53                           	pushq	%rbx
       4: 48 81 ec 80 00 00 00         	subq	$0x80, %rsp
       b: 48 8b 41 10                  	movq	0x10(%rcx), %rax
       f: 4d 8d 4b b8                  	leaq	-0x48(%r11), %r9
      13: 49 89 43 b8                  	movq	%rax, -0x48(%r11)
      17: 48 8b da                     	movq	%rdx, %rbx
      1a: 48 8b 41 18                  	movq	0x18(%rcx), %rax
      1e: 48 8b 11                     	movq	(%rcx), %rdx
      21: 49 89 43 c0                  	movq	%rax, -0x40(%r11)
      25: 48 8b 41 08                  	movq	0x8(%rcx), %rax
      29: 49 8d 4b a8                  	leaq	-0x58(%r11), %rcx
      2d: 4d 89 43 c8                  	movq	%r8, -0x38(%r11)
      31: 4d 89 43 98                  	movq	%r8, -0x68(%r11)
      35: 4d 8d 43 d8                  	leaq	-0x28(%r11), %r8
      39: 0f 10 00                     	movups	(%rax), %xmm0
      3c: f2 0f 10 48 10               	movsd	0x10(%rax), %xmm1
      41: 0f 29 44 24 60               	movaps	%xmm0, 0x60(%rsp)
      46: f2 0f 11 4c 24 70            	movsd	%xmm1, 0x70(%rsp)
      4c: e8 00 00 00 00               	callq	0x51 <??$?RN@<lambda_1>@?1???R0?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@N@std@@V0?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@N@Z@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z@QEBA?A_PAEAN@Z+0x51>
		000000000000004d:  IMAGE_REL_AMD64_REL32	??$invokePreparedScriptAbilityAsync@XV<lambda_1>@?1???$?RN@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PAEAN@Z@N@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@VPreparedLocalAsyncStart@012@$$QEAV<lambda_1>@?1???$?RN@6?1???R6?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@N@std@@V6?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@N@Z@@Z@QEAA@AEAV7012@0@Z@QEBA?A_PAEAN@Z@6@Z
      51: 0f 10 00                     	movups	(%rax), %xmm0
      54: 48 8b c3                     	movq	%rbx, %rax
      57: 0f 11 03                     	movups	%xmm0, (%rbx)
      5a: 48 81 c4 80 00 00 00         	addq	$0x80, %rsp
      61: 5b                           	popq	%rbx
      62: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$_Apply_impl@V<lambda_1>@?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@AEAV89@$S@std@@YA?A_T$$QEAV<lambda_1>@?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@0@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@AEAV80@U?$integer_sequence@_K$S@0@@Z>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 60                  	subq	$0x60, %rsp
       6: 48 8b 42 10                  	movq	0x10(%rdx), %rax
       a: 4c 8d 4c 24 20               	leaq	0x20(%rsp), %r9
       f: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
      14: 4c 8d 44 24 40               	leaq	0x40(%rsp), %r8
      19: 48 8b 42 18                  	movq	0x18(%rdx), %rax
      1d: 48 8b d9                     	movq	%rcx, %rbx
      20: 48 89 44 24 28               	movq	%rax, 0x28(%rsp)
      25: 48 8d 4c 24 30               	leaq	0x30(%rsp), %rcx
      2a: 48 8b 42 08                  	movq	0x8(%rdx), %rax
      2e: 48 8b 12                     	movq	(%rdx), %rdx
      31: 0f 10 00                     	movups	(%rax), %xmm0
      34: f2 0f 10 48 10               	movsd	0x10(%rax), %xmm1
      39: 0f 29 44 24 40               	movaps	%xmm0, 0x40(%rsp)
      3e: f2 0f 11 4c 24 50            	movsd	%xmm1, 0x50(%rsp)
      44: e8 00 00 00 00               	callq	0x49 <??$_Apply_impl@V<lambda_1>@?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@AEAV89@$S@std@@YA?A_T$$QEAV<lambda_1>@?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@0@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@AEAV80@U?$integer_sequence@_K$S@0@@Z+0x49>
		0000000000000045:  IMAGE_REL_AMD64_REL32	??$invokePreparedScriptAbilityAsync@XV<lambda_1>@?1???$?R$$V@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PXZ@$$V@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@VPreparedLocalAsyncStart@012@$$QEAV<lambda_1>@?1???$?R$$V@6?1???R6?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@$$V@std@@V6?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@XZ@@Z@QEAA@AEAV7012@0@Z@QEBA?A_PXZ@@Z
      49: 0f 10 00                     	movups	(%rax), %xmm0
      4c: 48 8b c3                     	movq	%rbx, %rax
      4f: 0f 11 03                     	movups	%xmm0, (%rbx)
      52: 48 83 c4 60                  	addq	$0x60, %rsp
      56: 5b                           	popq	%rbx
      57: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$_Apply_impl@V<lambda_1>@?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@AEAV89@$0A@@std@@YA?A_T$$QEAV<lambda_1>@?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@0@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@AEAV80@U?$integer_sequence@_K$0A@@0@@Z>:
       0: 4c 8b dc                     	movq	%rsp, %r11
       3: 53                           	pushq	%rbx
       4: 48 81 ec 80 00 00 00         	subq	$0x80, %rsp
       b: 48 8b 42 10                  	movq	0x10(%rdx), %rax
       f: 4d 8d 4b b8                  	leaq	-0x48(%r11), %r9
      13: 49 89 43 b8                  	movq	%rax, -0x48(%r11)
      17: 48 8b d9                     	movq	%rcx, %rbx
      1a: 48 8b 42 18                  	movq	0x18(%rdx), %rax
      1e: 49 8d 4b a8                  	leaq	-0x58(%r11), %rcx
      22: 49 89 43 c0                  	movq	%rax, -0x40(%r11)
      26: 48 8b 42 08                  	movq	0x8(%rdx), %rax
      2a: 48 8b 12                     	movq	(%rdx), %rdx
      2d: 4d 89 43 c8                  	movq	%r8, -0x38(%r11)
      31: 4d 89 43 98                  	movq	%r8, -0x68(%r11)
      35: 4d 8d 43 d8                  	leaq	-0x28(%r11), %r8
      39: 0f 10 00                     	movups	(%rax), %xmm0
      3c: f2 0f 10 48 10               	movsd	0x10(%rax), %xmm1
      41: 0f 29 44 24 60               	movaps	%xmm0, 0x60(%rsp)
      46: f2 0f 11 4c 24 70            	movsd	%xmm1, 0x70(%rsp)
      4c: e8 00 00 00 00               	callq	0x51 <??$_Apply_impl@V<lambda_1>@?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@AEAV89@$0A@@std@@YA?A_T$$QEAV<lambda_1>@?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@0@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@AEAV80@U?$integer_sequence@_K$0A@@0@@Z+0x51>
		000000000000004d:  IMAGE_REL_AMD64_REL32	??$invokePreparedScriptAbilityAsync@XV<lambda_1>@?1???$?RN@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PAEAN@Z@N@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@VPreparedLocalAsyncStart@012@$$QEAV<lambda_1>@?1???$?RN@6?1???R6?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@N@std@@V6?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@N@Z@@Z@QEAA@AEAV7012@0@Z@QEBA?A_PAEAN@Z@6@Z
      51: 0f 10 00                     	movups	(%rax), %xmm0
      54: 48 8b c3                     	movq	%rbx, %rax
      57: 0f 11 03                     	movups	%xmm0, (%rbx)
      5a: 48 81 c4 80 00 00 00         	addq	$0x80, %rsp
      61: 5b                           	popq	%rbx
      62: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <protected: void __cdecl std::time_get<char, class std::istreambuf_iterator<char, struct std::char_traits<char>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)>:
       0: 48 89 5c 24 10               	movq	%rbx, 0x10(%rsp)
       5: 48 89 6c 24 20               	movq	%rbp, 0x20(%rsp)
       a: 56                           	pushq	%rsi
       b: 57                           	pushq	%rdi
       c: 41 56                        	pushq	%r14
       e: 48 83 ec 60                  	subq	$0x60, %rsp
      12: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x19 <protected: void __cdecl std::time_get<char, class std::istreambuf_iterator<char, struct std::char_traits<char>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x19>
		0000000000000015:  IMAGE_REL_AMD64_REL32	__security_cookie
      19: 48 33 c4                     	xorq	%rsp, %rax
      1c: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
      21: 48 8b d9                     	movq	%rcx, %rbx
      24: 48 8d 54 24 20               	leaq	0x20(%rsp), %rdx
      29: 49 8b c8                     	movq	%r8, %rcx
      2c: 49 8b f0                     	movq	%r8, %rsi
      2f: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x35 <protected: void __cdecl std::time_get<char, class std::istreambuf_iterator<char, struct std::char_traits<char>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x35>
		0000000000000031:  IMAGE_REL_AMD64_REL32	__imp_?_Getcvt@_Locinfo@std@@QEBA?AU_Cvtvec@@XZ
      35: 48 8b ce                     	movq	%rsi, %rcx
      38: 0f 10 00                     	movups	(%rax), %xmm0
      3b: 0f 11 43 2c                  	movups	%xmm0, 0x2c(%rbx)
      3f: 0f 10 48 10                  	movups	0x10(%rax), %xmm1
      43: 0f 11 4b 3c                  	movups	%xmm1, 0x3c(%rbx)
      47: f2 0f 10 40 20               	movsd	0x20(%rax), %xmm0
      4c: f2 0f 11 43 4c               	movsd	%xmm0, 0x4c(%rbx)
      51: 8b 40 28                     	movl	0x28(%rax), %eax
      54: 89 43 54                     	movl	%eax, 0x54(%rbx)
      57: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x5d <protected: void __cdecl std::time_get<char, class std::istreambuf_iterator<char, struct std::char_traits<char>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x5d>
		0000000000000059:  IMAGE_REL_AMD64_REL32	__imp_?_W_Getdays@_Locinfo@std@@QEBAPEBGXZ
      5d: 48 8b c8                     	movq	%rax, %rcx
      60: 48 8b e8                     	movq	%rax, %rbp
      63: e8 00 00 00 00               	callq	0x68 <protected: void __cdecl std::time_get<char, class std::istreambuf_iterator<char, struct std::char_traits<char>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x68>
		0000000000000064:  IMAGE_REL_AMD64_REL32	wcslen
      68: ba 02 00 00 00               	movl	$0x2, %edx
      6d: 4c 8d 70 01                  	leaq	0x1(%rax), %r14
      71: 49 8b ce                     	movq	%r14, %rcx
      74: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x7a <protected: void __cdecl std::time_get<char, class std::istreambuf_iterator<char, struct std::char_traits<char>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x7a>
		0000000000000076:  IMAGE_REL_AMD64_REL32	__imp_calloc
      7a: 48 8b f8                     	movq	%rax, %rdi
      7d: 48 85 c0                     	testq	%rax, %rax
      80: 0f 84 b4 00 00 00            	je	0x13a <protected: void __cdecl std::time_get<char, class std::istreambuf_iterator<char, struct std::char_traits<char>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x13a>
      86: 4f 8d 04 36                  	leaq	(%r14,%r14), %r8
      8a: 48 8b d5                     	movq	%rbp, %rdx
      8d: 48 8b c8                     	movq	%rax, %rcx
      90: e8 00 00 00 00               	callq	0x95 <protected: void __cdecl std::time_get<char, class std::istreambuf_iterator<char, struct std::char_traits<char>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x95>
		0000000000000091:  IMAGE_REL_AMD64_REL32	memcpy
      95: 48 8b ce                     	movq	%rsi, %rcx
      98: 48 89 7b 10                  	movq	%rdi, 0x10(%rbx)
      9c: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xa2 <protected: void __cdecl std::time_get<char, class std::istreambuf_iterator<char, struct std::char_traits<char>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0xa2>
		000000000000009e:  IMAGE_REL_AMD64_REL32	__imp_?_W_Getmonths@_Locinfo@std@@QEBAPEBGXZ
      a2: 48 8b c8                     	movq	%rax, %rcx
      a5: 48 8b f0                     	movq	%rax, %rsi
      a8: e8 00 00 00 00               	callq	0xad <protected: void __cdecl std::time_get<char, class std::istreambuf_iterator<char, struct std::char_traits<char>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0xad>
		00000000000000a9:  IMAGE_REL_AMD64_REL32	wcslen
      ad: ba 02 00 00 00               	movl	$0x2, %edx
      b2: 4c 8d 70 01                  	leaq	0x1(%rax), %r14
      b6: 49 8b ce                     	movq	%r14, %rcx
      b9: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xbf <protected: void __cdecl std::time_get<char, class std::istreambuf_iterator<char, struct std::char_traits<char>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0xbf>
		00000000000000bb:  IMAGE_REL_AMD64_REL32	__imp_calloc
      bf: 48 8b f8                     	movq	%rax, %rdi
      c2: 48 85 c0                     	testq	%rax, %rax
      c5: 74 79                        	je	0x140 <protected: void __cdecl std::time_get<char, class std::istreambuf_iterator<char, struct std::char_traits<char>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x140>
      c7: 4f 8d 04 36                  	leaq	(%r14,%r14), %r8
      cb: 48 8b d6                     	movq	%rsi, %rdx
      ce: 48 8b c8                     	movq	%rax, %rcx
      d1: e8 00 00 00 00               	callq	0xd6 <protected: void __cdecl std::time_get<char, class std::istreambuf_iterator<char, struct std::char_traits<char>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0xd6>
		00000000000000d2:  IMAGE_REL_AMD64_REL32	memcpy
      d6: ba 02 00 00 00               	movl	$0x2, %edx
      db: 48 89 7b 18                  	movq	%rdi, 0x18(%rbx)
      df: b9 0d 00 00 00               	movl	$0xd, %ecx
      e4: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xea <protected: void __cdecl std::time_get<char, class std::istreambuf_iterator<char, struct std::char_traits<char>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0xea>
		00000000000000e6:  IMAGE_REL_AMD64_REL32	__imp_calloc
      ea: 48 8b c8                     	movq	%rax, %rcx
      ed: 48 85 c0                     	testq	%rax, %rax
      f0: 74 54                        	je	0x146 <protected: void __cdecl std::time_get<char, class std::istreambuf_iterator<char, struct std::char_traits<char>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x146>
      f2: 0f 10 05 00 00 00 00         	movups	(%rip), %xmm0           # 0xf9 <protected: void __cdecl std::time_get<char, class std::istreambuf_iterator<char, struct std::char_traits<char>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0xf9>
		00000000000000f5:  IMAGE_REL_AMD64_REL32	??_C@_1BK@MHIKGOKE@?$AA?3?$AAA?$AAM?$AA?3?$AAa?$AAm?$AA?3?$AAP?$AAM?$AA?3?$AAp?$AAm@
      f9: 0f 11 00                     	movups	%xmm0, (%rax)
      fc: f2 0f 10 05 10 00 00 00      	movsd	0x10(%rip), %xmm0       # 0x114 <protected: void __cdecl std::time_get<char, class std::istreambuf_iterator<char, struct std::char_traits<char>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x114>
		0000000000000100:  IMAGE_REL_AMD64_REL32	??_C@_1BK@MHIKGOKE@?$AA?3?$AAA?$AAM?$AA?3?$AAa?$AAm?$AA?3?$AAP?$AAM?$AA?3?$AAp?$AAm@
     104: f2 0f 11 40 10               	movsd	%xmm0, 0x10(%rax)
     109: 0f b7 05 18 00 00 00         	movzwl	0x18(%rip), %eax        # 0x128 <protected: void __cdecl std::time_get<char, class std::istreambuf_iterator<char, struct std::char_traits<char>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x128>
		000000000000010c:  IMAGE_REL_AMD64_REL32	??_C@_1BK@MHIKGOKE@?$AA?3?$AAA?$AAM?$AA?3?$AAa?$AAm?$AA?3?$AAP?$AAM?$AA?3?$AAp?$AAm@
     110: 66 89 41 18                  	movw	%ax, 0x18(%rcx)
     114: 48 89 4b 20                  	movq	%rcx, 0x20(%rbx)
     118: 48 8b 4c 24 50               	movq	0x50(%rsp), %rcx
     11d: 48 33 cc                     	xorq	%rsp, %rcx
     120: e8 00 00 00 00               	callq	0x125 <protected: void __cdecl std::time_get<char, class std::istreambuf_iterator<char, struct std::char_traits<char>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x125>
		0000000000000121:  IMAGE_REL_AMD64_REL32	__security_check_cookie
     125: 4c 8d 5c 24 60               	leaq	0x60(%rsp), %r11
     12a: 49 8b 5b 28                  	movq	0x28(%r11), %rbx
     12e: 49 8b 6b 38                  	movq	0x38(%r11), %rbp
     132: 49 8b e3                     	movq	%r11, %rsp
     135: 41 5e                        	popq	%r14
     137: 5f                           	popq	%rdi
     138: 5e                           	popq	%rsi
     139: c3                           	retq
     13a: e8 00 00 00 00               	callq	0x13f <protected: void __cdecl std::time_get<char, class std::istreambuf_iterator<char, struct std::char_traits<char>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x13f>
		000000000000013b:  IMAGE_REL_AMD64_REL32	?_Xbad_alloc@std@@YAXXZ
     13f: cc                           	int3
     140: e8 00 00 00 00               	callq	0x145 <protected: void __cdecl std::time_get<char, class std::istreambuf_iterator<char, struct std::char_traits<char>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x145>
		0000000000000141:  IMAGE_REL_AMD64_REL32	?_Xbad_alloc@std@@YAXXZ
     145: cc                           	int3
     146: e8 00 00 00 00               	callq	0x14b <protected: void __cdecl std::time_get<char, class std::istreambuf_iterator<char, struct std::char_traits<char>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x14b>
		0000000000000147:  IMAGE_REL_AMD64_REL32	?_Xbad_alloc@std@@YAXXZ
     14b: cc                           	int3

Disassembly of section .text$mn:

0000000000000000 <protected: void __cdecl std::time_get<wchar_t, class std::istreambuf_iterator<wchar_t, struct std::char_traits<wchar_t>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)>:
       0: 48 89 5c 24 10               	movq	%rbx, 0x10(%rsp)
       5: 48 89 6c 24 20               	movq	%rbp, 0x20(%rsp)
       a: 56                           	pushq	%rsi
       b: 57                           	pushq	%rdi
       c: 41 56                        	pushq	%r14
       e: 48 83 ec 60                  	subq	$0x60, %rsp
      12: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x19 <protected: void __cdecl std::time_get<wchar_t, class std::istreambuf_iterator<wchar_t, struct std::char_traits<wchar_t>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x19>
		0000000000000015:  IMAGE_REL_AMD64_REL32	__security_cookie
      19: 48 33 c4                     	xorq	%rsp, %rax
      1c: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
      21: 48 8b d9                     	movq	%rcx, %rbx
      24: 48 8d 54 24 20               	leaq	0x20(%rsp), %rdx
      29: 49 8b c8                     	movq	%r8, %rcx
      2c: 49 8b f0                     	movq	%r8, %rsi
      2f: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x35 <protected: void __cdecl std::time_get<wchar_t, class std::istreambuf_iterator<wchar_t, struct std::char_traits<wchar_t>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x35>
		0000000000000031:  IMAGE_REL_AMD64_REL32	__imp_?_Getcvt@_Locinfo@std@@QEBA?AU_Cvtvec@@XZ
      35: 48 8b ce                     	movq	%rsi, %rcx
      38: 0f 10 00                     	movups	(%rax), %xmm0
      3b: 0f 11 43 2c                  	movups	%xmm0, 0x2c(%rbx)
      3f: 0f 10 48 10                  	movups	0x10(%rax), %xmm1
      43: 0f 11 4b 3c                  	movups	%xmm1, 0x3c(%rbx)
      47: f2 0f 10 40 20               	movsd	0x20(%rax), %xmm0
      4c: f2 0f 11 43 4c               	movsd	%xmm0, 0x4c(%rbx)
      51: 8b 40 28                     	movl	0x28(%rax), %eax
      54: 89 43 54                     	movl	%eax, 0x54(%rbx)
      57: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x5d <protected: void __cdecl std::time_get<wchar_t, class std::istreambuf_iterator<wchar_t, struct std::char_traits<wchar_t>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x5d>
		0000000000000059:  IMAGE_REL_AMD64_REL32	__imp_?_W_Getdays@_Locinfo@std@@QEBAPEBGXZ
      5d: 48 8b c8                     	movq	%rax, %rcx
      60: 48 8b e8                     	movq	%rax, %rbp
      63: e8 00 00 00 00               	callq	0x68 <protected: void __cdecl std::time_get<wchar_t, class std::istreambuf_iterator<wchar_t, struct std::char_traits<wchar_t>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x68>
		0000000000000064:  IMAGE_REL_AMD64_REL32	wcslen
      68: ba 02 00 00 00               	movl	$0x2, %edx
      6d: 4c 8d 70 01                  	leaq	0x1(%rax), %r14
      71: 49 8b ce                     	movq	%r14, %rcx
      74: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x7a <protected: void __cdecl std::time_get<wchar_t, class std::istreambuf_iterator<wchar_t, struct std::char_traits<wchar_t>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x7a>
		0000000000000076:  IMAGE_REL_AMD64_REL32	__imp_calloc
      7a: 48 8b f8                     	movq	%rax, %rdi
      7d: 48 85 c0                     	testq	%rax, %rax
      80: 0f 84 b4 00 00 00            	je	0x13a <protected: void __cdecl std::time_get<wchar_t, class std::istreambuf_iterator<wchar_t, struct std::char_traits<wchar_t>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x13a>
      86: 4f 8d 04 36                  	leaq	(%r14,%r14), %r8
      8a: 48 8b d5                     	movq	%rbp, %rdx
      8d: 48 8b c8                     	movq	%rax, %rcx
      90: e8 00 00 00 00               	callq	0x95 <protected: void __cdecl std::time_get<wchar_t, class std::istreambuf_iterator<wchar_t, struct std::char_traits<wchar_t>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x95>
		0000000000000091:  IMAGE_REL_AMD64_REL32	memcpy
      95: 48 8b ce                     	movq	%rsi, %rcx
      98: 48 89 7b 10                  	movq	%rdi, 0x10(%rbx)
      9c: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xa2 <protected: void __cdecl std::time_get<wchar_t, class std::istreambuf_iterator<wchar_t, struct std::char_traits<wchar_t>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0xa2>
		000000000000009e:  IMAGE_REL_AMD64_REL32	__imp_?_W_Getmonths@_Locinfo@std@@QEBAPEBGXZ
      a2: 48 8b c8                     	movq	%rax, %rcx
      a5: 48 8b f0                     	movq	%rax, %rsi
      a8: e8 00 00 00 00               	callq	0xad <protected: void __cdecl std::time_get<wchar_t, class std::istreambuf_iterator<wchar_t, struct std::char_traits<wchar_t>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0xad>
		00000000000000a9:  IMAGE_REL_AMD64_REL32	wcslen
      ad: ba 02 00 00 00               	movl	$0x2, %edx
      b2: 4c 8d 70 01                  	leaq	0x1(%rax), %r14
      b6: 49 8b ce                     	movq	%r14, %rcx
      b9: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xbf <protected: void __cdecl std::time_get<wchar_t, class std::istreambuf_iterator<wchar_t, struct std::char_traits<wchar_t>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0xbf>
		00000000000000bb:  IMAGE_REL_AMD64_REL32	__imp_calloc
      bf: 48 8b f8                     	movq	%rax, %rdi
      c2: 48 85 c0                     	testq	%rax, %rax
      c5: 74 79                        	je	0x140 <protected: void __cdecl std::time_get<wchar_t, class std::istreambuf_iterator<wchar_t, struct std::char_traits<wchar_t>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x140>
      c7: 4f 8d 04 36                  	leaq	(%r14,%r14), %r8
      cb: 48 8b d6                     	movq	%rsi, %rdx
      ce: 48 8b c8                     	movq	%rax, %rcx
      d1: e8 00 00 00 00               	callq	0xd6 <protected: void __cdecl std::time_get<wchar_t, class std::istreambuf_iterator<wchar_t, struct std::char_traits<wchar_t>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0xd6>
		00000000000000d2:  IMAGE_REL_AMD64_REL32	memcpy
      d6: ba 02 00 00 00               	movl	$0x2, %edx
      db: 48 89 7b 18                  	movq	%rdi, 0x18(%rbx)
      df: b9 0d 00 00 00               	movl	$0xd, %ecx
      e4: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xea <protected: void __cdecl std::time_get<wchar_t, class std::istreambuf_iterator<wchar_t, struct std::char_traits<wchar_t>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0xea>
		00000000000000e6:  IMAGE_REL_AMD64_REL32	__imp_calloc
      ea: 48 8b c8                     	movq	%rax, %rcx
      ed: 48 85 c0                     	testq	%rax, %rax
      f0: 74 54                        	je	0x146 <protected: void __cdecl std::time_get<wchar_t, class std::istreambuf_iterator<wchar_t, struct std::char_traits<wchar_t>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x146>
      f2: 0f 10 05 00 00 00 00         	movups	(%rip), %xmm0           # 0xf9 <protected: void __cdecl std::time_get<wchar_t, class std::istreambuf_iterator<wchar_t, struct std::char_traits<wchar_t>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0xf9>
		00000000000000f5:  IMAGE_REL_AMD64_REL32	??_C@_1BK@MHIKGOKE@?$AA?3?$AAA?$AAM?$AA?3?$AAa?$AAm?$AA?3?$AAP?$AAM?$AA?3?$AAp?$AAm@
      f9: 0f 11 00                     	movups	%xmm0, (%rax)
      fc: f2 0f 10 05 10 00 00 00      	movsd	0x10(%rip), %xmm0       # 0x114 <protected: void __cdecl std::time_get<wchar_t, class std::istreambuf_iterator<wchar_t, struct std::char_traits<wchar_t>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x114>
		0000000000000100:  IMAGE_REL_AMD64_REL32	??_C@_1BK@MHIKGOKE@?$AA?3?$AAA?$AAM?$AA?3?$AAa?$AAm?$AA?3?$AAP?$AAM?$AA?3?$AAp?$AAm@
     104: f2 0f 11 40 10               	movsd	%xmm0, 0x10(%rax)
     109: 0f b7 05 18 00 00 00         	movzwl	0x18(%rip), %eax        # 0x128 <protected: void __cdecl std::time_get<wchar_t, class std::istreambuf_iterator<wchar_t, struct std::char_traits<wchar_t>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x128>
		000000000000010c:  IMAGE_REL_AMD64_REL32	??_C@_1BK@MHIKGOKE@?$AA?3?$AAA?$AAM?$AA?3?$AAa?$AAm?$AA?3?$AAP?$AAM?$AA?3?$AAp?$AAm@
     110: 66 89 41 18                  	movw	%ax, 0x18(%rcx)
     114: 48 89 4b 20                  	movq	%rcx, 0x20(%rbx)
     118: 48 8b 4c 24 50               	movq	0x50(%rsp), %rcx
     11d: 48 33 cc                     	xorq	%rsp, %rcx
     120: e8 00 00 00 00               	callq	0x125 <protected: void __cdecl std::time_get<wchar_t, class std::istreambuf_iterator<wchar_t, struct std::char_traits<wchar_t>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x125>
		0000000000000121:  IMAGE_REL_AMD64_REL32	__security_check_cookie
     125: 4c 8d 5c 24 60               	leaq	0x60(%rsp), %r11
     12a: 49 8b 5b 28                  	movq	0x28(%r11), %rbx
     12e: 49 8b 6b 38                  	movq	0x38(%r11), %rbp
     132: 49 8b e3                     	movq	%r11, %rsp
     135: 41 5e                        	popq	%r14
     137: 5f                           	popq	%rdi
     138: 5e                           	popq	%rsi
     139: c3                           	retq
     13a: e8 00 00 00 00               	callq	0x13f <protected: void __cdecl std::time_get<wchar_t, class std::istreambuf_iterator<wchar_t, struct std::char_traits<wchar_t>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x13f>
		000000000000013b:  IMAGE_REL_AMD64_REL32	?_Xbad_alloc@std@@YAXXZ
     13f: cc                           	int3
     140: e8 00 00 00 00               	callq	0x145 <protected: void __cdecl std::time_get<wchar_t, class std::istreambuf_iterator<wchar_t, struct std::char_traits<wchar_t>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x145>
		0000000000000141:  IMAGE_REL_AMD64_REL32	?_Xbad_alloc@std@@YAXXZ
     145: cc                           	int3
     146: e8 00 00 00 00               	callq	0x14b <protected: void __cdecl std::time_get<wchar_t, class std::istreambuf_iterator<wchar_t, struct std::char_traits<wchar_t>>>::_Getvals<wchar_t>(wchar_t, class std::_Locinfo const &)+0x14b>
		0000000000000147:  IMAGE_REL_AMD64_REL32	?_Xbad_alloc@std@@YAXXZ
     14b: cc                           	int3

Disassembly of section .text$mn:

0000000000000000 <protected: void __cdecl std::_Ptr_base<void>::_Move_construct_from<void>(class std::_Ptr_base<void> &&)>:
       0: 48 8b 02                     	movq	(%rdx), %rax
       3: 48 89 01                     	movq	%rax, (%rcx)
       6: 48 8b 42 08                  	movq	0x8(%rdx), %rax
       a: 48 89 41 08                  	movq	%rax, 0x8(%rcx)
       e: 33 c0                        	xorl	%eax, %eax
      10: 48 89 02                     	movq	%rax, (%rdx)
      13: 48 89 42 08                  	movq	%rax, 0x8(%rdx)
      17: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <int const * __cdecl std::addressof<int const>(int const &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <struct lux::simulation::script::test::ValuePose const * __cdecl std::addressof<struct lux::simulation::script::test::ValuePose const>(struct lux::simulation::script::test::ValuePose const &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <int * __cdecl std::addressof<int>(int &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <double * __cdecl std::addressof<double>(double &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <struct lux::simulation::script::ScriptAwaitableRegistration * __cdecl std::addressof<struct lux::simulation::script::ScriptAwaitableRegistration>(struct lux::simulation::script::ScriptAwaitableRegistration &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <struct lux::simulation::script::ScriptCoroutine::promise_type * __cdecl std::addressof<struct lux::simulation::script::ScriptCoroutine::promise_type>(struct lux::simulation::script::ScriptCoroutine::promise_type &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <class lux::simulation::script::ScriptCoroutineContext * __cdecl std::addressof<class lux::simulation::script::ScriptCoroutineContext>(class lux::simulation::script::ScriptCoroutineContext &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$apply@V<lambda_1>@?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@AEAV89@@std@@YA?A_T$$QEAV<lambda_1>@?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@0@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@AEAV80@@Z>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 60                  	subq	$0x60, %rsp
       6: 48 8b 42 10                  	movq	0x10(%rdx), %rax
       a: 4c 8d 4c 24 20               	leaq	0x20(%rsp), %r9
       f: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
      14: 4c 8d 44 24 40               	leaq	0x40(%rsp), %r8
      19: 48 8b 42 18                  	movq	0x18(%rdx), %rax
      1d: 48 8b d9                     	movq	%rcx, %rbx
      20: 48 89 44 24 28               	movq	%rax, 0x28(%rsp)
      25: 48 8d 4c 24 30               	leaq	0x30(%rsp), %rcx
      2a: 48 8b 42 08                  	movq	0x8(%rdx), %rax
      2e: 48 8b 12                     	movq	(%rdx), %rdx
      31: 0f 10 00                     	movups	(%rax), %xmm0
      34: f2 0f 10 48 10               	movsd	0x10(%rax), %xmm1
      39: 0f 29 44 24 40               	movaps	%xmm0, 0x40(%rsp)
      3e: f2 0f 11 4c 24 50            	movsd	%xmm1, 0x50(%rsp)
      44: e8 00 00 00 00               	callq	0x49 <??$apply@V<lambda_1>@?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@AEAV89@@std@@YA?A_T$$QEAV<lambda_1>@?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@0@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@AEAV80@@Z+0x49>
		0000000000000045:  IMAGE_REL_AMD64_REL32	??$invokePreparedScriptAbilityAsync@XV<lambda_1>@?1???$?R$$V@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PXZ@$$V@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@VPreparedLocalAsyncStart@012@$$QEAV<lambda_1>@?1???$?R$$V@6?1???R6?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@$$V@std@@V6?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@XZ@@Z@QEAA@AEAV7012@0@Z@QEBA?A_PXZ@@Z
      49: 0f 10 00                     	movups	(%rax), %xmm0
      4c: 48 8b c3                     	movq	%rbx, %rax
      4f: 0f 11 03                     	movups	%xmm0, (%rbx)
      52: 48 83 c4 60                  	addq	$0x60, %rsp
      56: 5b                           	popq	%rbx
      57: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$apply@V<lambda_1>@?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@AEAV89@@std@@YA?A_T$$QEAV<lambda_1>@?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@0@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@AEAV80@@Z>:
       0: 4c 8b dc                     	movq	%rsp, %r11
       3: 53                           	pushq	%rbx
       4: 48 81 ec 80 00 00 00         	subq	$0x80, %rsp
       b: 48 8b 42 10                  	movq	0x10(%rdx), %rax
       f: 4d 8d 4b b8                  	leaq	-0x48(%r11), %r9
      13: 49 89 43 b8                  	movq	%rax, -0x48(%r11)
      17: 48 8b d9                     	movq	%rcx, %rbx
      1a: 48 8b 42 18                  	movq	0x18(%rdx), %rax
      1e: 49 8d 4b a8                  	leaq	-0x58(%r11), %rcx
      22: 49 89 43 c0                  	movq	%rax, -0x40(%r11)
      26: 48 8b 42 08                  	movq	0x8(%rdx), %rax
      2a: 48 8b 12                     	movq	(%rdx), %rdx
      2d: 4d 89 43 c8                  	movq	%r8, -0x38(%r11)
      31: 4d 89 43 98                  	movq	%r8, -0x68(%r11)
      35: 4d 8d 43 d8                  	leaq	-0x28(%r11), %r8
      39: 0f 10 00                     	movups	(%rax), %xmm0
      3c: f2 0f 10 48 10               	movsd	0x10(%rax), %xmm1
      41: 0f 29 44 24 60               	movaps	%xmm0, 0x60(%rsp)
      46: f2 0f 11 4c 24 70            	movsd	%xmm1, 0x70(%rsp)
      4c: e8 00 00 00 00               	callq	0x51 <??$apply@V<lambda_1>@?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@AEAV89@@std@@YA?A_T$$QEAV<lambda_1>@?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@0@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@AEAV80@@Z+0x51>
		000000000000004d:  IMAGE_REL_AMD64_REL32	??$invokePreparedScriptAbilityAsync@XV<lambda_1>@?1???$?RN@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PAEAN@Z@N@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@VPreparedLocalAsyncStart@012@$$QEAV<lambda_1>@?1???$?RN@6?1???R6?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@N@std@@V6?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@N@Z@@Z@QEAA@AEAV7012@0@Z@QEBA?A_PAEAN@Z@6@Z
      51: 0f 10 00                     	movups	(%rax), %xmm0
      54: 48 8b c3                     	movq	%rbx, %rax
      57: 0f 11 03                     	movups	%xmm0, (%rbx)
      5a: 48 81 c4 80 00 00 00         	addq	$0x80, %rsp
      61: 5b                           	popq	%rbx
      62: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@3@V?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@13@QEBA@XZ@@Z>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 40                  	subq	$0x40, %rsp
       6: 44 89 44 24 20               	movl	%r8d, 0x20(%rsp)
       b: 48 8b da                     	movq	%rdx, %rbx
       e: 4c 8d 44 24 20               	leaq	0x20(%rsp), %r8
      13: 4c 89 4c 24 28               	movq	%r9, 0x28(%rsp)
      18: e8 00 00 00 00               	callq	0x1d <??$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@3@V?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@13@QEBA@XZ@@Z+0x1d>
		0000000000000019:  IMAGE_REL_AMD64_REL32	??$makeAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@0123@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@3@V?$tuple@$$V@std@@V4?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@13@QEBA@XZ@@Z@@Z
      1d: 48 8b c3                     	movq	%rbx, %rax
      20: 48 83 c4 40                  	addq	$0x40, %rsp
      24: 5b                           	popq	%rbx
      25: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@3@V?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@13@QEBA@N@Z@@Z>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 40                  	subq	$0x40, %rsp
       6: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
       b: 48 8b da                     	movq	%rdx, %rbx
       e: 44 89 44 24 20               	movl	%r8d, 0x20(%rsp)
      13: 4c 8d 44 24 20               	leaq	0x20(%rsp), %r8
      18: 4c 89 4c 24 28               	movq	%r9, 0x28(%rsp)
      1d: f2 0f 10 00                  	movsd	(%rax), %xmm0
      21: f2 0f 11 44 24 30            	movsd	%xmm0, 0x30(%rsp)
      27: e8 00 00 00 00               	callq	0x2c <??$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@3@V?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@13@QEBA@N@Z@@Z+0x2c>
		0000000000000028:  IMAGE_REL_AMD64_REL32	??$makeAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@0123@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@3@V?$tuple@N@std@@V4?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@13@QEBA@N@Z@@Z@@Z
      2c: 48 8b c3                     	movq	%rbx, %rax
      2f: 48 83 c4 40                  	addq	$0x40, %rsp
      33: 5b                           	popq	%rbx
      34: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::pose(class lux::simulation::script::ScriptCoroutineContext &, struct lux::simulation::script::test::ValuePose const &)>::call<0>(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *, struct std::integer_sequence<unsigned __int64, 0>)>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 6c 24 10               	movq	%rbp, 0x10(%rsp)
       a: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
       f: 48 89 7c 24 20               	movq	%rdi, 0x20(%rsp)
      14: 41 56                        	pushq	%r14
      16: 48 83 ec 20                  	subq	$0x20, %rsp
      1a: 4d 8b f0                     	movq	%r8, %r14
      1d: 48 8b ea                     	movq	%rdx, %rbp
      20: 48 8b d9                     	movq	%rcx, %rbx
      23: 48 85 d2                     	testq	%rdx, %rdx
      26: 0f 84 ed 00 00 00            	je	0x119 <$$__resumable_init_label$115+0x60>
      2c: 41 83 79 18 00               	cmpl	$0x0, 0x18(%r9)
      31: 0f 85 e2 00 00 00            	jne	0x119 <$$__resumable_init_label$115+0x60>
      37: 48 8b 74 24 50               	movq	0x50(%rsp), %rsi
      3c: 48 85 f6                     	testq	%rsi, %rsi
      3f: 0f 84 d4 00 00 00            	je	0x119 <$$__resumable_init_label$115+0x60>
      45: 41 8b 49 08                  	movl	0x8(%r9), %ecx
      49: 85 c9                        	testl	%ecx, %ecx
      4b: 74 0a                        	je	0x57 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::pose(class lux::simulation::script::ScriptCoroutineContext &, struct lux::simulation::script::test::ValuePose const &)>::call<0>(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *, struct std::integer_sequence<unsigned __int64, 0>)+0x57>
      4d: 49 83 39 00                  	cmpq	$0x0, (%r9)
      51: 75 04                        	jne	0x57 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::pose(class lux::simulation::script::ScriptCoroutineContext &, struct lux::simulation::script::test::ValuePose const &)>::call<0>(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *, struct std::integer_sequence<unsigned __int64, 0>)+0x57>
      53: b0 01                        	movb	$0x1, %al
      55: eb 02                        	jmp	0x59 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::pose(class lux::simulation::script::ScriptCoroutineContext &, struct lux::simulation::script::test::ValuePose const &)>::call<0>(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *, struct std::integer_sequence<unsigned __int64, 0>)+0x59>
      57: 32 c0                        	xorb	%al, %al
      59: 83 f9 01                     	cmpl	$0x1, %ecx
      5c: 0f 85 b7 00 00 00            	jne	0x119 <$$__resumable_init_label$115+0x60>
      62: 84 c0                        	testb	%al, %al
      64: 0f 85 af 00 00 00            	jne	0x119 <$$__resumable_init_label$115+0x60>
      6a: 49 8b 39                     	movq	(%r9), %rdi
      6d: 48 8b cf                     	movq	%rdi, %rcx
      70: e8 00 00 00 00               	callq	0x75 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::pose(class lux::simulation::script::ScriptCoroutineContext &, struct lux::simulation::script::test::ValuePose const &)>::call<0>(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *, struct std::integer_sequence<unsigned __int64, 0>)+0x75>
		0000000000000071:  IMAGE_REL_AMD64_REL32	??$cppStaticSlotMatches@AEBUValuePose@test@script@simulation@lux@@@detail@script@simulation@lux@@YA_NAEBUlux_script_value_slot@@@Z
      75: 84 c0                        	testb	%al, %al
      77: 0f 84 9c 00 00 00            	je	0x119 <$$__resumable_init_label$115+0x60>
      7d: 48 8b 47 10                  	movq	0x10(%rdi), %rax
      81: 0f 10 00                     	movups	(%rax), %xmm0
      84: 0f 11 06                     	movups	%xmm0, (%rsi)
      87: 0f 10 48 10                  	movups	0x10(%rax), %xmm1
      8b: 0f 11 4e 10                  	movups	%xmm1, 0x10(%rsi)
      8f: ba 30 01 00 00               	movl	$0x130, %edx            # imm = 0x130
      94: 41 b8 08 00 00 00            	movl	$0x8, %r8d
      9a: 49 8b ce                     	movq	%r14, %rcx
      9d: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xa3 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::pose(class lux::simulation::script::ScriptCoroutineContext &, struct lux::simulation::script::test::ValuePose const &)>::call<0>(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *, struct std::integer_sequence<unsigned __int64, 0>)+0xa3>
		000000000000009f:  IMAGE_REL_AMD64_REL32	__imp_?allocateFrame@ScriptCoroutineContext@script@simulation@lux@@AEAAPEAX_K0@Z
      a3: 48 8b f8                     	movq	%rax, %rdi
      a6: 48 8b cb                     	movq	%rbx, %rcx
      a9: 48 85 c0                     	testq	%rax, %rax
      ac: 75 0b                        	jne	0xb9 <$$__resumable_init_label$115>
      ae: 48 89 03                     	movq	%rax, (%rbx)
      b1: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xb7 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::pose(class lux::simulation::script::ScriptCoroutineContext &, struct lux::simulation::script::test::ValuePose const &)>::call<0>(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *, struct std::integer_sequence<unsigned __int64, 0>)+0xb7>
		00000000000000b3:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
      b7: eb 5e                        	jmp	0x117 <$$__resumable_init_label$115+0x5e>

00000000000000b9 <$$__resumable_init_label$115>:
      b9: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0xc0 <$$__resumable_init_label$115+0x7>
		00000000000000bc:  IMAGE_REL_AMD64_REL32	?pose$_DestroyCoro$2@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@AEBUValuePose@test@745@@Z
      c0: 48 89 47 08                  	movq	%rax, 0x8(%rdi)
      c4: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0xcb <$$__resumable_init_label$115+0x12>
		00000000000000c7:  IMAGE_REL_AMD64_REL32	?pose$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@AEBUValuePose@test@745@@Z
      cb: 48 89 07                     	movq	%rax, (%rdi)
      ce: 48 89 6f 40                  	movq	%rbp, 0x40(%rdi)
      d2: 4c 89 77 48                  	movq	%r14, 0x48(%rdi)
      d6: 48 89 77 50                  	movq	%rsi, 0x50(%rdi)
      da: c7 47 58 02 00 01 00         	movl	$0x10002, 0x58(%rdi)    # imm = 0x10002
      e1: 33 c0                        	xorl	%eax, %eax
      e3: 66 89 47 11                  	movw	%ax, 0x11(%rdi)
      e7: 88 47 13                     	movb	%al, 0x13(%rdi)
      ea: 88 47 10                     	movb	%al, 0x10(%rdi)
      ed: 48 89 47 14                  	movq	%rax, 0x14(%rdi)
      f1: 89 47 1c                     	movl	%eax, 0x1c(%rdi)
      f4: 48 89 47 20                  	movq	%rax, 0x20(%rdi)
      f8: 48 89 47 28                  	movq	%rax, 0x28(%rdi)
      fc: 48 89 47 30                  	movq	%rax, 0x30(%rdi)
     100: 48 8b d7                     	movq	%rdi, %rdx
     103: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x109 <$$__resumable_init_label$115+0x50>
		0000000000000105:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@AEAA@U?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
     109: 33 c0                        	xorl	%eax, %eax
     10b: 88 47 38                     	movb	%al, 0x38(%rdi)
     10e: 48 8b cf                     	movq	%rdi, %rcx
     111: e8 00 00 00 00               	callq	0x116 <$$__resumable_init_label$115+0x5d>
		0000000000000112:  IMAGE_REL_AMD64_REL32	?pose$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@AEBUValuePose@test@745@@Z
     116: 90                           	nop
     117: eb 0e                        	jmp	0x127 <$$__resumable_init_label$115+0x6e>
     119: 33 c0                        	xorl	%eax, %eax
     11b: 48 89 03                     	movq	%rax, (%rbx)
     11e: 48 8b cb                     	movq	%rbx, %rcx
     121: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x127 <$$__resumable_init_label$115+0x6e>
		0000000000000123:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
     127: 48 8b c3                     	movq	%rbx, %rax
     12a: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
     12f: 48 8b 6c 24 38               	movq	0x38(%rsp), %rbp
     134: 48 8b 74 24 40               	movq	0x40(%rsp), %rsi
     139: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
     13e: 48 83 c4 20                  	addq	$0x20, %rsp
     142: 41 5e                        	popq	%r14
     144: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::event(class lux::simulation::script::ScriptCoroutineContext &)>::call<>(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *, struct std::integer_sequence<unsigned __int64>)>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 6c 24 10               	movq	%rbp, 0x10(%rsp)
       a: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
       f: 57                           	pushq	%rdi
      10: 48 83 ec 20                  	subq	$0x20, %rsp
      14: 49 8b e8                     	movq	%r8, %rbp
      17: 48 8b f2                     	movq	%rdx, %rsi
      1a: 48 8b d9                     	movq	%rcx, %rbx
      1d: 48 85 d2                     	testq	%rdx, %rdx
      20: 0f 84 ab 00 00 00            	je	0xd1 <$$__resumable_init_label$105+0x5c>
      26: 41 83 79 18 00               	cmpl	$0x0, 0x18(%r9)
      2b: 0f 85 a0 00 00 00            	jne	0xd1 <$$__resumable_init_label$105+0x5c>
      31: 41 8b 41 08                  	movl	0x8(%r9), %eax
      35: 85 c0                        	testl	%eax, %eax
      37: 74 12                        	je	0x4b <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::event(class lux::simulation::script::ScriptCoroutineContext &)>::call<>(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *, struct std::integer_sequence<unsigned __int64>)+0x4b>
      39: 49 83 39 00                  	cmpq	$0x0, (%r9)
      3d: 0f 84 8e 00 00 00            	je	0xd1 <$$__resumable_init_label$105+0x5c>
      43: 85 c0                        	testl	%eax, %eax
      45: 0f 85 86 00 00 00            	jne	0xd1 <$$__resumable_init_label$105+0x5c>
      4b: ba e0 00 00 00               	movl	$0xe0, %edx
      50: 41 b8 08 00 00 00            	movl	$0x8, %r8d
      56: 48 8b cd                     	movq	%rbp, %rcx
      59: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x5f <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::event(class lux::simulation::script::ScriptCoroutineContext &)>::call<>(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *, struct std::integer_sequence<unsigned __int64>)+0x5f>
		000000000000005b:  IMAGE_REL_AMD64_REL32	__imp_?allocateFrame@ScriptCoroutineContext@script@simulation@lux@@AEAAPEAX_K0@Z
      5f: 48 8b f8                     	movq	%rax, %rdi
      62: 48 8b cb                     	movq	%rbx, %rcx
      65: 48 85 c0                     	testq	%rax, %rax
      68: 75 0b                        	jne	0x75 <$$__resumable_init_label$105>
      6a: 48 89 03                     	movq	%rax, (%rbx)
      6d: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x73 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::event(class lux::simulation::script::ScriptCoroutineContext &)>::call<>(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *, struct std::integer_sequence<unsigned __int64>)+0x73>
		000000000000006f:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
      73: eb 5a                        	jmp	0xcf <$$__resumable_init_label$105+0x5a>

0000000000000075 <$$__resumable_init_label$105>:
      75: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x7c <$$__resumable_init_label$105+0x7>
		0000000000000078:  IMAGE_REL_AMD64_REL32	?event$_DestroyCoro$2@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      7c: 48 89 47 08                  	movq	%rax, 0x8(%rdi)
      80: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x87 <$$__resumable_init_label$105+0x12>
		0000000000000083:  IMAGE_REL_AMD64_REL32	?event$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      87: 48 89 07                     	movq	%rax, (%rdi)
      8a: 48 89 77 40                  	movq	%rsi, 0x40(%rdi)
      8e: 48 89 6f 48                  	movq	%rbp, 0x48(%rdi)
      92: c7 47 50 02 00 01 00         	movl	$0x10002, 0x50(%rdi)    # imm = 0x10002
      99: 33 c0                        	xorl	%eax, %eax
      9b: 66 89 47 11                  	movw	%ax, 0x11(%rdi)
      9f: 88 47 13                     	movb	%al, 0x13(%rdi)
      a2: 88 47 10                     	movb	%al, 0x10(%rdi)
      a5: 48 89 47 14                  	movq	%rax, 0x14(%rdi)
      a9: 89 47 1c                     	movl	%eax, 0x1c(%rdi)
      ac: 48 89 47 20                  	movq	%rax, 0x20(%rdi)
      b0: 48 89 47 28                  	movq	%rax, 0x28(%rdi)
      b4: 48 89 47 30                  	movq	%rax, 0x30(%rdi)
      b8: 48 8b d7                     	movq	%rdi, %rdx
      bb: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xc1 <$$__resumable_init_label$105+0x4c>
		00000000000000bd:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@AEAA@U?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
      c1: 33 c0                        	xorl	%eax, %eax
      c3: 88 47 38                     	movb	%al, 0x38(%rdi)
      c6: 48 8b cf                     	movq	%rdi, %rcx
      c9: e8 00 00 00 00               	callq	0xce <$$__resumable_init_label$105+0x59>
		00000000000000ca:  IMAGE_REL_AMD64_REL32	?event$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      ce: 90                           	nop
      cf: eb 0b                        	jmp	0xdc <$$__resumable_init_label$105+0x67>
      d1: 33 c0                        	xorl	%eax, %eax
      d3: 48 89 01                     	movq	%rax, (%rcx)
      d6: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xdc <$$__resumable_init_label$105+0x67>
		00000000000000d8:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
      dc: 48 8b c3                     	movq	%rbx, %rax
      df: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
      e4: 48 8b 6c 24 38               	movq	0x38(%rsp), %rbp
      e9: 48 8b 74 24 40               	movq	0x40(%rsp), %rsi
      ee: 48 83 c4 20                  	addq	$0x20, %rsp
      f2: 5f                           	popq	%rdi
      f3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::longTask(class lux::simulation::script::ScriptCoroutineContext &)>::call<>(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *, struct std::integer_sequence<unsigned __int64>)>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 6c 24 10               	movq	%rbp, 0x10(%rsp)
       a: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
       f: 57                           	pushq	%rdi
      10: 48 83 ec 20                  	subq	$0x20, %rsp
      14: 49 8b e8                     	movq	%r8, %rbp
      17: 48 8b f2                     	movq	%rdx, %rsi
      1a: 48 8b d9                     	movq	%rcx, %rbx
      1d: 48 85 d2                     	testq	%rdx, %rdx
      20: 0f 84 ab 00 00 00            	je	0xd1 <$$__resumable_init_label$108+0x5c>
      26: 41 83 79 18 00               	cmpl	$0x0, 0x18(%r9)
      2b: 0f 85 a0 00 00 00            	jne	0xd1 <$$__resumable_init_label$108+0x5c>
      31: 41 8b 41 08                  	movl	0x8(%r9), %eax
      35: 85 c0                        	testl	%eax, %eax
      37: 74 12                        	je	0x4b <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::longTask(class lux::simulation::script::ScriptCoroutineContext &)>::call<>(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *, struct std::integer_sequence<unsigned __int64>)+0x4b>
      39: 49 83 39 00                  	cmpq	$0x0, (%r9)
      3d: 0f 84 8e 00 00 00            	je	0xd1 <$$__resumable_init_label$108+0x5c>
      43: 85 c0                        	testl	%eax, %eax
      45: 0f 85 86 00 00 00            	jne	0xd1 <$$__resumable_init_label$108+0x5c>
      4b: ba e0 00 00 00               	movl	$0xe0, %edx
      50: 41 b8 08 00 00 00            	movl	$0x8, %r8d
      56: 48 8b cd                     	movq	%rbp, %rcx
      59: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x5f <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::longTask(class lux::simulation::script::ScriptCoroutineContext &)>::call<>(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *, struct std::integer_sequence<unsigned __int64>)+0x5f>
		000000000000005b:  IMAGE_REL_AMD64_REL32	__imp_?allocateFrame@ScriptCoroutineContext@script@simulation@lux@@AEAAPEAX_K0@Z
      5f: 48 8b f8                     	movq	%rax, %rdi
      62: 48 8b cb                     	movq	%rbx, %rcx
      65: 48 85 c0                     	testq	%rax, %rax
      68: 75 0b                        	jne	0x75 <$$__resumable_init_label$108>
      6a: 48 89 03                     	movq	%rax, (%rbx)
      6d: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x73 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::longTask(class lux::simulation::script::ScriptCoroutineContext &)>::call<>(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *, struct std::integer_sequence<unsigned __int64>)+0x73>
		000000000000006f:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
      73: eb 5a                        	jmp	0xcf <$$__resumable_init_label$108+0x5a>

0000000000000075 <$$__resumable_init_label$108>:
      75: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x7c <$$__resumable_init_label$108+0x7>
		0000000000000078:  IMAGE_REL_AMD64_REL32	?longTask$_DestroyCoro$2@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      7c: 48 89 47 08                  	movq	%rax, 0x8(%rdi)
      80: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x87 <$$__resumable_init_label$108+0x12>
		0000000000000083:  IMAGE_REL_AMD64_REL32	?longTask$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      87: 48 89 07                     	movq	%rax, (%rdi)
      8a: 48 89 77 40                  	movq	%rsi, 0x40(%rdi)
      8e: 48 89 6f 48                  	movq	%rbp, 0x48(%rdi)
      92: c7 47 50 02 00 01 00         	movl	$0x10002, 0x50(%rdi)    # imm = 0x10002
      99: 33 c0                        	xorl	%eax, %eax
      9b: 66 89 47 11                  	movw	%ax, 0x11(%rdi)
      9f: 88 47 13                     	movb	%al, 0x13(%rdi)
      a2: 88 47 10                     	movb	%al, 0x10(%rdi)
      a5: 48 89 47 14                  	movq	%rax, 0x14(%rdi)
      a9: 89 47 1c                     	movl	%eax, 0x1c(%rdi)
      ac: 48 89 47 20                  	movq	%rax, 0x20(%rdi)
      b0: 48 89 47 28                  	movq	%rax, 0x28(%rdi)
      b4: 48 89 47 30                  	movq	%rax, 0x30(%rdi)
      b8: 48 8b d7                     	movq	%rdi, %rdx
      bb: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xc1 <$$__resumable_init_label$108+0x4c>
		00000000000000bd:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@AEAA@U?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
      c1: 33 c0                        	xorl	%eax, %eax
      c3: 88 47 38                     	movb	%al, 0x38(%rdi)
      c6: 48 8b cf                     	movq	%rdi, %rcx
      c9: e8 00 00 00 00               	callq	0xce <$$__resumable_init_label$108+0x59>
		00000000000000ca:  IMAGE_REL_AMD64_REL32	?longTask$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      ce: 90                           	nop
      cf: eb 0b                        	jmp	0xdc <$$__resumable_init_label$108+0x67>
      d1: 33 c0                        	xorl	%eax, %eax
      d3: 48 89 01                     	movq	%rax, (%rcx)
      d6: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xdc <$$__resumable_init_label$108+0x67>
		00000000000000d8:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
      dc: 48 8b c3                     	movq	%rbx, %rax
      df: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
      e4: 48 8b 6c 24 38               	movq	0x38(%rsp), %rbp
      e9: 48 8b 74 24 40               	movq	0x40(%rsp), %rsi
      ee: 48 83 c4 20                  	addq	$0x20, %rsp
      f2: 5f                           	popq	%rdi
      f3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::next(class lux::simulation::script::ScriptCoroutineContext &)>::call<>(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *, struct std::integer_sequence<unsigned __int64>)>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 6c 24 10               	movq	%rbp, 0x10(%rsp)
       a: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
       f: 57                           	pushq	%rdi
      10: 48 83 ec 20                  	subq	$0x20, %rsp
      14: 49 8b e8                     	movq	%r8, %rbp
      17: 48 8b f2                     	movq	%rdx, %rsi
      1a: 48 8b d9                     	movq	%rcx, %rbx
      1d: 48 85 d2                     	testq	%rdx, %rdx
      20: 0f 84 ab 00 00 00            	je	0xd1 <$$__resumable_init_label$108+0x5c>
      26: 41 83 79 18 00               	cmpl	$0x0, 0x18(%r9)
      2b: 0f 85 a0 00 00 00            	jne	0xd1 <$$__resumable_init_label$108+0x5c>
      31: 41 8b 41 08                  	movl	0x8(%r9), %eax
      35: 85 c0                        	testl	%eax, %eax
      37: 74 12                        	je	0x4b <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::next(class lux::simulation::script::ScriptCoroutineContext &)>::call<>(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *, struct std::integer_sequence<unsigned __int64>)+0x4b>
      39: 49 83 39 00                  	cmpq	$0x0, (%r9)
      3d: 0f 84 8e 00 00 00            	je	0xd1 <$$__resumable_init_label$108+0x5c>
      43: 85 c0                        	testl	%eax, %eax
      45: 0f 85 86 00 00 00            	jne	0xd1 <$$__resumable_init_label$108+0x5c>
      4b: ba 20 01 00 00               	movl	$0x120, %edx            # imm = 0x120
      50: 41 b8 08 00 00 00            	movl	$0x8, %r8d
      56: 48 8b cd                     	movq	%rbp, %rcx
      59: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x5f <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::next(class lux::simulation::script::ScriptCoroutineContext &)>::call<>(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *, struct std::integer_sequence<unsigned __int64>)+0x5f>
		000000000000005b:  IMAGE_REL_AMD64_REL32	__imp_?allocateFrame@ScriptCoroutineContext@script@simulation@lux@@AEAAPEAX_K0@Z
      5f: 48 8b f8                     	movq	%rax, %rdi
      62: 48 8b cb                     	movq	%rbx, %rcx
      65: 48 85 c0                     	testq	%rax, %rax
      68: 75 0b                        	jne	0x75 <$$__resumable_init_label$108>
      6a: 48 89 03                     	movq	%rax, (%rbx)
      6d: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x73 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::next(class lux::simulation::script::ScriptCoroutineContext &)>::call<>(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *, struct std::integer_sequence<unsigned __int64>)+0x73>
		000000000000006f:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
      73: eb 5a                        	jmp	0xcf <$$__resumable_init_label$108+0x5a>

0000000000000075 <$$__resumable_init_label$108>:
      75: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x7c <$$__resumable_init_label$108+0x7>
		0000000000000078:  IMAGE_REL_AMD64_REL32	?next$_DestroyCoro$2@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      7c: 48 89 47 08                  	movq	%rax, 0x8(%rdi)
      80: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x87 <$$__resumable_init_label$108+0x12>
		0000000000000083:  IMAGE_REL_AMD64_REL32	?next$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      87: 48 89 07                     	movq	%rax, (%rdi)
      8a: 48 89 77 40                  	movq	%rsi, 0x40(%rdi)
      8e: 48 89 6f 48                  	movq	%rbp, 0x48(%rdi)
      92: c7 47 50 02 00 01 00         	movl	$0x10002, 0x50(%rdi)    # imm = 0x10002
      99: 33 c0                        	xorl	%eax, %eax
      9b: 66 89 47 11                  	movw	%ax, 0x11(%rdi)
      9f: 88 47 13                     	movb	%al, 0x13(%rdi)
      a2: 88 47 10                     	movb	%al, 0x10(%rdi)
      a5: 48 89 47 14                  	movq	%rax, 0x14(%rdi)
      a9: 89 47 1c                     	movl	%eax, 0x1c(%rdi)
      ac: 48 89 47 20                  	movq	%rax, 0x20(%rdi)
      b0: 48 89 47 28                  	movq	%rax, 0x28(%rdi)
      b4: 48 89 47 30                  	movq	%rax, 0x30(%rdi)
      b8: 48 8b d7                     	movq	%rdi, %rdx
      bb: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xc1 <$$__resumable_init_label$108+0x4c>
		00000000000000bd:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@AEAA@U?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
      c1: 33 c0                        	xorl	%eax, %eax
      c3: 88 47 38                     	movb	%al, 0x38(%rdi)
      c6: 48 8b cf                     	movq	%rdi, %rcx
      c9: e8 00 00 00 00               	callq	0xce <$$__resumable_init_label$108+0x59>
		00000000000000ca:  IMAGE_REL_AMD64_REL32	?next$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      ce: 90                           	nop
      cf: eb 0b                        	jmp	0xdc <$$__resumable_init_label$108+0x67>
      d1: 33 c0                        	xorl	%eax, %eax
      d3: 48 89 01                     	movq	%rax, (%rcx)
      d6: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xdc <$$__resumable_init_label$108+0x67>
		00000000000000d8:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
      dc: 48 8b c3                     	movq	%rbx, %rax
      df: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
      e4: 48 8b 6c 24 38               	movq	0x38(%rsp), %rbp
      e9: 48 8b 74 24 40               	movq	0x40(%rsp), %rsi
      ee: 48 83 c4 20                  	addq	$0x20, %rsp
      f2: 5f                           	popq	%rdi
      f3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::sequence(class lux::simulation::script::ScriptCoroutineContext &)>::call<>(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *, struct std::integer_sequence<unsigned __int64>)>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 6c 24 10               	movq	%rbp, 0x10(%rsp)
       a: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
       f: 57                           	pushq	%rdi
      10: 48 83 ec 20                  	subq	$0x20, %rsp
      14: 49 8b e8                     	movq	%r8, %rbp
      17: 48 8b f2                     	movq	%rdx, %rsi
      1a: 48 8b d9                     	movq	%rcx, %rbx
      1d: 48 85 d2                     	testq	%rdx, %rdx
      20: 0f 84 ab 00 00 00            	je	0xd1 <$$__resumable_init_label$112+0x5c>
      26: 41 83 79 18 00               	cmpl	$0x0, 0x18(%r9)
      2b: 0f 85 a0 00 00 00            	jne	0xd1 <$$__resumable_init_label$112+0x5c>
      31: 41 8b 41 08                  	movl	0x8(%r9), %eax
      35: 85 c0                        	testl	%eax, %eax
      37: 74 12                        	je	0x4b <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::sequence(class lux::simulation::script::ScriptCoroutineContext &)>::call<>(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *, struct std::integer_sequence<unsigned __int64>)+0x4b>
      39: 49 83 39 00                  	cmpq	$0x0, (%r9)
      3d: 0f 84 8e 00 00 00            	je	0xd1 <$$__resumable_init_label$112+0x5c>
      43: 85 c0                        	testl	%eax, %eax
      45: 0f 85 86 00 00 00            	jne	0xd1 <$$__resumable_init_label$112+0x5c>
      4b: ba a0 01 00 00               	movl	$0x1a0, %edx            # imm = 0x1A0
      50: 41 b8 08 00 00 00            	movl	$0x8, %r8d
      56: 48 8b cd                     	movq	%rbp, %rcx
      59: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x5f <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::sequence(class lux::simulation::script::ScriptCoroutineContext &)>::call<>(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *, struct std::integer_sequence<unsigned __int64>)+0x5f>
		000000000000005b:  IMAGE_REL_AMD64_REL32	__imp_?allocateFrame@ScriptCoroutineContext@script@simulation@lux@@AEAAPEAX_K0@Z
      5f: 48 8b f8                     	movq	%rax, %rdi
      62: 48 8b cb                     	movq	%rbx, %rcx
      65: 48 85 c0                     	testq	%rax, %rax
      68: 75 0b                        	jne	0x75 <$$__resumable_init_label$112>
      6a: 48 89 03                     	movq	%rax, (%rbx)
      6d: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x73 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::detail::CppStaticCoroutineEntry<&public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::sequence(class lux::simulation::script::ScriptCoroutineContext &)>::call<>(void *, class lux::simulation::script::ScriptCoroutineContext &, struct lux_script_call_frame const &, void *, struct std::integer_sequence<unsigned __int64>)+0x73>
		000000000000006f:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
      73: eb 5a                        	jmp	0xcf <$$__resumable_init_label$112+0x5a>

0000000000000075 <$$__resumable_init_label$112>:
      75: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x7c <$$__resumable_init_label$112+0x7>
		0000000000000078:  IMAGE_REL_AMD64_REL32	?sequence$_DestroyCoro$2@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      7c: 48 89 47 08                  	movq	%rax, 0x8(%rdi)
      80: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x87 <$$__resumable_init_label$112+0x12>
		0000000000000083:  IMAGE_REL_AMD64_REL32	?sequence$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      87: 48 89 07                     	movq	%rax, (%rdi)
      8a: 48 89 77 40                  	movq	%rsi, 0x40(%rdi)
      8e: 48 89 6f 48                  	movq	%rbp, 0x48(%rdi)
      92: c7 47 50 02 00 01 00         	movl	$0x10002, 0x50(%rdi)    # imm = 0x10002
      99: 33 c0                        	xorl	%eax, %eax
      9b: 66 89 47 11                  	movw	%ax, 0x11(%rdi)
      9f: 88 47 13                     	movb	%al, 0x13(%rdi)
      a2: 88 47 10                     	movb	%al, 0x10(%rdi)
      a5: 48 89 47 14                  	movq	%rax, 0x14(%rdi)
      a9: 89 47 1c                     	movl	%eax, 0x1c(%rdi)
      ac: 48 89 47 20                  	movq	%rax, 0x20(%rdi)
      b0: 48 89 47 28                  	movq	%rax, 0x28(%rdi)
      b4: 48 89 47 30                  	movq	%rax, 0x30(%rdi)
      b8: 48 8b d7                     	movq	%rdi, %rdx
      bb: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xc1 <$$__resumable_init_label$112+0x4c>
		00000000000000bd:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@AEAA@U?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
      c1: 33 c0                        	xorl	%eax, %eax
      c3: 88 47 38                     	movb	%al, 0x38(%rdi)
      c6: 48 8b cf                     	movq	%rdi, %rcx
      c9: e8 00 00 00 00               	callq	0xce <$$__resumable_init_label$112+0x59>
		00000000000000ca:  IMAGE_REL_AMD64_REL32	?sequence$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      ce: 90                           	nop
      cf: eb 0b                        	jmp	0xdc <$$__resumable_init_label$112+0x67>
      d1: 33 c0                        	xorl	%eax, %eax
      d3: 48 89 01                     	movq	%rax, (%rcx)
      d6: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xdc <$$__resumable_init_label$112+0x67>
		00000000000000d8:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
      dc: 48 8b c3                     	movq	%rbx, %rax
      df: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
      e4: 48 8b 6c 24 38               	movq	0x38(%rsp), %rbp
      e9: 48 8b 74 24 40               	movq	0x40(%rsp), %rsi
      ee: 48 83 c4 20                  	addq	$0x20, %rsp
      f2: 5f                           	popq	%rdi
      f3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$callStep@$$A6AXAEBUValuePose@test@script@simulation@lux@@@ZAEBU12345@@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PIAEBUValuePose@test@123@@Z>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 30                  	subq	$0x30, %rsp
       6: 4c 89 4c 24 48               	movq	%r9, 0x48(%rsp)
       b: 48 8d 44 24 48               	leaq	0x48(%rsp), %rax
      10: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0x17 <??$callStep@$$A6AXAEBUValuePose@test@script@simulation@lux@@@ZAEBU12345@@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PIAEBUValuePose@test@123@@Z+0x17>
		0000000000000013:  IMAGE_REL_AMD64_REL32	?Shape@?$ScriptSyncStepCall@$$A6AXAEBUValuePose@test@script@simulation@lux@@@Z@detail@script@simulation@lux@@2UScriptSyncStepShape@345@B
      17: 48 c7 44 24 28 00 00 00 00   	movq	$0x0, 0x28(%rsp)
      20: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
      25: 48 8b da                     	movq	%rdx, %rbx
      28: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x2e <??$callStep@$$A6AXAEBUValuePose@test@script@simulation@lux@@@ZAEBU12345@@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PIAEBUValuePose@test@123@@Z+0x2e>
		000000000000002a:  IMAGE_REL_AMD64_REL32	__imp_?invokeSyncStep@ScriptCoroutineContext@script@simulation@lux@@AEAA?AV?$expected@XUScriptSyncStepError@script@simulation@lux@@@tl@@IAEBUScriptSyncStepShape@234@PEBQEBXPEAX@Z
      2e: 48 8b c3                     	movq	%rbx, %rax
      31: 48 83 c4 30                  	addq	$0x30, %rsp
      35: 5b                           	popq	%rbx
      36: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$callStep@$$A6AXAEBUValuePose@test@script@simulation@lux@@H@ZAEBU12345@AEBH@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PIAEBUValuePose@test@123@AEBH@Z>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 40                  	subq	$0x40, %rsp
       6: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
       b: 48 8b da                     	movq	%rdx, %rbx
       e: 48 89 44 24 38               	movq	%rax, 0x38(%rsp)
      13: 48 8d 44 24 30               	leaq	0x30(%rsp), %rax
      18: 4c 89 4c 24 30               	movq	%r9, 0x30(%rsp)
      1d: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0x24 <??$callStep@$$A6AXAEBUValuePose@test@script@simulation@lux@@H@ZAEBU12345@AEBH@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PIAEBUValuePose@test@123@AEBH@Z+0x24>
		0000000000000020:  IMAGE_REL_AMD64_REL32	?Shape@?$ScriptSyncStepCall@$$A6AXAEBUValuePose@test@script@simulation@lux@@H@Z@detail@script@simulation@lux@@2UScriptSyncStepShape@345@B
      24: 48 c7 44 24 28 00 00 00 00   	movq	$0x0, 0x28(%rsp)
      2d: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
      32: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x38 <??$callStep@$$A6AXAEBUValuePose@test@script@simulation@lux@@H@ZAEBU12345@AEBH@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PIAEBUValuePose@test@123@AEBH@Z+0x38>
		0000000000000034:  IMAGE_REL_AMD64_REL32	__imp_?invokeSyncStep@ScriptCoroutineContext@script@simulation@lux@@AEAA?AV?$expected@XUScriptSyncStepError@script@simulation@lux@@@tl@@IAEBUScriptSyncStepShape@234@PEBQEBXPEAX@Z
      38: 48 8b c3                     	movq	%rbx, %rax
      3b: 48 83 c4 40                  	addq	$0x40, %rsp
      3f: 5b                           	popq	%rbx
      40: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$callStep@$$A6AXH@ZAEBH@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PIAEBH@Z>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 30                  	subq	$0x30, %rsp
       6: 4c 89 4c 24 48               	movq	%r9, 0x48(%rsp)
       b: 48 8d 44 24 48               	leaq	0x48(%rsp), %rax
      10: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0x17 <??$callStep@$$A6AXH@ZAEBH@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PIAEBH@Z+0x17>
		0000000000000013:  IMAGE_REL_AMD64_REL32	?Shape@?$ScriptSyncStepCall@$$A6AXH@Z@detail@script@simulation@lux@@2UScriptSyncStepShape@345@B
      17: 48 c7 44 24 28 00 00 00 00   	movq	$0x0, 0x28(%rsp)
      20: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
      25: 48 8b da                     	movq	%rdx, %rbx
      28: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x2e <??$callStep@$$A6AXH@ZAEBH@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PIAEBH@Z+0x2e>
		000000000000002a:  IMAGE_REL_AMD64_REL32	__imp_?invokeSyncStep@ScriptCoroutineContext@script@simulation@lux@@AEAA?AV?$expected@XUScriptSyncStepError@script@simulation@lux@@@tl@@IAEBUScriptSyncStepShape@234@PEBQEBXPEAX@Z
      2e: 48 8b c3                     	movq	%rbx, %rax
      31: 48 83 c4 30                  	addq	$0x30, %rsp
      35: 5b                           	popq	%rbx
      36: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$callStep@$$A6AXXZ$$V@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PI@Z>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 30                  	subq	$0x30, %rsp
       6: 33 c0                        	xorl	%eax, %eax
       8: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0xf <??$callStep@$$A6AXXZ$$V@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PI@Z+0xf>
		000000000000000b:  IMAGE_REL_AMD64_REL32	?Shape@?$ScriptSyncStepCall@$$A6AXXZ@detail@script@simulation@lux@@2UScriptSyncStepShape@345@B
       f: 48 89 44 24 28               	movq	%rax, 0x28(%rsp)
      14: 48 8b da                     	movq	%rdx, %rbx
      17: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
      1c: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x22 <??$callStep@$$A6AXXZ$$V@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PI@Z+0x22>
		000000000000001e:  IMAGE_REL_AMD64_REL32	__imp_?invokeSyncStep@ScriptCoroutineContext@script@simulation@lux@@AEAA?AV?$expected@XUScriptSyncStepError@script@simulation@lux@@@tl@@IAEBUScriptSyncStepShape@234@PEBQEBXPEAX@Z
      22: 48 8b c3                     	movq	%rbx, %rax
      25: 48 83 c4 30                  	addq	$0x30, %rsp
      29: 5b                           	popq	%rbx
      2a: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <struct lux::simulation::na1::cost::Tasks * __cdecl std::construct_at<struct lux::simulation::na1::cost::Tasks>(struct lux::simulation::na1::cost::Tasks *const)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <bool __cdecl lux::simulation::script::detail::cppStaticSlotMatches<struct lux::simulation::script::test::ValuePose const &>(struct lux_script_value_slot const &)>:
       0: 48 83 ec 38                  	subq	$0x38, %rsp
       4: 48 8b 41 10                  	movq	0x10(%rcx), %rax
       8: 48 ba df 9e 75 48 50 8d ca 66	movabsq	$0x66ca8d5048759edf, %rdx # imm = 0x66CA8D5048759EDF
      12: 41 b8 08 00 00 00            	movl	$0x8, %r8d
      18: 48 85 c0                     	testq	%rax, %rax
      1b: 74 25                        	je	0x42 <bool __cdecl lux::simulation::script::detail::cppStaticSlotMatches<struct lux::simulation::script::test::ValuePose const &>(struct lux_script_value_slot const &)+0x42>
      1d: 48 39 51 08                  	cmpq	%rdx, 0x8(%rcx)
      21: 75 1f                        	jne	0x42 <bool __cdecl lux::simulation::script::detail::cppStaticSlotMatches<struct lux::simulation::script::test::ValuePose const &>(struct lux_script_value_slot const &)+0x42>
      23: 80 39 0a                     	cmpb	$0xa, (%rcx)
      26: 75 1a                        	jne	0x42 <bool __cdecl lux::simulation::script::detail::cppStaticSlotMatches<struct lux::simulation::script::test::ValuePose const &>(struct lux_script_value_slot const &)+0x42>
      28: 83 79 04 20                  	cmpl	$0x20, 0x4(%rcx)
      2c: 75 14                        	jne	0x42 <bool __cdecl lux::simulation::script::detail::cppStaticSlotMatches<struct lux::simulation::script::test::ValuePose const &>(struct lux_script_value_slot const &)+0x42>
      2e: 33 d2                        	xorl	%edx, %edx
      30: 41 8b c8                     	movl	%r8d, %ecx
      33: 48 f7 f1                     	divq	%rcx
      36: 48 85 d2                     	testq	%rdx, %rdx
      39: 75 07                        	jne	0x42 <bool __cdecl lux::simulation::script::detail::cppStaticSlotMatches<struct lux::simulation::script::test::ValuePose const &>(struct lux_script_value_slot const &)+0x42>
      3b: b0 01                        	movb	$0x1, %al
      3d: 48 83 c4 38                  	addq	$0x38, %rsp
      41: c3                           	retq
      42: 32 c0                        	xorb	%al, %al
      44: 48 83 c4 38                  	addq	$0x38, %rsp
      48: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <void __cdecl std::destroy_at<struct lux::simulation::na1::cost::Tasks>(struct lux::simulation::na1::cost::Tasks *const)>:
       0: c2 00 00                     	retq	$0x0

Disassembly of section .text$mn:

0000000000000000 <class std::tuple<> & __cdecl std::forward<class std::tuple<> &>(class std::tuple<> &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <class std::tuple<double> & __cdecl std::forward<class std::tuple<double> &>(class std::tuple<double> &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <int const & __cdecl std::forward<int const &>(int const &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <struct lux::simulation::script::test::ValuePose const & __cdecl std::forward<struct lux::simulation::script::test::ValuePose const &>(struct lux::simulation::script::test::ValuePose const &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <double && __cdecl std::forward<double>(double &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$forward@V<lambda_1>@?1???$?R$$V@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PXZ@@std@@YA$$QEAV<lambda_1>@?1???$?R$$V@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@0@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PXZ@AEAV1?1???$?R$$V@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@2345@AEAA?A_PI012@Z@QEAA@34@Z@QEBA?A_PXZ@@Z>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$forward@V<lambda_1>@?1???$?RN@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PAEAN@Z@@std@@YA$$QEAV<lambda_1>@?1???$?RN@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@0@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PAEAN@Z@AEAV1?1???$?RN@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@2345@AEAA?A_PI012@Z@QEAA@34@Z@QEBA?A_P5@Z@@Z>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$forward@V<lambda_1>@?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@@std@@YA$$QEAV<lambda_1>@?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@0@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@AEAV1?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@2345@AEAA?A_PI012@Z@QEAA@34@Z@@Z>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$forward@V<lambda_1>@?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@@std@@YA$$QEAV<lambda_1>@?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@0@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@AEAV1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@2345@AEAA?A_PI012@Z@QEAA@34@Z@@Z>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <enum lux::simulation::script::EScriptAwaitableCreateError && __cdecl std::forward<enum lux::simulation::script::EScriptAwaitableCreateError>(enum lux::simulation::script::EScriptAwaitableCreateError &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <enum lux::simulation::script::EScriptEventWaitError && __cdecl std::forward<enum lux::simulation::script::EScriptEventWaitError>(enum lux::simulation::script::EScriptEventWaitError &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <double & __cdecl std::get<0, double>(class std::tuple<double> &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$invoke@V<lambda_1>@?1???$?R$$V@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PXZ@V?$ScriptAbilityCompletion@X@35@$$V@std@@YA?AV?$expected@XUScriptAbilityOperationError@script@lux@@@tl@@$$QEAV<lambda_1>@?1???$?R$$V@3?1???R3?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@7@V?$tuple@$$V@0@V3?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@57@QEBA@XZ@@Z@QEAA@AEAV4567@AEAUScriptStepContext@567@@Z@QEBA?A_PXZ@$$QEAV?$ScriptAbilityCompletion@X@57@@Z>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 6c 24 10               	movq	%rbp, 0x10(%rsp)
       a: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
       f: 57                           	pushq	%rdi
      10: 41 54                        	pushq	%r12
      12: 41 55                        	pushq	%r13
      14: 41 56                        	pushq	%r14
      16: 41 57                        	pushq	%r15
      18: 48 81 ec 80 00 00 00         	subq	$0x80, %rsp
      1f: 4d 8b f0                     	movq	%r8, %r14
      22: 4c 8b e9                     	movq	%rcx, %r13
      25: 4d 8b 20                     	movq	(%r8), %r12
      28: 4d 8b 78 08                  	movq	0x8(%r8), %r15
      2c: 33 c0                        	xorl	%eax, %eax
      2e: 49 89 00                     	movq	%rax, (%r8)
      31: 49 89 40 08                  	movq	%rax, 0x8(%r8)
      35: 4d 8b 48 10                  	movq	0x10(%r8), %r9
      39: 4d 8b 50 18                  	movq	0x18(%r8), %r10
      3d: 4d 8b 58 20                  	movq	0x20(%r8), %r11
      41: 49 8b 58 28                  	movq	0x28(%r8), %rbx
      45: 49 8b 78 30                  	movq	0x30(%r8), %rdi
      49: 4d 8b 40 38                  	movq	0x38(%r8), %r8
      4d: 49 8b 76 40                  	movq	0x40(%r14), %rsi
      51: 49 8b 6e 48                  	movq	0x48(%r14), %rbp
      55: 4d 8b 76 50                  	movq	0x50(%r14), %r14
      59: 48 8b 42 08                  	movq	0x8(%rdx), %rax
      5d: 48 8b 48 08                  	movq	0x8(%rax), %rcx
      61: 48 8b 10                     	movq	(%rax), %rdx
      64: 4c 89 64 24 20               	movq	%r12, 0x20(%rsp)
      69: 4c 89 7c 24 28               	movq	%r15, 0x28(%rsp)
      6e: 4c 89 4c 24 30               	movq	%r9, 0x30(%rsp)
      73: 4c 89 54 24 38               	movq	%r10, 0x38(%rsp)
      78: 4c 89 5c 24 40               	movq	%r11, 0x40(%rsp)
      7d: 48 89 5c 24 48               	movq	%rbx, 0x48(%rsp)
      82: 48 89 7c 24 50               	movq	%rdi, 0x50(%rsp)
      87: 4c 89 44 24 58               	movq	%r8, 0x58(%rsp)
      8c: 48 89 74 24 60               	movq	%rsi, 0x60(%rsp)
      91: 48 89 6c 24 68               	movq	%rbp, 0x68(%rsp)
      96: 4c 89 74 24 70               	movq	%r14, 0x70(%rsp)
      9b: 48 8b 01                     	movq	(%rcx), %rax
      9e: 4c 8d 44 24 20               	leaq	0x20(%rsp), %r8
      a3: 49 8b cd                     	movq	%r13, %rcx
      a6: ff d0                        	callq	*%rax
      a8: 90                           	nop
      a9: 49 8b c5                     	movq	%r13, %rax
      ac: 4c 8d 9c 24 80 00 00 00      	leaq	0x80(%rsp), %r11
      b4: 49 8b 5b 30                  	movq	0x30(%r11), %rbx
      b8: 49 8b 6b 38                  	movq	0x38(%r11), %rbp
      bc: 49 8b 73 40                  	movq	0x40(%r11), %rsi
      c0: 49 8b e3                     	movq	%r11, %rsp
      c3: 41 5f                        	popq	%r15
      c5: 41 5e                        	popq	%r14
      c7: 41 5d                        	popq	%r13
      c9: 41 5c                        	popq	%r12
      cb: 5f                           	popq	%rdi
      cc: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$invoke@V<lambda_1>@?1???$?RN@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PAEAN@Z@V?$ScriptAbilityCompletion@X@35@$$V@std@@YA?AV?$expected@XUScriptAbilityOperationError@script@lux@@@tl@@$$QEAV<lambda_1>@?1???$?RN@3?1???R3?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@7@V?$tuple@N@0@V3?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@57@QEBA@N@Z@@Z@QEAA@AEAV4567@AEAUScriptStepContext@567@@Z@QEBA?A_PAEAN@Z@$$QEAV?$ScriptAbilityCompletion@X@57@@Z>:
       0: 48 89 5c 24 10               	movq	%rbx, 0x10(%rsp)
       5: 48 89 6c 24 18               	movq	%rbp, 0x18(%rsp)
       a: 48 89 74 24 20               	movq	%rsi, 0x20(%rsp)
       f: 48 89 4c 24 08               	movq	%rcx, 0x8(%rsp)
      14: 57                           	pushq	%rdi
      15: 41 54                        	pushq	%r12
      17: 41 55                        	pushq	%r13
      19: 41 56                        	pushq	%r14
      1b: 41 57                        	pushq	%r15
      1d: 48 81 ec 80 00 00 00         	subq	$0x80, %rsp
      24: 4d 8b 28                     	movq	(%r8), %r13
      27: 4d 8b 60 08                  	movq	0x8(%r8), %r12
      2b: 33 c0                        	xorl	%eax, %eax
      2d: 49 89 00                     	movq	%rax, (%r8)
      30: 49 89 40 08                  	movq	%rax, 0x8(%r8)
      34: 4d 8b 48 10                  	movq	0x10(%r8), %r9
      38: 4d 8b 50 18                  	movq	0x18(%r8), %r10
      3c: 4d 8b 58 20                  	movq	0x20(%r8), %r11
      40: 49 8b 58 28                  	movq	0x28(%r8), %rbx
      44: 49 8b 78 30                  	movq	0x30(%r8), %rdi
      48: 49 8b 70 38                  	movq	0x38(%r8), %rsi
      4c: 49 8b 68 40                  	movq	0x40(%r8), %rbp
      50: 4d 8b 70 48                  	movq	0x48(%r8), %r14
      54: 4d 8b 40 50                  	movq	0x50(%r8), %r8
      58: 4c 8b 7a 10                  	movq	0x10(%rdx), %r15
      5c: 48 8b 42 08                  	movq	0x8(%rdx), %rax
      60: 48 8b 48 08                  	movq	0x8(%rax), %rcx
      64: 48 8b 10                     	movq	(%rax), %rdx
      67: 4c 89 6c 24 20               	movq	%r13, 0x20(%rsp)
      6c: 4c 89 64 24 28               	movq	%r12, 0x28(%rsp)
      71: 4c 89 4c 24 30               	movq	%r9, 0x30(%rsp)
      76: 4c 89 54 24 38               	movq	%r10, 0x38(%rsp)
      7b: 4c 89 5c 24 40               	movq	%r11, 0x40(%rsp)
      80: 48 89 5c 24 48               	movq	%rbx, 0x48(%rsp)
      85: 48 89 7c 24 50               	movq	%rdi, 0x50(%rsp)
      8a: 48 89 74 24 58               	movq	%rsi, 0x58(%rsp)
      8f: 48 89 6c 24 60               	movq	%rbp, 0x60(%rsp)
      94: 4c 89 74 24 68               	movq	%r14, 0x68(%rsp)
      99: 4c 89 44 24 70               	movq	%r8, 0x70(%rsp)
      9e: 48 8b 41 10                  	movq	0x10(%rcx), %rax
      a2: 4c 8d 4c 24 20               	leaq	0x20(%rsp), %r9
      a7: f2 41 0f 10 17               	movsd	(%r15), %xmm2
      ac: 48 8b 8c 24 b0 00 00 00      	movq	0xb0(%rsp), %rcx
      b4: ff d0                        	callq	*%rax
      b6: 90                           	nop
      b7: 48 8b 84 24 b0 00 00 00      	movq	0xb0(%rsp), %rax
      bf: 4c 8d 9c 24 80 00 00 00      	leaq	0x80(%rsp), %r11
      c7: 49 8b 5b 38                  	movq	0x38(%r11), %rbx
      cb: 49 8b 6b 40                  	movq	0x40(%r11), %rbp
      cf: 49 8b 73 48                  	movq	0x48(%r11), %rsi
      d3: 49 8b e3                     	movq	%r11, %rsp
      d6: 41 5f                        	popq	%r15
      d8: 41 5e                        	popq	%r14
      da: 41 5d                        	popq	%r13
      dc: 41 5c                        	popq	%r12
      de: 5f                           	popq	%rdi
      df: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$invoke@V<lambda_1>@?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@@std@@YA?AUScriptStepResult@script@simulation@lux@@$$QEAV<lambda_1>@?1???R5?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@234@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@$$V@0@V5?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@XZ@@Z@QEAA@AEAV6234@AEAUScriptStepContext@234@@Z@@Z>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 60                  	subq	$0x60, %rsp
       6: 48 8b 42 10                  	movq	0x10(%rdx), %rax
       a: 4c 8d 4c 24 20               	leaq	0x20(%rsp), %r9
       f: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
      14: 4c 8d 44 24 40               	leaq	0x40(%rsp), %r8
      19: 48 8b 42 18                  	movq	0x18(%rdx), %rax
      1d: 48 8b d9                     	movq	%rcx, %rbx
      20: 48 89 44 24 28               	movq	%rax, 0x28(%rsp)
      25: 48 8d 4c 24 30               	leaq	0x30(%rsp), %rcx
      2a: 48 8b 42 08                  	movq	0x8(%rdx), %rax
      2e: 48 8b 12                     	movq	(%rdx), %rdx
      31: 0f 10 00                     	movups	(%rax), %xmm0
      34: f2 0f 10 48 10               	movsd	0x10(%rax), %xmm1
      39: 0f 29 44 24 40               	movaps	%xmm0, 0x40(%rsp)
      3e: f2 0f 11 4c 24 50            	movsd	%xmm1, 0x50(%rsp)
      44: e8 00 00 00 00               	callq	0x49 <??$invoke@V<lambda_1>@?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@@std@@YA?AUScriptStepResult@script@simulation@lux@@$$QEAV<lambda_1>@?1???R5?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@234@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@$$V@0@V5?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@XZ@@Z@QEAA@AEAV6234@AEAUScriptStepContext@234@@Z@@Z+0x49>
		0000000000000045:  IMAGE_REL_AMD64_REL32	??$invokePreparedScriptAbilityAsync@XV<lambda_1>@?1???$?R$$V@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PXZ@$$V@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@VPreparedLocalAsyncStart@012@$$QEAV<lambda_1>@?1???$?R$$V@6?1???R6?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@$$V@std@@V6?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@XZ@@Z@QEAA@AEAV7012@0@Z@QEBA?A_PXZ@@Z
      49: 0f 10 00                     	movups	(%rax), %xmm0
      4c: 48 8b c3                     	movq	%rbx, %rax
      4f: 0f 11 03                     	movups	%xmm0, (%rbx)
      52: 48 83 c4 60                  	addq	$0x60, %rsp
      56: 5b                           	popq	%rbx
      57: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$invoke@V<lambda_1>@?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@AEAN$$V@std@@YA?AUScriptStepResult@script@simulation@lux@@$$QEAV<lambda_1>@?1???R5?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@234@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@N@0@V5?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@N@Z@@Z@QEAA@AEAV6234@AEAUScriptStepContext@234@@Z@AEAN@Z>:
       0: 4c 8b dc                     	movq	%rsp, %r11
       3: 53                           	pushq	%rbx
       4: 48 81 ec 80 00 00 00         	subq	$0x80, %rsp
       b: 48 8b 42 10                  	movq	0x10(%rdx), %rax
       f: 4d 8d 4b b8                  	leaq	-0x48(%r11), %r9
      13: 49 89 43 b8                  	movq	%rax, -0x48(%r11)
      17: 48 8b d9                     	movq	%rcx, %rbx
      1a: 48 8b 42 18                  	movq	0x18(%rdx), %rax
      1e: 49 8d 4b a8                  	leaq	-0x58(%r11), %rcx
      22: 49 89 43 c0                  	movq	%rax, -0x40(%r11)
      26: 48 8b 42 08                  	movq	0x8(%rdx), %rax
      2a: 48 8b 12                     	movq	(%rdx), %rdx
      2d: 4d 89 43 c8                  	movq	%r8, -0x38(%r11)
      31: 4d 89 43 98                  	movq	%r8, -0x68(%r11)
      35: 4d 8d 43 d8                  	leaq	-0x28(%r11), %r8
      39: 0f 10 00                     	movups	(%rax), %xmm0
      3c: f2 0f 10 48 10               	movsd	0x10(%rax), %xmm1
      41: 0f 29 44 24 60               	movaps	%xmm0, 0x60(%rsp)
      46: f2 0f 11 4c 24 70            	movsd	%xmm1, 0x70(%rsp)
      4c: e8 00 00 00 00               	callq	0x51 <??$invoke@V<lambda_1>@?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@AEAN$$V@std@@YA?AUScriptStepResult@script@simulation@lux@@$$QEAV<lambda_1>@?1???R5?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@234@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@N@0@V5?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@N@Z@@Z@QEAA@AEAV6234@AEAUScriptStepContext@234@@Z@AEAN@Z+0x51>
		000000000000004d:  IMAGE_REL_AMD64_REL32	??$invokePreparedScriptAbilityAsync@XV<lambda_1>@?1???$?RN@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PAEAN@Z@N@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@VPreparedLocalAsyncStart@012@$$QEAV<lambda_1>@?1???$?RN@6?1???R6?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@N@std@@V6?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@N@Z@@Z@QEAA@AEAV7012@0@Z@QEBA?A_PAEAN@Z@6@Z
      51: 0f 10 00                     	movups	(%rax), %xmm0
      54: 48 8b c3                     	movq	%rbx, %rax
      57: 0f 11 03                     	movups	%xmm0, (%rbx)
      5a: 48 81 c4 80 00 00 00         	addq	$0x80, %rsp
      61: 5b                           	popq	%rbx
      62: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static class tl::expected<void, struct lux::simulation::script::ScriptSyncStepError> __cdecl lux::simulation::script::detail::ScriptSyncStepCall<void __cdecl(struct lux::simulation::script::test::ValuePose const &)>::invoke<class lux::simulation::script::ScriptCoroutineContext>(class lux::simulation::script::ScriptCoroutineContext &, unsigned int, struct lux::simulation::script::test::ValuePose const &)>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 30                  	subq	$0x30, %rsp
       6: 48 8b d9                     	movq	%rcx, %rbx
       9: 4c 89 4c 24 40               	movq	%r9, 0x40(%rsp)
       e: 48 8b c2                     	movq	%rdx, %rax
      11: 48 c7 44 24 28 00 00 00 00   	movq	$0x0, 0x28(%rsp)
      1a: 48 8d 4c 24 40               	leaq	0x40(%rsp), %rcx
      1f: 48 8b d3                     	movq	%rbx, %rdx
      22: 48 89 4c 24 20               	movq	%rcx, 0x20(%rsp)
      27: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0x2e <public: static class tl::expected<void, struct lux::simulation::script::ScriptSyncStepError> __cdecl lux::simulation::script::detail::ScriptSyncStepCall<void __cdecl(struct lux::simulation::script::test::ValuePose const &)>::invoke<class lux::simulation::script::ScriptCoroutineContext>(class lux::simulation::script::ScriptCoroutineContext &, unsigned int, struct lux::simulation::script::test::ValuePose const &)+0x2e>
		000000000000002a:  IMAGE_REL_AMD64_REL32	?Shape@?$ScriptSyncStepCall@$$A6AXAEBUValuePose@test@script@simulation@lux@@@Z@detail@script@simulation@lux@@2UScriptSyncStepShape@345@B
      2e: 48 8b c8                     	movq	%rax, %rcx
      31: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x37 <public: static class tl::expected<void, struct lux::simulation::script::ScriptSyncStepError> __cdecl lux::simulation::script::detail::ScriptSyncStepCall<void __cdecl(struct lux::simulation::script::test::ValuePose const &)>::invoke<class lux::simulation::script::ScriptCoroutineContext>(class lux::simulation::script::ScriptCoroutineContext &, unsigned int, struct lux::simulation::script::test::ValuePose const &)+0x37>
		0000000000000033:  IMAGE_REL_AMD64_REL32	__imp_?invokeSyncStep@ScriptCoroutineContext@script@simulation@lux@@AEAA?AV?$expected@XUScriptSyncStepError@script@simulation@lux@@@tl@@IAEBUScriptSyncStepShape@234@PEBQEBXPEAX@Z
      37: 48 8b c3                     	movq	%rbx, %rax
      3a: 48 83 c4 30                  	addq	$0x30, %rsp
      3e: 5b                           	popq	%rbx
      3f: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static class tl::expected<void, struct lux::simulation::script::ScriptSyncStepError> __cdecl lux::simulation::script::detail::ScriptSyncStepCall<void __cdecl(struct lux::simulation::script::test::ValuePose const &, int)>::invoke<class lux::simulation::script::ScriptCoroutineContext>(class lux::simulation::script::ScriptCoroutineContext &, unsigned int, struct lux::simulation::script::test::ValuePose const &, int const &)>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 40                  	subq	$0x40, %rsp
       6: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
       b: 4c 8b d2                     	movq	%rdx, %r10
       e: 48 89 44 24 38               	movq	%rax, 0x38(%rsp)
      13: 48 8b d9                     	movq	%rcx, %rbx
      16: 48 8d 44 24 30               	leaq	0x30(%rsp), %rax
      1b: 4c 89 4c 24 30               	movq	%r9, 0x30(%rsp)
      20: 48 8b d1                     	movq	%rcx, %rdx
      23: 48 c7 44 24 28 00 00 00 00   	movq	$0x0, 0x28(%rsp)
      2c: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0x33 <public: static class tl::expected<void, struct lux::simulation::script::ScriptSyncStepError> __cdecl lux::simulation::script::detail::ScriptSyncStepCall<void __cdecl(struct lux::simulation::script::test::ValuePose const &, int)>::invoke<class lux::simulation::script::ScriptCoroutineContext>(class lux::simulation::script::ScriptCoroutineContext &, unsigned int, struct lux::simulation::script::test::ValuePose const &, int const &)+0x33>
		000000000000002f:  IMAGE_REL_AMD64_REL32	?Shape@?$ScriptSyncStepCall@$$A6AXAEBUValuePose@test@script@simulation@lux@@H@Z@detail@script@simulation@lux@@2UScriptSyncStepShape@345@B
      33: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
      38: 49 8b ca                     	movq	%r10, %rcx
      3b: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x41 <public: static class tl::expected<void, struct lux::simulation::script::ScriptSyncStepError> __cdecl lux::simulation::script::detail::ScriptSyncStepCall<void __cdecl(struct lux::simulation::script::test::ValuePose const &, int)>::invoke<class lux::simulation::script::ScriptCoroutineContext>(class lux::simulation::script::ScriptCoroutineContext &, unsigned int, struct lux::simulation::script::test::ValuePose const &, int const &)+0x41>
		000000000000003d:  IMAGE_REL_AMD64_REL32	__imp_?invokeSyncStep@ScriptCoroutineContext@script@simulation@lux@@AEAA?AV?$expected@XUScriptSyncStepError@script@simulation@lux@@@tl@@IAEBUScriptSyncStepShape@234@PEBQEBXPEAX@Z
      41: 48 8b c3                     	movq	%rbx, %rax
      44: 48 83 c4 40                  	addq	$0x40, %rsp
      48: 5b                           	popq	%rbx
      49: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static class tl::expected<void, struct lux::simulation::script::ScriptSyncStepError> __cdecl lux::simulation::script::detail::ScriptSyncStepCall<void __cdecl(int)>::invoke<class lux::simulation::script::ScriptCoroutineContext>(class lux::simulation::script::ScriptCoroutineContext &, unsigned int, int const &)>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 30                  	subq	$0x30, %rsp
       6: 48 8b d9                     	movq	%rcx, %rbx
       9: 4c 89 4c 24 40               	movq	%r9, 0x40(%rsp)
       e: 48 8b c2                     	movq	%rdx, %rax
      11: 48 c7 44 24 28 00 00 00 00   	movq	$0x0, 0x28(%rsp)
      1a: 48 8d 4c 24 40               	leaq	0x40(%rsp), %rcx
      1f: 48 8b d3                     	movq	%rbx, %rdx
      22: 48 89 4c 24 20               	movq	%rcx, 0x20(%rsp)
      27: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0x2e <public: static class tl::expected<void, struct lux::simulation::script::ScriptSyncStepError> __cdecl lux::simulation::script::detail::ScriptSyncStepCall<void __cdecl(int)>::invoke<class lux::simulation::script::ScriptCoroutineContext>(class lux::simulation::script::ScriptCoroutineContext &, unsigned int, int const &)+0x2e>
		000000000000002a:  IMAGE_REL_AMD64_REL32	?Shape@?$ScriptSyncStepCall@$$A6AXH@Z@detail@script@simulation@lux@@2UScriptSyncStepShape@345@B
      2e: 48 8b c8                     	movq	%rax, %rcx
      31: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x37 <public: static class tl::expected<void, struct lux::simulation::script::ScriptSyncStepError> __cdecl lux::simulation::script::detail::ScriptSyncStepCall<void __cdecl(int)>::invoke<class lux::simulation::script::ScriptCoroutineContext>(class lux::simulation::script::ScriptCoroutineContext &, unsigned int, int const &)+0x37>
		0000000000000033:  IMAGE_REL_AMD64_REL32	__imp_?invokeSyncStep@ScriptCoroutineContext@script@simulation@lux@@AEAA?AV?$expected@XUScriptSyncStepError@script@simulation@lux@@@tl@@IAEBUScriptSyncStepShape@234@PEBQEBXPEAX@Z
      37: 48 8b c3                     	movq	%rbx, %rax
      3a: 48 83 c4 30                  	addq	$0x30, %rsp
      3e: 5b                           	popq	%rbx
      3f: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static class tl::expected<void, struct lux::simulation::script::ScriptSyncStepError> __cdecl lux::simulation::script::detail::ScriptSyncStepCall<void __cdecl(void)>::invoke<class lux::simulation::script::ScriptCoroutineContext>(class lux::simulation::script::ScriptCoroutineContext &, unsigned int)>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 30                  	subq	$0x30, %rsp
       6: 48 8b d9                     	movq	%rcx, %rbx
       9: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0x10 <public: static class tl::expected<void, struct lux::simulation::script::ScriptSyncStepError> __cdecl lux::simulation::script::detail::ScriptSyncStepCall<void __cdecl(void)>::invoke<class lux::simulation::script::ScriptCoroutineContext>(class lux::simulation::script::ScriptCoroutineContext &, unsigned int)+0x10>
		000000000000000c:  IMAGE_REL_AMD64_REL32	?Shape@?$ScriptSyncStepCall@$$A6AXXZ@detail@script@simulation@lux@@2UScriptSyncStepShape@345@B
      10: 33 c9                        	xorl	%ecx, %ecx
      12: 48 8b c2                     	movq	%rdx, %rax
      15: 48 89 4c 24 28               	movq	%rcx, 0x28(%rsp)
      1a: 48 8b d3                     	movq	%rbx, %rdx
      1d: 48 89 4c 24 20               	movq	%rcx, 0x20(%rsp)
      22: 48 8b c8                     	movq	%rax, %rcx
      25: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x2b <public: static class tl::expected<void, struct lux::simulation::script::ScriptSyncStepError> __cdecl lux::simulation::script::detail::ScriptSyncStepCall<void __cdecl(void)>::invoke<class lux::simulation::script::ScriptCoroutineContext>(class lux::simulation::script::ScriptCoroutineContext &, unsigned int)+0x2b>
		0000000000000027:  IMAGE_REL_AMD64_REL32	__imp_?invokeSyncStep@ScriptCoroutineContext@script@simulation@lux@@AEAA?AV?$expected@XUScriptSyncStepError@script@simulation@lux@@@tl@@IAEBUScriptSyncStepShape@234@PEBQEBXPEAX@Z
      2b: 48 8b c3                     	movq	%rbx, %rax
      2e: 48 83 c4 30                  	addq	$0x30, %rsp
      32: 5b                           	popq	%rbx
      33: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$invokePreparedScriptAbilityAsync@XV<lambda_1>@?1???$?R$$V@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PXZ@$$V@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@VPreparedLocalAsyncStart@012@$$QEAV<lambda_1>@?1???$?R$$V@6?1???R6?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@$$V@std@@V6?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@XZ@@Z@QEAA@AEAV7012@0@Z@QEBA?A_PXZ@@Z>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 40                  	subq	$0x40, %rsp
       6: 49 8b c0                     	movq	%r8, %rax
       9: 48 8b d9                     	movq	%rcx, %rbx
       c: 4d 8b 50 08                  	movq	0x8(%r8), %r10
      10: 4d 85 d2                     	testq	%r10, %r10
      13: 74 2c                        	je	0x41 <??$invokePreparedScriptAbilityAsync@XV<lambda_1>@?1???$?R$$V@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PXZ@$$V@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@VPreparedLocalAsyncStart@012@$$QEAV<lambda_1>@?1???$?R$$V@6?1???R6?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@$$V@std@@V6?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@XZ@@Z@QEAA@AEAV7012@0@Z@QEBA?A_PXZ@@Z+0x41>
      15: 0f 57 c0                     	xorps	%xmm0, %xmm0
      18: 66 0f 7f 44 24 20            	movdqa	%xmm0, 0x20(%rsp)
      1e: 4c 8d 4c 24 20               	leaq	0x20(%rsp), %r9
      23: 4c 8b c2                     	movq	%rdx, %r8
      26: 48 8b 10                     	movq	(%rax), %rdx
      29: 48 8d 4c 24 30               	leaq	0x30(%rsp), %rcx
      2e: 41 ff d2                     	callq	*%r10
      31: 90                           	nop
      32: 0f 10 00                     	movups	(%rax), %xmm0
      35: 48 8b c3                     	movq	%rbx, %rax
      38: 0f 11 03                     	movups	%xmm0, (%rbx)
      3b: 48 83 c4 40                  	addq	$0x40, %rsp
      3f: 5b                           	popq	%rbx
      40: c3                           	retq
      41: 4d 8b c1                     	movq	%r9, %r8
      44: 48 8d 4c 24 30               	leaq	0x30(%rsp), %rcx
      49: e8 00 00 00 00               	callq	0x4e <??$invokePreparedScriptAbilityAsync@XV<lambda_1>@?1???$?R$$V@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PXZ@$$V@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@VPreparedLocalAsyncStart@012@$$QEAV<lambda_1>@?1???$?R$$V@6?1???R6?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@$$V@std@@V6?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@XZ@@Z@QEAA@AEAV7012@0@Z@QEBA?A_PXZ@@Z+0x4e>
		000000000000004a:  IMAGE_REL_AMD64_REL32	??$invokeScriptAbilityAsync@XV<lambda_1>@?1???$?R$$V@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PXZ@@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@$$QEAV<lambda_1>@?1???$?R$$V@5?1???R5?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@$$V@std@@V5?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@XZ@@Z@QEAA@AEAV6012@0@Z@QEBA?A_PXZ@@Z
      4e: 0f 10 00                     	movups	(%rax), %xmm0
      51: 48 8b c3                     	movq	%rbx, %rax
      54: 0f 11 03                     	movups	%xmm0, (%rbx)
      57: 48 83 c4 40                  	addq	$0x40, %rsp
      5b: 5b                           	popq	%rbx
      5c: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$invokePreparedScriptAbilityAsync@XV<lambda_1>@?1???$?RN@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PAEAN@Z@N@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@VPreparedLocalAsyncStart@012@$$QEAV<lambda_1>@?1???$?RN@6?1???R6?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@N@std@@V6?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@N@Z@@Z@QEAA@AEAV7012@0@Z@QEBA?A_PAEAN@Z@6@Z>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 60                  	subq	$0x60, %rsp
       6: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0xd <??$invokePreparedScriptAbilityAsync@XV<lambda_1>@?1???$?RN@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PAEAN@Z@N@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@VPreparedLocalAsyncStart@012@$$QEAV<lambda_1>@?1???$?RN@6?1???R6?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@N@std@@V6?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@N@Z@@Z@QEAA@AEAV7012@0@Z@QEBA?A_PAEAN@Z@6@Z+0xd>
		0000000000000009:  IMAGE_REL_AMD64_REL32	__security_cookie
       d: 48 33 c4                     	xorq	%rsp, %rax
      10: 48 89 44 24 58               	movq	%rax, 0x58(%rsp)
      15: 4d 8b d8                     	movq	%r8, %r11
      18: 4c 8b d2                     	movq	%rdx, %r10
      1b: 48 8b d9                     	movq	%rcx, %rbx
      1e: 49 83 78 08 00               	cmpq	$0x0, 0x8(%r8)
      23: 0f 84 9d 00 00 00            	je	0xc6 <??$invokePreparedScriptAbilityAsync@XV<lambda_1>@?1???$?RN@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PAEAN@Z@N@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@VPreparedLocalAsyncStart@012@$$QEAV<lambda_1>@?1???$?RN@6?1???R6?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@N@std@@V6?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@N@Z@@Z@QEAA@AEAV7012@0@Z@QEBA?A_PAEAN@Z@6@Z+0xc6>
      29: c6 44 24 40 07               	movb	$0x7, 0x40(%rsp)
      2e: 33 c0                        	xorl	%eax, %eax
      30: 66 89 44 24 41               	movw	%ax, 0x41(%rsp)
      35: 88 44 24 43                  	movb	%al, 0x43(%rsp)
      39: c7 44 24 44 08 00 00 00      	movl	$0x8, 0x44(%rsp)
      41: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x48 <??$invokePreparedScriptAbilityAsync@XV<lambda_1>@?1???$?RN@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PAEAN@Z@N@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@VPreparedLocalAsyncStart@012@$$QEAV<lambda_1>@?1???$?RN@6?1???R6?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@N@std@@V6?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@N@Z@@Z@QEAA@AEAV7012@0@Z@QEBA?A_PAEAN@Z@6@Z+0x48>
		0000000000000044:  IMAGE_REL_AMD64_REL32	?CanonicalName@?$TypeTraits@N@semantic@lux@@2V?$basic_string_view@DU?$char_traits@D@std@@@std@@B
      48: 48 ba 25 23 22 84 e4 9c f2 cb	movabsq	$-0x340d631b7bdddcdb, %rdx # imm = 0xCBF29CE484222325
      52: 4c 8d 40 07                  	leaq	0x7(%rax), %r8
      56: 49 3b c0                     	cmpq	%r8, %rax
      59: 74 27                        	je	0x82 <??$invokePreparedScriptAbilityAsync@XV<lambda_1>@?1???$?RN@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PAEAN@Z@N@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@VPreparedLocalAsyncStart@012@$$QEAV<lambda_1>@?1???$?RN@6?1???R6?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@N@std@@V6?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@N@Z@@Z@QEAA@AEAV7012@0@Z@QEBA?A_PAEAN@Z@6@Z+0x82>
      5b: 49 b9 b3 01 00 00 00 01 00 00	movabsq	$0x100000001b3, %r9     # imm = 0x100000001B3
      65: 66 66 66 0f 1f 84 00 00 00 00 00     	nopw	(%rax,%rax)
      70: 0f b6 08                     	movzbl	(%rax), %ecx
      73: 48 33 d1                     	xorq	%rcx, %rdx
      76: 49 0f af d1                  	imulq	%r9, %rdx
      7a: 48 ff c0                     	incq	%rax
      7d: 49 3b c0                     	cmpq	%r8, %rax
      80: 75 ee                        	jne	0x70 <??$invokePreparedScriptAbilityAsync@XV<lambda_1>@?1???$?RN@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PAEAN@Z@N@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@VPreparedLocalAsyncStart@012@$$QEAV<lambda_1>@?1???$?RN@6?1???R6?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@N@std@@V6?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@N@Z@@Z@QEAA@AEAV7012@0@Z@QEBA?A_PAEAN@Z@6@Z+0x70>
      82: b9 01 00 00 00               	movl	$0x1, %ecx
      87: 48 85 d2                     	testq	%rdx, %rdx
      8a: 48 0f 44 d1                  	cmoveq	%rcx, %rdx
      8e: 48 89 54 24 48               	movq	%rdx, 0x48(%rsp)
      93: 48 8b 84 24 90 00 00 00      	movq	0x90(%rsp), %rax
      9b: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
      a0: 48 8d 44 24 40               	leaq	0x40(%rsp), %rax
      a5: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
      aa: 48 89 4c 24 28               	movq	%rcx, 0x28(%rsp)
      af: 4c 8d 4c 24 20               	leaq	0x20(%rsp), %r9
      b4: 4d 8b c2                     	movq	%r10, %r8
      b7: 49 8b 13                     	movq	(%r11), %rdx
      ba: 48 8d 4c 24 30               	leaq	0x30(%rsp), %rcx
      bf: 41 ff 53 08                  	callq	*0x8(%r11)
      c3: 90                           	nop
      c4: eb 0d                        	jmp	0xd3 <??$invokePreparedScriptAbilityAsync@XV<lambda_1>@?1???$?RN@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PAEAN@Z@N@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@VPreparedLocalAsyncStart@012@$$QEAV<lambda_1>@?1???$?RN@6?1???R6?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@N@std@@V6?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@N@Z@@Z@QEAA@AEAV7012@0@Z@QEBA?A_PAEAN@Z@6@Z+0xd3>
      c6: 4d 8b c1                     	movq	%r9, %r8
      c9: 48 8d 4c 24 30               	leaq	0x30(%rsp), %rcx
      ce: e8 00 00 00 00               	callq	0xd3 <??$invokePreparedScriptAbilityAsync@XV<lambda_1>@?1???$?RN@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PAEAN@Z@N@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@VPreparedLocalAsyncStart@012@$$QEAV<lambda_1>@?1???$?RN@6?1???R6?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@N@std@@V6?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@N@Z@@Z@QEAA@AEAV7012@0@Z@QEBA?A_PAEAN@Z@6@Z+0xd3>
		00000000000000cf:  IMAGE_REL_AMD64_REL32	??$invokeScriptAbilityAsync@XV<lambda_1>@?1???$?RN@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PAEAN@Z@@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@$$QEAV<lambda_1>@?1???$?RN@5?1???R5?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@N@std@@V5?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@N@Z@@Z@QEAA@AEAV6012@0@Z@QEBA?A_PAEAN@Z@@Z
      d3: 0f 10 00                     	movups	(%rax), %xmm0
      d6: 48 8b c3                     	movq	%rbx, %rax
      d9: 0f 11 03                     	movups	%xmm0, (%rbx)
      dc: 48 8b 4c 24 58               	movq	0x58(%rsp), %rcx
      e1: 48 33 cc                     	xorq	%rsp, %rcx
      e4: e8 00 00 00 00               	callq	0xe9 <??$invokePreparedScriptAbilityAsync@XV<lambda_1>@?1???$?RN@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PAEAN@Z@N@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@VPreparedLocalAsyncStart@012@$$QEAV<lambda_1>@?1???$?RN@6?1???R6?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@N@std@@V6?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@N@Z@@Z@QEAA@AEAV7012@0@Z@QEBA?A_PAEAN@Z@6@Z+0xe9>
		00000000000000e5:  IMAGE_REL_AMD64_REL32	__security_check_cookie
      e9: 48 83 c4 60                  	addq	$0x60, %rsp
      ed: 5b                           	popq	%rbx
      ee: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$invokeScriptAbilityAsync@XV<lambda_1>@?1???$?R$$V@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PXZ@@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@$$QEAV<lambda_1>@?1???$?R$$V@5?1???R5?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@$$V@std@@V5?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@XZ@@Z@QEAA@AEAV6012@0@Z@QEBA?A_PXZ@@Z>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 74 24 10               	movq	%rsi, 0x10(%rsp)
       a: 48 89 7c 24 18               	movq	%rdi, 0x18(%rsp)
       f: 55                           	pushq	%rbp
      10: 48 8d ac 24 50 ff ff ff      	leaq	-0xb0(%rsp), %rbp
      18: 48 81 ec b0 01 00 00         	subq	$0x1b0, %rsp            # imm = 0x1B0
      1f: 49 8b f8                     	movq	%r8, %rdi
      22: 48 8b da                     	movq	%rdx, %rbx
      25: 48 8b f1                     	movq	%rcx, %rsi
      28: 0f 10 4c 24 20               	movups	0x20(%rsp), %xmm1
      2d: f2 0f 10 44 24 30            	movsd	0x30(%rsp), %xmm0
      33: f2 0f 11 44 24 30            	movsd	%xmm0, 0x30(%rsp)
      39: c6 44 24 38 00               	movb	$0x0, 0x38(%rsp)
      3e: 8b 44 24 39                  	movl	0x39(%rsp), %eax
      42: 89 44 24 39                  	movl	%eax, 0x39(%rsp)
      46: 0f b7 44 24 3d               	movzwl	0x3d(%rsp), %eax
      4b: 66 89 44 24 3d               	movw	%ax, 0x3d(%rsp)
      50: 0f b6 44 24 3f               	movzbl	0x3f(%rsp), %eax
      55: 88 44 24 3f                  	movb	%al, 0x3f(%rsp)
      59: 48 8b 42 10                  	movq	0x10(%rdx), %rax
      5d: 48 85 c0                     	testq	%rax, %rax
      60: 75 0f                        	jne	0x71 <??$invokeScriptAbilityAsync@XV<lambda_1>@?1???$?R$$V@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PXZ@@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@$$QEAV<lambda_1>@?1???$?R$$V@5?1???R5?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@$$V@std@@V5?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@XZ@@Z@QEAA@AEAV6012@0@Z@QEBA?A_PXZ@@Z+0x71>
      62: b0 05                        	movb	$0x5, %al
      64: 88 45 10                     	movb	%al, 0x10(%rbp)
      67: 32 c9                        	xorb	%cl, %cl
      69: 88 8d 80 00 00 00            	movb	%cl, 0x80(%rbp)
      6f: eb 33                        	jmp	0xa4 <??$invokeScriptAbilityAsync@XV<lambda_1>@?1???$?R$$V@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PXZ@@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@$$QEAV<lambda_1>@?1???$?R$$V@5?1???R5?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@$$V@std@@V5?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@XZ@@Z@QEAA@AEAV6012@0@Z@QEBA?A_PXZ@@Z+0xa4>
      71: 0f 29 8d 90 00 00 00         	movaps	%xmm1, 0x90(%rbp)
      78: 0f 28 44 24 30               	movaps	0x30(%rsp), %xmm0
      7d: 0f 29 85 a0 00 00 00         	movaps	%xmm0, 0xa0(%rbp)
      84: 4c 8d 8d 90 00 00 00         	leaq	0x90(%rbp), %r9
      8b: 4c 8b 42 20                  	movq	0x20(%rdx), %r8
      8f: 48 8b 52 08                  	movq	0x8(%rdx), %rdx
      93: 48 8d 4d 10                  	leaq	0x10(%rbp), %rcx
      97: ff d0                        	callq	*%rax
      99: 0f b6 8d 80 00 00 00         	movzbl	0x80(%rbp), %ecx
      a0: 0f b6 45 10                  	movzbl	0x10(%rbp), %eax
      a4: 84 c9                        	testb	%cl, %cl
      a6: 75 59                        	jne	0x101 <$LN44+0x22>
      a8: 0f b6 c8                     	movzbl	%al, %ecx
      ab: 83 f9 05                     	cmpl	$0x5, %ecx
      ae: 77 2f                        	ja	0xdf <$LN44>
      b0: 48 8d 15 00 00 00 00         	leaq	(%rip), %rdx            # 0xb7 <??$invokeScriptAbilityAsync@XV<lambda_1>@?1???$?R$$V@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PXZ@@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@$$QEAV<lambda_1>@?1???$?R$$V@5?1???R5?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@$$V@std@@V5?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@XZ@@Z@QEAA@AEAV6012@0@Z@QEBA?A_PXZ@@Z+0xb7>
		00000000000000b3:  IMAGE_REL_AMD64_REL32	__ImageBase
      b7: 8b 8c 8a 00 00 00 00         	movl	(%rdx,%rcx,4), %ecx
		00000000000000ba:  IMAGE_REL_AMD64_ADDR32NB	$LN530
      be: 48 03 ca                     	addq	%rdx, %rcx
      c1: ff e1                        	jmpq	*%rcx

00000000000000c3 <$LN46>:
      c3: bb fe ff ff ff               	movl	$0xfffffffe, %ebx       # imm = 0xFFFFFFFE
      c8: eb 1a                        	jmp	0xe4 <$LN44+0x5>

00000000000000ca <$LN47>:
      ca: bb fd ff ff ff               	movl	$0xfffffffd, %ebx       # imm = 0xFFFFFFFD
      cf: eb 13                        	jmp	0xe4 <$LN44+0x5>

00000000000000d1 <$LN48>:
      d1: bb fc ff ff ff               	movl	$0xfffffffc, %ebx       # imm = 0xFFFFFFFC
      d6: eb 0c                        	jmp	0xe4 <$LN44+0x5>

00000000000000d8 <$LN49>:
      d8: bb fa ff ff ff               	movl	$0xfffffffa, %ebx       # imm = 0xFFFFFFFA
      dd: eb 05                        	jmp	0xe4 <$LN44+0x5>

00000000000000df <$LN44>:
      df: bb ff ff ff ff               	movl	$0xffffffff, %ebx       # imm = 0xFFFFFFFF
      e4: c6 44 24 40 02               	movb	$0x2, 0x40(%rsp)
      e9: 33 c0                        	xorl	%eax, %eax
      eb: 48 89 44 24 44               	movq	%rax, 0x44(%rsp)
      f0: 89 5c 24 4c                  	movl	%ebx, 0x4c(%rsp)
      f4: 0f 10 44 24 40               	movups	0x40(%rsp), %xmm0
      f9: 0f 11 06                     	movups	%xmm0, (%rsi)
      fc: e9 3f 01 00 00               	jmp	0x240 <$LN44+0x161>
     101: 48 8d 54 24 50               	leaq	0x50(%rsp), %rdx
     106: 48 8d 4d 18                  	leaq	0x18(%rbp), %rcx
     10a: e8 00 00 00 00               	callq	0x10f <$LN44+0x30>
		000000000000010b:  IMAGE_REL_AMD64_REL32	?intoAbilityCompletion@ScriptAwaitableCompletion@script@simulation@lux@@QEHAA?AVScriptAbilityErasedCompletion@24@XZ
     10f: 48 8b d0                     	movq	%rax, %rdx
     112: 48 8d 4d b0                  	leaq	-0x50(%rbp), %rcx
     116: e8 00 00 00 00               	callq	0x11b <$LN44+0x3c>
		0000000000000117:  IMAGE_REL_AMD64_REL32	?fromErased@?$ScriptAbilityCompletion@X@script@lux@@SA?AV123@VScriptAbilityErasedCompletion@23@@Z
     11b: 48 8b 4d b8                  	movq	-0x48(%rbp), %rcx
     11f: 48 8b 47 08                  	movq	0x8(%rdi), %rax
     123: 4c 8b 40 08                  	movq	0x8(%rax), %r8
     127: 48 8b 10                     	movq	(%rax), %rdx
     12a: 48 8b 45 b0                  	movq	-0x50(%rbp), %rax
     12e: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
     133: 48 89 4c 24 58               	movq	%rcx, 0x58(%rsp)
     138: 48 8b 45 c0                  	movq	-0x40(%rbp), %rax
     13c: 48 89 44 24 60               	movq	%rax, 0x60(%rsp)
     141: 48 8b 45 c8                  	movq	-0x38(%rbp), %rax
     145: 48 89 44 24 68               	movq	%rax, 0x68(%rsp)
     14a: 48 8b 45 d0                  	movq	-0x30(%rbp), %rax
     14e: 48 89 44 24 70               	movq	%rax, 0x70(%rsp)
     153: 48 8b 45 d8                  	movq	-0x28(%rbp), %rax
     157: 48 89 44 24 78               	movq	%rax, 0x78(%rsp)
     15c: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
     160: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
     164: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
     168: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
     16c: 48 8b 45 f0                  	movq	-0x10(%rbp), %rax
     170: 48 89 45 90                  	movq	%rax, -0x70(%rbp)
     174: 48 8b 45 f8                  	movq	-0x8(%rbp), %rax
     178: 48 89 45 98                  	movq	%rax, -0x68(%rbp)
     17c: 48 8b 45 00                  	movq	(%rbp), %rax
     180: 48 89 45 a0                  	movq	%rax, -0x60(%rbp)
     184: 49 8b 00                     	movq	(%r8), %rax
     187: 4c 8d 44 24 50               	leaq	0x50(%rsp), %r8
     18c: 48 8d 4c 24 40               	leaq	0x40(%rsp), %rcx
     191: ff d0                        	callq	*%rax
     193: 90                           	nop
     194: 80 7c 24 44 00               	cmpb	$0x0, 0x44(%rsp)
     199: 74 16                        	je	0x1b1 <$LN44+0xd2>
     19b: c6 44 24 20 01               	movb	$0x1, 0x20(%rsp)
     1a0: 48 8b 45 10                  	movq	0x10(%rbp), %rax
     1a4: 48 89 44 24 24               	movq	%rax, 0x24(%rsp)
     1a9: 33 c0                        	xorl	%eax, %eax
     1ab: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
     1af: eb 4a                        	jmp	0x1fb <$LN44+0x11c>
     1b1: 4c 8b 45 10                  	movq	0x10(%rbp), %r8
     1b5: 49 8b c0                     	movq	%r8, %rax
     1b8: 48 c1 e8 20                  	shrq	$0x20, %rax
     1bc: 4c 8b 4b 18                  	movq	0x18(%rbx), %r9
     1c0: 4d 85 c9                     	testq	%r9, %r9
     1c3: 74 16                        	je	0x1db <$LN44+0xfc>
     1c5: 83 7d 10 00                  	cmpl	$0x0, 0x10(%rbp)
     1c9: 74 10                        	je	0x1db <$LN44+0xfc>
     1cb: 85 c0                        	testl	%eax, %eax
     1cd: 74 0c                        	je	0x1db <$LN44+0xfc>
     1cf: 48 8b 53 20                  	movq	0x20(%rbx), %rdx
     1d3: 48 8b 4b 08                  	movq	0x8(%rbx), %rcx
     1d7: 41 ff d1                     	callq	*%r9
     1da: 90                           	nop
     1db: 8b 4c 24 40                  	movl	0x40(%rsp), %ecx
     1df: c6 44 24 20 02               	movb	$0x2, 0x20(%rsp)
     1e4: 33 c0                        	xorl	%eax, %eax
     1e6: 48 89 44 24 24               	movq	%rax, 0x24(%rsp)
     1eb: 85 c9                        	testl	%ecx, %ecx
     1ed: c7 44 24 2c fb ff ff ff      	movl	$0xfffffffb, 0x2c(%rsp) # imm = 0xFFFFFFFB
     1f5: 7e 04                        	jle	0x1fb <$LN44+0x11c>
     1f7: 89 4c 24 2c                  	movl	%ecx, 0x2c(%rsp)
     1fb: 0f 10 44 24 20               	movups	0x20(%rsp), %xmm0
     200: 0f 11 06                     	movups	%xmm0, (%rsi)
     203: 38 85 80 00 00 00            	cmpb	%al, 0x80(%rbp)
     209: 74 35                        	je	0x240 <$LN44+0x161>
     20b: 48 8b 7d 20                  	movq	0x20(%rbp), %rdi
     20f: 48 85 ff                     	testq	%rdi, %rdi
     212: 74 2c                        	je	0x240 <$LN44+0x161>
     214: bb ff ff ff ff               	movl	$0xffffffff, %ebx       # imm = 0xFFFFFFFF
     219: 8b c3                        	movl	%ebx, %eax
     21b: f0                           	lock
     21c: 0f c1 47 08                  	xaddl	%eax, 0x8(%rdi)
     220: 83 f8 01                     	cmpl	$0x1, %eax
     223: 75 1b                        	jne	0x240 <$LN44+0x161>
     225: 48 8b 07                     	movq	(%rdi), %rax
     228: 48 8b cf                     	movq	%rdi, %rcx
     22b: ff 10                        	callq	*(%rax)
     22d: f0                           	lock
     22e: 0f c1 5f 0c                  	xaddl	%ebx, 0xc(%rdi)
     232: 83 fb 01                     	cmpl	$0x1, %ebx
     235: 75 09                        	jne	0x240 <$LN44+0x161>
     237: 48 8b 07                     	movq	(%rdi), %rax
     23a: 48 8b cf                     	movq	%rdi, %rcx
     23d: ff 50 08                     	callq	*0x8(%rax)
     240: 48 8b c6                     	movq	%rsi, %rax
     243: 4c 8d 9c 24 b0 01 00 00      	leaq	0x1b0(%rsp), %r11
     24b: 49 8b 5b 10                  	movq	0x10(%r11), %rbx
     24f: 49 8b 73 18                  	movq	0x18(%r11), %rsi
     253: 49 8b 7b 20                  	movq	0x20(%r11), %rdi
     257: 49 8b e3                     	movq	%r11, %rsp
     25a: 5d                           	popq	%rbp
     25b: c3                           	retq

000000000000025c <$LN530>:
     25c: 00 00                        	addb	%al, (%rax)
		000000000000025c:  IMAGE_REL_AMD64_ADDR32NB	$LN44
     25e: 00 00                        	addb	%al, (%rax)
     260: 00 00                        	addb	%al, (%rax)
		0000000000000260:  IMAGE_REL_AMD64_ADDR32NB	$LN44
     262: 00 00                        	addb	%al, (%rax)
     264: 00 00                        	addb	%al, (%rax)
		0000000000000264:  IMAGE_REL_AMD64_ADDR32NB	$LN49
     266: 00 00                        	addb	%al, (%rax)
     268: 00 00                        	addb	%al, (%rax)
		0000000000000268:  IMAGE_REL_AMD64_ADDR32NB	$LN46
     26a: 00 00                        	addb	%al, (%rax)
     26c: 00 00                        	addb	%al, (%rax)
		000000000000026c:  IMAGE_REL_AMD64_ADDR32NB	$LN47
     26e: 00 00                        	addb	%al, (%rax)
     270: 00 00                        	addb	%al, (%rax)
		0000000000000270:  IMAGE_REL_AMD64_ADDR32NB	$LN48
     272: 00 00                        	addb	%al, (%rax)

Disassembly of section .text$mn:

0000000000000000 <??$invokeScriptAbilityAsync@XV<lambda_1>@?1???$?RN@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PAEAN@Z@@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@$$QEAV<lambda_1>@?1???$?RN@5?1???R5?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@N@std@@V5?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@N@Z@@Z@QEAA@AEAV6012@0@Z@QEBA?A_PAEAN@Z@@Z>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 74 24 10               	movq	%rsi, 0x10(%rsp)
       a: 48 89 7c 24 18               	movq	%rdi, 0x18(%rsp)
       f: 55                           	pushq	%rbp
      10: 48 8d ac 24 50 ff ff ff      	leaq	-0xb0(%rsp), %rbp
      18: 48 81 ec b0 01 00 00         	subq	$0x1b0, %rsp            # imm = 0x1B0
      1f: 49 8b f8                     	movq	%r8, %rdi
      22: 48 8b da                     	movq	%rdx, %rbx
      25: 48 8b f1                     	movq	%rcx, %rsi
      28: 0f 10 4c 24 20               	movups	0x20(%rsp), %xmm1
      2d: f2 0f 10 44 24 30            	movsd	0x30(%rsp), %xmm0
      33: f2 0f 11 44 24 30            	movsd	%xmm0, 0x30(%rsp)
      39: c6 44 24 38 00               	movb	$0x0, 0x38(%rsp)
      3e: 8b 44 24 39                  	movl	0x39(%rsp), %eax
      42: 89 44 24 39                  	movl	%eax, 0x39(%rsp)
      46: 0f b7 44 24 3d               	movzwl	0x3d(%rsp), %eax
      4b: 66 89 44 24 3d               	movw	%ax, 0x3d(%rsp)
      50: 0f b6 44 24 3f               	movzbl	0x3f(%rsp), %eax
      55: 88 44 24 3f                  	movb	%al, 0x3f(%rsp)
      59: 48 8b 42 10                  	movq	0x10(%rdx), %rax
      5d: 48 85 c0                     	testq	%rax, %rax
      60: 75 0f                        	jne	0x71 <??$invokeScriptAbilityAsync@XV<lambda_1>@?1???$?RN@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PAEAN@Z@@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@$$QEAV<lambda_1>@?1???$?RN@5?1???R5?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@N@std@@V5?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@N@Z@@Z@QEAA@AEAV6012@0@Z@QEBA?A_PAEAN@Z@@Z+0x71>
      62: b0 05                        	movb	$0x5, %al
      64: 88 45 10                     	movb	%al, 0x10(%rbp)
      67: 32 c9                        	xorb	%cl, %cl
      69: 88 8d 80 00 00 00            	movb	%cl, 0x80(%rbp)
      6f: eb 33                        	jmp	0xa4 <??$invokeScriptAbilityAsync@XV<lambda_1>@?1???$?RN@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PAEAN@Z@@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@$$QEAV<lambda_1>@?1???$?RN@5?1???R5?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@N@std@@V5?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@N@Z@@Z@QEAA@AEAV6012@0@Z@QEBA?A_PAEAN@Z@@Z+0xa4>
      71: 0f 29 8d 90 00 00 00         	movaps	%xmm1, 0x90(%rbp)
      78: 0f 28 44 24 30               	movaps	0x30(%rsp), %xmm0
      7d: 0f 29 85 a0 00 00 00         	movaps	%xmm0, 0xa0(%rbp)
      84: 4c 8d 8d 90 00 00 00         	leaq	0x90(%rbp), %r9
      8b: 4c 8b 42 20                  	movq	0x20(%rdx), %r8
      8f: 48 8b 52 08                  	movq	0x8(%rdx), %rdx
      93: 48 8d 4d 10                  	leaq	0x10(%rbp), %rcx
      97: ff d0                        	callq	*%rax
      99: 0f b6 8d 80 00 00 00         	movzbl	0x80(%rbp), %ecx
      a0: 0f b6 45 10                  	movzbl	0x10(%rbp), %eax
      a4: 84 c9                        	testb	%cl, %cl
      a6: 75 59                        	jne	0x101 <$LN44+0x22>
      a8: 0f b6 c8                     	movzbl	%al, %ecx
      ab: 83 f9 05                     	cmpl	$0x5, %ecx
      ae: 77 2f                        	ja	0xdf <$LN44>
      b0: 48 8d 15 00 00 00 00         	leaq	(%rip), %rdx            # 0xb7 <??$invokeScriptAbilityAsync@XV<lambda_1>@?1???$?RN@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PAEAN@Z@@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@$$QEAV<lambda_1>@?1???$?RN@5?1???R5?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@N@std@@V5?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@N@Z@@Z@QEAA@AEAV6012@0@Z@QEBA?A_PAEAN@Z@@Z+0xb7>
		00000000000000b3:  IMAGE_REL_AMD64_REL32	__ImageBase
      b7: 8b 8c 8a 00 00 00 00         	movl	(%rdx,%rcx,4), %ecx
		00000000000000ba:  IMAGE_REL_AMD64_ADDR32NB	$LN530
      be: 48 03 ca                     	addq	%rdx, %rcx
      c1: ff e1                        	jmpq	*%rcx

00000000000000c3 <$LN46>:
      c3: bb fe ff ff ff               	movl	$0xfffffffe, %ebx       # imm = 0xFFFFFFFE
      c8: eb 1a                        	jmp	0xe4 <$LN44+0x5>

00000000000000ca <$LN47>:
      ca: bb fd ff ff ff               	movl	$0xfffffffd, %ebx       # imm = 0xFFFFFFFD
      cf: eb 13                        	jmp	0xe4 <$LN44+0x5>

00000000000000d1 <$LN48>:
      d1: bb fc ff ff ff               	movl	$0xfffffffc, %ebx       # imm = 0xFFFFFFFC
      d6: eb 0c                        	jmp	0xe4 <$LN44+0x5>

00000000000000d8 <$LN49>:
      d8: bb fa ff ff ff               	movl	$0xfffffffa, %ebx       # imm = 0xFFFFFFFA
      dd: eb 05                        	jmp	0xe4 <$LN44+0x5>

00000000000000df <$LN44>:
      df: bb ff ff ff ff               	movl	$0xffffffff, %ebx       # imm = 0xFFFFFFFF
      e4: c6 44 24 40 02               	movb	$0x2, 0x40(%rsp)
      e9: 33 c0                        	xorl	%eax, %eax
      eb: 48 89 44 24 44               	movq	%rax, 0x44(%rsp)
      f0: 89 5c 24 4c                  	movl	%ebx, 0x4c(%rsp)
      f4: 0f 10 44 24 40               	movups	0x40(%rsp), %xmm0
      f9: 0f 11 06                     	movups	%xmm0, (%rsi)
      fc: e9 49 01 00 00               	jmp	0x24a <$LN44+0x16b>
     101: 48 8d 54 24 50               	leaq	0x50(%rsp), %rdx
     106: 48 8d 4d 18                  	leaq	0x18(%rbp), %rcx
     10a: e8 00 00 00 00               	callq	0x10f <$LN44+0x30>
		000000000000010b:  IMAGE_REL_AMD64_REL32	?intoAbilityCompletion@ScriptAwaitableCompletion@script@simulation@lux@@QEHAA?AVScriptAbilityErasedCompletion@24@XZ
     10f: 48 8b d0                     	movq	%rax, %rdx
     112: 48 8d 4d b0                  	leaq	-0x50(%rbp), %rcx
     116: e8 00 00 00 00               	callq	0x11b <$LN44+0x3c>
		0000000000000117:  IMAGE_REL_AMD64_REL32	?fromErased@?$ScriptAbilityCompletion@X@script@lux@@SA?AV123@VScriptAbilityErasedCompletion@23@@Z
     11b: 48 8b 4d b8                  	movq	-0x48(%rbp), %rcx
     11f: 4c 8b 57 10                  	movq	0x10(%rdi), %r10
     123: 48 8b 47 08                  	movq	0x8(%rdi), %rax
     127: 4c 8b 40 08                  	movq	0x8(%rax), %r8
     12b: 48 8b 10                     	movq	(%rax), %rdx
     12e: 48 8b 45 b0                  	movq	-0x50(%rbp), %rax
     132: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
     137: 48 89 4c 24 58               	movq	%rcx, 0x58(%rsp)
     13c: 48 8b 45 c0                  	movq	-0x40(%rbp), %rax
     140: 48 89 44 24 60               	movq	%rax, 0x60(%rsp)
     145: 48 8b 45 c8                  	movq	-0x38(%rbp), %rax
     149: 48 89 44 24 68               	movq	%rax, 0x68(%rsp)
     14e: 48 8b 45 d0                  	movq	-0x30(%rbp), %rax
     152: 48 89 44 24 70               	movq	%rax, 0x70(%rsp)
     157: 48 8b 45 d8                  	movq	-0x28(%rbp), %rax
     15b: 48 89 44 24 78               	movq	%rax, 0x78(%rsp)
     160: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
     164: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
     168: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
     16c: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
     170: 48 8b 45 f0                  	movq	-0x10(%rbp), %rax
     174: 48 89 45 90                  	movq	%rax, -0x70(%rbp)
     178: 48 8b 45 f8                  	movq	-0x8(%rbp), %rax
     17c: 48 89 45 98                  	movq	%rax, -0x68(%rbp)
     180: 48 8b 45 00                  	movq	(%rbp), %rax
     184: 48 89 45 a0                  	movq	%rax, -0x60(%rbp)
     188: 49 8b 40 10                  	movq	0x10(%r8), %rax
     18c: 4c 8d 4c 24 50               	leaq	0x50(%rsp), %r9
     191: f2 41 0f 10 12               	movsd	(%r10), %xmm2
     196: 48 8d 4c 24 40               	leaq	0x40(%rsp), %rcx
     19b: ff d0                        	callq	*%rax
     19d: 90                           	nop
     19e: 80 7c 24 44 00               	cmpb	$0x0, 0x44(%rsp)
     1a3: 74 16                        	je	0x1bb <$LN44+0xdc>
     1a5: c6 44 24 20 01               	movb	$0x1, 0x20(%rsp)
     1aa: 48 8b 45 10                  	movq	0x10(%rbp), %rax
     1ae: 48 89 44 24 24               	movq	%rax, 0x24(%rsp)
     1b3: 33 c0                        	xorl	%eax, %eax
     1b5: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
     1b9: eb 4a                        	jmp	0x205 <$LN44+0x126>
     1bb: 4c 8b 45 10                  	movq	0x10(%rbp), %r8
     1bf: 49 8b c0                     	movq	%r8, %rax
     1c2: 48 c1 e8 20                  	shrq	$0x20, %rax
     1c6: 4c 8b 4b 18                  	movq	0x18(%rbx), %r9
     1ca: 4d 85 c9                     	testq	%r9, %r9
     1cd: 74 16                        	je	0x1e5 <$LN44+0x106>
     1cf: 83 7d 10 00                  	cmpl	$0x0, 0x10(%rbp)
     1d3: 74 10                        	je	0x1e5 <$LN44+0x106>
     1d5: 85 c0                        	testl	%eax, %eax
     1d7: 74 0c                        	je	0x1e5 <$LN44+0x106>
     1d9: 48 8b 53 20                  	movq	0x20(%rbx), %rdx
     1dd: 48 8b 4b 08                  	movq	0x8(%rbx), %rcx
     1e1: 41 ff d1                     	callq	*%r9
     1e4: 90                           	nop
     1e5: 8b 4c 24 40                  	movl	0x40(%rsp), %ecx
     1e9: c6 44 24 20 02               	movb	$0x2, 0x20(%rsp)
     1ee: 33 c0                        	xorl	%eax, %eax
     1f0: 48 89 44 24 24               	movq	%rax, 0x24(%rsp)
     1f5: 85 c9                        	testl	%ecx, %ecx
     1f7: c7 44 24 2c fb ff ff ff      	movl	$0xfffffffb, 0x2c(%rsp) # imm = 0xFFFFFFFB
     1ff: 7e 04                        	jle	0x205 <$LN44+0x126>
     201: 89 4c 24 2c                  	movl	%ecx, 0x2c(%rsp)
     205: 0f 10 44 24 20               	movups	0x20(%rsp), %xmm0
     20a: 0f 11 06                     	movups	%xmm0, (%rsi)
     20d: 38 85 80 00 00 00            	cmpb	%al, 0x80(%rbp)
     213: 74 35                        	je	0x24a <$LN44+0x16b>
     215: 48 8b 7d 20                  	movq	0x20(%rbp), %rdi
     219: 48 85 ff                     	testq	%rdi, %rdi
     21c: 74 2c                        	je	0x24a <$LN44+0x16b>
     21e: bb ff ff ff ff               	movl	$0xffffffff, %ebx       # imm = 0xFFFFFFFF
     223: 8b c3                        	movl	%ebx, %eax
     225: f0                           	lock
     226: 0f c1 47 08                  	xaddl	%eax, 0x8(%rdi)
     22a: 83 f8 01                     	cmpl	$0x1, %eax
     22d: 75 1b                        	jne	0x24a <$LN44+0x16b>
     22f: 48 8b 07                     	movq	(%rdi), %rax
     232: 48 8b cf                     	movq	%rdi, %rcx
     235: ff 10                        	callq	*(%rax)
     237: f0                           	lock
     238: 0f c1 5f 0c                  	xaddl	%ebx, 0xc(%rdi)
     23c: 83 fb 01                     	cmpl	$0x1, %ebx
     23f: 75 09                        	jne	0x24a <$LN44+0x16b>
     241: 48 8b 07                     	movq	(%rdi), %rax
     244: 48 8b cf                     	movq	%rdi, %rcx
     247: ff 50 08                     	callq	*0x8(%rax)
     24a: 48 8b c6                     	movq	%rsi, %rax
     24d: 4c 8d 9c 24 b0 01 00 00      	leaq	0x1b0(%rsp), %r11
     255: 49 8b 5b 10                  	movq	0x10(%r11), %rbx
     259: 49 8b 73 18                  	movq	0x18(%r11), %rsi
     25d: 49 8b 7b 20                  	movq	0x20(%r11), %rdi
     261: 49 8b e3                     	movq	%r11, %rsp
     264: 5d                           	popq	%rbp
     265: c3                           	retq
     266: 66 90                        	nop

0000000000000268 <$LN530>:
     268: 00 00                        	addb	%al, (%rax)
		0000000000000268:  IMAGE_REL_AMD64_ADDR32NB	$LN44
     26a: 00 00                        	addb	%al, (%rax)
     26c: 00 00                        	addb	%al, (%rax)
		000000000000026c:  IMAGE_REL_AMD64_ADDR32NB	$LN44
     26e: 00 00                        	addb	%al, (%rax)
     270: 00 00                        	addb	%al, (%rax)
		0000000000000270:  IMAGE_REL_AMD64_ADDR32NB	$LN49
     272: 00 00                        	addb	%al, (%rax)
     274: 00 00                        	addb	%al, (%rax)
		0000000000000274:  IMAGE_REL_AMD64_ADDR32NB	$LN46
     276: 00 00                        	addb	%al, (%rax)
     278: 00 00                        	addb	%al, (%rax)
		0000000000000278:  IMAGE_REL_AMD64_ADDR32NB	$LN47
     27a: 00 00                        	addb	%al, (%rax)
     27c: 00 00                        	addb	%al, (%rax)
		000000000000027c:  IMAGE_REL_AMD64_ADDR32NB	$LN48
     27e: 00 00                        	addb	%al, (%rax)

Disassembly of section .text$mn:

0000000000000000 <??$makeAwaiter@HV<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@345@@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PV<lambda_1>@?1???$wait@H@0123@QEAA?A_PAEBV?$CppScriptEventSource@H@123@@Z@@Z>:
       0: 41 0f 10 00                  	movups	(%r8), %xmm0
       4: 48 89 0a                     	movq	%rcx, (%rdx)
       7: 48 8b c2                     	movq	%rdx, %rax
       a: 48 c7 42 18 00 00 00 00      	movq	$0x0, 0x18(%rdx)
      12: 0f 11 42 08                  	movups	%xmm0, 0x8(%rdx)
      16: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$makeAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@0123@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@3@V?$tuple@$$V@std@@V4?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@13@QEBA@XZ@@Z@@Z>:
       0: 41 8b 00                     	movl	(%r8), %eax
       3: 4d 8b 40 08                  	movq	0x8(%r8), %r8
       7: 89 42 08                     	movl	%eax, 0x8(%rdx)
       a: 48 8b c2                     	movq	%rdx, %rax
       d: 4c 89 42 10                  	movq	%r8, 0x10(%rdx)
      11: 48 89 0a                     	movq	%rcx, (%rdx)
      14: 48 c7 42 20 00 00 00 00      	movq	$0x0, 0x20(%rdx)
      1c: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$makeAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@0123@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@3@V?$tuple@N@std@@V4?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@13@QEBA@N@Z@@Z@@Z>:
       0: 41 8b 00                     	movl	(%r8), %eax
       3: 4d 8b 48 08                  	movq	0x8(%r8), %r9
       7: f2 41 0f 10 40 10            	movsd	0x10(%r8), %xmm0
       d: 89 42 08                     	movl	%eax, 0x8(%rdx)
      10: 48 8b c2                     	movq	%rdx, %rax
      13: 4c 89 4a 10                  	movq	%r9, 0x10(%rdx)
      17: 48 89 0a                     	movq	%rcx, (%rdx)
      1a: f2 0f 11 42 18               	movsd	%xmm0, 0x18(%rdx)
      1f: 48 c7 42 28 00 00 00 00      	movq	$0x0, 0x28(%rdx)
      27: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$move@AEAV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@@std@@YA$$QEAV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@0@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@AEAV1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@2345@AEAA?A_PI012@Z@@Z>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$move@AEAV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@@std@@YA$$QEAV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@0@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@AEAV1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@2345@AEAA?A_PI012@Z@@Z>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$move@AEAV<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@345@@Z@@std@@YA$$QEAV<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@345@@Z@AEAV1?1???$wait@H@2345@QEAA?A_P0@Z@@Z>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <class `public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::nextStep(void) const'::`2'::<lambda_1> && __cdecl std::move<class `public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::nextStep(void) const'::`2'::<lambda_1> &>(class `public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::nextStep(void) const'::`2'::<lambda_1> &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <class `public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::simulationSeconds(double) const'::`2'::<lambda_1> && __cdecl std::move<class `public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::simulationSeconds(double) const'::`2'::<lambda_1> &>(class `public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::simulationSeconds(double) const'::`2'::<lambda_1> &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <class lux::script::ScriptAbilityCompletion<void> && __cdecl std::move<class lux::script::ScriptAbilityCompletion<void> &>(class lux::script::ScriptAbilityCompletion<void> &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <class std::optional<struct lux::simulation::script::PreparedResumeType> && __cdecl std::move<class std::optional<struct lux::simulation::script::PreparedResumeType> &>(class std::optional<struct lux::simulation::script::PreparedResumeType> &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <class std::shared_ptr<void> && __cdecl std::move<class std::shared_ptr<void> &>(class std::shared_ptr<void> &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <class std::tuple<> && __cdecl std::move<class std::tuple<> &>(class std::tuple<> &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <class std::tuple<double> && __cdecl std::move<class std::tuple<double> &>(class std::tuple<double> &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <class lux::script::ScriptAbilityErasedCompletion && __cdecl std::move<class lux::script::ScriptAbilityErasedCompletion &>(class lux::script::ScriptAbilityErasedCompletion &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <class lux::simulation::script::ScriptAwaitableCompletion && __cdecl std::move<class lux::simulation::script::ScriptAwaitableCompletion &>(class lux::simulation::script::ScriptAwaitableCompletion &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <enum lux::simulation::script::EScriptAwaitableCreateError && __cdecl std::move<enum lux::simulation::script::EScriptAwaitableCreateError &>(enum lux::simulation::script::EScriptAwaitableCreateError &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <enum lux::simulation::script::EScriptEventWaitError && __cdecl std::move<enum lux::simulation::script::EScriptEventWaitError &>(enum lux::simulation::script::EScriptEventWaitError &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$read@$0A@@?$CppStaticOwnedArguments@AEBUValuePose@test@script@simulation@lux@@@detail@script@simulation@lux@@SA?A_TAEBUlux_script_call_frame@@PEAX@Z>:
       0: 48 8b 01                     	movq	(%rcx), %rax
       3: 48 8b 48 10                  	movq	0x10(%rax), %rcx
       7: 48 8b c2                     	movq	%rdx, %rax
       a: 0f 10 01                     	movups	(%rcx), %xmm0
       d: 0f 11 02                     	movups	%xmm0, (%rdx)
      10: 0f 10 49 10                  	movups	0x10(%rcx), %xmm1
      14: 0f 11 4a 10                  	movups	%xmm1, 0x10(%rdx)
      18: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <private: int __cdecl lux::simulation::script::ScriptCoroutine::promise_type::result<int>(void) const>:
       0: 48 8b 41 20                  	movq	0x20(%rcx), %rax
       4: 8b 00                        	movl	(%rax), %eax
       6: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: struct lux::simulation::script::ScriptStepResult __cdecl lux::simulation::script::PreparedLocalAsyncStart::startTyped<>(struct lux::simulation::script::ScriptStepContext &) const>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 40                  	subq	$0x40, %rsp
       6: 48 8b da                     	movq	%rdx, %rbx
       9: 48 8b 41 08                  	movq	0x8(%rcx), %rax
       d: 48 85 c0                     	testq	%rax, %rax
      10: 74 22                        	je	0x34 <public: struct lux::simulation::script::ScriptStepResult __cdecl lux::simulation::script::PreparedLocalAsyncStart::startTyped<>(struct lux::simulation::script::ScriptStepContext &) const+0x34>
      12: 0f 57 c0                     	xorps	%xmm0, %xmm0
      15: 66 0f 7f 44 24 20            	movdqa	%xmm0, 0x20(%rsp)
      1b: 4c 8d 4c 24 20               	leaq	0x20(%rsp), %r9
      20: 48 8b 11                     	movq	(%rcx), %rdx
      23: 48 8d 4c 24 30               	leaq	0x30(%rsp), %rcx
      28: ff d0                        	callq	*%rax
      2a: 0f 10 00                     	movups	(%rax), %xmm0
      2d: 0f 11 44 24 20               	movups	%xmm0, 0x20(%rsp)
      32: eb 1f                        	jmp	0x53 <public: struct lux::simulation::script::ScriptStepResult __cdecl lux::simulation::script::PreparedLocalAsyncStart::startTyped<>(struct lux::simulation::script::ScriptStepContext &) const+0x53>
      34: c6 44 24 20 02               	movb	$0x2, 0x20(%rsp)
      39: 33 c0                        	xorl	%eax, %eax
      3b: 48 89 44 24 24               	movq	%rax, 0x24(%rsp)
      40: c7 44 24 2c ff ff ff ff      	movl	$0xffffffff, 0x2c(%rsp) # imm = 0xFFFFFFFF
      48: 0f 28 44 24 20               	movaps	0x20(%rsp), %xmm0
      4d: 66 0f 7f 44 24 20            	movdqa	%xmm0, 0x20(%rsp)
      53: 48 8d 44 24 20               	leaq	0x20(%rsp), %rax
      58: 0f 10 00                     	movups	(%rax), %xmm0
      5b: 0f 11 03                     	movups	%xmm0, (%rbx)
      5e: 48 8b c3                     	movq	%rbx, %rax
      61: 48 83 c4 40                  	addq	$0x40, %rsp
      65: 5b                           	popq	%rbx
      66: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: struct lux::simulation::script::ScriptStepResult __cdecl lux::simulation::script::PreparedLocalAsyncStart::startTyped<double>(struct lux::simulation::script::ScriptStepContext &, double &) const>:
       0: 48 89 5c 24 20               	movq	%rbx, 0x20(%rsp)
       5: 57                           	pushq	%rdi
       6: 48 83 ec 60                  	subq	$0x60, %rsp
       a: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x11 <public: struct lux::simulation::script::ScriptStepResult __cdecl lux::simulation::script::PreparedLocalAsyncStart::startTyped<double>(struct lux::simulation::script::ScriptStepContext &, double &) const+0x11>
		000000000000000d:  IMAGE_REL_AMD64_REL32	__security_cookie
      11: 48 33 c4                     	xorq	%rsp, %rax
      14: 48 89 44 24 58               	movq	%rax, 0x58(%rsp)
      19: 4d 8b d8                     	movq	%r8, %r11
      1c: 48 8b da                     	movq	%rdx, %rbx
      1f: 4c 8b d1                     	movq	%rcx, %r10
      22: c6 44 24 40 07               	movb	$0x7, 0x40(%rsp)
      27: 33 c0                        	xorl	%eax, %eax
      29: 66 89 44 24 41               	movw	%ax, 0x41(%rsp)
      2e: 88 44 24 43                  	movb	%al, 0x43(%rsp)
      32: c7 44 24 44 08 00 00 00      	movl	$0x8, 0x44(%rsp)
      3a: 48 8b 15 00 00 00 00         	movq	(%rip), %rdx            # 0x41 <public: struct lux::simulation::script::ScriptStepResult __cdecl lux::simulation::script::PreparedLocalAsyncStart::startTyped<double>(struct lux::simulation::script::ScriptStepContext &, double &) const+0x41>
		000000000000003d:  IMAGE_REL_AMD64_REL32	?CanonicalName@?$TypeTraits@N@semantic@lux@@2V?$basic_string_view@DU?$char_traits@D@std@@@std@@B
      41: 48 b9 25 23 22 84 e4 9c f2 cb	movabsq	$-0x340d631b7bdddcdb, %rcx # imm = 0xCBF29CE484222325
      4b: 4c 8d 42 07                  	leaq	0x7(%rdx), %r8
      4f: 49 3b d0                     	cmpq	%r8, %rdx
      52: 74 1e                        	je	0x72 <public: struct lux::simulation::script::ScriptStepResult __cdecl lux::simulation::script::PreparedLocalAsyncStart::startTyped<double>(struct lux::simulation::script::ScriptStepContext &, double &) const+0x72>
      54: 48 bf b3 01 00 00 00 01 00 00	movabsq	$0x100000001b3, %rdi    # imm = 0x100000001B3
      5e: 66 90                        	nop
      60: 0f b6 02                     	movzbl	(%rdx), %eax
      63: 48 33 c8                     	xorq	%rax, %rcx
      66: 48 0f af cf                  	imulq	%rdi, %rcx
      6a: 48 ff c2                     	incq	%rdx
      6d: 49 3b d0                     	cmpq	%r8, %rdx
      70: 75 ee                        	jne	0x60 <public: struct lux::simulation::script::ScriptStepResult __cdecl lux::simulation::script::PreparedLocalAsyncStart::startTyped<double>(struct lux::simulation::script::ScriptStepContext &, double &) const+0x60>
      72: ba 01 00 00 00               	movl	$0x1, %edx
      77: 48 85 c9                     	testq	%rcx, %rcx
      7a: 48 0f 44 ca                  	cmoveq	%rdx, %rcx
      7e: 48 89 4c 24 48               	movq	%rcx, 0x48(%rsp)
      83: 4c 89 4c 24 50               	movq	%r9, 0x50(%rsp)
      88: 49 8b 42 08                  	movq	0x8(%r10), %rax
      8c: 48 85 c0                     	testq	%rax, %rax
      8f: 74 2b                        	je	0xbc <public: struct lux::simulation::script::ScriptStepResult __cdecl lux::simulation::script::PreparedLocalAsyncStart::startTyped<double>(struct lux::simulation::script::ScriptStepContext &, double &) const+0xbc>
      91: 48 8d 4c 24 40               	leaq	0x40(%rsp), %rcx
      96: 48 89 4c 24 20               	movq	%rcx, 0x20(%rsp)
      9b: 48 89 54 24 28               	movq	%rdx, 0x28(%rsp)
      a0: 4c 8d 4c 24 20               	leaq	0x20(%rsp), %r9
      a5: 4d 8b c3                     	movq	%r11, %r8
      a8: 49 8b 12                     	movq	(%r10), %rdx
      ab: 48 8d 4c 24 30               	leaq	0x30(%rsp), %rcx
      b0: ff d0                        	callq	*%rax
      b2: 0f 10 00                     	movups	(%rax), %xmm0
      b5: 0f 11 44 24 20               	movups	%xmm0, 0x20(%rsp)
      ba: eb 1f                        	jmp	0xdb <public: struct lux::simulation::script::ScriptStepResult __cdecl lux::simulation::script::PreparedLocalAsyncStart::startTyped<double>(struct lux::simulation::script::ScriptStepContext &, double &) const+0xdb>
      bc: c6 44 24 20 02               	movb	$0x2, 0x20(%rsp)
      c1: 33 c0                        	xorl	%eax, %eax
      c3: 48 89 44 24 24               	movq	%rax, 0x24(%rsp)
      c8: c7 44 24 2c ff ff ff ff      	movl	$0xffffffff, 0x2c(%rsp) # imm = 0xFFFFFFFF
      d0: 0f 28 44 24 20               	movaps	0x20(%rsp), %xmm0
      d5: 66 0f 7f 44 24 20            	movdqa	%xmm0, 0x20(%rsp)
      db: 48 8d 44 24 20               	leaq	0x20(%rsp), %rax
      e0: 0f 10 00                     	movups	(%rax), %xmm0
      e3: 0f 11 03                     	movups	%xmm0, (%rbx)
      e6: 48 8b c3                     	movq	%rbx, %rax
      e9: 48 8b 4c 24 58               	movq	0x58(%rsp), %rcx
      ee: 48 33 cc                     	xorq	%rsp, %rcx
      f1: e8 00 00 00 00               	callq	0xf6 <public: struct lux::simulation::script::ScriptStepResult __cdecl lux::simulation::script::PreparedLocalAsyncStart::startTyped<double>(struct lux::simulation::script::ScriptStepContext &, double &) const+0xf6>
		00000000000000f2:  IMAGE_REL_AMD64_REL32	__security_check_cookie
      f6: 48 8b 9c 24 88 00 00 00      	movq	0x88(%rsp), %rbx
      fe: 48 83 c4 60                  	addq	$0x60, %rsp
     102: 5f                           	popq	%rdi
     103: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$step@$$A6AXAEBUValuePose@test@script@simulation@lux@@@ZAEBU12345@@Tasks@cost@na1@simulation@lux@@SA?A_PAEAVScriptCoroutineContext@script@34@IAEBUValuePose@test@634@@Z>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 30                  	subq	$0x30, %rsp
       6: 48 8b d9                     	movq	%rcx, %rbx
       9: 4c 89 4c 24 40               	movq	%r9, 0x40(%rsp)
       e: 48 8b c2                     	movq	%rdx, %rax
      11: 48 c7 44 24 28 00 00 00 00   	movq	$0x0, 0x28(%rsp)
      1a: 48 8d 4c 24 40               	leaq	0x40(%rsp), %rcx
      1f: 48 8b d3                     	movq	%rbx, %rdx
      22: 48 89 4c 24 20               	movq	%rcx, 0x20(%rsp)
      27: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0x2e <??$step@$$A6AXAEBUValuePose@test@script@simulation@lux@@@ZAEBU12345@@Tasks@cost@na1@simulation@lux@@SA?A_PAEAVScriptCoroutineContext@script@34@IAEBUValuePose@test@634@@Z+0x2e>
		000000000000002a:  IMAGE_REL_AMD64_REL32	?Shape@?$ScriptSyncStepCall@$$A6AXAEBUValuePose@test@script@simulation@lux@@@Z@detail@script@simulation@lux@@2UScriptSyncStepShape@345@B
      2e: 48 8b c8                     	movq	%rax, %rcx
      31: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x37 <??$step@$$A6AXAEBUValuePose@test@script@simulation@lux@@@ZAEBU12345@@Tasks@cost@na1@simulation@lux@@SA?A_PAEAVScriptCoroutineContext@script@34@IAEBUValuePose@test@634@@Z+0x37>
		0000000000000033:  IMAGE_REL_AMD64_REL32	__imp_?invokeSyncStep@ScriptCoroutineContext@script@simulation@lux@@AEAA?AV?$expected@XUScriptSyncStepError@script@simulation@lux@@@tl@@IAEBUScriptSyncStepShape@234@PEBQEBXPEAX@Z
      37: 48 8b c3                     	movq	%rbx, %rax
      3a: 48 83 c4 30                  	addq	$0x30, %rsp
      3e: 5b                           	popq	%rbx
      3f: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$step@$$A6AXAEBUValuePose@test@script@simulation@lux@@H@ZAEBU12345@AEBH@Tasks@cost@na1@simulation@lux@@SA?A_PAEAVScriptCoroutineContext@script@34@IAEBUValuePose@test@634@AEBH@Z>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 40                  	subq	$0x40, %rsp
       6: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
       b: 4c 8b d2                     	movq	%rdx, %r10
       e: 48 89 44 24 38               	movq	%rax, 0x38(%rsp)
      13: 48 8b d9                     	movq	%rcx, %rbx
      16: 48 8d 44 24 30               	leaq	0x30(%rsp), %rax
      1b: 4c 89 4c 24 30               	movq	%r9, 0x30(%rsp)
      20: 48 8b d1                     	movq	%rcx, %rdx
      23: 48 c7 44 24 28 00 00 00 00   	movq	$0x0, 0x28(%rsp)
      2c: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0x33 <??$step@$$A6AXAEBUValuePose@test@script@simulation@lux@@H@ZAEBU12345@AEBH@Tasks@cost@na1@simulation@lux@@SA?A_PAEAVScriptCoroutineContext@script@34@IAEBUValuePose@test@634@AEBH@Z+0x33>
		000000000000002f:  IMAGE_REL_AMD64_REL32	?Shape@?$ScriptSyncStepCall@$$A6AXAEBUValuePose@test@script@simulation@lux@@H@Z@detail@script@simulation@lux@@2UScriptSyncStepShape@345@B
      33: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
      38: 49 8b ca                     	movq	%r10, %rcx
      3b: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x41 <??$step@$$A6AXAEBUValuePose@test@script@simulation@lux@@H@ZAEBU12345@AEBH@Tasks@cost@na1@simulation@lux@@SA?A_PAEAVScriptCoroutineContext@script@34@IAEBUValuePose@test@634@AEBH@Z+0x41>
		000000000000003d:  IMAGE_REL_AMD64_REL32	__imp_?invokeSyncStep@ScriptCoroutineContext@script@simulation@lux@@AEAA?AV?$expected@XUScriptSyncStepError@script@simulation@lux@@@tl@@IAEBUScriptSyncStepShape@234@PEBQEBXPEAX@Z
      41: 48 8b c3                     	movq	%rbx, %rax
      44: 48 83 c4 40                  	addq	$0x40, %rsp
      48: 5b                           	popq	%rbx
      49: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$step@$$A6AXH@ZAEBH@Tasks@cost@na1@simulation@lux@@SA?A_PAEAVScriptCoroutineContext@script@34@IAEBH@Z>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 30                  	subq	$0x30, %rsp
       6: 48 8b d9                     	movq	%rcx, %rbx
       9: 4c 89 4c 24 40               	movq	%r9, 0x40(%rsp)
       e: 48 8b c2                     	movq	%rdx, %rax
      11: 48 c7 44 24 28 00 00 00 00   	movq	$0x0, 0x28(%rsp)
      1a: 48 8d 4c 24 40               	leaq	0x40(%rsp), %rcx
      1f: 48 8b d3                     	movq	%rbx, %rdx
      22: 48 89 4c 24 20               	movq	%rcx, 0x20(%rsp)
      27: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0x2e <??$step@$$A6AXH@ZAEBH@Tasks@cost@na1@simulation@lux@@SA?A_PAEAVScriptCoroutineContext@script@34@IAEBH@Z+0x2e>
		000000000000002a:  IMAGE_REL_AMD64_REL32	?Shape@?$ScriptSyncStepCall@$$A6AXH@Z@detail@script@simulation@lux@@2UScriptSyncStepShape@345@B
      2e: 48 8b c8                     	movq	%rax, %rcx
      31: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x37 <??$step@$$A6AXH@ZAEBH@Tasks@cost@na1@simulation@lux@@SA?A_PAEAVScriptCoroutineContext@script@34@IAEBH@Z+0x37>
		0000000000000033:  IMAGE_REL_AMD64_REL32	__imp_?invokeSyncStep@ScriptCoroutineContext@script@simulation@lux@@AEAA?AV?$expected@XUScriptSyncStepError@script@simulation@lux@@@tl@@IAEBUScriptSyncStepShape@234@PEBQEBXPEAX@Z
      37: 48 8b c3                     	movq	%rbx, %rax
      3a: 48 83 c4 30                  	addq	$0x30, %rsp
      3e: 5b                           	popq	%rbx
      3f: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$step@$$A6AXXZ$$V@Tasks@cost@na1@simulation@lux@@SA?A_PAEAVScriptCoroutineContext@script@34@I@Z>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 30                  	subq	$0x30, %rsp
       6: 48 8b d9                     	movq	%rcx, %rbx
       9: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0x10 <??$step@$$A6AXXZ$$V@Tasks@cost@na1@simulation@lux@@SA?A_PAEAVScriptCoroutineContext@script@34@I@Z+0x10>
		000000000000000c:  IMAGE_REL_AMD64_REL32	?Shape@?$ScriptSyncStepCall@$$A6AXXZ@detail@script@simulation@lux@@2UScriptSyncStepShape@345@B
      10: 33 c9                        	xorl	%ecx, %ecx
      12: 48 8b c2                     	movq	%rdx, %rax
      15: 48 89 4c 24 28               	movq	%rcx, 0x28(%rsp)
      1a: 48 8b d3                     	movq	%rbx, %rdx
      1d: 48 89 4c 24 20               	movq	%rcx, 0x20(%rsp)
      22: 48 8b c8                     	movq	%rax, %rcx
      25: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x2b <??$step@$$A6AXXZ$$V@Tasks@cost@na1@simulation@lux@@SA?A_PAEAVScriptCoroutineContext@script@34@I@Z+0x2b>
		0000000000000027:  IMAGE_REL_AMD64_REL32	__imp_?invokeSyncStep@ScriptCoroutineContext@script@simulation@lux@@AEAA?AV?$expected@XUScriptSyncStepError@script@simulation@lux@@@tl@@IAEBUScriptSyncStepShape@234@PEBQEBXPEAX@Z
      2b: 48 8b c3                     	movq	%rbx, %rax
      2e: 48 83 c4 30                  	addq	$0x30, %rsp
      32: 5b                           	popq	%rbx
      33: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <private: struct lux::simulation::script::ScriptAwaitableId const & __cdecl tl::expected<struct lux::simulation::script::ScriptAwaitableId, enum lux::simulation::script::EScriptEventWaitError>::val<struct lux::simulation::script::ScriptAwaitableId, 0>(void) const>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static bool __cdecl lux::simulation::script::detail::CppStaticArguments<struct lux::simulation::script::test::ValuePose const &>::valid<0>(struct lux_script_call_frame const &, struct std::integer_sequence<unsigned __int64, 0>)>:
       0: 48 83 ec 28                  	subq	$0x28, %rsp
       4: 8b 51 08                     	movl	0x8(%rcx), %edx
       7: 85 d2                        	testl	%edx, %edx
       9: 74 0a                        	je	0x15 <public: static bool __cdecl lux::simulation::script::detail::CppStaticArguments<struct lux::simulation::script::test::ValuePose const &>::valid<0>(struct lux_script_call_frame const &, struct std::integer_sequence<unsigned __int64, 0>)+0x15>
       b: 48 83 39 00                  	cmpq	$0x0, (%rcx)
       f: 75 04                        	jne	0x15 <public: static bool __cdecl lux::simulation::script::detail::CppStaticArguments<struct lux::simulation::script::test::ValuePose const &>::valid<0>(struct lux_script_call_frame const &, struct std::integer_sequence<unsigned __int64, 0>)+0x15>
      11: b0 01                        	movb	$0x1, %al
      13: eb 02                        	jmp	0x17 <public: static bool __cdecl lux::simulation::script::detail::CppStaticArguments<struct lux::simulation::script::test::ValuePose const &>::valid<0>(struct lux_script_call_frame const &, struct std::integer_sequence<unsigned __int64, 0>)+0x17>
      15: 32 c0                        	xorb	%al, %al
      17: 83 fa 01                     	cmpl	$0x1, %edx
      1a: 75 17                        	jne	0x33 <public: static bool __cdecl lux::simulation::script::detail::CppStaticArguments<struct lux::simulation::script::test::ValuePose const &>::valid<0>(struct lux_script_call_frame const &, struct std::integer_sequence<unsigned __int64, 0>)+0x33>
      1c: 84 c0                        	testb	%al, %al
      1e: 75 13                        	jne	0x33 <public: static bool __cdecl lux::simulation::script::detail::CppStaticArguments<struct lux::simulation::script::test::ValuePose const &>::valid<0>(struct lux_script_call_frame const &, struct std::integer_sequence<unsigned __int64, 0>)+0x33>
      20: 48 8b 09                     	movq	(%rcx), %rcx
      23: e8 00 00 00 00               	callq	0x28 <public: static bool __cdecl lux::simulation::script::detail::CppStaticArguments<struct lux::simulation::script::test::ValuePose const &>::valid<0>(struct lux_script_call_frame const &, struct std::integer_sequence<unsigned __int64, 0>)+0x28>
		0000000000000024:  IMAGE_REL_AMD64_REL32	??$cppStaticSlotMatches@AEBUValuePose@test@script@simulation@lux@@@detail@script@simulation@lux@@YA_NAEBUlux_script_value_slot@@@Z
      28: 84 c0                        	testb	%al, %al
      2a: 74 07                        	je	0x33 <public: static bool __cdecl lux::simulation::script::detail::CppStaticArguments<struct lux::simulation::script::test::ValuePose const &>::valid<0>(struct lux_script_call_frame const &, struct std::integer_sequence<unsigned __int64, 0>)+0x33>
      2c: b0 01                        	movb	$0x1, %al
      2e: 48 83 c4 28                  	addq	$0x28, %rsp
      32: c3                           	retq
      33: 32 c0                        	xorb	%al, %al
      35: 48 83 c4 28                  	addq	$0x28, %rsp
      39: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static bool __cdecl lux::simulation::script::detail::CppStaticArguments<>::valid<>(struct lux_script_call_frame const &, struct std::integer_sequence<unsigned __int64>)>:
       0: 8b 41 08                     	movl	0x8(%rcx), %eax
       3: 85 c0                        	testl	%eax, %eax
       5: 74 0a                        	je	0x11 <public: static bool __cdecl lux::simulation::script::detail::CppStaticArguments<>::valid<>(struct lux_script_call_frame const &, struct std::integer_sequence<unsigned __int64>)+0x11>
       7: 48 83 39 00                  	cmpq	$0x0, (%rcx)
       b: 74 07                        	je	0x14 <public: static bool __cdecl lux::simulation::script::detail::CppStaticArguments<>::valid<>(struct lux_script_call_frame const &, struct std::integer_sequence<unsigned __int64>)+0x14>
       d: 85 c0                        	testl	%eax, %eax
       f: 75 03                        	jne	0x14 <public: static bool __cdecl lux::simulation::script::detail::CppStaticArguments<>::valid<>(struct lux_script_call_frame const &, struct std::integer_sequence<unsigned __int64>)+0x14>
      11: b0 01                        	movb	$0x1, %al
      13: c3                           	retq
      14: 32 c0                        	xorb	%al, %al
      16: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@123@@Z>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 30                  	subq	$0x30, %rsp
       6: 49 8b 00                     	movq	(%r8), %rax
       9: 48 8b da                     	movq	%rdx, %rbx
       c: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
      11: 41 8b 40 08                  	movl	0x8(%r8), %eax
      15: 4c 8d 44 24 20               	leaq	0x20(%rsp), %r8
      1a: 89 44 24 28                  	movl	%eax, 0x28(%rsp)
      1e: 0f 28 44 24 20               	movaps	0x20(%rsp), %xmm0
      23: 66 0f 7f 44 24 20            	movdqa	%xmm0, 0x20(%rsp)
      29: e8 00 00 00 00               	callq	0x2e <??$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@123@@Z+0x2e>
		000000000000002a:  IMAGE_REL_AMD64_REL32	??$makeAwaiter@HV<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@345@@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PV<lambda_1>@?1???$wait@H@0123@QEAA?A_PAEBV?$CppScriptEventSource@H@123@@Z@@Z
      2e: 48 8b c3                     	movq	%rbx, %rax
      31: 48 83 c4 30                  	addq	$0x30, %rsp
      35: 5b                           	popq	%rbx
      36: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??0<lambda_1>@?1???$?R$$V@0?1???R0?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@$$V@std@@V0?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@XZ@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z@QEBA?A_PXZ@QEAA@AEAV0?1??9?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@XZ@AEAUScriptCoroutineAbilityAccess@detail@234@@Z>:
       0: 48 89 11                     	movq	%rdx, (%rcx)
       3: 48 8b c1                     	movq	%rcx, %rax
       6: 4c 89 41 08                  	movq	%r8, 0x8(%rcx)
       a: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??0<lambda_1>@?1???$?RN@0?1???R0?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@N@std@@V0?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@N@Z@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z@QEBA?A_PAEAN@Z@QEAA@AEAV0?1??9?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@N@Z@AEAUScriptCoroutineAbilityAccess@detail@234@5@Z>:
       0: 48 89 11                     	movq	%rdx, (%rcx)
       3: 48 8b c1                     	movq	%rcx, %rax
       6: 4c 89 41 08                  	movq	%r8, 0x8(%rcx)
       a: 4c 89 49 10                  	movq	%r9, 0x10(%rcx)
       e: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??0<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@$$V@std@@V0?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@XZ@@Z@QEAA@$$QEAV0?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@1234@AEAA?A_PI012@Z@@Z>:
       0: 8b 02                        	movl	(%rdx), %eax
       2: 89 01                        	movl	%eax, (%rcx)
       4: 48 8b 42 08                  	movq	0x8(%rdx), %rax
       8: 48 89 41 08                  	movq	%rax, 0x8(%rcx)
       c: 48 8b c1                     	movq	%rcx, %rax
       f: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??0<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@$$V@std@@V0?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@XZ@@Z@QEAA@AEBIPEBV564@$$QEAV78@$$QEAV0?1??9?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@XZ@@Z>:
       0: 8b 02                        	movl	(%rdx), %eax
       2: 89 01                        	movl	%eax, (%rcx)
       4: 48 8b c1                     	movq	%rcx, %rax
       7: 4c 89 41 08                  	movq	%r8, 0x8(%rcx)
       b: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??0<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@N@std@@V0?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@N@Z@@Z@QEAA@$$QEAV0?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@1234@AEAA?A_PI012@Z@@Z>:
       0: 8b 02                        	movl	(%rdx), %eax
       2: 89 01                        	movl	%eax, (%rcx)
       4: 48 8b 42 08                  	movq	0x8(%rdx), %rax
       8: 48 89 41 08                  	movq	%rax, 0x8(%rcx)
       c: 48 8b c1                     	movq	%rcx, %rax
       f: f2 0f 10 42 10               	movsd	0x10(%rdx), %xmm0
      14: f2 0f 11 41 10               	movsd	%xmm0, 0x10(%rcx)
      19: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??0<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@N@std@@V0?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@N@Z@@Z@QEAA@AEBIPEBV564@$$QEAV78@$$QEAV0?1??9?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@N@Z@@Z>:
       0: 8b 02                        	movl	(%rdx), %eax
       2: 89 01                        	movl	%eax, (%rcx)
       4: 48 8b c1                     	movq	%rcx, %rax
       7: 4c 89 41 08                  	movq	%r8, 0x8(%rcx)
       b: f2 41 0f 10 01               	movsd	(%r9), %xmm0
      10: f2 0f 11 41 10               	movsd	%xmm0, 0x10(%rcx)
      15: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??0<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@234@@Z@QEAA@PEBUCppStaticContract@234@I@Z>:
       0: 48 89 11                     	movq	%rdx, (%rcx)
       3: 48 8b c1                     	movq	%rcx, %rax
       6: 44 89 41 08                  	movl	%r8d, 0x8(%rcx)
       a: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??0<lambda_1>@?1???R0?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@$$V@std@@V0?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@XZ@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z@QEAA@4AEBVPreparedLocalAsyncStart@234@AEAV0?1??9?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@XZ@AEAUScriptCoroutineAbilityAccess@detail@234@@Z>:
       0: 48 8b 44 24 28               	movq	0x28(%rsp), %rax
       5: 48 89 41 18                  	movq	%rax, 0x18(%rcx)
       9: 48 8b c1                     	movq	%rcx, %rax
       c: 48 89 11                     	movq	%rdx, (%rcx)
       f: 4c 89 41 08                  	movq	%r8, 0x8(%rcx)
      13: 4c 89 49 10                  	movq	%r9, 0x10(%rcx)
      17: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??0<lambda_1>@?1???R0?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@N@std@@V0?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@N@Z@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z@QEAA@4AEBVPreparedLocalAsyncStart@234@AEAV0?1??9?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@N@Z@AEAUScriptCoroutineAbilityAccess@detail@234@@Z>:
       0: 48 8b 44 24 28               	movq	0x28(%rsp), %rax
       5: 48 89 41 18                  	movq	%rax, 0x18(%rcx)
       9: 48 8b c1                     	movq	%rcx, %rax
       c: 48 89 11                     	movq	%rdx, (%rcx)
       f: 4c 89 41 08                  	movq	%r8, 0x8(%rcx)
      13: 4c 89 49 10                  	movq	%r9, 0x10(%rcx)
      17: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl `public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::event(class lux::simulation::script::ScriptCoroutineContext &)'::`5'::<parameters>::<parameters>(struct lux::simulation::na1::cost::Tasks *, class lux::simulation::script::ScriptCoroutineContext &)>:
       0: 48 89 11                     	movq	%rdx, (%rcx)
       3: 48 8b c1                     	movq	%rcx, %rax
       6: 4c 89 41 08                  	movq	%r8, 0x8(%rcx)
       a: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl `public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::longTask(class lux::simulation::script::ScriptCoroutineContext &)'::`7'::<parameters>::<parameters>(struct lux::simulation::na1::cost::Tasks *, class lux::simulation::script::ScriptCoroutineContext &)>:
       0: 48 89 11                     	movq	%rdx, (%rcx)
       3: 48 8b c1                     	movq	%rcx, %rax
       6: 4c 89 41 08                  	movq	%r8, 0x8(%rcx)
       a: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl `public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::next(class lux::simulation::script::ScriptCoroutineContext &)'::`7'::<parameters>::<parameters>(struct lux::simulation::na1::cost::Tasks *, class lux::simulation::script::ScriptCoroutineContext &)>:
       0: 48 89 11                     	movq	%rdx, (%rcx)
       3: 48 8b c1                     	movq	%rcx, %rax
       6: 4c 89 41 08                  	movq	%r8, 0x8(%rcx)
       a: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl `public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::pose(class lux::simulation::script::ScriptCoroutineContext &, struct lux::simulation::script::test::ValuePose const &)'::`7'::<parameters>::<parameters>(struct lux::simulation::na1::cost::Tasks *, class lux::simulation::script::ScriptCoroutineContext &, struct lux::simulation::script::test::ValuePose const &)>:
       0: 48 89 11                     	movq	%rdx, (%rcx)
       3: 48 8b c1                     	movq	%rcx, %rax
       6: 4c 89 41 08                  	movq	%r8, 0x8(%rcx)
       a: 4c 89 49 10                  	movq	%r9, 0x10(%rcx)
       e: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl `public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::sequence(class lux::simulation::script::ScriptCoroutineContext &)'::`7'::<parameters>::<parameters>(struct lux::simulation::na1::cost::Tasks *, class lux::simulation::script::ScriptCoroutineContext &)>:
       0: 48 89 11                     	movq	%rdx, (%rcx)
       3: 48 8b c1                     	movq	%rcx, %rax
       6: 4c 89 41 08                  	movq	%r8, 0x8(%rcx)
       a: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl lux::cxx::ScopeId<struct lux::simulation::script::ScriptEventAdmissionScopeTag>::ScopeId<struct lux::simulation::script::ScriptEventAdmissionScopeTag>(void)>:
       0: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
       7: 48 8b c1                     	movq	%rcx, %rax
       a: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <private: __cdecl lux::script::ScriptAbilityCompletion<void>::ScriptAbilityCompletion<void>(class lux::script::ScriptAbilityErasedCompletion)>:
       0: 48 89 5c 24 10               	movq	%rbx, 0x10(%rsp)
       5: 57                           	pushq	%rdi
       6: 48 83 ec 20                  	subq	$0x20, %rsp
       a: 48 8b f9                     	movq	%rcx, %rdi
       d: 33 c9                        	xorl	%ecx, %ecx
       f: 48 89 0f                     	movq	%rcx, (%rdi)
      12: 48 89 4f 08                  	movq	%rcx, 0x8(%rdi)
      16: 48 8b 02                     	movq	(%rdx), %rax
      19: 48 89 07                     	movq	%rax, (%rdi)
      1c: 48 8b 42 08                  	movq	0x8(%rdx), %rax
      20: 48 89 47 08                  	movq	%rax, 0x8(%rdi)
      24: 48 89 0a                     	movq	%rcx, (%rdx)
      27: 48 89 4a 08                  	movq	%rcx, 0x8(%rdx)
      2b: 48 8b 42 10                  	movq	0x10(%rdx), %rax
      2f: 48 89 47 10                  	movq	%rax, 0x10(%rdi)
      33: 48 8b 42 18                  	movq	0x18(%rdx), %rax
      37: 48 89 47 18                  	movq	%rax, 0x18(%rdi)
      3b: 48 8b 42 20                  	movq	0x20(%rdx), %rax
      3f: 48 89 47 20                  	movq	%rax, 0x20(%rdi)
      43: 48 8b 42 28                  	movq	0x28(%rdx), %rax
      47: 48 89 47 28                  	movq	%rax, 0x28(%rdi)
      4b: 48 8b 42 30                  	movq	0x30(%rdx), %rax
      4f: 48 89 47 30                  	movq	%rax, 0x30(%rdi)
      53: 48 8b 42 38                  	movq	0x38(%rdx), %rax
      57: 48 89 47 38                  	movq	%rax, 0x38(%rdi)
      5b: 48 8b 42 40                  	movq	0x40(%rdx), %rax
      5f: 48 89 47 40                  	movq	%rax, 0x40(%rdi)
      63: 48 8b 42 48                  	movq	0x48(%rdx), %rax
      67: 48 89 47 48                  	movq	%rax, 0x48(%rdi)
      6b: 48 8b 42 50                  	movq	0x50(%rdx), %rax
      6f: 48 89 47 50                  	movq	%rax, 0x50(%rdi)
      73: 48 8b 5a 08                  	movq	0x8(%rdx), %rbx
      77: 48 85 db                     	testq	%rbx, %rbx
      7a: 74 44                        	je	0xc0 <private: __cdecl lux::script::ScriptAbilityCompletion<void>::ScriptAbilityCompletion<void>(class lux::script::ScriptAbilityErasedCompletion)+0xc0>
      7c: 48 89 74 24 30               	movq	%rsi, 0x30(%rsp)
      81: be ff ff ff ff               	movl	$0xffffffff, %esi       # imm = 0xFFFFFFFF
      86: 8b c6                        	movl	%esi, %eax
      88: f0                           	lock
      89: 0f c1 43 08                  	xaddl	%eax, 0x8(%rbx)
      8d: 83 f8 01                     	cmpl	$0x1, %eax
      90: 75 1b                        	jne	0xad <private: __cdecl lux::script::ScriptAbilityCompletion<void>::ScriptAbilityCompletion<void>(class lux::script::ScriptAbilityErasedCompletion)+0xad>
      92: 48 8b 03                     	movq	(%rbx), %rax
      95: 48 8b cb                     	movq	%rbx, %rcx
      98: ff 10                        	callq	*(%rax)
      9a: f0                           	lock
      9b: 0f c1 73 0c                  	xaddl	%esi, 0xc(%rbx)
      9f: 83 fe 01                     	cmpl	$0x1, %esi
      a2: 75 09                        	jne	0xad <private: __cdecl lux::script::ScriptAbilityCompletion<void>::ScriptAbilityCompletion<void>(class lux::script::ScriptAbilityErasedCompletion)+0xad>
      a4: 48 8b 03                     	movq	(%rbx), %rax
      a7: 48 8b cb                     	movq	%rbx, %rcx
      aa: ff 50 08                     	callq	*0x8(%rax)
      ad: 48 8b 74 24 30               	movq	0x30(%rsp), %rsi
      b2: 48 8b c7                     	movq	%rdi, %rax
      b5: 48 8b 5c 24 38               	movq	0x38(%rsp), %rbx
      ba: 48 83 c4 20                  	addq	$0x20, %rsp
      be: 5f                           	popq	%rdi
      bf: c3                           	retq
      c0: 48 8b 5c 24 38               	movq	0x38(%rsp), %rbx
      c5: 48 8b c7                     	movq	%rdi, %rax
      c8: 48 83 c4 20                  	addq	$0x20, %rsp
      cc: 5f                           	popq	%rdi
      cd: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl lux::script::ScriptAbilityCompletion<void>::ScriptAbilityCompletion<void>(class lux::script::ScriptAbilityCompletion<void> &&)>:
       0: 45 33 c0                     	xorl	%r8d, %r8d
       3: 4c 89 01                     	movq	%r8, (%rcx)
       6: 4c 89 41 08                  	movq	%r8, 0x8(%rcx)
       a: 48 8b 02                     	movq	(%rdx), %rax
       d: 48 89 01                     	movq	%rax, (%rcx)
      10: 48 8b 42 08                  	movq	0x8(%rdx), %rax
      14: 48 89 41 08                  	movq	%rax, 0x8(%rcx)
      18: 4c 89 02                     	movq	%r8, (%rdx)
      1b: 4c 89 42 08                  	movq	%r8, 0x8(%rdx)
      1f: 48 8b 42 10                  	movq	0x10(%rdx), %rax
      23: 48 89 41 10                  	movq	%rax, 0x10(%rcx)
      27: 48 8b 42 18                  	movq	0x18(%rdx), %rax
      2b: 48 89 41 18                  	movq	%rax, 0x18(%rcx)
      2f: 48 8b 42 20                  	movq	0x20(%rdx), %rax
      33: 48 89 41 20                  	movq	%rax, 0x20(%rcx)
      37: 48 8b 42 28                  	movq	0x28(%rdx), %rax
      3b: 48 89 41 28                  	movq	%rax, 0x28(%rcx)
      3f: 48 8b 42 30                  	movq	0x30(%rdx), %rax
      43: 48 89 41 30                  	movq	%rax, 0x30(%rcx)
      47: 48 8b 42 38                  	movq	0x38(%rdx), %rax
      4b: 48 89 41 38                  	movq	%rax, 0x38(%rcx)
      4f: 48 8b 42 40                  	movq	0x40(%rdx), %rax
      53: 48 89 41 40                  	movq	%rax, 0x40(%rcx)
      57: 48 8b 42 48                  	movq	0x48(%rdx), %rax
      5b: 48 89 41 48                  	movq	%rax, 0x48(%rcx)
      5f: 48 8b 42 50                  	movq	0x50(%rdx), %rax
      63: 48 89 41 50                  	movq	%rax, 0x50(%rcx)
      67: 48 8b c1                     	movq	%rcx, %rax
      6a: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??0?$ScriptCoroutineAwaiter@HV<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@345@@Z@@script@simulation@lux@@QEAA@AEAVScriptCoroutineContext@123@V<lambda_1>@?1???$wait@H@4123@QEAA?A_PAEBV?$CppScriptEventSource@H@123@@Z@@Z>:
       0: 41 0f 10 00                  	movups	(%r8), %xmm0
       4: 48 89 11                     	movq	%rdx, (%rcx)
       7: 48 8b c1                     	movq	%rcx, %rax
       a: 48 c7 41 18 00 00 00 00      	movq	$0x0, 0x18(%rcx)
      12: 0f 11 41 08                  	movups	%xmm0, 0x8(%rcx)
      16: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??0?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@@script@simulation@lux@@QEAA@AEAVScriptCoroutineContext@123@V<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@4123@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@3@V?$tuple@$$V@std@@V5?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@13@QEBA@XZ@@Z@@Z>:
       0: 48 89 11                     	movq	%rdx, (%rcx)
       3: 41 8b 00                     	movl	(%r8), %eax
       6: 89 41 08                     	movl	%eax, 0x8(%rcx)
       9: 49 8b 40 08                  	movq	0x8(%r8), %rax
       d: 48 89 41 10                  	movq	%rax, 0x10(%rcx)
      11: 48 8b c1                     	movq	%rcx, %rax
      14: 48 c7 41 20 00 00 00 00      	movq	$0x0, 0x20(%rcx)
      1c: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??0?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@@script@simulation@lux@@QEAA@AEAVScriptCoroutineContext@123@V<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@4123@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@3@V?$tuple@N@std@@V5?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@13@QEBA@N@Z@@Z@@Z>:
       0: 48 89 11                     	movq	%rdx, (%rcx)
       3: 41 8b 00                     	movl	(%r8), %eax
       6: 89 41 08                     	movl	%eax, 0x8(%rcx)
       9: 49 8b 40 08                  	movq	0x8(%r8), %rax
       d: 48 89 41 10                  	movq	%rax, 0x10(%rcx)
      11: 48 8b c1                     	movq	%rcx, %rax
      14: f2 41 0f 10 40 10            	movsd	0x10(%r8), %xmm0
      1a: f2 0f 11 41 18               	movsd	%xmm0, 0x18(%rcx)
      1f: 48 c7 41 28 00 00 00 00      	movq	$0x0, 0x28(%rcx)
      27: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl std::_Optional_construct_base<struct lux::simulation::script::PreparedResumeType>::_Optional_construct_base<struct lux::simulation::script::PreparedResumeType>(void)>:
       0: c6 41 18 00                  	movb	$0x0, 0x18(%rcx)
       4: 48 8b c1                     	movq	%rcx, %rax
       7: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl std::_Optional_destruct_base<struct lux::simulation::script::PreparedResumeType, 1>::_Optional_destruct_base<struct lux::simulation::script::PreparedResumeType, 1>(void)>:
       0: c6 41 18 00                  	movb	$0x0, 0x18(%rcx)
       4: 48 8b c1                     	movq	%rcx, %rax
       7: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <protected: __cdecl std::_Ptr_base<void>::_Ptr_base<void>(void)>:
       0: 33 c0                        	xorl	%eax, %eax
       2: 48 89 01                     	movq	%rax, (%rcx)
       5: 48 89 41 08                  	movq	%rax, 0x8(%rcx)
       9: 48 8b c1                     	movq	%rcx, %rax
       c: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl std::_Span_extent_type<struct lux_script_value_slot const, -1>::_Span_extent_type<struct lux_script_value_slot const, -1>(struct lux_script_value_slot const *const, unsigned __int64)>:
       0: 48 89 11                     	movq	%rdx, (%rcx)
       3: 48 8b c1                     	movq	%rcx, %rax
       6: 4c 89 41 08                  	movq	%r8, 0x8(%rcx)
       a: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl std::coroutine_handle<struct lux::simulation::script::ScriptCoroutine::promise_type>::coroutine_handle<struct lux::simulation::script::ScriptCoroutine::promise_type>(void)>:
       0: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
       7: 48 8b c1                     	movq	%rcx, %rax
       a: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl std::coroutine_handle<void>::coroutine_handle<void>(void)>:
       0: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
       7: 48 8b c1                     	movq	%rcx, %rax
       a: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::detail::expected_default_ctor_base<struct lux::simulation::script::ScriptAwaitableId, enum lux::simulation::script::EScriptEventWaitError, 1>::expected_default_ctor_base<struct lux::simulation::script::ScriptAwaitableId, enum lux::simulation::script::EScriptEventWaitError, 1>(struct tl::detail::default_constructor_tag)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::detail::expected_default_ctor_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 1>::expected_default_ctor_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 1>(struct tl::detail::default_constructor_tag)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl std::optional<struct lux::simulation::script::PreparedResumeType>::optional<struct lux::simulation::script::PreparedResumeType>(void)>:
       0: c6 41 18 00                  	movb	$0x0, 0x18(%rcx)
       4: 48 8b c1                     	movq	%rcx, %rax
       7: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl std::shared_ptr<void>::shared_ptr<void>(class std::shared_ptr<void> &&)>:
       0: 45 33 c0                     	xorl	%r8d, %r8d
       3: 4c 89 01                     	movq	%r8, (%rcx)
       6: 4c 89 41 08                  	movq	%r8, 0x8(%rcx)
       a: 48 8b 02                     	movq	(%rdx), %rax
       d: 48 89 01                     	movq	%rax, (%rcx)
      10: 48 8b 42 08                  	movq	0x8(%rdx), %rax
      14: 48 89 41 08                  	movq	%rax, 0x8(%rcx)
      18: 48 8b c1                     	movq	%rcx, %rax
      1b: 4c 89 02                     	movq	%r8, (%rdx)
      1e: 4c 89 42 08                  	movq	%r8, 0x8(%rdx)
      22: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl std::tuple<>::tuple<>(class std::tuple<> const &)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl std::tuple<double>::tuple<double>(class std::tuple<double> &&)>:
       0: f2 0f 10 02                  	movsd	(%rdx), %xmm0
       4: 48 8b c1                     	movq	%rcx, %rax
       7: f2 0f 11 01                  	movsd	%xmm0, (%rcx)
       b: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::unexpected<enum lux::simulation::script::EScriptAwaitableCreateError>::unexpected<enum lux::simulation::script::EScriptAwaitableCreateError>(enum lux::simulation::script::EScriptAwaitableCreateError &&)>:
       0: 0f b6 02                     	movzbl	(%rdx), %eax
       3: 88 01                        	movb	%al, (%rcx)
       5: 48 8b c1                     	movq	%rcx, %rax
       8: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::unexpected<enum lux::simulation::script::EScriptEventWaitError>::unexpected<enum lux::simulation::script::EScriptEventWaitError>(enum lux::simulation::script::EScriptEventWaitError &&)>:
       0: 0f b6 02                     	movzbl	(%rdx), %eax
       3: 88 01                        	movb	%al, (%rcx)
       5: 48 8b c1                     	movq	%rcx, %rax
       8: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl lux::simulation::script::PreparedLocalAsyncCatalog::PreparedLocalAsyncCatalog(void)>:
       0: 33 c0                        	xorl	%eax, %eax
       2: 48 89 01                     	movq	%rax, (%rcx)
       5: 48 89 41 08                  	movq	%rax, 0x8(%rcx)
       9: 48 89 41 10                  	movq	%rax, 0x10(%rcx)
       d: 48 8b c1                     	movq	%rcx, %rax
      10: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl lux::simulation::script::PreparedLocalAsyncStart::PreparedLocalAsyncStart(void)>:
       0: 33 c0                        	xorl	%eax, %eax
       2: 48 89 01                     	movq	%rax, (%rcx)
       5: 48 89 41 08                  	movq	%rax, 0x8(%rcx)
       9: 88 41 10                     	movb	%al, 0x10(%rcx)
       c: 48 8b c1                     	movq	%rcx, %rax
       f: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <private: __cdecl lux::script::ScriptAbilityErasedCompletion::ScriptAbilityErasedCompletion(class std::shared_ptr<void>, void *, unsigned __int64, unsigned __int64, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, unsigned __int64, void const *, unsigned int) noexcept, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, struct lux::script::ScriptAbilityOperationError) noexcept, bool (__cdecl *)(void *, unsigned __int64, unsigned __int64) noexcept, void *, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, unsigned __int64, void const *, unsigned int) noexcept, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, struct lux::script::ScriptAbilityOperationError) noexcept)>:
       0: 48 89 5c 24 10               	movq	%rbx, 0x10(%rsp)
       5: 57                           	pushq	%rdi
       6: 48 83 ec 20                  	subq	$0x20, %rsp
       a: 48 8b f9                     	movq	%rcx, %rdi
       d: 33 c9                        	xorl	%ecx, %ecx
       f: 48 89 0f                     	movq	%rcx, (%rdi)
      12: 48 89 4f 08                  	movq	%rcx, 0x8(%rdi)
      16: 48 8b 02                     	movq	(%rdx), %rax
      19: 48 89 07                     	movq	%rax, (%rdi)
      1c: 48 8b 42 08                  	movq	0x8(%rdx), %rax
      20: 48 89 47 08                  	movq	%rax, 0x8(%rdi)
      24: 48 8b 44 24 50               	movq	0x50(%rsp), %rax
      29: 48 89 4a 08                  	movq	%rcx, 0x8(%rdx)
      2d: 48 89 0a                     	movq	%rcx, (%rdx)
      30: 48 89 47 20                  	movq	%rax, 0x20(%rdi)
      34: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
      39: 48 89 47 28                  	movq	%rax, 0x28(%rdi)
      3d: 48 8b 44 24 60               	movq	0x60(%rsp), %rax
      42: 48 89 47 30                  	movq	%rax, 0x30(%rdi)
      46: 48 8b 44 24 68               	movq	0x68(%rsp), %rax
      4b: 48 89 47 38                  	movq	%rax, 0x38(%rdi)
      4f: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
      54: 48 89 47 40                  	movq	%rax, 0x40(%rdi)
      58: 48 8b 44 24 78               	movq	0x78(%rsp), %rax
      5d: 48 89 47 48                  	movq	%rax, 0x48(%rdi)
      61: 48 8b 84 24 80 00 00 00      	movq	0x80(%rsp), %rax
      69: 48 89 47 50                  	movq	%rax, 0x50(%rdi)
      6d: 4c 89 47 10                  	movq	%r8, 0x10(%rdi)
      71: 4c 89 4f 18                  	movq	%r9, 0x18(%rdi)
      75: 48 8b 5a 08                  	movq	0x8(%rdx), %rbx
      79: 48 85 db                     	testq	%rbx, %rbx
      7c: 74 44                        	je	0xc2 <private: __cdecl lux::script::ScriptAbilityErasedCompletion::ScriptAbilityErasedCompletion(class std::shared_ptr<void>, void *, unsigned __int64, unsigned __int64, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, unsigned __int64, void const *, unsigned int) noexcept, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, struct lux::script::ScriptAbilityOperationError) noexcept, bool (__cdecl *)(void *, unsigned __int64, unsigned __int64) noexcept, void *, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, unsigned __int64, void const *, unsigned int) noexcept, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, struct lux::script::ScriptAbilityOperationError) noexcept)+0xc2>
      7e: 48 89 74 24 30               	movq	%rsi, 0x30(%rsp)
      83: be ff ff ff ff               	movl	$0xffffffff, %esi       # imm = 0xFFFFFFFF
      88: 8b c6                        	movl	%esi, %eax
      8a: f0                           	lock
      8b: 0f c1 43 08                  	xaddl	%eax, 0x8(%rbx)
      8f: 83 f8 01                     	cmpl	$0x1, %eax
      92: 75 1b                        	jne	0xaf <private: __cdecl lux::script::ScriptAbilityErasedCompletion::ScriptAbilityErasedCompletion(class std::shared_ptr<void>, void *, unsigned __int64, unsigned __int64, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, unsigned __int64, void const *, unsigned int) noexcept, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, struct lux::script::ScriptAbilityOperationError) noexcept, bool (__cdecl *)(void *, unsigned __int64, unsigned __int64) noexcept, void *, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, unsigned __int64, void const *, unsigned int) noexcept, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, struct lux::script::ScriptAbilityOperationError) noexcept)+0xaf>
      94: 48 8b 03                     	movq	(%rbx), %rax
      97: 48 8b cb                     	movq	%rbx, %rcx
      9a: ff 10                        	callq	*(%rax)
      9c: f0                           	lock
      9d: 0f c1 73 0c                  	xaddl	%esi, 0xc(%rbx)
      a1: 83 fe 01                     	cmpl	$0x1, %esi
      a4: 75 09                        	jne	0xaf <private: __cdecl lux::script::ScriptAbilityErasedCompletion::ScriptAbilityErasedCompletion(class std::shared_ptr<void>, void *, unsigned __int64, unsigned __int64, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, unsigned __int64, void const *, unsigned int) noexcept, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, struct lux::script::ScriptAbilityOperationError) noexcept, bool (__cdecl *)(void *, unsigned __int64, unsigned __int64) noexcept, void *, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, unsigned __int64, void const *, unsigned int) noexcept, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, struct lux::script::ScriptAbilityOperationError) noexcept)+0xaf>
      a6: 48 8b 03                     	movq	(%rbx), %rax
      a9: 48 8b cb                     	movq	%rbx, %rcx
      ac: ff 50 08                     	callq	*0x8(%rax)
      af: 48 8b 74 24 30               	movq	0x30(%rsp), %rsi
      b4: 48 8b c7                     	movq	%rdi, %rax
      b7: 48 8b 5c 24 38               	movq	0x38(%rsp), %rbx
      bc: 48 83 c4 20                  	addq	$0x20, %rsp
      c0: 5f                           	popq	%rdi
      c1: c3                           	retq
      c2: 48 8b 5c 24 38               	movq	0x38(%rsp), %rbx
      c7: 48 8b c7                     	movq	%rdi, %rax
      ca: 48 83 c4 20                  	addq	$0x20, %rsp
      ce: 5f                           	popq	%rdi
      cf: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl lux::script::ScriptAbilityErasedCompletion::ScriptAbilityErasedCompletion(class lux::script::ScriptAbilityErasedCompletion &&)>:
       0: 45 33 c0                     	xorl	%r8d, %r8d
       3: 4c 89 01                     	movq	%r8, (%rcx)
       6: 4c 89 41 08                  	movq	%r8, 0x8(%rcx)
       a: 48 8b 02                     	movq	(%rdx), %rax
       d: 48 89 01                     	movq	%rax, (%rcx)
      10: 48 8b 42 08                  	movq	0x8(%rdx), %rax
      14: 48 89 41 08                  	movq	%rax, 0x8(%rcx)
      18: 4c 89 02                     	movq	%r8, (%rdx)
      1b: 4c 89 42 08                  	movq	%r8, 0x8(%rdx)
      1f: 48 8b 42 10                  	movq	0x10(%rdx), %rax
      23: 48 89 41 10                  	movq	%rax, 0x10(%rcx)
      27: 48 8b 42 18                  	movq	0x18(%rdx), %rax
      2b: 48 89 41 18                  	movq	%rax, 0x18(%rcx)
      2f: 48 8b 42 20                  	movq	0x20(%rdx), %rax
      33: 48 89 41 20                  	movq	%rax, 0x20(%rcx)
      37: 48 8b 42 28                  	movq	0x28(%rdx), %rax
      3b: 48 89 41 28                  	movq	%rax, 0x28(%rcx)
      3f: 48 8b 42 30                  	movq	0x30(%rdx), %rax
      43: 48 89 41 30                  	movq	%rax, 0x30(%rcx)
      47: 48 8b 42 38                  	movq	0x38(%rdx), %rax
      4b: 48 89 41 38                  	movq	%rax, 0x38(%rcx)
      4f: 48 8b 42 40                  	movq	0x40(%rdx), %rax
      53: 48 89 41 40                  	movq	%rax, 0x40(%rcx)
      57: 48 8b 42 48                  	movq	0x48(%rdx), %rax
      5b: 48 89 41 48                  	movq	%rax, 0x48(%rcx)
      5f: 48 8b 42 50                  	movq	0x50(%rdx), %rax
      63: 48 89 41 50                  	movq	%rax, 0x50(%rcx)
      67: 48 8b c1                     	movq	%rcx, %rax
      6a: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl lux::simulation::script::ScriptAwaitableId::ScriptAwaitableId(void)>:
       0: 33 c0                        	xorl	%eax, %eax
       2: 48 89 01                     	movq	%rax, (%rcx)
       5: 48 8b c1                     	movq	%rcx, %rax
       8: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl lux::simulation::script::detail::ScriptCoroutineAbilityAccess::ScriptCoroutineAbilityAccess(void)>:
       0: 33 c0                        	xorl	%eax, %eax
       2: 48 89 01                     	movq	%rax, (%rcx)
       5: 48 89 41 08                  	movq	%rax, 0x8(%rcx)
       9: 48 89 41 10                  	movq	%rax, 0x10(%rcx)
       d: 48 89 41 18                  	movq	%rax, 0x18(%rcx)
      11: 48 89 41 20                  	movq	%rax, 0x20(%rcx)
      15: 48 8b c1                     	movq	%rcx, %rax
      18: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl lux::simulation::script::ScriptEventAdmissionHandle::ScriptEventAdmissionHandle(void)>:
       0: 33 c0                        	xorl	%eax, %eax
       2: 48 89 01                     	movq	%rax, (%rcx)
       5: 48 89 41 08                  	movq	%rax, 0x8(%rcx)
       9: 48 89 41 10                  	movq	%rax, 0x10(%rcx)
       d: 89 41 18                     	movl	%eax, 0x18(%rcx)
      10: 48 8b c1                     	movq	%rcx, %rax
      13: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl lux::simulation::script::ScriptInstanceId::ScriptInstanceId(void)>:
       0: 33 c0                        	xorl	%eax, %eax
       2: 48 89 01                     	movq	%rax, (%rcx)
       5: 48 8b c1                     	movq	%rcx, %rax
       8: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl lux::simulation::script::ScriptStepError::ScriptStepError(void)>:
       0: c7 01 00 00 00 00            	movl	$0x0, (%rcx)
       6: 48 8b c1                     	movq	%rcx, %rax
       9: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl lux::simulation::script::ScriptStepResult::ScriptStepResult(void)>:
       0: 33 c0                        	xorl	%eax, %eax
       2: c6 01 00                     	movb	$0x0, (%rcx)
       5: 48 89 41 04                  	movq	%rax, 0x4(%rcx)
       9: 89 41 0c                     	movl	%eax, 0xc(%rcx)
       c: 48 8b c1                     	movq	%rcx, %rax
       f: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl std::_Nontrivial_dummy_type::_Nontrivial_dummy_type(void)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl lux::simulation::script::ScriptCoroutine::promise_type::promise_type(void)>:
       0: 33 c0                        	xorl	%eax, %eax
       2: c6 01 00                     	movb	$0x0, (%rcx)
       5: 48 89 41 04                  	movq	%rax, 0x4(%rcx)
       9: 89 41 0c                     	movl	%eax, 0xc(%rcx)
       c: 48 89 41 10                  	movq	%rax, 0x10(%rcx)
      10: 48 89 41 18                  	movq	%rax, 0x18(%rcx)
      14: 48 89 41 20                  	movq	%rax, 0x20(%rcx)
      18: 48 8b c1                     	movq	%rcx, %rax
      1b: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl lux::script::ScriptAbilityCompletion<void>::~ScriptAbilityCompletion<void>(void)>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 20                  	subq	$0x20, %rsp
       6: 48 8b 59 08                  	movq	0x8(%rcx), %rbx
       a: 48 85 db                     	testq	%rbx, %rbx
       d: 74 36                        	je	0x45 <public: __cdecl lux::script::ScriptAbilityCompletion<void>::~ScriptAbilityCompletion<void>(void)+0x45>
       f: 48 89 7c 24 30               	movq	%rdi, 0x30(%rsp)
      14: bf ff ff ff ff               	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
      19: 8b c7                        	movl	%edi, %eax
      1b: f0                           	lock
      1c: 0f c1 43 08                  	xaddl	%eax, 0x8(%rbx)
      20: 83 f8 01                     	cmpl	$0x1, %eax
      23: 75 1b                        	jne	0x40 <public: __cdecl lux::script::ScriptAbilityCompletion<void>::~ScriptAbilityCompletion<void>(void)+0x40>
      25: 48 8b 03                     	movq	(%rbx), %rax
      28: 48 8b cb                     	movq	%rbx, %rcx
      2b: ff 10                        	callq	*(%rax)
      2d: f0                           	lock
      2e: 0f c1 7b 0c                  	xaddl	%edi, 0xc(%rbx)
      32: 83 ff 01                     	cmpl	$0x1, %edi
      35: 75 09                        	jne	0x40 <public: __cdecl lux::script::ScriptAbilityCompletion<void>::~ScriptAbilityCompletion<void>(void)+0x40>
      37: 48 8b 03                     	movq	(%rbx), %rax
      3a: 48 8b cb                     	movq	%rbx, %rcx
      3d: ff 50 08                     	callq	*0x8(%rax)
      40: 48 8b 7c 24 30               	movq	0x30(%rsp), %rdi
      45: 48 83 c4 20                  	addq	$0x20, %rsp
      49: 5b                           	popq	%rbx
      4a: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::expected<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>::~expected<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>(void)>:
       0: 48 83 ec 28                  	subq	$0x28, %rsp
       4: 80 79 70 00                  	cmpb	$0x0, 0x70(%rcx)
       8: 74 49                        	je	0x53 <public: __cdecl tl::expected<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>::~expected<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>(void)+0x53>
       a: 48 89 5c 24 30               	movq	%rbx, 0x30(%rsp)
       f: 48 8b 59 10                  	movq	0x10(%rcx), %rbx
      13: 48 85 db                     	testq	%rbx, %rbx
      16: 74 36                        	je	0x4e <public: __cdecl tl::expected<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>::~expected<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>(void)+0x4e>
      18: 48 89 7c 24 20               	movq	%rdi, 0x20(%rsp)
      1d: bf ff ff ff ff               	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
      22: 8b c7                        	movl	%edi, %eax
      24: f0                           	lock
      25: 0f c1 43 08                  	xaddl	%eax, 0x8(%rbx)
      29: 83 f8 01                     	cmpl	$0x1, %eax
      2c: 75 1b                        	jne	0x49 <public: __cdecl tl::expected<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>::~expected<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>(void)+0x49>
      2e: 48 8b 03                     	movq	(%rbx), %rax
      31: 48 8b cb                     	movq	%rbx, %rcx
      34: ff 10                        	callq	*(%rax)
      36: f0                           	lock
      37: 0f c1 7b 0c                  	xaddl	%edi, 0xc(%rbx)
      3b: 83 ff 01                     	cmpl	$0x1, %edi
      3e: 75 09                        	jne	0x49 <public: __cdecl tl::expected<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>::~expected<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>(void)+0x49>
      40: 48 8b 03                     	movq	(%rbx), %rax
      43: 48 8b cb                     	movq	%rbx, %rcx
      46: ff 50 08                     	callq	*0x8(%rax)
      49: 48 8b 7c 24 20               	movq	0x20(%rsp), %rdi
      4e: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
      53: 48 83 c4 28                  	addq	$0x28, %rsp
      57: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::detail::expected_copy_assign_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>::~expected_copy_assign_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>(void)>:
       0: 48 83 ec 28                  	subq	$0x28, %rsp
       4: 80 79 70 00                  	cmpb	$0x0, 0x70(%rcx)
       8: 74 49                        	je	0x53 <public: __cdecl tl::detail::expected_copy_assign_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>::~expected_copy_assign_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>(void)+0x53>
       a: 48 89 5c 24 30               	movq	%rbx, 0x30(%rsp)
       f: 48 8b 59 10                  	movq	0x10(%rcx), %rbx
      13: 48 85 db                     	testq	%rbx, %rbx
      16: 74 36                        	je	0x4e <public: __cdecl tl::detail::expected_copy_assign_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>::~expected_copy_assign_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>(void)+0x4e>
      18: 48 89 7c 24 20               	movq	%rdi, 0x20(%rsp)
      1d: bf ff ff ff ff               	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
      22: 8b c7                        	movl	%edi, %eax
      24: f0                           	lock
      25: 0f c1 43 08                  	xaddl	%eax, 0x8(%rbx)
      29: 83 f8 01                     	cmpl	$0x1, %eax
      2c: 75 1b                        	jne	0x49 <public: __cdecl tl::detail::expected_copy_assign_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>::~expected_copy_assign_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>(void)+0x49>
      2e: 48 8b 03                     	movq	(%rbx), %rax
      31: 48 8b cb                     	movq	%rbx, %rcx
      34: ff 10                        	callq	*(%rax)
      36: f0                           	lock
      37: 0f c1 7b 0c                  	xaddl	%edi, 0xc(%rbx)
      3b: 83 ff 01                     	cmpl	$0x1, %edi
      3e: 75 09                        	jne	0x49 <public: __cdecl tl::detail::expected_copy_assign_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>::~expected_copy_assign_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>(void)+0x49>
      40: 48 8b 03                     	movq	(%rbx), %rax
      43: 48 8b cb                     	movq	%rbx, %rcx
      46: ff 50 08                     	callq	*0x8(%rax)
      49: 48 8b 7c 24 20               	movq	0x20(%rsp), %rdi
      4e: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
      53: 48 83 c4 28                  	addq	$0x28, %rsp
      57: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::detail::expected_copy_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>::~expected_copy_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>(void)>:
       0: 48 83 ec 28                  	subq	$0x28, %rsp
       4: 80 79 70 00                  	cmpb	$0x0, 0x70(%rcx)
       8: 74 49                        	je	0x53 <public: __cdecl tl::detail::expected_copy_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>::~expected_copy_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>(void)+0x53>
       a: 48 89 5c 24 30               	movq	%rbx, 0x30(%rsp)
       f: 48 8b 59 10                  	movq	0x10(%rcx), %rbx
      13: 48 85 db                     	testq	%rbx, %rbx
      16: 74 36                        	je	0x4e <public: __cdecl tl::detail::expected_copy_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>::~expected_copy_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>(void)+0x4e>
      18: 48 89 7c 24 20               	movq	%rdi, 0x20(%rsp)
      1d: bf ff ff ff ff               	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
      22: 8b c7                        	movl	%edi, %eax
      24: f0                           	lock
      25: 0f c1 43 08                  	xaddl	%eax, 0x8(%rbx)
      29: 83 f8 01                     	cmpl	$0x1, %eax
      2c: 75 1b                        	jne	0x49 <public: __cdecl tl::detail::expected_copy_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>::~expected_copy_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>(void)+0x49>
      2e: 48 8b 03                     	movq	(%rbx), %rax
      31: 48 8b cb                     	movq	%rbx, %rcx
      34: ff 10                        	callq	*(%rax)
      36: f0                           	lock
      37: 0f c1 7b 0c                  	xaddl	%edi, 0xc(%rbx)
      3b: 83 ff 01                     	cmpl	$0x1, %edi
      3e: 75 09                        	jne	0x49 <public: __cdecl tl::detail::expected_copy_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>::~expected_copy_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>(void)+0x49>
      40: 48 8b 03                     	movq	(%rbx), %rax
      43: 48 8b cb                     	movq	%rbx, %rcx
      46: ff 50 08                     	callq	*0x8(%rax)
      49: 48 8b 7c 24 20               	movq	0x20(%rsp), %rdi
      4e: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
      53: 48 83 c4 28                  	addq	$0x28, %rsp
      57: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::detail::expected_move_assign_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0>::~expected_move_assign_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0>(void)>:
       0: 48 83 ec 28                  	subq	$0x28, %rsp
       4: 80 79 70 00                  	cmpb	$0x0, 0x70(%rcx)
       8: 74 49                        	je	0x53 <public: __cdecl tl::detail::expected_move_assign_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0>::~expected_move_assign_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0>(void)+0x53>
       a: 48 89 5c 24 30               	movq	%rbx, 0x30(%rsp)
       f: 48 8b 59 10                  	movq	0x10(%rcx), %rbx
      13: 48 85 db                     	testq	%rbx, %rbx
      16: 74 36                        	je	0x4e <public: __cdecl tl::detail::expected_move_assign_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0>::~expected_move_assign_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0>(void)+0x4e>
      18: 48 89 7c 24 20               	movq	%rdi, 0x20(%rsp)
      1d: bf ff ff ff ff               	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
      22: 8b c7                        	movl	%edi, %eax
      24: f0                           	lock
      25: 0f c1 43 08                  	xaddl	%eax, 0x8(%rbx)
      29: 83 f8 01                     	cmpl	$0x1, %eax
      2c: 75 1b                        	jne	0x49 <public: __cdecl tl::detail::expected_move_assign_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0>::~expected_move_assign_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0>(void)+0x49>
      2e: 48 8b 03                     	movq	(%rbx), %rax
      31: 48 8b cb                     	movq	%rbx, %rcx
      34: ff 10                        	callq	*(%rax)
      36: f0                           	lock
      37: 0f c1 7b 0c                  	xaddl	%edi, 0xc(%rbx)
      3b: 83 ff 01                     	cmpl	$0x1, %edi
      3e: 75 09                        	jne	0x49 <public: __cdecl tl::detail::expected_move_assign_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0>::~expected_move_assign_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0>(void)+0x49>
      40: 48 8b 03                     	movq	(%rbx), %rax
      43: 48 8b cb                     	movq	%rbx, %rcx
      46: ff 50 08                     	callq	*0x8(%rax)
      49: 48 8b 7c 24 20               	movq	0x20(%rsp), %rdi
      4e: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
      53: 48 83 c4 28                  	addq	$0x28, %rsp
      57: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::detail::expected_move_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0>::~expected_move_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0>(void)>:
       0: 48 83 ec 28                  	subq	$0x28, %rsp
       4: 80 79 70 00                  	cmpb	$0x0, 0x70(%rcx)
       8: 74 49                        	je	0x53 <public: __cdecl tl::detail::expected_move_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0>::~expected_move_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0>(void)+0x53>
       a: 48 89 5c 24 30               	movq	%rbx, 0x30(%rsp)
       f: 48 8b 59 10                  	movq	0x10(%rcx), %rbx
      13: 48 85 db                     	testq	%rbx, %rbx
      16: 74 36                        	je	0x4e <public: __cdecl tl::detail::expected_move_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0>::~expected_move_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0>(void)+0x4e>
      18: 48 89 7c 24 20               	movq	%rdi, 0x20(%rsp)
      1d: bf ff ff ff ff               	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
      22: 8b c7                        	movl	%edi, %eax
      24: f0                           	lock
      25: 0f c1 43 08                  	xaddl	%eax, 0x8(%rbx)
      29: 83 f8 01                     	cmpl	$0x1, %eax
      2c: 75 1b                        	jne	0x49 <public: __cdecl tl::detail::expected_move_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0>::~expected_move_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0>(void)+0x49>
      2e: 48 8b 03                     	movq	(%rbx), %rax
      31: 48 8b cb                     	movq	%rbx, %rcx
      34: ff 10                        	callq	*(%rax)
      36: f0                           	lock
      37: 0f c1 7b 0c                  	xaddl	%edi, 0xc(%rbx)
      3b: 83 ff 01                     	cmpl	$0x1, %edi
      3e: 75 09                        	jne	0x49 <public: __cdecl tl::detail::expected_move_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0>::~expected_move_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0>(void)+0x49>
      40: 48 8b 03                     	movq	(%rbx), %rax
      43: 48 8b cb                     	movq	%rbx, %rcx
      46: ff 50 08                     	callq	*0x8(%rax)
      49: 48 8b 7c 24 20               	movq	0x20(%rsp), %rdi
      4e: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
      53: 48 83 c4 28                  	addq	$0x28, %rsp
      57: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::detail::expected_operations_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>::~expected_operations_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>(void)>:
       0: 48 83 ec 28                  	subq	$0x28, %rsp
       4: 80 79 70 00                  	cmpb	$0x0, 0x70(%rcx)
       8: 74 49                        	je	0x53 <public: __cdecl tl::detail::expected_operations_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>::~expected_operations_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>(void)+0x53>
       a: 48 89 5c 24 30               	movq	%rbx, 0x30(%rsp)
       f: 48 8b 59 10                  	movq	0x10(%rcx), %rbx
      13: 48 85 db                     	testq	%rbx, %rbx
      16: 74 36                        	je	0x4e <public: __cdecl tl::detail::expected_operations_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>::~expected_operations_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>(void)+0x4e>
      18: 48 89 7c 24 20               	movq	%rdi, 0x20(%rsp)
      1d: bf ff ff ff ff               	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
      22: 8b c7                        	movl	%edi, %eax
      24: f0                           	lock
      25: 0f c1 43 08                  	xaddl	%eax, 0x8(%rbx)
      29: 83 f8 01                     	cmpl	$0x1, %eax
      2c: 75 1b                        	jne	0x49 <public: __cdecl tl::detail::expected_operations_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>::~expected_operations_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>(void)+0x49>
      2e: 48 8b 03                     	movq	(%rbx), %rax
      31: 48 8b cb                     	movq	%rbx, %rcx
      34: ff 10                        	callq	*(%rax)
      36: f0                           	lock
      37: 0f c1 7b 0c                  	xaddl	%edi, 0xc(%rbx)
      3b: 83 ff 01                     	cmpl	$0x1, %edi
      3e: 75 09                        	jne	0x49 <public: __cdecl tl::detail::expected_operations_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>::~expected_operations_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>(void)+0x49>
      40: 48 8b 03                     	movq	(%rbx), %rax
      43: 48 8b cb                     	movq	%rbx, %rcx
      46: ff 50 08                     	callq	*0x8(%rax)
      49: 48 8b 7c 24 20               	movq	0x20(%rsp), %rdi
      4e: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
      53: 48 83 c4 28                  	addq	$0x28, %rsp
      57: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl tl::detail::expected_storage_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>::~expected_storage_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>(void)>:
       0: 48 83 ec 28                  	subq	$0x28, %rsp
       4: 80 79 70 00                  	cmpb	$0x0, 0x70(%rcx)
       8: 74 49                        	je	0x53 <public: __cdecl tl::detail::expected_storage_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>::~expected_storage_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>(void)+0x53>
       a: 48 89 5c 24 30               	movq	%rbx, 0x30(%rsp)
       f: 48 8b 59 10                  	movq	0x10(%rcx), %rbx
      13: 48 85 db                     	testq	%rbx, %rbx
      16: 74 36                        	je	0x4e <public: __cdecl tl::detail::expected_storage_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>::~expected_storage_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>(void)+0x4e>
      18: 48 89 7c 24 20               	movq	%rdi, 0x20(%rsp)
      1d: bf ff ff ff ff               	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
      22: 8b c7                        	movl	%edi, %eax
      24: f0                           	lock
      25: 0f c1 43 08                  	xaddl	%eax, 0x8(%rbx)
      29: 83 f8 01                     	cmpl	$0x1, %eax
      2c: 75 1b                        	jne	0x49 <public: __cdecl tl::detail::expected_storage_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>::~expected_storage_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>(void)+0x49>
      2e: 48 8b 03                     	movq	(%rbx), %rax
      31: 48 8b cb                     	movq	%rbx, %rcx
      34: ff 10                        	callq	*(%rax)
      36: f0                           	lock
      37: 0f c1 7b 0c                  	xaddl	%edi, 0xc(%rbx)
      3b: 83 ff 01                     	cmpl	$0x1, %edi
      3e: 75 09                        	jne	0x49 <public: __cdecl tl::detail::expected_storage_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>::~expected_storage_base<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError, 0, 1>(void)+0x49>
      40: 48 8b 03                     	movq	(%rbx), %rax
      43: 48 8b cb                     	movq	%rbx, %rcx
      46: ff 50 08                     	callq	*0x8(%rax)
      49: 48 8b 7c 24 20               	movq	0x20(%rsp), %rdi
      4e: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
      53: 48 83 c4 28                  	addq	$0x28, %rsp
      57: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl std::shared_ptr<void>::~shared_ptr<void>(void)>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 20                  	subq	$0x20, %rsp
       6: 48 8b 59 08                  	movq	0x8(%rcx), %rbx
       a: 48 85 db                     	testq	%rbx, %rbx
       d: 74 36                        	je	0x45 <public: __cdecl std::shared_ptr<void>::~shared_ptr<void>(void)+0x45>
       f: 48 89 7c 24 30               	movq	%rdi, 0x30(%rsp)
      14: bf ff ff ff ff               	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
      19: 8b c7                        	movl	%edi, %eax
      1b: f0                           	lock
      1c: 0f c1 43 08                  	xaddl	%eax, 0x8(%rbx)
      20: 83 f8 01                     	cmpl	$0x1, %eax
      23: 75 1b                        	jne	0x40 <public: __cdecl std::shared_ptr<void>::~shared_ptr<void>(void)+0x40>
      25: 48 8b 03                     	movq	(%rbx), %rax
      28: 48 8b cb                     	movq	%rbx, %rcx
      2b: ff 10                        	callq	*(%rax)
      2d: f0                           	lock
      2e: 0f c1 7b 0c                  	xaddl	%edi, 0xc(%rbx)
      32: 83 ff 01                     	cmpl	$0x1, %edi
      35: 75 09                        	jne	0x40 <public: __cdecl std::shared_ptr<void>::~shared_ptr<void>(void)+0x40>
      37: 48 8b 03                     	movq	(%rbx), %rax
      3a: 48 8b cb                     	movq	%rbx, %rcx
      3d: ff 50 08                     	callq	*0x8(%rax)
      40: 48 8b 7c 24 30               	movq	0x30(%rsp), %rdi
      45: 48 83 c4 20                  	addq	$0x20, %rsp
      49: 5b                           	popq	%rbx
      4a: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl lux::script::ScriptAbilityErasedCompletion::~ScriptAbilityErasedCompletion(void)>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 20                  	subq	$0x20, %rsp
       6: 48 8b 59 08                  	movq	0x8(%rcx), %rbx
       a: 48 85 db                     	testq	%rbx, %rbx
       d: 74 36                        	je	0x45 <public: __cdecl lux::script::ScriptAbilityErasedCompletion::~ScriptAbilityErasedCompletion(void)+0x45>
       f: 48 89 7c 24 30               	movq	%rdi, 0x30(%rsp)
      14: bf ff ff ff ff               	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
      19: 8b c7                        	movl	%edi, %eax
      1b: f0                           	lock
      1c: 0f c1 43 08                  	xaddl	%eax, 0x8(%rbx)
      20: 83 f8 01                     	cmpl	$0x1, %eax
      23: 75 1b                        	jne	0x40 <public: __cdecl lux::script::ScriptAbilityErasedCompletion::~ScriptAbilityErasedCompletion(void)+0x40>
      25: 48 8b 03                     	movq	(%rbx), %rax
      28: 48 8b cb                     	movq	%rbx, %rcx
      2b: ff 10                        	callq	*(%rax)
      2d: f0                           	lock
      2e: 0f c1 7b 0c                  	xaddl	%edi, 0xc(%rbx)
      32: 83 ff 01                     	cmpl	$0x1, %edi
      35: 75 09                        	jne	0x40 <public: __cdecl lux::script::ScriptAbilityErasedCompletion::~ScriptAbilityErasedCompletion(void)+0x40>
      37: 48 8b 03                     	movq	(%rbx), %rax
      3a: 48 8b cb                     	movq	%rbx, %rcx
      3d: ff 50 08                     	callq	*0x8(%rax)
      40: 48 8b 7c 24 30               	movq	0x30(%rsp), %rdi
      45: 48 83 c4 20                  	addq	$0x20, %rsp
      49: 5b                           	popq	%rbx
      4a: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl lux::simulation::script::ScriptAwaitableCompletion::~ScriptAwaitableCompletion(void)>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 20                  	subq	$0x20, %rsp
       6: 48 8b 59 08                  	movq	0x8(%rcx), %rbx
       a: 48 85 db                     	testq	%rbx, %rbx
       d: 74 36                        	je	0x45 <public: __cdecl lux::simulation::script::ScriptAwaitableCompletion::~ScriptAwaitableCompletion(void)+0x45>
       f: 48 89 7c 24 30               	movq	%rdi, 0x30(%rsp)
      14: bf ff ff ff ff               	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
      19: 8b c7                        	movl	%edi, %eax
      1b: f0                           	lock
      1c: 0f c1 43 08                  	xaddl	%eax, 0x8(%rbx)
      20: 83 f8 01                     	cmpl	$0x1, %eax
      23: 75 1b                        	jne	0x40 <public: __cdecl lux::simulation::script::ScriptAwaitableCompletion::~ScriptAwaitableCompletion(void)+0x40>
      25: 48 8b 03                     	movq	(%rbx), %rax
      28: 48 8b cb                     	movq	%rbx, %rcx
      2b: ff 10                        	callq	*(%rax)
      2d: f0                           	lock
      2e: 0f c1 7b 0c                  	xaddl	%edi, 0xc(%rbx)
      32: 83 ff 01                     	cmpl	$0x1, %edi
      35: 75 09                        	jne	0x40 <public: __cdecl lux::simulation::script::ScriptAwaitableCompletion::~ScriptAwaitableCompletion(void)+0x40>
      37: 48 8b 03                     	movq	(%rbx), %rax
      3a: 48 8b cb                     	movq	%rbx, %rcx
      3d: ff 50 08                     	callq	*0x8(%rax)
      40: 48 8b 7c 24 30               	movq	0x30(%rsp), %rdi
      45: 48 83 c4 20                  	addq	$0x20, %rsp
      49: 5b                           	popq	%rbx
      4a: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl lux::simulation::script::ScriptAwaitableRegistration::~ScriptAwaitableRegistration(void)>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 20                  	subq	$0x20, %rsp
       6: 48 8b 59 10                  	movq	0x10(%rcx), %rbx
       a: 48 85 db                     	testq	%rbx, %rbx
       d: 74 36                        	je	0x45 <public: __cdecl lux::simulation::script::ScriptAwaitableRegistration::~ScriptAwaitableRegistration(void)+0x45>
       f: 48 89 7c 24 30               	movq	%rdi, 0x30(%rsp)
      14: bf ff ff ff ff               	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
      19: 8b c7                        	movl	%edi, %eax
      1b: f0                           	lock
      1c: 0f c1 43 08                  	xaddl	%eax, 0x8(%rbx)
      20: 83 f8 01                     	cmpl	$0x1, %eax
      23: 75 1b                        	jne	0x40 <public: __cdecl lux::simulation::script::ScriptAwaitableRegistration::~ScriptAwaitableRegistration(void)+0x40>
      25: 48 8b 03                     	movq	(%rbx), %rax
      28: 48 8b cb                     	movq	%rbx, %rcx
      2b: ff 10                        	callq	*(%rax)
      2d: f0                           	lock
      2e: 0f c1 7b 0c                  	xaddl	%edi, 0xc(%rbx)
      32: 83 ff 01                     	cmpl	$0x1, %edi
      35: 75 09                        	jne	0x40 <public: __cdecl lux::simulation::script::ScriptAwaitableRegistration::~ScriptAwaitableRegistration(void)+0x40>
      37: 48 8b 03                     	movq	(%rbx), %rax
      3a: 48 8b cb                     	movq	%rbx, %rcx
      3d: ff 50 08                     	callq	*0x8(%rax)
      40: 48 8b 7c 24 30               	movq	0x30(%rsp), %rdi
      45: 48 83 c4 20                  	addq	$0x20, %rsp
      49: 5b                           	popq	%rbx
      4a: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <void * __cdecl operator new(unsigned __int64, void *)>:
       0: 48 8b c2                     	movq	%rdx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static void __cdecl lux::simulation::script::ScriptCoroutine::promise_type::operator delete(void *, unsigned __int64)>:
       0: 48 ff 25 00 00 00 00         	jmpq	*(%rip)                 # 0x7 <public: static void __cdecl lux::simulation::script::ScriptCoroutine::promise_type::operator delete(void *, unsigned __int64)+0x7>
		0000000000000003:  IMAGE_REL_AMD64_REL32	__imp_?releaseFrame@ScriptCoroutineContext@script@simulation@lux@@CAXPEAX@Z

Disassembly of section .text$mn:

0000000000000000 <public: unsigned __int64 const & __cdecl std::array<unsigned __int64, 1>::operator[](unsigned __int64) const>:
       0: 48 8d 04 d1                  	leaq	(%rcx,%rdx,8), %rax
       4: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: struct std::coroutine_handle<void> __cdecl std::coroutine_handle<struct lux::simulation::script::ScriptCoroutine::promise_type>::operator struct std::coroutine_handle<void>(void) const>:
       0: 48 8b 01                     	movq	(%rcx), %rax
       3: 48 89 02                     	movq	%rax, (%rdx)
       6: 48 8b c2                     	movq	%rdx, %rax
       9: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: bool __cdecl tl::expected<struct lux::simulation::script::ScriptAwaitableId, enum lux::simulation::script::EScriptEventWaitError>::operator bool(void) const>:
       0: 0f b6 41 08                  	movzbl	0x8(%rcx), %eax
       4: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: bool __cdecl tl::expected<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>::operator bool(void) const>:
       0: 0f b6 41 70                  	movzbl	0x70(%rcx), %eax
       4: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: bool __cdecl tl::expected<void, struct lux::script::ScriptAbilityOperationError>::operator bool(void) const>:
       0: 0f b6 41 04                  	movzbl	0x4(%rcx), %eax
       4: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: bool __cdecl tl::expected<void, struct lux::simulation::script::ScriptSyncStepError>::operator bool(void) const>:
       0: 0f b6 41 0c                  	movzbl	0xc(%rcx), %eax
       4: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: bool __cdecl lux::simulation::script::PreparedLocalAsyncStart::operator bool(void) const>:
       0: 48 83 79 08 00               	cmpq	$0x0, 0x8(%rcx)
       5: 0f 95 c0                     	setne	%al
       8: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: struct lux::simulation::script::ScriptAwaitableRegistration * __cdecl tl::expected<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>::operator->(void)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: class lux::simulation::script::CppScriptEventSource<int> & __cdecl std::_Optional_construct_base<class lux::simulation::script::CppScriptEventSource<int>>::operator*(void) &>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??R<lambda_1>@?1???$?R$$V@0?1???R0?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@$$V@std@@V0?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@XZ@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z@QEBA?A_PXZ@QEBA@V?$ScriptAbilityCompletion@X@24@@Z>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 6c 24 18               	movq	%rbp, 0x18(%rsp)
       a: 48 89 74 24 20               	movq	%rsi, 0x20(%rsp)
       f: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
      14: 57                           	pushq	%rdi
      15: 41 54                        	pushq	%r12
      17: 41 55                        	pushq	%r13
      19: 41 56                        	pushq	%r14
      1b: 41 57                        	pushq	%r15
      1d: 48 81 ec 80 00 00 00         	subq	$0x80, %rsp
      24: 4d 8b e8                     	movq	%r8, %r13
      27: 4d 8b 20                     	movq	(%r8), %r12
      2a: 4d 8b 78 08                  	movq	0x8(%r8), %r15
      2e: 33 c0                        	xorl	%eax, %eax
      30: 49 89 00                     	movq	%rax, (%r8)
      33: 49 89 40 08                  	movq	%rax, 0x8(%r8)
      37: 4d 8b 48 10                  	movq	0x10(%r8), %r9
      3b: 4d 8b 50 18                  	movq	0x18(%r8), %r10
      3f: 4d 8b 58 20                  	movq	0x20(%r8), %r11
      43: 49 8b 58 28                  	movq	0x28(%r8), %rbx
      47: 49 8b 78 30                  	movq	0x30(%r8), %rdi
      4b: 4d 8b 40 38                  	movq	0x38(%r8), %r8
      4f: 49 8b 75 40                  	movq	0x40(%r13), %rsi
      53: 49 8b 6d 48                  	movq	0x48(%r13), %rbp
      57: 4d 8b 75 50                  	movq	0x50(%r13), %r14
      5b: 48 8b 41 08                  	movq	0x8(%rcx), %rax
      5f: 48 8b 48 08                  	movq	0x8(%rax), %rcx
      63: 48 8b 10                     	movq	(%rax), %rdx
      66: 4c 89 64 24 20               	movq	%r12, 0x20(%rsp)
      6b: 4c 89 7c 24 28               	movq	%r15, 0x28(%rsp)
      70: 4c 89 4c 24 30               	movq	%r9, 0x30(%rsp)
      75: 4c 89 54 24 38               	movq	%r10, 0x38(%rsp)
      7a: 4c 89 5c 24 40               	movq	%r11, 0x40(%rsp)
      7f: 48 89 5c 24 48               	movq	%rbx, 0x48(%rsp)
      84: 48 89 7c 24 50               	movq	%rdi, 0x50(%rsp)
      89: 4c 89 44 24 58               	movq	%r8, 0x58(%rsp)
      8e: 48 89 74 24 60               	movq	%rsi, 0x60(%rsp)
      93: 48 89 6c 24 68               	movq	%rbp, 0x68(%rsp)
      98: 4c 89 74 24 70               	movq	%r14, 0x70(%rsp)
      9d: 48 8b 01                     	movq	(%rcx), %rax
      a0: 4c 8d 44 24 20               	leaq	0x20(%rsp), %r8
      a5: 48 8b b4 24 b8 00 00 00      	movq	0xb8(%rsp), %rsi
      ad: 48 8b ce                     	movq	%rsi, %rcx
      b0: ff d0                        	callq	*%rax
      b2: 90                           	nop
      b3: 49 8b 5d 08                  	movq	0x8(%r13), %rbx
      b7: 48 85 db                     	testq	%rbx, %rbx
      ba: 74 2c                        	je	0xe8 <??R<lambda_1>@?1???$?R$$V@0?1???R0?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@$$V@std@@V0?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@XZ@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z@QEBA?A_PXZ@QEBA@V?$ScriptAbilityCompletion@X@24@@Z+0xe8>
      bc: bf ff ff ff ff               	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
      c1: 8b c7                        	movl	%edi, %eax
      c3: f0                           	lock
      c4: 0f c1 43 08                  	xaddl	%eax, 0x8(%rbx)
      c8: 83 f8 01                     	cmpl	$0x1, %eax
      cb: 75 1b                        	jne	0xe8 <??R<lambda_1>@?1???$?R$$V@0?1???R0?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@$$V@std@@V0?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@XZ@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z@QEBA?A_PXZ@QEBA@V?$ScriptAbilityCompletion@X@24@@Z+0xe8>
      cd: 48 8b 03                     	movq	(%rbx), %rax
      d0: 48 8b cb                     	movq	%rbx, %rcx
      d3: ff 10                        	callq	*(%rax)
      d5: f0                           	lock
      d6: 0f c1 7b 0c                  	xaddl	%edi, 0xc(%rbx)
      da: 83 ff 01                     	cmpl	$0x1, %edi
      dd: 75 09                        	jne	0xe8 <??R<lambda_1>@?1???$?R$$V@0?1???R0?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@$$V@std@@V0?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@XZ@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z@QEBA?A_PXZ@QEBA@V?$ScriptAbilityCompletion@X@24@@Z+0xe8>
      df: 48 8b 03                     	movq	(%rbx), %rax
      e2: 48 8b cb                     	movq	%rbx, %rcx
      e5: ff 50 08                     	callq	*0x8(%rax)
      e8: 48 8b c6                     	movq	%rsi, %rax
      eb: 4c 8d 9c 24 80 00 00 00      	leaq	0x80(%rsp), %r11
      f3: 49 8b 5b 30                  	movq	0x30(%r11), %rbx
      f7: 49 8b 6b 40                  	movq	0x40(%r11), %rbp
      fb: 49 8b 73 48                  	movq	0x48(%r11), %rsi
      ff: 49 8b e3                     	movq	%r11, %rsp
     102: 41 5f                        	popq	%r15
     104: 41 5e                        	popq	%r14
     106: 41 5d                        	popq	%r13
     108: 41 5c                        	popq	%r12
     10a: 5f                           	popq	%rdi
     10b: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??R<lambda_1>@?1???$?RN@0?1???R0?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@N@std@@V0?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@N@Z@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z@QEBA?A_PAEAN@Z@QEBA@V?$ScriptAbilityCompletion@X@24@@Z>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 4c 89 44 24 18               	movq	%r8, 0x18(%rsp)
       a: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
       f: 55                           	pushq	%rbp
      10: 56                           	pushq	%rsi
      11: 57                           	pushq	%rdi
      12: 41 54                        	pushq	%r12
      14: 41 55                        	pushq	%r13
      16: 41 56                        	pushq	%r14
      18: 41 57                        	pushq	%r15
      1a: 48 81 ec 80 00 00 00         	subq	$0x80, %rsp
      21: 49 8b c0                     	movq	%r8, %rax
      24: 4c 8b 69 10                  	movq	0x10(%rcx), %r13
      28: 4d 8b 20                     	movq	(%r8), %r12
      2b: 4d 8b 78 08                  	movq	0x8(%r8), %r15
      2f: 33 d2                        	xorl	%edx, %edx
      31: 49 89 10                     	movq	%rdx, (%r8)
      34: 49 89 50 08                  	movq	%rdx, 0x8(%r8)
      38: 4d 8b 48 10                  	movq	0x10(%r8), %r9
      3c: 4d 8b 50 18                  	movq	0x18(%r8), %r10
      40: 4d 8b 58 20                  	movq	0x20(%r8), %r11
      44: 49 8b 58 28                  	movq	0x28(%r8), %rbx
      48: 4d 8b 40 30                  	movq	0x30(%r8), %r8
      4c: 48 8b 78 38                  	movq	0x38(%rax), %rdi
      50: 48 8b 70 40                  	movq	0x40(%rax), %rsi
      54: 48 8b 68 48                  	movq	0x48(%rax), %rbp
      58: 4c 8b 70 50                  	movq	0x50(%rax), %r14
      5c: 48 8b 41 08                  	movq	0x8(%rcx), %rax
      60: 48 8b 48 08                  	movq	0x8(%rax), %rcx
      64: 48 8b 10                     	movq	(%rax), %rdx
      67: 4c 89 64 24 20               	movq	%r12, 0x20(%rsp)
      6c: 4c 89 7c 24 28               	movq	%r15, 0x28(%rsp)
      71: 4c 89 4c 24 30               	movq	%r9, 0x30(%rsp)
      76: 4c 89 54 24 38               	movq	%r10, 0x38(%rsp)
      7b: 4c 89 5c 24 40               	movq	%r11, 0x40(%rsp)
      80: 48 89 5c 24 48               	movq	%rbx, 0x48(%rsp)
      85: 4c 89 44 24 50               	movq	%r8, 0x50(%rsp)
      8a: 48 89 7c 24 58               	movq	%rdi, 0x58(%rsp)
      8f: 48 89 74 24 60               	movq	%rsi, 0x60(%rsp)
      94: 48 89 6c 24 68               	movq	%rbp, 0x68(%rsp)
      99: 4c 89 74 24 70               	movq	%r14, 0x70(%rsp)
      9e: 48 8b 41 10                  	movq	0x10(%rcx), %rax
      a2: 4c 8d 4c 24 20               	leaq	0x20(%rsp), %r9
      a7: f2 41 0f 10 55 00            	movsd	(%r13), %xmm2
      ad: 48 8b b4 24 c8 00 00 00      	movq	0xc8(%rsp), %rsi
      b5: 48 8b ce                     	movq	%rsi, %rcx
      b8: ff d0                        	callq	*%rax
      ba: 90                           	nop
      bb: 48 8b 84 24 d0 00 00 00      	movq	0xd0(%rsp), %rax
      c3: 48 8b 58 08                  	movq	0x8(%rax), %rbx
      c7: 48 85 db                     	testq	%rbx, %rbx
      ca: 74 2c                        	je	0xf8 <??R<lambda_1>@?1???$?RN@0?1???R0?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@N@std@@V0?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@N@Z@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z@QEBA?A_PAEAN@Z@QEBA@V?$ScriptAbilityCompletion@X@24@@Z+0xf8>
      cc: bf ff ff ff ff               	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
      d1: 8b c7                        	movl	%edi, %eax
      d3: f0                           	lock
      d4: 0f c1 43 08                  	xaddl	%eax, 0x8(%rbx)
      d8: 83 f8 01                     	cmpl	$0x1, %eax
      db: 75 1b                        	jne	0xf8 <??R<lambda_1>@?1???$?RN@0?1???R0?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@N@std@@V0?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@N@Z@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z@QEBA?A_PAEAN@Z@QEBA@V?$ScriptAbilityCompletion@X@24@@Z+0xf8>
      dd: 48 8b 03                     	movq	(%rbx), %rax
      e0: 48 8b cb                     	movq	%rbx, %rcx
      e3: ff 10                        	callq	*(%rax)
      e5: f0                           	lock
      e6: 0f c1 7b 0c                  	xaddl	%edi, 0xc(%rbx)
      ea: 83 ff 01                     	cmpl	$0x1, %edi
      ed: 75 09                        	jne	0xf8 <??R<lambda_1>@?1???$?RN@0?1???R0?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@N@std@@V0?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@N@Z@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z@QEBA?A_PAEAN@Z@QEBA@V?$ScriptAbilityCompletion@X@24@@Z+0xf8>
      ef: 48 8b 03                     	movq	(%rbx), %rax
      f2: 48 8b cb                     	movq	%rbx, %rcx
      f5: ff 50 08                     	callq	*0x8(%rax)
      f8: 48 8b c6                     	movq	%rsi, %rax
      fb: 48 8b 9c 24 c0 00 00 00      	movq	0xc0(%rsp), %rbx
     103: 48 81 c4 80 00 00 00         	addq	$0x80, %rsp
     10a: 41 5f                        	popq	%r15
     10c: 41 5e                        	popq	%r14
     10e: 41 5d                        	popq	%r13
     110: 41 5c                        	popq	%r12
     112: 5f                           	popq	%rdi
     113: 5e                           	popq	%rsi
     114: 5d                           	popq	%rbp
     115: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??R<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@$$V@std@@V0?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@XZ@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 74 24 10               	movq	%rsi, 0x10(%rsp)
       a: 48 89 7c 24 18               	movq	%rdi, 0x18(%rsp)
       f: 4c 89 74 24 20               	movq	%r14, 0x20(%rsp)
      14: 55                           	pushq	%rbp
      15: 48 8d 6c 24 a9               	leaq	-0x57(%rsp), %rbp
      1a: 48 81 ec c0 00 00 00         	subq	$0xc0, %rsp
      21: 49 8b f1                     	movq	%r9, %rsi
      24: 49 8b c0                     	movq	%r8, %rax
      27: 48 8b da                     	movq	%rdx, %rbx
      2a: 48 8b f9                     	movq	%rcx, %rdi
      2d: 0f 57 c0                     	xorps	%xmm0, %xmm0
      30: f3 0f 7f 45 e7               	movdqu	%xmm0, -0x19(%rbp)
      35: 45 33 f6                     	xorl	%r14d, %r14d
      38: 4c 89 75 f7                  	movq	%r14, -0x9(%rbp)
      3c: 4c 89 75 ff                  	movq	%r14, -0x1(%rbp)
      40: 4c 89 75 07                  	movq	%r14, 0x7(%rbp)
      44: 4c 8d 45 e7                  	leaq	-0x19(%rbp), %r8
      48: 8b 11                        	movl	(%rcx), %edx
      4a: 48 8b c8                     	movq	%rax, %rcx
      4d: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x53 <??R<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@$$V@std@@V0?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@XZ@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z+0x53>
		000000000000004f:  IMAGE_REL_AMD64_REL32	__imp_?resolveAbility@ScriptCoroutineContext@script@simulation@lux@@AEBA_NIAEAUScriptCoroutineAbilityAccess@detail@234@@Z
      53: 84 c0                        	testb	%al, %al
      55: 75 18                        	jne	0x6f <??R<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@$$V@std@@V0?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@XZ@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z+0x6f>
      57: c6 45 b7 02                  	movb	$0x2, -0x49(%rbp)
      5b: 4c 89 75 bb                  	movq	%r14, -0x45(%rbp)
      5f: c7 45 c3 ff ff ff ff         	movl	$0xffffffff, -0x3d(%rbp) # imm = 0xFFFFFFFF
      66: 0f 10 45 b7                  	movups	-0x49(%rbp), %xmm0
      6a: e9 8b 00 00 00               	jmp	0xfa <??R<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@$$V@std@@V0?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@XZ@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z+0xfa>
      6f: 48 8b 4f 08                  	movq	0x8(%rdi), %rcx
      73: 4c 8b 4d 07                  	movq	0x7(%rbp), %r9
      77: 4d 85 c9                     	testq	%r9, %r9
      7a: 74 35                        	je	0xb1 <??R<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@$$V@std@@V0?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@XZ@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z+0xb1>
      7c: 48 8b 55 f7                  	movq	-0x9(%rbp), %rdx
      80: 48 39 55 e7                  	cmpq	%rdx, -0x19(%rbp)
      84: 75 2b                        	jne	0xb1 <??R<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@$$V@std@@V0?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@XZ@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z+0xb1>
      86: 48 8b 45 ff                  	movq	-0x1(%rbp), %rax
      8a: 48 39 45 ef                  	cmpq	%rax, -0x11(%rbp)
      8e: 75 21                        	jne	0xb1 <??R<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@$$V@std@@V0?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@XZ@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z+0xb1>
      90: 0f 10 01                     	movups	(%rcx), %xmm0
      93: 0f 29 45 c7                  	movaps	%xmm0, -0x39(%rbp)
      97: f2 0f 10 49 10               	movsd	0x10(%rcx), %xmm1
      9c: f2 0f 11 4d d7               	movsd	%xmm1, -0x29(%rbp)
      a1: 4c 8d 45 c7                  	leaq	-0x39(%rbp), %r8
      a5: 48 8d 4d 37                  	leaq	0x37(%rbp), %rcx
      a9: 41 ff d1                     	callq	*%r9
      ac: 48 8b c8                     	movq	%rax, %rcx
      af: eb 11                        	jmp	0xc2 <??R<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@$$V@std@@V0?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@XZ@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z+0xc2>
      b1: 0f 57 c0                     	xorps	%xmm0, %xmm0
      b4: 33 c0                        	xorl	%eax, %eax
      b6: 0f 11 45 c7                  	movups	%xmm0, -0x39(%rbp)
      ba: 48 89 45 d7                  	movq	%rax, -0x29(%rbp)
      be: 48 8d 4d c7                  	leaq	-0x39(%rbp), %rcx
      c2: 48 8d 47 11                  	leaq	0x11(%rdi), %rax
      c6: 48 89 45 b7                  	movq	%rax, -0x49(%rbp)
      ca: 48 8d 45 e7                  	leaq	-0x19(%rbp), %rax
      ce: 48 89 45 bf                  	movq	%rax, -0x41(%rbp)
      d2: 0f 10 01                     	movups	(%rcx), %xmm0
      d5: 0f 29 45 17                  	movaps	%xmm0, 0x17(%rbp)
      d9: f2 0f 10 49 10               	movsd	0x10(%rcx), %xmm1
      de: f2 0f 11 4d 27               	movsd	%xmm1, 0x27(%rbp)
      e3: 4c 8d 4d b7                  	leaq	-0x49(%rbp), %r9
      e7: 4c 8d 45 17                  	leaq	0x17(%rbp), %r8
      eb: 48 8b d6                     	movq	%rsi, %rdx
      ee: 48 8d 4d c7                  	leaq	-0x39(%rbp), %rcx
      f2: e8 00 00 00 00               	callq	0xf7 <??R<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@$$V@std@@V0?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@XZ@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z+0xf7>
		00000000000000f3:  IMAGE_REL_AMD64_REL32	??$invokePreparedScriptAbilityAsync@XV<lambda_1>@?1???$?R$$V@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PXZ@$$V@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@VPreparedLocalAsyncStart@012@$$QEAV<lambda_1>@?1???$?R$$V@6?1???R6?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@$$V@std@@V6?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@XZ@@Z@QEAA@AEAV7012@0@Z@QEBA?A_PXZ@@Z
      f7: 0f 10 00                     	movups	(%rax), %xmm0
      fa: 48 8b c3                     	movq	%rbx, %rax
      fd: 0f 11 03                     	movups	%xmm0, (%rbx)
     100: 4c 8d 9c 24 c0 00 00 00      	leaq	0xc0(%rsp), %r11
     108: 49 8b 5b 10                  	movq	0x10(%r11), %rbx
     10c: 49 8b 73 18                  	movq	0x18(%r11), %rsi
     110: 49 8b 7b 20                  	movq	0x20(%r11), %rdi
     114: 4d 8b 73 28                  	movq	0x28(%r11), %r14
     118: 49 8b e3                     	movq	%r11, %rsp
     11b: 5d                           	popq	%rbp
     11c: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <??R<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@N@std@@V0?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@N@Z@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 74 24 10               	movq	%rsi, 0x10(%rsp)
       a: 48 89 7c 24 18               	movq	%rdi, 0x18(%rsp)
       f: 4c 89 74 24 20               	movq	%r14, 0x20(%rsp)
      14: 55                           	pushq	%rbp
      15: 48 8d 6c 24 a9               	leaq	-0x57(%rsp), %rbp
      1a: 48 81 ec c0 00 00 00         	subq	$0xc0, %rsp
      21: 49 8b f1                     	movq	%r9, %rsi
      24: 49 8b c0                     	movq	%r8, %rax
      27: 48 8b da                     	movq	%rdx, %rbx
      2a: 48 8b f9                     	movq	%rcx, %rdi
      2d: 0f 57 c0                     	xorps	%xmm0, %xmm0
      30: f3 0f 7f 45 07               	movdqu	%xmm0, 0x7(%rbp)
      35: 45 33 f6                     	xorl	%r14d, %r14d
      38: 4c 89 75 17                  	movq	%r14, 0x17(%rbp)
      3c: 4c 89 75 1f                  	movq	%r14, 0x1f(%rbp)
      40: 4c 89 75 27                  	movq	%r14, 0x27(%rbp)
      44: 4c 8d 45 07                  	leaq	0x7(%rbp), %r8
      48: 8b 11                        	movl	(%rcx), %edx
      4a: 48 8b c8                     	movq	%rax, %rcx
      4d: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x53 <??R<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@N@std@@V0?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@N@Z@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z+0x53>
		000000000000004f:  IMAGE_REL_AMD64_REL32	__imp_?resolveAbility@ScriptCoroutineContext@script@simulation@lux@@AEBA_NIAEAUScriptCoroutineAbilityAccess@detail@234@@Z
      53: 84 c0                        	testb	%al, %al
      55: 75 18                        	jne	0x6f <??R<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@N@std@@V0?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@N@Z@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z+0x6f>
      57: c6 45 c7 02                  	movb	$0x2, -0x39(%rbp)
      5b: 4c 89 75 cb                  	movq	%r14, -0x35(%rbp)
      5f: c7 45 d3 ff ff ff ff         	movl	$0xffffffff, -0x2d(%rbp) # imm = 0xFFFFFFFF
      66: 0f 10 45 c7                  	movups	-0x39(%rbp), %xmm0
      6a: e9 98 00 00 00               	jmp	0x107 <??R<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@N@std@@V0?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@N@Z@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z+0x107>
      6f: 48 8b 4f 08                  	movq	0x8(%rdi), %rcx
      73: 4c 8b 4d 27                  	movq	0x27(%rbp), %r9
      77: 4d 85 c9                     	testq	%r9, %r9
      7a: 74 35                        	je	0xb1 <??R<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@N@std@@V0?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@N@Z@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z+0xb1>
      7c: 48 8b 55 17                  	movq	0x17(%rbp), %rdx
      80: 48 39 55 07                  	cmpq	%rdx, 0x7(%rbp)
      84: 75 2b                        	jne	0xb1 <??R<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@N@std@@V0?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@N@Z@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z+0xb1>
      86: 48 8b 45 1f                  	movq	0x1f(%rbp), %rax
      8a: 48 39 45 0f                  	cmpq	%rax, 0xf(%rbp)
      8e: 75 21                        	jne	0xb1 <??R<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@N@std@@V0?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@N@Z@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z+0xb1>
      90: 0f 10 01                     	movups	(%rcx), %xmm0
      93: 0f 29 45 e7                  	movaps	%xmm0, -0x19(%rbp)
      97: f2 0f 10 49 10               	movsd	0x10(%rcx), %xmm1
      9c: f2 0f 11 4d f7               	movsd	%xmm1, -0x9(%rbp)
      a1: 4c 8d 45 e7                  	leaq	-0x19(%rbp), %r8
      a5: 48 8d 4d c7                  	leaq	-0x39(%rbp), %rcx
      a9: 41 ff d1                     	callq	*%r9
      ac: 48 8b d0                     	movq	%rax, %rdx
      af: eb 11                        	jmp	0xc2 <??R<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@N@std@@V0?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@N@Z@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z+0xc2>
      b1: 0f 57 c0                     	xorps	%xmm0, %xmm0
      b4: 33 c0                        	xorl	%eax, %eax
      b6: 0f 11 45 c7                  	movups	%xmm0, -0x39(%rbp)
      ba: 48 89 45 d7                  	movq	%rax, -0x29(%rbp)
      be: 48 8d 55 c7                  	leaq	-0x39(%rbp), %rdx
      c2: 48 8d 4f 10                  	leaq	0x10(%rdi), %rcx
      c6: 48 8d 47 18                  	leaq	0x18(%rdi), %rax
      ca: 48 89 45 e7                  	movq	%rax, -0x19(%rbp)
      ce: 48 8d 45 07                  	leaq	0x7(%rbp), %rax
      d2: 48 89 45 ef                  	movq	%rax, -0x11(%rbp)
      d6: 48 89 4d f7                  	movq	%rcx, -0x9(%rbp)
      da: 0f 10 02                     	movups	(%rdx), %xmm0
      dd: 0f 29 45 37                  	movaps	%xmm0, 0x37(%rbp)
      e1: f2 0f 10 4a 10               	movsd	0x10(%rdx), %xmm1
      e6: f2 0f 11 4d 47               	movsd	%xmm1, 0x47(%rbp)
      eb: 48 89 4c 24 20               	movq	%rcx, 0x20(%rsp)
      f0: 4c 8d 4d e7                  	leaq	-0x19(%rbp), %r9
      f4: 4c 8d 45 37                  	leaq	0x37(%rbp), %r8
      f8: 48 8b d6                     	movq	%rsi, %rdx
      fb: 48 8d 4d c7                  	leaq	-0x39(%rbp), %rcx
      ff: e8 00 00 00 00               	callq	0x104 <??R<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@V?$tuple@N@std@@V0?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@QEBA@N@Z@@Z@QEAA@AEAV1234@AEAUScriptStepContext@234@@Z+0x104>
		0000000000000100:  IMAGE_REL_AMD64_REL32	??$invokePreparedScriptAbilityAsync@XV<lambda_1>@?1???$?RN@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PAEAN@Z@N@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@VPreparedLocalAsyncStart@012@$$QEAV<lambda_1>@?1???$?RN@6?1???R6?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@N@std@@V6?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@N@Z@@Z@QEAA@AEAV7012@0@Z@QEBA?A_PAEAN@Z@6@Z
     104: 0f 10 00                     	movups	(%rax), %xmm0
     107: 48 8b c3                     	movq	%rbx, %rax
     10a: 0f 11 03                     	movups	%xmm0, (%rbx)
     10d: 4c 8d 9c 24 c0 00 00 00      	leaq	0xc0(%rsp), %r11
     115: 49 8b 5b 10                  	movq	0x10(%r11), %rbx
     119: 49 8b 73 18                  	movq	0x18(%r11), %rsi
     11d: 49 8b 7b 20                  	movq	0x20(%r11), %rdi
     121: 4d 8b 73 28                  	movq	0x28(%r11), %r14
     125: 49 8b e3                     	movq	%r11, %rsp
     128: 5d                           	popq	%rbp
     129: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl `struct lux::simulation::script::CppStaticObjectOperations __cdecl lux::simulation::script::detail::cppStaticObject<struct lux::simulation::na1::cost::Tasks, 0>(void)'::`2'::<lambda_1>::operator()(void *) const>:
       0: b0 01                        	movb	$0x1, %al
       2: eb 02                        	jmp	0x6 <$LN8+0x2>

0000000000000004 <$LN8>:
       4: 32 c0                        	xorb	%al, %al
       6: c3                           	retq
       7: cc                           	int3

Disassembly of section .text$x:

0000000000000000 <int `public: __cdecl `struct simulation::script::detail::CppStaticObjectOperations __cdecl lux::simulation::script::detail::cppStaticObject<struct lux::simulation::na1::cost::Tasks, 0>(void)'::`2'::<lambda_1>::operator()(void *) const'::`1'::catch$0>:
       0: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
       5: 55                           	pushq	%rbp
       6: 48 8b ea                     	movq	%rdx, %rbp

0000000000000009 <__catch$??R<lambda_1>@?1???$cppStaticObject@UTasks@cost@na1@simulation@lux@@$M$$T0A@@detail@script@simulation@lux@@YA?AUCppStaticObjectOperations@234@XZ@QEBA@PEAX@Z$0>:
       9: 48 b8 00 00 00 00 00 00 00 00	movabsq	$0x0, %rax
      13: 5d                           	popq	%rbp
      14: c3                           	retq
      15: cc                           	int3

Disassembly of section .text$mn:

0000000000000000 <??R<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@234@@Z@QEBA@AEAV1234@AEAUScriptStepContext@234@@Z>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 74 24 10               	movq	%rsi, 0x10(%rsp)
       a: 48 89 7c 24 18               	movq	%rdi, 0x18(%rsp)
       f: 55                           	pushq	%rbp
      10: 48 8b ec                     	movq	%rsp, %rbp
      13: 48 81 ec 80 00 00 00         	subq	$0x80, %rsp
      1a: 49 8b f9                     	movq	%r9, %rdi
      1d: 49 8b c0                     	movq	%r8, %rax
      20: 48 8b da                     	movq	%rdx, %rbx
      23: 33 f6                        	xorl	%esi, %esi
      25: 48 89 75 c0                  	movq	%rsi, -0x40(%rbp)
      29: 48 89 75 c8                  	movq	%rsi, -0x38(%rbp)
      2d: 48 89 75 d0                  	movq	%rsi, -0x30(%rbp)
      31: 89 75 d8                     	movl	%esi, -0x28(%rbp)
      34: 4d 8b 50 30                  	movq	0x30(%r8), %r10
      38: 4d 85 d2                     	testq	%r10, %r10
      3b: 0f 84 99 00 00 00            	je	0xda <??R<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@234@@Z@QEBA@AEAV1234@AEAUScriptStepContext@234@@Z+0xda>
      41: 48 8d 55 c0                  	leaq	-0x40(%rbp), %rdx
      45: 48 89 54 24 20               	movq	%rdx, 0x20(%rsp)
      4a: 44 8b 49 08                  	movl	0x8(%rcx), %r9d
      4e: 4c 8b 01                     	movq	(%rcx), %r8
      51: 8b 50 18                     	movl	0x18(%rax), %edx
      54: 48 8b 48 10                  	movq	0x10(%rax), %rcx
      58: 41 ff d2                     	callq	*%r10
      5b: 84 c0                        	testb	%al, %al
      5d: 74 7b                        	je	0xda <??R<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@234@@Z@QEBA@AEAV1234@AEAUScriptStepContext@234@@Z+0xda>
      5f: 48 8b 47 30                  	movq	0x30(%rdi), %rax
      63: 48 85 c0                     	testq	%rax, %rax
      66: 75 06                        	jne	0x6e <??R<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@234@@Z@QEBA@AEAV1234@AEAUScriptStepContext@234@@Z+0x6e>
      68: c6 45 b0 0b                  	movb	$0xb, -0x50(%rbp)
      6c: eb 26                        	jmp	0x94 <??R<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@234@@Z@QEBA@AEAV1234@AEAUScriptStepContext@234@@Z+0x94>
      6e: 0f 10 45 c0                  	movups	-0x40(%rbp), %xmm0
      72: 0f 29 45 e0                  	movaps	%xmm0, -0x20(%rbp)
      76: 0f 10 4d d0                  	movups	-0x30(%rbp), %xmm1
      7a: 0f 29 4d f0                  	movaps	%xmm1, -0x10(%rbp)
      7e: 4c 8d 4d e0                  	leaq	-0x20(%rbp), %r9
      82: 4c 8b 47 38                  	movq	0x38(%rdi), %r8
      86: 48 8b 57 28                  	movq	0x28(%rdi), %rdx
      8a: 48 8d 4d b0                  	leaq	-0x50(%rbp), %rcx
      8e: ff d0                        	callq	*%rax
      90: 0f b6 45 b8                  	movzbl	-0x48(%rbp), %eax
      94: 84 c0                        	testb	%al, %al
      96: 74 21                        	je	0xb9 <??R<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@234@@Z@QEBA@AEAV1234@AEAUScriptStepContext@234@@Z+0xb9>
      98: c6 45 c0 01                  	movb	$0x1, -0x40(%rbp)
      9c: 48 8b 45 b0                  	movq	-0x50(%rbp), %rax
      a0: 48 89 45 c4                  	movq	%rax, -0x3c(%rbp)
      a4: 89 75 cc                     	movl	%esi, -0x34(%rbp)
      a7: 0f 28 45 c0                  	movaps	-0x40(%rbp), %xmm0
      ab: 48 8d 45 c0                  	leaq	-0x40(%rbp), %rax
      af: 66 0f 7f 45 c0               	movdqa	%xmm0, -0x40(%rbp)
      b4: 0f 10 00                     	movups	(%rax), %xmm0
      b7: eb 34                        	jmp	0xed <??R<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@234@@Z@QEBA@AEAV1234@AEAUScriptStepContext@234@@Z+0xed>
      b9: c6 45 b0 02                  	movb	$0x2, -0x50(%rbp)
      bd: 48 89 75 b4                  	movq	%rsi, -0x4c(%rbp)
      c1: c7 45 bc ff ff ff ff         	movl	$0xffffffff, -0x44(%rbp) # imm = 0xFFFFFFFF
      c8: 0f 28 45 b0                  	movaps	-0x50(%rbp), %xmm0
      cc: 48 8d 45 c0                  	leaq	-0x40(%rbp), %rax
      d0: 66 0f 7f 45 c0               	movdqa	%xmm0, -0x40(%rbp)
      d5: 0f 10 00                     	movups	(%rax), %xmm0
      d8: eb 13                        	jmp	0xed <??R<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@234@@Z@QEBA@AEAV1234@AEAUScriptStepContext@234@@Z+0xed>
      da: c6 45 b0 02                  	movb	$0x2, -0x50(%rbp)
      de: 48 89 75 b4                  	movq	%rsi, -0x4c(%rbp)
      e2: c7 45 bc ff ff ff ff         	movl	$0xffffffff, -0x44(%rbp) # imm = 0xFFFFFFFF
      e9: 0f 10 45 b0                  	movups	-0x50(%rbp), %xmm0
      ed: 48 8b c3                     	movq	%rbx, %rax
      f0: 0f 11 03                     	movups	%xmm0, (%rbx)
      f3: 4c 8d 9c 24 80 00 00 00      	leaq	0x80(%rsp), %r11
      fb: 49 8b 5b 10                  	movq	0x10(%r11), %rbx
      ff: 49 8b 73 18                  	movq	0x18(%r11), %rsi
     103: 49 8b 7b 20                  	movq	0x20(%r11), %rdi
     107: 49 8b e3                     	movq	%r11, %rsp
     10a: 5d                           	popq	%rbp
     10b: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl `public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::nextStep(void) const'::`2'::<lambda_1>::operator()(void *, void const *, class lux::script::ScriptAbilityCompletion<void>) const>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 74 24 10               	movq	%rsi, 0x10(%rsp)
       a: 57                           	pushq	%rdi
       b: 48 81 ec 80 00 00 00         	subq	$0x80, %rsp
      12: 4d 8b d8                     	movq	%r8, %r11
      15: 48 8b f2                     	movq	%rdx, %rsi
      18: 4d 8b 11                     	movq	(%r9), %r10
      1b: 48 8b 9c 24 b0 00 00 00      	movq	0xb0(%rsp), %rbx
      23: 48 8b 03                     	movq	(%rbx), %rax
      26: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
      2b: 48 8b 43 08                  	movq	0x8(%rbx), %rax
      2f: 48 89 44 24 28               	movq	%rax, 0x28(%rsp)
      34: 33 c0                        	xorl	%eax, %eax
      36: 48 89 03                     	movq	%rax, (%rbx)
      39: 48 89 43 08                  	movq	%rax, 0x8(%rbx)
      3d: 48 8b 43 10                  	movq	0x10(%rbx), %rax
      41: 48 89 44 24 30               	movq	%rax, 0x30(%rsp)
      46: 48 8b 43 18                  	movq	0x18(%rbx), %rax
      4a: 48 89 44 24 38               	movq	%rax, 0x38(%rsp)
      4f: 48 8b 43 20                  	movq	0x20(%rbx), %rax
      53: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
      58: 48 8b 43 28                  	movq	0x28(%rbx), %rax
      5c: 48 89 44 24 48               	movq	%rax, 0x48(%rsp)
      61: 48 8b 43 30                  	movq	0x30(%rbx), %rax
      65: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
      6a: 48 8b 43 38                  	movq	0x38(%rbx), %rax
      6e: 48 89 44 24 58               	movq	%rax, 0x58(%rsp)
      73: 48 8b 43 40                  	movq	0x40(%rbx), %rax
      77: 48 89 44 24 60               	movq	%rax, 0x60(%rsp)
      7c: 48 8b 43 48                  	movq	0x48(%rbx), %rax
      80: 48 89 44 24 68               	movq	%rax, 0x68(%rsp)
      85: 48 8b 43 50                  	movq	0x50(%rbx), %rax
      89: 48 89 44 24 70               	movq	%rax, 0x70(%rsp)
      8e: 4c 8d 44 24 20               	leaq	0x20(%rsp), %r8
      93: 49 8b d3                     	movq	%r11, %rdx
      96: 48 8b ce                     	movq	%rsi, %rcx
      99: 41 ff d2                     	callq	*%r10
      9c: 48 8b 5b 08                  	movq	0x8(%rbx), %rbx
      a0: 48 85 db                     	testq	%rbx, %rbx
      a3: 74 2c                        	je	0xd1 <public: __cdecl `public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::nextStep(void) const'::`2'::<lambda_1>::operator()(void *, void const *, class lux::script::ScriptAbilityCompletion<void>) const+0xd1>
      a5: bf ff ff ff ff               	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
      aa: 8b c7                        	movl	%edi, %eax
      ac: f0                           	lock
      ad: 0f c1 43 08                  	xaddl	%eax, 0x8(%rbx)
      b1: 83 f8 01                     	cmpl	$0x1, %eax
      b4: 75 1b                        	jne	0xd1 <public: __cdecl `public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::nextStep(void) const'::`2'::<lambda_1>::operator()(void *, void const *, class lux::script::ScriptAbilityCompletion<void>) const+0xd1>
      b6: 48 8b 03                     	movq	(%rbx), %rax
      b9: 48 8b cb                     	movq	%rbx, %rcx
      bc: ff 10                        	callq	*(%rax)
      be: f0                           	lock
      bf: 0f c1 7b 0c                  	xaddl	%edi, 0xc(%rbx)
      c3: 83 ff 01                     	cmpl	$0x1, %edi
      c6: 75 09                        	jne	0xd1 <public: __cdecl `public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::nextStep(void) const'::`2'::<lambda_1>::operator()(void *, void const *, class lux::script::ScriptAbilityCompletion<void>) const+0xd1>
      c8: 48 8b 03                     	movq	(%rbx), %rax
      cb: 48 8b cb                     	movq	%rbx, %rcx
      ce: ff 50 08                     	callq	*0x8(%rax)
      d1: 48 8b c6                     	movq	%rsi, %rax
      d4: 4c 8d 9c 24 80 00 00 00      	leaq	0x80(%rsp), %r11
      dc: 49 8b 5b 10                  	movq	0x10(%r11), %rbx
      e0: 49 8b 73 18                  	movq	0x18(%r11), %rsi
      e4: 49 8b e3                     	movq	%r11, %rsp
      e7: 5f                           	popq	%rdi
      e8: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl `public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::simulationSeconds(double) const'::`2'::<lambda_1>::operator()(void *, void const *, class lux::script::ScriptAbilityCompletion<void>, double &) const>:
       0: 4c 8b dc                     	movq	%rsp, %r11
       3: 49 89 5b 08                  	movq	%rbx, 0x8(%r11)
       7: 49 89 73 10                  	movq	%rsi, 0x10(%r11)
       b: 57                           	pushq	%rdi
       c: 48 81 ec 80 00 00 00         	subq	$0x80, %rsp
      13: 48 8b f2                     	movq	%rdx, %rsi
      16: 4d 8b 51 10                  	movq	0x10(%r9), %r10
      1a: 48 8b 9c 24 b0 00 00 00      	movq	0xb0(%rsp), %rbx
      22: 48 8b 03                     	movq	(%rbx), %rax
      25: 49 89 43 98                  	movq	%rax, -0x68(%r11)
      29: 48 8b 43 08                  	movq	0x8(%rbx), %rax
      2d: 49 89 43 a0                  	movq	%rax, -0x60(%r11)
      31: 33 c0                        	xorl	%eax, %eax
      33: 48 89 03                     	movq	%rax, (%rbx)
      36: 48 89 43 08                  	movq	%rax, 0x8(%rbx)
      3a: 48 8b 43 10                  	movq	0x10(%rbx), %rax
      3e: 49 89 43 a8                  	movq	%rax, -0x58(%r11)
      42: 48 8b 43 18                  	movq	0x18(%rbx), %rax
      46: 49 89 43 b0                  	movq	%rax, -0x50(%r11)
      4a: 48 8b 43 20                  	movq	0x20(%rbx), %rax
      4e: 49 89 43 b8                  	movq	%rax, -0x48(%r11)
      52: 48 8b 43 28                  	movq	0x28(%rbx), %rax
      56: 49 89 43 c0                  	movq	%rax, -0x40(%r11)
      5a: 48 8b 43 30                  	movq	0x30(%rbx), %rax
      5e: 49 89 43 c8                  	movq	%rax, -0x38(%r11)
      62: 48 8b 43 38                  	movq	0x38(%rbx), %rax
      66: 49 89 43 d0                  	movq	%rax, -0x30(%r11)
      6a: 48 8b 43 40                  	movq	0x40(%rbx), %rax
      6e: 49 89 43 d8                  	movq	%rax, -0x28(%r11)
      72: 48 8b 43 48                  	movq	0x48(%rbx), %rax
      76: 49 89 43 e0                  	movq	%rax, -0x20(%r11)
      7a: 48 8b 43 50                  	movq	0x50(%rbx), %rax
      7e: 49 89 43 e8                  	movq	%rax, -0x18(%r11)
      82: 4d 8d 4b 98                  	leaq	-0x68(%r11), %r9
      86: 48 8b 84 24 b8 00 00 00      	movq	0xb8(%rsp), %rax
      8e: f2 0f 10 10                  	movsd	(%rax), %xmm2
      92: 49 8b d0                     	movq	%r8, %rdx
      95: 48 8b ce                     	movq	%rsi, %rcx
      98: 41 ff d2                     	callq	*%r10
      9b: 48 8b 5b 08                  	movq	0x8(%rbx), %rbx
      9f: 48 85 db                     	testq	%rbx, %rbx
      a2: 74 2c                        	je	0xd0 <public: __cdecl `public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::simulationSeconds(double) const'::`2'::<lambda_1>::operator()(void *, void const *, class lux::script::ScriptAbilityCompletion<void>, double &) const+0xd0>
      a4: bf ff ff ff ff               	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
      a9: 8b c7                        	movl	%edi, %eax
      ab: f0                           	lock
      ac: 0f c1 43 08                  	xaddl	%eax, 0x8(%rbx)
      b0: 83 f8 01                     	cmpl	$0x1, %eax
      b3: 75 1b                        	jne	0xd0 <public: __cdecl `public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::simulationSeconds(double) const'::`2'::<lambda_1>::operator()(void *, void const *, class lux::script::ScriptAbilityCompletion<void>, double &) const+0xd0>
      b5: 48 8b 03                     	movq	(%rbx), %rax
      b8: 48 8b cb                     	movq	%rbx, %rcx
      bb: ff 10                        	callq	*(%rax)
      bd: f0                           	lock
      be: 0f c1 7b 0c                  	xaddl	%edi, 0xc(%rbx)
      c2: 83 ff 01                     	cmpl	$0x1, %edi
      c5: 75 09                        	jne	0xd0 <public: __cdecl `public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::simulationSeconds(double) const'::`2'::<lambda_1>::operator()(void *, void const *, class lux::script::ScriptAbilityCompletion<void>, double &) const+0xd0>
      c7: 48 8b 03                     	movq	(%rbx), %rax
      ca: 48 8b cb                     	movq	%rbx, %rcx
      cd: ff 50 08                     	callq	*0x8(%rax)
      d0: 48 8b c6                     	movq	%rsi, %rax
      d3: 4c 8d 9c 24 80 00 00 00      	leaq	0x80(%rsp), %r11
      db: 49 8b 5b 10                  	movq	0x10(%r11), %rbx
      df: 49 8b 73 18                  	movq	0x18(%r11), %rsi
      e3: 49 8b e3                     	movq	%r11, %rsp
      e6: 5f                           	popq	%rdi
      e7: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl `struct lux::simulation::script::CppStaticObjectOperations __cdecl lux::simulation::script::detail::cppStaticObject<struct lux::simulation::na1::cost::Tasks, 0>(void)'::`2'::<lambda_2>::operator()(void *) const>:
       0: c2 00 00                     	retq	$0x0

Disassembly of section .text$mn:

0000000000000000 <public: void * __cdecl lux::simulation::script::ScriptAwaitableRegistration::`scalar deleting dtor'(unsigned int)>:
       0: 40 57                        	pushq	%rdi
       2: 48 83 ec 20                  	subq	$0x20, %rsp
       6: 48 89 5c 24 30               	movq	%rbx, 0x30(%rsp)
       b: 48 8b f9                     	movq	%rcx, %rdi
       e: 48 8b 59 10                  	movq	0x10(%rcx), %rbx
      12: 48 89 6c 24 38               	movq	%rbp, 0x38(%rsp)
      17: 8b ea                        	movl	%edx, %ebp
      19: 48 85 db                     	testq	%rbx, %rbx
      1c: 74 36                        	je	0x54 <public: void * __cdecl lux::simulation::script::ScriptAwaitableRegistration::`scalar deleting dtor'(unsigned int)+0x54>
      1e: 48 89 74 24 40               	movq	%rsi, 0x40(%rsp)
      23: be ff ff ff ff               	movl	$0xffffffff, %esi       # imm = 0xFFFFFFFF
      28: 8b c6                        	movl	%esi, %eax
      2a: f0                           	lock
      2b: 0f c1 43 08                  	xaddl	%eax, 0x8(%rbx)
      2f: 83 f8 01                     	cmpl	$0x1, %eax
      32: 75 1b                        	jne	0x4f <public: void * __cdecl lux::simulation::script::ScriptAwaitableRegistration::`scalar deleting dtor'(unsigned int)+0x4f>
      34: 48 8b 03                     	movq	(%rbx), %rax
      37: 48 8b cb                     	movq	%rbx, %rcx
      3a: ff 10                        	callq	*(%rax)
      3c: f0                           	lock
      3d: 0f c1 73 0c                  	xaddl	%esi, 0xc(%rbx)
      41: 83 fe 01                     	cmpl	$0x1, %esi
      44: 75 09                        	jne	0x4f <public: void * __cdecl lux::simulation::script::ScriptAwaitableRegistration::`scalar deleting dtor'(unsigned int)+0x4f>
      46: 48 8b 03                     	movq	(%rbx), %rax
      49: 48 8b cb                     	movq	%rbx, %rcx
      4c: ff 50 08                     	callq	*0x8(%rax)
      4f: 48 8b 74 24 40               	movq	0x40(%rsp), %rsi
      54: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
      59: 40 f6 c5 01                  	testb	$0x1, %bpl
      5d: 48 8b 6c 24 38               	movq	0x38(%rsp), %rbp
      62: 74 0d                        	je	0x71 <public: void * __cdecl lux::simulation::script::ScriptAwaitableRegistration::`scalar deleting dtor'(unsigned int)+0x71>
      64: ba 70 00 00 00               	movl	$0x70, %edx
      69: 48 8b cf                     	movq	%rdi, %rcx
      6c: e8 00 00 00 00               	callq	0x71 <public: void * __cdecl lux::simulation::script::ScriptAwaitableRegistration::`scalar deleting dtor'(unsigned int)+0x71>
		000000000000006d:  IMAGE_REL_AMD64_REL32	??3@YAXPEAX_K@Z
      71: 48 8b c7                     	movq	%rdi, %rax
      74: 48 83 c4 20                  	addq	$0x20, %rsp
      78: 5f                           	popq	%rdi
      79: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <protected: void __cdecl std::_Ptr_base<void>::_Decref(void)>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 20                  	subq	$0x20, %rsp
       6: 48 8b 59 08                  	movq	0x8(%rcx), %rbx
       a: 48 85 db                     	testq	%rbx, %rbx
       d: 74 36                        	je	0x45 <protected: void __cdecl std::_Ptr_base<void>::_Decref(void)+0x45>
       f: 48 89 7c 24 30               	movq	%rdi, 0x30(%rsp)
      14: bf ff ff ff ff               	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
      19: 8b c7                        	movl	%edi, %eax
      1b: f0                           	lock
      1c: 0f c1 43 08                  	xaddl	%eax, 0x8(%rbx)
      20: 83 f8 01                     	cmpl	$0x1, %eax
      23: 75 1b                        	jne	0x40 <protected: void __cdecl std::_Ptr_base<void>::_Decref(void)+0x40>
      25: 48 8b 03                     	movq	(%rbx), %rax
      28: 48 8b cb                     	movq	%rbx, %rcx
      2b: ff 10                        	callq	*(%rax)
      2d: f0                           	lock
      2e: 0f c1 7b 0c                  	xaddl	%edi, 0xc(%rbx)
      32: 83 ff 01                     	cmpl	$0x1, %edi
      35: 75 09                        	jne	0x40 <protected: void __cdecl std::_Ptr_base<void>::_Decref(void)+0x40>
      37: 48 8b 03                     	movq	(%rbx), %rax
      3a: 48 8b cb                     	movq	%rbx, %rcx
      3d: ff 50 08                     	callq	*0x8(%rax)
      40: 48 8b 7c 24 30               	movq	0x30(%rsp), %rdi
      45: 48 83 c4 20                  	addq	$0x20, %rsp
      49: 5b                           	popq	%rbx
      4a: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: void __cdecl std::_Ref_count_base::_Decref(void)>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 57                           	pushq	%rdi
       6: 48 83 ec 20                  	subq	$0x20, %rsp
       a: bf ff ff ff ff               	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
       f: 48 8b d9                     	movq	%rcx, %rbx
      12: 8b c7                        	movl	%edi, %eax
      14: f0                           	lock
      15: 0f c1 41 08                  	xaddl	%eax, 0x8(%rcx)
      19: 83 f8 01                     	cmpl	$0x1, %eax
      1c: 75 18                        	jne	0x36 <public: void __cdecl std::_Ref_count_base::_Decref(void)+0x36>
      1e: 48 8b 01                     	movq	(%rcx), %rax
      21: ff 10                        	callq	*(%rax)
      23: f0                           	lock
      24: 0f c1 7b 0c                  	xaddl	%edi, 0xc(%rbx)
      28: 83 ff 01                     	cmpl	$0x1, %edi
      2b: 75 09                        	jne	0x36 <public: void __cdecl std::_Ref_count_base::_Decref(void)+0x36>
      2d: 48 8b 03                     	movq	(%rbx), %rax
      30: 48 8b cb                     	movq	%rbx, %rcx
      33: ff 50 08                     	callq	*0x8(%rax)
      36: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
      3b: 48 83 c4 20                  	addq	$0x20, %rsp
      3f: 5f                           	popq	%rdi
      40: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: void __cdecl std::_Ref_count_base::_Decwref(void)>:
       0: b8 ff ff ff ff               	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
       5: f0                           	lock
       6: 0f c1 41 0c                  	xaddl	%eax, 0xc(%rcx)
       a: 83 f8 01                     	cmpl	$0x1, %eax
       d: 75 07                        	jne	0x16 <public: void __cdecl std::_Ref_count_base::_Decwref(void)+0x16>
       f: 48 8b 01                     	movq	(%rcx), %rax
      12: 48 ff 60 08                  	jmpq	*0x8(%rax)
      16: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <wchar_t * __cdecl std::_Maklocwcs(wchar_t const *)>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 74 24 10               	movq	%rsi, 0x10(%rsp)
       a: 57                           	pushq	%rdi
       b: 48 83 ec 20                  	subq	$0x20, %rsp
       f: 48 8b f9                     	movq	%rcx, %rdi
      12: e8 00 00 00 00               	callq	0x17 <wchar_t * __cdecl std::_Maklocwcs(wchar_t const *)+0x17>
		0000000000000013:  IMAGE_REL_AMD64_REL32	wcslen
      17: ba 02 00 00 00               	movl	$0x2, %edx
      1c: 48 8d 70 01                  	leaq	0x1(%rax), %rsi
      20: 48 8b ce                     	movq	%rsi, %rcx
      23: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x29 <wchar_t * __cdecl std::_Maklocwcs(wchar_t const *)+0x29>
		0000000000000025:  IMAGE_REL_AMD64_REL32	__imp_calloc
      29: 48 8b d8                     	movq	%rax, %rbx
      2c: 48 85 c0                     	testq	%rax, %rax
      2f: 74 22                        	je	0x53 <wchar_t * __cdecl std::_Maklocwcs(wchar_t const *)+0x53>
      31: 4c 8d 04 36                  	leaq	(%rsi,%rsi), %r8
      35: 48 8b d7                     	movq	%rdi, %rdx
      38: 48 8b c8                     	movq	%rax, %rcx
      3b: e8 00 00 00 00               	callq	0x40 <wchar_t * __cdecl std::_Maklocwcs(wchar_t const *)+0x40>
		000000000000003c:  IMAGE_REL_AMD64_REL32	memcpy
      40: 48 8b 74 24 38               	movq	0x38(%rsp), %rsi
      45: 48 8b c3                     	movq	%rbx, %rax
      48: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
      4d: 48 83 c4 20                  	addq	$0x20, %rsp
      51: 5f                           	popq	%rdi
      52: c3                           	retq
      53: e8 00 00 00 00               	callq	0x58 <wchar_t * __cdecl std::_Maklocwcs(wchar_t const *)+0x58>
		0000000000000054:  IMAGE_REL_AMD64_REL32	?_Xbad_alloc@std@@YAXXZ
      58: cc                           	int3

Disassembly of section .text$mn:

0000000000000000 <public: char const * __cdecl std::basic_string_view<char, struct std::char_traits<char>>::_Unchecked_begin(void) const>:
       0: 48 8b 01                     	movq	(%rcx), %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: char const * __cdecl std::basic_string_view<char, struct std::char_traits<char>>::_Unchecked_end(void) const>:
       0: 48 8b 41 08                  	movq	0x8(%rcx), %rax
       4: 48 03 01                     	addq	(%rcx), %rax
       7: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static void * __cdecl lux::simulation::script::ScriptCoroutinePromiseAccess::allocate(class lux::simulation::script::ScriptCoroutineContext &, unsigned __int64, unsigned __int64)>:
       0: 48 ff 25 00 00 00 00         	jmpq	*(%rip)                 # 0x7 <public: static void * __cdecl lux::simulation::script::ScriptCoroutinePromiseAccess::allocate(class lux::simulation::script::ScriptCoroutineContext &, unsigned __int64, unsigned __int64)+0x7>
		0000000000000003:  IMAGE_REL_AMD64_REL32	__imp_?allocateFrame@ScriptCoroutineContext@script@simulation@lux@@AEAAPEAX_K0@Z

Disassembly of section .text$mn:

0000000000000000 <?await_ready@?$ScriptCoroutineAwaiter@HV<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@345@@Z@@script@simulation@lux@@QEBA_NXZ>:
       0: 32 c0                        	xorb	%al, %al
       2: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <?await_ready@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@@script@simulation@lux@@QEBA_NXZ>:
       0: 32 c0                        	xorb	%al, %al
       2: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <?await_ready@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@@script@simulation@lux@@QEBA_NXZ>:
       0: 32 c0                        	xorb	%al, %al
       2: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: bool __cdecl lux::simulation::script::ScriptCoroutineFailure::await_ready(void) const>:
       0: 32 c0                        	xorb	%al, %al
       2: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: bool __cdecl std::suspend_always::await_ready(void) const>:
       0: 32 c0                        	xorb	%al, %al
       2: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: bool __cdecl std::suspend_never::await_ready(void) const>:
       0: b0 01                        	movb	$0x1, %al
       2: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <?await_resume@?$ScriptCoroutineAwaiter@HV<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@345@@Z@@script@simulation@lux@@QEBAHXZ>:
       0: 48 8b 41 18                  	movq	0x18(%rcx), %rax
       4: 48 8b 40 20                  	movq	0x20(%rax), %rax
       8: 8b 00                        	movl	(%rax), %eax
       a: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <?await_resume@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@@script@simulation@lux@@QEBAXXZ>:
       0: c2 00 00                     	retq	$0x0

Disassembly of section .text$mn:

0000000000000000 <?await_resume@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@@script@simulation@lux@@QEBAXXZ>:
       0: c2 00 00                     	retq	$0x0

Disassembly of section .text$mn:

0000000000000000 <public: void __cdecl lux::simulation::script::ScriptCoroutineFailure::await_resume(void) const>:
       0: 48 83 ec 28                  	subq	$0x28, %rsp
       4: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xa <public: void __cdecl lux::simulation::script::ScriptCoroutineFailure::await_resume(void) const+0xa>
		0000000000000006:  IMAGE_REL_AMD64_REL32	__imp_terminate
       a: cc                           	int3

Disassembly of section .text$mn:

0000000000000000 <public: void __cdecl std::suspend_always::await_resume(void) const>:
       0: c2 00 00                     	retq	$0x0

Disassembly of section .text$mn:

0000000000000000 <public: void __cdecl std::suspend_never::await_resume(void) const>:
       0: c2 00 00                     	retq	$0x0

Disassembly of section .text$mn:

0000000000000000 <?await_suspend@?$ScriptCoroutineAwaiter@HV<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@345@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 74 24 10               	movq	%rsi, 0x10(%rsp)
       a: 48 89 7c 24 18               	movq	%rdi, 0x18(%rsp)
       f: 55                           	pushq	%rbp
      10: 48 8b ec                     	movq	%rsp, %rbp
      13: 48 81 ec 80 00 00 00         	subq	$0x80, %rsp
      1a: 48 8b f1                     	movq	%rcx, %rsi
      1d: 48 8d 42 10                  	leaq	0x10(%rdx), %rax
      21: 48 89 41 18                  	movq	%rax, 0x18(%rcx)
      25: 48 8b 09                     	movq	(%rcx), %rcx
      28: 48 85 c9                     	testq	%rcx, %rcx
      2b: 0f 84 f3 00 00 00            	je	0x124 <?await_suspend@?$ScriptCoroutineAwaiter@HV<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@345@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0x124>
      31: 48 8b 79 58                  	movq	0x58(%rcx), %rdi
      35: 48 85 ff                     	testq	%rdi, %rdi
      38: 0f 84 e6 00 00 00            	je	0x124 <?await_suspend@?$ScriptCoroutineAwaiter@HV<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@345@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0x124>
      3e: 33 db                        	xorl	%ebx, %ebx
      40: 48 89 5d b0                  	movq	%rbx, -0x50(%rbp)
      44: 48 89 5d b8                  	movq	%rbx, -0x48(%rbp)
      48: 48 89 5d c0                  	movq	%rbx, -0x40(%rbp)
      4c: 89 5d c8                     	movl	%ebx, -0x38(%rbp)
      4f: 48 8b 41 30                  	movq	0x30(%rcx), %rax
      53: 48 85 c0                     	testq	%rax, %rax
      56: 0f 84 99 00 00 00            	je	0xf5 <?await_suspend@?$ScriptCoroutineAwaiter@HV<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@345@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0xf5>
      5c: 48 8d 55 b0                  	leaq	-0x50(%rbp), %rdx
      60: 48 89 54 24 20               	movq	%rdx, 0x20(%rsp)
      65: 44 8b 4e 10                  	movl	0x10(%rsi), %r9d
      69: 4c 8b 46 08                  	movq	0x8(%rsi), %r8
      6d: 8b 51 18                     	movl	0x18(%rcx), %edx
      70: 48 8b 49 10                  	movq	0x10(%rcx), %rcx
      74: ff d0                        	callq	*%rax
      76: 84 c0                        	testb	%al, %al
      78: 74 7b                        	je	0xf5 <?await_suspend@?$ScriptCoroutineAwaiter@HV<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@345@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0xf5>
      7a: 48 8b 47 30                  	movq	0x30(%rdi), %rax
      7e: 48 85 c0                     	testq	%rax, %rax
      81: 75 06                        	jne	0x89 <?await_suspend@?$ScriptCoroutineAwaiter@HV<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@345@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0x89>
      83: c6 45 d0 0b                  	movb	$0xb, -0x30(%rbp)
      87: eb 26                        	jmp	0xaf <?await_suspend@?$ScriptCoroutineAwaiter@HV<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@345@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0xaf>
      89: 0f 10 45 b0                  	movups	-0x50(%rbp), %xmm0
      8d: 0f 29 45 e0                  	movaps	%xmm0, -0x20(%rbp)
      91: 0f 10 4d c0                  	movups	-0x40(%rbp), %xmm1
      95: 0f 29 4d f0                  	movaps	%xmm1, -0x10(%rbp)
      99: 4c 8d 4d e0                  	leaq	-0x20(%rbp), %r9
      9d: 4c 8b 47 38                  	movq	0x38(%rdi), %r8
      a1: 48 8b 57 28                  	movq	0x28(%rdi), %rdx
      a5: 48 8d 4d d0                  	leaq	-0x30(%rbp), %rcx
      a9: ff d0                        	callq	*%rax
      ab: 0f b6 45 d8                  	movzbl	-0x28(%rbp), %eax
      af: 84 c0                        	testb	%al, %al
      b1: 0f b7 45 d1                  	movzwl	-0x2f(%rbp), %eax
      b5: 66 89 45 b1                  	movw	%ax, -0x4f(%rbp)
      b9: 0f b6 45 d3                  	movzbl	-0x2d(%rbp), %eax
      bd: 88 45 b3                     	movb	%al, -0x4d(%rbp)
      c0: 74 1e                        	je	0xe0 <?await_suspend@?$ScriptCoroutineAwaiter@HV<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@345@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0xe0>
      c2: c6 45 b0 01                  	movb	$0x1, -0x50(%rbp)
      c6: 8b 45 d0                     	movl	-0x30(%rbp), %eax
      c9: 89 45 b4                     	movl	%eax, -0x4c(%rbp)
      cc: 48 8b 45 d0                  	movq	-0x30(%rbp), %rax
      d0: 48 c1 e8 20                  	shrq	$0x20, %rax
      d4: 89 45 b8                     	movl	%eax, -0x48(%rbp)
      d7: 89 5d bc                     	movl	%ebx, -0x44(%rbp)
      da: 0f 28 45 b0                  	movaps	-0x50(%rbp), %xmm0
      de: eb 28                        	jmp	0x108 <?await_suspend@?$ScriptCoroutineAwaiter@HV<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@345@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0x108>
      e0: c6 45 b0 02                  	movb	$0x2, -0x50(%rbp)
      e4: 48 89 5d b4                  	movq	%rbx, -0x4c(%rbp)
      e8: c7 45 bc ff ff ff ff         	movl	$0xffffffff, -0x44(%rbp) # imm = 0xFFFFFFFF
      ef: 0f 28 45 b0                  	movaps	-0x50(%rbp), %xmm0
      f3: eb 13                        	jmp	0x108 <?await_suspend@?$ScriptCoroutineAwaiter@HV<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@345@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0x108>
      f5: c6 45 d0 02                  	movb	$0x2, -0x30(%rbp)
      f9: 48 89 5d d4                  	movq	%rbx, -0x2c(%rbp)
      fd: c7 45 dc ff ff ff ff         	movl	$0xffffffff, -0x24(%rbp) # imm = 0xFFFFFFFF
     104: 0f 28 45 d0                  	movaps	-0x30(%rbp), %xmm0
     108: 48 8b 46 18                  	movq	0x18(%rsi), %rax
     10c: 48 b9 26 73 d7 d3 75 fc bc a2	movabsq	$-0x5d43038a2c288cda, %rcx # imm = 0xA2BCFC75D3D77326
     116: 48 89 48 10                  	movq	%rcx, 0x10(%rax)
     11a: 48 c7 40 18 04 00 00 00      	movq	$0x4, 0x18(%rax)
     122: eb 1d                        	jmp	0x141 <?await_suspend@?$ScriptCoroutineAwaiter@HV<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@345@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0x141>
     124: c6 45 d0 02                  	movb	$0x2, -0x30(%rbp)
     128: 33 db                        	xorl	%ebx, %ebx
     12a: 48 89 5d d4                  	movq	%rbx, -0x2c(%rbp)
     12e: c7 45 dc ff ff ff ff         	movl	$0xffffffff, -0x24(%rbp) # imm = 0xFFFFFFFF
     135: 0f 10 45 d0                  	movups	-0x30(%rbp), %xmm0
     139: 48 89 5a 20                  	movq	%rbx, 0x20(%rdx)
     13d: 48 89 5a 28                  	movq	%rbx, 0x28(%rdx)
     141: 0f 11 00                     	movups	%xmm0, (%rax)
     144: 4c 8d 9c 24 80 00 00 00      	leaq	0x80(%rsp), %r11
     14c: 49 8b 5b 10                  	movq	0x10(%r11), %rbx
     150: 49 8b 73 18                  	movq	0x18(%r11), %rsi
     154: 49 8b 7b 20                  	movq	0x20(%r11), %rdi
     158: 49 8b e3                     	movq	%r11, %rsp
     15b: 5d                           	popq	%rbp
     15c: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 74 24 10               	movq	%rsi, 0x10(%rsp)
       a: 48 89 7c 24 18               	movq	%rdi, 0x18(%rsp)
       f: 55                           	pushq	%rbp
      10: 48 8d 6c 24 a9               	leaq	-0x57(%rsp), %rbp
      15: 48 81 ec c0 00 00 00         	subq	$0xc0, %rsp
      1c: 48 8b f9                     	movq	%rcx, %rdi
      1f: 48 8d 42 10                  	leaq	0x10(%rdx), %rax
      23: 48 89 41 20                  	movq	%rax, 0x20(%rcx)
      27: 48 8b 09                     	movq	(%rcx), %rcx
      2a: 48 85 c9                     	testq	%rcx, %rcx
      2d: 0f 84 f1 00 00 00            	je	0x124 <?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0x124>
      33: 48 8b 71 58                  	movq	0x58(%rcx), %rsi
      37: 48 85 f6                     	testq	%rsi, %rsi
      3a: 0f 84 e4 00 00 00            	je	0x124 <?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0x124>
      40: 0f 57 c0                     	xorps	%xmm0, %xmm0
      43: f3 0f 7f 45 e7               	movdqu	%xmm0, -0x19(%rbp)
      48: 33 db                        	xorl	%ebx, %ebx
      4a: 48 89 5d f7                  	movq	%rbx, -0x9(%rbp)
      4e: 48 89 5d ff                  	movq	%rbx, -0x1(%rbp)
      52: 48 89 5d 07                  	movq	%rbx, 0x7(%rbp)
      56: 4c 8d 45 e7                  	leaq	-0x19(%rbp), %r8
      5a: 8b 57 08                     	movl	0x8(%rdi), %edx
      5d: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x63 <?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0x63>
		000000000000005f:  IMAGE_REL_AMD64_REL32	__imp_?resolveAbility@ScriptCoroutineContext@script@simulation@lux@@AEBA_NIAEAUScriptCoroutineAbilityAccess@detail@234@@Z
      63: 84 c0                        	testb	%al, %al
      65: 75 24                        	jne	0x8b <?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0x8b>
      67: c6 45 b7 02                  	movb	$0x2, -0x49(%rbp)
      6b: 48 89 5d bb                  	movq	%rbx, -0x45(%rbp)
      6f: c7 45 c3 ff ff ff ff         	movl	$0xffffffff, -0x3d(%rbp) # imm = 0xFFFFFFFF
      76: 0f 28 45 b7                  	movaps	-0x49(%rbp), %xmm0
      7a: 48 8b 47 20                  	movq	0x20(%rdi), %rax
      7e: 48 89 58 10                  	movq	%rbx, 0x10(%rax)
      82: 48 89 58 18                  	movq	%rbx, 0x18(%rax)
      86: e9 b6 00 00 00               	jmp	0x141 <?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0x141>
      8b: 48 8b 4f 10                  	movq	0x10(%rdi), %rcx
      8f: 4c 8b 4d 07                  	movq	0x7(%rbp), %r9
      93: 4d 85 c9                     	testq	%r9, %r9
      96: 74 35                        	je	0xcd <?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0xcd>
      98: 48 8b 55 f7                  	movq	-0x9(%rbp), %rdx
      9c: 48 39 55 e7                  	cmpq	%rdx, -0x19(%rbp)
      a0: 75 2b                        	jne	0xcd <?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0xcd>
      a2: 48 8b 45 ff                  	movq	-0x1(%rbp), %rax
      a6: 48 39 45 ef                  	cmpq	%rax, -0x11(%rbp)
      aa: 75 21                        	jne	0xcd <?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0xcd>
      ac: 0f 10 01                     	movups	(%rcx), %xmm0
      af: 0f 29 45 c7                  	movaps	%xmm0, -0x39(%rbp)
      b3: f2 0f 10 49 10               	movsd	0x10(%rcx), %xmm1
      b8: f2 0f 11 4d d7               	movsd	%xmm1, -0x29(%rbp)
      bd: 4c 8d 45 c7                  	leaq	-0x39(%rbp), %r8
      c1: 48 8d 4d 37                  	leaq	0x37(%rbp), %rcx
      c5: 41 ff d1                     	callq	*%r9
      c8: 48 8b c8                     	movq	%rax, %rcx
      cb: eb 11                        	jmp	0xde <?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0xde>
      cd: 0f 57 c0                     	xorps	%xmm0, %xmm0
      d0: 33 c0                        	xorl	%eax, %eax
      d2: 0f 11 45 c7                  	movups	%xmm0, -0x39(%rbp)
      d6: 48 89 45 d7                  	movq	%rax, -0x29(%rbp)
      da: 48 8d 4d c7                  	leaq	-0x39(%rbp), %rcx
      de: 48 8d 47 19                  	leaq	0x19(%rdi), %rax
      e2: 48 89 45 b7                  	movq	%rax, -0x49(%rbp)
      e6: 48 8d 45 e7                  	leaq	-0x19(%rbp), %rax
      ea: 48 89 45 bf                  	movq	%rax, -0x41(%rbp)
      ee: 0f 10 01                     	movups	(%rcx), %xmm0
      f1: 0f 29 45 17                  	movaps	%xmm0, 0x17(%rbp)
      f5: f2 0f 10 49 10               	movsd	0x10(%rcx), %xmm1
      fa: f2 0f 11 4d 27               	movsd	%xmm1, 0x27(%rbp)
      ff: 4c 8d 4d b7                  	leaq	-0x49(%rbp), %r9
     103: 4c 8d 45 17                  	leaq	0x17(%rbp), %r8
     107: 48 8b d6                     	movq	%rsi, %rdx
     10a: 48 8d 4d c7                  	leaq	-0x39(%rbp), %rcx
     10e: e8 00 00 00 00               	callq	0x113 <?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0x113>
		000000000000010f:  IMAGE_REL_AMD64_REL32	??$invokePreparedScriptAbilityAsync@XV<lambda_1>@?1???$?R$$V@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PXZ@$$V@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@VPreparedLocalAsyncStart@012@$$QEAV<lambda_1>@?1???$?R$$V@6?1???R6?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@$$V@std@@V6?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@XZ@@Z@QEAA@AEAV7012@0@Z@QEBA?A_PXZ@@Z
     113: 0f 10 00                     	movups	(%rax), %xmm0
     116: 48 8b 47 20                  	movq	0x20(%rdi), %rax
     11a: 48 89 58 10                  	movq	%rbx, 0x10(%rax)
     11e: 48 89 58 18                  	movq	%rbx, 0x18(%rax)
     122: eb 1d                        	jmp	0x141 <?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0x141>
     124: c6 45 b7 02                  	movb	$0x2, -0x49(%rbp)
     128: 33 db                        	xorl	%ebx, %ebx
     12a: 48 89 5d bb                  	movq	%rbx, -0x45(%rbp)
     12e: c7 45 c3 ff ff ff ff         	movl	$0xffffffff, -0x3d(%rbp) # imm = 0xFFFFFFFF
     135: 0f 10 45 b7                  	movups	-0x49(%rbp), %xmm0
     139: 48 89 5a 20                  	movq	%rbx, 0x20(%rdx)
     13d: 48 89 5a 28                  	movq	%rbx, 0x28(%rdx)
     141: 0f 11 00                     	movups	%xmm0, (%rax)
     144: 4c 8d 9c 24 c0 00 00 00      	leaq	0xc0(%rsp), %r11
     14c: 49 8b 5b 10                  	movq	0x10(%r11), %rbx
     150: 49 8b 73 18                  	movq	0x18(%r11), %rsi
     154: 49 8b 7b 20                  	movq	0x20(%r11), %rdi
     158: 49 8b e3                     	movq	%r11, %rsp
     15b: 5d                           	popq	%rbp
     15c: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 74 24 10               	movq	%rsi, 0x10(%rsp)
       a: 48 89 7c 24 18               	movq	%rdi, 0x18(%rsp)
       f: 55                           	pushq	%rbp
      10: 48 8d 6c 24 a9               	leaq	-0x57(%rsp), %rbp
      15: 48 81 ec c0 00 00 00         	subq	$0xc0, %rsp
      1c: 48 8b f9                     	movq	%rcx, %rdi
      1f: 48 8d 42 10                  	leaq	0x10(%rdx), %rax
      23: 48 89 41 28                  	movq	%rax, 0x28(%rcx)
      27: 48 8b 09                     	movq	(%rcx), %rcx
      2a: 48 85 c9                     	testq	%rcx, %rcx
      2d: 0f 84 fe 00 00 00            	je	0x131 <?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0x131>
      33: 48 8b 71 58                  	movq	0x58(%rcx), %rsi
      37: 48 85 f6                     	testq	%rsi, %rsi
      3a: 0f 84 f1 00 00 00            	je	0x131 <?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0x131>
      40: 0f 57 c0                     	xorps	%xmm0, %xmm0
      43: f3 0f 7f 45 07               	movdqu	%xmm0, 0x7(%rbp)
      48: 33 db                        	xorl	%ebx, %ebx
      4a: 48 89 5d 17                  	movq	%rbx, 0x17(%rbp)
      4e: 48 89 5d 1f                  	movq	%rbx, 0x1f(%rbp)
      52: 48 89 5d 27                  	movq	%rbx, 0x27(%rbp)
      56: 4c 8d 45 07                  	leaq	0x7(%rbp), %r8
      5a: 8b 57 08                     	movl	0x8(%rdi), %edx
      5d: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x63 <?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0x63>
		000000000000005f:  IMAGE_REL_AMD64_REL32	__imp_?resolveAbility@ScriptCoroutineContext@script@simulation@lux@@AEBA_NIAEAUScriptCoroutineAbilityAccess@detail@234@@Z
      63: 84 c0                        	testb	%al, %al
      65: 75 24                        	jne	0x8b <?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0x8b>
      67: c6 45 c7 02                  	movb	$0x2, -0x39(%rbp)
      6b: 48 89 5d cb                  	movq	%rbx, -0x35(%rbp)
      6f: c7 45 d3 ff ff ff ff         	movl	$0xffffffff, -0x2d(%rbp) # imm = 0xFFFFFFFF
      76: 0f 28 45 c7                  	movaps	-0x39(%rbp), %xmm0
      7a: 48 8b 47 28                  	movq	0x28(%rdi), %rax
      7e: 48 89 58 10                  	movq	%rbx, 0x10(%rax)
      82: 48 89 58 18                  	movq	%rbx, 0x18(%rax)
      86: e9 c3 00 00 00               	jmp	0x14e <?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0x14e>
      8b: 48 8b 4f 10                  	movq	0x10(%rdi), %rcx
      8f: 4c 8b 4d 27                  	movq	0x27(%rbp), %r9
      93: 4d 85 c9                     	testq	%r9, %r9
      96: 74 35                        	je	0xcd <?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0xcd>
      98: 48 8b 55 17                  	movq	0x17(%rbp), %rdx
      9c: 48 39 55 07                  	cmpq	%rdx, 0x7(%rbp)
      a0: 75 2b                        	jne	0xcd <?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0xcd>
      a2: 48 8b 45 1f                  	movq	0x1f(%rbp), %rax
      a6: 48 39 45 0f                  	cmpq	%rax, 0xf(%rbp)
      aa: 75 21                        	jne	0xcd <?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0xcd>
      ac: 0f 10 01                     	movups	(%rcx), %xmm0
      af: 0f 29 45 e7                  	movaps	%xmm0, -0x19(%rbp)
      b3: f2 0f 10 49 10               	movsd	0x10(%rcx), %xmm1
      b8: f2 0f 11 4d f7               	movsd	%xmm1, -0x9(%rbp)
      bd: 4c 8d 45 e7                  	leaq	-0x19(%rbp), %r8
      c1: 48 8d 4d c7                  	leaq	-0x39(%rbp), %rcx
      c5: 41 ff d1                     	callq	*%r9
      c8: 48 8b d0                     	movq	%rax, %rdx
      cb: eb 11                        	jmp	0xde <?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0xde>
      cd: 0f 57 c0                     	xorps	%xmm0, %xmm0
      d0: 33 c0                        	xorl	%eax, %eax
      d2: 0f 11 45 c7                  	movups	%xmm0, -0x39(%rbp)
      d6: 48 89 45 d7                  	movq	%rax, -0x29(%rbp)
      da: 48 8d 55 c7                  	leaq	-0x39(%rbp), %rdx
      de: 48 8d 4f 18                  	leaq	0x18(%rdi), %rcx
      e2: 48 8d 47 20                  	leaq	0x20(%rdi), %rax
      e6: 48 89 45 e7                  	movq	%rax, -0x19(%rbp)
      ea: 48 8d 45 07                  	leaq	0x7(%rbp), %rax
      ee: 48 89 45 ef                  	movq	%rax, -0x11(%rbp)
      f2: 48 89 4d f7                  	movq	%rcx, -0x9(%rbp)
      f6: 0f 10 02                     	movups	(%rdx), %xmm0
      f9: 0f 29 45 37                  	movaps	%xmm0, 0x37(%rbp)
      fd: f2 0f 10 4a 10               	movsd	0x10(%rdx), %xmm1
     102: f2 0f 11 4d 47               	movsd	%xmm1, 0x47(%rbp)
     107: 48 89 4c 24 20               	movq	%rcx, 0x20(%rsp)
     10c: 4c 8d 4d e7                  	leaq	-0x19(%rbp), %r9
     110: 4c 8d 45 37                  	leaq	0x37(%rbp), %r8
     114: 48 8b d6                     	movq	%rsi, %rdx
     117: 48 8d 4d c7                  	leaq	-0x39(%rbp), %rcx
     11b: e8 00 00 00 00               	callq	0x120 <?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0x120>
		000000000000011c:  IMAGE_REL_AMD64_REL32	??$invokePreparedScriptAbilityAsync@XV<lambda_1>@?1???$?RN@1?1???R1?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@QEAA@AEAV2345@AEAUScriptStepContext@345@@Z@QEBA?A_PAEAN@Z@N@script@simulation@lux@@YA?AUScriptStepResult@012@AEAUScriptStepContext@012@VPreparedLocalAsyncStart@012@$$QEAV<lambda_1>@?1???$?RN@6?1???R6?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@012@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@2@V?$tuple@N@std@@V6?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@02@QEBA@N@Z@@Z@QEAA@AEAV7012@0@Z@QEBA?A_PAEAN@Z@6@Z
     120: 0f 10 00                     	movups	(%rax), %xmm0
     123: 48 8b 47 28                  	movq	0x28(%rdi), %rax
     127: 48 89 58 10                  	movq	%rbx, 0x10(%rax)
     12b: 48 89 58 18                  	movq	%rbx, 0x18(%rax)
     12f: eb 1d                        	jmp	0x14e <?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z+0x14e>
     131: c6 45 c7 02                  	movb	$0x2, -0x39(%rbp)
     135: 33 db                        	xorl	%ebx, %ebx
     137: 48 89 5d cb                  	movq	%rbx, -0x35(%rbp)
     13b: c7 45 d3 ff ff ff ff         	movl	$0xffffffff, -0x2d(%rbp) # imm = 0xFFFFFFFF
     142: 0f 10 45 c7                  	movups	-0x39(%rbp), %xmm0
     146: 48 89 5a 20                  	movq	%rbx, 0x20(%rdx)
     14a: 48 89 5a 28                  	movq	%rbx, 0x28(%rdx)
     14e: 0f 11 00                     	movups	%xmm0, (%rax)
     151: 4c 8d 9c 24 c0 00 00 00      	leaq	0xc0(%rsp), %r11
     159: 49 8b 5b 10                  	movq	0x10(%r11), %rbx
     15d: 49 8b 73 18                  	movq	0x18(%r11), %rsi
     161: 49 8b 7b 20                  	movq	0x20(%r11), %rdi
     165: 49 8b e3                     	movq	%r11, %rsp
     168: 5d                           	popq	%rbp
     169: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: void __cdecl lux::simulation::script::ScriptCoroutineFailure::await_suspend(struct std::coroutine_handle<struct lux::simulation::script::ScriptCoroutine::promise_type>) const>:
       0: 48 83 ec 18                  	subq	$0x18, %rsp
       4: 8b 01                        	movl	(%rcx), %eax
       6: 45 33 c0                     	xorl	%r8d, %r8d
       9: 4c 89 44 24 04               	movq	%r8, 0x4(%rsp)
       e: c6 04 24 02                  	movb	$0x2, (%rsp)
      12: 89 44 24 0c                  	movl	%eax, 0xc(%rsp)
      16: 0f 10 04 24                  	movups	(%rsp), %xmm0
      1a: 4c 89 42 20                  	movq	%r8, 0x20(%rdx)
      1e: 4c 89 42 28                  	movq	%r8, 0x28(%rdx)
      22: 0f 11 42 10                  	movups	%xmm0, 0x10(%rdx)
      26: 48 83 c4 18                  	addq	$0x18, %rsp
      2a: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: void __cdecl std::suspend_always::await_suspend(struct std::coroutine_handle<void>) const>:
       0: c2 00 00                     	retq	$0x0

Disassembly of section .text$mn:

0000000000000000 <public: void __cdecl std::suspend_never::await_suspend(struct std::coroutine_handle<void>) const>:
       0: c2 00 00                     	retq	$0x0

Disassembly of section .text$mn:

0000000000000000 <int __cdecl lux::simulation::script::detail::awaitableCreateStatus(enum lux::simulation::script::EScriptAwaitableCreateError)>:
       0: 80 f9 05                     	cmpb	$0x5, %cl
       3: 77 2e                        	ja	0x33 <$LN2>
       5: 48 8d 15 00 00 00 00         	leaq	(%rip), %rdx            # 0xc <int __cdecl lux::simulation::script::detail::awaitableCreateStatus(enum lux::simulation::script::EScriptAwaitableCreateError)+0xc>
		0000000000000008:  IMAGE_REL_AMD64_REL32	__ImageBase
       c: 0f b6 c1                     	movzbl	%cl, %eax
       f: 8b 84 82 00 00 00 00         	movl	(%rdx,%rax,4), %eax
		0000000000000012:  IMAGE_REL_AMD64_ADDR32NB	$LN12
      16: 48 03 c2                     	addq	%rdx, %rax
      19: ff e0                        	jmpq	*%rax

000000000000001b <$LN4>:
      1b: b8 fe ff ff ff               	movl	$0xfffffffe, %eax       # imm = 0xFFFFFFFE
      20: c3                           	retq

0000000000000021 <$LN5>:
      21: b8 fd ff ff ff               	movl	$0xfffffffd, %eax       # imm = 0xFFFFFFFD
      26: c3                           	retq

0000000000000027 <$LN6>:
      27: b8 fc ff ff ff               	movl	$0xfffffffc, %eax       # imm = 0xFFFFFFFC
      2c: c3                           	retq

000000000000002d <$LN7>:
      2d: b8 fa ff ff ff               	movl	$0xfffffffa, %eax       # imm = 0xFFFFFFFA
      32: c3                           	retq

0000000000000033 <$LN2>:
      33: b8 ff ff ff ff               	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
      38: c3                           	retq
      39: 0f 1f 00                     	nopl	(%rax)

000000000000003c <$LN12>:
      3c: 00 00                        	addb	%al, (%rax)
		000000000000003c:  IMAGE_REL_AMD64_ADDR32NB	$LN2
      3e: 00 00                        	addb	%al, (%rax)
      40: 00 00                        	addb	%al, (%rax)
		0000000000000040:  IMAGE_REL_AMD64_ADDR32NB	$LN2
      42: 00 00                        	addb	%al, (%rax)
      44: 00 00                        	addb	%al, (%rax)
		0000000000000044:  IMAGE_REL_AMD64_ADDR32NB	$LN7
      46: 00 00                        	addb	%al, (%rax)
      48: 00 00                        	addb	%al, (%rax)
		0000000000000048:  IMAGE_REL_AMD64_ADDR32NB	$LN4
      4a: 00 00                        	addb	%al, (%rax)
      4c: 00 00                        	addb	%al, (%rax)
		000000000000004c:  IMAGE_REL_AMD64_ADDR32NB	$LN5
      4e: 00 00                        	addb	%al, (%rax)
      50: 00 00                        	addb	%al, (%rax)
		0000000000000050:  IMAGE_REL_AMD64_ADDR32NB	$LN6
      52: 00 00                        	addb	%al, (%rax)

Disassembly of section .text$mn:

0000000000000000 <public: static class lux::script::ScriptAbilityErasedCompletion __cdecl lux::script::ScriptAbilityErasedCompletion::bind(class std::shared_ptr<void>, void *, unsigned __int64, unsigned __int64, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, unsigned __int64, void const *, unsigned int) noexcept, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, struct lux::script::ScriptAbilityOperationError) noexcept, bool (__cdecl *)(void *, unsigned __int64, unsigned __int64) noexcept, void *, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, unsigned __int64, void const *, unsigned int) noexcept, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, struct lux::script::ScriptAbilityOperationError) noexcept)>:
       0: 48 89 5c 24 10               	movq	%rbx, 0x10(%rsp)
       5: 57                           	pushq	%rdi
       6: 48 83 ec 20                  	subq	$0x20, %rsp
       a: 48 8b 42 08                  	movq	0x8(%rdx), %rax
       e: 48 8b f9                     	movq	%rcx, %rdi
      11: 4c 8b 12                     	movq	(%rdx), %r10
      14: 33 c9                        	xorl	%ecx, %ecx
      16: 48 89 4a 08                  	movq	%rcx, 0x8(%rdx)
      1a: 48 89 0a                     	movq	%rcx, (%rdx)
      1d: 48 89 47 08                  	movq	%rax, 0x8(%rdi)
      21: 48 8b 44 24 50               	movq	0x50(%rsp), %rax
      26: 48 89 47 20                  	movq	%rax, 0x20(%rdi)
      2a: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
      2f: 48 89 47 28                  	movq	%rax, 0x28(%rdi)
      33: 48 8b 44 24 60               	movq	0x60(%rsp), %rax
      38: 48 89 47 30                  	movq	%rax, 0x30(%rdi)
      3c: 48 8b 44 24 68               	movq	0x68(%rsp), %rax
      41: 48 89 47 38                  	movq	%rax, 0x38(%rdi)
      45: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
      4a: 48 89 47 40                  	movq	%rax, 0x40(%rdi)
      4e: 48 8b 44 24 78               	movq	0x78(%rsp), %rax
      53: 48 89 47 48                  	movq	%rax, 0x48(%rdi)
      57: 48 8b 84 24 80 00 00 00      	movq	0x80(%rsp), %rax
      5f: 48 89 47 50                  	movq	%rax, 0x50(%rdi)
      63: 4c 89 17                     	movq	%r10, (%rdi)
      66: 4c 89 47 10                  	movq	%r8, 0x10(%rdi)
      6a: 4c 89 4f 18                  	movq	%r9, 0x18(%rdi)
      6e: 48 8b 5a 08                  	movq	0x8(%rdx), %rbx
      72: 48 85 db                     	testq	%rbx, %rbx
      75: 74 44                        	je	0xbb <public: static class lux::script::ScriptAbilityErasedCompletion __cdecl lux::script::ScriptAbilityErasedCompletion::bind(class std::shared_ptr<void>, void *, unsigned __int64, unsigned __int64, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, unsigned __int64, void const *, unsigned int) noexcept, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, struct lux::script::ScriptAbilityOperationError) noexcept, bool (__cdecl *)(void *, unsigned __int64, unsigned __int64) noexcept, void *, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, unsigned __int64, void const *, unsigned int) noexcept, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, struct lux::script::ScriptAbilityOperationError) noexcept)+0xbb>
      77: 48 89 74 24 30               	movq	%rsi, 0x30(%rsp)
      7c: be ff ff ff ff               	movl	$0xffffffff, %esi       # imm = 0xFFFFFFFF
      81: 8b c6                        	movl	%esi, %eax
      83: f0                           	lock
      84: 0f c1 43 08                  	xaddl	%eax, 0x8(%rbx)
      88: 83 f8 01                     	cmpl	$0x1, %eax
      8b: 75 1b                        	jne	0xa8 <public: static class lux::script::ScriptAbilityErasedCompletion __cdecl lux::script::ScriptAbilityErasedCompletion::bind(class std::shared_ptr<void>, void *, unsigned __int64, unsigned __int64, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, unsigned __int64, void const *, unsigned int) noexcept, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, struct lux::script::ScriptAbilityOperationError) noexcept, bool (__cdecl *)(void *, unsigned __int64, unsigned __int64) noexcept, void *, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, unsigned __int64, void const *, unsigned int) noexcept, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, struct lux::script::ScriptAbilityOperationError) noexcept)+0xa8>
      8d: 48 8b 03                     	movq	(%rbx), %rax
      90: 48 8b cb                     	movq	%rbx, %rcx
      93: ff 10                        	callq	*(%rax)
      95: f0                           	lock
      96: 0f c1 73 0c                  	xaddl	%esi, 0xc(%rbx)
      9a: 83 fe 01                     	cmpl	$0x1, %esi
      9d: 75 09                        	jne	0xa8 <public: static class lux::script::ScriptAbilityErasedCompletion __cdecl lux::script::ScriptAbilityErasedCompletion::bind(class std::shared_ptr<void>, void *, unsigned __int64, unsigned __int64, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, unsigned __int64, void const *, unsigned int) noexcept, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, struct lux::script::ScriptAbilityOperationError) noexcept, bool (__cdecl *)(void *, unsigned __int64, unsigned __int64) noexcept, void *, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, unsigned __int64, void const *, unsigned int) noexcept, class tl::expected<void, enum lux::script::EScriptAbilityCompletionError> (__cdecl *)(void *, unsigned __int64, unsigned __int64, struct lux::script::ScriptAbilityOperationError) noexcept)+0xa8>
      9f: 48 8b 03                     	movq	(%rbx), %rax
      a2: 48 8b cb                     	movq	%rbx, %rcx
      a5: ff 50 08                     	callq	*0x8(%rax)
      a8: 48 8b 74 24 30               	movq	0x30(%rsp), %rsi
      ad: 48 8b c7                     	movq	%rdi, %rax
      b0: 48 8b 5c 24 38               	movq	0x38(%rsp), %rbx
      b5: 48 83 c4 20                  	addq	$0x20, %rsp
      b9: 5f                           	popq	%rdi
      ba: c3                           	retq
      bb: 48 8b 5c 24 38               	movq	0x38(%rsp), %rbx
      c0: 48 8b c7                     	movq	%rdi, %rax
      c3: 48 83 c4 20                  	addq	$0x20, %rsp
      c7: 5f                           	popq	%rdi
      c8: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static struct lux::simulation::script::ScriptStepResult __cdecl lux::simulation::script::ScriptStepResult::completed(void)>:
       0: 33 c0                        	xorl	%eax, %eax
       2: c6 01 00                     	movb	$0x0, (%rcx)
       5: 48 89 41 04                  	movq	%rax, 0x4(%rcx)
       9: 89 41 0c                     	movl	%eax, 0xc(%rcx)
       c: 48 8b c1                     	movq	%rcx, %rax
       f: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: class tl::expected<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError> __cdecl lux::simulation::script::ScriptAwaitableFactory::create(class std::optional<struct lux::simulation::script::PreparedResumeType>) const>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 40                  	subq	$0x40, %rsp
       6: 48 8b da                     	movq	%rdx, %rbx
       9: 48 8b 41 08                  	movq	0x8(%rcx), %rax
       d: 48 85 c0                     	testq	%rax, %rax
      10: 75 0f                        	jne	0x21 <public: class tl::expected<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError> __cdecl lux::simulation::script::ScriptAwaitableFactory::create(class std::optional<struct lux::simulation::script::PreparedResumeType>) const+0x21>
      12: c6 02 05                     	movb	$0x5, (%rdx)
      15: 88 42 70                     	movb	%al, 0x70(%rdx)
      18: 48 8b c2                     	movq	%rdx, %rax
      1b: 48 83 c4 40                  	addq	$0x40, %rsp
      1f: 5b                           	popq	%rbx
      20: c3                           	retq
      21: 41 0f 10 00                  	movups	(%r8), %xmm0
      25: 0f 29 44 24 20               	movaps	%xmm0, 0x20(%rsp)
      2a: 41 0f 10 48 10               	movups	0x10(%r8), %xmm1
      2f: 0f 29 4c 24 30               	movaps	%xmm1, 0x30(%rsp)
      34: 4c 8d 4c 24 20               	leaq	0x20(%rsp), %r9
      39: 4c 8b 41 18                  	movq	0x18(%rcx), %r8
      3d: 48 8b 11                     	movq	(%rcx), %rdx
      40: 48 8b cb                     	movq	%rbx, %rcx
      43: ff d0                        	callq	*%rax
      45: 48 8b c3                     	movq	%rbx, %rax
      48: 48 83 c4 40                  	addq	$0x40, %rsp
      4c: 5b                           	popq	%rbx
      4d: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: void const *const * __cdecl std::array<void const *, 1>::data(void) const>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: void const *const * __cdecl std::array<void const *, 2>::data(void) const>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: void const *const * __cdecl std::array<void const *, 0>::data(void) const>:
       0: 33 c0                        	xorl	%eax, %eax
       2: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: struct lux_script_value_slot const * __cdecl std::array<struct lux_script_value_slot, 1>::data(void) const>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: struct lux_script_value_slot const * __cdecl std::array<struct lux_script_value_slot, 0>::data(void) const>:
       0: 33 c0                        	xorl	%eax, %eax
       2: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: void __cdecl lux::simulation::script::ScriptAwaitableFactory::discard(struct lux::simulation::script::ScriptAwaitableId) const>:
       0: 48 83 ec 28                  	subq	$0x28, %rsp
       4: 4c 8b 49 10                  	movq	0x10(%rcx), %r9
       8: 4d 85 c9                     	testq	%r9, %r9
       b: 74 1d                        	je	0x2a <public: void __cdecl lux::simulation::script::ScriptAwaitableFactory::discard(struct lux::simulation::script::ScriptAwaitableId) const+0x2a>
       d: 85 d2                        	testl	%edx, %edx
       f: 74 19                        	je	0x2a <public: void __cdecl lux::simulation::script::ScriptAwaitableFactory::discard(struct lux::simulation::script::ScriptAwaitableId) const+0x2a>
      11: 48 8b c2                     	movq	%rdx, %rax
      14: 48 c1 e8 20                  	shrq	$0x20, %rax
      18: 85 c0                        	testl	%eax, %eax
      1a: 74 0e                        	je	0x2a <public: void __cdecl lux::simulation::script::ScriptAwaitableFactory::discard(struct lux::simulation::script::ScriptAwaitableId) const+0x2a>
      1c: 4c 8b c2                     	movq	%rdx, %r8
      1f: 48 8b 51 18                  	movq	0x18(%rcx), %rdx
      23: 48 8b 09                     	movq	(%rcx), %rcx
      26: 41 ff d1                     	callq	*%r9
      29: 90                           	nop
      2a: 48 83 c4 28                  	addq	$0x28, %rsp
      2e: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <private: class tl::unexpected<enum lux::simulation::script::EScriptAwaitableCreateError> & __cdecl tl::expected<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>::err(void)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <private: class tl::unexpected<struct lux::script::ScriptAbilityOperationError> & __cdecl tl::expected<void, struct lux::script::ScriptAbilityOperationError>::err(void)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <private: class tl::unexpected<struct lux::simulation::script::ScriptSyncStepError> & __cdecl tl::expected<void, struct lux::simulation::script::ScriptSyncStepError>::err(void)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: enum lux::simulation::script::EScriptAwaitableCreateError & __cdecl tl::expected<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>::error(void) &>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: struct lux::script::ScriptAbilityOperationError & __cdecl tl::expected<void, struct lux::script::ScriptAbilityOperationError>::error(void) &>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: struct lux::simulation::script::ScriptSyncStepError & __cdecl tl::expected<void, struct lux::simulation::script::ScriptSyncStepError>::error(void) &>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::event$_DestroyCoro$2(class lux::simulation::script::ScriptCoroutineContext &)>:
       0: 48 83 49 50 01               	orq	$0x1, 0x50(%rcx)
       5: e9 00 00 00 00               	jmp	0xa <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::event$_DestroyCoro$2(class lux::simulation::script::ScriptCoroutineContext &)+0xa>
		0000000000000006:  IMAGE_REL_AMD64_REL32	?event$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z

Disassembly of section .text$mn:

0000000000000000 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::event$_ResumeCoro$1(class lux::simulation::script::ScriptCoroutineContext &)>:
       0: 48 89 5c 24 10               	movq	%rbx, 0x10(%rsp)
       5: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
       a: 48 89 4c 24 08               	movq	%rcx, 0x8(%rsp)
       f: 57                           	pushq	%rdi
      10: 48 83 ec 60                  	subq	$0x60, %rsp

0000000000000014 <$__resumable_prolog_label>:
      14: 48 8b 5c 24 70               	movq	0x70(%rsp), %rbx
      19: 0f b7 43 50                  	movzwl	0x50(%rbx), %eax
      1d: 66 89 44 24 30               	movw	%ax, 0x30(%rsp)
      22: 66 ff c0                     	incw	%ax
      25: 66 83 f8 08                  	cmpw	$0x8, %ax
      29: 0f 87 63 01 00 00            	ja	0x192 <$__resumable_state_0>
      2f: 48 0f bf c0                  	movswq	%ax, %rax
      33: 48 8d 15 00 00 00 00         	leaq	(%rip), %rdx            # 0x3a <$__resumable_prolog_label+0x26>
		0000000000000036:  IMAGE_REL_AMD64_REL32	__ImageBase
      3a: 8b 8c 82 00 00 00 00         	movl	(%rdx,%rax,4), %ecx
		000000000000003d:  IMAGE_REL_AMD64_ADDR32NB	$LN115
      41: 48 03 ca                     	addq	%rdx, %rcx
      44: ff e1                        	jmpq	*%rcx

0000000000000046 <$__resumable_state_3>:
      46: e9 35 01 00 00               	jmp	0x180 <$__resumable_state_1>

000000000000004b <$__resumable_state_2>:
      4b: 48 8d 53 60                  	leaq	0x60(%rbx), %rdx
      4f: 4c 8d 05 00 00 00 00         	leaq	(%rip), %r8             # 0x56 <$__resumable_state_2+0xb>
		0000000000000052:  IMAGE_REL_AMD64_REL32	?source@cost@na1@simulation@lux@@3V?$optional@V?$CppScriptEventSource@H@script@simulation@lux@@@std@@A
      56: 48 8b 4b 48                  	movq	0x48(%rbx), %rcx
      5a: e8 00 00 00 00               	callq	0x5f <$__resumable_state_2+0x14>
		000000000000005b:  IMAGE_REL_AMD64_REL32	??$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@123@@Z
      5f: 48 89 43 58                  	movq	%rax, 0x58(%rbx)
      63: b9 04 00 00 00               	movl	$0x4, %ecx
      68: 66 89 4b 50                  	movw	%cx, 0x50(%rbx)
      6c: 48 8b d3                     	movq	%rbx, %rdx
      6f: 48 8b c8                     	movq	%rax, %rcx
      72: e8 00 00 00 00               	callq	0x77 <$__resumable_state_2+0x2c>
		0000000000000073:  IMAGE_REL_AMD64_REL32	?await_suspend@?$ScriptCoroutineAwaiter@HV<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@345@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
      77: e9 17 01 00 00               	jmp	0x193 <$__resumable_epilog_label>

000000000000007c <$__resumable_state_5>:
      7c: e9 ff 00 00 00               	jmp	0x180 <$__resumable_state_1>

0000000000000081 <$__resumable_state_4>:
      81: 48 8b 43 58                  	movq	0x58(%rbx), %rax
      85: 48 8d 53 54                  	leaq	0x54(%rbx), %rdx
      89: 48 8b 40 18                  	movq	0x18(%rax), %rax
      8d: 48 8b 48 20                  	movq	0x20(%rax), %rcx
      91: 8b 01                        	movl	(%rcx), %eax
      93: 89 02                        	movl	%eax, (%rdx)
      95: 48 8d 83 d0 00 00 00         	leaq	0xd0(%rbx), %rax
      9c: 48 89 10                     	movq	%rdx, (%rax)
      9f: 33 f6                        	xorl	%esi, %esi
      a1: 48 89 74 24 28               	movq	%rsi, 0x28(%rsp)
      a6: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
      ab: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0xb2 <$__resumable_state_4+0x31>
		00000000000000ae:  IMAGE_REL_AMD64_REL32	?Shape@?$ScriptSyncStepCall@$$A6AXH@Z@detail@script@simulation@lux@@2UScriptSyncStepShape@345@B
      b2: 45 33 c0                     	xorl	%r8d, %r8d
      b5: 48 8d 93 80 00 00 00         	leaq	0x80(%rbx), %rdx
      bc: 48 8b 4b 48                  	movq	0x48(%rbx), %rcx
      c0: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xc6 <$__resumable_state_4+0x45>
		00000000000000c2:  IMAGE_REL_AMD64_REL32	__imp_?invokeSyncStep@ScriptCoroutineContext@script@simulation@lux@@AEAA?AV?$expected@XUScriptSyncStepError@script@simulation@lux@@@tl@@IAEBUScriptSyncStepShape@234@PEBQEBXPEAX@Z
      c6: 0f b6 83 8c 00 00 00         	movzbl	0x8c(%rbx), %eax
      cd: 88 44 24 54                  	movb	%al, 0x54(%rsp)
      d1: 84 c0                        	testb	%al, %al
      d3: 75 56                        	jne	0x12b <$__resumable_state_4+0xaa>
      d5: 4c 8d 83 b0 00 00 00         	leaq	0xb0(%rbx), %r8
      dc: f2 0f 10 83 80 00 00 00      	movsd	0x80(%rbx), %xmm0
      e4: f2 0f 11 44 24 48            	movsd	%xmm0, 0x48(%rsp)
      ea: 8b 83 88 00 00 00            	movl	0x88(%rbx), %eax
      f0: 89 44 24 50                  	movl	%eax, 0x50(%rsp)
      f4: f2 41 0f 11 00               	movsd	%xmm0, (%r8)
      f9: 41 89 40 08                  	movl	%eax, 0x8(%r8)
      fd: 48 8d 93 a0 00 00 00         	leaq	0xa0(%rbx), %rdx
     104: 48 8b 4b 48                  	movq	0x48(%rbx), %rcx
     108: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x10e <$__resumable_state_4+0x8d>
		000000000000010a:  IMAGE_REL_AMD64_REL32	__imp_?fail@ScriptCoroutineContext@script@simulation@lux@@QEAA?AVScriptCoroutineFailure@234@UScriptSyncStepError@234@@Z
     10e: 48 89 83 98 00 00 00         	movq	%rax, 0x98(%rbx)
     115: b9 06 00 00 00               	movl	$0x6, %ecx
     11a: 66 89 4b 50                  	movw	%cx, 0x50(%rbx)
     11e: 48 8b d3                     	movq	%rbx, %rdx
     121: 48 8b c8                     	movq	%rax, %rcx
     124: e8 00 00 00 00               	callq	0x129 <$__resumable_state_4+0xa8>
		0000000000000125:  IMAGE_REL_AMD64_REL32	?await_suspend@ScriptCoroutineFailure@script@simulation@lux@@QEBAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
     129: eb 68                        	jmp	0x193 <$__resumable_epilog_label>
     12b: 80 7b 10 02                  	cmpb	$0x2, 0x10(%rbx)
     12f: 74 24                        	je	0x155 <$$__resumable_return_label$117>
     131: 40 88 b3 c0 00 00 00         	movb	%sil, 0xc0(%rbx)
     138: 48 89 b3 c4 00 00 00         	movq	%rsi, 0xc4(%rbx)
     13f: 89 b3 cc 00 00 00            	movl	%esi, 0xcc(%rbx)
     145: 0f 10 83 c0 00 00 00         	movups	0xc0(%rbx), %xmm0
     14c: 0f 11 44 24 38               	movups	%xmm0, 0x38(%rsp)
     151: 0f 11 43 10                  	movups	%xmm0, 0x10(%rbx)

0000000000000155 <$$__resumable_return_label$117>:
     155: 48 8d 8b a4 00 00 00         	leaq	0xa4(%rbx), %rcx
     15c: 33 c0                        	xorl	%eax, %eax
     15e: 88 01                        	movb	%al, (%rcx)
     160: 66 89 43 50                  	movw	%ax, 0x50(%rbx)
     164: 48 89 33                     	movq	%rsi, (%rbx)
     167: 48 8b d3                     	movq	%rbx, %rdx
     16a: e8 00 00 00 00               	callq	0x16f <$$__resumable_return_label$117+0x1a>
		000000000000016b:  IMAGE_REL_AMD64_REL32	?await_suspend@suspend_always@std@@QEBAXU?$coroutine_handle@X@2@@Z
     16f: eb 22                        	jmp	0x193 <$__resumable_epilog_label>

0000000000000171 <$__resumable_state_7>:
     171: eb 0d                        	jmp	0x180 <$__resumable_state_1>

0000000000000173 <$__resumable_state_6>:
     173: 48 8b 8b 98 00 00 00         	movq	0x98(%rbx), %rcx
     17a: e8 00 00 00 00               	callq	0x17f <$__resumable_state_6+0xc>
		000000000000017b:  IMAGE_REL_AMD64_REL32	?await_resume@ScriptCoroutineFailure@script@simulation@lux@@QEBAXXZ
     17f: cc                           	int3

0000000000000180 <$__resumable_state_1>:
     180: 66 83 7b 52 00               	cmpw	$0x0, 0x52(%rbx)
     185: 74 0c                        	je	0x193 <$__resumable_epilog_label>
     187: 48 8b cb                     	movq	%rbx, %rcx
     18a: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x190 <$__resumable_state_1+0x10>
		000000000000018c:  IMAGE_REL_AMD64_REL32	__imp_?releaseFrame@ScriptCoroutineContext@script@simulation@lux@@CAXPEAX@Z
     190: eb 01                        	jmp	0x193 <$__resumable_epilog_label>

0000000000000192 <$__resumable_state_0>:
     192: cc                           	int3

0000000000000193 <$__resumable_epilog_label>:
     193: 48 8b 5c 24 78               	movq	0x78(%rsp), %rbx
     198: 48 8b b4 24 80 00 00 00      	movq	0x80(%rsp), %rsi
     1a0: 48 83 c4 60                  	addq	$0x60, %rsp
     1a4: 5f                           	popq	%rdi
     1a5: c3                           	retq
     1a6: cc                           	int3

00000000000001a7 <$LN116>:
     1a7: 90                           	nop

00000000000001a8 <$LN115>:
     1a8: 00 00                        	addb	%al, (%rax)
		00000000000001a8:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_1
     1aa: 00 00                        	addb	%al, (%rax)
     1ac: 00 00                        	addb	%al, (%rax)
		00000000000001ac:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_0
     1ae: 00 00                        	addb	%al, (%rax)
     1b0: 00 00                        	addb	%al, (%rax)
		00000000000001b0:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_1
     1b2: 00 00                        	addb	%al, (%rax)
     1b4: 00 00                        	addb	%al, (%rax)
		00000000000001b4:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_2
     1b6: 00 00                        	addb	%al, (%rax)
     1b8: 00 00                        	addb	%al, (%rax)
		00000000000001b8:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_3
     1ba: 00 00                        	addb	%al, (%rax)
     1bc: 00 00                        	addb	%al, (%rax)
		00000000000001bc:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_4
     1be: 00 00                        	addb	%al, (%rax)
     1c0: 00 00                        	addb	%al, (%rax)
		00000000000001c0:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_5
     1c2: 00 00                        	addb	%al, (%rax)
     1c4: 00 00                        	addb	%al, (%rax)
		00000000000001c4:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_6
     1c6: 00 00                        	addb	%al, (%rax)
     1c8: 00 00                        	addb	%al, (%rax)
		00000000000001c8:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_7
     1ca: 00 00                        	addb	%al, (%rax)

Disassembly of section .text$x:

0000000000000000 <int `public: class simulation::na1::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::event$_ResumeCoro$1(class simulation::na1::ScriptCoroutine::ScriptCoroutineContext &)'::`1'::catch$0>:
       0: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
       5: 55                           	pushq	%rbp
       6: 48 83 ec 30                  	subq	$0x30, %rsp
       a: 48 8b ea                     	movq	%rdx, %rbp

000000000000000d <__catch$?event$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z$0>:
       d: 48 8b 4d 70                  	movq	0x70(%rbp), %rcx
      11: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
      18: b8 ff ff ff ff               	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
      1d: 66 89 41 50                  	movw	%ax, 0x50(%rcx)
      21: 48 83 c1 10                  	addq	$0x10, %rcx
      25: e8 00 00 00 00               	callq	0x2a <__catch$?event$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z$0+0x1d>
		0000000000000026:  IMAGE_REL_AMD64_REL32	?unhandled_exception@promise_type@ScriptCoroutine@script@simulation@lux@@QEAAXXZ
      2a: 90                           	nop

Disassembly of section .text$mn:

0000000000000000 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::event(class lux::simulation::script::ScriptCoroutineContext &)>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 6c 24 10               	movq	%rbp, 0x10(%rsp)
       a: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
       f: 57                           	pushq	%rdi
      10: 48 83 ec 20                  	subq	$0x20, %rsp
      14: 49 8b f0                     	movq	%r8, %rsi
      17: 48 8b fa                     	movq	%rdx, %rdi
      1a: 48 8b e9                     	movq	%rcx, %rbp
      1d: ba e0 00 00 00               	movl	$0xe0, %edx
      22: 41 b8 08 00 00 00            	movl	$0x8, %r8d
      28: 48 8b ce                     	movq	%rsi, %rcx
      2b: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x31 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::event(class lux::simulation::script::ScriptCoroutineContext &)+0x31>
		000000000000002d:  IMAGE_REL_AMD64_REL32	__imp_?allocateFrame@ScriptCoroutineContext@script@simulation@lux@@AEAAPEAX_K0@Z
      31: 48 8b d8                     	movq	%rax, %rbx
      34: 48 8b cf                     	movq	%rdi, %rcx
      37: 48 85 c0                     	testq	%rax, %rax
      3a: 75 0b                        	jne	0x47 <$$__resumable_init_label$59>
      3c: 48 89 07                     	movq	%rax, (%rdi)
      3f: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x45 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::event(class lux::simulation::script::ScriptCoroutineContext &)+0x45>
		0000000000000041:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
      45: eb 59                        	jmp	0xa0 <$$__resumable_init_label$59+0x59>

0000000000000047 <$$__resumable_init_label$59>:
      47: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x4e <$$__resumable_init_label$59+0x7>
		000000000000004a:  IMAGE_REL_AMD64_REL32	?event$_DestroyCoro$2@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      4e: 48 89 43 08                  	movq	%rax, 0x8(%rbx)
      52: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x59 <$$__resumable_init_label$59+0x12>
		0000000000000055:  IMAGE_REL_AMD64_REL32	?event$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      59: 48 89 03                     	movq	%rax, (%rbx)
      5c: 48 89 6b 40                  	movq	%rbp, 0x40(%rbx)
      60: 48 89 73 48                  	movq	%rsi, 0x48(%rbx)
      64: c7 43 50 02 00 01 00         	movl	$0x10002, 0x50(%rbx)    # imm = 0x10002
      6b: 33 c0                        	xorl	%eax, %eax
      6d: 66 89 43 11                  	movw	%ax, 0x11(%rbx)
      71: 88 43 13                     	movb	%al, 0x13(%rbx)
      74: 88 43 10                     	movb	%al, 0x10(%rbx)
      77: 48 89 43 14                  	movq	%rax, 0x14(%rbx)
      7b: 89 43 1c                     	movl	%eax, 0x1c(%rbx)
      7e: 48 89 43 20                  	movq	%rax, 0x20(%rbx)
      82: 48 89 43 28                  	movq	%rax, 0x28(%rbx)
      86: 48 89 43 30                  	movq	%rax, 0x30(%rbx)
      8a: 48 8b d3                     	movq	%rbx, %rdx
      8d: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x93 <$$__resumable_init_label$59+0x4c>
		000000000000008f:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@AEAA@U?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
      93: 33 c0                        	xorl	%eax, %eax
      95: 88 43 38                     	movb	%al, 0x38(%rbx)
      98: 48 8b cb                     	movq	%rbx, %rcx
      9b: e8 00 00 00 00               	callq	0xa0 <$$__resumable_init_label$59+0x59>
		000000000000009c:  IMAGE_REL_AMD64_REL32	?event$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      a0: 48 8b c7                     	movq	%rdi, %rax
      a3: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
      a8: 48 8b 6c 24 38               	movq	0x38(%rsp), %rbp
      ad: 48 8b 74 24 40               	movq	0x40(%rsp), %rsi
      b2: 48 83 c4 20                  	addq	$0x20, %rsp
      b6: 5f                           	popq	%rdi
      b7: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static struct lux::simulation::script::ScriptStepResult __cdecl lux::simulation::script::ScriptStepResult::failed(int)>:
       0: 33 c0                        	xorl	%eax, %eax
       2: c6 01 02                     	movb	$0x2, (%rcx)
       5: 48 89 41 04                  	movq	%rax, 0x4(%rcx)
       9: 48 8b c1                     	movq	%rcx, %rax
       c: 89 51 0c                     	movl	%edx, 0xc(%rcx)
       f: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: struct std::suspend_always __cdecl lux::simulation::script::ScriptCoroutine::promise_type::final_suspend(void) const>:
       0: 33 c0                        	xorl	%eax, %eax
       2: 88 02                        	movb	%al, (%rdx)
       4: 48 8b c2                     	movq	%rdx, %rax
       7: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static class lux::script::ScriptAbilityCompletion<void> __cdecl lux::script::ScriptAbilityCompletion<void>::fromErased(class lux::script::ScriptAbilityErasedCompletion)>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 6c 24 10               	movq	%rbp, 0x10(%rsp)
       a: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
       f: 57                           	pushq	%rdi
      10: 41 56                        	pushq	%r14
      12: 41 57                        	pushq	%r15
      14: 48 83 ec 20                  	subq	$0x20, %rsp
      18: 48 8b 2a                     	movq	(%rdx), %rbp
      1b: 4c 8b f9                     	movq	%rcx, %r15
      1e: 48 8b 72 08                  	movq	0x8(%rdx), %rsi
      22: 4c 8b f2                     	movq	%rdx, %r14
      25: 33 c0                        	xorl	%eax, %eax
      27: 48 89 02                     	movq	%rax, (%rdx)
      2a: 48 89 42 08                  	movq	%rax, 0x8(%rdx)
      2e: 48 8b 5a 38                  	movq	0x38(%rdx), %rbx
      32: 48 8b 42 10                  	movq	0x10(%rdx), %rax
      36: 4c 8b 42 18                  	movq	0x18(%rdx), %r8
      3a: 4c 8b 4a 20                  	movq	0x20(%rdx), %r9
      3e: 4c 8b 52 28                  	movq	0x28(%rdx), %r10
      42: 4c 8b 5a 30                  	movq	0x30(%rdx), %r11
      46: 49 8b 4e 48                  	movq	0x48(%r14), %rcx
      4a: 49 8b 7e 50                  	movq	0x50(%r14), %rdi
      4e: 48 8b 52 40                  	movq	0x40(%rdx), %rdx
      52: 49 89 4f 48                  	movq	%rcx, 0x48(%r15)
      56: 49 89 7f 50                  	movq	%rdi, 0x50(%r15)
      5a: 49 89 2f                     	movq	%rbp, (%r15)
      5d: 49 89 77 08                  	movq	%rsi, 0x8(%r15)
      61: 49 89 47 10                  	movq	%rax, 0x10(%r15)
      65: 4d 89 47 18                  	movq	%r8, 0x18(%r15)
      69: 4d 89 4f 20                  	movq	%r9, 0x20(%r15)
      6d: 4d 89 57 28                  	movq	%r10, 0x28(%r15)
      71: 4d 89 5f 30                  	movq	%r11, 0x30(%r15)
      75: 49 89 5f 38                  	movq	%rbx, 0x38(%r15)
      79: 49 89 57 40                  	movq	%rdx, 0x40(%r15)
      7d: 49 8b 5e 08                  	movq	0x8(%r14), %rbx
      81: 48 85 db                     	testq	%rbx, %rbx
      84: 74 2c                        	je	0xb2 <public: static class lux::script::ScriptAbilityCompletion<void> __cdecl lux::script::ScriptAbilityCompletion<void>::fromErased(class lux::script::ScriptAbilityErasedCompletion)+0xb2>
      86: bf ff ff ff ff               	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
      8b: 8b c7                        	movl	%edi, %eax
      8d: f0                           	lock
      8e: 0f c1 43 08                  	xaddl	%eax, 0x8(%rbx)
      92: 83 f8 01                     	cmpl	$0x1, %eax
      95: 75 1b                        	jne	0xb2 <public: static class lux::script::ScriptAbilityCompletion<void> __cdecl lux::script::ScriptAbilityCompletion<void>::fromErased(class lux::script::ScriptAbilityErasedCompletion)+0xb2>
      97: 48 8b 03                     	movq	(%rbx), %rax
      9a: 48 8b cb                     	movq	%rbx, %rcx
      9d: ff 10                        	callq	*(%rax)
      9f: f0                           	lock
      a0: 0f c1 7b 0c                  	xaddl	%edi, 0xc(%rbx)
      a4: 83 ff 01                     	cmpl	$0x1, %edi
      a7: 75 09                        	jne	0xb2 <public: static class lux::script::ScriptAbilityCompletion<void> __cdecl lux::script::ScriptAbilityCompletion<void>::fromErased(class lux::script::ScriptAbilityErasedCompletion)+0xb2>
      a9: 48 8b 03                     	movq	(%rbx), %rax
      ac: 48 8b cb                     	movq	%rbx, %rcx
      af: ff 50 08                     	callq	*0x8(%rax)
      b2: 48 8b 5c 24 40               	movq	0x40(%rsp), %rbx
      b7: 49 8b c7                     	movq	%r15, %rax
      ba: 48 8b 6c 24 48               	movq	0x48(%rsp), %rbp
      bf: 48 8b 74 24 50               	movq	0x50(%rsp), %rsi
      c4: 48 83 c4 20                  	addq	$0x20, %rsp
      c8: 41 5f                        	popq	%r15
      ca: 41 5e                        	popq	%r14
      cc: 5f                           	popq	%rdi
      cd: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static struct std::coroutine_handle<struct lux::simulation::script::ScriptCoroutine::promise_type> __cdecl std::coroutine_handle<struct lux::simulation::script::ScriptCoroutine::promise_type>::from_address(void *const)>:
       0: 48 89 11                     	movq	%rdx, (%rcx)
       3: 48 8b c1                     	movq	%rcx, %rax
       6: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static struct std::coroutine_handle<void> __cdecl std::coroutine_handle<void>::from_address(void *const)>:
       0: 48 89 11                     	movq	%rdx, (%rcx)
       3: 48 8b c1                     	movq	%rcx, %rax
       6: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static struct std::coroutine_handle<struct lux::simulation::script::ScriptCoroutine::promise_type> __cdecl std::coroutine_handle<struct lux::simulation::script::ScriptCoroutine::promise_type>::from_promise(struct lux::simulation::script::ScriptCoroutine::promise_type &)>:
       0: 48 8d 42 f0                  	leaq	-0x10(%rdx), %rax
       4: 48 89 01                     	movq	%rax, (%rcx)
       7: 48 8b c1                     	movq	%rcx, %rax
       a: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::ScriptCoroutine::promise_type::get_return_object(void)>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 20                  	subq	$0x20, %rsp
       6: 48 8b da                     	movq	%rdx, %rbx
       9: 48 8d 51 f0                  	leaq	-0x10(%rcx), %rdx
       d: 48 8b cb                     	movq	%rbx, %rcx
      10: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x16 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::ScriptCoroutine::promise_type::get_return_object(void)+0x16>
		0000000000000012:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@AEAA@U?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
      16: 48 8b c3                     	movq	%rbx, %rax
      19: 48 83 c4 20                  	addq	$0x20, %rsp
      1d: 5b                           	popq	%rbx
      1e: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::ScriptCoroutine::promise_type::get_return_object_on_allocation_failure(void)>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 20                  	subq	$0x20, %rsp
       6: 33 c0                        	xorl	%eax, %eax
       8: 48 8b d9                     	movq	%rcx, %rbx
       b: 48 89 01                     	movq	%rax, (%rcx)
       e: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x14 <public: static class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::script::ScriptCoroutine::promise_type::get_return_object_on_allocation_failure(void)+0x14>
		0000000000000010:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
      14: 48 8b c3                     	movq	%rbx, %rax
      17: 48 83 c4 20                  	addq	$0x20, %rsp
      1b: 5b                           	popq	%rbx
      1c: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: struct std::suspend_never __cdecl lux::simulation::script::ScriptCoroutine::promise_type::initial_suspend(void) const>:
       0: 33 c0                        	xorl	%eax, %eax
       2: 88 02                        	movb	%al, (%rdx)
       4: 48 8b c2                     	movq	%rdx, %rax
       7: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: class lux::script::ScriptAbilityErasedCompletion __cdecl lux::simulation::script::ScriptAwaitableCompletion::intoAbilityCompletion(void) &&>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 6c 24 10               	movq	%rbp, 0x10(%rsp)
       a: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
       f: 48 89 7c 24 20               	movq	%rdi, 0x20(%rsp)
      14: 41 56                        	pushq	%r14
      16: 41 57                        	pushq	%r15
      18: 8b 41 34                     	movl	0x34(%rcx), %eax
      1b: 4c 8b fa                     	movq	%rdx, %r15
      1e: 44 8b 49 30                  	movl	0x30(%rcx), %r9d
      22: 4c 8b d9                     	movq	%rcx, %r11
      25: 44 8b 41 28                  	movl	0x28(%rcx), %r8d
      29: 48 8b 69 58                  	movq	0x58(%rcx), %rbp
      2d: 48 8b 71 50                  	movq	0x50(%rcx), %rsi
      31: 48 8b 79 48                  	movq	0x48(%rcx), %rdi
      35: 48 8b 59 40                  	movq	0x40(%rcx), %rbx
      39: 4c 8b 71 60                  	movq	0x60(%rcx), %r14
      3d: 4c 8b 51 38                  	movq	0x38(%rcx), %r10
      41: 48 8b 51 10                  	movq	0x10(%rcx), %rdx
      45: 49 c1 e1 20                  	shlq	$0x20, %r9
      49: 4c 0b c8                     	orq	%rax, %r9
      4c: 49 c1 e0 20                  	shlq	$0x20, %r8
      50: 8b 41 2c                     	movl	0x2c(%rcx), %eax
      53: 48 8b 09                     	movq	(%rcx), %rcx
      56: 4c 0b c0                     	orq	%rax, %r8
      59: 49 8b 43 08                  	movq	0x8(%r11), %rax
      5d: 49 c7 43 08 00 00 00 00      	movq	$0x0, 0x8(%r11)
      65: 49 c7 03 00 00 00 00         	movq	$0x0, (%r11)
      6c: 49 89 47 08                  	movq	%rax, 0x8(%r15)
      70: 49 8b c7                     	movq	%r15, %rax
      73: 49 89 5f 30                  	movq	%rbx, 0x30(%r15)
      77: 48 8b 5c 24 18               	movq	0x18(%rsp), %rbx
      7c: 49 89 7f 38                  	movq	%rdi, 0x38(%r15)
      80: 48 8b 7c 24 30               	movq	0x30(%rsp), %rdi
      85: 49 89 77 40                  	movq	%rsi, 0x40(%r15)
      89: 48 8b 74 24 28               	movq	0x28(%rsp), %rsi
      8e: 49 89 6f 48                  	movq	%rbp, 0x48(%r15)
      92: 48 8b 6c 24 20               	movq	0x20(%rsp), %rbp
      97: 49 89 0f                     	movq	%rcx, (%r15)
      9a: 49 89 57 10                  	movq	%rdx, 0x10(%r15)
      9e: 4d 89 47 18                  	movq	%r8, 0x18(%r15)
      a2: 4d 89 4f 20                  	movq	%r9, 0x20(%r15)
      a6: 4d 89 57 28                  	movq	%r10, 0x28(%r15)
      aa: 4d 89 77 50                  	movq	%r14, 0x50(%r15)
      ae: 41 5f                        	popq	%r15
      b0: 41 5e                        	popq	%r14
      b2: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <int __cdecl lux::simulation::script::detail::invocationStatus(enum lux::simulation::script::EScriptAbilityInvocationStatus)>:
       0: 8b c1                        	movl	%ecx, %eax
       2: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::longTask$_DestroyCoro$2(class lux::simulation::script::ScriptCoroutineContext &)>:
       0: 48 83 49 50 01               	orq	$0x1, 0x50(%rcx)
       5: e9 00 00 00 00               	jmp	0xa <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::longTask$_DestroyCoro$2(class lux::simulation::script::ScriptCoroutineContext &)+0xa>
		0000000000000006:  IMAGE_REL_AMD64_REL32	?longTask$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z

Disassembly of section .text$mn:

0000000000000000 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::longTask$_ResumeCoro$1(class lux::simulation::script::ScriptCoroutineContext &)>:
       0: 48 89 5c 24 10               	movq	%rbx, 0x10(%rsp)
       5: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
       a: 48 89 7c 24 20               	movq	%rdi, 0x20(%rsp)
       f: 48 89 4c 24 08               	movq	%rcx, 0x8(%rsp)
      14: 41 56                        	pushq	%r14
      16: 48 83 ec 60                  	subq	$0x60, %rsp
      1a: 48 8b 5c 24 70               	movq	0x70(%rsp), %rbx

000000000000001f <$__resumable_prolog_label>:
      1f: 0f b7 43 50                  	movzwl	0x50(%rbx), %eax
      23: 66 89 44 24 30               	movw	%ax, 0x30(%rsp)
      28: 66 ff c0                     	incw	%ax
      2b: 66 83 f8 08                  	cmpw	$0x8, %ax
      2f: 0f 87 8d 01 00 00            	ja	0x1c2 <$__resumable_state_0>
      35: 48 0f bf c0                  	movswq	%ax, %rax
      39: 48 8d 15 00 00 00 00         	leaq	(%rip), %rdx            # 0x40 <$__resumable_prolog_label+0x21>
		000000000000003c:  IMAGE_REL_AMD64_REL32	__ImageBase
      40: 8b 8c 82 00 00 00 00         	movl	(%rdx,%rax,4), %ecx
		0000000000000043:  IMAGE_REL_AMD64_ADDR32NB	$LN122
      47: 48 03 ca                     	addq	%rdx, %rcx
      4a: ff e1                        	jmpq	*%rcx

000000000000004c <$__resumable_state_3>:
      4c: e9 5f 01 00 00               	jmp	0x1b0 <$__resumable_state_1>

0000000000000051 <$__resumable_state_2>:
      51: 33 ff                        	xorl	%edi, %edi
      53: 89 7b 54                     	movl	%edi, 0x54(%rbx)
      56: 8b c7                        	movl	%edi, %eax
      58: 48 8d 73 48                  	leaq	0x48(%rbx), %rsi
      5c: e9 bf 00 00 00               	jmp	0x120 <$__resumable_state_4+0xba>

0000000000000061 <$__resumable_state_5>:
      61: e9 4a 01 00 00               	jmp	0x1b0 <$__resumable_state_1>

0000000000000066 <$__resumable_state_4>:
      66: 48 8b 43 60                  	movq	0x60(%rbx), %rax
      6a: 48 8d 53 58                  	leaq	0x58(%rbx), %rdx
      6e: 48 8b 40 18                  	movq	0x18(%rax), %rax
      72: 48 8b 48 20                  	movq	0x20(%rax), %rcx
      76: 8b 01                        	movl	(%rcx), %eax
      78: 89 02                        	movl	%eax, (%rdx)
      7a: 48 8d 73 48                  	leaq	0x48(%rbx), %rsi
      7e: 48 8d 83 d0 00 00 00         	leaq	0xd0(%rbx), %rax
      85: 48 89 10                     	movq	%rdx, (%rax)
      88: 33 ff                        	xorl	%edi, %edi
      8a: 48 89 7c 24 28               	movq	%rdi, 0x28(%rsp)
      8f: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
      94: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0x9b <$__resumable_state_4+0x35>
		0000000000000097:  IMAGE_REL_AMD64_REL32	?Shape@?$ScriptSyncStepCall@$$A6AXH@Z@detail@script@simulation@lux@@2UScriptSyncStepShape@345@B
      9b: 45 33 c0                     	xorl	%r8d, %r8d
      9e: 48 8d 93 88 00 00 00         	leaq	0x88(%rbx), %rdx
      a5: 48 8b 0e                     	movq	(%rsi), %rcx
      a8: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xae <$__resumable_state_4+0x48>
		00000000000000aa:  IMAGE_REL_AMD64_REL32	__imp_?invokeSyncStep@ScriptCoroutineContext@script@simulation@lux@@AEAA?AV?$expected@XUScriptSyncStepError@script@simulation@lux@@@tl@@IAEBUScriptSyncStepShape@234@PEBQEBXPEAX@Z
      ae: 0f b6 83 94 00 00 00         	movzbl	0x94(%rbx), %eax
      b5: 88 44 24 54                  	movb	%al, 0x54(%rsp)
      b9: 84 c0                        	testb	%al, %al
      bb: 75 58                        	jne	0x115 <$__resumable_state_4+0xaf>
      bd: 4c 8d 83 b0 00 00 00         	leaq	0xb0(%rbx), %r8
      c4: f2 0f 10 83 88 00 00 00      	movsd	0x88(%rbx), %xmm0
      cc: f2 0f 11 44 24 48            	movsd	%xmm0, 0x48(%rsp)
      d2: 8b 83 90 00 00 00            	movl	0x90(%rbx), %eax
      d8: 89 44 24 50                  	movl	%eax, 0x50(%rsp)
      dc: f2 41 0f 11 00               	movsd	%xmm0, (%r8)
      e1: 41 89 40 08                  	movl	%eax, 0x8(%r8)
      e5: 48 8d 93 a8 00 00 00         	leaq	0xa8(%rbx), %rdx
      ec: 48 8b 0e                     	movq	(%rsi), %rcx
      ef: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xf5 <$__resumable_state_4+0x8f>
		00000000000000f1:  IMAGE_REL_AMD64_REL32	__imp_?fail@ScriptCoroutineContext@script@simulation@lux@@QEAA?AVScriptCoroutineFailure@234@UScriptSyncStepError@234@@Z
      f5: 48 89 83 a0 00 00 00         	movq	%rax, 0xa0(%rbx)
      fc: b9 06 00 00 00               	movl	$0x6, %ecx
     101: 66 89 4b 50                  	movw	%cx, 0x50(%rbx)
     105: 48 8b d3                     	movq	%rbx, %rdx
     108: 48 8b c8                     	movq	%rax, %rcx
     10b: e8 00 00 00 00               	callq	0x110 <$__resumable_state_4+0xaa>
		000000000000010c:  IMAGE_REL_AMD64_REL32	?await_suspend@ScriptCoroutineFailure@script@simulation@lux@@QEBAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
     110: e9 ae 00 00 00               	jmp	0x1c3 <$__resumable_epilog_label>
     115: 8b 43 54                     	movl	0x54(%rbx), %eax
     118: ff c0                        	incl	%eax
     11a: 89 43 54                     	movl	%eax, 0x54(%rbx)
     11d: 0f 1f 00                     	nopl	(%rax)
     120: 83 f8 20                     	cmpl	$0x20, %eax
     123: 73 2d                        	jae	0x152 <$__resumable_state_4+0xec>
     125: 48 8d 53 68                  	leaq	0x68(%rbx), %rdx
     129: 4c 8d 05 00 00 00 00         	leaq	(%rip), %r8             # 0x130 <$__resumable_state_4+0xca>
		000000000000012c:  IMAGE_REL_AMD64_REL32	?source@cost@na1@simulation@lux@@3V?$optional@V?$CppScriptEventSource@H@script@simulation@lux@@@std@@A
     130: 48 8b 0e                     	movq	(%rsi), %rcx
     133: e8 00 00 00 00               	callq	0x138 <$__resumable_state_4+0xd2>
		0000000000000134:  IMAGE_REL_AMD64_REL32	??$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@123@@Z
     138: 48 89 43 60                  	movq	%rax, 0x60(%rbx)
     13c: b9 04 00 00 00               	movl	$0x4, %ecx
     141: 66 89 4b 50                  	movw	%cx, 0x50(%rbx)
     145: 48 8b d3                     	movq	%rbx, %rdx
     148: 48 8b c8                     	movq	%rax, %rcx
     14b: e8 00 00 00 00               	callq	0x150 <$__resumable_state_4+0xea>
		000000000000014c:  IMAGE_REL_AMD64_REL32	?await_suspend@?$ScriptCoroutineAwaiter@HV<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@345@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
     150: eb 71                        	jmp	0x1c3 <$__resumable_epilog_label>
     152: 80 7b 10 02                  	cmpb	$0x2, 0x10(%rbx)
     156: 74 28                        	je	0x180 <$$__resumable_return_label$124>
     158: c6 83 c0 00 00 00 00         	movb	$0x0, 0xc0(%rbx)
     15f: 48 c7 83 c4 00 00 00 00 00 00 00     	movq	$0x0, 0xc4(%rbx)
     16a: 89 bb cc 00 00 00            	movl	%edi, 0xcc(%rbx)
     170: 0f 10 83 c0 00 00 00         	movups	0xc0(%rbx), %xmm0
     177: 0f 11 44 24 38               	movups	%xmm0, 0x38(%rsp)
     17c: 0f 11 43 10                  	movups	%xmm0, 0x10(%rbx)

0000000000000180 <$$__resumable_return_label$124>:
     180: 48 8d 8b ac 00 00 00         	leaq	0xac(%rbx), %rcx
     187: 33 c0                        	xorl	%eax, %eax
     189: 88 01                        	movb	%al, (%rcx)
     18b: 66 89 43 50                  	movw	%ax, 0x50(%rbx)
     18f: 48 89 3b                     	movq	%rdi, (%rbx)
     192: 48 8b d3                     	movq	%rbx, %rdx
     195: e8 00 00 00 00               	callq	0x19a <$$__resumable_return_label$124+0x1a>
		0000000000000196:  IMAGE_REL_AMD64_REL32	?await_suspend@suspend_always@std@@QEBAXU?$coroutine_handle@X@2@@Z
     19a: eb 27                        	jmp	0x1c3 <$__resumable_epilog_label>

000000000000019c <$__resumable_state_7>:
     19c: eb 12                        	jmp	0x1b0 <$__resumable_state_1>

000000000000019e <$__resumable_state_6>:
     19e: 48 8b 8b a0 00 00 00         	movq	0xa0(%rbx), %rcx
     1a5: e8 00 00 00 00               	callq	0x1aa <$__resumable_state_6+0xc>
		00000000000001a6:  IMAGE_REL_AMD64_REL32	?await_resume@ScriptCoroutineFailure@script@simulation@lux@@QEBAXXZ
     1aa: cc                           	int3
     1ab: 0f 1f 44 00 00               	nopl	(%rax,%rax)

00000000000001b0 <$__resumable_state_1>:
     1b0: 66 83 7b 52 00               	cmpw	$0x0, 0x52(%rbx)
     1b5: 74 0c                        	je	0x1c3 <$__resumable_epilog_label>
     1b7: 48 8b cb                     	movq	%rbx, %rcx
     1ba: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x1c0 <$__resumable_state_1+0x10>
		00000000000001bc:  IMAGE_REL_AMD64_REL32	__imp_?releaseFrame@ScriptCoroutineContext@script@simulation@lux@@CAXPEAX@Z
     1c0: eb 01                        	jmp	0x1c3 <$__resumable_epilog_label>

00000000000001c2 <$__resumable_state_0>:
     1c2: cc                           	int3

00000000000001c3 <$__resumable_epilog_label>:
     1c3: 4c 8d 5c 24 60               	leaq	0x60(%rsp), %r11
     1c8: 49 8b 5b 18                  	movq	0x18(%r11), %rbx
     1cc: 49 8b 73 20                  	movq	0x20(%r11), %rsi
     1d0: 49 8b 7b 28                  	movq	0x28(%r11), %rdi
     1d4: 49 8b e3                     	movq	%r11, %rsp
     1d7: 41 5e                        	popq	%r14
     1d9: c3                           	retq
     1da: cc                           	int3

00000000000001db <$LN123>:
     1db: 90                           	nop

00000000000001dc <$LN122>:
     1dc: 00 00                        	addb	%al, (%rax)
		00000000000001dc:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_1
     1de: 00 00                        	addb	%al, (%rax)
     1e0: 00 00                        	addb	%al, (%rax)
		00000000000001e0:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_0
     1e2: 00 00                        	addb	%al, (%rax)
     1e4: 00 00                        	addb	%al, (%rax)
		00000000000001e4:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_1
     1e6: 00 00                        	addb	%al, (%rax)
     1e8: 00 00                        	addb	%al, (%rax)
		00000000000001e8:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_2
     1ea: 00 00                        	addb	%al, (%rax)
     1ec: 00 00                        	addb	%al, (%rax)
		00000000000001ec:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_3
     1ee: 00 00                        	addb	%al, (%rax)
     1f0: 00 00                        	addb	%al, (%rax)
		00000000000001f0:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_4
     1f2: 00 00                        	addb	%al, (%rax)
     1f4: 00 00                        	addb	%al, (%rax)
		00000000000001f4:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_5
     1f6: 00 00                        	addb	%al, (%rax)
     1f8: 00 00                        	addb	%al, (%rax)
		00000000000001f8:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_6
     1fa: 00 00                        	addb	%al, (%rax)
     1fc: 00 00                        	addb	%al, (%rax)
		00000000000001fc:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_7
     1fe: 00 00                        	addb	%al, (%rax)

Disassembly of section .text$x:

0000000000000000 <int `public: class simulation::na1::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::longTask$_ResumeCoro$1(class simulation::na1::ScriptCoroutine::ScriptCoroutineContext &)'::`1'::catch$0>:
       0: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
       5: 55                           	pushq	%rbp
       6: 48 83 ec 30                  	subq	$0x30, %rsp
       a: 48 8b ea                     	movq	%rdx, %rbp

000000000000000d <__catch$?longTask$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z$0>:
       d: 48 8b 4d 70                  	movq	0x70(%rbp), %rcx
      11: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
      18: b8 ff ff ff ff               	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
      1d: 66 89 41 50                  	movw	%ax, 0x50(%rcx)
      21: 48 83 c1 10                  	addq	$0x10, %rcx
      25: e8 00 00 00 00               	callq	0x2a <__catch$?longTask$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z$0+0x1d>
		0000000000000026:  IMAGE_REL_AMD64_REL32	?unhandled_exception@promise_type@ScriptCoroutine@script@simulation@lux@@QEAAXXZ
      2a: 90                           	nop

Disassembly of section .text$mn:

0000000000000000 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::longTask(class lux::simulation::script::ScriptCoroutineContext &)>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 6c 24 10               	movq	%rbp, 0x10(%rsp)
       a: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
       f: 57                           	pushq	%rdi
      10: 48 83 ec 20                  	subq	$0x20, %rsp
      14: 49 8b f0                     	movq	%r8, %rsi
      17: 48 8b fa                     	movq	%rdx, %rdi
      1a: 48 8b e9                     	movq	%rcx, %rbp
      1d: ba e0 00 00 00               	movl	$0xe0, %edx
      22: 41 b8 08 00 00 00            	movl	$0x8, %r8d
      28: 48 8b ce                     	movq	%rsi, %rcx
      2b: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x31 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::longTask(class lux::simulation::script::ScriptCoroutineContext &)+0x31>
		000000000000002d:  IMAGE_REL_AMD64_REL32	__imp_?allocateFrame@ScriptCoroutineContext@script@simulation@lux@@AEAAPEAX_K0@Z
      31: 48 8b d8                     	movq	%rax, %rbx
      34: 48 8b cf                     	movq	%rdi, %rcx
      37: 48 85 c0                     	testq	%rax, %rax
      3a: 75 0b                        	jne	0x47 <$$__resumable_init_label$59>
      3c: 48 89 07                     	movq	%rax, (%rdi)
      3f: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x45 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::longTask(class lux::simulation::script::ScriptCoroutineContext &)+0x45>
		0000000000000041:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
      45: eb 59                        	jmp	0xa0 <$$__resumable_init_label$59+0x59>

0000000000000047 <$$__resumable_init_label$59>:
      47: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x4e <$$__resumable_init_label$59+0x7>
		000000000000004a:  IMAGE_REL_AMD64_REL32	?longTask$_DestroyCoro$2@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      4e: 48 89 43 08                  	movq	%rax, 0x8(%rbx)
      52: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x59 <$$__resumable_init_label$59+0x12>
		0000000000000055:  IMAGE_REL_AMD64_REL32	?longTask$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      59: 48 89 03                     	movq	%rax, (%rbx)
      5c: 48 89 6b 40                  	movq	%rbp, 0x40(%rbx)
      60: 48 89 73 48                  	movq	%rsi, 0x48(%rbx)
      64: c7 43 50 02 00 01 00         	movl	$0x10002, 0x50(%rbx)    # imm = 0x10002
      6b: 33 c0                        	xorl	%eax, %eax
      6d: 66 89 43 11                  	movw	%ax, 0x11(%rbx)
      71: 88 43 13                     	movb	%al, 0x13(%rbx)
      74: 88 43 10                     	movb	%al, 0x10(%rbx)
      77: 48 89 43 14                  	movq	%rax, 0x14(%rbx)
      7b: 89 43 1c                     	movl	%eax, 0x1c(%rbx)
      7e: 48 89 43 20                  	movq	%rax, 0x20(%rbx)
      82: 48 89 43 28                  	movq	%rax, 0x28(%rbx)
      86: 48 89 43 30                  	movq	%rax, 0x30(%rbx)
      8a: 48 8b d3                     	movq	%rbx, %rdx
      8d: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x93 <$$__resumable_init_label$59+0x4c>
		000000000000008f:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@AEAA@U?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
      93: 33 c0                        	xorl	%eax, %eax
      95: 88 43 38                     	movb	%al, 0x38(%rbx)
      98: 48 8b cb                     	movq	%rbx, %rcx
      9b: e8 00 00 00 00               	callq	0xa0 <$$__resumable_init_label$59+0x59>
		000000000000009c:  IMAGE_REL_AMD64_REL32	?longTask$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      a0: 48 8b c7                     	movq	%rdi, %rax
      a3: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
      a8: 48 8b 6c 24 38               	movq	0x38(%rsp), %rbp
      ad: 48 8b 74 24 40               	movq	0x40(%rsp), %rsi
      b2: 48 83 c4 20                  	addq	$0x20, %rsp
      b6: 5f                           	popq	%rdi
      b7: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::next$_DestroyCoro$2(class lux::simulation::script::ScriptCoroutineContext &)>:
       0: 48 83 49 50 01               	orq	$0x1, 0x50(%rcx)
       5: e9 00 00 00 00               	jmp	0xa <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::next$_DestroyCoro$2(class lux::simulation::script::ScriptCoroutineContext &)+0xa>
		0000000000000006:  IMAGE_REL_AMD64_REL32	?next$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z

Disassembly of section .text$mn:

0000000000000000 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::next$_ResumeCoro$1(class lux::simulation::script::ScriptCoroutineContext &)>:
       0: 48 89 5c 24 10               	movq	%rbx, 0x10(%rsp)
       5: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
       a: 48 89 4c 24 08               	movq	%rcx, 0x8(%rsp)
       f: 57                           	pushq	%rdi
      10: 48 81 ec 80 00 00 00         	subq	$0x80, %rsp

0000000000000017 <$__resumable_prolog_label>:
      17: 48 8b bc 24 90 00 00 00      	movq	0x90(%rsp), %rdi
      1f: 0f b7 47 50                  	movzwl	0x50(%rdi), %eax
      23: 66 89 44 24 30               	movw	%ax, 0x30(%rsp)
      28: 66 ff c0                     	incw	%ax
      2b: 66 83 f8 0a                  	cmpw	$0xa, %ax
      2f: 0f 87 22 02 00 00            	ja	0x257 <$__resumable_state_0>
      35: 48 0f bf c0                  	movswq	%ax, %rax
      39: 48 8d 15 00 00 00 00         	leaq	(%rip), %rdx            # 0x40 <$__resumable_prolog_label+0x29>
		000000000000003c:  IMAGE_REL_AMD64_REL32	__ImageBase
      40: 8b 8c 82 00 00 00 00         	movl	(%rdx,%rax,4), %ecx
		0000000000000043:  IMAGE_REL_AMD64_ADDR32NB	$LN133
      47: 48 03 ca                     	addq	%rdx, %rcx
      4a: ff e1                        	jmpq	*%rcx

000000000000004c <$__resumable_state_3>:
      4c: e9 f4 01 00 00               	jmp	0x245 <$__resumable_state_1>

0000000000000051 <$__resumable_state_2>:
      51: 33 db                        	xorl	%ebx, %ebx
      53: 48 89 5c 24 28               	movq	%rbx, 0x28(%rsp)
      58: 48 89 5c 24 20               	movq	%rbx, 0x20(%rsp)
      5d: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0x64 <$__resumable_state_2+0x13>
		0000000000000060:  IMAGE_REL_AMD64_REL32	?Shape@?$ScriptSyncStepCall@$$A6AXXZ@detail@script@simulation@lux@@2UScriptSyncStepShape@345@B
      64: 41 b8 01 00 00 00            	movl	$0x1, %r8d
      6a: 48 8d 57 58                  	leaq	0x58(%rdi), %rdx
      6e: 48 8b 4f 48                  	movq	0x48(%rdi), %rcx
      72: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x78 <$__resumable_state_2+0x27>
		0000000000000074:  IMAGE_REL_AMD64_REL32	__imp_?invokeSyncStep@ScriptCoroutineContext@script@simulation@lux@@AEAA?AV?$expected@XUScriptSyncStepError@script@simulation@lux@@@tl@@IAEBUScriptSyncStepShape@234@PEBQEBXPEAX@Z
      78: 48 8b 4f 48                  	movq	0x48(%rdi), %rcx
      7c: 0f b6 47 64                  	movzbl	0x64(%rdi), %eax
      80: 88 44 24 6c                  	movb	%al, 0x6c(%rsp)
      84: 84 c0                        	testb	%al, %al
      86: 75 49                        	jne	0xd1 <$__resumable_state_2+0x80>
      88: 4c 8d 87 e0 00 00 00         	leaq	0xe0(%rdi), %r8
      8f: f2 0f 10 47 58               	movsd	0x58(%rdi), %xmm0
      94: f2 0f 11 44 24 60            	movsd	%xmm0, 0x60(%rsp)
      9a: 8b 47 60                     	movl	0x60(%rdi), %eax
      9d: 89 44 24 68                  	movl	%eax, 0x68(%rsp)
      a1: f2 41 0f 11 00               	movsd	%xmm0, (%r8)
      a6: 41 89 40 08                  	movl	%eax, 0x8(%r8)
      aa: 48 8d 57 78                  	leaq	0x78(%rdi), %rdx
      ae: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xb4 <$__resumable_state_2+0x63>
		00000000000000b0:  IMAGE_REL_AMD64_REL32	__imp_?fail@ScriptCoroutineContext@script@simulation@lux@@QEAA?AVScriptCoroutineFailure@234@UScriptSyncStepError@234@@Z
      b4: 48 89 47 70                  	movq	%rax, 0x70(%rdi)
      b8: b9 04 00 00 00               	movl	$0x4, %ecx
      bd: 66 89 4f 50                  	movw	%cx, 0x50(%rdi)
      c1: 48 8b d7                     	movq	%rdi, %rdx
      c4: 48 8b c8                     	movq	%rax, %rcx
      c7: e8 00 00 00 00               	callq	0xcc <$__resumable_state_2+0x7b>
		00000000000000c8:  IMAGE_REL_AMD64_REL32	?await_suspend@ScriptCoroutineFailure@script@simulation@lux@@QEBAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
      cc: e9 87 01 00 00               	jmp	0x258 <$__resumable_epilog_label>
      d1: 48 8d 97 80 00 00 00         	leaq	0x80(%rdi), %rdx
      d8: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xde <$__resumable_state_2+0x8d>
		00000000000000da:  IMAGE_REL_AMD64_REL32	__imp_?delay@ScriptCoroutineContext@script@simulation@lux@@QEAA?AV?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@XZ
      de: 0f b6 97 01 01 00 00         	movzbl	0x101(%rdi), %edx
      e5: 4c 8d 87 00 01 00 00         	leaq	0x100(%rdi), %r8
      ec: 88 54 24 28                  	movb	%dl, 0x28(%rsp)
      f0: 4c 89 44 24 20               	movq	%r8, 0x20(%rsp)
      f5: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0xfc <$__resumable_state_2+0xab>
		00000000000000f8:  IMAGE_REL_AMD64_REL32	?method_id@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@4V?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@B
      fc: 44 8b 40 08                  	movl	0x8(%rax), %r8d
     100: 48 8d 97 90 00 00 00         	leaq	0x90(%rdi), %rdx
     107: 48 8b 08                     	movq	(%rax), %rcx
     10a: e8 00 00 00 00               	callq	0x10f <$__resumable_state_2+0xbe>
		000000000000010b:  IMAGE_REL_AMD64_REL32	??$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@3@V?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@13@QEBA@XZ@@Z
     10f: b8 06 00 00 00               	movl	$0x6, %eax
     114: 66 89 47 50                  	movw	%ax, 0x50(%rdi)
     118: 48 8b d7                     	movq	%rdi, %rdx
     11b: 48 8d 8f 90 00 00 00         	leaq	0x90(%rdi), %rcx
     122: e8 00 00 00 00               	callq	0x127 <$__resumable_state_2+0xd6>
		0000000000000123:  IMAGE_REL_AMD64_REL32	?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
     127: e9 2c 01 00 00               	jmp	0x258 <$__resumable_epilog_label>

000000000000012c <$__resumable_state_5>:
     12c: e9 14 01 00 00               	jmp	0x245 <$__resumable_state_1>

0000000000000131 <$__resumable_state_4>:
     131: 48 8b 4f 70                  	movq	0x70(%rdi), %rcx
     135: e8 00 00 00 00               	callq	0x13a <$__resumable_state_4+0x9>
		0000000000000136:  IMAGE_REL_AMD64_REL32	?await_resume@ScriptCoroutineFailure@script@simulation@lux@@QEBAXXZ
     13a: 90                           	nop

000000000000013b <$__resumable_state_7>:
     13b: e9 05 01 00 00               	jmp	0x245 <$__resumable_state_1>

0000000000000140 <$__resumable_state_6>:
     140: 33 db                        	xorl	%ebx, %ebx
     142: 48 89 5c 24 28               	movq	%rbx, 0x28(%rsp)
     147: 48 89 5c 24 20               	movq	%rbx, 0x20(%rsp)
     14c: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0x153 <$__resumable_state_6+0x13>
		000000000000014f:  IMAGE_REL_AMD64_REL32	?Shape@?$ScriptSyncStepCall@$$A6AXXZ@detail@script@simulation@lux@@2UScriptSyncStepShape@345@B
     153: 41 b8 02 00 00 00            	movl	$0x2, %r8d
     159: 48 8d 97 b8 00 00 00         	leaq	0xb8(%rdi), %rdx
     160: 48 8b 4f 48                  	movq	0x48(%rdi), %rcx
     164: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x16a <$__resumable_state_6+0x2a>
		0000000000000166:  IMAGE_REL_AMD64_REL32	__imp_?invokeSyncStep@ScriptCoroutineContext@script@simulation@lux@@AEAA?AV?$expected@XUScriptSyncStepError@script@simulation@lux@@@tl@@IAEBUScriptSyncStepShape@234@PEBQEBXPEAX@Z
     16a: 0f 10 87 b8 00 00 00         	movups	0xb8(%rdi), %xmm0
     171: 0f 11 44 24 48               	movups	%xmm0, 0x48(%rsp)
     176: 8b 87 c8 00 00 00            	movl	0xc8(%rdi), %eax
     17c: 89 44 24 58                  	movl	%eax, 0x58(%rsp)
     180: 0f 11 47 58                  	movups	%xmm0, 0x58(%rdi)
     184: 89 47 68                     	movl	%eax, 0x68(%rdi)
     187: 48 8b 87 c0 00 00 00         	movq	0xc0(%rdi), %rax
     18e: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
     193: 48 c1 e8 20                  	shrq	$0x20, %rax
     197: 84 c0                        	testb	%al, %al
     199: 75 56                        	jne	0x1f1 <$__resumable_state_6+0xb1>
     19b: 4c 8d 87 f0 00 00 00         	leaq	0xf0(%rdi), %r8
     1a2: f2 0f 10 87 b8 00 00 00      	movsd	0xb8(%rdi), %xmm0
     1aa: f2 0f 11 44 24 48            	movsd	%xmm0, 0x48(%rsp)
     1b0: 8b 87 c0 00 00 00            	movl	0xc0(%rdi), %eax
     1b6: 89 44 24 50                  	movl	%eax, 0x50(%rsp)
     1ba: f2 41 0f 11 00               	movsd	%xmm0, (%r8)
     1bf: 41 89 40 08                  	movl	%eax, 0x8(%r8)
     1c3: 48 8d 97 d8 00 00 00         	leaq	0xd8(%rdi), %rdx
     1ca: 48 8b 4f 48                  	movq	0x48(%rdi), %rcx
     1ce: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x1d4 <$__resumable_state_6+0x94>
		00000000000001d0:  IMAGE_REL_AMD64_REL32	__imp_?fail@ScriptCoroutineContext@script@simulation@lux@@QEAA?AVScriptCoroutineFailure@234@UScriptSyncStepError@234@@Z
     1d4: 48 89 87 d0 00 00 00         	movq	%rax, 0xd0(%rdi)
     1db: b9 08 00 00 00               	movl	$0x8, %ecx
     1e0: 66 89 4f 50                  	movw	%cx, 0x50(%rdi)
     1e4: 48 8b d7                     	movq	%rdi, %rdx
     1e7: 48 8b c8                     	movq	%rax, %rcx
     1ea: e8 00 00 00 00               	callq	0x1ef <$__resumable_state_6+0xaf>
		00000000000001eb:  IMAGE_REL_AMD64_REL32	?await_suspend@ScriptCoroutineFailure@script@simulation@lux@@QEBAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
     1ef: eb 67                        	jmp	0x258 <$__resumable_epilog_label>
     1f1: 80 7f 10 02                  	cmpb	$0x2, 0x10(%rdi)
     1f5: 74 23                        	je	0x21a <$$__resumable_return_label$135>
     1f7: 88 9f 08 01 00 00            	movb	%bl, 0x108(%rdi)
     1fd: 48 89 9f 0c 01 00 00         	movq	%rbx, 0x10c(%rdi)
     204: 89 9f 14 01 00 00            	movl	%ebx, 0x114(%rdi)
     20a: 0f 10 87 08 01 00 00         	movups	0x108(%rdi), %xmm0
     211: 0f 11 44 24 38               	movups	%xmm0, 0x38(%rsp)
     216: 0f 11 47 10                  	movups	%xmm0, 0x10(%rdi)

000000000000021a <$$__resumable_return_label$135>:
     21a: 48 8d 8f dc 00 00 00         	leaq	0xdc(%rdi), %rcx
     221: 33 c0                        	xorl	%eax, %eax
     223: 88 01                        	movb	%al, (%rcx)
     225: 66 89 47 50                  	movw	%ax, 0x50(%rdi)
     229: 48 89 1f                     	movq	%rbx, (%rdi)
     22c: 48 8b d7                     	movq	%rdi, %rdx
     22f: e8 00 00 00 00               	callq	0x234 <$$__resumable_return_label$135+0x1a>
		0000000000000230:  IMAGE_REL_AMD64_REL32	?await_suspend@suspend_always@std@@QEBAXU?$coroutine_handle@X@2@@Z
     234: eb 22                        	jmp	0x258 <$__resumable_epilog_label>

0000000000000236 <$__resumable_state_9>:
     236: eb 0d                        	jmp	0x245 <$__resumable_state_1>

0000000000000238 <$__resumable_state_8>:
     238: 48 8b 8f d0 00 00 00         	movq	0xd0(%rdi), %rcx
     23f: e8 00 00 00 00               	callq	0x244 <$__resumable_state_8+0xc>
		0000000000000240:  IMAGE_REL_AMD64_REL32	?await_resume@ScriptCoroutineFailure@script@simulation@lux@@QEBAXXZ
     244: cc                           	int3

0000000000000245 <$__resumable_state_1>:
     245: 66 83 7f 52 00               	cmpw	$0x0, 0x52(%rdi)
     24a: 74 0c                        	je	0x258 <$__resumable_epilog_label>
     24c: 48 8b cf                     	movq	%rdi, %rcx
     24f: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x255 <$__resumable_state_1+0x10>
		0000000000000251:  IMAGE_REL_AMD64_REL32	__imp_?releaseFrame@ScriptCoroutineContext@script@simulation@lux@@CAXPEAX@Z
     255: eb 01                        	jmp	0x258 <$__resumable_epilog_label>

0000000000000257 <$__resumable_state_0>:
     257: cc                           	int3

0000000000000258 <$__resumable_epilog_label>:
     258: 4c 8d 9c 24 80 00 00 00      	leaq	0x80(%rsp), %r11
     260: 49 8b 5b 18                  	movq	0x18(%r11), %rbx
     264: 49 8b 73 20                  	movq	0x20(%r11), %rsi
     268: 49 8b e3                     	movq	%r11, %rsp
     26b: 5f                           	popq	%rdi
     26c: c3                           	retq
     26d: cc                           	int3

000000000000026e <$LN134>:
     26e: 66 90                        	nop

0000000000000270 <$LN133>:
     270: 00 00                        	addb	%al, (%rax)
		0000000000000270:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_1
     272: 00 00                        	addb	%al, (%rax)
     274: 00 00                        	addb	%al, (%rax)
		0000000000000274:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_0
     276: 00 00                        	addb	%al, (%rax)
     278: 00 00                        	addb	%al, (%rax)
		0000000000000278:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_1
     27a: 00 00                        	addb	%al, (%rax)
     27c: 00 00                        	addb	%al, (%rax)
		000000000000027c:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_2
     27e: 00 00                        	addb	%al, (%rax)
     280: 00 00                        	addb	%al, (%rax)
		0000000000000280:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_3
     282: 00 00                        	addb	%al, (%rax)
     284: 00 00                        	addb	%al, (%rax)
		0000000000000284:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_4
     286: 00 00                        	addb	%al, (%rax)
     288: 00 00                        	addb	%al, (%rax)
		0000000000000288:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_5
     28a: 00 00                        	addb	%al, (%rax)
     28c: 00 00                        	addb	%al, (%rax)
		000000000000028c:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_6
     28e: 00 00                        	addb	%al, (%rax)
     290: 00 00                        	addb	%al, (%rax)
		0000000000000290:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_7
     292: 00 00                        	addb	%al, (%rax)
     294: 00 00                        	addb	%al, (%rax)
		0000000000000294:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_8
     296: 00 00                        	addb	%al, (%rax)
     298: 00 00                        	addb	%al, (%rax)
		0000000000000298:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_9
     29a: 00 00                        	addb	%al, (%rax)

Disassembly of section .text$x:

0000000000000000 <int `public: class simulation::na1::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::next$_ResumeCoro$1(class simulation::na1::ScriptCoroutine::ScriptCoroutineContext &)'::`1'::catch$0>:
       0: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
       5: 55                           	pushq	%rbp
       6: 48 83 ec 30                  	subq	$0x30, %rsp
       a: 48 8b ea                     	movq	%rdx, %rbp

000000000000000d <__catch$?next$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z$0>:
       d: 48 8b 8d 90 00 00 00         	movq	0x90(%rbp), %rcx
      14: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
      1b: b8 ff ff ff ff               	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
      20: 66 89 41 50                  	movw	%ax, 0x50(%rcx)
      24: 48 83 c1 10                  	addq	$0x10, %rcx
      28: e8 00 00 00 00               	callq	0x2d <__catch$?next$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z$0+0x20>
		0000000000000029:  IMAGE_REL_AMD64_REL32	?unhandled_exception@promise_type@ScriptCoroutine@script@simulation@lux@@QEAAXXZ
      2d: 90                           	nop

Disassembly of section .text$mn:

0000000000000000 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::next(class lux::simulation::script::ScriptCoroutineContext &)>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 6c 24 10               	movq	%rbp, 0x10(%rsp)
       a: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
       f: 57                           	pushq	%rdi
      10: 48 83 ec 20                  	subq	$0x20, %rsp
      14: 49 8b f0                     	movq	%r8, %rsi
      17: 48 8b fa                     	movq	%rdx, %rdi
      1a: 48 8b e9                     	movq	%rcx, %rbp
      1d: ba 20 01 00 00               	movl	$0x120, %edx            # imm = 0x120
      22: 41 b8 08 00 00 00            	movl	$0x8, %r8d
      28: 48 8b ce                     	movq	%rsi, %rcx
      2b: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x31 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::next(class lux::simulation::script::ScriptCoroutineContext &)+0x31>
		000000000000002d:  IMAGE_REL_AMD64_REL32	__imp_?allocateFrame@ScriptCoroutineContext@script@simulation@lux@@AEAAPEAX_K0@Z
      31: 48 8b d8                     	movq	%rax, %rbx
      34: 48 8b cf                     	movq	%rdi, %rcx
      37: 48 85 c0                     	testq	%rax, %rax
      3a: 75 0b                        	jne	0x47 <$$__resumable_init_label$59>
      3c: 48 89 07                     	movq	%rax, (%rdi)
      3f: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x45 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::next(class lux::simulation::script::ScriptCoroutineContext &)+0x45>
		0000000000000041:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
      45: eb 59                        	jmp	0xa0 <$$__resumable_init_label$59+0x59>

0000000000000047 <$$__resumable_init_label$59>:
      47: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x4e <$$__resumable_init_label$59+0x7>
		000000000000004a:  IMAGE_REL_AMD64_REL32	?next$_DestroyCoro$2@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      4e: 48 89 43 08                  	movq	%rax, 0x8(%rbx)
      52: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x59 <$$__resumable_init_label$59+0x12>
		0000000000000055:  IMAGE_REL_AMD64_REL32	?next$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      59: 48 89 03                     	movq	%rax, (%rbx)
      5c: 48 89 6b 40                  	movq	%rbp, 0x40(%rbx)
      60: 48 89 73 48                  	movq	%rsi, 0x48(%rbx)
      64: c7 43 50 02 00 01 00         	movl	$0x10002, 0x50(%rbx)    # imm = 0x10002
      6b: 33 c0                        	xorl	%eax, %eax
      6d: 66 89 43 11                  	movw	%ax, 0x11(%rbx)
      71: 88 43 13                     	movb	%al, 0x13(%rbx)
      74: 88 43 10                     	movb	%al, 0x10(%rbx)
      77: 48 89 43 14                  	movq	%rax, 0x14(%rbx)
      7b: 89 43 1c                     	movl	%eax, 0x1c(%rbx)
      7e: 48 89 43 20                  	movq	%rax, 0x20(%rbx)
      82: 48 89 43 28                  	movq	%rax, 0x28(%rbx)
      86: 48 89 43 30                  	movq	%rax, 0x30(%rbx)
      8a: 48 8b d3                     	movq	%rbx, %rdx
      8d: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x93 <$$__resumable_init_label$59+0x4c>
		000000000000008f:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@AEAA@U?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
      93: 33 c0                        	xorl	%eax, %eax
      95: 88 43 38                     	movb	%al, 0x38(%rbx)
      98: 48 8b cb                     	movq	%rbx, %rcx
      9b: e8 00 00 00 00               	callq	0xa0 <$$__resumable_init_label$59+0x59>
		000000000000009c:  IMAGE_REL_AMD64_REL32	?next$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      a0: 48 8b c7                     	movq	%rdi, %rax
      a3: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
      a8: 48 8b 6c 24 38               	movq	0x38(%rsp), %rbp
      ad: 48 8b 74 24 40               	movq	0x40(%rsp), %rsi
      b2: 48 83 c4 20                  	addq	$0x20, %rsp
      b6: 5f                           	popq	%rdi
      b7: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::nextStep(void) const>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 30                  	subq	$0x30, %rsp
       6: 0f b6 44 24 40               	movzbl	0x40(%rsp), %eax
       b: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0x12 <public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::nextStep(void) const+0x12>
		000000000000000e:  IMAGE_REL_AMD64_REL32	?method_id@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@4V?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@B
      12: 44 8b 41 08                  	movl	0x8(%rcx), %r8d
      16: 48 8b da                     	movq	%rdx, %rbx
      19: 48 8b 09                     	movq	(%rcx), %rcx
      1c: 88 44 24 28                  	movb	%al, 0x28(%rsp)
      20: 48 8d 44 24 40               	leaq	0x40(%rsp), %rax
      25: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
      2a: e8 00 00 00 00               	callq	0x2f <public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::nextStep(void) const+0x2f>
		000000000000002b:  IMAGE_REL_AMD64_REL32	??$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@3@V?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@13@QEBA@XZ@@Z
      2f: 48 8b c3                     	movq	%rbx, %rax
      32: 48 83 c4 30                  	addq	$0x30, %rsp
      36: 5b                           	popq	%rbx
      37: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <private: static unsigned __int64 __cdecl lux::simulation::script::ScriptAwaitableCompletion::pack(unsigned int, unsigned int)>:
       0: 8b c1                        	movl	%ecx, %eax
       2: 48 c1 e0 20                  	shlq	$0x20, %rax
       6: 8b ca                        	movl	%edx, %ecx
       8: 48 0b c1                     	orq	%rcx, %rax
       b: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::pose$_DestroyCoro$2(class lux::simulation::script::ScriptCoroutineContext &, struct lux::simulation::script::test::ValuePose const &)>:
       0: 48 83 49 58 01               	orq	$0x1, 0x58(%rcx)
       5: e9 00 00 00 00               	jmp	0xa <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::pose$_DestroyCoro$2(class lux::simulation::script::ScriptCoroutineContext &, struct lux::simulation::script::test::ValuePose const &)+0xa>
		0000000000000006:  IMAGE_REL_AMD64_REL32	?pose$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@AEBUValuePose@test@745@@Z

Disassembly of section .text$mn:

0000000000000000 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::pose$_ResumeCoro$1(class lux::simulation::script::ScriptCoroutineContext &, struct lux::simulation::script::test::ValuePose const &)>:
       0: 48 89 5c 24 10               	movq	%rbx, 0x10(%rsp)
       5: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
       a: 48 89 4c 24 08               	movq	%rcx, 0x8(%rsp)
       f: 57                           	pushq	%rdi
      10: 48 81 ec 80 00 00 00         	subq	$0x80, %rsp

0000000000000017 <$__resumable_prolog_label>:
      17: 48 8b 9c 24 90 00 00 00      	movq	0x90(%rsp), %rbx
      1f: 0f b7 43 58                  	movzwl	0x58(%rbx), %eax
      23: 66 89 44 24 30               	movw	%ax, 0x30(%rsp)
      28: 66 ff c0                     	incw	%ax
      2b: 66 83 f8 0a                  	cmpw	$0xa, %ax
      2f: 0f 87 3d 02 00 00            	ja	0x272 <$__resumable_state_0>
      35: 48 0f bf c0                  	movswq	%ax, %rax
      39: 48 8d 15 00 00 00 00         	leaq	(%rip), %rdx            # 0x40 <$__resumable_prolog_label+0x29>
		000000000000003c:  IMAGE_REL_AMD64_REL32	__ImageBase
      40: 8b 8c 82 00 00 00 00         	movl	(%rdx,%rax,4), %ecx
		0000000000000043:  IMAGE_REL_AMD64_ADDR32NB	$LN136
      47: 48 03 ca                     	addq	%rdx, %rcx
      4a: ff e1                        	jmpq	*%rcx

000000000000004c <$__resumable_state_3>:
      4c: e9 0f 02 00 00               	jmp	0x260 <$__resumable_state_1>

0000000000000051 <$__resumable_state_2>:
      51: 48 8d 8b 00 01 00 00         	leaq	0x100(%rbx), %rcx
      58: 48 8b 43 50                  	movq	0x50(%rbx), %rax
      5c: 48 89 01                     	movq	%rax, (%rcx)
      5f: 33 ff                        	xorl	%edi, %edi
      61: 48 89 7c 24 28               	movq	%rdi, 0x28(%rsp)
      66: 48 89 4c 24 20               	movq	%rcx, 0x20(%rsp)
      6b: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0x72 <$__resumable_state_2+0x21>
		000000000000006e:  IMAGE_REL_AMD64_REL32	?Shape@?$ScriptSyncStepCall@$$A6AXAEBUValuePose@test@script@simulation@lux@@@Z@detail@script@simulation@lux@@2UScriptSyncStepShape@345@B
      72: bf 04 00 00 00               	movl	$0x4, %edi
      77: 44 8b c7                     	movl	%edi, %r8d
      7a: 48 8d 53 60                  	leaq	0x60(%rbx), %rdx
      7e: 48 8b 4b 48                  	movq	0x48(%rbx), %rcx
      82: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x88 <$__resumable_state_2+0x37>
		0000000000000084:  IMAGE_REL_AMD64_REL32	__imp_?invokeSyncStep@ScriptCoroutineContext@script@simulation@lux@@AEAA?AV?$expected@XUScriptSyncStepError@script@simulation@lux@@@tl@@IAEBUScriptSyncStepShape@234@PEBQEBXPEAX@Z
      88: 48 8b 4b 48                  	movq	0x48(%rbx), %rcx
      8c: 0f b6 43 6c                  	movzbl	0x6c(%rbx), %eax
      90: 88 44 24 6c                  	movb	%al, 0x6c(%rsp)
      94: 84 c0                        	testb	%al, %al
      96: 75 47                        	jne	0xdf <$__resumable_state_2+0x8e>
      98: 4c 8d 83 e0 00 00 00         	leaq	0xe0(%rbx), %r8
      9f: f2 0f 10 43 60               	movsd	0x60(%rbx), %xmm0
      a4: f2 0f 11 44 24 60            	movsd	%xmm0, 0x60(%rsp)
      aa: 8b 43 68                     	movl	0x68(%rbx), %eax
      ad: 89 44 24 68                  	movl	%eax, 0x68(%rsp)
      b1: f2 41 0f 11 00               	movsd	%xmm0, (%r8)
      b6: 41 89 40 08                  	movl	%eax, 0x8(%r8)
      ba: 48 8d 93 80 00 00 00         	leaq	0x80(%rbx), %rdx
      c1: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xc7 <$__resumable_state_2+0x76>
		00000000000000c3:  IMAGE_REL_AMD64_REL32	__imp_?fail@ScriptCoroutineContext@script@simulation@lux@@QEAA?AVScriptCoroutineFailure@234@UScriptSyncStepError@234@@Z
      c7: 48 89 43 78                  	movq	%rax, 0x78(%rbx)
      cb: 66 89 7b 58                  	movw	%di, 0x58(%rbx)
      cf: 48 8b d3                     	movq	%rbx, %rdx
      d2: 48 8b c8                     	movq	%rax, %rcx
      d5: e8 00 00 00 00               	callq	0xda <$__resumable_state_2+0x89>
		00000000000000d6:  IMAGE_REL_AMD64_REL32	?await_suspend@ScriptCoroutineFailure@script@simulation@lux@@QEBAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
      da: e9 94 01 00 00               	jmp	0x273 <$__resumable_epilog_label>
      df: 48 8d 93 90 00 00 00         	leaq	0x90(%rbx), %rdx
      e6: 4c 8d 05 00 00 00 00         	leaq	(%rip), %r8             # 0xed <$__resumable_state_2+0x9c>
		00000000000000e9:  IMAGE_REL_AMD64_REL32	?source@cost@na1@simulation@lux@@3V?$optional@V?$CppScriptEventSource@H@script@simulation@lux@@@std@@A
      ed: e8 00 00 00 00               	callq	0xf2 <$__resumable_state_2+0xa1>
		00000000000000ee:  IMAGE_REL_AMD64_REL32	??$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@123@@Z
      f2: 48 89 83 88 00 00 00         	movq	%rax, 0x88(%rbx)
      f9: b9 06 00 00 00               	movl	$0x6, %ecx
      fe: 66 89 4b 58                  	movw	%cx, 0x58(%rbx)
     102: 48 8b d3                     	movq	%rbx, %rdx
     105: 48 8b c8                     	movq	%rax, %rcx
     108: e8 00 00 00 00               	callq	0x10d <$__resumable_state_2+0xbc>
		0000000000000109:  IMAGE_REL_AMD64_REL32	?await_suspend@?$ScriptCoroutineAwaiter@HV<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@345@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
     10d: e9 61 01 00 00               	jmp	0x273 <$__resumable_epilog_label>

0000000000000112 <$__resumable_state_5>:
     112: e9 49 01 00 00               	jmp	0x260 <$__resumable_state_1>

0000000000000117 <$__resumable_state_4>:
     117: 48 8b 4b 78                  	movq	0x78(%rbx), %rcx
     11b: e8 00 00 00 00               	callq	0x120 <$__resumable_state_4+0x9>
		000000000000011c:  IMAGE_REL_AMD64_REL32	?await_resume@ScriptCoroutineFailure@script@simulation@lux@@QEBAXXZ
     120: 90                           	nop

0000000000000121 <$__resumable_state_7>:
     121: e9 3a 01 00 00               	jmp	0x260 <$__resumable_state_1>

0000000000000126 <$__resumable_state_6>:
     126: 48 8b 83 88 00 00 00         	movq	0x88(%rbx), %rax
     12d: 48 8d 93 84 00 00 00         	leaq	0x84(%rbx), %rdx
     134: 48 8b 40 18                  	movq	0x18(%rax), %rax
     138: 48 8b 48 20                  	movq	0x20(%rax), %rcx
     13c: 8b 01                        	movl	(%rcx), %eax
     13e: 89 02                        	movl	%eax, (%rdx)
     140: 48 8d 8b 18 01 00 00         	leaq	0x118(%rbx), %rcx
     147: 48 8b 43 50                  	movq	0x50(%rbx), %rax
     14b: 48 89 01                     	movq	%rax, (%rcx)
     14e: 48 89 93 20 01 00 00         	movq	%rdx, 0x120(%rbx)
     155: 33 ff                        	xorl	%edi, %edi
     157: 48 89 7c 24 28               	movq	%rdi, 0x28(%rsp)
     15c: 48 89 4c 24 20               	movq	%rcx, 0x20(%rsp)
     161: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0x168 <$__resumable_state_6+0x42>
		0000000000000164:  IMAGE_REL_AMD64_REL32	?Shape@?$ScriptSyncStepCall@$$A6AXAEBUValuePose@test@script@simulation@lux@@H@Z@detail@script@simulation@lux@@2UScriptSyncStepShape@345@B
     168: 41 b8 05 00 00 00            	movl	$0x5, %r8d
     16e: 48 8d 93 b0 00 00 00         	leaq	0xb0(%rbx), %rdx
     175: 48 8b 4b 48                  	movq	0x48(%rbx), %rcx
     179: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x17f <$__resumable_state_6+0x59>
		000000000000017b:  IMAGE_REL_AMD64_REL32	__imp_?invokeSyncStep@ScriptCoroutineContext@script@simulation@lux@@AEAA?AV?$expected@XUScriptSyncStepError@script@simulation@lux@@@tl@@IAEBUScriptSyncStepShape@234@PEBQEBXPEAX@Z
     17f: 0f 10 83 b0 00 00 00         	movups	0xb0(%rbx), %xmm0
     186: 0f 11 44 24 48               	movups	%xmm0, 0x48(%rsp)
     18b: 8b 83 c0 00 00 00            	movl	0xc0(%rbx), %eax
     191: 89 44 24 58                  	movl	%eax, 0x58(%rsp)
     195: 0f 11 43 60                  	movups	%xmm0, 0x60(%rbx)
     199: 89 43 70                     	movl	%eax, 0x70(%rbx)
     19c: 48 8b 83 b8 00 00 00         	movq	0xb8(%rbx), %rax
     1a3: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
     1a8: 48 c1 e8 20                  	shrq	$0x20, %rax
     1ac: 84 c0                        	testb	%al, %al
     1ae: 75 56                        	jne	0x206 <$__resumable_state_6+0xe0>
     1b0: 4c 8d 83 f0 00 00 00         	leaq	0xf0(%rbx), %r8
     1b7: f2 0f 10 83 b0 00 00 00      	movsd	0xb0(%rbx), %xmm0
     1bf: f2 0f 11 44 24 48            	movsd	%xmm0, 0x48(%rsp)
     1c5: 8b 83 b8 00 00 00            	movl	0xb8(%rbx), %eax
     1cb: 89 44 24 50                  	movl	%eax, 0x50(%rsp)
     1cf: f2 41 0f 11 00               	movsd	%xmm0, (%r8)
     1d4: 41 89 40 08                  	movl	%eax, 0x8(%r8)
     1d8: 48 8d 93 d0 00 00 00         	leaq	0xd0(%rbx), %rdx
     1df: 48 8b 4b 48                  	movq	0x48(%rbx), %rcx
     1e3: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x1e9 <$__resumable_state_6+0xc3>
		00000000000001e5:  IMAGE_REL_AMD64_REL32	__imp_?fail@ScriptCoroutineContext@script@simulation@lux@@QEAA?AVScriptCoroutineFailure@234@UScriptSyncStepError@234@@Z
     1e9: 48 89 83 c8 00 00 00         	movq	%rax, 0xc8(%rbx)
     1f0: b9 08 00 00 00               	movl	$0x8, %ecx
     1f5: 66 89 4b 58                  	movw	%cx, 0x58(%rbx)
     1f9: 48 8b d3                     	movq	%rbx, %rdx
     1fc: 48 8b c8                     	movq	%rax, %rcx
     1ff: e8 00 00 00 00               	callq	0x204 <$__resumable_state_6+0xde>
		0000000000000200:  IMAGE_REL_AMD64_REL32	?await_suspend@ScriptCoroutineFailure@script@simulation@lux@@QEBAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
     204: eb 6d                        	jmp	0x273 <$__resumable_epilog_label>
     206: 80 7b 10 02                  	cmpb	$0x2, 0x10(%rbx)
     20a: 74 24                        	je	0x230 <$$__resumable_return_label$138>
     20c: 40 88 bb 08 01 00 00         	movb	%dil, 0x108(%rbx)
     213: 48 89 bb 0c 01 00 00         	movq	%rdi, 0x10c(%rbx)
     21a: 89 bb 14 01 00 00            	movl	%edi, 0x114(%rbx)
     220: 0f 10 83 08 01 00 00         	movups	0x108(%rbx), %xmm0
     227: 0f 11 44 24 38               	movups	%xmm0, 0x38(%rsp)
     22c: 0f 11 43 10                  	movups	%xmm0, 0x10(%rbx)

0000000000000230 <$$__resumable_return_label$138>:
     230: 48 8d 8b d4 00 00 00         	leaq	0xd4(%rbx), %rcx
     237: 33 c0                        	xorl	%eax, %eax
     239: 88 01                        	movb	%al, (%rcx)
     23b: 66 89 43 58                  	movw	%ax, 0x58(%rbx)
     23f: 48 89 3b                     	movq	%rdi, (%rbx)
     242: 48 8b d3                     	movq	%rbx, %rdx
     245: e8 00 00 00 00               	callq	0x24a <$$__resumable_return_label$138+0x1a>
		0000000000000246:  IMAGE_REL_AMD64_REL32	?await_suspend@suspend_always@std@@QEBAXU?$coroutine_handle@X@2@@Z
     24a: eb 27                        	jmp	0x273 <$__resumable_epilog_label>

000000000000024c <$__resumable_state_9>:
     24c: eb 12                        	jmp	0x260 <$__resumable_state_1>

000000000000024e <$__resumable_state_8>:
     24e: 48 8b 8b c8 00 00 00         	movq	0xc8(%rbx), %rcx
     255: e8 00 00 00 00               	callq	0x25a <$__resumable_state_8+0xc>
		0000000000000256:  IMAGE_REL_AMD64_REL32	?await_resume@ScriptCoroutineFailure@script@simulation@lux@@QEBAXXZ
     25a: cc                           	int3
     25b: 0f 1f 44 00 00               	nopl	(%rax,%rax)

0000000000000260 <$__resumable_state_1>:
     260: 66 83 7b 5a 00               	cmpw	$0x0, 0x5a(%rbx)
     265: 74 0c                        	je	0x273 <$__resumable_epilog_label>
     267: 48 8b cb                     	movq	%rbx, %rcx
     26a: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x270 <$__resumable_state_1+0x10>
		000000000000026c:  IMAGE_REL_AMD64_REL32	__imp_?releaseFrame@ScriptCoroutineContext@script@simulation@lux@@CAXPEAX@Z
     270: eb 01                        	jmp	0x273 <$__resumable_epilog_label>

0000000000000272 <$__resumable_state_0>:
     272: cc                           	int3

0000000000000273 <$__resumable_epilog_label>:
     273: 4c 8d 9c 24 80 00 00 00      	leaq	0x80(%rsp), %r11
     27b: 49 8b 5b 18                  	movq	0x18(%r11), %rbx
     27f: 49 8b 73 20                  	movq	0x20(%r11), %rsi
     283: 49 8b e3                     	movq	%r11, %rsp
     286: 5f                           	popq	%rdi
     287: c3                           	retq
     288: cc                           	int3

0000000000000289 <$LN137>:
     289: 0f 1f 00                     	nopl	(%rax)

000000000000028c <$LN136>:
     28c: 00 00                        	addb	%al, (%rax)
		000000000000028c:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_1
     28e: 00 00                        	addb	%al, (%rax)
     290: 00 00                        	addb	%al, (%rax)
		0000000000000290:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_0
     292: 00 00                        	addb	%al, (%rax)
     294: 00 00                        	addb	%al, (%rax)
		0000000000000294:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_1
     296: 00 00                        	addb	%al, (%rax)
     298: 00 00                        	addb	%al, (%rax)
		0000000000000298:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_2
     29a: 00 00                        	addb	%al, (%rax)
     29c: 00 00                        	addb	%al, (%rax)
		000000000000029c:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_3
     29e: 00 00                        	addb	%al, (%rax)
     2a0: 00 00                        	addb	%al, (%rax)
		00000000000002a0:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_4
     2a2: 00 00                        	addb	%al, (%rax)
     2a4: 00 00                        	addb	%al, (%rax)
		00000000000002a4:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_5
     2a6: 00 00                        	addb	%al, (%rax)
     2a8: 00 00                        	addb	%al, (%rax)
		00000000000002a8:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_6
     2aa: 00 00                        	addb	%al, (%rax)
     2ac: 00 00                        	addb	%al, (%rax)
		00000000000002ac:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_7
     2ae: 00 00                        	addb	%al, (%rax)
     2b0: 00 00                        	addb	%al, (%rax)
		00000000000002b0:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_8
     2b2: 00 00                        	addb	%al, (%rax)
     2b4: 00 00                        	addb	%al, (%rax)
		00000000000002b4:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_9
     2b6: 00 00                        	addb	%al, (%rax)

Disassembly of section .text$x:

0000000000000000 <int `public: class simulation::na1::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::pose$_ResumeCoro$1(class simulation::na1::ScriptCoroutine::ScriptCoroutineContext &, struct simulation::na1::ScriptCoroutine::test::ValuePose const &)'::`1'::catch$0>:
       0: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
       5: 55                           	pushq	%rbp
       6: 48 83 ec 30                  	subq	$0x30, %rsp
       a: 48 8b ea                     	movq	%rdx, %rbp

000000000000000d <__catch$?pose$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@AEBUValuePose@test@745@@Z$0>:
       d: 48 8b 8d 90 00 00 00         	movq	0x90(%rbp), %rcx
      14: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
      1b: b8 ff ff ff ff               	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
      20: 66 89 41 58                  	movw	%ax, 0x58(%rcx)
      24: 48 83 c1 10                  	addq	$0x10, %rcx
      28: e8 00 00 00 00               	callq	0x2d <__catch$?pose$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@AEBUValuePose@test@745@@Z$0+0x20>
		0000000000000029:  IMAGE_REL_AMD64_REL32	?unhandled_exception@promise_type@ScriptCoroutine@script@simulation@lux@@QEAAXXZ
      2d: 90                           	nop

Disassembly of section .text$mn:

0000000000000000 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::pose(class lux::simulation::script::ScriptCoroutineContext &, struct lux::simulation::script::test::ValuePose const &)>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 6c 24 10               	movq	%rbp, 0x10(%rsp)
       a: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
       f: 48 89 7c 24 20               	movq	%rdi, 0x20(%rsp)
      14: 41 56                        	pushq	%r14
      16: 48 83 ec 20                  	subq	$0x20, %rsp
      1a: 49 8b e9                     	movq	%r9, %rbp
      1d: 49 8b f0                     	movq	%r8, %rsi
      20: 48 8b fa                     	movq	%rdx, %rdi
      23: 4c 8b f1                     	movq	%rcx, %r14
      26: ba 30 01 00 00               	movl	$0x130, %edx            # imm = 0x130
      2b: 41 b8 08 00 00 00            	movl	$0x8, %r8d
      31: 48 8b ce                     	movq	%rsi, %rcx
      34: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x3a <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::pose(class lux::simulation::script::ScriptCoroutineContext &, struct lux::simulation::script::test::ValuePose const &)+0x3a>
		0000000000000036:  IMAGE_REL_AMD64_REL32	__imp_?allocateFrame@ScriptCoroutineContext@script@simulation@lux@@AEAAPEAX_K0@Z
      3a: 48 8b d8                     	movq	%rax, %rbx
      3d: 48 8b cf                     	movq	%rdi, %rcx
      40: 48 85 c0                     	testq	%rax, %rax
      43: 75 0b                        	jne	0x50 <$$__resumable_init_label$59>
      45: 48 89 07                     	movq	%rax, (%rdi)
      48: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x4e <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::pose(class lux::simulation::script::ScriptCoroutineContext &, struct lux::simulation::script::test::ValuePose const &)+0x4e>
		000000000000004a:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
      4e: eb 5d                        	jmp	0xad <$$__resumable_init_label$59+0x5d>

0000000000000050 <$$__resumable_init_label$59>:
      50: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x57 <$$__resumable_init_label$59+0x7>
		0000000000000053:  IMAGE_REL_AMD64_REL32	?pose$_DestroyCoro$2@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@AEBUValuePose@test@745@@Z
      57: 48 89 43 08                  	movq	%rax, 0x8(%rbx)
      5b: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x62 <$$__resumable_init_label$59+0x12>
		000000000000005e:  IMAGE_REL_AMD64_REL32	?pose$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@AEBUValuePose@test@745@@Z
      62: 48 89 03                     	movq	%rax, (%rbx)
      65: 4c 89 73 40                  	movq	%r14, 0x40(%rbx)
      69: 48 89 73 48                  	movq	%rsi, 0x48(%rbx)
      6d: 48 89 6b 50                  	movq	%rbp, 0x50(%rbx)
      71: c7 43 58 02 00 01 00         	movl	$0x10002, 0x58(%rbx)    # imm = 0x10002
      78: 33 c0                        	xorl	%eax, %eax
      7a: 66 89 43 11                  	movw	%ax, 0x11(%rbx)
      7e: 88 43 13                     	movb	%al, 0x13(%rbx)
      81: 88 43 10                     	movb	%al, 0x10(%rbx)
      84: 48 89 43 14                  	movq	%rax, 0x14(%rbx)
      88: 89 43 1c                     	movl	%eax, 0x1c(%rbx)
      8b: 48 89 43 20                  	movq	%rax, 0x20(%rbx)
      8f: 48 89 43 28                  	movq	%rax, 0x28(%rbx)
      93: 48 89 43 30                  	movq	%rax, 0x30(%rbx)
      97: 48 8b d3                     	movq	%rbx, %rdx
      9a: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xa0 <$$__resumable_init_label$59+0x50>
		000000000000009c:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@AEAA@U?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
      a0: 33 c0                        	xorl	%eax, %eax
      a2: 88 43 38                     	movb	%al, 0x38(%rbx)
      a5: 48 8b cb                     	movq	%rbx, %rcx
      a8: e8 00 00 00 00               	callq	0xad <$$__resumable_init_label$59+0x5d>
		00000000000000a9:  IMAGE_REL_AMD64_REL32	?pose$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@AEBUValuePose@test@745@@Z
      ad: 48 8b c7                     	movq	%rdi, %rax
      b0: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
      b5: 48 8b 6c 24 38               	movq	0x38(%rsp), %rbp
      ba: 48 8b 74 24 40               	movq	0x40(%rsp), %rsi
      bf: 48 8b 7c 24 48               	movq	0x48(%rsp), %rdi
      c4: 48 83 c4 20                  	addq	$0x20, %rsp
      c8: 41 5e                        	popq	%r14
      ca: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: struct lux::simulation::script::ScriptCoroutine::promise_type & __cdecl std::coroutine_handle<struct lux::simulation::script::ScriptCoroutine::promise_type>::promise(void) const>:
       0: 48 8b 01                     	movq	(%rcx), %rax
       3: 48 83 c0 10                  	addq	$0x10, %rax
       7: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static void __cdecl lux::simulation::script::ScriptCoroutinePromiseAccess::release(void *)>:
       0: 48 ff 25 00 00 00 00         	jmpq	*(%rip)                 # 0x7 <public: static void __cdecl lux::simulation::script::ScriptCoroutinePromiseAccess::release(void *)+0x7>
		0000000000000003:  IMAGE_REL_AMD64_REL32	__imp_?releaseFrame@ScriptCoroutineContext@script@simulation@lux@@CAXPEAX@Z

Disassembly of section .text$mn:

0000000000000000 <public: class lux::simulation::script::PreparedLocalAsyncStart __cdecl lux::simulation::script::PreparedLocalAsyncCatalog::resolve(class lux::cxx::StableNameIdView<struct lux::script::ScriptApiMethodIdTag, struct lux::cxx::Fnv1a64>, void *, void const *) const>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 60                  	subq	$0x60, %rsp
       6: 48 8b da                     	movq	%rdx, %rbx
       9: 4c 8b 51 10                  	movq	0x10(%rcx), %r10
       d: 4d 85 d2                     	testq	%r10, %r10
      10: 74 3a                        	je	0x4c <public: class lux::simulation::script::PreparedLocalAsyncStart __cdecl lux::simulation::script::PreparedLocalAsyncCatalog::resolve(class lux::cxx::StableNameIdView<struct lux::script::ScriptApiMethodIdTag, struct lux::cxx::Fnv1a64>, void *, void const *) const+0x4c>
      12: 48 8b 11                     	movq	(%rcx), %rdx
      15: 4c 3b ca                     	cmpq	%rdx, %r9
      18: 75 32                        	jne	0x4c <public: class lux::simulation::script::PreparedLocalAsyncStart __cdecl lux::simulation::script::PreparedLocalAsyncCatalog::resolve(class lux::cxx::StableNameIdView<struct lux::script::ScriptApiMethodIdTag, struct lux::cxx::Fnv1a64>, void *, void const *) const+0x4c>
      1a: 48 8b 41 08                  	movq	0x8(%rcx), %rax
      1e: 48 39 84 24 90 00 00 00      	cmpq	%rax, 0x90(%rsp)
      26: 75 24                        	jne	0x4c <public: class lux::simulation::script::PreparedLocalAsyncStart __cdecl lux::simulation::script::PreparedLocalAsyncCatalog::resolve(class lux::cxx::StableNameIdView<struct lux::script::ScriptApiMethodIdTag, struct lux::cxx::Fnv1a64>, void *, void const *) const+0x4c>
      28: 41 0f 10 00                  	movups	(%r8), %xmm0
      2c: 0f 29 44 24 20               	movaps	%xmm0, 0x20(%rsp)
      31: f2 41 0f 10 48 10            	movsd	0x10(%r8), %xmm1
      37: f2 0f 11 4c 24 30            	movsd	%xmm1, 0x30(%rsp)
      3d: 4c 8d 44 24 20               	leaq	0x20(%rsp), %r8
      42: 48 8d 4c 24 40               	leaq	0x40(%rsp), %rcx
      47: 41 ff d2                     	callq	*%r10
      4a: eb 14                        	jmp	0x60 <public: class lux::simulation::script::PreparedLocalAsyncStart __cdecl lux::simulation::script::PreparedLocalAsyncCatalog::resolve(class lux::cxx::StableNameIdView<struct lux::script::ScriptApiMethodIdTag, struct lux::cxx::Fnv1a64>, void *, void const *) const+0x60>
      4c: 0f 57 c0                     	xorps	%xmm0, %xmm0
      4f: 33 c0                        	xorl	%eax, %eax
      51: 0f 11 44 24 20               	movups	%xmm0, 0x20(%rsp)
      56: 48 89 44 24 30               	movq	%rax, 0x30(%rsp)
      5b: 48 8d 44 24 20               	leaq	0x20(%rsp), %rax
      60: 0f 10 00                     	movups	(%rax), %xmm0
      63: 0f 11 03                     	movups	%xmm0, (%rbx)
      66: f2 0f 10 48 10               	movsd	0x10(%rax), %xmm1
      6b: f2 0f 11 4b 10               	movsd	%xmm1, 0x10(%rbx)
      70: 48 8b c3                     	movq	%rbx, %rax
      73: 48 83 c4 60                  	addq	$0x60, %rsp
      77: 5b                           	popq	%rbx
      78: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: void __cdecl lux::simulation::script::ScriptCoroutine::promise_type::return_void(void)>:
       0: 48 83 ec 18                  	subq	$0x18, %rsp
       4: 80 39 02                     	cmpb	$0x2, (%rcx)
       7: 74 16                        	je	0x1f <public: void __cdecl lux::simulation::script::ScriptCoroutine::promise_type::return_void(void)+0x1f>
       9: 33 c0                        	xorl	%eax, %eax
       b: c6 04 24 00                  	movb	$0x0, (%rsp)
       f: 48 89 44 24 04               	movq	%rax, 0x4(%rsp)
      14: 89 44 24 0c                  	movl	%eax, 0xc(%rsp)
      18: 0f 10 04 24                  	movups	(%rsp), %xmm0
      1c: 0f 11 01                     	movups	%xmm0, (%rcx)
      1f: 48 83 c4 18                  	addq	$0x18, %rsp
      23: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::sequence$_DestroyCoro$2(class lux::simulation::script::ScriptCoroutineContext &)>:
       0: 48 83 49 50 01               	orq	$0x1, 0x50(%rcx)
       5: e9 00 00 00 00               	jmp	0xa <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::sequence$_DestroyCoro$2(class lux::simulation::script::ScriptCoroutineContext &)+0xa>
		0000000000000006:  IMAGE_REL_AMD64_REL32	?sequence$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z

Disassembly of section .text$mn:

0000000000000000 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::sequence$_ResumeCoro$1(class lux::simulation::script::ScriptCoroutineContext &)>:
       0: 48 89 5c 24 10               	movq	%rbx, 0x10(%rsp)
       5: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
       a: 48 89 4c 24 08               	movq	%rcx, 0x8(%rsp)
       f: 57                           	pushq	%rdi
      10: 48 81 ec 80 00 00 00         	subq	$0x80, %rsp

0000000000000017 <$__resumable_prolog_label>:
      17: 48 8b bc 24 90 00 00 00      	movq	0x90(%rsp), %rdi
      1f: 0f b7 47 50                  	movzwl	0x50(%rdi), %eax
      23: 66 89 44 24 30               	movw	%ax, 0x30(%rsp)
      28: 66 ff c0                     	incw	%ax
      2b: 66 83 f8 0e                  	cmpw	$0xe, %ax
      2f: 0f 87 fd 02 00 00            	ja	0x332 <$__resumable_state_0>
      35: 48 0f bf c0                  	movswq	%ax, %rax
      39: 48 8d 15 00 00 00 00         	leaq	(%rip), %rdx            # 0x40 <$__resumable_prolog_label+0x29>
		000000000000003c:  IMAGE_REL_AMD64_REL32	__ImageBase
      40: 8b 8c 82 00 00 00 00         	movl	(%rdx,%rax,4), %ecx
		0000000000000043:  IMAGE_REL_AMD64_ADDR32NB	$LN171
      47: 48 03 ca                     	addq	%rdx, %rcx
      4a: ff e1                        	jmpq	*%rcx

000000000000004c <$__resumable_state_3>:
      4c: e9 cf 02 00 00               	jmp	0x320 <$__resumable_state_1>

0000000000000051 <$__resumable_state_2>:
      51: 33 db                        	xorl	%ebx, %ebx
      53: 48 89 5c 24 28               	movq	%rbx, 0x28(%rsp)
      58: 48 89 5c 24 20               	movq	%rbx, 0x20(%rsp)
      5d: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0x64 <$__resumable_state_2+0x13>
		0000000000000060:  IMAGE_REL_AMD64_REL32	?Shape@?$ScriptSyncStepCall@$$A6AXXZ@detail@script@simulation@lux@@2UScriptSyncStepShape@345@B
      64: 41 b8 01 00 00 00            	movl	$0x1, %r8d
      6a: 48 8d 57 58                  	leaq	0x58(%rdi), %rdx
      6e: 48 8b 4f 48                  	movq	0x48(%rdi), %rcx
      72: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x78 <$__resumable_state_2+0x27>
		0000000000000074:  IMAGE_REL_AMD64_REL32	__imp_?invokeSyncStep@ScriptCoroutineContext@script@simulation@lux@@AEAA?AV?$expected@XUScriptSyncStepError@script@simulation@lux@@@tl@@IAEBUScriptSyncStepShape@234@PEBQEBXPEAX@Z
      78: 48 8b 4f 48                  	movq	0x48(%rdi), %rcx
      7c: 0f b6 47 64                  	movzbl	0x64(%rdi), %eax
      80: 88 44 24 6c                  	movb	%al, 0x6c(%rsp)
      84: 84 c0                        	testb	%al, %al
      86: 75 49                        	jne	0xd1 <$__resumable_state_2+0x80>
      88: 4c 8d 87 50 01 00 00         	leaq	0x150(%rdi), %r8
      8f: f2 0f 10 47 58               	movsd	0x58(%rdi), %xmm0
      94: f2 0f 11 44 24 60            	movsd	%xmm0, 0x60(%rsp)
      9a: 8b 47 60                     	movl	0x60(%rdi), %eax
      9d: 89 44 24 68                  	movl	%eax, 0x68(%rsp)
      a1: f2 41 0f 11 00               	movsd	%xmm0, (%r8)
      a6: 41 89 40 08                  	movl	%eax, 0x8(%r8)
      aa: 48 8d 57 78                  	leaq	0x78(%rdi), %rdx
      ae: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xb4 <$__resumable_state_2+0x63>
		00000000000000b0:  IMAGE_REL_AMD64_REL32	__imp_?fail@ScriptCoroutineContext@script@simulation@lux@@QEAA?AVScriptCoroutineFailure@234@UScriptSyncStepError@234@@Z
      b4: 48 89 47 70                  	movq	%rax, 0x70(%rdi)
      b8: b9 04 00 00 00               	movl	$0x4, %ecx
      bd: 66 89 4f 50                  	movw	%cx, 0x50(%rdi)
      c1: 48 8b d7                     	movq	%rdi, %rdx
      c4: 48 8b c8                     	movq	%rax, %rcx
      c7: e8 00 00 00 00               	callq	0xcc <$__resumable_state_2+0x7b>
		00000000000000c8:  IMAGE_REL_AMD64_REL32	?await_suspend@ScriptCoroutineFailure@script@simulation@lux@@QEBAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
      cc: e9 62 02 00 00               	jmp	0x333 <$__resumable_epilog_label>
      d1: 48 8d 97 80 00 00 00         	leaq	0x80(%rdi), %rdx
      d8: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xde <$__resumable_state_2+0x8d>
		00000000000000da:  IMAGE_REL_AMD64_REL32	__imp_?delay@ScriptCoroutineContext@script@simulation@lux@@QEAA?AV?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@XZ
      de: 0f b6 97 71 01 00 00         	movzbl	0x171(%rdi), %edx
      e5: 4c 8d 87 70 01 00 00         	leaq	0x170(%rdi), %r8
      ec: 88 54 24 28                  	movb	%dl, 0x28(%rsp)
      f0: 4c 89 44 24 20               	movq	%r8, 0x20(%rsp)
      f5: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0xfc <$__resumable_state_2+0xab>
		00000000000000f8:  IMAGE_REL_AMD64_REL32	?method_id@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@4V?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@B
      fc: 44 8b 40 08                  	movl	0x8(%rax), %r8d
     100: 48 8d 97 90 00 00 00         	leaq	0x90(%rdi), %rdx
     107: 48 8b 08                     	movq	(%rax), %rcx
     10a: e8 00 00 00 00               	callq	0x10f <$__resumable_state_2+0xbe>
		000000000000010b:  IMAGE_REL_AMD64_REL32	??$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@3@V?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@13@QEBA@XZ@@Z
     10f: b8 06 00 00 00               	movl	$0x6, %eax
     114: 66 89 47 50                  	movw	%ax, 0x50(%rdi)
     118: 48 8b d7                     	movq	%rdi, %rdx
     11b: 48 8d 8f 90 00 00 00         	leaq	0x90(%rdi), %rcx
     122: e8 00 00 00 00               	callq	0x127 <$__resumable_state_2+0xd6>
		0000000000000123:  IMAGE_REL_AMD64_REL32	?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@$$V@std@@V<lambda_1>@?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@XZ@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@$$V@std@@V1?1??nextStep@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@XZ@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
     127: e9 07 02 00 00               	jmp	0x333 <$__resumable_epilog_label>

000000000000012c <$__resumable_state_5>:
     12c: e9 ef 01 00 00               	jmp	0x320 <$__resumable_state_1>

0000000000000131 <$__resumable_state_4>:
     131: 48 8b 4f 70                  	movq	0x70(%rdi), %rcx
     135: e8 00 00 00 00               	callq	0x13a <$__resumable_state_4+0x9>
		0000000000000136:  IMAGE_REL_AMD64_REL32	?await_resume@ScriptCoroutineFailure@script@simulation@lux@@QEBAXXZ
     13a: 90                           	nop

000000000000013b <$__resumable_state_7>:
     13b: e9 e0 01 00 00               	jmp	0x320 <$__resumable_state_1>

0000000000000140 <$__resumable_state_6>:
     140: 48 8d 97 c8 00 00 00         	leaq	0xc8(%rdi), %rdx
     147: 4c 8d 05 00 00 00 00         	leaq	(%rip), %r8             # 0x14e <$__resumable_state_6+0xe>
		000000000000014a:  IMAGE_REL_AMD64_REL32	?source@cost@na1@simulation@lux@@3V?$optional@V?$CppScriptEventSource@H@script@simulation@lux@@@std@@A
     14e: 48 8b 4f 48                  	movq	0x48(%rdi), %rcx
     152: e8 00 00 00 00               	callq	0x157 <$__resumable_state_6+0x17>
		0000000000000153:  IMAGE_REL_AMD64_REL32	??$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@123@@Z
     157: 48 89 87 c0 00 00 00         	movq	%rax, 0xc0(%rdi)
     15e: b9 08 00 00 00               	movl	$0x8, %ecx
     163: 66 89 4f 50                  	movw	%cx, 0x50(%rdi)
     167: 48 8b d7                     	movq	%rdi, %rdx
     16a: 48 8b c8                     	movq	%rax, %rcx
     16d: e8 00 00 00 00               	callq	0x172 <$__resumable_state_6+0x32>
		000000000000016e:  IMAGE_REL_AMD64_REL32	?await_suspend@?$ScriptCoroutineAwaiter@HV<lambda_1>@?1???$wait@H@ScriptCoroutineContext@script@simulation@lux@@QEAA?A_PAEBV?$CppScriptEventSource@H@345@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
     172: e9 bc 01 00 00               	jmp	0x333 <$__resumable_epilog_label>

0000000000000177 <$__resumable_state_9>:
     177: e9 a4 01 00 00               	jmp	0x320 <$__resumable_state_1>

000000000000017c <$__resumable_state_8>:
     17c: 48 8b 87 c0 00 00 00         	movq	0xc0(%rdi), %rax
     183: 48 8b 40 18                  	movq	0x18(%rax), %rax
     187: 48 8b 48 20                  	movq	0x20(%rax), %rcx
     18b: 8b 01                        	movl	(%rcx), %eax
     18d: 89 87 b8 00 00 00            	movl	%eax, 0xb8(%rdi)
     193: 48 8d 97 e8 00 00 00         	leaq	0xe8(%rdi), %rdx
     19a: 48 8b 4f 48                  	movq	0x48(%rdi), %rcx
     19e: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x1a4 <$__resumable_state_8+0x28>
		00000000000001a0:  IMAGE_REL_AMD64_REL32	__imp_?delay@ScriptCoroutineContext@script@simulation@lux@@QEAA?AV?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@24@XZ
     1a4: 4c 8d 87 78 01 00 00         	leaq	0x178(%rdi), %r8
     1ab: 48 b9 fc a9 f1 d2 4d 62 50 3f	movabsq	$0x3f50624dd2f1a9fc, %rcx # imm = 0x3F50624DD2F1A9FC
     1b5: 49 89 08                     	movq	%rcx, (%r8)
     1b8: 0f b6 97 72 01 00 00         	movzbl	0x172(%rdi), %edx
     1bf: 88 54 24 28                  	movb	%dl, 0x28(%rsp)
     1c3: 4c 89 44 24 20               	movq	%r8, 0x20(%rsp)
     1c8: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0x1cf <$__resumable_state_8+0x53>
		00000000000001cb:  IMAGE_REL_AMD64_REL32	?method_id@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@4V?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@B
     1cf: 44 8b 40 08                  	movl	0x8(%rax), %r8d
     1d3: 48 8d 97 f8 00 00 00         	leaq	0xf8(%rdi), %rdx
     1da: 48 8b 08                     	movq	(%rax), %rcx
     1dd: e8 00 00 00 00               	callq	0x1e2 <$__resumable_state_8+0x66>
		00000000000001de:  IMAGE_REL_AMD64_REL32	??$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@3@V?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@13@QEBA@N@Z@@Z
     1e2: b8 0a 00 00 00               	movl	$0xa, %eax
     1e7: 66 89 47 50                  	movw	%ax, 0x50(%rdi)
     1eb: 48 8b d7                     	movq	%rdi, %rdx
     1ee: 48 8d 8f f8 00 00 00         	leaq	0xf8(%rdi), %rcx
     1f5: e8 00 00 00 00               	callq	0x1fa <$__resumable_state_8+0x7e>
		00000000000001f6:  IMAGE_REL_AMD64_REL32	?await_suspend@?$ScriptCoroutineAwaiter@XV<lambda_1>@?1???$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@5@V?$tuple@N@std@@V1?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@35@QEBA@N@Z@@Z@@script@simulation@lux@@QEAAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
     1fa: e9 34 01 00 00               	jmp	0x333 <$__resumable_epilog_label>

00000000000001ff <$__resumable_state_11>:
     1ff: e9 1c 01 00 00               	jmp	0x320 <$__resumable_state_1>

0000000000000204 <$__resumable_state_10>:
     204: 48 8d 8f 90 01 00 00         	leaq	0x190(%rdi), %rcx
     20b: 48 8d 87 b8 00 00 00         	leaq	0xb8(%rdi), %rax
     212: 48 89 01                     	movq	%rax, (%rcx)
     215: 33 db                        	xorl	%ebx, %ebx
     217: 48 89 5c 24 28               	movq	%rbx, 0x28(%rsp)
     21c: 48 89 4c 24 20               	movq	%rcx, 0x20(%rsp)
     221: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0x228 <$__resumable_state_10+0x24>
		0000000000000224:  IMAGE_REL_AMD64_REL32	?Shape@?$ScriptSyncStepCall@$$A6AXH@Z@detail@script@simulation@lux@@2UScriptSyncStepShape@345@B
     228: 41 b8 03 00 00 00            	movl	$0x3, %r8d
     22e: 48 8d 97 28 01 00 00         	leaq	0x128(%rdi), %rdx
     235: 48 8b 4f 48                  	movq	0x48(%rdi), %rcx
     239: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x23f <$__resumable_state_10+0x3b>
		000000000000023b:  IMAGE_REL_AMD64_REL32	__imp_?invokeSyncStep@ScriptCoroutineContext@script@simulation@lux@@AEAA?AV?$expected@XUScriptSyncStepError@script@simulation@lux@@@tl@@IAEBUScriptSyncStepShape@234@PEBQEBXPEAX@Z
     23f: 0f 10 87 28 01 00 00         	movups	0x128(%rdi), %xmm0
     246: 0f 11 44 24 48               	movups	%xmm0, 0x48(%rsp)
     24b: 8b 87 38 01 00 00            	movl	0x138(%rdi), %eax
     251: 89 44 24 58                  	movl	%eax, 0x58(%rsp)
     255: 0f 11 47 58                  	movups	%xmm0, 0x58(%rdi)
     259: 89 47 68                     	movl	%eax, 0x68(%rdi)
     25c: 48 8b 87 30 01 00 00         	movq	0x130(%rdi), %rax
     263: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
     268: 48 c1 e8 20                  	shrq	$0x20, %rax
     26c: 84 c0                        	testb	%al, %al
     26e: 75 56                        	jne	0x2c6 <$__resumable_state_10+0xc2>
     270: 4c 8d 87 60 01 00 00         	leaq	0x160(%rdi), %r8
     277: f2 0f 10 87 28 01 00 00      	movsd	0x128(%rdi), %xmm0
     27f: f2 0f 11 44 24 48            	movsd	%xmm0, 0x48(%rsp)
     285: 8b 87 30 01 00 00            	movl	0x130(%rdi), %eax
     28b: 89 44 24 50                  	movl	%eax, 0x50(%rsp)
     28f: f2 41 0f 11 00               	movsd	%xmm0, (%r8)
     294: 41 89 40 08                  	movl	%eax, 0x8(%r8)
     298: 48 8d 97 48 01 00 00         	leaq	0x148(%rdi), %rdx
     29f: 48 8b 4f 48                  	movq	0x48(%rdi), %rcx
     2a3: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x2a9 <$__resumable_state_10+0xa5>
		00000000000002a5:  IMAGE_REL_AMD64_REL32	__imp_?fail@ScriptCoroutineContext@script@simulation@lux@@QEAA?AVScriptCoroutineFailure@234@UScriptSyncStepError@234@@Z
     2a9: 48 89 87 40 01 00 00         	movq	%rax, 0x140(%rdi)
     2b0: b9 0c 00 00 00               	movl	$0xc, %ecx
     2b5: 66 89 4f 50                  	movw	%cx, 0x50(%rdi)
     2b9: 48 8b d7                     	movq	%rdi, %rdx
     2bc: 48 8b c8                     	movq	%rax, %rcx
     2bf: e8 00 00 00 00               	callq	0x2c4 <$__resumable_state_10+0xc0>
		00000000000002c0:  IMAGE_REL_AMD64_REL32	?await_suspend@ScriptCoroutineFailure@script@simulation@lux@@QEBAXU?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
     2c4: eb 6d                        	jmp	0x333 <$__resumable_epilog_label>
     2c6: 80 7f 10 02                  	cmpb	$0x2, 0x10(%rdi)
     2ca: 74 23                        	je	0x2ef <$$__resumable_return_label$173>
     2cc: 88 9f 80 01 00 00            	movb	%bl, 0x180(%rdi)
     2d2: 48 89 9f 84 01 00 00         	movq	%rbx, 0x184(%rdi)
     2d9: 89 9f 8c 01 00 00            	movl	%ebx, 0x18c(%rdi)
     2df: 0f 10 87 80 01 00 00         	movups	0x180(%rdi), %xmm0
     2e6: 0f 11 44 24 38               	movups	%xmm0, 0x38(%rsp)
     2eb: 0f 11 47 10                  	movups	%xmm0, 0x10(%rdi)

00000000000002ef <$$__resumable_return_label$173>:
     2ef: 48 8d 8f 4c 01 00 00         	leaq	0x14c(%rdi), %rcx
     2f6: 33 c0                        	xorl	%eax, %eax
     2f8: 88 01                        	movb	%al, (%rcx)
     2fa: 66 89 47 50                  	movw	%ax, 0x50(%rdi)
     2fe: 48 89 1f                     	movq	%rbx, (%rdi)
     301: 48 8b d7                     	movq	%rdi, %rdx
     304: e8 00 00 00 00               	callq	0x309 <$$__resumable_return_label$173+0x1a>
		0000000000000305:  IMAGE_REL_AMD64_REL32	?await_suspend@suspend_always@std@@QEBAXU?$coroutine_handle@X@2@@Z
     309: eb 28                        	jmp	0x333 <$__resumable_epilog_label>

000000000000030b <$__resumable_state_13>:
     30b: eb 13                        	jmp	0x320 <$__resumable_state_1>

000000000000030d <$__resumable_state_12>:
     30d: 48 8b 8f 40 01 00 00         	movq	0x140(%rdi), %rcx
     314: e8 00 00 00 00               	callq	0x319 <$__resumable_state_12+0xc>
		0000000000000315:  IMAGE_REL_AMD64_REL32	?await_resume@ScriptCoroutineFailure@script@simulation@lux@@QEBAXXZ
     319: cc                           	int3
     31a: 66 0f 1f 44 00 00            	nopw	(%rax,%rax)

0000000000000320 <$__resumable_state_1>:
     320: 66 83 7f 52 00               	cmpw	$0x0, 0x52(%rdi)
     325: 74 0c                        	je	0x333 <$__resumable_epilog_label>
     327: 48 8b cf                     	movq	%rdi, %rcx
     32a: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x330 <$__resumable_state_1+0x10>
		000000000000032c:  IMAGE_REL_AMD64_REL32	__imp_?releaseFrame@ScriptCoroutineContext@script@simulation@lux@@CAXPEAX@Z
     330: eb 01                        	jmp	0x333 <$__resumable_epilog_label>

0000000000000332 <$__resumable_state_0>:
     332: cc                           	int3

0000000000000333 <$__resumable_epilog_label>:
     333: 4c 8d 9c 24 80 00 00 00      	leaq	0x80(%rsp), %r11
     33b: 49 8b 5b 18                  	movq	0x18(%r11), %rbx
     33f: 49 8b 73 20                  	movq	0x20(%r11), %rsi
     343: 49 8b e3                     	movq	%r11, %rsp
     346: 5f                           	popq	%rdi
     347: c3                           	retq
     348: cc                           	int3

0000000000000349 <$LN172>:
     349: 0f 1f 00                     	nopl	(%rax)

000000000000034c <$LN171>:
     34c: 00 00                        	addb	%al, (%rax)
		000000000000034c:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_1
     34e: 00 00                        	addb	%al, (%rax)
     350: 00 00                        	addb	%al, (%rax)
		0000000000000350:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_0
     352: 00 00                        	addb	%al, (%rax)
     354: 00 00                        	addb	%al, (%rax)
		0000000000000354:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_1
     356: 00 00                        	addb	%al, (%rax)
     358: 00 00                        	addb	%al, (%rax)
		0000000000000358:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_2
     35a: 00 00                        	addb	%al, (%rax)
     35c: 00 00                        	addb	%al, (%rax)
		000000000000035c:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_3
     35e: 00 00                        	addb	%al, (%rax)
     360: 00 00                        	addb	%al, (%rax)
		0000000000000360:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_4
     362: 00 00                        	addb	%al, (%rax)
     364: 00 00                        	addb	%al, (%rax)
		0000000000000364:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_5
     366: 00 00                        	addb	%al, (%rax)
     368: 00 00                        	addb	%al, (%rax)
		0000000000000368:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_6
     36a: 00 00                        	addb	%al, (%rax)
     36c: 00 00                        	addb	%al, (%rax)
		000000000000036c:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_7
     36e: 00 00                        	addb	%al, (%rax)
     370: 00 00                        	addb	%al, (%rax)
		0000000000000370:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_8
     372: 00 00                        	addb	%al, (%rax)
     374: 00 00                        	addb	%al, (%rax)
		0000000000000374:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_9
     376: 00 00                        	addb	%al, (%rax)
     378: 00 00                        	addb	%al, (%rax)
		0000000000000378:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_10
     37a: 00 00                        	addb	%al, (%rax)
     37c: 00 00                        	addb	%al, (%rax)
		000000000000037c:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_11
     37e: 00 00                        	addb	%al, (%rax)
     380: 00 00                        	addb	%al, (%rax)
		0000000000000380:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_12
     382: 00 00                        	addb	%al, (%rax)
     384: 00 00                        	addb	%al, (%rax)
		0000000000000384:  IMAGE_REL_AMD64_ADDR32NB	$__resumable_state_13
     386: 00 00                        	addb	%al, (%rax)

Disassembly of section .text$x:

0000000000000000 <int `public: class simulation::na1::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::sequence$_ResumeCoro$1(class simulation::na1::ScriptCoroutine::ScriptCoroutineContext &)'::`1'::catch$0>:
       0: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
       5: 55                           	pushq	%rbp
       6: 48 83 ec 30                  	subq	$0x30, %rsp
       a: 48 8b ea                     	movq	%rdx, %rbp

000000000000000d <__catch$?sequence$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z$0>:
       d: 48 8b 8d 90 00 00 00         	movq	0x90(%rbp), %rcx
      14: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
      1b: b8 ff ff ff ff               	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
      20: 66 89 41 50                  	movw	%ax, 0x50(%rcx)
      24: 48 83 c1 10                  	addq	$0x10, %rcx
      28: e8 00 00 00 00               	callq	0x2d <__catch$?sequence$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z$0+0x20>
		0000000000000029:  IMAGE_REL_AMD64_REL32	?unhandled_exception@promise_type@ScriptCoroutine@script@simulation@lux@@QEAAXXZ
      2d: 90                           	nop

Disassembly of section .text$mn:

0000000000000000 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::sequence(class lux::simulation::script::ScriptCoroutineContext &)>:
       0: 48 89 5c 24 08               	movq	%rbx, 0x8(%rsp)
       5: 48 89 6c 24 10               	movq	%rbp, 0x10(%rsp)
       a: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
       f: 57                           	pushq	%rdi
      10: 48 83 ec 20                  	subq	$0x20, %rsp
      14: 49 8b f0                     	movq	%r8, %rsi
      17: 48 8b fa                     	movq	%rdx, %rdi
      1a: 48 8b e9                     	movq	%rcx, %rbp
      1d: ba a0 01 00 00               	movl	$0x1a0, %edx            # imm = 0x1A0
      22: 41 b8 08 00 00 00            	movl	$0x8, %r8d
      28: 48 8b ce                     	movq	%rsi, %rcx
      2b: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x31 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::sequence(class lux::simulation::script::ScriptCoroutineContext &)+0x31>
		000000000000002d:  IMAGE_REL_AMD64_REL32	__imp_?allocateFrame@ScriptCoroutineContext@script@simulation@lux@@AEAAPEAX_K0@Z
      31: 48 8b d8                     	movq	%rax, %rbx
      34: 48 8b cf                     	movq	%rdi, %rcx
      37: 48 85 c0                     	testq	%rax, %rax
      3a: 75 0b                        	jne	0x47 <$$__resumable_init_label$59>
      3c: 48 89 07                     	movq	%rax, (%rdi)
      3f: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x45 <public: class lux::simulation::script::ScriptCoroutine __cdecl lux::simulation::na1::cost::Tasks::sequence(class lux::simulation::script::ScriptCoroutineContext &)+0x45>
		0000000000000041:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@QEAA@XZ
      45: eb 59                        	jmp	0xa0 <$$__resumable_init_label$59+0x59>

0000000000000047 <$$__resumable_init_label$59>:
      47: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x4e <$$__resumable_init_label$59+0x7>
		000000000000004a:  IMAGE_REL_AMD64_REL32	?sequence$_DestroyCoro$2@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      4e: 48 89 43 08                  	movq	%rax, 0x8(%rbx)
      52: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x59 <$$__resumable_init_label$59+0x12>
		0000000000000055:  IMAGE_REL_AMD64_REL32	?sequence$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      59: 48 89 03                     	movq	%rax, (%rbx)
      5c: 48 89 6b 40                  	movq	%rbp, 0x40(%rbx)
      60: 48 89 73 48                  	movq	%rsi, 0x48(%rbx)
      64: c7 43 50 02 00 01 00         	movl	$0x10002, 0x50(%rbx)    # imm = 0x10002
      6b: 33 c0                        	xorl	%eax, %eax
      6d: 66 89 43 11                  	movw	%ax, 0x11(%rbx)
      71: 88 43 13                     	movb	%al, 0x13(%rbx)
      74: 88 43 10                     	movb	%al, 0x10(%rbx)
      77: 48 89 43 14                  	movq	%rax, 0x14(%rbx)
      7b: 89 43 1c                     	movl	%eax, 0x1c(%rbx)
      7e: 48 89 43 20                  	movq	%rax, 0x20(%rbx)
      82: 48 89 43 28                  	movq	%rax, 0x28(%rbx)
      86: 48 89 43 30                  	movq	%rax, 0x30(%rbx)
      8a: 48 8b d3                     	movq	%rbx, %rdx
      8d: ff 15 00 00 00 00            	callq	*(%rip)                 # 0x93 <$$__resumable_init_label$59+0x4c>
		000000000000008f:  IMAGE_REL_AMD64_REL32	__imp_??0ScriptCoroutine@script@simulation@lux@@AEAA@U?$coroutine_handle@Upromise_type@ScriptCoroutine@script@simulation@lux@@@std@@@Z
      93: 33 c0                        	xorl	%eax, %eax
      95: 88 43 38                     	movb	%al, 0x38(%rbx)
      98: 48 8b cb                     	movq	%rbx, %rcx
      9b: e8 00 00 00 00               	callq	0xa0 <$$__resumable_init_label$59+0x59>
		000000000000009c:  IMAGE_REL_AMD64_REL32	?sequence$_ResumeCoro$1@Tasks@cost@na1@simulation@lux@@QEAA?AVScriptCoroutine@script@45@AEAVScriptCoroutineContext@745@@Z
      a0: 48 8b c7                     	movq	%rdi, %rax
      a3: 48 8b 5c 24 30               	movq	0x30(%rsp), %rbx
      a8: 48 8b 6c 24 38               	movq	0x38(%rsp), %rbp
      ad: 48 8b 74 24 40               	movq	0x40(%rsp), %rsi
      b2: 48 83 c4 20                  	addq	$0x20, %rsp
      b6: 5f                           	popq	%rdi
      b7: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::simulationSeconds(double) const>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 30                  	subq	$0x30, %rsp
       6: 44 8b 41 08                  	movl	0x8(%rcx), %r8d
       a: 4c 8d 0d 00 00 00 00         	leaq	(%rip), %r9             # 0x11 <public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::simulationSeconds(double) const+0x11>
		000000000000000d:  IMAGE_REL_AMD64_REL32	?method_id@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@4V?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@4@B
      11: 48 8b 09                     	movq	(%rcx), %rcx
      14: 48 8b da                     	movq	%rdx, %rbx
      17: f2 0f 11 54 24 40            	movsd	%xmm2, 0x40(%rsp)
      1d: 0f b6 44 24 40               	movzbl	0x40(%rsp), %eax
      22: 88 44 24 28                  	movb	%al, 0x28(%rsp)
      26: 48 8d 44 24 40               	leaq	0x40(%rsp), %rax
      2b: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
      30: e8 00 00 00 00               	callq	0x35 <public: __cdecl lux::script::ScriptAbilityCoroutine<struct lux::simulation::script::DelayAbility, class lux::simulation::script::ScriptCoroutineContext>::simulationSeconds(double) const+0x35>
		0000000000000031:  IMAGE_REL_AMD64_REL32	??$awaitPreparedAbility@XV?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@script@lux@@QEBA@N@Z@@ScriptCoroutineContext@script@simulation@lux@@AEAA?A_PIAEBV?$StableNameIdView@UScriptApiMethodIdTag@script@lux@@UFnv1a64@cxx@3@@cxx@3@V?$tuple@N@std@@V<lambda_1>@?1??simulationSeconds@?$ScriptAbilityCoroutine@UDelayAbility@script@simulation@lux@@VScriptCoroutineContext@234@@13@QEBA@N@Z@@Z
      35: 48 8b c3                     	movq	%rbx, %rax
      38: 48 83 c4 30                  	addq	$0x30, %rsp
      3c: 5b                           	popq	%rbx
      3d: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: struct lux::simulation::script::ScriptStepResult __cdecl lux::simulation::script::PreparedLocalAsyncStart::start(struct lux::simulation::script::ScriptStepContext &, class std::span<struct lux_script_value_slot const, -1>) const>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 40                  	subq	$0x40, %rsp
       6: 48 8b da                     	movq	%rdx, %rbx
       9: 48 8b 41 08                  	movq	0x8(%rcx), %rax
       d: 48 85 c0                     	testq	%rax, %rax
      10: 74 34                        	je	0x46 <public: struct lux::simulation::script::ScriptStepResult __cdecl lux::simulation::script::PreparedLocalAsyncStart::start(struct lux::simulation::script::ScriptStepContext &, class std::span<struct lux_script_value_slot const, -1>) const+0x46>
      12: 41 0f 10 01                  	movups	(%r9), %xmm0
      16: 0f 29 44 24 20               	movaps	%xmm0, 0x20(%rsp)
      1b: 4c 8d 4c 24 20               	leaq	0x20(%rsp), %r9
      20: 48 8b 11                     	movq	(%rcx), %rdx
      23: 48 8d 4c 24 30               	leaq	0x30(%rsp), %rcx
      28: ff d0                        	callq	*%rax
      2a: 0f 10 00                     	movups	(%rax), %xmm0
      2d: 0f 11 44 24 20               	movups	%xmm0, 0x20(%rsp)
      32: 48 8d 44 24 20               	leaq	0x20(%rsp), %rax
      37: 0f 10 00                     	movups	(%rax), %xmm0
      3a: 0f 11 03                     	movups	%xmm0, (%rbx)
      3d: 48 8b c3                     	movq	%rbx, %rax
      40: 48 83 c4 40                  	addq	$0x40, %rsp
      44: 5b                           	popq	%rbx
      45: c3                           	retq
      46: c6 44 24 20 02               	movb	$0x2, 0x20(%rsp)
      4b: 33 c0                        	xorl	%eax, %eax
      4d: 48 89 44 24 24               	movq	%rax, 0x24(%rsp)
      52: c7 44 24 2c ff ff ff ff      	movl	$0xffffffff, 0x2c(%rsp) # imm = 0xFFFFFFFF
      5a: 0f 28 44 24 20               	movaps	0x20(%rsp), %xmm0
      5f: 66 0f 7f 44 24 20            	movdqa	%xmm0, 0x20(%rsp)
      65: 48 8d 44 24 20               	leaq	0x20(%rsp), %rax
      6a: 0f 10 00                     	movups	(%rax), %xmm0
      6d: 0f 11 03                     	movups	%xmm0, (%rbx)
      70: 48 8b c3                     	movq	%rbx, %rax
      73: 48 83 c4 40                  	addq	$0x40, %rsp
      77: 5b                           	popq	%rbx
      78: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: void __cdecl lux::simulation::script::ScriptCoroutine::promise_type::suspend(struct lux::simulation::script::ScriptStepResult, unsigned __int64, unsigned __int64)>:
       0: 0f 10 02                     	movups	(%rdx), %xmm0
       3: 4c 89 41 10                  	movq	%r8, 0x10(%rcx)
       7: 4c 89 49 18                  	movq	%r9, 0x18(%rcx)
       b: 0f 11 01                     	movups	%xmm0, (%rcx)
       e: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: static struct lux::simulation::script::ScriptStepResult __cdecl lux::simulation::script::ScriptStepResult::suspended(struct lux::simulation::script::ScriptAwaitableId)>:
       0: c6 01 01                     	movb	$0x1, (%rcx)
       3: 48 8b c1                     	movq	%rcx, %rax
       6: 48 89 51 04                  	movq	%rdx, 0x4(%rcx)
       a: c7 41 0c 00 00 00 00         	movl	$0x0, 0xc(%rcx)
      11: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <unsigned __int64 __cdecl lux::semantic::typeId(class std::basic_string_view<char, struct std::char_traits<char>>)>:
       0: 48 8b 11                     	movq	(%rcx), %rdx
       3: 48 b8 25 23 22 84 e4 9c f2 cb	movabsq	$-0x340d631b7bdddcdb, %rax # imm = 0xCBF29CE484222325
       d: 4c 8b 41 08                  	movq	0x8(%rcx), %r8
      11: 4c 03 c2                     	addq	%rdx, %r8
      14: 49 3b d0                     	cmpq	%r8, %rdx
      17: 74 29                        	je	0x42 <unsigned __int64 __cdecl lux::semantic::typeId(class std::basic_string_view<char, struct std::char_traits<char>>)+0x42>
      19: 49 b9 b3 01 00 00 00 01 00 00	movabsq	$0x100000001b3, %r9     # imm = 0x100000001B3
      23: 0f 1f 40 00                  	nopl	(%rax)
      27: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
      30: 0f b6 0a                     	movzbl	(%rdx), %ecx
      33: 48 ff c2                     	incq	%rdx
      36: 48 33 c1                     	xorq	%rcx, %rax
      39: 49 0f af c1                  	imulq	%r9, %rax
      3d: 49 3b d0                     	cmpq	%r8, %rdx
      40: 75 ee                        	jne	0x30 <unsigned __int64 __cdecl lux::semantic::typeId(class std::basic_string_view<char, struct std::char_traits<char>>)+0x30>
      42: 48 85 c0                     	testq	%rax, %rax
      45: b9 01 00 00 00               	movl	$0x1, %ecx
      4a: 48 0f 44 c1                  	cmoveq	%rcx, %rax
      4e: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: void __cdecl lux::simulation::script::ScriptCoroutine::promise_type::unhandled_exception(void)>:
       0: 48 83 ec 28                  	subq	$0x28, %rsp
       4: ff 15 00 00 00 00            	callq	*(%rip)                 # 0xa <public: void __cdecl lux::simulation::script::ScriptCoroutine::promise_type::unhandled_exception(void)+0xa>
		0000000000000006:  IMAGE_REL_AMD64_REL32	__imp_terminate
       a: cc                           	int3

Disassembly of section .text$mn:

0000000000000000 <public: bool __cdecl lux::script::ScriptAbilityOperationError::valid(void) const>:
       0: 83 39 00                     	cmpl	$0x0, (%rcx)
       3: 0f 9f c0                     	setg	%al
       6: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: bool __cdecl lux::simulation::script::ScriptAwaitableId::valid(void) const>:
       0: 83 39 00                     	cmpl	$0x0, (%rcx)
       3: 74 09                        	je	0xe <public: bool __cdecl lux::simulation::script::ScriptAwaitableId::valid(void) const+0xe>
       5: 83 79 04 00                  	cmpl	$0x0, 0x4(%rcx)
       9: 74 03                        	je	0xe <public: bool __cdecl lux::simulation::script::ScriptAwaitableId::valid(void) const+0xe>
       b: b0 01                        	movb	$0x1, %al
       d: c3                           	retq
       e: 32 c0                        	xorb	%al, %al
      10: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <private: struct lux::simulation::script::ScriptAwaitableRegistration * __cdecl tl::expected<struct lux::simulation::script::ScriptAwaitableRegistration, enum lux::simulation::script::EScriptAwaitableCreateError>::valptr(void)>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: struct lux::script::ScriptAbilityOperationError & __cdecl tl::unexpected<struct lux::script::ScriptAbilityOperationError>::value(void) &>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: struct lux::simulation::script::ScriptSyncStepError & __cdecl tl::unexpected<struct lux::simulation::script::ScriptSyncStepError>::value(void) &>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: enum lux::simulation::script::EScriptAwaitableCreateError & __cdecl tl::unexpected<enum lux::simulation::script::EScriptAwaitableCreateError>::value(void) &>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: enum lux::simulation::script::EScriptEventWaitError & __cdecl tl::unexpected<enum lux::simulation::script::EScriptEventWaitError>::value(void) &>:
       0: 48 8b c1                     	movq	%rcx, %rax
       3: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <public: class tl::expected<struct lux::simulation::script::ScriptAwaitableId, enum lux::simulation::script::EScriptEventWaitError> __cdecl lux::simulation::script::ScriptEventWaitFactory::wait(class lux::simulation::script::ScriptEventAdmissionHandle) const>:
       0: 40 53                        	pushq	%rbx
       2: 48 83 ec 40                  	subq	$0x40, %rsp
       6: 48 8b da                     	movq	%rdx, %rbx
       9: 48 8b 41 08                  	movq	0x8(%rcx), %rax
       d: 48 85 c0                     	testq	%rax, %rax
      10: 75 0f                        	jne	0x21 <public: class tl::expected<struct lux::simulation::script::ScriptAwaitableId, enum lux::simulation::script::EScriptEventWaitError> __cdecl lux::simulation::script::ScriptEventWaitFactory::wait(class lux::simulation::script::ScriptEventAdmissionHandle) const+0x21>
      12: c6 02 0b                     	movb	$0xb, (%rdx)
      15: 88 42 08                     	movb	%al, 0x8(%rdx)
      18: 48 8b c2                     	movq	%rdx, %rax
      1b: 48 83 c4 40                  	addq	$0x40, %rsp
      1f: 5b                           	popq	%rbx
      20: c3                           	retq
      21: 41 0f 10 00                  	movups	(%r8), %xmm0
      25: 0f 29 44 24 20               	movaps	%xmm0, 0x20(%rsp)
      2a: 41 0f 10 48 10               	movups	0x10(%r8), %xmm1
      2f: 0f 29 4c 24 30               	movaps	%xmm1, 0x30(%rsp)
      34: 4c 8d 4c 24 20               	leaq	0x20(%rsp), %r9
      39: 4c 8b 41 10                  	movq	0x10(%rcx), %r8
      3d: 48 8b 11                     	movq	(%rcx), %rdx
      40: 48 8b cb                     	movq	%rbx, %rcx
      43: ff d0                        	callq	*%rax
      45: 48 8b c3                     	movq	%rbx, %rax
      48: 48 83 c4 40                  	addq	$0x40, %rsp
      4c: 5b                           	popq	%rbx
      4d: c3                           	retq

Disassembly of section .text$mn:

0000000000000000 <wmemcpy>:
       0: 4d 03 c0                     	addq	%r8, %r8
       3: e9 00 00 00 00               	jmp	0x8 <wmemcpy+0x8>
		0000000000000004:  IMAGE_REL_AMD64_REL32	memcpy
