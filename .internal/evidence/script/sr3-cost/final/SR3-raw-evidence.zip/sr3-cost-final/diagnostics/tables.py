import csv, json, statistics
from pathlib import Path

base = Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo')
root = base / 'sr3-cost-final'
costs = json.loads((root / 'cost-results.json').read_text())['comparisons']
lines = ['| 场景 | B0→B1 中位 % [min,max] | B1→B2 | B0→B2 |', '|---|---:|---:|---:|']
for case in sorted({r['case'] for r in costs}):
    values = [next(r for r in costs if r['case'] == case and r['comparison'] == c) for c in ('b0-b1','b1-b2','b0-b2')]
    lines.append('| '+case+' | '+' | '.join(f"{r['median_percent']:+.2f} [{r['range_percent'][0]:+.2f},{r['range_percent'][1]:+.2f}]" for r in values)+' |')
lines += ['', '| B0→B2 场景 | B0/B2 批量中位 ms | 实际操作数 | B0/B2 ns/操作 | 配对差中位 ms |', '|---|---:|---:|---:|---:|']
for r in costs:
    if r['comparison'] != 'b0-b2': continue
    key = 'resumes' if r['case'].endswith('event') or r['case']=='event-fanout' else 'script_calls'
    operations = r['pairs'][0]['baseline']['effective_work'][key]
    a,b = r['median_baseline_ns'], r['median_candidate_ns']
    lines.append(f"| {r['case']} | {a/1e6:.4f} / {b/1e6:.4f} | {operations:,} {key} | {a/operations:.3f} / {b/operations:.3f} | {r['median_delta_ns']/1e6:+.4f} |")
lines += ['', '| 冷期对照 | prepare ns | 7 项迟到 ns | 128 次 remount ns |', '|---|---:|---:|---:|']
cold = []
for comparison, directory in [('b0-b1',base/'sr3-closeout/b0-b1-probes'),('b1-b2',root/'b1-b2-probes'),('b0-b2',base/'sr3-c3-checks/probes')]:
    pairs=[]
    for i in range(5):
        record={}
        for variant in ('baseline','candidate'):
            raw=(directory/f'{variant}-{i}.csv.log').read_text().splitlines()
            at=next(n for n,line in enumerate(raw) if line.startswith('prepare_ns,'))
            row=dict(zip(raw[at].split(','),map(int,raw[at+1].split(','))))
            assert [row[k] for k in ('creates','destroys','prepares','releases')] == [152,152,456,456]
            record[variant]=row
        pairs.append(record)
    metrics={}
    for metric in ('prepare_ns','late_ns','remount_128_ns'):
        a=statistics.median(r['baseline'][metric] for r in pairs)
        b=statistics.median(r['candidate'][metric] for r in pairs)
        deltas=[100*(r['candidate'][metric]/r['baseline'][metric]-1) for r in pairs]
        metrics[metric]={'baseline_ns':a,'candidate_ns':b,'paired_percent':deltas,'median_percent':statistics.median(deltas)}
    cold.append({'comparison':comparison,'pairs':pairs,'metrics':metrics})
    lines.append('| '+comparison+' | '+' | '.join(f"{m['baseline_ns']:,.0f}→{m['candidate_ns']:,.0f} ({m['median_percent']:+.2f}%)" for m in metrics.values())+' |')
lines += ['', '| 单配置 128 次重建对照 | 配置/endpoint 数 | B0或B1/B1或B2 ns | 配对中位 % [min,max] |', '|---|---:|---:|---:|']
scales=[]
for comparison,directory in [('b0-b1',base/'sr3-closeout/b0-b1-scale'),('b1-b2',root/'b1-b2-scale'),('b0-b2',base/'sr3-c3-checks/scale')]:
    records=json.loads((directory/'runs.json').read_text())
    assert len(records)==24
    for count in (8,8192):
        variants={v:[r for r in records if r['variant']==v and r['configs']==count and not r['diagnostics']] for v in ('baseline','candidate')}
        a,b=variants['baseline'],variants['candidate']
        assert len(a)==len(b)==5
        assert all(r['errors']==0 and r['backlog']==0 and r['creates']==r['destroys']==count+144 and r['ticks']==count for r in a+b)
        deltas=[100*(y['elapsed_ns']/x['elapsed_ns']-1) for x,y in zip(a,b)]
        m1,m2=statistics.median(r['elapsed_ns'] for r in a),statistics.median(r['elapsed_ns'] for r in b)
        scales.append({'comparison':comparison,'configs':count,'baseline_ns':m1,'candidate_ns':m2,'paired_percent':deltas,'records':a+b})
        lines.append(f'| {comparison} | {count:,} | {m1:,} / {m2:,} | {statistics.median(deltas):+.2f} [{min(deltas):+.2f},{max(deltas):+.2f}] |')
(root/'diagnostics/cold-scale-results.json').write_text(json.dumps({'cold':cold,'scale':scales},indent=2))
(root/'performance-tables.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print('\n'.join(lines))
