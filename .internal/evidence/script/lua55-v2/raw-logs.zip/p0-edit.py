from pathlib import Path
import re

root = Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source')
def edit(name, fn):
    p = root / name
    old = p.read_text(encoding='utf-8-sig')
    new = fn(old)
    if new != old:
        p.write_text(new, encoding='utf-8', newline='\n')

def fold55(s):
    # Fold only VM-version conditionals. Preserve unrelated preprocessor scopes verbatim.
    output, stack = [], []
    def enabled(): return all(x[1] for x in stack if x[0])
    def condition(expr):
        if 'LUX_SCRIPT_LUA_VM_' in expr:
            return 'LUA55' in expr
        if 'LUA_VERSION_NUM' in expr and ('#if' in expr or '#elif' in expr):
            return not ('== 501' in expr)
        return None
    for line in s.splitlines(True):
        stripped = line.strip()
        if re.match(r'#\s*if(?:def|ndef)?\b', stripped):
            val = condition(stripped)
            stack.append([val is not None, val if val is not None else True, bool(val)])
            if val is None and enabled(): output.append(line)
        elif re.match(r'#\s*elif\b', stripped) and stack:
            item = stack[-1]
            if item[0]:
                val = condition(stripped)
                assert val is not None, stripped
                item[1] = not item[2] and val
                item[2] |= val
            elif enabled(): output.append(line)
        elif re.match(r'#\s*else\b', stripped) and stack:
            item = stack[-1]
            if item[0]: item[1] = not item[2]; item[2] = True
            elif enabled(): output.append(line)
        elif re.match(r'#\s*endif\b', stripped) and stack:
            item = stack.pop()
            if not item[0] and enabled(): output.append(line)
        elif enabled(): output.append(line)
    assert not stack
    return ''.join(output)

edit('CMakeLists.txt', lambda s: re.sub(r'set\(LUX_LUA_VM "LUA55".*?unset\(_lux_supported_lua_vms\)',
    'if(DEFINED LUX_LUA_VM)\n    message(FATAL_ERROR "LUX_LUA_VM was removed. Lux supports only Lua 5.5; remove the old selector.")\nendif()', s, flags=re.S))

name='modules/function/script/lua/CMakeLists.txt'
def cmake_lua(s):
    start=s.index('configure_file('); end=s.index('include(CheckCXXSourceCompiles)')
    s=s[:start]+'find_package(LuxLua55 5.5.1 EXACT CONFIG REQUIRED)\n\n'+s[end:]
    s=s.replace('lux::engine::function::script_lua_vm','LuxLua55::Runtime')
    start=s.index('if(LUX_LUA_VM STREQUAL'); end=s.index('set(_lux_lua_vm_probe')
    s=s[:start]+s[end:]
    s=s.replace('LUX_EXPECTED_LUA_VERSION','505')
    s=re.sub(r'    #if 505 == 505\n(.*?)    #endif\n',r'\1',s,flags=re.S)
    s=re.sub(r'        #if 505 == 501\n.*?        #else\n(.*?)        #endif\n',r'\1',s,flags=re.S)
    s=s.replace('LUX_SELECTED_LUA_VM_CAPABLE','LUX_LUA55_CAPABLE')
    s=s.replace('unset(_lux_expected_lua_version)\n','')
    s=s.replace("Selected Lua VM '${LUX_LUA_VM}'",'Lua 5.5.1')
    s=s.replace('        LUX_SCRIPT_LUA_VM_${LUX_LUA_VM}=1\n','')
    start=s.index('get_target_property(_lux_lua_vm_runtime'); end=s.index('component_add_cmake_scripts(')
    s=s[:start]+'''add_custom_command(TARGET script_lua POST_BUILD
    COMMAND ${CMAKE_COMMAND} -E copy_if_different
        "$<TARGET_FILE:LuxLua55::Runtime>" "$<TARGET_FILE_DIR:script_lua>"
    VERBATIM
)
install(FILES "$<TARGET_FILE:LuxLua55::Runtime>" DESTINATION bin COMPONENT lux_sdk)

component_add_transitive_commands(
    script_lua
    "find_package(LuxLua55 5.5.1 EXACT CONFIG REQUIRED)"
    "find_package(lux-cxx REQUIRED COMPONENTS compile_time)"
    "find_package(lux-engine-function REQUIRED COMPONENTS script_core)"
)

'''+s[end:]
    s=re.sub(r'install\(\n    FILES\n        \$\{CMAKE_CURRENT_BINARY_DIR\}/LuxLuaVmSelection.cmake.*?\n\)\n','',s,flags=re.S)
    return s
edit(name,cmake_lua)
(root/'modules/function/script/lua/cmake/LuxLuaVmSelection.cmake.in').unlink()
(root/'cmake/FindLuaJIT.cmake').unlink()

for folder in ['modules/function/script','engine','cmake/installed-consumers']:
    for p in (root/folder).rglob('*'):
        if not p.is_file() or p.suffix not in {'.cpp','.hpp','.h','.template','.txt','.cmake'}: continue
        if p.name=='CMakeLists.txt':
            edit(p.relative_to(root),lambda s:s.replace('lux::engine::function::script_lua_vm','LuxLua55::Runtime').replace('        LUX_SCRIPT_LUA_VM_${LUX_LUA_VM}=1\n',''))
        elif p.suffix in {'.cpp','.hpp','.h'}:
            if re.search(r'#\s*(?:if|elif).*?(?:LUX_SCRIPT_LUA_VM_|LUA_VERSION_NUM)',p.read_text(encoding='utf-8-sig')):
                edit(p.relative_to(root),fold55)

edit('modules/function/script/lua/include/lux/engine/function/script/lua/LuaVm.hpp',lambda s:re.sub(r'    enum class ELuaExecutionPolicy.*?    };\n\n','',s,flags=re.S).replace('        bool jit_available{};\n','').replace('        bool jit_enabled{};\n',''))
edit('modules/function/script/lua/src/LuaVm.cpp',lambda s:re.sub(r'        ELuaExecutionPolicy policy,\n','',s).replace('        const bool valid_policy = policy == ELuaExecutionPolicy::DEFAULT ||\n            policy == ELuaExecutionPolicy::INTERPRETER_ONLY;\n        if (state == nullptr || !valid_policy)\n            return false;\n','        if (state == nullptr) return false;\n').replace('{"Lua55", LUA_RELEASE, false, false}','{"Lua55", LUA_RELEASE}'))
edit('modules/function/script/lua/sinclude/lux/engine/function/script/lua/detail/LuaVmCompatibility.hpp',lambda s:s.replace('        ELuaExecutionPolicy policy,\n',''))
edit('engine/domain/simulation/scripting/lua/src/LuaScriptBackend.cpp',lambda s:s.replace('                    config.execution_policy,\n','').replace("// outside pcall; LuaJIT's allocating C closure is installed at the cold protected boundary.",'// outside pcall; thread allocation remains inside the protected boundary.'))
edit('engine/domain/simulation/scripting/lua/include/lux/engine/simulation/scripting/lua/LuaScriptBackend.hpp',lambda s:re.sub(r'        lux::script::lua::ELuaExecutionPolicy execution_policy\{.*?        };\n','',s,flags=re.S))

# Removed policy has no runtime error branch to test. Keep all capacity/business failures.
edit('engine/domain/simulation/scripting/lua/test/lua_backend_test.cpp',lambda s:re.sub(r'    const auto invalid_policy = .*?assert\(invalid_policy.error\(\) == .*?;\n','',s,flags=re.S))
for p in list((root/'engine').rglob('*.cpp')):
    s=p.read_text(encoding='utf-8-sig')
    if not any(x in s for x in ['ELuaExecutionPolicy','execution_policy','jit_enabled','lua_policy']): continue
    def policies(s):
        s=re.sub(r'    (?:    )?lux::script::lua::ELuaExecutionPolicy (?:g_execution_policy|policy|lua_policy)\{.*?};\n','',s,flags=re.S)
        s=re.sub(r'    const auto policy = argc > 1.*?ELuaExecutionPolicy::DEFAULT;\n','',s,flags=re.S)
        s=re.sub(r'    const bool interpreter_only = .*?;\n','',s)
        s=re.sub(r'        interpreter_only\n.*?ELuaExecutionPolicy::DEFAULT,\n','',s,flags=re.S)
        s=re.sub(r'            assert\(g_execution_policy.*?jit_enabled\);\n','',s,flags=re.S)
        s=re.sub(r'    assert\(.*?runtime.jit_(?:available|enabled).*?;\n','',s)
        s=re.sub(r'    if \(argc == 2 && std::string_view\{argv\[1\]} == "--interpreter-only"\)\n        (?:g_execution_policy|policy) = .*?;\n','',s)
        s=s.replace('        if (argument == "--interpreter-only")\n            g_execution_policy = lux::script::lua::ELuaExecutionPolicy::INTERPRETER_ONLY;\n        else if (argument == "--workers"','        if (argument == "--workers"')
        s=re.sub(r'            else if \(key == "--lua-policy"\)\n            \{.*?\n            }\n','',s,flags=re.S)
        s=re.sub(r'(?m)^\s*\.execution_policy = [^\n,]+,?\n','',s)
        s=re.sub(r'\.execution_policy = [\w.]+, ','',s)
        s=s.replace('lux::script::lua::ELuaExecutionPolicy execution_policy, ','')
        s=s.replace('std::size_t count,\n            lux::script::lua::ELuaExecutionPolicy execution_policy','std::size_t count')
        s=s.replace(', options.lua_policy','').replace('options.lua_policy, ','').replace('options->lua_policy, ','')
        s=s.replace('lua_vm,lua_version,jit_available,jit_enabled,scenario','lua_vm,lua_version,scenario')
        s=re.sub(r"                   << \(g_lua_runtime_info.jit_(?:available|enabled) \? 1 : 0\) << ','\n",'',s)
        return s
    edit(p.relative_to(root),policies)

for name in ['engine/domain/simulation/scripting/lua/CMakeLists.txt','engine/scene/integration/script/CMakeLists.txt']:
    def remove_duplicate(s):
        # Preserve workers=4 coverage under the sole runtime, then remove duplicate defaults.
        s=s.replace('scene_script_lua_runtime_interpreter_workers_4','scene_script_lua_runtime_workers_4').replace('--interpreter-only --workers 4','--workers 4')
        s=re.sub(r'(?m)^\s*add_test\(\s*NAME [^\s)]*interpreter[^\s)]*.*?\)\n','\n',s,flags=re.S)
        return s
    edit(name,remove_duplicate)

edit('modules/function/script/lua/src/LuaValue.cpp',lambda s:s.replace("// Lua 5.4's zero-upvalue C function is a light C function (no allocation).",'// A zero-upvalue C function does not allocate a closure.'))
edit('modules/function/script/lua/test/lua_value_test.cpp',lambda s:s.replace('including LuaJIT closure allocation','including allocation failure'))
