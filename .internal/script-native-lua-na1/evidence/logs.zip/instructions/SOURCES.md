# 来源与新设计边界

本包没有附带或重打包旧的全部原始证据。以下固定源码是设计依据；`NativeLuaTaskBackend`、同步step view、终止fail接口、测试fixture扩展均是本包提出的**新实现要求**，不是已有代码事实。未实际运行引擎。

## 固定仓库来源

- **[S1] V4 分支引用**。本次只读核对得到`f92853ea8361a7dc90ce0da072497d3722c29f88`。引用可能以后移动，实施前再读并以完整SHA固定。
  https://api.github.com/repos/LUX-YU/lux-engine/git/ref/heads/codex/s6-deep-optimization
- **[S2] A1 历史结果/合同**。用于继承明确的V4等待语义与吸取负实验教训，不将A1当基线。
  https://github.com/LUX-YU/lux-engine/blob/1039f2bcca44cff7bdfdb09f5c090db3647ae32a/.internal/script-cell-a1/RESULT.zh-CN.md
  https://github.com/LUX-YU/lux-engine/blob/1039f2bcca44cff7bdfdb09f5c090db3647ae32a/.internal/script-cell-a1/NOTES.zh-CN.md
- **[S3] Lua后端公开对象及配置**。
  https://github.com/LUX-YU/lux-engine/blob/f7d2815bdd2025ee23a7c11449def822413f58e9/engine/domain/simulation/scripting/lua/include/lux/engine/simulation/scripting/lua/LuaScriptBackend.hpp
- **[S4] Lua后端实际create/prepare/sync/resume实现**。
  https://github.com/LUX-YU/lux-engine/blob/f7d2815bdd2025ee23a7c11449def822413f58e9/engine/domain/simulation/scripting/lua/src/LuaScriptBackend.cpp
- **[S5] 当前后端上下文、descriptor与核心挂载**。
  https://github.com/LUX-YU/lux-engine/blob/f7d2815bdd2025ee23a7c11449def822413f58e9/engine/domain/simulation/scripting/core/include/lux/engine/simulation/scripting/ScriptBackend.hpp
  https://github.com/LUX-YU/lux-engine/blob/f7d2815bdd2025ee23a7c11449def822413f58e9/engine/domain/simulation/builtin/script/include/lux/engine/simulation/ScriptSystem.hpp
- **[S6] 原生C++ coroutine、promise、awaiter和frame接口**。特别注意void return和`unhandled_exception()`。
  https://github.com/LUX-YU/lux-engine/blob/f7d2815bdd2025ee23a7c11449def822413f58e9/engine/domain/simulation/scripting/cpp_static/include/lux/engine/simulation/scripting/cpp_static/ScriptCoroutine.hpp
- **[S7] CppStatic真正的后端、pool和outcome处理**。
  https://github.com/LUX-YU/lux-engine/blob/f7d2815bdd2025ee23a7c11449def822413f58e9/engine/domain/simulation/scripting/cpp_static/src/CppStaticScriptBridge.cpp
  https://github.com/LUX-YU/lux-engine/blob/f7d2815bdd2025ee23a7c11449def822413f58e9/engine/domain/simulation/scripting/cpp_static/include/lux/engine/simulation/scripting/cpp_static/CppStaticScriptBridge.hpp
- **[S8] 统一core continuation、step context、A/C与值协议**。
  https://github.com/LUX-YU/lux-engine/blob/f7d2815bdd2025ee23a7c11449def822413f58e9/engine/domain/simulation/scripting/core/include/lux/engine/simulation/scripting/ScriptRuntime.hpp
- **[S9] Lua值、protected callback和动态实际值检查**。
  https://github.com/LUX-YU/lux-engine/blob/f7d2815bdd2025ee23a7c11449def822413f58e9/modules/function/script/lua/src/LuaValue.cpp
  https://github.com/LUX-YU/lux-engine/blob/f7d2815bdd2025ee23a7c11449def822413f58e9/modules/function/script/lua/include/lux/engine/function/script/lua/LuaValue.hpp
  https://github.com/LUX-YU/lux-engine/blob/f7d2815bdd2025ee23a7c11449def822413f58e9/modules/function/script/lua/src/LuaBoundary.c
- **[S10] 原Lua benchmark业务函数**。
  https://github.com/LUX-YU/lux-engine/blob/f7d2815bdd2025ee23a7c11449def822413f58e9/engine/toolchain/lua/test/lua_runtime_benchmark_fixture.lua
- **[S11] CppStatic contract与真实导出支持集合**。
  https://github.com/LUX-YU/lux-engine/blob/f7d2815bdd2025ee23a7c11449def822413f58e9/engine/domain/simulation/scripting/cpp_static/include/lux/engine/simulation/scripting/cpp_static/CppStaticScriptContract.hpp

## 官方外部机制来源（非Lux性能数据）

- **[S12] Intel ITT API**：pause/resume和标记用于受控profile区间。实际采集参数按本机VTune版本验证。
  https://github.com/intel/ittapi/blob/master/include/ittnotify.h
- **[S13] Lua 5.5 Reference Manual**：Lua值/GC/错误/受保护调用/协程机制。它描述语言/API，不证明本轮实现安全或提速。
  https://www.lua.org/manual/5.5/manual.html
- **[S14] LLVM Coroutines**：编译器生成的持久frame、活跃值和恢复/销毁；不是可直接序列化的稳定任务wire。
  https://llvm.org/docs/Coroutines.html

所有依赖新版软件行为的实现要求，实施前仍应对匹配的实际头/库/工具版本核对。本包不使用外部引擎的ns数字来预测Lux的收益。
