"""Supplemental fixture variants against both frozen runtime images. Original tests remain unchanged."""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
r=Path(__file__).parent;source=r/'source';build=r.parent/'o/w/d';out=r/'additional-contracts';out.mkdir(exist_ok=False)
testroot=source/'engine/domain/simulation/builtin/script/test'
files={'event':'script_system_event_wait_test.cpp','timer':'script_system_continuation_test.cpp'}
traces={}
for kind,filename in files.items():
 original=testroot/filename;text=original.read_text()
 if kind=='event':
  begin=text.index('    void testCapacityFailure()');end=text.index('    void testAwaitableCapacityFailure()',begin)
  block=text[begin:end]
  before='options.limits = {8U, 1U, 2U, 2U, 2U, 1U, 64U, 1U, 2U, 2U, 1U, 2U};'
  assert block.count(before)==1
  block=block.replace(before,before.replace('2U, 2U, 2U, 1U','2U, 2U, 1U, 1U'))
  block=block.replace('        const auto stats = harness.system->stats();','        std::puts("A1_EXTRA both_full winner=WAITER_CAPACITY_EXCEEDED");\n        const auto stats = harness.system->stats();')
  text=text[:begin]+block+text[end:]
 else:
  at=text.index('int main(')
  extra=r'''
struct SameNameDelay final
{
    unsigned calls{};
    using C = lux::script::ScriptAbilityCompletion<void>;
    using R = lux::script::ScriptAbilityStartResult;
    R nextStep(C) noexcept { ++calls; return {}; }
    R seconds(double, C) noexcept { ++calls; return {}; }
    R simulationSeconds(double, C) noexcept { ++calls; return {}; }
    R realSeconds(double, C) noexcept { ++calls; return {}; }
};
void testSameNameDelayPublication()
{
    SameNameDelay provider;
    const auto binding = lux::script::bindScriptAbility<DelayAbility>(provider);
    const std::array published{publishScriptAbility(binding)};
    Harness harness{false};
    auto created = harness.create(limits(), published);
    assert(!created && created.error() == EScriptSystemError::SCRIPT_CAPABILITY_AMBIGUOUS_PROVIDER);
    assert(provider.calls == 0U && harness.backend_state.creates == 0U);
    std::puts("A1_EXTRA same_name_delay cold_rejected=AMBIGUOUS_PROVIDER provider=0 backend=0");
}
'''
  text=text[:at]+extra+text[at:]
  at=text.index('{',text.index('int main('))+1
  text=text[:at]+'\n    testSameNameDelayPublication();'+text[at:]
 def include(m):
  path=(original.parent/m[1]).resolve()
  return '#include "'+path.as_posix()+'"' if path.exists() else m[0]
 text=re.sub(r'#include "([^"]+)"',include,text)
 unit=out/filename;unit.write_text(text)
 name='simulation_script_event_wait_test' if kind=='event' else 'simulation_script_continuation_test'
 commands=subprocess.check_output(['ninja','-C',str(build),'-t','commands',name],text=True).splitlines()
 cc=next(x for x in commands if ('/c ' in x or '-c ' in x) and name+'.dir' in x and '.cpp' in x)
 ld=next(x for x in reversed(commands) if 'vs_link_exe' in x and '/out:bin\\'+name+'.exe' in x).split(' -- ',1)[1].split(' && ',1)[0]
 for side in ['A','B']:
  folder=out/(kind+'-'+side);folder.mkdir()
  image=(r.parent/'script-v4' if side=='A' else r)/'final-image'
  for p in image.glob('*.dll'):shutil.copy2(p,folder/p.name)
  inc=r/'contract-comparison/a-headers' if side=='A' else source/'engine/domain/simulation/builtin/script/include'
  obj=folder/'test.obj'
  command=cc.replace(' /nologo ',f' /nologo /I{inc} ',1)
  command=re.sub(r'/Fo\S+',lambda m:'/Fo'+str(obj),command)
  command=re.sub(r'/Fd\S+',lambda m:'/Fd'+str(folder/'test.pdb'),command)
  command,hits=re.subn(r' [-/]c .*$',lambda m:' /c '+str(unit),command)
  assert hits==1 and str(unit) in command
  link=re.sub(r'engine\\domain\\simulation\\builtin\\script\\CMakeFiles\\'+name+r'\.dir\\test\\\S+\.obj',lambda m:str(obj),ld)
  link=link.replace('/out:bin\\'+name+'.exe','/out:'+str(folder/'test.exe')).replace('/pdb:bin\\'+name+'.pdb','/pdb:'+str(folder/'test-link.pdb'))
  link=link.replace('/implib:lib\\'+name+'.lib','/implib:'+str(folder/'test.lib'))
  records=[]
  for stage,cmd in [('compile',['cmd','/d','/s','/c',command]),('link',['cmd','/d','/s','/c',link]),('run',[str(folder/'test.exe')])]:
   env=dict(os.environ);env['PATH']=str(folder)+';D:/Development/vcpkg/installed/x64-windows/bin;'+env['PATH']
   with (folder/(stage+'.log')).open('wb') as f:code=subprocess.call(cmd,cwd=build,stdout=f,stderr=subprocess.STDOUT,env=env)
   records.append({'stage':stage,'command':cmd,'exit':code})
   (folder/'identity.json').write_text(json.dumps({'fixture_sha256':hashlib.sha256(unit.read_bytes()).hexdigest(),
    'base_test_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'runtime_identity':str(image/'identity.json'),'commands':records},indent=2))
   if code:raise SystemExit(kind+' '+side+' '+stage+' failed')
  lines=[x for x in (folder/'run.log').read_text().splitlines() if x.startswith('A1_EXTRA')]
  assert lines
  traces[kind+'-'+side]=lines
  print(kind,side,lines,flush=True)
 assert traces[kind+'-A']==traces[kind+'-B']
(out/'result.json').write_text(json.dumps({'same_trace':True,'traces':traces},indent=2))
