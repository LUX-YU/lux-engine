from pathlib import Path
r=Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/lua55-v2');p=r/'installed-closure.ps1';s=p.read_text();marker='& "$r/consumers-closure.ps1"';idx=s.index(marker)
s=s[:idx]+'''$d='E:/SyncForder/CodeRepos/build/RelWithDebInfo/o/w/d'
& cmake -S $source -B $d -DLUX_LUA_VM=LuaJIT *> "$r/legacy-selector-rejected.log"
$rejected=$LASTEXITCODE
try {
    if($rejected -eq 0 -or !(Select-String -LiteralPath "$r/legacy-selector-rejected.log" -SimpleMatch 'LUX_LUA_VM was removed' -Quiet)) {
        throw 'Removed selector was not rejected by the actual root configuration'
    }
    @{source=(git -C $source rev-parse HEAD);exit=$rejected;expected='root fatal diagnostic';selector='LuaJIT'} |
        ConvertTo-Json | Set-Content "$r/legacy-selector-rejected.json"
} finally {
    & cmake -S $source -B $d -ULUX_LUA_VM *> "$r/legacy-selector-restore.log"
    if($LASTEXITCODE) { throw 'Restore configure failed' }
}
& cmake --build 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-lua55-s0-s1-20260909/dependencies/build-lua55' --target all -j 4 -- -k 0 *> "$r/vm-final-noop.log"
if($LASTEXITCODE -or !(Select-String -LiteralPath "$r/vm-final-noop.log" -SimpleMatch 'no work to do' -Quiet)) { throw 'VM build not idle' }
'''+s[idx:];p.write_text(s)
