from pathlib import Path
r=Path('E:/RenderV2Rebuild/Layer/source')
p=r/'modules/function/render/native/vulkan/test/DirectGraph.cpp';s=p.read_text().replace('auto* execution = take(session->prepare(graph, target, session->resources().root()));','auto scene = take(session->resources().createDomain(session->resources().root(), EResourceScope::SCENE));\n        auto view = take(session->resources().createDomain(scene, EResourceScope::VIEW));\n        auto* execution = take(session->prepare(graph, target, view));');p.write_text(s)
p=r/'modules/function/render/native/vulkan/src/Compile.cpp';s=p.read_text().replace('''            auto& resource = result.resources_[binding.resource.index];
            const auto* factory''','''            if (binding.resource.index >= result.resources_.size())
                return cxx::unexpected(RenderError{kInvalidArgument});
            auto& resource = result.resources_[binding.resource.index];
            if (resource.storage) return cxx::unexpected(RenderError{kInvalidArgument});
            const auto* factory''');p.write_text(s)
p=r/'modules/function/render/native/vulkan/test/Compiler.cpp';s=p.read_text();needle='            auto missing = programs;';s=s.replace(needle,'''            auto duplicate = programs;
            duplicate.push_back(programs.front());
            CHECK(!compileGraph(*session, assembly.definition, assembly.analysis, assembly.external_bindings,
                duplicate, native_fixture::target(config)));
            auto unknown = programs;
            unknown.front().pass_key = "unknown.pass";
            CHECK(!compileGraph(*session, assembly.definition, assembly.analysis, assembly.external_bindings,
                unknown, native_fixture::target(config)));
            auto bindings = assembly.external_bindings;
            bindings.front().resource.index = UINT32_MAX;
            CHECK(!compileGraph(*session, assembly.definition, assembly.analysis, bindings,
                programs, native_fixture::target(config)));
            bindings = assembly.external_bindings;
            bindings.push_back(bindings.front());
            CHECK(!compileGraph(*session, assembly.definition, assembly.analysis, bindings,
                programs, native_fixture::target(config)));
'''+needle);p.write_text(s)
p=r/'modules/function/render/runtime/test/Programs.cpp';s=p.read_text().replace('return ProgramContribution{std::move(values), {}};','return ProgramContribution{std::move(values), {{"test.argument", OwnedWireBytes::copyOf(\n        std::array{std::byte{1}})}}};').replace('    return ProgramContribution{};','    return ProgramContribution{{}, {{"test.argument", OwnedWireBytes::copyOf(\n        std::array{mode == 5 ? std::byte{2} : std::byte{1}})}}};');s=s.replace('    mode = 4;\n    take(client->submit(command));','    mode = 5;\n    auto conflict = call(*client, command);\n    check(conflict.header.outcome == ECommandOutcome::FAILED && conflict.header.error.type == kStorageMismatch);\n    check(server->stats().compiled_graphs == 2);\n    mode = 4;\n    take(client->submit(command));');p.write_text(s)
