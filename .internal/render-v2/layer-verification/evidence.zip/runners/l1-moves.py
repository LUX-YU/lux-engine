from pathlib import Path
r=Path('E:/RenderV2Rebuild/Layer/source'); base=r/'modules/function/render'
def edit(p,a,b):
 p=base/p;s=p.read_text();assert a in s,(p,a);p.write_text(s.replace(a,b))
def move(a,b):
 a=base/a;b=base/b;b.parent.mkdir(parents=True,exist_ok=True);a.rename(b)
move('features/include/lux/engine/render/features/Texture.hpp','resource/include/lux/engine/render/resource/Texture.hpp')
move('features/src/Texture.cpp','resource/src/Texture.cpp')
for p in base.rglob('*'):
 if p.is_file() and p.suffix in ('.hpp','.cpp','.txt','.cmake','.md','.py'):
  s=p.read_text();t=s.replace('lux/engine/render/features/Texture.hpp','lux/engine/render/resource/Texture.hpp')
  if s!=t:p.write_text(t)
edit('resource/include/lux/engine/render/resource/Texture.hpp','#include <lux/engine/render/features/Feature.hpp>','#include <lux/engine/render/resource/Storage.hpp>\n#include <lux/engine/render/protocol/Protocol.hpp>')
p=base/'resource/include/lux/engine/render/resource/Texture.hpp';s=p.read_text()
for cmd,value in [('SetTexture','TextureWrite'),('SetTextureRegion','TextureRegionWrite')]:
 start=s.index('        struct Request final',s.index('    struct '+cmd+' final'));end=s.index('        using Response',start)
 body=s[start:end].replace('        struct Request final','    struct '+value+' final',1)
 body='\n'.join(line[4:] if line.startswith('        ') else line for line in body.splitlines())+'\n\n'
 pos=s.index('    struct '+cmd+' final')
 s=s[:start]+'        using Request = '+value+';\n'+s[end:];s=s[:pos]+body+s[pos:]
p.write_text(s)
# Native storage consumes neutral values, not command envelopes.
for rel in ['native/vulkan/include/lux/engine/render/native/vulkan/texture/TextureStorage.hpp','native/vulkan/src/texture/TextureStorage.cpp','resource/src/Texture.cpp']:
 p=base/rel;p.write_text(p.read_text().replace('SetTextureRegion::Request','TextureRegionWrite').replace('SetTexture::Request','TextureWrite'))
p=base/'resource/include/lux/engine/render/resource/Factory.hpp';s=p.read_text();a=s.index('    // Cold declaration');b=s.index('    [[nodiscard]] RenderResult<void>',a);reg=s[a:b];s=s[:a]+s[b:];s=s.replace('    struct CommandHandler;\n\n','');p.write_text(s)
(base/'resource/include/lux/engine/render/resource/Registration.hpp').write_text('#pragma once\n\n#include <lux/engine/render/resource/Factory.hpp>\n#include <lux/engine/render/protocol/Protocol.hpp>\n\nnamespace lux::render\n{\n'+reg+'}\n')
for p in base.rglob('*'):
 if p.is_file() and p.suffix in ('.cpp','.hpp'):
  s=p.read_text()
  if ('StorageRegistration' in s or 'nativeStorageBinding' in s) and p.name not in ('Registration.hpp','Texture.hpp'):
   if '#include <lux/engine/render/resource/Factory.hpp>' in s:s=s.replace('#include <lux/engine/render/resource/Factory.hpp>','#include <lux/engine/render/resource/Registration.hpp>')
   elif '#include <lux/engine/render/resource/Registration.hpp>' not in s:s='#include <lux/engine/render/resource/Registration.hpp>\n'+s
   p.write_text(s)
edit('features/CMakeLists.txt','src/Assemble.cpp src/Texture.cpp','src/Assemble.cpp')
edit('resource/CMakeLists.txt','src/Storage.cpp src/ResourceRegistry.cpp','src/Storage.cpp src/ResourceRegistry.cpp src/Texture.cpp')
edit('resource/CMakeLists.txt','component_add_internal_dependencies(render_resource lux::engine::render::render_data)','component_add_internal_dependencies(render_resource\n    lux::engine::render::render_data\n    lux::engine::render::render_protocol\n)')
edit('protocol/CMakeLists.txt','lux::cxx::core STDEXEC::stdexec','lux::cxx::core')
edit('protocol/CMakeLists.txt','    "find_package(stdexec CONFIG REQUIRED)"\n','')
edit('protocol/CMakeLists.txt','if(BUILD_TESTING)','add_interface_component(\n    COMPONENT_NAME render_protocol_async\n    NAMESPACE lux::engine::render\n)\n\ncomponent_add_internal_dependencies(render_protocol_async lux::engine::render::render_protocol)\n\ntarget_link_libraries(render_protocol_async INTERFACE STDEXEC::stdexec)\n\ncomponent_add_transitive_commands(render_protocol_async "find_package(stdexec CONFIG REQUIRED)")\n\nif(BUILD_TESTING)')
edit('CMakeLists.txt','render_core render_data render_protocol render_resource','render_core render_data render_protocol render_protocol_async render_resource')
for rel in ['protocol/test/CMakeLists.txt','protocol/test/installed/CMakeLists.txt']:
 edit(rel,'lux::cxx::core STDEXEC::stdexec','lux::cxx::core')
edit('protocol/test/CMakeLists.txt','render_protocol_async_header PRIVATE render_protocol)','render_protocol_async_header PRIVATE render_protocol_async)')
edit('protocol/test/installed/CMakeLists.txt','find_package(lux-engine-render','set(CMAKE_DISABLE_FIND_PACKAGE_stdexec TRUE)\n\nfind_package(lux-engine-render')
edit('runtime/CMakeLists.txt','lux::engine::render::render_native_vulkan\n','lux::engine::render::render_native_vulkan lux::engine::render::render_protocol_async\n')
# Existing resource consumers use CPU scheduling, while synchronous Protocol/Client no longer pull stdexec.
