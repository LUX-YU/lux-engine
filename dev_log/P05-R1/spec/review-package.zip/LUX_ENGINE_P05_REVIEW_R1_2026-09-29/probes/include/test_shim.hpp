#pragma once
// ISOLATION HARNESS ONLY. Not a replacement Lux SDK and never intended for the repository.
// Copies the public value shapes used by the two unmodified .cpp files. Low-level Lux expected,
// CodeLease and identity dependencies are stand-ins; tests exercise coordinator/dispatch logic only.
#include <cstddef>
#include <cstdint>
#include <expected>
#include <memory>
#include <optional>
#include <stop_token>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>
namespace lux::cxx { using std::expected; using std::unexpected; }
namespace lux::asset { struct AssetId { std::uint64_t value{}; }; }
namespace lux::editor::contracts {
struct CodeLease {
 bool builtin_ = true; std::shared_ptr<const void> owner;
 static CodeLease builtin() { return {}; }
 bool valid() const { return builtin_ || bool(owner); }
};
}
namespace lux::editor::sessions {
struct SessionId { std::uint64_t store{},slot{},generation{};
 bool valid() const {return store && generation;}
 friend bool operator==(SessionId,SessionId)=default; };
struct HistoryId {std::uint64_t value{}; friend bool operator==(HistoryId,HistoryId)=default;};
struct StateId {HistoryId history;std::uint64_t serial{}; bool valid()const{return history.value && serial;}
 friend bool operator==(StateId,StateId)=default;};
struct ContentStamp {SessionId session;StateId state;friend bool operator==(ContentStamp,ContentStamp)=default;};
struct BindingRevision {std::uint64_t value{};friend bool operator==(BindingRevision,BindingRevision)=default;};
struct PublicationOrder {std::uint64_t value{};};
}
namespace lux::editor::persistence {
enum class EPersistenceError : std::uint8_t {
 INVALID_ARGUMENT,WRONG_THREAD,CAPACITY,UNKNOWN_ID,BUSY,UNBOUND,STALE_SOURCE,CANCELLED,ENCODE,
 DECODE,CONFLICT,IO,UNSUPPORTED_TARGET,REBIND_UNSUPPORTED,EXECUTION,NOT_TERMINAL,WRITER_ACTIVE};
struct PersistenceFailure {EPersistenceError code{EPersistenceError::INVALID_ARGUMENT};std::string detail;std::uint64_t native_code{};};
template<class T>using PersistenceResult=lux::cxx::expected<T,PersistenceFailure>;
struct WriteTargetKey{std::string value;friend bool operator==(const WriteTargetKey&,const WriteTargetKey&)=default;};
struct WriteTarget{WriteTargetKey key;std::string expected_version;friend bool operator==(const WriteTarget&,const WriteTarget&)=default;};
struct WriteTicket{std::uint64_t value{};friend bool operator==(WriteTicket,WriteTicket)=default;};
struct WriteOrigin{sessions::SessionId session;sessions::BindingRevision binding;friend bool operator==(WriteOrigin,WriteOrigin)=default;};
struct EncodedArtifact{std::vector<std::byte> bytes;};
enum class EDurability:std::uint8_t{FILE_FLUSHED,UNCONFIRMED};
struct CommitReceipt{std::string version;EDurability durability{EDurability::UNCONFIRMED};std::optional<PersistenceFailure>warning;};
struct NotPublished{PersistenceFailure failure;};
struct PublicationUnknown{PersistenceFailure failure;std::string token;};
using VPublicationOutcome=std::variant<CommitReceipt,NotPublished,PublicationUnknown>;
struct PublicationQuery{WriteTicket ticket;WriteTarget target;std::shared_ptr<const EncodedArtifact>artifact;std::string token;};
struct Reconciliation{bool writer_retired{};VPublicationOutcome outcome;};
class IArtifactStore{public:virtual ~IArtifactStore()=default;virtual PersistenceResult<WriteTarget>resolve(std::string_view)=0;
 virtual VPublicationOutcome publish(const PublicationQuery&,std::stop_token={})=0;
 virtual Reconciliation reconcile(const PublicationQuery&)=0;};
enum class EWriteStage:std::uint8_t{RESERVED,READY,PUBLISHING,UNKNOWN,TERMINAL};
struct WriteStatus{EWriteStage stage{EWriteStage::RESERVED};std::optional<VPublicationOutcome>outcome;};
struct WriteLimits{std::size_t tickets{128},artifact_bytes{256*1024*1024};};
class WriteCoordinator final{public:explicit WriteCoordinator(WriteLimits={});~WriteCoordinator();
 WriteCoordinator(const WriteCoordinator&)=delete;WriteCoordinator&operator=(const WriteCoordinator&)=delete;
 PersistenceResult<WriteTicket>reserve(WriteTarget,WriteOrigin);
 PersistenceResult<void>provideEncoded(WriteTicket,EncodedArtifact);
 PersistenceResult<void>cancelBeforePublish(WriteTicket,PersistenceFailure);
 PersistenceResult<std::optional<PublicationQuery>>takeReady();
 PersistenceResult<void>complete(WriteTicket,VPublicationOutcome);
 PersistenceResult<void>reconcile(WriteTicket,IArtifactStore&);
 PersistenceResult<WriteStatus>status(WriteTicket)const;PersistenceResult<void>acknowledge(WriteTicket);
 std::size_t size()const noexcept;private:struct Impl;std::unique_ptr<Impl>impl_;};
struct SaveId{std::uint64_t value{};friend bool operator==(SaveId,SaveId)=default;};
enum class ESaveMode:std::uint8_t{SAVE,SAVE_AS,EXPORT_COPY};
struct SaveRequest{sessions::SessionId session;ESaveMode mode{ESaveMode::SAVE};std::optional<WriteTarget>destination;asset::AssetId asset;};
enum class EAdoption:std::uint8_t{NONE,APPLIED,CLOSED,STALE_HISTORY,STALE_BINDING,OLDER_RECEIPT,BUSY};
enum class ESaveStage:std::uint8_t{CAPTURING,CAPTURED,ENCODING,READY,PUBLISHING,AWAITING_ADOPTION,TERMINAL};
enum class ECancelResult:std::uint8_t{REQUESTED,TOO_LATE,ALREADY_TERMINAL};
struct SaveOutcome{VPublicationOutcome publication;EAdoption adoption{EAdoption::NONE};};
struct SaveStatus{ESaveStage stage;sessions::ContentStamp content;WriteTicket ticket;std::optional<SaveOutcome>outcome;};
struct SaveLimits{std::size_t max_active_saves{32},snapshot_bytes{128*1024*1024},terminal_records{128};};
struct SaveSourceInfo{sessions::ContentStamp content;sessions::BindingRevision binding;std::optional<WriteTarget>target;};
struct SaveReceipt{sessions::ContentStamp content;sessions::BindingRevision binding;sessions::PublicationOrder order;WriteTarget target;CommitReceipt publication;};
class IEncodeJob{public:virtual ~IEncodeJob()=default;virtual PersistenceResult<EncodedArtifact>encode(std::stop_token)=0;};
struct OwnedEncodeJob final{
 contracts::CodeLease code{contracts::CodeLease::builtin()};std::unique_ptr<IEncodeJob>job;
 OwnedEncodeJob()=default;
 OwnedEncodeJob(contracts::CodeLease lease,std::unique_ptr<IEncodeJob>value)noexcept:code(std::move(lease)),job(std::move(value)){}
 OwnedEncodeJob(OwnedEncodeJob&&)noexcept=default;
 OwnedEncodeJob&operator=(OwnedEncodeJob&& other)noexcept{
 OwnedEncodeJob previous(std::move(other));using std::swap;swap(code,previous.code);swap(job,previous.job);return *this;}
 PersistenceResult<EncodedArtifact>encode(std::stop_token stop){return job->encode(stop);}
};
class IPreparedRebind{public:virtual ~IPreparedRebind()=default;virtual EAdoption apply(SaveReceipt&&)noexcept=0;};
struct FrozenSave final{
 SaveSourceInfo source;std::size_t retained_bytes{};OwnedEncodeJob encoding;std::unique_ptr<IPreparedRebind>rebind;
 FrozenSave()=default;
 FrozenSave(SaveSourceInfo info,std::size_t bytes,OwnedEncodeJob job,std::unique_ptr<IPreparedRebind>candidate)
 :source(std::move(info)),retained_bytes(bytes),encoding(std::move(job)),rebind(std::move(candidate)){}
 FrozenSave(FrozenSave&&)noexcept=default;
 FrozenSave&operator=(FrozenSave&& other)noexcept{
 FrozenSave previous(std::move(other));using std::swap;swap(source,previous.source);swap(retained_bytes,previous.retained_bytes);
 swap(encoding,previous.encoding);swap(rebind,previous.rebind);return *this;}
 ~FrozenSave(){encoding={};rebind.reset();}
};
struct EncodeWork{SaveId id;OwnedEncodeJob encoding;};
class ISaveSource{public:virtual ~ISaveSource()=default;
 virtual PersistenceResult<SaveSourceInfo>describe()const=0;
 virtual PersistenceResult<FrozenSave>captureForSave(const SaveSourceInfo&,const SaveRequest&,std::size_t)=0;
 virtual EAdoption accept(SaveReceipt&&)noexcept=0;};
class SaveService;
class SaveSourceRegistration final{public:~SaveSourceRegistration();SaveSourceRegistration(SaveSourceRegistration&&)noexcept;
 SaveSourceRegistration&operator=(SaveSourceRegistration&&)noexcept;
 SaveSourceRegistration(const SaveSourceRegistration&)=delete;SaveSourceRegistration&operator=(const SaveSourceRegistration&)=delete;
 private:friend class SaveService;struct State;explicit SaveSourceRegistration(std::shared_ptr<State>)noexcept;std::shared_ptr<State>state_;};
class SaveService final{public:explicit SaveService(WriteCoordinator&,SaveLimits={});~SaveService();
 SaveService(const SaveService&)=delete;SaveService&operator=(const SaveService&)=delete;
 PersistenceResult<SaveSourceRegistration>registerSource(ISaveSource&,contracts::CodeLease=contracts::CodeLease::builtin());
 PersistenceResult<SaveId>requestSave(SaveRequest);PersistenceResult<SaveStatus>status(SaveId)const;
 PersistenceResult<ECancelResult>requestCancel(SaveId);PersistenceResult<void>acknowledge(SaveId);
 PersistenceResult<std::optional<EncodeWork>>takeEncoding();PersistenceResult<void>completeEncoding(SaveId,PersistenceResult<EncodedArtifact>);
 void adoptCompletions();private:struct Impl;std::unique_ptr<Impl>impl_;};
}
