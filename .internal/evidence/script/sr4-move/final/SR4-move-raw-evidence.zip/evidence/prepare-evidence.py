import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).parent
SOURCE = ROOT / 'source'
BUILD = Path('E:/SyncForder/CodeRepos/build/RelWithDebInfo/m4')
OUTPUT = ROOT / 'evidence'
def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

qualification = read(BUILD / 'qualification.json')
qualification = [row for row in qualification if row['source_sha'] == 'cd7160ff47c8f8bf36a44f7fbbdeb813fabb018b']
assert len(qualification) == 2 and all(row['status'] == 'PASS' for row in qualification)
assert {row['source_sha'] for row in qualification} == {'cd7160ff47c8f8bf36a44f7fbbdeb813fabb018b'}
consumers = read(ROOT / 'consumers/consumers.json')
retry = read(ROOT / 'consumers-retry/consumers.json')
assert {row['consumer'] for row in retry} == {'lua-script-packager', 'script-authoring'} and len(retry) == 2
consumers = [row for row in consumers if row['consumer'] not in {'lua-script-packager', 'script-authoring'}] + retry
assert len(consumers) == 14 and all(row['status'] == 'PASS' and row['source_sha'] == qualification[0]['source_sha'] for row in consumers)
assert not subprocess.check_output(['git', '-C', str(ROOT / 'candidate-source'), 'status', '--porcelain'], text=True).strip()
OUTPUT.mkdir(exist_ok=False)
selected_suffixes = {'.log', '.json', '.csv', '.xml', '.cmake', '.py', '.ps1'}
for folder, label in [(ROOT / 'before', 'before'), (ROOT / 'candidate', 'invalid-long-path'),
                      (BUILD, 'qualification'), (ROOT / 'consumers', 'consumers'), (ROOT / 'consumers-retry', 'consumers-retry'), (ROOT / 'iteration-return-error', 'iteration-return-error')]:
    for path in folder.rglob('*'):
        if path.is_file() and (path.suffix in selected_suffixes or path.name in {'CMakeLists.txt', 'CMakeCache.txt', 'build.ninja', 'rules.ninja'}):
            target = OUTPUT / label / path.relative_to(folder)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target)
for name in ['start-identity.json', 'qualification-driver.log', 'qualification-long-path-invalid.log', 'qualification-return-error.log', 'candidate-clone.log', 'qualify.ps1', 'prepare-evidence.py', 'retry-lua-consumer.ps1', 'retry-lua-consumer.log']:
    shutil.copy2(ROOT / name, OUTPUT / name)
patch = subprocess.check_output(['git', '-C', str(SOURCE), 'diff', '22304336..cd7160ff', '--', 'engine'])
(OUTPUT / 'move-correction.patch').write_bytes(patch)
start = read(ROOT / 'start-identity.json')
main = Path('E:/SyncForder/CodeRepos/lux-engine')
assert subprocess.check_output(['git', '-C', str(main), 'rev-parse', 'HEAD'], text=True).strip() == start['main_head']
assert subprocess.check_output(['git', '-C', str(main), 'status', '--porcelain=v1'], text=True) == start['main_status']
for item in start['main_local_files']:
    assert digest(main / item['path']) == item['sha256']
for folder in ['lux-cxx-v3r', 'lux-cmake-toolset-s6-relocation']:
    path = main.parent / folder
    assert subprocess.check_output(['git', '-C', str(path), 'rev-parse', 'HEAD'], text=True).strip() == start[folder]['head']
    assert subprocess.check_output(['git', '-C', str(path), 'status', '--short'], text=True) == start[folder]['status']
(OUTPUT / 'preservation-check.json').write_text(json.dumps({'main_and_local_files_unchanged': True, 'dependencies_unchanged': True, 'start': start}, indent=2))
invalid = [
    {'trial': 'consumers/{lua-script-packager,script-authoring}/configure.log', 'reason': 'Toolchain prefix appeared before Developer and its simulation package intentionally excludes Lua. CMake does not union component lists across prefixes. Retried only these two consumers in fresh directories with candidate Developer first, same two candidate installs, no source change.'},
    {'trial': 'iteration-return-error', 'reason': 'New test expected INVALID_ID after whole runtime shutdown, but existing closed ingress protocol returns STOPPING. Both all builds and busy subprocess passed; lifecycle assertion corrected in test-only cd7160ff. No production protocol change.'},
    {'trial': 'before/compile-first-invalid.log', 'reason': 'Test used expected<optional<status>> as a direct status; compilation failed before any runtime execution; corrected by test-only commit 4fdb57e3'},
    {'trial': 'invalid-long-path/t/all.log', 'reason': 'MSVC C1083 compiler-generated file Invalid argument at long CppStatic generated object path; all build failed, no old binary used; fresh shorter build root m4 succeeds'},
    {'trial': 'invalid-long-path/qualification.json developer', 'reason': 'Blocked because failed Toolchain all had not generated cross-profile fixtures; not a separate runtime regression'}
]
(OUTPUT / 'invalid-trials.json').write_text(json.dumps(invalid, indent=2))
(OUTPUT / 'final-results.json').write_text(json.dumps({'qualification': qualification, 'consumers': consumers}, indent=2))
print('Evidence staged; candidate qualification PASS; main, local edits and fixed dependencies unchanged')
