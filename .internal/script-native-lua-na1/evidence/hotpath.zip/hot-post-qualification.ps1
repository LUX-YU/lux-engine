$ErrorActionPreference='Stop'
$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1'
foreach($slot in @('d','t')){if((Get-Content "$r/hot-final-$slot-tests2.json" -Raw|ConvertFrom-Json).exit){throw 'Qualification not green'}}
$vm='E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-lua55-s0-s1-20260909/dependencies/build-lua55'
if((Get-FileHash "$vm/lux_lua55.dll").Hash -ne (Get-FileHash 'E:/SyncForder/CodeRepos/install/o/v4/lua55/bin/lux_lua55.dll').Hash){throw 'Wrong VM test image'}
& ctest --test-dir $vm --output-on-failure -V -j 1 *> "$r/hot-vm-tests.log"
$vmCode=$LASTEXITCODE
@{exit=$vmCode;vm_dll=(Get-FileHash "$vm/lux_lua55.dll").Hash;source=(git -C "$r/opt-source" rev-parse HEAD);test_location=$vm}|ConvertTo-Json|Set-Content "$r/hot-vm-tests.json"
if($vmCode){throw 'VM contract failure'}

& "$r/hot-benchmark.ps1" -Side B -Label hot-final-common
& 'C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -B "$r/hot-save-images.py"
if($LASTEXITCODE){throw 'Image capture failed'}
& "$r/hot-installed.ps1"
& "$r/hot-new-incremental.ps1"
& "$r/hot-relocated.ps1" -Root $r
& 'C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -B "$r/hot-machine.py"
if($LASTEXITCODE){throw 'Machine capture failed'}
& "$r/hot-class-layout.ps1"
if($LASTEXITCODE){throw 'Layout capture failed'}
& 'C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -B "$r/hot-resources.py"
if($LASTEXITCODE){throw 'Resource capture failed'}
& 'C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -B "$r/hot-costs.py"
if($LASTEXITCODE){throw 'Cost runs failed'}
& 'C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -B "$r/hot-profile.py"
if($LASTEXITCODE){throw 'Profile failed'}
