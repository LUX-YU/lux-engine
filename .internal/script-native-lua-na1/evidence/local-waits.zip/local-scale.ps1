$ErrorActionPreference='Stop'
& 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
& 'C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -B "$PSScriptRoot/local-scale.py" --baseline-source "$PSScriptRoot/next-source" --candidate-source "$PSScriptRoot/local-source" --baseline-prefix 'E:/SyncForder/CodeRepos/install/o/na1/next-sdk' --candidate-prefix 'E:/SyncForder/CodeRepos/install/o/na1/local-sdk' --dependencies 'E:/SyncForder/CodeRepos/install/q2/c;E:/SyncForder/CodeRepos/install/q2/toolset' --output "$PSScriptRoot/local-scale"
if($LASTEXITCODE){throw 'Scale qualification failed'}
