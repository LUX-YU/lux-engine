$ErrorActionPreference='Stop'
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
$env:LUX_FLOWFORGE_LINKER=Join-Path $env:VCToolsInstallDir 'bin/Hostx64/x64/link.exe'
$base='E:/SyncForder/CodeRepos'
$root="$base/build/RelWithDebInfo/sr3-event"
$python='C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
foreach($v in @(@('sr3-c3','lux-engine-sr3-cost-final','b2-observed-counts','b2'),@('sr3-e','lux-engine-sr3-event','final-counts','b3'))) {
 & $python -B "$root/diagnostics/probe.py" --build "$base/build/RelWithDebInfo/$($v[0])/d" --source "$base/$($v[1])" --output "$root/diagnostics/$($v[2])" --executable "$root/observer-$($v[3])/build/script_event_observer.exe" *> "$root/diagnostics/$($v[2])-driver.log"
 if($LASTEXITCODE -ne 0) { throw 'Final branch accounting failed' }
}
foreach($script in @('machine.py','verify.py','tables.py')) {
 & $python -B "$root/diagnostics/$script" *> "$root/diagnostics/$script.log"
 if($LASTEXITCODE -ne 0) { throw "Final diagnostic failed: $script" }
}
& $python -B "$root/write-report.py"
if($LASTEXITCODE -ne 0) { throw 'Report failed' }
