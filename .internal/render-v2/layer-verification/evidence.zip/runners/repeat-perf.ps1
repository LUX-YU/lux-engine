$ErrorActionPreference='Stop'
$Output='E:/RenderV2Rebuild/Layer/evidence/L4/repeat'
$root='E:/RenderV2Rebuild/Layer/perf'
$manifest=Get-Content "$root/manifest.json" -Raw | ConvertFrom-Json
$env:Path="D:/Softwares/VulkanSDK/1.3.280.0/Bin;$env:Path"
New-Item -ItemType Directory -Force $Output | Out-Null
$runs=[System.Collections.Generic.List[object]]::new()
foreach($round in 0..7) {
    $order=if($round%2 -eq 0){@('baseline','layer')}else{@('layer','baseline')}
    foreach($variant in $order) {
        $build=($manifest | Where-Object variant -eq $variant).build
        foreach($test in 'native','alias') {
            $directory=Join-Path $Output "$round-$variant-$test"
            New-Item -ItemType Directory -Force $directory | Out-Null
            $exe=switch($test) {
                'command' {"$build/ipc/bin/render_runtime_operations_test.exe"}
                'native' {"$build/render/native/vulkan/test/render_execution_test.exe"}
                default {"$root/$variant/fixed.exe"}
            }
            if(-not (Test-Path $exe)) { throw "Missing $exe" }
            $arguments=if($test -eq 'alias'){@('alias')}else{@()}
            $start=Get-Date -AsUTC -Format o
            Push-Location $directory
            try { & $exe @arguments *> run.log; $code=$LASTEXITCODE } finally { Pop-Location }
            $runs.Add(@{round=$round;variant=$variant;test=$test;start=$start;end=(Get-Date -AsUTC -Format o);exit=$code;exe=$exe;exe_sha256=(Get-FileHash $exe).Hash})
            $runs | ConvertTo-Json -Depth 4 | Set-Content "$Output/runs.json"
            if($code -ne 0){ Get-Content "$directory/run.log" -Tail 15; exit $code }
            Write-Output "$round $variant $test EXIT=0"
        }
    }
}


