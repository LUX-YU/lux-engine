from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).parent;repo=r.parent/'script-cell-a1/source';qual=r.parent/'script-region-opt/final-source'
start=json.loads((r/'start.json').read_text());main=Path('E:/SyncForder/CodeRepos/lux-engine')
def git(path,*args):return subprocess.check_output(['git','-C',str(path),*args],text=True).rstrip('\r\n')
def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
expected=json.loads((r/'final2-d-build.json').read_text(encoding='utf-8-sig'))['source']
assert git(qual,'rev-parse','HEAD')==expected and not git(qual,'status','--porcelain')
assert git(main,'rev-parse','HEAD')==start['main_head']
assert git(main,'status','--porcelain')==start['main_status']
for path,digest in start['protected'].items():assert sha(main/path)==digest,path
for group,data in start['images'].items():
 for name,entry in data['images'].items():assert sha(r.parent/'script-v4'/group/name)==entry['sha256'],name
deps=json.loads((r/'fixed-dependencies.json').read_text())
for entry in deps['files']:assert sha(entry['path'])==entry['sha256'],entry['path']
assert git(repo,'rev-parse','codex/s6-deep-optimization')=='f92853ea8361a7dc90ce0da072497d3722c29f88'
assert git(repo,'rev-parse','codex/s6-execution-cell-a1')=='1039f2bcca44cff7bdfdb09f5c090db3647ae32a'
changed=git(repo,'diff','--name-only','f7d2815b',expected).splitlines()
production=[p for p in changed if p.startswith(('engine/','modules/','cmake/')) and '/test/' not in p]
assert set(production)=={
 'engine/domain/simulation/scripting/native/src/NativeScriptBackend.cpp',
 'engine/domain/simulation/scripting/core/include/lux/engine/simulation/scripting/detail/BoundedClassStorage.hpp'}
sdk=Path('E:/SyncForder/CodeRepos/install/o/v4-h1/sdk')
header='lux/engine/simulation/scripting/detail/BoundedClassStorage.hpp'
original=qual/'engine/domain/simulation/scripting/core/include'/header
assert (sdk/'include'/header).read_bytes()==original.read_bytes()
runtime='lux/engine/simulation/scripting/ScriptRuntime.hpp'
assert (sdk/'include'/runtime).read_bytes()==(qual/'engine/domain/simulation/scripting/core/include'/runtime).read_bytes()
for name in ['ScriptExecution.hpp','ScriptInstances.hpp','ScriptBindings.hpp','ScriptTimers.hpp','ScriptCompletionIngress.hpp']:
 assert not list((sdk/'include').rglob(name)),name
artifacts={}
for group in ['final-image','final-flow-image','final2-image','final2-flow-image']:
 artifacts[group]={p.name:dict(sha256=sha(p),bytes=p.stat().st_size) for p in (r/group).iterdir()
    if p.suffix.lower() in ['.exe','.dll','.pdb','.lxsa']}
records=dict(source=expected,qualifier_clean=True,main_head=start['main_head'],main_status=start['main_status'],
 protected_files=start['protected'],dependencies_verified=len(deps['files']),baseline_images_verified=True,
 preserved_v4='f92853ea8361a7dc90ce0da072497d3722c29f88',preserved_a1='1039f2bcca44cff7bdfdb09f5c090db3647ae32a',
 production_changes=production,sdk_headers_match=True,private_headers_absent=True,artifacts=artifacts)
(r/'final-audit.json').write_text(json.dumps(records,indent=2))
print('FINAL_IDENTITY_AUDIT_PASS',expected,len(deps['files']),len(start['protected']))
