import hashlib,json,os,subprocess,shutil
from pathlib import Path
base=Path('E:/SyncForder/CodeRepos');root=base/'build/RelWithDebInfo/sr4';out=root/'diagnostics/timer-source-proof-final'
out.mkdir(parents=True,exist_ok=False)
exe=out/'simulation_script_continuation_test.exe'
shutil.copy2(root/'candidate/d/bin'/exe.name,exe)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
records=[]
for variant,prefix in [('e0',base/'install/sr3-e/d'),('e1',base/'install/sr4-candidate/d')]:
 env=dict(os.environ);clean=[v for v in env['PATH'].split(';') if 'CodeRepos' not in v and 'vcpkg' not in v]
 env['PATH']=';'.join([str(prefix/'bin'),'D:/Development/vcpkg/installed/x64-windows/bin',str(base/'install/q2/c/bin'),str(base/'install/RelWithDebInfo/bin')]+clean)
 with (out/(variant+'.log')).open('w') as log:r=subprocess.run([str(exe)],env=env,stdout=log,stderr=subprocess.STDOUT)
 text=(out/(variant+'.log')).read_text();valid=(r.returncode==0) if variant=='e1' else (r.returncode!=0 and 'waits() == 1U && system.activeAwaitableCount() == 1U' in text)
 records.append(dict(variant=variant,prefix=str(prefix),exit=r.returncode,expected_result=valid,dll_sha256=digest(prefix/'bin/lux_engine_simulation_script.dll')))
 assert valid,records[-1]
(out/'identity.json').write_text(json.dumps(dict(executable=str(exe),sha256=digest(exe),test_source_sha256=digest(base/'lux-engine-sr4-candidate/engine/domain/simulation/builtin/script/test/script_system_continuation_test.cpp'),runs=records),indent=2))
