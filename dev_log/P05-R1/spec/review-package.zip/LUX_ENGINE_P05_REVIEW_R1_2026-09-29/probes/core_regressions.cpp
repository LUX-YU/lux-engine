#include <test_shim.hpp>
#include <cassert>
#include <functional>
#include <iostream>
#include <map>
using namespace lux::editor;
using namespace lux::editor::persistence;
EncodedArtifact artifact(const std::string& s){EncodedArtifact a;for(char c:s)a.bytes.push_back(std::byte(c));return a;}
std::string text(const EncodedArtifact& a){return {reinterpret_cast<const char*>(a.bytes.data()),a.bytes.size()};}
struct Job final:IEncodeJob{std::string s;explicit Job(std::string x):s(std::move(x)){}
 PersistenceResult<EncodedArtifact>encode(std::stop_token)override{return artifact(s);}};
struct Source final:ISaveSource{
 SaveSourceInfo info{{{1,0,1},{{1},1}},{1},WriteTarget{{"document"},"V0"}};
 std::string payload="V1"; std::function<void()>onDescribe,onAccept;int acceptCalls{};
 PersistenceResult<SaveSourceInfo>describe()const override{if(onDescribe)onDescribe();return info;}
 PersistenceResult<FrozenSave>captureForSave(const SaveSourceInfo&i,const SaveRequest&,std::size_t)override{
 return FrozenSave{i,16,{contracts::CodeLease::builtin(),std::make_unique<Job>(payload)},{}};}
 EAdoption accept(SaveReceipt&&r)noexcept override{++acceptCalls;if(onAccept)onAccept();info.target->expected_version=r.publication.version;return EAdoption::APPLIED;}
};
struct Disk final:IArtifactStore{
 std::string version="V0";int conflicts{};
 PersistenceResult<WriteTarget>resolve(std::string_view address)override{return WriteTarget{{std::string(address)},version};}
 VPublicationOutcome publish(const PublicationQuery&w,std::stop_token)override{
 if(w.target.expected_version!=version){++conflicts;std::cout<<"CONFLICT expected="<<w.target.expected_version<<" actual="<<version<<std::endl;return NotPublished{{EPersistenceError::CONFLICT}};}
 version=text(*w.artifact);std::cout<<"published "<<version<<" ticket="<<w.ticket.value<<std::endl;return CommitReceipt{version,EDurability::FILE_FLUSHED};}
 Reconciliation reconcile(const PublicationQuery&)override{return {true,NotPublished{{EPersistenceError::IO}}};}
};
void encode(SaveService&s){while(true){auto w=s.takeEncoding();assert(w);if(!*w)break;assert(s.completeEncoding((**w).id,(**w).encoding.encode({})));}}
void publish(WriteCoordinator&w,Disk&d){while(true){auto p=w.takeReady();assert(p);if(!*p)break;assert(w.complete((**p).ticket,d.publish(**p,{})));}}
SaveId save(SaveService&s,Source&src,const char*v){src.payload=v;++src.info.content.state.serial;auto r=s.requestSave({src.info.content.session});assert(r);return *r;}
void chain(bool acknowledge){
 WriteCoordinator writes;SaveService saves(writes);Source source;Disk disk;auto reg=saves.registerSource(source);assert(reg);
 const auto w1=save(saves,source,"V1");encode(saves);publish(writes,disk);saves.adoptCompletions();assert(source.info.target->expected_version=="V1");
 save(saves,source,"V2");save(saves,source,"V3");encode(saves);publish(writes,disk); // Physical completions, no baseline adoption yet.
 assert(disk.version=="V3");assert(source.info.target->expected_version=="V1");
 if(acknowledge)assert(saves.acknowledge(w1)); // A terminal, already-adopted W1 only.
 const auto w4=save(saves,source,"V4");encode(saves);publish(writes,disk);saves.adoptCompletions();
 auto status=saves.status(w4);assert(status&&status->outcome);
 const bool ok=std::holds_alternative<CommitReceipt>(status->outcome->publication);
 std::cout<<"ack_first="<<acknowledge<<" fourth_published="<<ok<<" final="<<disk.version<<" conflicts="<<disk.conflicts<<std::endl;
 // Target contract: acknowledgement must not invalidate legitimate same-source chaining.
 if(!ok||disk.version!="V4")std::exit(10);
}
void revoke(){WriteCoordinator writes;SaveService saves(writes);Source source;
 std::optional<SaveSourceRegistration>reg;auto r=saves.registerSource(source);assert(r);reg.emplace(std::move(*r));
 source.onDescribe=[&]{reg.reset();std::cout<<"registration_revoked_inside_describe=1 source_still_alive=1"<<std::endl;};
 auto saved=saves.requestSave({source.info.content.session});
 std::cout<<"request_returned="<<bool(saved)<<std::endl;
 if(saved||saved.error().code!=EPersistenceError::STALE_SOURCE)std::exit(11);
}
void recursive(){WriteCoordinator writes;SaveService saves(writes);Source source;Disk disk;auto reg=saves.registerSource(source);assert(reg);
 auto id=save(saves,source,"V1");encode(saves);publish(writes,disk);bool nested{};
 source.onAccept=[&]{if(nested)return;nested=true;saves.adoptCompletions();
 auto ack=saves.acknowledge(id);std::cout<<"nested_accept_calls="<<source.acceptCalls<<" acknowledged_inside_accept="<<bool(ack)<<std::endl;};
 saves.adoptCompletions();std::cout<<"returned safely accept_calls="<<source.acceptCalls<<std::endl;
 if(source.acceptCalls!=1)std::exit(12);
}
int main(int argc,char**argv){assert(argc==2);std::string mode=argv[1];if(mode=="chain-control")chain(false);else if(mode=="chain-ack")chain(true);else if(mode=="revoke")revoke();else if(mode=="recursive-adoption")recursive();else return 2;}
