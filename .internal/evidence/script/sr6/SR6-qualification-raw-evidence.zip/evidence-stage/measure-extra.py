import csv,ctypes,hashlib,json,os,subprocess
from pathlib import Path
r=Path(__file__).resolve().parent
root=r/'extra-costs';root.mkdir(exist_ok=False)
variants={'E':r.parent/'s5c/q/d/bin','F':r/'q/d/bin'}
records=[]
class Counters(ctypes.Structure):
    _fields_=[('cb',ctypes.c_ulong),('PageFaultCount',ctypes.c_ulong)]+[(name,ctypes.c_size_t) for name in
      ('PeakWorkingSetSize','WorkingSetSize','QuotaPeakPagedPoolUsage','QuotaPagedPoolUsage',
       'QuotaPeakNonPagedPoolUsage','QuotaNonPagedPoolUsage','PagefileUsage','PeakPagefileUsage')]
get_memory=ctypes.WinDLL('psapi').GetProcessMemoryInfo
get_memory.argtypes=[ctypes.c_void_p,ctypes.POINTER(Counters),ctypes.c_ulong]
get_memory.restype=ctypes.c_int
for name,group,size,frames,warmup,workers in [('sequence','scene-cpp-sequence',10000,200,16,0),
                                           ('regions','scene-region-numeric',65536,256,16,2)]:
 for pair in range(5):
  for side in (('E','F') if pair%2==0 else ('F','E')):
   folder=variants[side];exe=folder/'script_runtime_benchmark.exe';stem=f'{name}-{side}-{pair}'
   args=[str(exe),'--group',group,'--mode','performance','--size',str(size),'--frames',str(frames),
         '--warmups',str(warmup),'--workers',str(workers),'--resume-budget','2000','--seed','1592598566',
         '--output',str(root/(stem+'.csv'))]
   env=dict(os.environ)
   env['PATH']=';'.join([str(folder),'D:/Development/vcpkg/installed/x64-windows/bin']+
                       [p for p in env['PATH'].split(';') if 'CodeRepos' not in p and 'vcpkg' not in p])
   with (root/(stem+'.log')).open('wb') as log:
    process=subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT)
    code=process.wait(timeout=180)
    memory=Counters();memory.cb=ctypes.sizeof(memory)
    available=bool(get_memory(int(process._handle),ctypes.byref(memory),ctypes.sizeof(memory)))
   row={'case':name,'pair':pair,'side':side,'arguments':args,'exit':code,
        'exe_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),
        'memory_scope':'whole child process including VM/DLL/loader; queried after exit, not arena or live instance size',
        'peak_working_set':memory.PeakWorkingSetSize if available else None,
        'peak_pagefile_usage':memory.PeakPagefileUsage if available else None}
   records.append(row);(root/'runs.json').write_text(json.dumps(records,indent=2))
   assert code==0,row
   rows=list(csv.DictReader((root/(stem+'.csv')).open()))
   assert rows and all(v['build_type']=='RelWithDebInfo' for v in rows)
   if name=='sequence':
    last=rows[-1];assert last['scenario'].endswith('-drain')
    assert int(last['queue_depth'])==int(last['awaitables'])==int(last['continuations'])==0
    assert int(last['calls'])==int(last['ability_calls'])>0
    assert int(last['resumes'])==3*int(last['calls'])
   else:
    timed=[v for v in rows if v['scenario']=='scene-region-numeric']
    assert len(timed)==256 and all(int(v['calls'])==2 and int(v['workers'])==2 for v in timed)
   print(stem,'PASS',flush=True)
