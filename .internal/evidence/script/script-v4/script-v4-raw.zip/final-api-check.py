from pathlib import Path
import json,os,subprocess,shutil,time,hashlib,struct
r=Path(__file__).parent;image=r/'final-api-image';image.mkdir(exist_ok=True)
assert not (image/'identity.json').exists(), 'Completed API image already exists'
helper=(r/'save-w1.py').read_text();exec(helper[helper.index('def sha('):helper.index('queue=')])
source=json.loads((r/'final-d-build.json').read_text(encoding='utf-8-sig'))['source']
names=['simulation_script_lua_value_boundary_test.exe','simulation_script_lua_value_runtime_test.exe',
 'script_lua_page_allocator_test.exe','simulation_script_lua_vm_coroutine_contract_test.exe']
queue=list(names);saved={};external=[]
roots=[r.parent/'o/w/d/bin',Path('D:/Development/vcpkg/installed/x64-windows/bin')]
api=Path('E:/SyncForder/CodeRepos/install/o/v4/api-lua55')
while queue:
 name=queue.pop()
 if name.lower() in saved:continue
 p=api/'bin/lux_lua55.dll' if name.lower()=='lux_lua55.dll' else next((root/name for root in roots if (root/name).exists()),None)
 if not p:external.append(name);continue
 shutil.copy2(p,image/name);saved[name.lower()]={'origin':str(p),'sha256':sha(p)}
 queue+=imports(p)
(image/'identity.json').write_text(json.dumps(dict(engine_source=source,
 api_vm=json.loads((api/'share/LuxLua55/identity.json').read_text()),
 images=saved,system_imports=external),indent=2))
env=dict(os.environ);env['PATH']=';'.join([str(image),'D:/Development/vcpkg/installed/x64-windows/bin',*[p for p in env['PATH'].split(';') if 'CodeRepos' not in p and 'vcpkg' not in p]])
runs=[]
for name,args in [(names[0],['--deep-stack']),*( (n,[]) for n in names)]:
 label=Path(name).stem+('-deep' if args else '')
 cmd=[str(image/name),*args];start=time.monotonic()
 with (r/f'final-api-{label}.log').open('wb') as f:code=subprocess.call(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 runs.append(dict(command=cmd,exit=code,seconds=time.monotonic()-start,source=source))
 (r/'final-api-runs.json').write_text(json.dumps(runs,indent=2))
 print(label,code,flush=True)
 if code:raise SystemExit(code)
