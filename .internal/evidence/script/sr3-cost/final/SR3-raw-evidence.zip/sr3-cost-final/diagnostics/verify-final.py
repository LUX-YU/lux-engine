import hashlib, json, re, subprocess
from pathlib import Path

base = Path('E:/SyncForder/CodeRepos')
root = base / 'build/RelWithDebInfo/sr3-cost-final/diagnostics'
results = {'qualification': {}, 'assertion_build_flags': [], 'preserved_evidence': {}, 'sources': []}
for profile, expected in [('t', (107, 0)), ('d', (119, 6))]:
    build = base / f'build/RelWithDebInfo/sr3-c3/{profile}'
    summary = (build / 'ctest.log').read_text()
    assert f'{expected[1]} tests failed out of {expected[0]}' in summary
    trace = (build / 'Testing/Temporary/LastTest.log').read_text()
    points = re.findall(r'^REENTRY_OK,(.*)$', trace, re.M)
    assert len(points) == 8 and [int(p.split(',')[0]) for p in points] == [1,2,3,4,5,6,7,3]
    assert trace.count('INVOCATION_AUTHORITY_OK,') == 1 and trace.count('BINDINGS_OK,') == 1
    results['qualification'][profile] = {'tests': expected[0], 'failed': expected[1], 'reentry_records': points}
    db = json.loads((build / 'compile_commands.json').read_text())
    for item in db:
        if item['file'].endswith(('/script_system_lifecycle_test.cpp', '/script_bindings_test.cpp', '/script_system_event_wait_test.cpp')):
            assert '/UNDEBUG' in item['command']
            results['assertion_build_flags'].append(item)
    if profile == 'd':
        failed = re.findall(r'\d+:([^\n]+)', (build / 'Testing/Temporary/LastTestsFailed.log').read_text())
        assert len(failed) == 6 and all('scene_script_lua_runtime' in f for f in failed)
        results['qualification'][profile]['historical_failures'] = failed
        for name in ('sr3-reference', 'sr3-final'):
            old = (base / f'build/RelWithDebInfo/{name}/d/Testing/Temporary/LastTestsFailed.log').read_text()
            assert sorted(re.findall(r'\d+:([^\n]+)', old)) == sorted(failed)
for label, source in [('B0', 'lux-engine-sr3-reference'), ('B1', 'lux-engine-sr3-final'), ('B2', 'lux-engine-sr3-cost-final'), ('cxx', 'lux-cxx-v3r')]:
    path = base / source
    sha = subprocess.check_output(['git', '-C', str(path), 'rev-parse', 'HEAD'], text=True).strip()
    state = subprocess.check_output(['git', '-C', str(path), 'status', '--porcelain'], text=True).strip()
    assert not state
    results['sources'].append({'label': label, 'path': str(path), 'commit': sha, 'status': state})
repo = base / 'lux-engine-deep-optimization'
old = subprocess.check_output(['git', '-C', str(repo), 'ls-tree', '-r', '4297022c97bfefa6aa53af942d429687ee19228e', '--', '.internal/evidence/script'], text=True)
new = subprocess.check_output(['git', '-C', str(repo), 'ls-tree', '-r', 'HEAD', '--', '.internal/evidence/script'], text=True)
assert old == new
results['preserved_evidence'] = {'tree_entries': len(old.splitlines()), 'all_original_blob_ids_equal': True, 'before': '4297022c97bfefa6aa53af942d429687ee19228e', 'after': '99c1d095fad6a728c3d808ff2d853ce84b59bfea'}
(root / 'verification.json').write_text(json.dumps(results, indent=2))
print('Qualified assertions, exact six historical failures, clean sources and original evidence blobs verified.')
