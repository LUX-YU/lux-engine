from pathlib import Path
s=Path(r'E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1/source')
p=s/'engine/domain/simulation/scripting/core/include/lux/engine/simulation/scripting/ScriptSyncStep.hpp'
t=p.read_text();pos=t.index('        ScriptInstanceId instance;',t.index('    struct ScriptSyncStepSetView'))
t=t[:pos]+'''        ScriptSyncStepSetView() noexcept = default;
        ScriptSyncStepSetView(ScriptInstanceId identity, std::uint64_t epoch, ScriptBehavior* host,
            std::span<const PreparedScriptSyncStep> entries, const void* context,
            bool (*check)(const void*, ScriptInstanceId, std::uint64_t) noexcept) noexcept
            : instance(identity), publication(epoch), behavior(host), steps(entries), owner(context), current(check) {}
        ScriptSyncStepSetView(const ScriptSyncStepSetView& other) noexcept
            : ScriptSyncStepSetView(other.instance, other.publication, other.behavior, other.steps,
                other.owner, other.current) {}
        ScriptSyncStepSetView& operator=(const ScriptSyncStepSetView& other) noexcept
        {
            if (this != &other)
            {
                instance = other.instance;
                publication = other.publication;
                behavior = other.behavior;
                steps = other.steps;
                owner = other.owner;
                current = other.current;
                instance_owned_ = false;
            }
            return *this;
        }
        [[nodiscard]] bool hasInstanceLifetime() const noexcept { return instance_owned_; }
'''+t[pos:]
pos=t.index('        bool (*current)(const void*, ScriptInstanceId, std::uint64_t) noexcept{};')+len('        bool (*current)(const void*, ScriptInstanceId, std::uint64_t) noexcept{};')
t=t[:pos]+'''
    private:
        // Only the engine's owning composition may establish this lifetime. A
        // copied/public producer view is checked, even when copied from this view.
        friend class detail::ScriptRuntimeAccess;
        bool instance_owned_{};'''+t[pos:]
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/scripting/core/sinclude/lux/engine/simulation/scripting/ScriptRuntimeAccess.hpp'
t=p.read_text().replace('    public:\n','''    public:
        static void bindSyncStepLifetime(ScriptSyncStepSetView& view) noexcept
        {
            view.instance_owned_ = true;
        }
''',1);p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/scripting/native_lua_tasks/src/NativeLuaTaskBackend.cpp'
t=p.read_text().replace('#include <algorithm>', '#include <lux/engine/simulation/scripting/ScriptRuntimeAccess.hpp>\n\n#include <algorithm>')
t=t.replace('                              &current};\n', '                              &current};\n        detail::ScriptRuntimeAccess::bindSyncStepLifetime(instance.step_view);\n')
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/scripting/cpp_static/include/lux/engine/simulation/scripting/cpp_static/ScriptCoroutine.hpp'
t=p.read_text().replace('return lux::cxx::unexpected(entry.error());','return lux::cxx::unexpected<ScriptSyncStepError>(entry.error());')
t=t.replace(': sync_steps_(sync_steps),', ': sync_steps_(sync_steps), sync_publication_(sync_steps ? sync_steps->publication : 0U),')
t=t.replace('        const ScriptSyncStepSetView* sync_steps_{};\n', '        const ScriptSyncStepSetView* sync_steps_{};\n        std::uint64_t sync_publication_{};\n')
p.write_text(t,encoding='utf-8')
p=s/'engine/domain/simulation/scripting/cpp_static/src/CppStaticScriptBridge.cpp'
t=p.read_text().replace('!view->current || view->publication == 0U;', '!view->current;')
a=t.index('        // Publication is not live while');b=t.index('        auto &descriptor',a);t=t[:a]+t[b:]
pos=t.index('    // No user code between capture',t.index('ScriptCoroutineContext::invokeResolvedSyncStep'))
t=t[:pos]+'''    const auto* view = sync_steps_;
    const auto identity = active_step_->instance;
    const bool checked_publication = !view->hasInstanceLifetime();
    if (checked_publication)
    {
        const bool invalid = view->instance != identity || view->publication != sync_publication_ ||
            !view->current(view->owner, identity, sync_publication_);
        if (invalid) return error(EScriptSyncStepError::INVALID_CONTEXT, -32001);
    }
'''+t[pos:]
t=t.replace('    if (!qualification.valid()) return error(EScriptSyncStepError::INVOCATION_REVOKED, -32004);','''    if ((checked_publication && !view->current(view->owner, identity, sync_publication_)) || !qualification.valid())
        return error(EScriptSyncStepError::INVOCATION_REVOKED, -32004);''')
p.write_text(t,encoding='utf-8')
p=s/'cmake/installed-consumers/native-task-lua-steps/ConsumerBehavior.hpp'
t=p.read_text().replace('        const auto payload = co_await context.wait(*pulse_event);', '''        auto step = context.bindStep<std::int32_t(std::int32_t)>(0U);
        if (!step) co_await context.fail(step.error());
        const auto payload = co_await context.wait(*pulse_event);''').replace('context.callStep<std::int32_t(std::int32_t)>(0U, payload)', '(*step)(payload)')
p.write_text(t,encoding='utf-8')
