from pathlib import Path
import hashlib,json
r=Path(__file__).parent
records={}
for group in ['native-cold','native-boundary','pin-boundary','contract-comparison-final','h2-withdrawal']:
 records[group]=[]
 for p in (r/group).rglob('*'):
  if p.is_file() and p.suffix in ['.dll','.exe','.pdb','.cpp','.hpp']:
   with p.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
   records[group].append(dict(path=p.relative_to(r).as_posix(),sha256=digest,bytes=p.stat().st_size))
(r/'diagnostic-identities.json').write_text(json.dumps(records,indent=2))
print('DIAGNOSTIC_IDENTITIES',sum(map(len,records.values())))
