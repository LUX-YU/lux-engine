from pathlib import Path
import hashlib,json,re,subprocess
r=Path(__file__).parent
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
start=json.loads((r/'start.json').read_text())
protection=[]
for repo in start['repositories'][:1]:
 path=Path(repo['path']);head=subprocess.check_output(['git','-C',str(path),'rev-parse','HEAD'],text=True).strip()
 status=subprocess.check_output(['git','-C',str(path),'status','--porcelain','-z']).decode()
 files={name:sha(path/name) for name in repo['files']}
 assert head==repo['head'] and status==repo['status'] and files==repo['files'],'Unknown main workspace changed'
 protection.append(dict(path=str(path),head=head,status=status,files=files,unchanged=True))
dependency=json.loads((r/'fixed-dependencies.json').read_text())
for f in dependency['files']:assert sha(Path(f['path']))==f['sha256']
headers=[]
relative=Path('lux/engine/function/script/lua/LuaAllocation.hpp')
current=r.parent/'s5/source/modules/function/script/lua/include'/relative
for prefix in ['Debug','RelWithDebInfo','Android/lux-engine','o/v4/sdk']:
 target=Path('E:/SyncForder/CodeRepos/install')/prefix/'include'/relative
 assert sha(target)==sha(current)
 headers.append(dict(path=str(target),sha256=sha(target)))
caches=[]
for slot in ['d','t']:
 path=r.parent/'o/w'/slot/'CMakeCache.txt'
 rows={}
 for line in path.read_text().splitlines():
  if re.match(r'(CMAKE_(BUILD_TYPE|CXX_COMPILER|C_COMPILER|CXX_FLAGS|C_FLAGS|LINKER|INTERPROCEDURAL_OPTIMIZATION)|LUX_|LuxLua55_DIR|lux_cxx_DIR|lux_cmake_toolset_DIR|CMAKE_PREFIX_PATH)[^=]*=',line):
   key,value=line.split('=',1);rows[key]=value
 caches.append(dict(path=str(path),sha256=sha(path),values=rows))
 private=Path('E:/SyncForder/CodeRepos/install/o/v4')/('sdk' if slot=='d' else 'tools')/'include'
 assert not list(private.rglob('NativeFrameStorage.hpp')), 'private storage leaked into SDK'
result=dict(protected_workspaces=protection,dependency_hashes_verified=len(dependency['files']),
 headers=headers,caches=caches,private_native_storage_not_installed=True)
(r/'final-audit.json').write_text(json.dumps(result,indent=2));print('FINAL_IDENTITY_AND_PROTECTION_AUDIT_PASS')
