"""Compile the same new business assertions against A headers and the immutable A DLL set.
No production source, historical image or timed workload is changed.
"""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,time
r=Path(__file__).parent
source=r/'source';build=r.parent/'o/w/d';v4=r.parent/'script-v4'
out=r/'contract-comparison';out.mkdir(exist_ok=False)
inc=out/'a-headers';inc.mkdir()
headers={
 'engine/domain/simulation/builtin/script/include/lux/engine/simulation/ScriptSystem.hpp':'lux/engine/simulation/ScriptSystem.hpp',
 'engine/domain/simulation/scripting/core/include/lux/engine/simulation/scripting/ScriptRuntime.hpp':'lux/engine/simulation/scripting/ScriptRuntime.hpp',
 'engine/domain/simulation/scripting/core/sinclude/lux/engine/simulation/scripting/ScriptRuntimeAccess.hpp':'lux/engine/simulation/scripting/ScriptRuntimeAccess.hpp'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
baseline='f7d2815bdd2025ee23a7c11449def822413f58e9'
for src,dest in headers.items():
 p=inc/dest;p.parent.mkdir(parents=True,exist_ok=True)
 p.write_bytes(subprocess.check_output(['git','-C',str(source),'show',baseline+':'+src]))
images=[v4/'final-image'] # These are Developer fixtures; do not mix Toolchain DLL builds into A.
for image in images:
 for p in image.glob('*.dll'):
  target=out/p.name
  if target.exists():assert sha(target)==sha(p),p
  else:shutil.copy2(p,target)
def run(name,command,cwd):
 t=time.monotonic()
 with (out/(name+'.log')).open('wb') as f:code=subprocess.call(command,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 result={'command':command,'cwd':str(cwd),'exit':code,'seconds':time.monotonic()-t}
 (out/(name+'.json')).write_text(json.dumps(result,indent=2))
 if code:raise RuntimeError(name+' failed')
 return (out/(name+'.log')).read_text(errors='replace')
results=[]
for name in ['simulation_script_event_wait_test','simulation_script_continuation_test']:
 commands=subprocess.check_output(['ninja','-C',str(build),'-t','commands',name],text=True).splitlines()
 compile_command=next(x for x in commands if ('/c ' in x or '-c ' in x) and name+'.dir' in x and '.cpp' in x)
 obj=out/(name+'.obj')
 compile_command=compile_command.replace(' /nologo ',f' /nologo /I{inc} ',1)
 compile_command=re.sub(r'/Fo\S+',lambda m:'/Fo'+str(obj),compile_command)
 compile_command=re.sub(r'/Fd\S+',lambda m:'/Fd'+str(out/(name+'.pdb')),compile_command)
 # The current clean clone has the exact same new test file; historical headers precede all source includes.
 run(name+'-a-compile',['cmd','/d','/s','/c',compile_command],build)
 wrapped=next(x for x in reversed(commands) if 'vs_link_exe' in x and '/out:bin\\'+name+'.exe' in x)
 link=wrapped.split(' -- ',1)[1].split(' && ',1)[0]
 link=re.sub(r'engine\\domain\\simulation\\builtin\\script\\CMakeFiles\\'+name+r'\.dir\\test\\\S+\.obj',lambda m:str(obj),link)
 link=link.replace('/out:bin\\'+name+'.exe','/out:'+str(out/(name+'.exe')))
 link=link.replace('/pdb:bin\\'+name+'.pdb','/pdb:'+str(out/(name+'-link.pdb')))
 link=link.replace('/implib:lib\\'+name+'.lib','/implib:'+str(out/(name+'.lib')))
 run(name+'-a-link',['cmd','/d','/s','/c',link],build)
 os.environ['PATH']=';'.join([str(out),'D:/Development/vcpkg/installed/x64-windows/bin',
   *[p for p in os.environ['PATH'].split(';') if 'CodeRepos' not in p and 'vcpkg' not in p]])
 a=run(name+'-A',[str(out/(name+'.exe'))],out)
 os.environ['PATH']=str(build/'bin')+';'+os.environ['PATH']
 b=run(name+'-B',[str(build/'bin'/(name+'.exe'))],build/'bin')
 traces=lambda text:[x for x in text.splitlines() if x.startswith(('CELL_CASE','LOCAL_TIMER','TIMER_RETRY'))]
 assert traces(a) and traces(a)==traces(b),(name,traces(a),traces(b))
 results.append({'test':name,'A_production':baseline,'A_headers':{h:sha(inc/d) for h,d in headers.items()},
   'B_source':subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip(),
   'new_test_sha256':sha(source/'engine/domain/simulation/builtin/script/test'/
     ('script_system_event_wait_test.cpp' if 'event_wait' in name else 'script_system_continuation_test.cpp')),
   'traces':traces(a),'same_trace':True})
(out/'result.json').write_text(json.dumps(results,indent=2))
print('A_B_CONTRACTS_PASS',sum(len(x['traces']) for x in results),flush=True)
