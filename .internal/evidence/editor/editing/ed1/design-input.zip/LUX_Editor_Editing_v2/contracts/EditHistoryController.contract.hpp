#pragma once
// Production: engine/editor/context/include/lux/engine/editor/EditHistoryController.hpp.
// Use existing editor_context visibility and meta generation.
#include "ActiveEditHistory.contract.hpp"
#include <lux/engine/object/Object.hpp>
#include <lux/engine/object/ObjectAnnotations.hpp>
namespace lux::editor
{
    struct EditHistoryActionFailure final
    {
        HistoryTargetHandle target;
        editing::EHistoryAction action{editing::EHistoryAction::UNDO};
        editing::EditFailure failure;
    };
    class LUX_OBJECT() EditHistoryController final : public object::Object<EditHistoryController>
    {
    public:
        static const signal_type<EditHistoryActionFailure> failed;
        explicit EditHistoryController(object::ObjectDispatcherRef dispatcher, ActiveEditHistory& histories) noexcept;
        ~EditHistoryController() override;
        void undo() noexcept;
        void redo() noexcept;
        [[nodiscard]] bool canUndo() const noexcept;
        [[nodiscard]] bool canRedo() const noexcept;
        [[nodiscard]] std::string_view undoLabel() const noexcept;
        [[nodiscard]] std::string_view redoLabel() const noexcept;
    private:
        ActiveEditHistory* histories_{};
    };
}
