#pragma once
// Generated typed value operations and immutable CodecPlan specializations.
// Member thunks preserve non-standard-layout and const-member construction; no runtime reflection interpretation.
#include <lux/engine/function/script/lua/LuaValue.hpp>
#include <Values.hpp>
#include "E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-v4/installed/script-lua-values/source/Rules.hpp"

namespace lux::script::lua
{


template <> struct LuaGeneratedValue<::Item> : LuaRecordValue<::Item,
    LuaValueField<&::Item::id, "key">,
    LuaValueField<&::Item::weight, "weight">>
{
};
static_assert(LuaValueCodec<::Item>::bounded, "Lua value expanded frame exceeds 64 KiB or depth 32");

template <> struct LuaGeneratedValue<::WideValue> : LuaRecordValue<::WideValue,
    LuaValueField<&::WideValue::field0, "field0">,
    LuaValueField<&::WideValue::field1, "field1">,
    LuaValueField<&::WideValue::field2, "field2">,
    LuaValueField<&::WideValue::field3, "field3">,
    LuaValueField<&::WideValue::field4, "field4">,
    LuaValueField<&::WideValue::field5, "field5">,
    LuaValueField<&::WideValue::field6, "field6">,
    LuaValueField<&::WideValue::field7, "field7">,
    LuaValueField<&::WideValue::field8, "field8">,
    LuaValueField<&::WideValue::field9, "field9">,
    LuaValueField<&::WideValue::field10, "field10">,
    LuaValueField<&::WideValue::field11, "field11">,
    LuaValueField<&::WideValue::field12, "field12">,
    LuaValueField<&::WideValue::field13, "field13">,
    LuaValueField<&::WideValue::field14, "field14">,
    LuaValueField<&::WideValue::field15, "field15">,
    LuaValueField<&::WideValue::field16, "field16">,
    LuaValueField<&::WideValue::field17, "field17">,
    LuaValueField<&::WideValue::field18, "field18">,
    LuaValueField<&::WideValue::field19, "field19">,
    LuaValueField<&::WideValue::field20, "field20">,
    LuaValueField<&::WideValue::field21, "field21">,
    LuaValueField<&::WideValue::field22, "field22">,
    LuaValueField<&::WideValue::field23, "field23">,
    LuaValueField<&::WideValue::field24, "field24">,
    LuaValueField<&::WideValue::field25, "field25">,
    LuaValueField<&::WideValue::field26, "field26">,
    LuaValueField<&::WideValue::field27, "field27">,
    LuaValueField<&::WideValue::field28, "field28">,
    LuaValueField<&::WideValue::field29, "field29">,
    LuaValueField<&::WideValue::field30, "field30">,
    LuaValueField<&::WideValue::field31, "field31">,
    LuaValueField<&::WideValue::field32, "field32">,
    LuaValueField<&::WideValue::field33, "field33">,
    LuaValueField<&::WideValue::field34, "field34">,
    LuaValueField<&::WideValue::field35, "field35">,
    LuaValueField<&::WideValue::field36, "field36">,
    LuaValueField<&::WideValue::field37, "field37">,
    LuaValueField<&::WideValue::field38, "field38">,
    LuaValueField<&::WideValue::field39, "field39">,
    LuaValueField<&::WideValue::field40, "field40">,
    LuaValueField<&::WideValue::field41, "field41">,
    LuaValueField<&::WideValue::field42, "field42">,
    LuaValueField<&::WideValue::field43, "field43">,
    LuaValueField<&::WideValue::field44, "field44">,
    LuaValueField<&::WideValue::field45, "field45">,
    LuaValueField<&::WideValue::field46, "field46">,
    LuaValueField<&::WideValue::field47, "field47">,
    LuaValueField<&::WideValue::field48, "field48">,
    LuaValueField<&::WideValue::field49, "field49">,
    LuaValueField<&::WideValue::field50, "field50">,
    LuaValueField<&::WideValue::field51, "field51">,
    LuaValueField<&::WideValue::field52, "field52">,
    LuaValueField<&::WideValue::field53, "field53">,
    LuaValueField<&::WideValue::field54, "field54">,
    LuaValueField<&::WideValue::field55, "field55">,
    LuaValueField<&::WideValue::field56, "field56">,
    LuaValueField<&::WideValue::field57, "field57">,
    LuaValueField<&::WideValue::field58, "field58">,
    LuaValueField<&::WideValue::field59, "field59">,
    LuaValueField<&::WideValue::field60, "field60">,
    LuaValueField<&::WideValue::field61, "field61">,
    LuaValueField<&::WideValue::field62, "field62">,
    LuaValueField<&::WideValue::field63, "field63">>
{
};
static_assert(LuaValueCodec<::WideValue>::bounded, "Lua value expanded frame exceeds 64 KiB or depth 32");
}

// SR-5 isolated installed-template invalidation probe
