$ErrorActionPreference = 'Stop'
$taskRoot = 'E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5'
$source = "$taskRoot/candidate-source"
& "$source/cmake/RunScriptV3Qualification.ps1" -SourceDir $source -BuildRoot "$taskRoot/q" -InstallRoot 'E:/SyncForder/CodeRepos/install/s5/q' -CxxPrefix 'E:/SyncForder/CodeRepos/install/q2/c' -ToolsetPrefix 'E:/SyncForder/CodeRepos/install/q2/toolset' -FoundationPrefix 'E:/SyncForder/CodeRepos/install/RelWithDebInfo' -Lua54Prefix 'E:/SyncForder/CodeRepos/build/deps/lua54-vcpkg/x64-windows' -Profiles @('toolchain','developer','lua54')
