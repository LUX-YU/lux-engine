#pragma once
// Generated typed Lua projection. Include the matching .ability.generated.hpp first.
#include <lux/engine/simulation/scripting/lua/LuaScriptAbilityProjection.hpp>

#include <array>
#include <type_traits>
#include <utility>

namespace lux::script::lua
{

    template <>
    struct ScriptAbilityLuaTraits<::lux::simulation::script::test::LuaPushOnlyAbility> final
    {
        using AbilityTraits = ScriptAbilityTraits<::lux::simulation::script::test::LuaPushOnlyAbility>;
        using Policy = typename ScriptAbilityLuaPolicy<::lux::simulation::script::test::LuaPushOnlyAbility>::Type;

        using Values_read = LuaAbilityValueSignature<Policy, int, lux::simulation::script::test::ValuePushOnly>;
        [[nodiscard]] static int read(lua_State* state) noexcept
        {
            return lux::simulation::script::detail::invokeLuaValueAbility<Policy, int, lux::simulation::script::test::ValuePushOnly>(
                state,
                [](lux::simulation::script::detail::LuaPreparedAbilityAccess access, lux::simulation::script::test::ValuePushOnly value) noexcept -> int
                {
                    const auto& dispatch = *static_cast<const AbilityTraits::Dispatch*>(access.dispatch);
                    return dispatch.read(access.context, value);
                }
            );
        }

        inline static constexpr std::array<ScriptAbilityLuaMethodProjection, AbilityTraits::Methods.size()> Methods{
            ScriptAbilityLuaMethodProjection{
                ScriptApiMethodIdView{"lux.test.lua_push_only.read"},
                &read, Values_read::Parameters, Values_read::Results
            }
        };
    };
} // namespace lux::script::lua
