import hashlib,json,os,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent
s=r/'candidate-source'
sys.path.insert(0,str(s/'cmake'))
from RunScriptSR2Probes import run
root=r/'regions'
root.mkdir(exist_ok=False)
p=s/'engine/domain/simulation/composition/test/hook_regions_test.cpp'
t=p.read_text()
t='#include <atomic>\n#include <cstdio>\n'+t
t=t.replace('    struct State final\n    {','''    std::atomic<unsigned> worker_entries{}, owner_entries{};
    struct Windows final { std::atomic<int> workers{}, owners{}; };
    struct Window final
    {
        Windows& windows;
        bool worker;
        Window(Windows& w, bool is_worker) : windows(w), worker(is_worker)
        {
            if (worker) { ++worker_entries; ++windows.workers; assert(windows.owners.load() == 0); }
            else { ++owner_entries; ++windows.owners; assert(windows.workers.load() == 0); }
        }
        ~Window() { if (worker) --windows.workers; else --windows.owners; }
    };
    struct State final
    {
        Windows windows;
''',1)
hits={}
replacements={
 '[](RegionSystem& system) noexcept {': ('[](RegionSystem& system) noexcept {\n            Window interval{system.state.windows, true};',3),
 '[](RegionSystem& system, const HookInvocation& invocation) noexcept {': ('[](RegionSystem& system, const HookInvocation& invocation) noexcept {\n                Window interval{system.state.windows, false};',2),
 'auto& state = *static_cast<State*>(context);': ('auto& state = *static_cast<State*>(context);\n            Window interval{state.windows, false};',5),
 '    std::jthread second([&] { run(&rendezvous); });': ('    std::jthread second([&] { run(&rendezvous); });\n    first.join(); second.join();\n    assert(worker_entries == 21U && owner_entries > 0U);\n    std::printf("EXCLUSIVE workers=%u owners=%u violations=0 full_windows=1 PASS\\n", worker_entries.load(), owner_entries.load());',1)
}
for old,(new,count) in replacements.items():
 hits[old]=t.count(old);assert hits[old]==count,(old,hits[old]);t=t.replace(old,new)
(root/'regions.cpp').write_text(t)
(root/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.22)
project(sr6_regions LANGUAGES CXX)
find_package(lux-cmake-toolset CONFIG REQUIRED)
find_package(lux-engine-simulation-composition REQUIRED COMPONENTS simulation_composition)
add_executable(regions regions.cpp)
target_compile_features(regions PRIVATE cxx_std_20)
target_compile_options(regions PRIVATE /UNDEBUG)
target_link_libraries(regions PRIVATE lux::engine::simulation::composition)
''')
prefix='E:/SyncForder/CodeRepos/install/s6/q/d;E:/SyncForder/CodeRepos/install/q2/c;E:/SyncForder/CodeRepos/install/q2/toolset;E:/SyncForder/CodeRepos/install/RelWithDebInfo'
run(['cmake','-S',str(root),'-B',str(root/'build'),'-G','Ninja','-DCMAKE_BUILD_TYPE=RelWithDebInfo','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DCMAKE_FIND_USE_PACKAGE_REGISTRY=OFF','-DCMAKE_FIND_USE_SYSTEM_PACKAGE_REGISTRY=OFF','-DCMAKE_TOOLCHAIN_FILE=D:/Development/vcpkg/scripts/buildsystems/vcpkg.cmake','-DCMAKE_PREFIX_PATH='+prefix],root/'configure.log')
cmd=['cmake','--build',str(root/'build'),'--target','all','-j','4','--','-k','0']
run(cmd,root/'all.log');run(cmd,root/'noop.log')
env=dict(os.environ);env['PATH']=';'.join([str(Path(v)/'bin') for v in prefix.split(';')]+['D:/Development/vcpkg/installed/x64-windows/bin']+[v for v in env['PATH'].split(';') if 'CodeRepos' not in v and 'vcpkg' not in v])
exe=root/'build/regions.exe';run([str(exe)],root/'regions.log',env)
assert 'violations=0 full_windows=1 PASS' in (root/'regions.log').read_text()
(root/'identity.json').write_text(json.dumps({'source':subprocess.check_output(['git','-C',str(s),'rev-parse','HEAD'],text=True).strip(),'fixture_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'insertion_hits':hits,'exe_sha256':hashlib.sha256(exe.read_bytes()).hexdigest()},indent=2))
