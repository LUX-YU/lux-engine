from pathlib import Path
import csv,ctypes as ct,json,os,subprocess,time,re
r=Path(__file__).parent;image=r/'w2-image';out=r/'w3-budget32';out.mkdir(exist_ok=False)
k=ct.WinDLL('kernel32');k.GetCurrentProcess.restype=ct.c_void_p;k.SetProcessAffinityMask.argtypes=[ct.c_void_p,ct.c_size_t];assert k.SetProcessAffinityMask(k.GetCurrentProcess(),16)
env=dict(os.environ);env['PATH']=';'.join([str(image),'D:/Development/vcpkg/installed/x64-windows/bin',*[p for p in env['PATH'].split(';') if 'CodeRepos' not in p and 'vcpkg' not in p]])
class Memory(ct.Structure):
 _fields_=[('cb',ct.c_ulong),('faults',ct.c_ulong),('PeakWorkingSetSize',ct.c_size_t),('WorkingSetSize',ct.c_size_t),('QuotaPeakPagedPoolUsage',ct.c_size_t),('QuotaPagedPoolUsage',ct.c_size_t),('QuotaPeakNonPagedPoolUsage',ct.c_size_t),('QuotaNonPagedPoolUsage',ct.c_size_t),('PagefileUsage',ct.c_size_t),('PeakPagefileUsage',ct.c_size_t)]
psapi=ct.WinDLL('psapi');psapi.GetProcessMemoryInfo.argtypes=[ct.c_void_p,ct.POINTER(Memory),ct.c_ulong]
runs=[]
for config in ['g0']:
 for leg in ['event']:
  for diagnostic in [False,True]:
   name=f'{config}-{leg}-'+('diagnostic' if diagnostic else 'timing');data=out/(name+'.csv');log=out/(name+'.log')
   if leg=='event':
    command=[str(image/'script_runtime_benchmark.exe'),'--group','scene-lua-event','--mode','performance','--size','10000','--frames','2000','--warmups','1000','--seed','1592598566','--resume-budget','10000','--vm-accounting','on' if diagnostic else 'off','--lua-artifact',str(image/'lua_runtime_benchmark_fixture.lxsa'),'--output',str(data),'--idle-page-budget','33554432']
    if config=='g1':command+=['--gc-pause','150']
    if config=='g2':command+=['--lua-gc','gen']
   else:
    command=[str(image/'simulation_script_lua_value_runtime_test.exe'),'--benchmark','1000000']
    if config!='g0':command+=['--gc-'+config]
    if diagnostic:command+=['--allocations']
   peak_ws=peak_private=samples=0;start=time.monotonic()
   with log.open('wb') as f:
    p=subprocess.Popen(command,env=env,stdout=f,stderr=subprocess.STDOUT)
    while p.poll() is None:
     if diagnostic:
      m=Memory();m.cb=ct.sizeof(m)
      if psapi.GetProcessMemoryInfo(int(p._handle),ct.byref(m),m.cb):
       peak_ws=max(peak_ws,m.PeakWorkingSetSize);peak_private=max(peak_private,m.PeakPagefileUsage);samples+=1
     time.sleep(.1)
    code=p.wait()
   text=log.read_text();rows=list(csv.DictReader(data.open())) if data.exists() else []
   if leg=='event':
    valid=code==0 and len(rows)==2000 and 'checksum=930010000' in text and text.count('invocation_errors=0')==2
    times=sorted(int(x['nanoseconds']) for x in rows);ns=sum(times);ops=20000000
    valid=valid and (not diagnostic or 'PAGE_PHASE_END,count=12000,dropped=0' in text)
   else:
    match=re.search(r'VALUE_BENCH count=1000000 ns=(\d+) operations=1000000 errors=0 backlog=0',text)
    valid=code==0 and match is not None and 'VALUE_CLEANUP invocation_errors=0' in text
    ns=int(match[1]) if match else None;ops=1000000;times=[]
   runs.append(dict(config=config,leg=leg,diagnostic=diagnostic,source=json.loads((image/'identity.json').read_text())['source'],command=command,exit=code,valid=valid,total_ns=ns,operations=ops,ns_per_operation=ns/ops if ns else None,p99_batch_ns=times[1980] if times else None,wall_seconds=time.monotonic()-start,peak_working_set=peak_ws if diagnostic else None,peak_private=peak_private if diagnostic else None,memory_samples=samples if diagnostic else None,errors=0 if valid else None,backlog=0 if valid else None))
   (out/'runs.json').write_text(json.dumps(runs,indent=2));print(name,code,valid,ns/ops if ns else None,flush=True)
   if not valid:raise SystemExit('Invalid '+name)
