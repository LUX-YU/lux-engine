from pathlib import Path
b=Path('E:/RenderV2Rebuild/Layer/source/modules/function/render')
p=b/'protocol/include/lux/engine/render/protocol/Protocol.hpp';s=p.read_text().replace('struct CommandHandler final','struct CommandHandler');p.write_text(s)
p=b/'features/test/CMakeLists.txt';s=p.read_text().replace('foreach(header Feature Resources Texture Program Registration)','foreach(header Feature Resources Program Registration)');p.write_text(s)
p=b/'resource/test/CMakeLists.txt';s=p.read_text().replace('foreach(header Storage Factory TransferOptions ResourceRegistry CpuSchedule Upload)','foreach(header Storage Factory Registration Texture TransferOptions ResourceRegistry CpuSchedule Upload)');p.write_text(s)
p=b/'resource/test/Registry.cpp';s=p.read_text().replace('        require(bool(registry.configureType(TestStorage::description, std::make_shared<const unsigned>(7))));','''        // Same schema and same sizeof cannot authorize a different native C++ Config.
        struct WrongConfig { unsigned value; };
        static_assert(sizeof(WrongConfig) == sizeof(TestStorage::Config));
        require(!registry.configureType(TestStorage::description, std::make_shared<const WrongConfig>(WrongConfig{7})));
        require(bool(registry.configureType(TestStorage::description, std::make_shared<const unsigned>(7))));
        const WrongConfig wrong{7};
        require(!registry.getOrCreate(root, "wrong", TestStorage::description, &wrong));
        require(counts.created == 0);''');p.write_text(s)
p=b/'native/vulkan/test/Foundation.cpp';s=p.read_text().replace('    auto b = take(DeviceSession::create(bootstrap, {}, 3, 1));','''    auto b = take(DeviceSession::create(bootstrap, {}, 3, 1));
    CHECK(a->resources().factory(StorageTypeIdView("lux.render.TextureStorage")) == nullptr);
    CHECK(a->resources().size() == 0);''');p.write_text(s)
# Exact-signature tests are independent of Native and stdexec.
p=b/'protocol/test/Binding.cpp';p.write_text('''#include <lux/engine/render/protocol/Protocol.hpp>
#include <cstdlib>

using namespace lux::render;

struct Command final
{
    static constexpr std::string_view name = "test.typed.binding";
    struct Request { unsigned value; };
    using Response = unsigned;
};
struct OtherRequest { unsigned value; };
struct State { unsigned value = 0; };

static RenderResult<void> apply(State& state, const Command::Request& input, CommandContext<Command>& context) noexcept
{
    state.value = input.value;
    return context.complete(input.value);
}

static RenderResult<void> wrong(State&, const OtherRequest&, CommandContext<Command>&) noexcept { return {}; }
static RenderResult<void> throwing(State&, const Command::Request&, CommandContext<Command>&) { return {}; }

template <auto Function>
concept CanBind = requires(State& state) { bindCommand<Command, Function>(state); };
static_assert(CanBind<apply>);
static_assert(!CanBind<wrong> && !CanBind<throwing>);
static_assert(sizeof(OtherRequest) == sizeof(Command::Request));

int main()
{
    State state;
    unsigned result = 0;
    const CommandCompletionFns completion{
        [](void* output, ECommandOutcome outcome, RenderError, void* value) noexcept -> RenderResult<void> {
            if (outcome != ECommandOutcome::SUCCESS) std::abort();
            *static_cast<unsigned*>(output) = *static_cast<unsigned*>(value);
            return {};
        }, [](const void*) noexcept { return true; }
    };
    const auto handler = bindCommand<Command, apply>(state);
    const Command::Request input{47};
    CommandInvocation invocation{&input, &result, &completion};
    if (!handler.invoke(handler.user, invocation) || state.value != 47 || result != 47) std::abort();
}
''')
p=b/'protocol/test/CMakeLists.txt';s=p.read_text()+'''
add_executable(render_protocol_binding_test Binding.cpp)

target_link_libraries(render_protocol_binding_test PRIVATE render_protocol)

add_test(NAME render.protocol.binding COMMAND render_protocol_binding_test)
''';p.write_text(s)
