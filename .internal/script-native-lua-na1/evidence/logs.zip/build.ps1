param([string]$Label='dev', [string]$Slot='d', [switch]$Fresh, [switch]$ReconfigureTask, [string]$Tests='script|lua')
$ErrorActionPreference='Stop'
$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1'
$s="$r/source"
$b="E:/SyncForder/CodeRepos/build/RelWithDebInfo/o/w/$Slot"
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
function Run([string]$name,[string[]]$command) {
 $log="$r/$Label-$name.log"
 if(Test-Path -LiteralPath $log){throw 'Existing log'}
 $command|ConvertTo-Json -Compress|Set-Content -LiteralPath $log
 $watch=[Diagnostics.Stopwatch]::StartNew()
 & $command[0] $command[1..($command.Length-1)] *>>$log
 $code=$LASTEXITCODE
 @{source=(git -C $s rev-parse HEAD);worktree_status=(@(git -C $s status --porcelain) -join "`n");command=$command;exit=$code;seconds=$watch.Elapsed.TotalSeconds} | ConvertTo-Json -Depth 5 | Set-Content "$r/$Label-$name.json"
 Write-Output "$Label-$name exit=$code"
 if($code){throw "Failed $log"}
}
$taskProfile=if($Slot -eq 't'){'TOOLCHAIN'}else{'DEVELOPER'}
$prefix=if($Slot -eq 't'){'tools'}else{'sdk'}
$configure=@('cmake','-S',$s,'-B',$b,'-G','Ninja','-DCMAKE_BUILD_TYPE=RelWithDebInfo',"-DLUX_BUILD_PROFILE=$taskProfile",'-DBUILD_TESTING=ON',
 '-DCMAKE_TOOLCHAIN_FILE=D:/Development/vcpkg/scripts/buildsystems/vcpkg.cmake',
 '-DCMAKE_PREFIX_PATH=E:/SyncForder/CodeRepos/install/q2/toolset;E:/SyncForder/CodeRepos/install/q2/c;E:/SyncForder/CodeRepos/install/RelWithDebInfo',
 '-DLuxLua55_DIR=E:/SyncForder/CodeRepos/install/o/v4/lua55/lib/cmake/LuxLua55',
 "-DCMAKE_INSTALL_PREFIX=E:/SyncForder/CodeRepos/install/o/na1/$prefix",'-DLUX_SCRIPT_HOTPATH_OBSERVATION=OFF','-DLUX_BUILD_PHYSICS2D=ON',
 '-DLUX_PHYSICS2D_LUA_ARTIFACT=E:/SyncForder/CodeRepos/build/RelWithDebInfo/o/w/t/engine/toolchain/physics2d/physics2d_lua_fixture.lxsa',
 '-DLUX_PHYSICS2D_FLOWFORGE_ARTIFACT=E:/SyncForder/CodeRepos/build/RelWithDebInfo/o/w/t/engine/toolchain/physics2d/physics2d_flowforge_fixture.lxsa',
 '-DLUX_LUA_PORTABILITY_ARTIFACT=E:/SyncForder/CodeRepos/build/RelWithDebInfo/o/w/t/engine/toolchain/lua/lua_portability_fixture.lxsa')
if($Fresh){$configure+='--fresh'; Copy-Item -LiteralPath "$b/CMakeCache.txt" -Destination "$r/$Label-old-CMakeCache.txt"}
if($Fresh -or $ReconfigureTask -or !(Test-Path -LiteralPath "$b/CMakeCache.txt")){Run 'configure' $configure}
Run 'build' @('cmake','--build',$b,'--target','all','-j','4','--','-k','0')
$env:PATH="$b/bin;D:/Development/vcpkg/installed/x64-windows/bin;$env:PATH"
if($Tests){Run 'tests' @('ctest','--test-dir',$b,'--output-on-failure','-j','1','-R',$Tests)}
