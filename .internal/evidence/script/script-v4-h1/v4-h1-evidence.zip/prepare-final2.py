from pathlib import Path
r=Path(__file__).parent
s=(r/'qualify-final.ps1').read_text().replace('final-', 'final2-').replace('script-region-opt/final2-source', 'script-region-opt/final-source')
(r/'qualify-final2.ps1').write_text(s)
s=(r/'capture-final.py').read_text().replace("r/'final-d-build.json'", "r/'final2-d-build.json'").replace("r/'final-t-build.json'", "r/'final2-t-build.json'")
s=s.replace('image=r/label;', "image=r/label.replace('final-', 'final2-');")
(r/'capture-final2.py').write_text(s)
s=(r/'final-costs.py').read_text().replace("out=r/'final-costs'", "out=r/'final2-costs'").replace("r/'final-image/identity.json'", "r/'final2-image/identity.json'")
s=s.replace("image=home/('final-flow-image' if scene=='flowforge-event' else 'final-image')", "image=home/(('final-' if side=='A' else 'final2-')+('flow-image' if scene=='flowforge-event' else 'image'))")
(r/'final2-costs.py').write_text(s)
s=(r/'native-cold.py').read_text().replace("out=r/'native-cold'", "out=r/'native-boundary'").replace('native-cold-fixture.cpp','native-boundary-fixture.cpp').replace('native-cold-test.cpp','native-boundary-test.cpp').replace('LUX_H1_COLD_CASE','LUX_H1_BOUNDARY_CASE').replace('NATIVE_COLD_PASS_16','NATIVE_BOUNDARY_PASS_16').replace("r/'final-image'", "r/'final2-image'")
source=r.parent/'script-cell-a1/source'
prefix=(source/'engine/domain/simulation/scripting/native/test/native_backend_test.cpp').read_text().split('int main()')[0]
(r/'native-boundary-test.cpp').write_text(prefix+(r/'native-boundary-main.cpp').read_text())
(r/'native-boundary.py').write_text(s)
