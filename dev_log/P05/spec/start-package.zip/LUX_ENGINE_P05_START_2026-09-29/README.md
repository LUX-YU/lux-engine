# P05 启动包

请先读取 [START_P05.md](START_P05.md)，再读取 [原 V4 P05](reference-v4/phases/P05_persistence.md)。

本包只放行 P05；P04 R1 复审基准为 `aad13c594afe33af69fcfba1b44790b4e9ad148d`。本包不是代码补丁，不代表 P05 已实施。

`reference-v4/` 是原始 V4 的逐字节参考副本。为保持阶段文档的原相对链接而完整保留，不代表允许执行其中 P06–P13。不得复制旧 manifests/种子账本/审计脚本覆盖当前仓库；以当前 `.internal/editor-redesign/` 和实际迁移记录为准。

`SHA256SUMS.txt` 校验本包文件；`PACKAGE_CHECK.json` 只记录文档与归档检查，不是引擎测试。
