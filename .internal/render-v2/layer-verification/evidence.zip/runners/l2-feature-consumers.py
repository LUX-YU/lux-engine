from pathlib import Path
import re
b=Path('E:/RenderV2Rebuild/Layer/source/modules/function/render')
# Scan C++ initializer punctuation, ignoring quoted text and comments.
def endbrace(s,start):
 depth=0;i=start;quote=None
 while i<len(s):
  c=s[i]
  if quote:
   if c=='\\':i+=2;continue
   if c==quote:quote=None
  elif s.startswith('//',i):
   j=s.find('\n',i);i=len(s) if j<0 else j;continue
  elif s.startswith('/*',i):i=s.index('*/',i+2)+2;continue
  elif c in '\"\'':quote=c
  elif c=='{':depth+=1
  elif c=='}':
   depth-=1
   if depth==0:return i
  i+=1
 raise ValueError('unclosed')
def fields(s):
 result=[];depth=0;start=0;i=0;quote=None
 while i<len(s):
  c=s[i]
  if quote:
   if c=='\\':i+=2;continue
   if c==quote:quote=None
  elif s.startswith('//',i):
   j=s.find('\n',i);i=len(s) if j<0 else j;continue
  elif s.startswith('/*',i):i=s.index('*/',i+2)+2;continue
  elif c in '\"\'':quote=c
  elif c in '({[':depth+=1
  elif c in ')}]':depth-=1
  elif c==',' and depth==0:result.append(s[start:i].strip());start=i+1
  i+=1
 if s[start:].strip():result.append(s[start:].strip())
 return result
names=set()
for p in b.rglob('*'):
 if p.suffix not in ('.cpp','.hpp') or '/test/' not in p.as_posix():continue
 s=p.read_text();offset=0
 while m:=re.search(r'FeatureDefinition\s+(\w+)\s*\{',s[offset:]):
  a=offset+m.start();brace=offset+m.end()-1;z=endbrace(s,brace);name=m[1];names.add(name);args=fields(s[brace+1:z]);assert 4<=len(args)<=6,(p,name,args)
  line=s.rfind('\n',0,a)+1;qual=s[line:a];indent=re.match(r'\s*',qual)[0];qual=qual.strip()
  callbacks=args[3:5];callbacks+=['nullptr']*(2-len(callbacks))
  new='FeatureDescriptor '+name+'{'+', '.join(args[:3])+'};\n'+indent+(qual+' ' if qual else '')+'FeatureGraphOps '+name+'_graph{'+', '.join(callbacks)+'}'
  s=s[:a]+new+s[z+1:];offset=a+len(new)
 if 'FeatureDefinition' in s:s=s.replace('FeatureDefinition','FeatureDescriptor')
 p.write_text(s)
# Functions returning a descriptor do not return the graph ops; both static values are explicit.
p=b/'features/test/Scenarios.hpp';s=p.read_text();a=s.index('        static const FeatureGraphOps value_graph');z=s.index(';',a)+1;value=s[a:z].replace('value_graph','value');s=s[:a]+s[z:];pos=s.index('    inline RenderResult<FeatureAssembly> scenario');s=s[:pos]+'''    template <ERole R> const FeatureGraphOps& graph() noexcept
    {
'''+value+'''
        return value;
    }

'''+s[pos:];s=re.sub(r'\{&definition<([^>]+)>\(\),',r'{&definition<\1>(), &graph<\1>(),',s)
s=s.replace('{which == 1 ? &definition<ERole::HISTORY>() : &definition<ERole::MATERIAL>(),','{which == 1 ? &definition<ERole::HISTORY>() : &definition<ERole::MATERIAL>(),\n                which == 1 ? &graph<ERole::HISTORY>() : &graph<ERole::MATERIAL>(),').replace('{which == 1 ? &definition<ERole::CULL>() : &definition<ERole::MESH>(),','{which == 1 ? &definition<ERole::CULL>() : &definition<ERole::MESH>(),\n                which == 1 ? &graph<ERole::CULL>() : &graph<ERole::MESH>(),');p.write_text(s)
for p in b.rglob('*'):
 if p.suffix not in ('.cpp','.hpp'):continue
 s=p.read_text()
 # Production registration and test selections use separate descriptor/ops borrows.
 s=re.sub(r'\{&((?:\w+::)*\w+),',lambda m:'{&'+m[1]+', &'+m[1]+'_graph,' if m[1].split('::')[-1] in names and m[1]!='value' else m[0],s)
 if '/test/' in p.as_posix():
  s=re.sub(r'\b('+ '|'.join(names)+r')\.(describe|build)\b',r'\1_graph.\2',s)
  s=re.sub(r'\b(s|instances\[1\])\.definition\b',r'\1.descriptor',s)
 if p.name=='Feature.cpp':
  s=s.replace('    auto saved = d;','    auto saved = d;\n    auto saved_graph = d_graph;').replace('    d = saved;','    d = saved;\n    d_graph = saved_graph;').replace('    d.commands = {};\n','')
 if p.name=='RenderServer.cpp':
  s=s.replace('f.definition','f.descriptor').replace('registration->definition','registration->descriptor').replace('feature.definition','feature.descriptor').replace('current.definition','current.descriptor')
  s=s.replace('selected.push_back({&definition, &definition_graph, wire, selection.instance});','selected.push_back({&definition, registration->graph, wire, selection.instance});')
  s=s.replace('(feature.descriptor && (!feature.descriptor->describe || feature.descriptor->type.name().empty()))','!feature.graph || (feature.graph && !feature.graph->describe) ||\n            (feature.descriptor && feature.descriptor->type.name().empty())')
  a=s.index('        if (feature.handlers.size() != feature.descriptor->commands.size())');z=s.index('        for (std::size_t i = 0; i < feature.handlers.size(); ++i)\n            s.addCommand',a)
  s=s[:a]+'        if (auto valid = s.validateHandlers(feature.handlers, transports); !valid) return valid;\n'+s[z:]
 if p.name=='RenderServer.hpp':s=s.replace('registration.definition','registration.descriptor')
 p.write_text(s)
Path('E:/RenderV2Rebuild/Layer/feature-names.json').write_text(str(sorted(names)))
