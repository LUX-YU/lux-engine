$ErrorActionPreference='Stop'
$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-native-lua-na1'
foreach($slot in @('d','t')){if((Get-Content "$r/qualified-$slot-tests2.json" -Raw|ConvertFrom-Json).exit){throw 'Qualification not green'}}
$vm='E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-lua55-s0-s1-20260909/dependencies/build-lua55'
if((Get-FileHash "$vm/lux_lua55.dll").Hash -ne (Get-FileHash 'E:/SyncForder/CodeRepos/install/o/v4/lua55/bin/lux_lua55.dll').Hash){throw 'Wrong VM test image'}
& ctest --test-dir $vm --output-on-failure -V -j 1 *> "$r/final-vm-tests.log"
$vmCode=$LASTEXITCODE
@{exit=$vmCode;vm_dll=(Get-FileHash "$vm/lux_lua55.dll").Hash;source=(git -C "$r/qualification-source" rev-parse HEAD);test_location=$vm}|ConvertTo-Json|Set-Content "$r/final-vm-tests.json"
if($vmCode){throw 'VM contract failure'}
& "$r/benchmark-final.ps1" -Side A -Label final-common
& "$r/benchmark-final.ps1" -Side B -Label final-common
& 'C:/Users/ChenHui/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -B "$r/save-final-images.py"
if($LASTEXITCODE){throw 'Image capture failed'}
& "$r/installed-final.ps1"
& "$r/new-incremental.ps1"
& "$r/relocated-final.ps1" -Root $r
