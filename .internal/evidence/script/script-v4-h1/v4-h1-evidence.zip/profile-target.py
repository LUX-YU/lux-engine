import json, subprocess, sys
from pathlib import Path
out=Path(sys.argv[1]);command=json.loads((out/'target-command.json').read_text())
with (out/'target.log').open('wb') as f:
    child=subprocess.Popen(command,stdout=f,stderr=subprocess.STDOUT);code=child.wait()
(out/'target-exit.json').write_text(json.dumps(dict(command=command,pid=child.pid,exit=code),indent=2))
sys.exit(code)
