// Reduced C++20 algorithm probe. NOT Lux source, NOT a FlowSession test.
// Models only: live-record re-materialization; graph-local node/pin counters;
// variable-only preservation; live/parked graph exchange on undo/redo.
// Counter and call-chain evidence is listed in ../REVIEW_AND_INSTRUCTIONS.md.
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

using Id = std::uint64_t;
struct Node { Id id; std::vector<Id> pins; };
struct Graph {
    std::string name = "base";
    std::vector<Node> nodes;
    Id next_node = 1, next_pin = 1, next_variable = 1;
    Node add_node() {
        if (!next_node || !next_pin || next_pin == UINT64_MAX)
            throw std::runtime_error("probe exhausted");
        Node result{next_node++, {next_pin++, next_pin++}};
        nodes.push_back(result);
        return result;
    }
    void erase_node(Id id) {
        std::erase_if(nodes, [=](const Node& value) { return value.id == id; });
        // Erasing content does not rewind the live graph's allocator.
    }
};
Graph materialize_live_records(const Graph& source) {
    Graph result;
    result.name = source.name;
    result.nodes = source.nodes;
    for (const auto& n : result.nodes) {
        result.next_node = std::max(result.next_node, n.id + 1);
        for (Id p : n.pins) result.next_pin = std::max(result.next_pin, p + 1);
    }
    // The serialized payload has no remembered node/pin high-water marks.
    return result;
}
Id join_counter(Id a, Id b) {
    return (!a || !b) ? 0 : std::max(a, b);
}
void preserve(Graph& destination, const Graph& source, bool corrected) {
    destination.next_variable = std::max(destination.next_variable, source.next_variable);
    if (corrected) {
        destination.next_node = join_counter(destination.next_node, source.next_node);
        destination.next_pin = join_counter(destination.next_pin, source.next_pin);
    }
}
void exchange_content(Graph& live, Graph& parked, bool corrected) {
    preserve(live, parked, corrected);
    preserve(parked, live, corrected);
    std::swap(live, parked);
}
struct BatchResult { Node inserted; Graph parked; };
BatchResult batch_insert(Graph& live, bool corrected) {
    Graph candidate = materialize_live_records(live);
    preserve(candidate, live, corrected);
    candidate.name = "batch";                // intent 1
    Node inserted = candidate.add_node();     // intent 2
    exchange_content(live, candidate, corrected);
    return {inserted, std::move(candidate)};
}
bool pin_intersection(const Node& a, const Node& b) {
    for (Id p : a.pins)
        if (std::find(b.pins.begin(), b.pins.end(), p) != b.pins.end()) return true;
    return false;
}
struct Observation { Id old_node, new_node; bool reused_node, reused_pin; };
Observation undo_then_branch(bool corrected) {
    Graph live;
    live.add_node();
    auto batch = batch_insert(live, corrected);
    exchange_content(live, batch.parked, corrected);  // Undo
    Node next = live.add_node();                     // new branch, not Redo
    return {batch.inserted.id, next.id, batch.inserted.id == next.id,
            pin_intersection(batch.inserted, next)};
}
Observation deleted_highest_then_batch(bool corrected) {
    Graph live;
    live.add_node();
    Node retired = live.add_node();
    live.erase_node(retired.id);
    auto batch = batch_insert(live, corrected);      // re-materializes only live nodes
    return {retired.id, batch.inserted.id, retired.id == batch.inserted.id,
            pin_intersection(retired, batch.inserted)};
}
void emit(const char* route, bool corrected, const Observation& o, bool comma) {
    std::cout << (comma ? ",\n" : "") << "  {\"route\":\"" << route
      << "\",\"corrected\":" << std::boolalpha << corrected
      << ",\"old_node\":" << o.old_node << ",\"new_node\":" << o.new_node
      << ",\"reused_node\":" << o.reused_node << ",\"reused_pin\":" << o.reused_pin << "}";
}
int main() {
    std::cout << "[\n";
    bool comma = false;
    for (bool fixed : {false, true}) {
        const auto a = undo_then_branch(fixed);
        const auto b = deleted_highest_then_batch(fixed);
        emit("undo_then_branch", fixed, a, comma); comma = true;
        emit("deleted_highest_then_batch", fixed, b, comma);
        if (a.reused_node == fixed || a.reused_pin == fixed ||
            b.reused_node == fixed || b.reused_pin == fixed) return 3;
    }
    std::cout << "\n]\n";
    return 0; // probe observations matched; original algorithm is NOT approved
}
