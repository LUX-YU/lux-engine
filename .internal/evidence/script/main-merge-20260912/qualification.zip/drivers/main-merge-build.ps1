param([ValidateSet('d','t')][string]$Slot, [string]$Label = 'initial')
$ErrorActionPreference = 'Stop'
$r = $PSScriptRoot
$q = "$r/local-source"
$b = "E:/SyncForder/CodeRepos/build/RelWithDebInfo/o/w/$Slot"
$out = "$r/main-merge-20260912"
$prefix = if ($Slot -eq 't') { 'main-merge-tools' } else { 'main-merge-sdk' }
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
function Run([string]$Name, [string[]]$Command) {
    $log = "$out/$Label-$Slot-$Name.log"
    if (Test-Path -LiteralPath $log) { throw "Existing log: $log" }
    $watch = [Diagnostics.Stopwatch]::StartNew()
    & $Command[0] $Command[1..($Command.Length - 1)] *> $log
    $code = $LASTEXITCODE
    @{source=(git -C $q rev-parse HEAD); status=(@(git -C $q status --porcelain) -join "`n");
      command=$Command; exit=$code; seconds=$watch.Elapsed.TotalSeconds} |
        ConvertTo-Json -Depth 5 | Set-Content -LiteralPath "$out/$Label-$Slot-$Name.json"
    Write-Output "$Label-$Slot-$Name exit=$code seconds=$($watch.Elapsed.TotalSeconds)"
    if ($code) { Get-Content -LiteralPath $log -Tail 35; throw "Failed $log" }
}
Run 'configure' @('cmake','-S',$q,'-B',$b,"-DCMAKE_INSTALL_PREFIX=E:/SyncForder/CodeRepos/install/o/na1/$prefix")
Run 'build' @('cmake','--build',$b,'--target','all','-j','4','--','-k','0')
Run 'noop' @('cmake','--build',$b,'--target','all','-j','4','--','-k','0')
if (!(Select-String -LiteralPath "$out/$Label-$Slot-noop.log" -Pattern 'no work to do' -Quiet)) {
    throw 'Second build was not idle'
}
Run 'tests' @('ctest','--test-dir',$b,'-C','RelWithDebInfo','--output-on-failure','-j','1')
Run 'install' @('cmake','--install',$b,'--config','RelWithDebInfo')
Copy-Item -LiteralPath "$b/Testing/Temporary/LastTest.log" -Destination "$out/$Label-$Slot-LastTest.log"
Copy-Item -LiteralPath "$b/CMakeCache.txt" -Destination "$out/$Label-$Slot-CMakeCache.txt"
Copy-Item -LiteralPath "$b/install_manifest.txt" -Destination "$out/$Label-$Slot-install-manifest.txt"
