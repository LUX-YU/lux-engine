$ErrorActionPreference='Stop'
$r='E:/SyncForder/CodeRepos/build/RelWithDebInfo/lua55-v2'
$source='E:/SyncForder/CodeRepos/build/RelWithDebInfo/script-region-opt/final-source'
$dev='E:/SyncForder/CodeRepos/build/RelWithDebInfo/s5/source'
if((git -C $dev status --porcelain) -or (git -C $source status --porcelain)) { throw 'Dirty qualification input' }
git -C $source fetch $dev codex/s6-deep-optimization
if($LASTEXITCODE) { throw 'fetch failed' }
$sha=(git -C $dev rev-parse HEAD).Trim()
git -C $source checkout --detach $sha
if($LASTEXITCODE) { throw 'checkout failed' }
. 'D:/Development/Mircosoft/VisualStudio/Common7/Tools/Launch-VsDevShell.ps1' -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
function Run([string]$name,[string[]]$command) {
    $path="$r/$name.log"
    if(Test-Path -LiteralPath $path) { throw "Existing log $path" }
    $command|ConvertTo-Json -Compress|Set-Content -LiteralPath $path
    $watch=[Diagnostics.Stopwatch]::StartNew()
    & $command[0] $command[1..($command.Length-1)] *>>$path
    $code=$LASTEXITCODE
    @{source=$sha;command=$command;exit=$code;seconds=$watch.Elapsed.TotalSeconds} |
        ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$r/$name.json"
    Write-Output "$name exit=$code"
    if($code) { throw "$name failed" }
}
Run 'final-tracked' @('cmake',"-DLUX_SOURCE_DIR=$source",'-P',"$source/cmake/ValidateTrackedSnapshot.cmake")
foreach($slot in @('t','d')) {
    $build="E:/SyncForder/CodeRepos/build/RelWithDebInfo/o/w/$slot"
    $prefix=if($slot -eq 't') { 'E:/SyncForder/CodeRepos/install/o/v2/tools' } else {
        'E:/SyncForder/CodeRepos/install/o/v2/sdk' }
    Run "final-$slot-configure" @('cmake','-S',$source,'-B',$build,'-ULUX_LUA_VM',
        '-DLuxLua55_DIR=E:/SyncForder/CodeRepos/install/o/v2/lua55/lib/cmake/LuxLua55',"-DCMAKE_INSTALL_PREFIX=$prefix")
    Run "final-$slot-build" @('cmake','--build',$build,'--target','all','-j','4','--','-k','0')
    if($slot -eq 't') {
        Run 'final-artifacts' @('cmake','--build',$build,'--target','physics2d_flowforge_fixture',
            'physics2d_lua_fixture','lua_runtime_benchmark_fixture','lua_portability_fixture','-j','4','--','-k','0')
    }
    Run "final-$slot-noop" @('cmake','--build',$build,'--target','all','-j','4','--','-k','0')
    if(!(Select-String -LiteralPath "$r/final-$slot-noop.log" -SimpleMatch 'no work to do' -Quiet)) {
        throw 'Expected a no-work second build'
    }
    $env:PATH="$build/bin;D:/Development/vcpkg/installed/x64-windows/bin;"+$env:PATH
    Run "final-$slot-tests" @('ctest','--test-dir',$build,'--output-on-failure','-j','1')
    Copy-Item -LiteralPath "$build/Testing/Temporary/LastTest.log" -Destination "$r/final-$slot-LastTest.log"
    Run "final-$slot-install" @('cmake','--install',$build)
    Copy-Item -LiteralPath "$build/install_manifest.txt" -Destination "$r/final-$slot-install-manifest.txt"
}
Write-Output "FINAL_BUILD_INSTALL_COMPLETE $sha"
